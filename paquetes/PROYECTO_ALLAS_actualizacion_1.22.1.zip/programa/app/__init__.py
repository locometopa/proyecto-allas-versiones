"""PROYECTO ALLAS · software de gestión y cobro de parking (local, sin Internet)."""
NOMBRE = "PROYECTO ALLAS"
__version__ = "1.22.1"
FECHA_VERSION = "2026-10-15"   # fecha de publicación: las licencias cubren actualizaciones hasta una fecha
VERSION_COMPLETA = f"{NOMBRE} v{__version__}"
