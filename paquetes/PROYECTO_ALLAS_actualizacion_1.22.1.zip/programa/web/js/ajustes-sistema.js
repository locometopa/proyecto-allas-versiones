/* PROYECTO ALLAS · Ajustes → Sistema */
"use strict";

// ========================================================= Importar y exportar


// Menú desplegable «Exportar ▾» con una opción por formato (1.6)
function menuFormatos(id, etiqueta, opciones, clase = "") {
  return `<details class="menu-fmt" id="${id}"><summary class="btn ${clase}">${etiqueta}</summary><div class="menu-fmt-lista">${opciones.map(([k, t, ayuda]) =>
    `<button type="button" data-k="${k}">${t}${ayuda ? `<span class="suave">${ayuda}</span>` : ""}</button>`).join("")}</div></details>`;
}
const FORMATOS_MENU = [["csv", "CSV", "para Excel en español"], ["xlsx", "Excel (.xlsx)", "recomendado"], ["xls", "Excel antiguo (.xls)", "Excel 97-2003"], ["pdf", "PDF", "para leer o imprimir"]];
const FORMATOS_PLANTILLA = FORMATOS_MENU.slice(0, 3);

// Enlaza un menú: al elegir una opción se cierra y se llama a alElegir(clave). Cierra también al pulsar fuera o con Escape.
function enlazarMenu(el, id, alElegir) {
  const m = $("#" + id, el);
  if (!m) return;
  $$("[data-k]", m).forEach((b) => (b.onclick = () => { m.open = false; alElegir(b.dataset.k); }));
  m.addEventListener("keydown", (e) => { if (e.key === "Escape") { m.open = false; $("summary", m).focus(); } });
}
document.addEventListener("click", (e) => {
  $$("details.menu-fmt[open]").forEach((m) => { if (!m.contains(e.target)) m.open = false; });
});

const ajImportar = accion(async (el) => {
  const ab = tieneModulo("abonados"), tienda = tieneModulo("tienda");
  const [rNo, rTodos] = await Promise.all(["no_abonados", "todos"].map((a) => api("GET", "/api/clientes/borrar-todos?ambito=" + a).catch(() => null)));
  const queClientes = [ab ? ["clientes-abonados", "Abonados"] : null, [ab ? "clientes-no-abonados" : "clientes-todos", ab ? "Clientes sin abono" : "Clientes"],
    ab ? ["clientes-todos", "Todos los clientes"] : null, ab ? ["abonados", "Listado de abonados con su bono"] : null].filter(Boolean);
  const queCatalogo = [["servicios", "Servicios"], tienda ? ["productos", "Productos de tienda"] : null, ["tarifas", "Tarifas (resumen)"]].filter(Boolean);
  const selector = (id, lista) => `<select class="ent" id="${id}" style="flex:1;min-width:160px">${lista.map(([k, t]) => `<option value="${k}">${esc(t)}</option>`).join("")}</select>`;
  el.innerHTML = `<p class="suave" style="margin:0 0 14px;max-width:900px">Listados para llevar a otro programa o a otro PC, y para cargar datos desde una hoja de cálculo.
      Se puede <b>exportar</b> en CSV, Excel (.xlsx), Excel antiguo (.xls) y PDF; <b>importar</b> en Excel (.xlsx, .xls) y CSV (un PDF no tiene columnas fiables, solo sirve para leer o imprimir).
      Para llevarse <b>todo</b> (movimientos, facturas, clientes…) use <a href="#" id="ie-copias">las copias de seguridad</a>.</p>
    <div class="rejilla r2 ie44">
    <div class="panel"><h3 class="titulo-icono">${icono("subir", 20)}${ab ? "Abonados y clientes" : "Clientes"}</h3>
      <h4 style="margin:10px 0 6px">Importar</h4>
      <p class="suave" style="margin:0 0 10px">Archivo <b>.xlsx, .xls o .csv</b>. Usted decide qué columna es cada dato
        ${ab ? "y si son <b>abonados</b> o <b>clientes sin abono</b> (de horas, productos o servicios: solo datos para facturas)" : ""}; antes de importar verá qué cambia.</p>
      <div class="fila"><button class="btn prim" id="ie-imp-cli">Importar ${ab ? "abonados o clientes" : "clientes"}…</button>
        ${menuFormatos("ie-pl-cli", "Plantilla", FORMATOS_PLANTILLA)}</div>
      <h4 style="margin:16px 0 6px">Exportar</h4>
      <div class="fila">${selector("ie-q-cli", queClientes)}${menuFormatos("ie-ex-cli", "Exportar", FORMATOS_MENU, "prim")}</div>
      <p class="suave" style="margin:6px 0 0;font-size:.85rem">Las columnas de «${ab ? "Abonados, Clientes sin abono y Todos" : "Clientes"}» son las de la plantilla, así que se pueden volver a importar.</p></div>
    <div class="panel"><h3 class="titulo-icono">${icono("nota", 20)}Tarifas, servicios y productos</h3>
      <h4 style="margin:10px 0 6px">Importar</h4>
      <p class="suave" style="margin:0 0 10px"><b>Servicios y productos</b>: hoja de cálculo (.xlsx, .xls, .csv) o archivo .json de PROYECTO ALLAS.
        Las <b>tarifas</b> solo desde el .json (llevan tramos y horarios). Verá lo que cambia y antes se hace una copia de seguridad.</p>
      <div class="fila"><button class="btn prim" id="ie-imp-cfg">Importar…</button>
        ${menuFormatos("ie-pl-cfg", "Plantilla", FORMATOS_PLANTILLA)}</div>
      <h4 style="margin:16px 0 6px">Exportar</h4>
      <div class="fila">${selector("ie-q-cfg", queCatalogo)}${menuFormatos("ie-ex-cfg", "Exportar", FORMATOS_MENU, "prim")}</div>
      <div class="fila" style="margin-top:10px"><span class="suave" style="flex:1">Copia completa para restaurar o llevar a otro PC con PROYECTO ALLAS:</span>
        ${menuFormatos("ie-json", "Copia .json", [["tarifas", "Tarifas"], ["servicios", "Servicios"], ...(tienda ? [["productos", "Productos de tienda"]] : []), ["todo", "Todo junto", "tarifas, servicios y productos"]])}</div></div>
    ${rTodos ? `<div class="panel ie-peligro" id="ie-borrar" style="grid-column:1/-1"><h3 style="color:var(--rojo)">Borrar clientes</h3>
      <p class="suave" style="margin:6px 0 10px">Borra de una vez los datos de los clientes, con sus vehículos y fotos. Las <b>facturas ya emitidas no cambian</b>: guardan su propia copia del nombre, NIF y dirección.
        <b>No se borran</b> los que tienen o tuvieron un bono, los que tienen una suscripción ni los que tienen un vehículo dentro (para conservar la contabilidad). Antes se hace una copia de seguridad.</p>
      <div class="fila">${ab && rNo ? `<label class="campo" style="min-width:230px">Qué clientes<select class="ent" id="ie-ambito"><option value="no_abonados">Solo los clientes sin abono</option><option value="todos">Todos los clientes</option></select></label>` : ""}
        <span id="ie-borrar-info" class="suave" style="flex:1"></span>
        <button class="btn peligro" id="ie-borrar-b">Borrar…</button></div></div>` : ""}</div>`;
  $("#ie-copias", el).onclick = (e) => { e.preventDefault(); irAjustes("copias"); };
  $("#ie-imp-cli", el).onclick = () => asistenteImportarClientes();
  enlazarMenu(el, "ie-pl-cli", (f) => descargarUrl(`/api/plantilla/clientes.${f}`));
  enlazarMenu(el, "ie-pl-cfg", (f) => descargarUrl(`/api/plantilla/servicios.${f}`));
  enlazarMenu(el, "ie-ex-cli", (f) => descargarUrl(`/api/exportar/tabla/${$("#ie-q-cli", el).value}.${f}`));
  enlazarMenu(el, "ie-ex-cfg", (f) => descargarUrl(`/api/exportar/tabla/${$("#ie-q-cfg", el).value}.${f}`));
  enlazarMenu(el, "ie-json", (k) => (k === "todo" ? exportarConfig() : descargarUrl(`/api/exportar/${k}.json`)));
  $("#ie-imp-cfg", el).onclick = () => modalImportarConfig(["tarifas", "servicios", "articulos"], () => ajImportar(el));
  if (!rTodos) return;
  const ambito = () => ($("#ie-ambito", el) ? $("#ie-ambito", el).value : "todos");
  const resumen = () => (ambito() === "todos" ? rTodos : rNo);
  const motivos = (r) => [r.motivos.bono ? `${r.motivos.bono} con bono` : "", r.motivos.suscripcion ? `${r.motivos.suscripcion} con suscripción` : "",
    r.motivos.dentro ? `${r.motivos.dentro} con vehículo dentro` : ""].filter(Boolean).join(", ");
  const pintarBorrar = () => {
    const r = resumen();
    $("#ie-borrar-info", el).innerHTML = `<b>${r.borrables}</b> se pueden borrar` + (r.se_quedan ? ` · ${r.se_quedan} se quedan (${esc(motivos(r))})` : "");
    $("#ie-borrar-b", el).disabled = !r.borrables;
    $("#ie-borrar-b", el).textContent = r.borrables ? `Borrar ${r.borrables} cliente(s)…` : "Nada que borrar";
  };
  pintarBorrar();
  if ($("#ie-ambito", el)) $("#ie-ambito", el).onchange = pintarBorrar;
  $("#ie-borrar-b", el).onclick = () => {
    const r = resumen(), amb = ambito();
    const m = modal(`<h2 style="color:var(--rojo)">Borrar ${r.borrables} cliente(s)</h2>
      <p>${amb === "todos" ? "Todos los clientes" : "Los clientes sin abono"} que no tienen bono, suscripción ni vehículo dentro. Por ejemplo: ${r.ejemplos.map(esc).join(", ")}${r.borrables > r.ejemplos.length ? "…" : ""}</p>
      <p class="suave">Las facturas emitidas no cambian. Se hace una copia de seguridad antes; para deshacerlo habría que restaurarla.</p>
      <div class="rejilla r2" style="margin-top:10px"><label class="campo">Escriba BORRAR<input class="ent" id="nb-conf" autocomplete="off"></label>
        <label class="campo">Su PIN<input class="ent" type="password" inputmode="numeric" id="nb-pin" autocomplete="off"></label></div>
      <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn peligro" data-ok>Borrar</button></div>`);
    $("[data-c]", m).onclick = cerrarModal;
    $("[data-ok]", m).onclick = accion(async () => {
      const x = await api("POST", "/api/clientes/borrar-todos", { ambito: amb, confirmacion: $("#nb-conf", m).value, pin: $("#nb-pin", m).value });
      cerrarModal(); toast(`${x.borrados} cliente(s) borrados (se hizo una copia de seguridad antes)`, "ok");
      ajImportar(el);
    });
  };
});

function irImportarExportar() {
  irAjustes("importar");
}

function exportarConfig() {
  const a = document.createElement("a");
  a.href = "/api/config/exportar?token=" + encodeURIComponent(S.token); a.download = "";
  document.body.appendChild(a); a.click(); a.remove();
  toast("Se ha descargado el archivo con las tarifas y los servicios. Guárdelo para restaurarlo o llevarlo a otro PC.", "ok");
}

const ACCION_IMPORT = { nueva: ["e-pagado", "Nueva"], actualizar: ["e-aviso", "Se actualiza"], igual: ["e-salido", "Sin cambios"],
  desactivar: ["e-err", "Se desactiva"], eliminar: ["e-err", "Se elimina"] };

function modalImportarConfig(queInicial, alTerminar) {
  // Tarifas, servicios y productos de tienda por separado («productos» de antes = servicios + productos)
  const ini = (queInicial || ["tarifas", "servicios", "articulos"]).flatMap((q) => (q === "productos" ? ["servicios", "articulos"] : [q]));
  const st = { datos: null, nombre: "", modo: "combinar", que: new Set(ini), vista: null };
  const grupoDe = (a) => (a.tipo === "tarifa" ? "tarifas" : a.tipo === "producto" ? "articulos" : "servicios");
  const m = modal(`<h2>Importar tarifas, servicios y productos</h2>
    <p class="suave">Elija un archivo <b>.json</b> exportado desde PROYECTO ALLAS (de este u otro PC) o una hoja de cálculo <b>.xlsx, .xls o .csv</b> de servicios o productos (con las columnas de la plantilla). Verá lo que va a cambiar antes de aplicarlo, y se hará una copia de seguridad.</p>
    <div class="fila" style="margin:8px 0"><label class="btn">Elegir archivo…<input type="file" id="im-arch" accept=".json,.xlsx,.xls,.csv,application/json" hidden></label>
      <label class="fila suave">Si no trae columna «Tipo», son <select class="ent" id="im-tipo" style="width:auto"><option value="servicios">servicios</option><option value="productos">productos de tienda</option></select></label></div>
    <span id="im-nombre" class="suave"></span>
    <div id="im-cuerpo"></div>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok disabled>Importar</button></div>`, { ancho: true });
  const cuerpo = $("#im-cuerpo"), ok = $("[data-ok]", m);
  const pintar = () => {
    const v = st.vista;
    const filas = v ? v.acciones.filter((a) => st.que.has(grupoDe(a))) : [];
    const nProd = (t) => (st.datos.productos || []).filter((p) => (p.tipo || "servicio") === t).length;
    cuerpo.innerHTML = !st.datos ? (st.error ? `<div class="aviso rojo">${esc(st.error)}</div>` : "") : `
      ${v && v.origen ? `<p class="suave" style="margin:6px 0">${esc(v.origen.software || "")}${v.origen.empresa ? " · " + esc(v.origen.empresa) : ""}${v.origen.fecha ? " · exportado el " + fechaHora(v.origen.fecha) : ""}</p>` : ""}
      <div class="fila" style="margin:10px 0">
        <label class="fila"><input type="checkbox" data-que="tarifas" ${st.que.has("tarifas") ? "checked" : ""}> Tarifas (${(st.datos.tarifas || []).length})</label>
        <label class="fila"><input type="checkbox" data-que="servicios" ${st.que.has("servicios") ? "checked" : ""}> Servicios (${nProd("servicio")})</label>
        <label class="fila"><input type="checkbox" data-que="articulos" ${st.que.has("articulos") ? "checked" : ""}> Productos de tienda (${nProd("producto")})</label></div>
      <div class="metodos" style="margin:8px 0">
        <button class="btn ${st.modo === "combinar" ? "sel" : ""}" data-modo="combinar">Combinar<br><span class="suave" style="font-size:.8rem;font-weight:500">añade y actualiza; no quita nada</span></button>
        <button class="btn ${st.modo === "reemplazar" ? "sel" : ""}" data-modo="reemplazar">Reemplazar<br><span class="suave" style="font-size:.8rem;font-weight:500">deja solo lo que trae el archivo</span></button></div>
      ${st.error ? `<div class="aviso rojo">${esc(st.error)}</div>` : ""}
      ${st.avisos && st.avisos.length ? `<div class="aviso">${st.avisos.slice(0, 8).map(esc).join("<br>")}${st.avisos.length > 8 ? `<br>…y ${st.avisos.length - 8} más` : ""}</div>` : ""}
      ${v ? `<table class="tabla" style="margin-top:8px"><tbody>${filas.map((a) => `<tr><td>${a.tipo === "tarifa" ? "Tarifa" : a.tipo === "producto" ? "Producto" : "Servicio"}</td>
        <td><b>${esc(a.nombre)}</b></td><td class="der"><span class="etiqueta ${ACCION_IMPORT[a.accion][0]}">${ACCION_IMPORT[a.accion][1]}</span></td></tr>`).join("")}</tbody></table>
        <p class="suave" style="margin-top:8px">${v.cambios ? `${v.cambios} cambio(s).` : "No hay nada que cambiar."} Las tarifas que se cambian o desactivan siguen valiendo para los vehículos que ya están dentro.</p>` : ""}`;
    ok.disabled = !v || !v.cambios || !st.que.size;
    $$("[data-que]", cuerpo).forEach((c) => (c.onchange = () => { c.checked ? st.que.add(c.dataset.que) : st.que.delete(c.dataset.que); previsualizar(); }));
    $$("[data-modo]", cuerpo).forEach((b) => (b.onclick = () => { st.modo = b.dataset.modo; previsualizar(); }));
  };
  const previsualizar = async () => {
    st.error = null; st.vista = null;
    if (st.que.size) {
      try { st.vista = await api("POST", "/api/config/importar", { datos: st.datos, modo: st.modo, que: [...st.que], aplicar: false }); }
      catch (e) { st.error = e.message; }
    }
    pintar();
  };
  $("#im-arch").onchange = async (e) => {
    const f = e.target.files[0];
    if (!f) return;
    $("#im-nombre").textContent = f.name;
    st.avisos = []; st.error = null;
    if (/\.json$/i.test(f.name)) {
      try { st.datos = JSON.parse(await f.text()); } catch (_) { st.datos = {}; }
    } else {
      try {
        const r = await fetch(`/api/config/importar/leer?nombre=${encodeURIComponent(f.name)}&tipo=${$("#im-tipo").value}`,
          { method: "POST", headers: { "X-Token": S.token, "Content-Type": "application/octet-stream" }, body: f });
        const d = await r.json().catch(() => ({}));
        if (!r.ok) { st.datos = null; st.vista = null; st.error = d.error || "No se pudo leer el archivo"; pintar(); return; }
        st.datos = d.datos; st.avisos = d.avisos || [];
      } catch (e) { st.datos = null; st.error = e.message; pintar(); return; }
    }
    const hay = { tarifas: (st.datos.tarifas || []).length, servicios: (st.datos.productos || []).filter((p) => (p.tipo || "servicio") === "servicio").length,
      articulos: (st.datos.productos || []).filter((p) => p.tipo === "producto").length };
    const quedan = [...st.que].filter((q) => hay[q]);
    if (quedan.length) st.que = new Set(quedan);   // solo lo que trae el archivo
    previsualizar();
  };
  $("[data-c]", m).onclick = cerrarModal;
  ok.onclick = accion(async () => {
    const r = await api("POST", "/api/config/importar", { datos: st.datos, modo: st.modo, que: [...st.que], aplicar: true });
    cerrarModal();
    toast(`Importado: ${r.cambios} cambio(s). Se guardó una copia de seguridad antes.`, "ok");
    await cargarTarifas();
    alTerminar && alTerminar();
  });
}

// Asistente: 1) archivo  2) columnas y opciones (con vista previa)  3) resultado
function asistenteImportarClientes() {
  const ab = tieneModulo("abonados");
  const st = { lectura: null, mapeo: {}, cabecera: true, tipo: ab ? "abonado" : "facturacion", duplicados: "actualizar", sim: null };
  const m = modal(`<h2>Importar clientes</h2>
    <div class="pasos-imp"><span class="activo" data-p="1">1 · Archivo</span><span data-p="2">2 · Columnas</span><span data-p="3">3 · Resultado</span></div>
    <div id="ic-cuerpo"></div>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><span style="flex:1"></span><button class="btn prim" data-ok disabled>Importar</button></div>`, { ancho: true });
  const cuerpo = $("#ic-cuerpo", m), ok = $("[data-ok]", m);
  $("[data-c]", m).onclick = cerrarModal;
  const paso = (n) => $$("[data-p]", m).forEach((x) => x.classList.toggle("activo", Number(x.dataset.p) <= n));

  const pintarArchivo = (error) => {
    paso(1);
    cuerpo.innerHTML = `<label class="zona-archivo" id="ic-zona">
        <input type="file" id="ic-arch" accept=".csv,.txt,.xlsx,.xls" hidden>
        <b>Elija el archivo o arrástrelo aquí</b>
        <span class="suave">Excel (.xlsx o .xls) o CSV (separado por punto y coma, coma o tabulador). La primera fila puede llevar los títulos de las columnas.</span></label>
      ${error ? `<div class="aviso rojo" style="margin-top:10px">${esc(error)}</div>` : ""}
      <p class="ayuda" style="margin-top:10px">¿No sabe cómo prepararlo? Descargue la plantilla en <a href="#" id="ic-plantilla">CSV</a>, <a href="#" id="ic-plantilla-x">Excel</a> o <a href="#" id="ic-plantilla-o">Excel antiguo</a>.</p>`;
    for (const [id, f] of [["ic-plantilla", "csv"], ["ic-plantilla-x", "xlsx"], ["ic-plantilla-o", "xls"]])
      $("#" + id, cuerpo).onclick = (e) => { e.preventDefault(); descargarUrl(`/api/plantilla/clientes.${f}`); };
    const leer = accion(async (f) => {
      if (!f) return;
      cuerpo.innerHTML = `<div class="vacio">Leyendo ${esc(f.name)}…</div>`;
      const r = await fetch("/api/clientes/importar/leer?nombre=" + encodeURIComponent(f.name),
        { method: "POST", headers: { "X-Token": S.token, "Content-Type": "application/octet-stream" }, body: f });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) return pintarArchivo(d.error || "No se pudo leer el archivo");
      st.lectura = d; st.nombre = f.name; st.mapeo = { ...d.sugerencia };
      st.cabecera = Object.keys(d.sugerencia).length > 0;
      pintarColumnas();
    });
    $("#ic-arch", cuerpo).onchange = (e) => leer(e.target.files[0]);
    const zona = $("#ic-zona", cuerpo);
    zona.ondragover = (e) => { e.preventDefault(); zona.classList.add("encima"); };
    zona.ondragleave = () => zona.classList.remove("encima");
    zona.ondrop = (e) => { e.preventDefault(); zona.classList.remove("encima"); leer(e.dataTransfer.files[0]); };
    ok.disabled = true;
  };

  const pintarColumnas = () => {
    paso(2);
    const L = st.lectura, cols = L.cabeceras.length;
    const nombreCol = (i) => (st.cabecera && L.cabeceras[i] ? L.cabeceras[i] : "Columna " + String.fromCharCode(65 + (i % 26)) + (i >= 26 ? Math.floor(i / 26) : ""));
    const campos = L.campos.filter(([id]) => ab || id !== "tipo");
    const filasMuestra = (st.cabecera ? L.muestra : [L.cabeceras, ...L.muestra]).slice(0, 5);
    const usados = new Map(Object.entries(st.mapeo).map(([k, v]) => [Number(v), k]));
    cuerpo.innerHTML = `<p class="suave" style="margin:4px 0 10px"><b>${esc(st.nombre)}</b> · ${L.filas - (st.cabecera ? 1 : 0)} fila(s) de datos</p>
      <label class="fila" style="gap:8px;font-weight:600"><input type="checkbox" id="ic-cab" ${st.cabecera ? "checked" : ""}> La primera fila son los títulos de las columnas</label>
      <div class="rejilla r3 mapeo-imp" style="margin-top:12px">${campos.map(([id, n]) => `<label class="campo">${esc(n)}${id === "nombre" ? " *" : ""}
        <select class="ent" data-campo="${id}"><option value="">— No importar —</option>
        ${Array.from({ length: cols }, (_, i) => `<option value="${i}" ${String(st.mapeo[id]) === String(i) ? "selected" : ""}>${esc(nombreCol(i))}</option>`).join("")}</select></label>`).join("")}</div>
      <div class="tabla-desliza" style="margin-top:12px"><table class="tabla compacta"><thead><tr>${Array.from({ length: cols }, (_, i) =>
        `<th>${esc(nombreCol(i))}${usados.has(i) ? `<br><span class="etiqueta e-pagado">${esc((L.campos.find(([c]) => c === usados.get(i)) || [, ""])[1])}</span>` : ""}</th>`).join("")}</tr></thead>
        <tbody>${filasMuestra.map((f) => `<tr>${f.map((v, i) => `<td class="${usados.has(i) ? "" : "suave"}">${esc(v)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>
      <div class="rejilla r2" style="margin-top:14px">
        ${ab ? `<label class="campo">Si el archivo no dice el tipo, importarlos como
          <select class="ent" id="ic-tipo"><option value="abonado" ${st.tipo === "abonado" ? "selected" : ""}>Abonados</option>
          <option value="facturacion" ${st.tipo === "facturacion" ? "selected" : ""}>Clientes sin abono (horas, productos, servicios)</option></select></label>` : ""}
        <label class="campo">Si el cliente ya existe (mismo NIF, matrícula o email)
          <select class="ent" id="ic-dup"><option value="actualizar" ${st.duplicados === "actualizar" ? "selected" : ""}>Actualizar sus datos y añadir sus vehículos</option>
          <option value="saltar" ${st.duplicados === "saltar" ? "selected" : ""}>Dejarlo como está</option></select></label></div>
      <div id="ic-sim" style="margin-top:12px"></div>`;
    $("#ic-cab", cuerpo).onchange = (e) => { st.cabecera = e.target.checked; pintarColumnas(); };
    $$("[data-campo]", cuerpo).forEach((s) => (s.onchange = () => {
      if (s.value === "") delete st.mapeo[s.dataset.campo]; else st.mapeo[s.dataset.campo] = Number(s.value);
      pintarColumnas();
    }));
    if ($("#ic-tipo", cuerpo)) $("#ic-tipo", cuerpo).onchange = (e) => { st.tipo = e.target.value; simular(); };
    $("#ic-dup", cuerpo).onchange = (e) => { st.duplicados = e.target.value; simular(); };
    simular();
  };

  const cuerpoPeticion = (simularlo) => ({ token: st.lectura.token, mapeo: st.mapeo, cabecera: st.cabecera,
    tipo_defecto: st.tipo, duplicados: st.duplicados, simular: simularlo });
  const listaErrores = (errs) => errs.length ? `<details style="margin-top:8px" ${errs.length <= 5 ? "open" : ""}><summary>${errs.length} fila(s) con problemas (no se importan)</summary>
      <table class="tabla compacta" style="margin-top:6px"><tbody>${errs.slice(0, 200).map((e) => `<tr><td class="num">Fila ${e.fila}</td><td>${esc(e.motivo)}</td></tr>`).join("")}</tbody></table>
      ${errs.length > 200 ? `<p class="suave">… y ${errs.length - 200} más.</p>` : ""}</details>` : "";

  const simular = async () => {
    const caja = $("#ic-sim", cuerpo);
    if (!caja) return;
    ok.disabled = true;
    if (st.mapeo.nombre === undefined) { caja.innerHTML = `<div class="aviso">Indique qué columna tiene el <b>nombre</b> del cliente.</div>`; return; }
    caja.innerHTML = `<div class="suave">Comprobando…</div>`;
    try {
      const r = await api("POST", "/api/clientes/importar", cuerpoPeticion(true));
      st.sim = r;
      caja.innerHTML = `<div class="resumen-imp"><div><b>${r.crear}</b><span>nuevos</span></div><div><b>${r.actualizar}</b><span>se actualizan</span></div>
        <div><b>${r.saltar}</b><span>se dejan igual</span></div><div class="${r.errores.length ? "mal" : ""}"><b>${r.errores.length}</b><span>con problemas</span></div></div>
        ${listaErrores(r.errores)}`;
      ok.disabled = !(r.crear + r.actualizar);
      ok.textContent = `Importar ${r.crear + r.actualizar} cliente(s)`;
    } catch (e) { caja.innerHTML = `<div class="aviso rojo">${esc(e.message)}</div>`; }
  };

  ok.onclick = accion(async () => {
    ok.disabled = true;
    const r = await api("POST", "/api/clientes/importar", cuerpoPeticion(false));
    paso(3);
    cuerpo.innerHTML = `<div class="exito"><div class="icono">✓</div><h2>Importación terminada</h2>
      <p>${r.crear} cliente(s) nuevo(s) · ${r.actualizar} actualizado(s)${r.saltar ? ` · ${r.saltar} sin cambios` : ""}.</p>
      <p class="suave">Antes de importar se hizo una copia de seguridad («antes de importar»).</p></div>${listaErrores(r.errores)}`;
    ok.classList.add("oculto");
    $("[data-c]", m).textContent = "Cerrar";
    $("[data-c]", m).onclick = () => { cerrarModal(); recargarClientes(); };
  });
  pintarArchivo();
}

// ============================================================= Actualizaciones

// Versión instalada, paquetes (subidos o descargados online) y versiones anteriores guardadas
const ajActualizaciones = accion(async (el) => {
  const online = !oculto("actualizaciones_online");   // la búsqueda online se puede ocultar desde Supervisión
  const [a, cfg] = await Promise.all([api("GET", "/api/actualizaciones"), online ? api("GET", "/api/config").catch(() => ({})) : null]);
  // 4.21: pestaña ordenada en tres bloques: versión instalada + acciones, actualización lista (solo si la hay) y lista única de versiones
  // 4.22: solo se ofrece la ÚLTIMA versión; su changelog reúne todo lo que cambia desde la instalada
  const vc = (x, y) => String(x).split(".").map(Number).reduce((r, n, i) => r || n - (Number(String(y).split(".")[i]) || 0), 0);
  const ultima = a.paquetes.filter((p) => !p.error && p.estado === "disponible").sort((x, y) => vc(y.version, x.version))[0];
  const nuevos = [...a.paquetes.filter((p) => p.error), ...(ultima ? [ultima] : [])];
  const AVISO = "Al instalar se hace una copia de seguridad y el programa se reinicia; después todos los usuarios tendrán que volver a entrar.";
  const tarjeta = (p) => p.error
    ? `<div class="paquete"><div class="cab-paq"><span class="mono">${esc(p.archivo)}</span><span class="etiqueta e-err">No válido</span></div><div class="suave">${esc(p.error)}</div></div>`
    : panelNovedades({ de: a.version, a: p.version, fecha: p.fecha ? fechaCorta2(p.fecha) : "", aviso: p.instalable ? AVISO : esc(p.motivo || "Este paquete no se puede instalar"),
        acciones: p.instalable ? `<button class="btn prim grande" data-inst="${esc(p.archivo)}" data-v="${esc(p.version)}">Instalar ${esc(p.version)}</button>`
          : `<span class="etiqueta e-salido" title="${esc(p.motivo || "")}">No se puede instalar</span>`, texto: p.cambios || p.notas });
  el.innerHTML = `<div class="act-pagina">
    <div class="panel">
      <div class="fila" style="justify-content:space-between;gap:12px;flex-wrap:wrap">
        <div><div class="suave" style="font-size:.85rem">Versión instalada</div><div style="font-size:1.6rem;font-weight:800">PROYECTO ALLAS ${esc(a.version)}</div>
          <div class="suave">publicada el ${fechaCorta2(a.fecha_version)}</div></div>
        <div class="fila" style="gap:10px;flex-wrap:wrap">${online ? '<button class="btn prim" id="ac-buscar">Buscar actualizaciones online</button>' : ""}
          <label class="btn${online ? "" : " prim"}">Subir paquete…<input type="file" id="ac-arch" accept=".zip,application/zip" hidden></label></div></div>
      <div id="ac-res" style="margin-top:${online ? 12 : 0}px"></div></div>
    ${nuevos.length ? `<div class="panel" style="margin-top:16px"><div class="fila" style="justify-content:space-between"><h3>Actualización lista para instalar</h3><span class="etiqueta e-pagado">Firmada y comprobada</span></div>
      <div class="nv-lista">${nuevos.map(tarjeta).join("")}</div></div>` : ""}</div>`;
  // 4.62: historial de versiones: las 5 últimas y, si hay más, «Mostrar todas»; descarga completa en .txt
  const hist = a.historial || [];
  const pintarHist = (todas) => {
    const vis = todas ? hist : hist.slice(0, 5);
    $("#ac-hist").innerHTML = `<div class="fila" style="justify-content:space-between;gap:10px;flex-wrap:wrap"><h3>Historial de actualizaciones</h3>
      <div class="fila" style="gap:8px"><span class="suave">${hist.length} ${hist.length === 1 ? "versión" : "versiones"}</span><button class="btn" id="ac-hist-txt">Descargar en texto</button>
        ${a.historial_limpio ? `<button class="btn" id="ac-hist-rest">Mostrar historial completo (${a.historial_total})</button>` : hist.length > 1 ? '<button class="btn" id="ac-hist-limpiar">Limpiar historial</button>' : ""}</div></div>
      ${hist.length ? vis.map((h) => `<details class="plegable" style="margin-top:8px"${h.version === a.version ? " open" : ""}><summary><b>Versión ${esc(h.version)}</b><span class="suave">${esc(h.fecha || "")}</span></summary>
        <div style="padding:6px 4px">${formatoNotas(h.notas)}</div></details>`).join("") : '<p class="suave">Sin historial disponible</p>'}
      ${hist.length > 5 ? `<button class="btn" id="ac-hist-mas" style="margin-top:10px">${todas ? "Mostrar solo las 5 últimas" : `Mostrar todas (${hist.length})`}</button>` : ""}`;
    $("#ac-hist-txt").onclick = () => descargarUrl("/api/actualizaciones/historial.txt", {});
    if ($("#ac-hist-mas")) $("#ac-hist-mas").onclick = () => pintarHist(!todas);
    if ($("#ac-hist-limpiar")) $("#ac-hist-limpiar").onclick = accion(async () => {
      if (!(await confirmar("Limpiar historial", `<p>Se dejará de mostrar el historial de versiones anteriores a la ${esc(a.version)} (${hist.length - 1} ${hist.length === 2 ? "versión" : "versiones"}).</p>
        <p class="suave">Solo cambia lo que se ve aquí y en el archivo de texto: el programa, los datos y el registro de auditoría no se tocan. Puede volver a mostrarlo cuando quiera.</p>`, { boton: "Limpiar historial" }))) return;
      await api("POST", "/api/actualizaciones/limpiar", { historial: "limpiar" });
      toast("Historial limpiado", "ok"); ajActualizaciones(el);
    });
    if ($("#ac-hist-rest")) $("#ac-hist-rest").onclick = accion(async () => {
      await api("POST", "/api/actualizaciones/limpiar", { historial: "restaurar" });
      toast("Historial completo restaurado", "ok"); ajActualizaciones(el);
    });
  };
  const ph = document.createElement("div"); ph.className = "panel"; ph.id = "ac-hist"; ph.style.marginTop = "16px";
  $(".act-pagina", el).appendChild(ph); pintarHist(false);
  montarLimpiezaActualizaciones(el, a);
  $("#ac-arch").onchange = accion(async (e) => {
    const f = e.target.files[0]; if (!f) return;
    const r = await fetch("/api/actualizaciones/subir", { method: "POST", headers: { "X-Token": S.token, "Content-Type": "application/zip" }, body: f });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || "No se pudo subir");
    toast(`Paquete de la versión ${j.version} comprobado: la firma es correcta`, "ok");
    ajActualizaciones(el);
  });
  $$("[data-inst]").forEach((b) => (b.onclick = accion(async () => {
    const pq = a.paquetes.find((x) => x.archivo === b.dataset.inst);
    if (!(await confirmar(`Instalar la versión ${b.dataset.v}`, `${datosConfirmacion({ de: a.version, a: b.dataset.v, fecha: pq && pq.fecha ? fechaCorta2(pq.fecha) : "", novedades: pq && (pq.cambios || pq.notas) })}
      <p>Después todos los usuarios tendrán que volver a entrar. ¿Continuar?</p>`, { boton: "Instalar" }))) return vistaAjustes($("#vista"));
    const r = await api("POST", "/api/actualizaciones/instalar", { archivo: b.dataset.inst });
    esperarReinicio(r.version);
  })));
  if (online) montarActualizacionesOnline(el);
});

// 1.13: limpieza de paquetes (no válidos, ya instalados, anteriores, incompatibles o sin instalar) y de copias de versiones anteriores
const MOTIVO_LIMPIAR = { no_valido: ["No válido", "e-err"], instalada: ["Ya instalada", "e-salido"], anterior: ["Anterior a la instalada", "e-salido"],
  incompatible: ["No se puede instalar", "e-salido"] };
function montarLimpiezaActualizaciones(el, a) {
  const pqs = a.paquetes || [], inutiles = pqs.filter((q) => q.limpiar), copias = a.guardadas || [];
  const pend = pqs.filter((q) => !q.limpiar);
  const cuantos = (n, uno, varios) => `${n} ${n === 1 ? uno : varios}`;
  const pesoCopias = copias.reduce((t, g) => t + (g.tamano || 0), 0);
  const fila = (q) => {
    const [txt, cls] = q.limpiar ? MOTIVO_LIMPIAR[q.limpiar] : ["Pendiente de instalar", "e-pagado"];
    return `<tr><td class="mono">${esc(q.archivo)}</td><td class="num">${q.version ? esc(q.version) : "–"}</td>
      <td><span class="etiqueta ${cls}"${q.motivo || q.error ? ` title="${esc(q.motivo || q.error)}"` : ""}>${txt}</span></td>
      <td class="der num">${tamano(q.tamano)}</td><td class="der"><button class="btn mini" data-quitar="${esc(q.archivo)}">Eliminar</button></td></tr>`;
  };
  const ph = document.createElement("div"); ph.className = "panel"; ph.id = "ac-limpieza"; ph.style.marginTop = "16px";
  ph.innerHTML = `<div class="fila" style="justify-content:space-between;gap:10px;flex-wrap:wrap"><h3>Limpieza de actualizaciones</h3>
      <span class="suave">${cuantos(pqs.length, "paquete", "paquetes")} · ${cuantos(copias.length, "copia anterior", "copias anteriores")}</span></div>
    <p class="suave" style="margin:6px 0 10px">Los paquetes son los archivos de actualización guardados en este equipo (subidos o descargados). Quitarlos no cambia la versión instalada.</p>
    ${pqs.length ? `<div class="tabla-desliza"><table class="tabla"><thead><tr><th>Archivo</th><th>Versión</th><th>Estado</th><th class="der">Tamaño</th><th></th></tr></thead><tbody>${pqs.map(fila).join("")}</tbody></table></div>`
      : '<p class="suave">No hay paquetes guardados.</p>'}
    <div class="fila" style="gap:8px;flex-wrap:wrap;margin-top:12px">
      <button class="btn prim" id="ac-l-inutiles"${inutiles.length ? "" : " disabled"}>Quitar los que no sirven (${inutiles.length})</button>
      ${pend.length ? `<button class="btn" id="ac-l-todos">Quitar también los pendientes (${pend.length})</button>` : ""}
      ${copias.length ? `<button class="btn" id="ac-l-copias">Borrar copias de versiones anteriores (${copias.length} · ${tamano(pesoCopias)})</button>` : ""}</div>
    <p class="ayuda" style="margin-top:8px">«Los que no sirven» son los no válidos, los ya instalados, los de una versión anterior y los que esta licencia o versión no admite.
      Las copias de versiones anteriores solo ocupan espacio: el programa no permite volver atrás desde aquí.</p>`;
  $(".act-pagina", el).appendChild(ph);
  const limpiar = (cuerpo, titulo, texto, boton) => accion(async () => {
    if (!(await confirmar(titulo, texto, { boton }))) return;
    const r = await api("POST", "/api/actualizaciones/limpiar", cuerpo);
    toast(`Limpieza hecha: ${cuantos(r.paquetes, "paquete", "paquetes")}, ${cuantos(r.copias, "copia", "copias")} (${tamano(r.liberado)} liberados)`, "ok");
    ajActualizaciones(el);
  });
  if ($("#ac-l-inutiles", ph)) $("#ac-l-inutiles", ph).onclick = limpiar({ paquetes: "inutiles" }, "Quitar paquetes que no sirven",
    `<p>Se eliminarán ${cuantos(inutiles.length, "paquete", "paquetes")} de este equipo (no válidos, ya instalados, anteriores o no instalables).</p>`, "Quitar");
  if ($("#ac-l-todos", ph)) $("#ac-l-todos", ph).onclick = limpiar({ paquetes: "todos" }, "Quitar todos los paquetes",
    `<p>Se eliminarán los ${pqs.length} paquetes, también ${cuantos(pend.length, "pendiente de instalar", "pendientes de instalar")}. Para instalarlos habría que volver a subirlos o descargarlos.</p>`, "Quitar todos");
  if ($("#ac-l-copias", ph)) $("#ac-l-copias", ph).onclick = limpiar({ copias: true }, "Borrar copias de versiones anteriores",
    `<p>Se borrarán ${cuantos(copias.length, "copia", "copias")} del programa (${tamano(pesoCopias)}). Los datos y las copias de seguridad no se tocan.</p>`, "Borrar");
  $$("[data-quitar]", ph).forEach((b) => (b.onclick = limpiar({ paquetes: [b.dataset.quitar] }, "Eliminar paquete",
    `<p>Se eliminará <span class="mono">${esc(b.dataset.quitar)}</span> de este equipo.</p>`, "Eliminar")));
}

// Buscar actualizaciones online (de dónde salen —servidor o Drive— lo decide la configuración interna; el usuario solo ve el botón)
function vc2(x, y) { return String(x).split(".").map(Number).reduce((r, n, i) => r || n - (Number(String(y).split(".")[i]) || 0), 0); }

function montarActualizacionesOnline(el) {
  const caja = el, res = $("#ac-res", el);
  const descargar = async (b) => api("POST", "/api/actualizaciones/online/descargar", { archivo: b.dataset.desc, sha256: b.dataset.sha, id: b.dataset.id });
  $("#ac-buscar", caja).onclick = accion(async () => {
    res.innerHTML = '<div class="vacio" style="padding:14px">Buscando…</div>';
    let r;
    try { r = await api("GET", "/api/actualizaciones/online"); } catch (e) { res.innerHTML = `<div class="aviso">${esc(e.message)}</div>`; return; }
    const nuevas = r.paquetes.filter((p) => p.nueva).sort((x, y) => vc2(y.version, x.version));
    const p = nuevas[0];   // 4.22: solo la última; sus novedades reúnen las de todas las versiones nuevas
    res.dataset.cambios = "";
    const deNotas = nuevas.filter((q) => (q.notas || "").trim()).map((q) => `## Versión ${q.version}\n${(q.notas || "").replace(/^## .*$/gm, "")}`).join("\n\n");
    const cambios = p && p.cambios ? p.cambios : deNotas || "Las novedades de esta versión se mostrarán aquí en cuanto se descargue el paquete.";
    res.dataset.cambios = cambios;
    res.innerHTML = !p ? '<p class="suave" style="margin:0">Está al día: no hay versiones más nuevas que la instalada.</p>'
      : panelNovedades({ de: r.version, a: p.version, fecha: p.fecha ? fechaCorta2(p.fecha) : "", extra: p.tamano ? tamanoTxt(p.tamano) : "",
          aviso: "Se descarga, se comprueba su firma y, al instalar, se hace una copia de seguridad y el programa se reinicia.",
          acciones: p.descargada ? '<span class="etiqueta e-pagado">Descargada: lista para instalar más abajo</span>'
            : `<button class="btn" data-desc="${esc(p.archivo)}" data-sha="${esc(p.sha256 || "")}" data-id="${esc(p.id || "")}" data-v="${esc(p.version)}">Descargar</button>
               <button class="btn prim grande" data-desc="${esc(p.archivo)}" data-sha="${esc(p.sha256 || "")}" data-id="${esc(p.id || "")}" data-v="${esc(p.version)}" data-ya="1">Descargar e instalar</button>`, texto: cambios });
    $$("[data-desc]", res).forEach((b) => (b.onclick = accion(async () => {
      if (b.dataset.ya && !(await confirmar(`Descargar e instalar la versión ${b.dataset.v}`, `${datosConfirmacion({ de: r.version, a: b.dataset.v, fecha: p.fecha ? fechaCorta2(p.fecha) : "", tamano: p.tamano ? tamanoTxt(p.tamano) : "", novedades: res.dataset.cambios, descarga: true })}
        <p>Después todos los usuarios tendrán que volver a entrar. ¿Continuar?</p>`, { boton: "Descargar e instalar" }))) return;
      const txt = b.textContent; b.disabled = true; b.textContent = "Descargando…";
      let d;
      try { d = await descargar(b); } finally { b.disabled = false; b.textContent = txt; }
      if (b.dataset.ya) { const i = await api("POST", "/api/actualizaciones/instalar", { archivo: d.archivo }); return esperarReinicio(i.version); }
      toast(`Versión ${d.version} descargada y comprobada: ya está lista para instalar más abajo`, "ok");
      ajActualizaciones(el);
    })));
  });
}

// 4.47: datos de la ventana de confirmación (sin repetir las novedades, que ya se ven en el panel)
function datosConfirmacion({ de, a, fecha, tamano, novedades, descarga }) {
  const n = (String(novedades || "").match(/^\s*[-*•]\s+/gm) || []).length;
  const fila = (k, v) => `<tr><td class="suave">${k}</td><td><b>${v}</b></td></tr>`;
  return `<table class="tabla" style="margin:8px 0 12px"><tbody>${fila("Versión", `${esc(de)} → ${esc(a)}`)}${fecha ? fila("Publicada", esc(fecha)) : ""}
    ${tamano ? fila("Tamaño", esc(tamano)) : ""}${n ? fila("Novedades", `${n}`) : ""}
    ${fila("Antes de instalar", "copia de seguridad automática")}${descarga ? fila("Paquete", "se comprueba su firma al descargar") : ""}
    ${fila("Tiempo estimado", "unos segundos (el programa se reinicia)")}</tbody></table>`;
}

// 4.33: panel de «nueva versión»: de dónde a dónde, cuántas novedades, acción principal y novedades en una sola columna con desplazamiento
function panelNovedades({ de, a, fecha, extra, acciones, texto, aviso }) {
  const t = String(texto || "");
  const versiones = (t.match(/^#{1,4}\s+(?:Versión\s+)?\d+(?:\.\d+)+/gim) || []).length;
  const cambios = (t.match(/^\s*[-*•]\s+/gm) || []).length;
  const resumen = [fecha, extra, cambios ? `${cambios} novedad${cambios === 1 ? "" : "es"}${versiones > 1 ? ` en ${versiones} versiones` : ""}` : ""].filter(Boolean).join(" · ");
  return `<div class="nv">
    <div class="nv-cab">
      <div class="nv-ver"><div class="nv-ruta"><span class="nv-de">${esc(de)}</span><span class="nv-flecha" aria-hidden="true">→</span><span class="nv-a">${esc(a)}</span></div>
        <div class="nv-sub">${esc(resumen)}</div></div>
      <div class="nv-acc">${acciones}</div></div>
    ${aviso ? `<div class="nv-aviso">${aviso}</div>` : ""}
    <div class="nv-tit">Novedades desde la versión ${esc(de)}</div>
    <div class="nv-cuerpo">${formatoNotas(t)}</div></div>`;
}

// 4.62: tras los «:» de la etiqueta de cada novedad, la primera letra va en mayúscula
function mayusEtiqueta(l) {
  const up = (x) => x.toLocaleUpperCase("es");
  let m = l.match(/^([-*•]\s+)(\*\*.+?\*\*)(.*)$/);
  if (m) return m[1] + m[2].replace(/(:[ \t]+)([a-záéíóúüñ])/g, (_, a, b) => a + up(b)) + m[3].replace(/^([\s.,:;—–-]*)([a-záéíóúüñ])/, (_, a, b) => a + up(b));
  m = l.match(/^([-*•]\s+[^:`]{1,80}:[ \t]+)([a-záéíóúüñ])(.*)$/);
  return m ? m[1] + up(m[2]) + m[3] : l;
}

function formatoNotas(texto) {
  // 4.25: changelog con formato cuidado: cabecera por versión (píldora + fecha), apartados y tarjetas de novedad (título en negrita + detalle)
  const t = String(texto || "").trim();
  if (!t) return '<span class="suave">Sin notas</span>';
  const enLinea = (s) => esc(s).replace(/\\\*/g, "&#42;").replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/(^|[\s(])\*([^*\s][^*]*?)\*(?=[\s).,:;]|$)/g, "$1<i>$2</i>")
    .replace(/`([^`]+)`/g, '<span class="mono">$1</span>');
  let html = "", lista = false;
  const cerrar = () => { if (lista) { html += "</ul>"; lista = false; } };
  const item = (txt) => {
    const m = txt.match(/^\*\*(.+?)\*\*[\s.,:;—–-]*(.*)$/);
    return m ? `<li class="nt-item"><b class="nt-t">${enLinea(m[1])}</b>${m[2] ? `<span class="nt-d">${enLinea(m[2])}</span>` : ""}</li>`
      : `<li class="nt-item"><span class="nt-d nt-solo">${enLinea(txt)}</span></li>`;
  };
  for (const bruta of t.split(/\r?\n/)) {
    const l = mayusEtiqueta(bruta.trim());
    if (!l) { cerrar(); continue; }
    const tit = l.match(/^#{1,4}\s+(.*)$/);
    const vi = l.match(/^[-*•]\s+(.*)$/);
    if (tit) {
      cerrar();
      const v = tit[1].match(/^(?:Versión\s+)?(\d+(?:\.\d+)+)\s*(?:[—–-]\s*(.*))?$/i);
      html += v ? `<div class="nt-ver"><span class="nt-v">Versión ${esc(v[1])}</span>${v[2] ? `<span class="nt-f">${esc(v[2])}</span>` : ""}</div>`
        : `<div class="nt-tit">${enLinea(tit[1])}</div>`;
    }
    else if (vi) { if (!lista) { html += '<ul class="nt-lista">'; lista = true; } html += item(vi[1]); }
    else if (/^PROYECTO ALLAS \d/i.test(l)) { cerrar(); html += `<div class="nt-tit">${enLinea(l)}</div>`; }
    else { cerrar(); html += `<p>${enLinea(l)}</p>`; }
  }
  cerrar();
  return `<div class="notas-paquete">${html}</div>`;
}

function esperarReinicio(version) {
  modal(`<div class="exito"><div class="icono">↻</div><h2>Instalando la versión ${esc(version)}…</h2>
    <p class="suave" id="re-txt">El programa se está reiniciando. Esta página se recargará sola.</p></div>`);
  let intentos = 0;
  const t = setInterval(async () => {
    intentos++;
    try {
      const r = await fetch("/api/estado", { cache: "no-store" });
      const e = await r.json();
      if (e.version === version) { clearInterval(t); sessionStorage.removeItem("token"); location.reload(); }
    } catch (_) { /* aún reiniciando */ }
    if (intentos === 40 && $("#re-txt")) $("#re-txt").textContent = "Está tardando más de lo normal. Si no vuelve, cierre la ventana del servidor y abra ARRANCAR.bat.";
  }, 1000);
}

// ==================================================================== Licencia

const NOMBRE_ESTADO_LIC = { activa: ["e-pagado", "Activa"], prueba: ["e-aviso", "Prueba"], prueba_caducada: ["e-err", "Prueba terminada"],
  caducada: ["e-err", "Caducada"], invalida: ["e-err", "No válida"], otro_equipo: ["e-err", "Otro equipo"], version_no_cubierta: ["e-err", "Versión no cubierta"],
  sin_comprobar: ["e-err", "Sin comprobar"], revocada: ["e-err", "Anulada"] };

// Estado y activación de la licencia, comprobación periódica (online o con código), módulos y datos del fabricante
const ajLicencia = accion(async (el) => {
  const admin = tieneRol("admin");
  const [l, acerca] = await Promise.all([api("GET", "/api/licencia"), admin ? api("GET", "/api/acerca").catch(() => null) : null]);
  const [cls, nom] = NOMBRE_ESTADO_LIC[l.estado] || ["e-salido", l.estado];
  const fila = (k, v) => (v ? `<tr><td class="suave">${k}</td><td><b>${v}</b></td></tr>` : "");
  el.innerHTML = `<div class="rejilla r2" style="align-items:start;max-width:1100px">
    <div class="panel">
      <div class="fila" style="justify-content:space-between"><h3>Estado de la licencia</h3><span class="etiqueta ${cls}">${nom}</span></div>
      <p style="margin:10px 0">${esc(l.mensaje)}</p>
      ${l.numero ? `<table class="tabla"><tbody>
        ${fila("Nº de licencia", l.numero)}${fila("Titular", esc(l.titular))}${fila("Tipo", esc(l.tipo_nombre))}
        ${fila("Caduca", l.caduca ? fechaCorta2(l.caduca) : "Nunca")}
        ${fila("Actualizaciones hasta", l.actualizaciones_hasta ? fechaCorta2(l.actualizaciones_hasta) : "Sin límite")}
        ${fila("Equipo", l.equipo_licencia ? `<span class="mono">${esc(l.equipo_licencia)}</span>` : "Cualquiera")}
        ${fila("Plan", esc(l.plan_nombre))}
        ${fila("Versión instalada", esc(S.estado.version))}</tbody></table>` : ""}
      ${acerca ? htmlFabricante(acerca.fabricante || {}) : ""}
      <h3 style="margin-top:20px">ID de este equipo</h3>
      <p class="suave" style="margin:6px 0">Si su licencia va ligada a este ordenador, envíe este código a su distribuidor.</p>
      <div class="fila"><span class="id-equipo">${esc(l.id_equipo)}</span><button class="btn" id="lc-copiar-id">Copiar</button></div>
    </div>${htmlComprobacionLicencia(l, admin)}
    <form class="panel" id="f-lic">
      <h3>${l.serial ? "Cambiar o renovar la licencia" : "Activar licencia"}</h3>
      <p class="suave" style="margin:6px 0 10px">Pegue el serial completo que le ha enviado su distribuidor o cargue el archivo <b>.lic</b>. No necesita Internet.</p>
      <textarea class="ent mono" id="lc-serial" rows="5" style="width:100%" placeholder="ALLAS-XXXXX-XXXXX-…"></textarea>
      <div class="fila" style="margin-top:10px">
        <button class="btn prim">Activar</button>
        <label class="btn">Cargar archivo .lic…<input type="file" id="lc-arch" accept=".lic,.txt,text/plain" hidden></label>
        ${l.serial ? '<button type="button" class="btn peligro" id="lc-quitar">Quitar licencia</button>' : ""}
      </div>
    </form>
    ${panelModulos(l)}</div>`;
  $("#lc-copiar-id").onclick = () => copiarTexto(l.id_equipo);
  $("#lc-arch").onchange = accion(async (e) => {
    const f = e.target.files[0]; if (!f) return;
    const txt = await f.text();
    const m = txt.match(/ALLAS(?:-[A-Z2-7]{1,5})+/);
    if (!m) throw new Error("El archivo no contiene un serial de PROYECTO ALLAS");
    $("#lc-serial").value = m[0];
    S.licArchivo = txt;   // El .lic puede traer también los datos del fabricante
    if (/DATOS DEL FABRICANTE/.test(txt)) toast("El archivo trae también los datos del fabricante (Acerca de)", "ok");
  });
  $("#f-lic").onsubmit = accion(async (e) => {
    e.preventDefault();
    const serial = $("#lc-serial").value;
    const r = await api("POST", "/api/licencia", { serial: S.licArchivo && serial.trim() && S.licArchivo.includes(serial.trim()) ? S.licArchivo : serial });
    S.licArchivo = null;
    toast(r.mensaje, "ok");
    S.estado = await api("GET", "/api/estado");
    S.ajustesTab = "licencia"; render();   // los módulos pueden haber cambiado: menú y Ajustes de nuevo
  });
  if ($("#lc-quitar")) $("#lc-quitar").onclick = accion(async () => {
    if (!(await confirmar("Quitar licencia", "El programa volverá al modo de prueba (si aún le quedan días) o dejará de registrar entradas. ¿Seguro?", { boton: "Quitar", peligro: true }))) return vistaAjustes($("#vista"));
    await api("DELETE", "/api/licencia");
    S.estado = await api("GET", "/api/estado");
    S.ajustesTab = "licencia"; render();
  });
  montarComprobacionLicencia(el, l);
});

// Qué módulos incluye la licencia y cuáles se pueden contratar
function panelModulos(l) {
  const cat = l.catalogo || { modulos: [], planes: {} };
  const tiene = new Set(l.modulos || []);
  const lim = l.limitada ? new Set(l.limitada.modulos) : null;   // 4.8: tipo reducido desde Supervisión
  const estadoMod = (id) => !tiene.has(id) ? ["no", "e-salido", "No incluido", "—"] : lim && !lim.has(id) ? ["no", "e-aviso", "Desactivado", "–"] : ["si", "e-pagado", "Incluido", "✓"];
  const prueba = !l.serial;
  return `<div class="panel" style="grid-column:1/-1">
    <div class="fila" style="justify-content:space-between"><h3>Módulos</h3><span class="etiqueta e-pagado">${esc(l.plan_nombre || "")}${lim ? ` → ${esc(l.limitada.nombre)}` : ""}</span></div>
    <p class="suave" style="margin:6px 0 12px">${prueba ? "Durante la prueba están activados todos los módulos, para que pueda conocer el programa entero."
      : "La <b>base</b> (entrada, salida, vehículos dentro, caja y turno, tarifas, ticket, resumen y copias) va siempre incluida; lo demás va en los módulos. Para añadir un módulo, pida a su distribuidor una licencia nueva: sus datos se conservan."}</p>
    ${lim ? `<div class="aviso" id="lc-limitada" style="margin:0 0 12px">Desde Supervisión se usa como licencia <b>${esc(l.limitada.nombre)}</b>:
      los módulos «Desactivado» están en su licencia pero no se usan en este parking.</div>` : ""}
    <div class="lista-modulos">${cat.modulos.map((m) => { const [c, et, txt, marca] = estadoMod(m.id); return `<div class="modulo-lic ${c}">
      <span class="marca-mod">${marca}</span>
      <div><b>${esc(m.nombre)}</b> <span class="etiqueta ${et}">${txt}</span>
        <div class="suave" style="font-size:.85rem">${esc(m.detalle)}</div></div></div>`; }).join("")}</div>
    <p class="ayuda" style="margin:12px 0 0">Planes: ${Object.values(cat.planes).map((p) => `<b>${esc(p.nombre)}</b> (${p.modulos.length ? p.modulos.map((id) => esc((cat.modulos.find((x) => x.id === id) || {}).nombre || id)).join(", ") : "solo la base"})`).join(" · ")}.</p>
  </div>`;
}

// Comprobación periódica de la licencia (si la licencia la pide). Oculta desde Supervisión salvo cuando toca comprobarla.
function htmlComprobacionLicencia(l, admin) {
  const c = l.comprobacion;
  if (!c || (oculto("licencia_online") && !c.pendiente && l.puede_operar !== false)) return "";
  const hoy = hoyISO();
  const estado = !l.puede_operar && (l.estado === "sin_comprobar" || l.estado === "revocada") ? ["e-err", l.estado === "revocada" ? "Anulada" : "Bloqueada"]
    : c.pendiente ? ["e-aviso", "Pendiente"] : ["e-pagado", "Al día"];
  return `<div class="panel" id="lc-comprobacion"><div class="fila" style="justify-content:space-between"><h3>Comprobación de la licencia</h3><span class="etiqueta ${estado[0]}">${estado[1]}</span></div>
    <p class="suave" style="margin:8px 0 10px">Esta licencia se comprueba con su distribuidor <b>cada ${c.cada} día${c.cada === 1 ? "" : "s"}</b>, automáticamente por Internet.
      Si no se puede, hay <b>${c.gracia} día${c.gracia === 1 ? "" : "s"} de margen</b>; después deja de registrar entradas hasta que se compruebe.</p>
    <table class="tabla"><tbody>
      <tr><td class="suave">Última comprobación</td><td><b>${c.ultima ? fechaCorta2(c.ultima) : "Todavía ninguna"}</b>${c.comprobado_el ? `<span class="suave"> · ${fechaHora(c.comprobado_el)}</span>` : ""}</td></tr>
      <tr><td class="suave">Próxima</td><td><b>${fechaCorta2(c.proxima)}</b>${c.proxima < hoy ? ' <span class="etiqueta e-aviso">toca ya</span>' : ""}</td></tr>
      <tr><td class="suave">Sin comprobar, se bloquea el</td><td><b>${fechaCorta2(c.limite)}</b></td></tr>
      <tr><td class="suave">Último intento</td><td>${c.ultimo_intento ? fechaHora(c.ultimo_intento) : "—"}${c.ultimo_error ? `<div style="color:var(--rojo);font-size:.88rem">${esc(c.ultimo_error)}</div>` : ""}</td></tr>
    </tbody></table>
    ${admin ? `<div class="fila" style="margin-top:12px"><button class="btn prim" id="lc-comprobar">Comprobar ahora</button></div>
    <h3 style="margin-top:18px">Sin Internet: código de validación</h3>
    <p class="suave" style="margin:6px 0">Diga a su distribuidor el <b>nº de licencia (${esc(String(l.numero || ""))})</b> y el <b>ID de este equipo</b>
      (<span class="mono">${esc(l.id_equipo)}</span>). Le dará un código que empieza por <span class="mono">VAL-</span>; péguelo aquí.</p>
    <textarea class="ent mono" id="lc-codigo" rows="3" style="width:100%" placeholder="VAL-XXXXX-XXXXX-…"></textarea>
    <div class="fila" style="margin-top:8px"><button class="btn" id="lc-validar">Validar con el código</button>
      <button class="btn" id="lc-copiar-datos">Copiar nº de licencia e ID de equipo</button></div>
    <details style="margin-top:14px"><summary class="suave">Servidor de comprobación</summary>
      <p class="suave" style="margin:8px 0">Lo indica la licencia${c.url ? ` (<span class="mono">${esc(c.url)}</span>)` : " (no indica ninguno)"}. Cámbielo solo si su distribuidor se lo pide.</p>
      <div class="fila"><input class="ent mono" id="lc-servidor" style="flex:1;min-width:260px" value="${esc(c.servidor_propio ? c.servidor : "")}" placeholder="${esc(c.url || "http://servidor:8771")}">
        <button class="btn" id="lc-guardar-servidor">Guardar</button></div></details>` : ""}</div>`;
}

function montarComprobacionLicencia(el, l) {
  if (!$("#lc-comprobar", el)) return;
  const recargar = async () => { S.estado = await api("GET", "/api/estado"); pintarBarra(); ajLicencia(el); };
  $("#lc-comprobar", el).onclick = accion(async () => {
    const b = $("#lc-comprobar", el); b.disabled = true; b.textContent = "Comprobando…";
    try { const r = await api("POST", "/api/licencia/comprobar"); toast("Licencia comprobada: " + (r.estado === "revocada" ? "ANULADA" : "correcta"), r.estado === "revocada" ? "err" : "ok"); }
    finally { await recargar(); }
  });
  $("#lc-validar", el).onclick = accion(async () => {
    const codigo = $("#lc-codigo", el).value.trim();
    if (!codigo) throw new Error("Pegue el código de validación");
    await api("POST", "/api/licencia/validacion", { codigo });
    toast("Licencia validada con el código", "ok");
    await recargar();
  });
  $("#lc-copiar-datos", el).onclick = () => copiarTexto(`Licencia nº ${l.numero} · ID de equipo ${l.id_equipo}`);
  $("#lc-guardar-servidor", el).onclick = accion(async () => {
    await api("PUT", "/api/config", { licencia_servidor: $("#lc-servidor", el).value.trim() });
    toast("Servidor guardado", "ok");
    await recargar();
  });
}

// Datos del fabricante (los de «Acerca de»): llegan junto con el serial (archivo .lic o comprobación online) y se muestran con él
function htmlFabricante(f) {
  const origen = { programa: "vienen con el programa", servidor: "recibidos con la comprobación online", manual: "cargados a mano",
    licencia: "vienen con el serial (.lic)", predeterminado: "aún no se han recibido" }[f.origen] || "";
  return `<div id="lc-fab" style="margin-top:16px"><div class="fila" style="justify-content:space-between"><h3>Fabricante</h3>
      ${f.logo ? `<img src="${f.logo}" alt="" style="max-height:34px;max-width:140px">` : ""}</div>
    <p style="margin:6px 0">${f.nombre ? `<b>${esc(f.nombre)}</b>${f.web ? ` · ${esc(f.web.replace(/^https?:\/\//, ""))}` : ""}` : "<span class=\"suave\">Sin datos todavía</span>"}
      <span class="suave"> (${esc(origen)})</span></p>
    <p class="ayuda" style="margin:0">Los datos del fabricante (copyright, logo y contacto) se incluyen con el serial: al cargar el archivo .lic o al comprobar la licencia se actualizan solos.</p></div>`;
}

// ==================================================================== Servidor

// Arranque con Windows, servidor (reiniciar / apagar), conexión, sesiones abiertas, registro y estabilidad
const ajServidor = accion(async (el) => {
  el.innerHTML = '<div id="srv40" style="max-width:1000px"></div>';
  const raiz = $("#srv40", el);
  const admin = tieneRol("admin");
  const [s, a] = await Promise.all([api("GET", "/api/sistema/servidor"), admin ? api("GET", "/api/sistema/autoarranque").catch(() => null) : null]);
  if (!el.isConnected) return;
  raiz.innerHTML = `${a ? `<form class="panel" id="srv45" style="margin-bottom: 16px;"><div class="fila" style="justify-content:space-between"><h3>Arrancar con Windows</h3>
      <span class="etiqueta ${a.activo ? "e-pagado" : "e-salido"}">${a.activo ? (a.modo === "quiosco" ? "Activado · quiosco" : "Activado") : "Desactivado"}</span></div>
    <p class="suave" style="margin:6px 0 10px">Al encender el PC y entrar en Windows, PROYECTO ALLAS se abre solo.</p>
    ${a.disponible ? `<label class="fila" style="gap:10px;font-weight:600"><input type="checkbox" name="activo" ${a.activo ? "checked" : ""}> Abrir PROYECTO ALLAS al iniciar Windows</label>
      <div class="tipos-pantalla" style="margin-top:10px">
        <label class="tipo-pantalla"><input type="radio" name="modo" value="normal" ${a.modo !== "quiosco" ? "checked" : ""}><b>Normal</b><span>En una ventana, como al abrir ARRANCAR.bat.</span></label>
        <label class="tipo-pantalla"><input type="radio" name="modo" value="quiosco" ${a.modo === "quiosco" ? "checked" : ""}><b>Quiosco</b><span>A pantalla completa, sin barras del navegador (para cajas táctiles). Se sale con Alt+F4.</span></label></div>
      <div class="fila" style="margin-top:12px"><button class="btn prim">Guardar</button></div>`
      : `<div class="aviso">${esc(a.mensaje || "No disponible en este equipo")}</div>`}</form>` : ""}
    ${admin ? `<div class="panel" id="panel-servidor" style="margin-top: 0px; max-width: 1000px;"><div class="fila" style="justify-content:space-between"><h3>Servidor del programa</h3>
      <span class="etiqueta e-pagado">En marcha</span></div>
    <p class="suave" style="margin:8px 0 12px">${s.oculto
      ? `Funciona en segundo plano, <b>sin ventana</b>. Los mensajes se guardan en <span class="mono">${esc(s.log || "datos/servidor.log")}</span>.`
      : "Funciona con su ventana abierta (arrancado con scripts\\ARRANCAR_CON_VENTANA.bat o a mano)."}
      ${s.inicio ? `<br>En marcha desde el ${fechaHora(s.inicio)}` : ""}${s.puerto ? ` · puerto ${s.puerto}` : ""} · Python ${esc(s.python)}</p>
    <div class="fila"><button class="btn" id="srv-reiniciar">Reiniciar…</button>
      <button class="btn peligro" id="srv-apagar">Apagar el programa…</button></div>
    <p class="ayuda" style="margin:10px 0 0">Para volver a abrirlo después de apagarlo, use el acceso directo <b>PROYECTO ALLAS</b> del escritorio (o ARRANCAR.bat).</p></div>` : ""}
    <div class="panel" style="margin-top: 16px;"><h3>Conexión</h3>
    <div class="rejilla r2" style="margin-top:10px">
      <div><div class="suave" style="font-size:.85rem">Escucha en</div><b class="mono">${esc(s.host || "127.0.0.1")}:${esc(s.puerto || "")}</b>
        <div class="suave" style="font-size:.85rem">${s.red ? "Accesible desde la red local" : "Solo este ordenador"}</div></div>
      <div><div class="suave" style="font-size:.85rem">Direcciones en la red</div>${s.ips && s.ips.length
        ? s.ips.map((ip) => `<div class="mono">http://${esc(ip)}:${esc(s.puerto)}</div>`).join("") : '<span class="suave">—</span>'}</div>
      <div><div class="suave" style="font-size:.85rem">Base de datos</div><span class="mono" style="font-size:.85rem;word-break:break-all">${esc(s.base_datos || "")}</span>
        ${s.tamano_db ? `<div class="suave" style="font-size:.85rem">${tamanoTxt(s.tamano_db)}</div>` : ""}</div>
      <div><div class="suave" style="font-size:.85rem">Programa</div>Python ${esc(s.python)}<div class="mono suave" style="font-size:.8rem;word-break:break-all">${esc(s.ejecutable || "")}</div></div></div>
    ${tieneModulo("movil") ? '<div class="fila" style="margin-top:12px"><button class="btn" id="srv-movil">Acceso desde móviles y tablets…</button></div>' : ""}</div>
    <div class="panel" style="margin-top: 16px;"><div class="fila" style="justify-content:space-between"><h3>Sesiones abiertas</h3>
      <button class="btn" id="srv-cerrar-ses" ${s.sesiones.length > 1 ? "" : "disabled"}>Cerrar las de los demás puestos…</button></div>
    ${s.sesiones.length ? `<div style="overflow-x:auto"><table class="tabla" style="margin-top:8px"><thead><tr><th>Usuario</th><th>Puesto</th><th>Entró</th><th>Última actividad</th></tr></thead><tbody>
      ${s.sesiones.map((x) => `<tr><td><b>${esc(x.nombre)}</b> <span class="suave">${esc(x.usuario)} · ${esc(x.rol)}</span>${x.propia ? ' <span class="etiqueta e-pagado">Esta</span>' : ""}</td>
        <td class="mono">${esc(x.origen || "—")}</td><td>${fechaHora(x.creada)}</td><td>${fechaHora(x.visto)}</td></tr>`).join("")}</tbody></table></div>`
      : '<div class="vacio" style="padding:14px">No hay sesiones guardadas.</div>'}</div>
    <div class="panel" style="margin-top: 16px;"><div class="fila" style="justify-content:space-between"><h3>Registro del servidor</h3><button class="btn" id="srv-log-r">Actualizar</button></div>
    <pre class="registro-srv" id="srv-log">Cargando…</pre></div>
    <div class="panel" id="srv44" style="margin-top: 16px;"></div>`;
  // arrancar con Windows
  const p = $("#srv45", raiz);
  if (p && a.disponible) p.onsubmit = accion(async (e) => {
    e.preventDefault();
    await api("PUT", "/api/sistema/autoarranque", { activo: p.activo.checked, modo: p.modo.value });
    toast(p.activo.checked ? `Se abrirá solo al iniciar Windows (${p.modo.value === "quiosco" ? "modo quiosco" : "normal"})` : "Ya no se abre solo al iniciar Windows", "ok");
    ajServidor(el);
  });
  // reiniciar / apagar
  if ($("#srv-reiniciar", raiz)) {
    $("#srv-reiniciar", raiz).onclick = () => modalApagar(true);
    $("#srv-apagar", raiz).onclick = () => modalApagar(false);
  }
  if ($("#srv-movil", raiz)) $("#srv-movil", raiz).onclick = () => irAjustes("movil");
  // sesiones
  $("#srv-cerrar-ses", raiz).onclick = accion(async () => {
    if (!(await confirmar("Cerrar sesiones", "Los demás puestos (cajas, móviles) tendrán que volver a entrar con su PIN. ¿Continuar?", { boton: "Cerrar sesiones", peligro: true }))) return ajServidor(el);
    const r = await api("POST", "/api/sistema/sesiones/cerrar");
    toast(`${r.cerradas} sesión(es) cerrada(s)`, "ok"); ajServidor(el);
  });
  // registro del servidor
  const log = raiz;
  const cargarLog = accion(async () => {
    const l = await api("GET", "/api/sistema/log");
    const pre = $("#srv-log", log); if (!pre) return;
    pre.textContent = l.lineas.length ? l.lineas.join("\n") : (l.log ? "El registro está vacío." : "Con la ventana abierta, los mensajes salen en la ventana del servidor (no se guardan en un archivo).");
    pre.scrollTop = pre.scrollHeight;
  });
  $("#srv-log-r", log).onclick = cargarLog;
  cargarLog();
  // estabilidad: comprobación de la base de datos y errores de las pantallas
  const p44 = $("#srv44", raiz);
  const pintar = accion(async () => {
    const r = await api("GET", "/api/errores-pantalla");
    const ok = r.integridad === "ok";
    p44.innerHTML = `<div class="fila" style="justify-content:space-between"><h3>Estabilidad</h3>
        <span class="etiqueta ${!r.integridad ? "e-salido" : ok ? "e-pagado" : "e-err"}">${!r.integridad ? "Sin comprobar" : ok ? "Base de datos correcta" : "Base de datos con errores"}</span></div>
      <p class="suave" style="margin:8px 0">Al arrancar se comprueba la base de datos${r.integridad_fecha ? ` (última: ${fechaHora(r.integridad_fecha)})` : ""}.
        Si el programa se cierra por un error o deja de responder, se vuelve a arrancar solo en unos segundos.</p>
      ${r.integridad && !ok ? `<div class="aviso rojo">${esc(r.integridad)}</div>` : ""}
      <div class="fila"><button class="btn" id="srv44-comp">Comprobar la base de datos ahora</button><button class="btn" id="srv44-act">Actualizar</button></div>
      <h3 style="margin-top:16px">Errores de las pantallas <span class="suave" style="font-weight:400">(desde el último arranque)</span></h3>
      ${r.errores.length ? `<div style="overflow-x:auto;margin-top:6px"><table class="tabla mini43"><thead><tr><th>Fecha</th><th>Usuario</th><th>Pantalla</th><th>Error</th></tr></thead><tbody>
        ${r.errores.map((x) => `<tr><td class="num">${fechaHora(x.fecha)}</td><td>${esc(x.usuario || "—")}</td><td>${esc(x.pantalla || "")}</td>
          <td class="mono" style="white-space:normal">${esc(x.mensaje)}<div class="suave">${esc(x.origen || "")}${x.linea ? ":" + x.linea : ""}</div></td></tr>`).join("")}</tbody></table></div>`
        : '<p class="suave">Ninguno.</p>'}`;
    $("#srv44-act", p44).onclick = pintar;
    $("#srv44-comp", p44).onclick = accion(async () => {
      const x = await api("POST", "/api/integridad");
      toast(x.resultado === "ok" ? "Base de datos correcta" : "La base de datos tiene errores: " + x.resultado, x.resultado === "ok" ? "ok" : "err");
      pintar();
    });
  });
  pintar();
});

// Reiniciar o apagar el servidor (con el PIN)
function modalApagar(reiniciar) {
  const m = modal(`<h2>${reiniciar ? "Reiniciar el programa" : "Apagar el programa"}</h2>
    <p>${reiniciar ? "El servidor se detendrá y volverá a arrancar en unos segundos." : "El servidor se detendrá: <b>ningún puesto podrá cobrar ni emitir tickets</b> hasta que se vuelva a abrir."}</p>
    <label class="campo">Confirme con su PIN<input class="ent" id="srv-pin" type="password" inputmode="numeric" autofocus></label>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn ${reiniciar ? "prim" : "peligro lleno"}" data-ok>${reiniciar ? "Reiniciar" : "Apagar"}</button></div>`);
  $("[data-c]", m).onclick = cerrarModal;
  const hacer = accion(async () => {
    await api("POST", "/api/sistema/apagar", { pin: $("#srv-pin", m).value, reiniciar });
    if (reiniciar) { cerrarModal(); return setTimeout(() => esperarReinicio(S.estado.version), 2500); }
    sessionStorage.removeItem("token");
    $("#app").innerHTML = `<div class="acceso"><div class="panel" style="max-width:520px;text-align:center">
      <h2>PROYECTO ALLAS se ha apagado</h2>
      <p class="suave">Puede cerrar esta ventana. Para volver a abrirlo, use el acceso directo <b>PROYECTO ALLAS</b> del escritorio.</p></div></div>`;
    cerrarModal();
  });
  $("[data-ok]", m).onclick = hacer;
  $("#srv-pin", m).onkeydown = (e) => { if (e.key === "Enter") hacer(); };
}

function reiniciarConPin() {
  const m = modal(`<h2>Reiniciar el programa</h2><p>Tarda unos segundos. Las pantallas abiertas se recargan solas.</p>
    <label class="campo" style="margin-top:12px">PIN de administrador<input class="ent" id="rp-pin" type="password" inputmode="numeric" autofocus></label>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Reiniciar</button></div>`);
  $("[data-c]", m).onclick = cerrarModal;
  const hacer = accion(async () => {
    await api("POST", "/api/sistema/apagar", { pin: $("#rp-pin", m).value, reiniciar: true });
    modal(`<div class="exito"><div class="icono">↻</div><h2>Reiniciando…</h2><p class="suave">Espere unos segundos.</p></div>`);
    let n = 0;
    const t = setInterval(async () => {
      n++;
      try { if ((await fetch("/api/estado", { cache: "no-store" })).ok && n > 2) { clearInterval(t); window.__salirSinPreguntar = true; location.reload(); } } catch (_) { /* aún no */ }
    }, 1000);
  });
  $("[data-ok]", m).onclick = hacer;
  $("#rp-pin", m).onkeydown = (e) => { if (e.key === "Enter") hacer(); };
}

// ================================================================ Demostración

// ------------------------------------------------ Ajustes → Sistema → Demostración
const ajDemo = accion(async (el) => {
  const demo = !!S.estado.demo;
  el.innerHTML = `<div class="panel" style="max-width:900px">
    <div class="fila" style="justify-content:space-between"><h3>Cuenta de demostración</h3>
      <span class="etiqueta ${demo ? "e-aviso" : "e-salido"}">${demo ? "Activa" : "No activa"}</span></div>
    <p style="margin:10px 0">Una copia del programa con <b>datos de ejemplo</b> para probar o enseñarlo: abonados con bonos (vigentes, caducados y con deuda),
      clientes de facturación, productos con foto, descuentos y vales, publicidad para la pantalla de cliente, vehículos dentro y un mes de entradas, cobros,
      ventas y turnos para ver los informes.</p>
    <ul class="suave" style="margin:0 0 12px 18px">
      <li>Sus datos reales <b>no se tocan</b>: la demo se guarda aparte, en la carpeta <span class="mono">datos\\demo</span>.</li>
      <li>Usuarios de la demo: <span class="mono">admin</span> PIN <span class="mono">1234</span> · <span class="mono">supervisor</span> PIN <span class="mono">2222</span> · <span class="mono">caja</span> PIN <span class="mono">1111</span>.</li>
      <li>Todo lo que se imprime lleva «DEMOSTRACIÓN - SIN VALIDEZ». En la demo están todos los módulos, tenga la licencia que tenga.</li>
    <li id="dm-caduca">La demostración está disponible <b>mientras su licencia (o la prueba) esté vigente</b>, y caduca el mismo día que ella.</li></ul>
    ${!S.estado.demo_disponible ? '<div class="aviso">No disponible: el programa no se ha arrancado con ARRANCAR.bat.</div>'
      : demo ? `<div class="fila"><button class="btn prim" id="dm-a-salir">Volver a mis datos</button>
          <button class="btn" id="dm-a-regenerar">Empezar la demo de cero</button></div>`
      : `<div class="fila"><button class="btn prim" id="dm-a-activar">Activar la demostración…</button></div>`}
  ${demo && S.estado.licencia && S.estado.licencia.mensaje ? `<div id="dm-estado" class="aviso ${S.estado.licencia.puede_operar ? "" : "rojo"}" style="margin-top: 12px;">${esc(S.estado.licencia.mensaje)}</div>` : ""}</div>`;
  if ($("#dm-a-activar", el)) $("#dm-a-activar", el).onclick = () => activarDemo(false);
  if ($("#dm-a-salir", el)) $("#dm-a-salir", el).onclick = salirDemo;
  if ($("#dm-a-regenerar", el)) $("#dm-a-regenerar", el).onclick = regenerarDemo;
});

// ================================================================= Supervisión

const ajSupervision = accion(async (el) => {
  const r = await api("GET", "/api/supervision");
  S.supervision = { abierta: r.abierta };
  aplicarOcultos();
  if (!r.abierta) {
    el.innerHTML = `<form class="panel" id="sup-entrar" style="max-width:520px"><h3 class="titulo-icono">${icono("candado", 22)}Supervisión</h3>
      <p class="suave" style="margin:8px 0 12px">Solo para el fabricante o el instalador. Escriba la contraseña de supervisión.</p>
      <label class="campo">Contraseña<input class="ent" type="password" id="sup-clave" autocomplete="off" autofocus></label>
      <div class="fila" style="margin-top:12px"><button class="btn prim">Entrar</button></div></form>`;
    $("#sup-entrar", el).onsubmit = accion(async (e) => {
      e.preventDefault();
      const x = await api("POST", "/api/supervision/entrar", { clave: $("#sup-clave", el).value });
      S.supervision = { abierta: true };
      const origen = { licencia: "contraseña de la licencia", maestra: "contraseña maestra", defecto: "contraseña de fábrica" }[x.origen] || "";
      toast(`Supervisión abierta (${origen}). Se cierra sola a los ${x.minutos} min sin uso.`, "ok");
      vistaAjustes($("#vista"));
    });
    return;
  }
  const ocultos = new Set(r.ocultos);
  const casilla = (id, nombre, extra = "") => `<label class="sup-op ${ocultos.has(id) ? "es-oculto" : ""}"><input type="checkbox" data-id="${esc(id)}" ${ocultos.has(id) ? "" : "checked"}>
      <span>${esc(nombre)}${extra ? `<span class="suave">${extra}</span>` : ""}</span></label>`;
  const menus = VISTAS.filter((v) => NOMBRE_MENU[v.id]).map((v) => casilla("menu:" + v.id, NOMBRE_MENU[v.id])).join("") + casilla("menu:apps", "Aplicaciones externas");
  const ajustes = GRUPOS_AJUSTES.map((g) => `<div class="sup-grupo"><b>${esc(g.nombre)}</b>${g.tabs.filter(([id]) => id !== "supervision")
    .map(([id, n]) => casilla("aj:" + id, n)).join("")}</div>`).join("");
  const informes = [["estadisticas", "Estadísticas"], ["facturas", "Facturas"], ["cierre", "Cierre y gestoría"], ["turnos", "Turnos"], ["auditoria", "Auditoría"], ["facturacion", "Registro de facturación"]]
    .map(([id, n]) => casilla("inf:" + id, n)).join("");
  const vehiculos = [["historial", "Historial de entradas y salidas"], ["listanegra", "Lista negra"]].map(([id, n]) => casilla("veh:" + id, n)).join("");
  const opciones = OCULTABLES.map((o) => casilla(o.id, o.nombre, o.donde)).join("");
  const nombreMod = (id) => ((r.nombres_modulos || {})[id] || id);
  const planes = (r.planes || []).map((pl) => `<label class="sup-op sup-plan ${pl.disponible ? "" : "no-disp"}" style="${estiloTipo(pl.color)}"><input type="radio" name="sup-plan" value="${esc(pl.id)}"
      ${r.plan === pl.id ? "checked" : ""} ${pl.disponible ? "" : "disabled"}><span><b class="nom-plan">${esc(pl.nombre)}</b><span class="suave">${pl.disponible
        ? (pl.modulos.length ? pl.modulos.map(nombreMod).map(esc).join(", ") : "solo la base") : "No lo permite la licencia contratada"}</span></span></label>`).join("");
  el.innerHTML = `<div class="sup44">
    ${r.clave_defecto ? `<div class="aviso rojo" id="sup-aviso-defecto" style="margin-bottom:16px">Está entrando con la <b>contraseña de fábrica</b>.
      Cámbiela en el <b>Gestor de licencias</b>: contraseña maestra en <i>Fabricante y copyright</i> (llega con las actualizaciones, la comprobación online
      o el archivo .lic) o una propia al emitir o renovar esta licencia. En cuanto haya una, la de fábrica deja de servir.</div>` : ""}
    <div class="panel sup-cab"><div><h3 class="titulo-icono">${icono("escudo", 22)}Supervisión</h3>
        <p class="suave" style="margin:6px 0 0">Desmarque lo que este parking no necesita y pulse <b>Guardar y aplicar</b>: se oculta al momento en este puesto y,
          en unos segundos, en los demás (se recargan solos). No se borra nada y se puede volver a mostrar.
          Las funciones que tienen su propio interruptor (devoluciones, alertas…) se activan en sus pantallas.</p></div>
      <div class="fila"><button class="btn" id="sup-todo">Marcar todo</button><button class="btn" id="sup-fabrica">Restablecer valores de fábrica</button>
        <button class="btn" id="sup-salir">Salir de Supervisión</button><button class="btn prim" id="sup-guardar">Guardar y aplicar</button></div></div>
    <div class="sup-rejilla">
      <div class="panel"><h3>Menú lateral</h3><p class="ayuda">Entrada, Salida y Ajustes siempre se ven.</p>${menus}
        <h3 style="margin-top:16px">Informes</h3>${informes}<h3 style="margin-top:16px">Vehículos</h3>${vehiculos}</div>
      <div class="panel"><h3>Pestañas de Ajustes</h3><div class="sup-grupos">${ajustes}</div></div>
      <div class="panel"><h3>Opciones y botones</h3>${opciones}
        <p class="ayuda" style="margin-top:10px">De fábrica se ocultan la búsqueda de actualizaciones online y la comprobación online de la licencia
          (la licencia se sigue comprobando sola; su panel aparece si hace falta validarla).</p></div></div>
    <form class="panel" id="sup-tipo" style="margin-top:16px"><div class="fila" style="justify-content:space-between"><h3>Tipo de licencia</h3>
        <span class="etiqueta e-pagado" id="sup-tipo-actual">${esc(r.tipo || "")}</span></div>
      <p class="suave" style="margin:6px 0 10px">Reduce lo que se ve y se puede usar en este parking a un tipo de licencia <b>igual o más sencillo</b>
        que el contratado (por ejemplo, <b>Lite</b> para un parking que solo cobra por horas). No se borra nada: al volver a «Según la licencia» reaparece todo.
        Para tener más módulos hace falta una licencia nueva del distribuidor.</p>
      ${r.demo ? '<div class="aviso">En la demostración están todos los módulos: el tipo de licencia se cambia con sus datos reales.</div>' : `
      <div class="sup-planes"><label class="sup-op sup-plan"><input type="radio" name="sup-plan" value="" ${r.plan ? "" : "checked"}>
          <span><b>Según la licencia</b><span class="suave">${(r.modulos_licencia || []).map(nombreMod).map(esc).join(", ") || "solo la base"}</span></span></label>${planes}</div>
      <div class="fila" style="margin-top:12px"><button class="btn prim">Cambiar tipo de licencia</button></div>`}</form>
    <form class="panel" id="sup-act" style="margin-top:16px"><h3>Actualizaciones online</h3>
      <p class="suave" style="margin:6px 0 10px">De dónde descarga el programa las actualizaciones al pulsar «Buscar actualizaciones online». Con «GitHub» no hace falta escribir nada:
        usa las versiones publicadas por el distribuidor. La dirección solo se usa con «Servidor de la dirección de arriba».</p>
      <div class="rejilla r2">
        <label class="campo">Dirección (enlace)<input class="ent mono" name="actualizaciones_url" placeholder="https://actualizaciones.midominio.com" autocomplete="off" spellcheck="false"></label>
        <label class="campo">De dónde se descargan<select class="ent" name="actualizaciones_origen"><option value="">Automático (según haya dirección o no)</option>
          <option value="github">GitHub (versiones publicadas)</option><option value="servidor">Servidor de la dirección de arriba</option><option value="drive">Carpeta de Google Drive</option></select></label></div>
      <div class="fila" style="margin-top:12px"><button class="btn prim">Guardar enlace</button><button class="btn" type="button" id="sup-act-probar">Probar ahora</button><span class="suave" id="sup-act-res"></span></div></form></div>`;
  api("GET", "/api/config").then((c) => {
    const f = $("#sup-act", el); if (!f) return;
    f.actualizaciones_url.value = c.actualizaciones_url || ""; f.actualizaciones_origen.value = c.actualizaciones_origen || "";
  }).catch(() => {});
  if ($("#sup-act", el)) {
    $("#sup-act", el).onsubmit = accion(async (e) => {
      e.preventDefault();
      const f = e.target, url = f.actualizaciones_url.value.trim();
      if (url && !/^https?:\/\//i.test(url) && !/^[\w.-]+(:\d+)?(\/.*)?$/.test(url)) throw new Error("Escriba una dirección válida, por ejemplo https://actualizaciones.midominio.com");
      await api("PUT", "/api/config", { actualizaciones_url: url, actualizaciones_origen: f.actualizaciones_origen.value });
      toast("Enlace de actualizaciones guardado", "ok");
    });
    $("#sup-act-probar", el).onclick = accion(async () => {
      const f = $("#sup-act", el), res = $("#sup-act-res", el);
      await api("PUT", "/api/config", { actualizaciones_url: f.actualizaciones_url.value.trim(), actualizaciones_origen: f.actualizaciones_origen.value });
      res.textContent = "Comprobando…";
      try { const r = await api("GET", "/api/actualizaciones/online"); const ps = r.paquetes || r.lista || [], nu = ps.find((x) => x.nueva);
        res.textContent = `Conexión correcta (${ps.length} paquete(s) publicado(s)).` + (nu ? ` Hay una versión nueva: ${nu.version}.` : " Está al día."); }
      catch (er) { res.textContent = "No se pudo conectar: " + er.message; }
    });
  }
  if ($("#sup-tipo", el)) $("#sup-tipo", el).onsubmit = accion(async (e) => {
    e.preventDefault();
    const sel = $("[name=sup-plan]:checked", el);
    const x = await api("PUT", "/api/supervision/plan", { plan: sel ? sel.value : "" });
    S.estado = await api("GET", "/api/estado");
    toast(`Tipo de licencia: ${x.tipo}`, "ok");
    render();
  });
  const marcar = (fn) => { $$("[data-id]", el).forEach((c) => { c.checked = fn(c.dataset.id); c.closest(".sup-op").classList.toggle("es-oculto", !c.checked); }); };
  $$("[data-id]", el).forEach((c) => (c.onchange = () => c.closest(".sup-op").classList.toggle("es-oculto", !c.checked)));
  $("#sup-todo", el).onclick = () => marcar(() => true);
  $("#sup-salir", el).onclick = accion(async () => {
    await api("POST", "/api/supervision/salir");
    S.supervision = { abierta: false };
    S.estado = await api("GET", "/api/estado");
    render();
  });
  const guardarYAplicar = async (lista, msg) => {
    await api("PUT", "/api/supervision/ocultos", { ocultos: lista });
    await api("POST", "/api/supervision/aplicar");   // los demás puestos se recargan solos
    S.estado = await api("GET", "/api/estado");
    toast(msg, "ok");
    render();   // este puesto, al momento
  };
  $("#sup-guardar", el).onclick = accion(async () => {
    const lista = $$("[data-id]", el).filter((c) => !c.checked).map((c) => c.dataset.id);
    await guardarYAplicar(lista, lista.length ? `Aplicado: ${lista.length} elemento(s) oculto(s) en todos los puestos` : "Aplicado: se ve todo");
  });
  $("#sup-fabrica", el).onclick = accion(async () => {
    if (!(await confirmar("Restablecer", "¿Volver a los valores de fábrica (se ve todo salvo la búsqueda de actualizaciones y la comprobación online de la licencia)?", { boton: "Restablecer" }))) return;
    await guardarYAplicar(OCULTABLES.filter((o) => o.defecto).map((o) => o.id), "Valores de fábrica aplicados");
  });
});

// ============================================================ al cargar

S.supervision = S.supervision || { abierta: false };
