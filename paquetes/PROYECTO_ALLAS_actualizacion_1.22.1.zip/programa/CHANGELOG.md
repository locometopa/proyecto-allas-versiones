# PROYECTO ALLAS · historial de versiones

La versión se muestra en el menú lateral, en la pantalla de acceso, en la ventana del servidor y al pie de las facturas en PDF. Desde la 1.0 se numera por la importancia de los cambios: **X.0** para cambios grandes de estructura, **X.Y** para funciones nuevas y **X.Y.Z** para correcciones. El historial que se ve en Ajustes empieza en la versión con la que se hizo la primera instalación en ese equipo; la numeración anterior (4.x) está en `docs/HISTORIAL_DESARROLLO_4x.md`.

## 1.22.1 — 25 de octubre de 2026

- **Entrada:** el rótulo «Zona» queda encima de los botones de zona (antes se pegaba a ellos) y se quita el texto de ayuda junto a «Hora de entrada».

## 1.22 — 25 de octubre de 2026

- **Actualizaciones online:** el texto de ayuda explica el origen GitHub y «Probar ahora» indica si hay una versión nueva o el programa está al día. Primera versión que se instala por GitHub.

## 1.21 — 24 de octubre de 2026

- **Actualizaciones desde GitHub:** nuevo origen «GitHub (versiones publicadas)» (Ajustes → Sistema → Actualizaciones online). El programa consulta las *releases* del repositorio público de versiones (`app/github_releases.py`, sin cuenta ni clave), muestra las novedades de cada una y descarga el paquete firmado; como con los demás orígenes, **solo se guarda si la firma del fabricante es correcta**. Es el origen por defecto cuando no hay dirección de servidor propia; Drive y servidor propio siguen disponibles. Los equipos con versiones anteriores a la 1.21 no conocen este origen: el paquete 1.21 debe llegarles por Drive (carpeta antigua); desde ahí, por GitHub.
- **Para el distribuidor:** `scripts/publicar_release.py PAQUETE.zip` publica el paquete como release `vX.Y` con las novedades del CHANGELOG (necesita `gh` con la sesión iniciada). El repositorio de versiones debe ser público; GitHub limita a 60 consultas por hora y por IP sin cuenta.

## 1.20 — 20 de octubre de 2026

- **Nueva carpeta de actualizaciones en Google Drive:** el programa busca ahora los paquetes firmados en la carpeta nueva del distribuidor (`app/drive.py`, `CARPETA_DEFECTO`). Los equipos con una versión anterior siguen mirando la carpeta antigua hasta que instalen esta versión, así que el paquete 1.20 debe subirse a la carpeta antigua; a partir de ahí, las siguientes van a la nueva.

## 1.19 — 16 de octubre de 2026

- **Vehículos → Presentes:** la pestaña «Dentro ahora» pasa a llamarse **Presentes**. Nueva columna **Pago estimado** (lo que pagaría si saliera ahora, con lo ya pagado y la señal de la reserva descontados) y un total al pie. La lista se ordena con **los que llevan menos tiempo arriba**.
- **Entrada:** los avisos de reservas que llegan hoy van **encima** del último ticket, y el último ticket se puede **ocultar** (queda una línea con «Mostrar»; el navegador recuerda la elección).
- **Interno:** `vehiculos_dentro` devuelve `pago_estimado_cent` y ordena por entrada descendente.

## 1.18 — 16 de octubre de 2026

- **Servidor de reservas en la nube (opcional):** para publicar las reservas **sin abrir el PC del parking a Internet**. Un pequeño servidor (`scripts/servidor_reservas/relay.py`, solo Python estándar; también `Dockerfile`) se pone en un hosting con HTTPS, sirve la página de reservas y recibe las peticiones de los clientes; **el programa del parking llama a ese servidor** (conexión saliente, cada pocos segundos), atiende las peticiones con su base de datos y devuelve la respuesta. El servidor no guarda nada; si el programa está apagado, el cliente ve «servicio no disponible». Solo se reenvían las rutas `/api/publico/reservas*`; ambas partes comparten una clave larga. En Ajustes → Reservas online → Web de clientes → **Servidor en la nube**: dirección, clave (con «Generar una nueva»), **Guardar y probar conexión**, estado (Conectado / error) y **Descargar el servidor (zip)**, que lleva `relay.py`, la página de reservas y las instrucciones (`LEEME.md`), pero no la clave. El programa ve la IP real del cliente (el límite por IP sigue funcionando).
- **Pago de la señal con tarjeta (Stripe):** en Ajustes → Reservas online → Cobro, «Cobrar con tarjeta en la propia página» (necesita señal o pago anticipado, Stripe activo en Pagos online y la página de reservas de su web). La página del cliente muestra **Pagar con tarjeta**; al volver, la reserva pasa a **pagada** sola (si el cliente cierra el navegador, el programa lo comprueba cada pocos minutos). Si una reserva pagada con tarjeta se cancela, **la señal se devuelve sola por Stripe**; si falla, queda «Devolver señal» con el botón **Devolver por Stripe**. Un pago que llega cuando la reserva ya no lo admite (cancelada, caducada o con otro importe) también se devuelve solo. Las sesiones de pago de reservas canceladas o cambiadas se cierran.
- **La señal pagada se descuenta sola al salir:** cuando el vehículo con reserva entra (o cuando se cobra la señal con el coche ya dentro), la señal se anota como **pago anticipado del ticket** (factura simplificada, método «online» si fue por tarjeta o «transferencia» con la forma de pago anotada si la cobró el personal) y «lo ya pagado» la descuenta al cobrar la salida. Si la señal es mayor que la estancia, Salida avisa de que la diferencia no se devuelve sola. Aviso: la factura de la señal lleva la fecha de la entrada del vehículo, no la del pago; consulte con su gestor si esto le encaja fiscalmente.
- **Modificar la reserva:** la página del cliente tiene **Cambiar fechas** (con el mismo plazo que la cancelación gratuita): se vuelve a comprobar el cupo sin contar la propia reserva, se recalcula el precio y se avisa por email. Con la señal ya pagada solo se admiten fechas con la misma señal. El personal puede hacerlo siempre con **Cambiar fechas** en Reservas.
- **No presentados:** nuevo ajuste «Liberar la plaza si no llega (minutos tras la entrada)», 0 = apagado. Pasado ese tiempo, la reserva se cancela, la plaza queda libre y **la señal pagada no se devuelve** (se ve «No se presentó» y «Señal retenida»).
- **Recordatorio por email:** nuevo ajuste «Recordatorio por email (horas antes)», 0 = apagado. Se envía una vez, con el código y el **QR adjunto en imagen**. La confirmación de reserva también lleva ahora el QR adjunto.
- **Informe de reservas:** Reservas → **Informe…** con totales por estado, importe previsto, señales (cobradas, devueltas, por devolver, retenidas, pendientes), porcentaje de no presentados y estancias que se pasaron de la hora reservada (el tiempo de más ya se cobraba con la tarifa normal). Descarga en **CSV**.
- **Interno:** migración 42 (`pago_sesion`, `pago_ref`, `noshow`, `recordatorio`, `modificada`, `senal_pago_id`, `senal_devuelta_ref` en `reservas_previstas`). Módulos nuevos `svc_reservas_despues.py`, `svc_reservas_pago.py`, `agente_reservas.py`; `codigos.qr_png`; `Stripe.reembolsar` y `expirar_sesion`. Rutas nuevas: `PUT /api/reservas-online/{id}`, `GET /api/reservas-online/informe[.csv]`, `POST /api/reservas-online/{id}/senal-reembolsar`, `GET|POST /api/reservas-online/relay`, `GET /api/reservas-online/servidor.zip`, y públicas `POST /api/publico/reservas/{modificar,pagar,pago-confirmar}`. Claves nuevas: `reservas_noshow_min`, `reservas_recordatorio_horas`, `reservas_pago_online`, `reservas_relay_activo|url|token`. Todo lo nuevo vive en `app/`, `web/` y `scripts/`.

## 1.17 — 16 de octubre de 2026

- **Duración mínima de la reserva (Ajustes → Reservas online → Cupos y reglas):** nueva regla «Duración mínima de la reserva (minutos)», de 0 (sin mínimo, como hasta ahora) a 1440. Las reservas de clientes más cortas no se admiten: la web avisa con «La reserva debe durar al menos…» ya al consultar el precio, y la página de reservas muestra «Reserva mínima: …». El personal puede crear reservas más cortas desde Reservas, igual que con la antelación mínima.
- **Interno:** nueva clave `reservas_min_minutos`; `pub_config` devuelve `min_minutos`.

## 1.16 — 16 de octubre de 2026

- **Web de pruebas de las reservas, dentro del programa:** en Ajustes → Reservas online → **Probar en local** hay un botón para **activar y desactivar** la web local de pruebas. Con ella activa se ve la **dirección** (con botón para copiarla y abrirla) y su **código QR**; además, un aviso con la dirección se muestra arriba en todas las pestañas de Reservas online mientras esté activa. Con «También desde otros dispositivos de la red» se abre al móvil por Wi-Fi (el QR usa la IP del equipo). Es la misma página que se publicará en la web del aparcamiento, y las reservas que se hacen en ella son reales. Se apaga sola al cerrar o reiniciar el programa. Si el puerto 8090 está ocupado usa el siguiente libre. Para poder probar sin parar, las reservas que entran por la web de pruebas **no tienen el límite de peticiones por IP ni el de reservas pendientes por email** (los cupos de plazas sí se respetan); el resto del programa mantiene los límites.
- **Reservas online reorganizado en pestañas:** **General** (activar y una lista de lo que falta para que funcione), **Cupos y reglas**, **Cobro**, **Web de clientes** (página de reservas de la web, dirección de la API, condiciones, opciones avanzadas para Internet y el kit para la web) y **Probar en local**. «Guardar» guarda las cuatro primeras pestañas a la vez.
- **Interno:** la web de pruebas pasa a `app/web_pruebas.py` (gestor `WebPruebas`; `scripts/web_pruebas.py` y `scripts/ARRANCAR_WEB_PRUEBAS.bat` siguen sirviendo para usarla desde la línea de comandos). Rutas nuevas `GET` y `POST /api/reservas-online/web-pruebas` (solo administradores).

## 1.15 — 16 de octubre de 2026

- **Web local para probar las reservas:** nuevo `scripts/ARRANCAR_WEB_PRUEBAS.bat` (o `python scripts/web_pruebas.py`). Con el programa en marcha y las reservas activadas, levanta en `http://127.0.0.1:8090` una web que se comporta como la web del aparcamiento: sirve la carpeta `integracion_web/` y reenvía la API de reservas al programa, como haría un servidor web con proxy. Permite probar todo el recorrido del cliente (reservar, ver el código, consultar y cancelar) sin publicar nada en Internet ni configurar «Webs autorizadas». Encuentra sola el programa en marcha (o `--programa http://127.0.0.1:8080`); `--puerto` cambia el 8090 y `--host 0.0.0.0` permite probar desde el móvil por Wi-Fi; `--abrir` abre el navegador. Avisa si las reservas no están activadas.
- **Ajustes → Reservas online:** una nota explica cómo arrancarla. Todo lo nuevo va dentro de `scripts/`, que es lo que aceptan los paquetes de actualización de cualquier versión anterior.

## 1.14 — 16 de octubre de 2026

- **Se elimina la página de reservas para clientes del programa:** el programa ya no sirve `/reservar` ni ofrece reservar desde el propio parking. Las reservas de clientes son **solo online y con antelación**, desde la web del aparcamiento. Desaparecen también el código QR y el cartel «Reserve su plaza» de Ajustes. El personal sigue creando reservas en **Reservas** (teléfono o mostrador).
- **Preparado para subir la web a un servidor:** la página de reservas pasa a la carpeta `scripts/integracion_web/` (`reservas.html`, `reservas.js` y un `LEEME.md` con los pasos), lista para subir a cualquier alojamiento o integrar en la web del aparcamiento. Habla con el programa por la API `/api/publico/reservas/*`. En Ajustes → Reservas online → **Reservas desde la web del aparcamiento**: *Dirección del programa visible desde la web (API)* (es el campo que antes se llamaba «Dirección pública»), *Página de reservas en su web* (la usa el enlace del email, con `?c=CÓDIGO`), *Webs autorizadas* (CORS), *Proxy de confianza* y *Aceptar peticiones desde Internet*. El botón **Descargar kit para la web** entrega el zip con la dirección de la API ya puesta.
- **Seguridad:** desde Internet solo se responde a `/api/publico/reservas/*` y solo si se marca «Aceptar peticiones desde Internet»; el resto del programa nunca se sirve fuera de la red local. Una web solo puede reservar si su dominio está en «Webs autorizadas» (o `*`). Con un proxy de confianza, el límite de peticiones por IP se aplica a la IP real del cliente.
- **Email de confirmación:** el enlace para ver o cancelar apunta a la página de reservas de la web (ya no a la dirección del programa); sin esa dirección, el email no lleva enlace.
- **Interno:** nuevas claves `reservas_web_url`, `reservas_origenes`, `reservas_internet`, `reservas_proxies`; se elimina `POST /api/reservas-online/qr`; nueva `GET /api/reservas-online/kit.zip` (admin). `scripts/integracion_web` viaja en los paquetes de actualización.

## 1.13 — 16 de octubre de 2026

- **Limpieza de actualizaciones (Ajustes → Sistema → Actualizaciones):** un panel nuevo, «Limpieza de actualizaciones», lista los paquetes guardados en el equipo (subidos o descargados) con su estado —no válido, ya instalado, anterior, no se puede instalar o pendiente de instalar— y su tamaño. Se puede **eliminar uno a uno**, **quitar los que no sirven** (no válidos, ya instalados, anteriores o que la versión o la licencia no admiten), o **quitar también los pendientes**. Antes esos archivos se quedaban en la carpeta sin que se vieran.
- **Copias de versiones anteriores:** botón para borrar las copias del programa que se guardan al actualizar (solo ocupan espacio, porque desde el programa no se puede volver atrás). Los datos y las copias de seguridad no se tocan.
- **Limpiar historial:** el historial de actualizaciones puede limpiarse para que solo muestre desde la versión instalada; **Mostrar historial completo** lo recupera. Solo cambia lo que se ve (y el archivo de texto): el programa y el registro de auditoría no se tocan, y cada limpieza queda anotada en la auditoría.
- **Interno:** `POST /api/actualizaciones/limpiar` (solo administradores; `paquetes`: `inutiles|todos|[nombres]`, `copias`, `historial`: `limpiar|restaurar`). `GET /api/actualizaciones` añade `limpiar` y `tamano` a cada paquete, `tamano` a las copias guardadas, `historial_limpio` y `historial_total`. Clave de configuración `actualizaciones_historial_desde`.

## 1.12 — 16 de octubre de 2026

- **QR de la página de reservas en Ajustes:** en Ajustes → Conexiones → Reservas online, dentro de «Página para clientes», se ve el código QR de la dirección, con **Imprimir cartel…** (un cartel «Reserve su plaza» con el QR, listo para poner en la entrada o el mostrador) y **Descargar QR**. Usa la «Dirección pública» guardada; si el programa se abrió como «localhost», usa la IP del equipo en la red y avisa de que conviene guardarla.
- **Cobro de la reserva (nuevo apartado en Reservas online):** se elige entre **Se paga en el parking** (como hasta ahora, por defecto), **Pagar una señal** (importe fijo o porcentaje del importe) y **Pago anticipado** (todo el importe). Con señal o pago anticipado se fija un **plazo para pagar** y unas **instrucciones** (Bizum, transferencia…) que ve el cliente en la página y en el email. Si no se paga a tiempo, la reserva **se cancela sola** y la plaza queda libre; el plazo nunca pasa de la hora de entrada.
- **Dónde se ve y se gestiona la señal:** en la lista de Reservas (etiqueta «Señal sin cobrar / cobrada / Devolver señal», botón **Señal cobrada** con el método de pago, aviso con el número de señales sin cobrar o por devolver y filtro «Señal por devolver»), en la ventana de reservas nuevas, en el aviso al entrar el vehículo (se puede cobrar desde ahí) y en Salida («Señal ya pagada: descuéntela del importe a cobrar»). Al crear una reserva en mostrador se puede marcar «Señal cobrada ahora». Si se cancela una reserva con la señal cobrada queda «Devolver señal» hasta que se marque como devuelta.
- **Importante:** el programa **anota** el cobro de la señal, pero no la cobra: no hay pago con tarjeta en línea y el importe no entra en la caja del turno ni se resta solo en el cobro de la salida (el aviso en Salida indica cuánto descontar).
- **Detección de la matrícula de la reserva en Entrada:** la ventana de «Este vehículo tiene una reserva» sale **en cuanto se escribe o lee por cámara la matrícula**, sin esperar a emitir el ticket (y sigue saliendo al emitir si no se decidió). Además, un panel nuevo en Entrada, **Reservas que llegan hoy**, lista las reservas pendientes del día con hora, zona y cliente («Ya puede entrar» / «Más tarde»); un clic rellena la matrícula y abre el aviso.
- **Interno:** base de datos versión 41 (`senal_cent`, `pago_limite`, `pago_fecha`, `pago_metodo`). Rutas nuevas `GET /api/reservas-online/llegadas`, `POST /api/reservas-online/{id}/senal`, `POST /api/reservas-online/{id}/senal-devuelta` y `POST /api/reservas-online/qr` (solo administradores).

## 1.11 — 16 de octubre de 2026

- **Reservas, sección propia del menú:** ahora está justo debajo de **Vehículos** (atajo **F9**) y ya no es una pestaña de Vehículos. Si el fabricante la tenía oculta como pestaña, sigue oculta; en Sistema → Supervisión aparece como opción de menú.
- **Aviso al entrar un vehículo con reserva:** al emitir la entrada de una matrícula que tiene reserva (online, de mostrador o de plataforma) sale una ventana con los datos de la reserva para **confirmar la entrada** o **cancelar la reserva**. Si el coche llega antes de hora lo dice y deja entrar sin la reserva. Bajo el campo de matrícula también se ve la reserva en cuanto se escribe, o cuando la lee la cámara.
- **El QR de la reserva se reconoce:** el código que recibe el cliente (`R-XXXXXX`) se lee con el lector desde cualquier pantalla (o se escribe en Entrada o en Salida) y abre la reserva: confirmar entrada lleva a Entrada y emite el ticket; si ya se usó, dice con qué ticket y lo abre. Antes ese código no lo reconocía nadie.
- **Corregido, la reserva no se enlazaba:** la entrada por la caja siempre manda una tarifa, y con una tarifa elegida la reserva online no se unía al ticket (seguía «pendiente» y la plaza contaba dos veces). Ahora se enlaza siempre y el ticket entra en la zona reservada.
- **Salida y Vehículos avisan:** el ticket de un vehículo que entró con reserva lo indica en Salida (código, zona, fechas) y en Vehículos → Dentro ahora aparece la etiqueta «Reserva»; si tiene una reserva pendiente que no se aplicó, también se avisa.
- **Reservas nuevas de clientes:** cuando un cliente reserva desde la página pública, el personal con permiso de reservas ve una ventana (con un pitido) con los datos para **confirmar** o **cancelar**, y una insignia roja en «Reservas» del menú hasta que se revisan. «Más tarde» deja la ventana y la insignia; en la lista las reservas nuevas llevan una etiqueta y un botón «Confirmar». El cliente ya tenía la plaza guardada: confirmar solo quita el aviso.
- **Página de reservas para clientes, versión móvil y de escritorio:** en pantalla ancha el formulario va a la izquierda y el resumen (fechas, zona, matrícula, disponibilidad y precio) queda fijo a la derecha; hay indicador de pasos (fechas, datos, confirmación), cabecera con enlace a «Mi reserva» y la confirmación enseña los tres pasos a seguir y permite imprimirla. En tableta y móvil todo va en una columna.
- **Interno:** base de datos versión 40 (`revisada` en las reservas). Rutas nuevas `GET /api/reservas-online/aviso`, `GET /api/reservas-online/por-revisar` y `POST /api/reservas-online/{id}/confirmar`; `/api/estado` trae `reservas_online` y `reservas_nuevas`.

## 1.10 — 16 de octubre de 2026

- **Página de reservas para clientes:** en `http://<dirección del programa>/reservar` el cliente reserva desde su móvil, sin contraseña. Elige entrada y salida, zona y tipo de vehículo, ve si hay plaza y cuánto costará (a pagar en el parking), escribe su matrícula, nombre y email, acepta las condiciones y recibe un código con su QR. Con el código y la matrícula puede volver a ver su reserva o cancelarla (gratis hasta las horas que se fijen).
- **Activación aparte, apagada por defecto:** Ajustes → Conexiones → Reservas online → «Página de reservas para clientes». Muestra la dirección que hay que dar a los clientes, deja poner el texto de las condiciones y una dirección pública para el enlace del email. **Solo funciona desde la red local**; desde Internet no se sirve.
- **Protecciones:** límite de peticiones por IP (reservas, consultas y búsquedas de código), máximo de 3 reservas pendientes por email, campo trampa contra robots, validación estricta de todo lo que llega, aviso genérico cuando no se encuentra una reserva y el mismo cupo, horario y antelación que las reservas del personal. Queda constancia de cuándo aceptó las condiciones.
- **Email de confirmación:** con el código, los datos y el enlace para verla o cancelarla. Si no hay servidor de correo o falla el envío, la reserva se mantiene, el cliente ve su código en pantalla y el envío se reintenta (Ajustes → Email). En Vehículos → Reservas se ve qué reservas vienen de clientes y si su email salió, y hay una acción «Reenviar confirmación por email».
- **Interno:** base de datos versión 39 (estado del email y aceptación de condiciones). Las cinco rutas públicas nuevas están dadas de alta a propósito en la prueba de seguridad.

## 1.9.4 — 16 de octubre de 2026

- **Tipo de licencia con otro diseño:** en el menú se ve como una etiqueta suave con un punto del color del plan (antes, una píldora de color sólido en mayúsculas).

## 1.9.3 — 16 de octubre de 2026

- **Horario del parking:** cerrar a medianoche es poner «Cierra» a las 00:00 (a las 00:00 ya está cerrado; una reserva puede salir justo al cierre). Los **festivos tienen ahora el mismo horario que los domingos** (antes eran días de cierre total); si el domingo está cerrado, los festivos también. Si ya habías guardado «días cerrados» en la 1.9, esas fechas pasan a ser festivos con horario de domingo.
- **Versión y licencia en el menú, rediseñadas:** nombre, versión y tipo de licencia (con su color, como etiqueta) quedan centrados, y debajo el estado de la licencia (por ejemplo «Prueba: 5 días»).
- **Aviso de actualización:** cuando la búsqueda automática encuentra una versión nueva, aparece en el menú un botón «↑ Nueva versión X» (solo para administradores) que lleva a Ajustes → Sistema → Actualizaciones.

## 1.9.2 — 16 de octubre de 2026

- **Corregido:** al guardar Ajustes → Empresa → Horario del parking salía el error «'[data-k=24h]' is not a valid selector» y no se guardaba nada. Ahora se guarda. Se ha añadido una prueba automática en un navegador que guarda y vuelve a leer el horario.
- **Datos de demostración:** de madrugada, los bonos que tocaban vender «hoy» no cabían y salían menos de los pedidos; ahora se pasan al día anterior.

## 1.9.1 — 15 de octubre de 2026

- **Reservas: el cupo cuenta los coches con reserva que ya están dentro.** Si en una zona se fija un cupo de 5, nunca habrá más de 5 coches con reserva a la vez en esa zona: cuentan los que aún tienen que llegar **y** los que ya han entrado y siguen dentro, hasta que salen (aunque se pasen de su hora de salida). Antes una reserva dejaba de contar en cuanto entraba el coche. El resto de plazas queda libre para quien llegue sin reserva. Se ha aclarado el texto de Ajustes → Conexiones → Reservas online.

## 1.9 — 15 de octubre de 2026

- **Horario del parking:** nueva pestaña Ajustes → Empresa → Horario del parking. Se marca qué días abre, de qué hora a qué hora (o 24 h; una franja puede pasar de medianoche) y los días cerrados (festivos, obras). Con el horario activado **no se dan entradas ni salidas con el parking cerrado**: ni por caja, ni por el lector de matrículas, ni a abonados. El aviso dice el horario de hoy. Los supervisores y administradores pueden operar igualmente, por si hay una urgencia. Sin activar, todo sigue como antes.
- **Reservas y horario:** una reserva online solo se acepta si su entrada y su salida caen con el parking abierto.
- **Plazas por reserva:** en Ajustes → Conexiones → Reservas online se fija el máximo de plazas que puede pedir una reserva (1 = una plaza). Cada plaza cuenta en el cupo de la zona, así que el máximo de reservas que coinciden sigue siendo el cupo configurado; el precio se multiplica por las plazas.
- **Interno:** base de datos versión 38 (columna `plazas`). La página pública para clientes pasa a la 1.10.

## 1.8 — 15 de octubre de 2026

- **Reservas online (primera parte):** nuevo interruptor en Ajustes → Conexiones → Reservas online, **apagado por defecto**. Apagado, el programa funciona exactamente como antes; las reservas ya hechas se conservan si se apaga.
- **Reservar una plaza en una zona entre dos fechas:** en Vehículos → Reservas, botón «Nueva reserva online…». Al elegir zona y fechas se ve cuántas plazas quedan y el precio con la tarifa normal; la reserva recibe un código (R-XXXXXX). Por ahora la crea el personal y se paga en el parking.
- **Cupo por zona y reglas:** en Ajustes se decide cuántas plazas de cada zona se ofrecen a reservas (0 = ninguna), con qué antelación mínima y máxima, la duración máxima y hasta cuántas horas antes de la entrada se puede cancelar gratis. Nunca se acepta una reserva que supere el cupo, ni dos para la misma matrícula en las mismas fechas.
- **Al llegar:** al dar entrada a la matrícula la reserva se enlaza sola con el ticket y el vehículo entra en la zona reservada. A diferencia de las reservas de plataformas u hoteles, el tiempo no se descuenta: se cobra con la tarifa normal.
- **Interno:** la base de datos pasa a la versión 37 (columnas nuevas en reservas y cupo por zona; se migra sola y no se pierde nada). El atributo `hidden` oculta ya también botones y etiquetas con estilo propio.
- **Pendiente para la 1.9:** la página pública para que el cliente reserve desde su móvil, confirmación por email y pago online opcional.

## 1.7 — 15 de octubre de 2026

- **Importar y exportar con menos botones:** cada bloque tiene ahora un selector del listado y un menú «Exportar ▾» con los cuatro formatos (CSV, Excel, Excel antiguo y PDF), un menú «Plantilla ▾» y, para tarifas, servicios y productos, un menú «Copia .json ▾».
- **Zona al dar entrada o cambiar de zona:** ahora son botones neutros en una sola barra; la zona elegida se marca con el color del programa, sin colores por zona.

## 1.6 — 15 de octubre de 2026

- **Ajustes → Sistema → Importar y exportar, reorganizado:** dos bloques claros («Abonados y clientes» y «Tarifas, servicios y productos»), cada uno con su importación, su plantilla y sus exportaciones, y un tercer bloque rojo para borrar clientes.
- **Todos los listados, en cuatro formatos:** CSV, Excel (.xlsx), Excel antiguo (.xls) y PDF, con un botón por formato: abonados, clientes sin abono, todos los clientes, listado de abonados con su bono, servicios, productos de tienda y tarifas. Los Excel salen con la cabecera destacada y fija, columnas ajustadas e importes con dos decimales.
- **Importar desde Excel (.xlsx y .xls) o CSV:** clientes y abonados (ya se podía con .xlsx y CSV; ahora también .xls) y, nuevo, **servicios y productos de tienda** desde una hoja de cálculo, con plantilla para descargar y vista previa de lo que cambia antes de aplicar. Las tarifas se siguen importando solo desde el archivo .json (llevan tramos y horarios). Un PDF no se puede importar: no tiene columnas fiables.
- **Borrar clientes desde Ajustes:** se elige «solo los clientes sin abono» o «todos los clientes». Se ve cuántos se pueden borrar y cuántos se quedan y por qué (con bono, con suscripción o con un vehículo dentro, para no romper la contabilidad), y se pide escribir BORRAR y el PIN. Antes se hace una copia de seguridad; las facturas emitidas no cambian.

## 1.5 — 15 de octubre de 2026

- **Cabeceras de seguridad:** todas las respuestas llevan `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy` y `Permissions-Policy`; las páginas, además, una política de contenido (CSP) que solo permite scripts del propio programa. Los pocos scripts que estaban dentro del HTML se han sacado a archivos.
- **Archivos de la interfaz:** corregida la comprobación de carpeta, que habría dejado leer carpetas vecinas cuyo nombre empezara por «web».
- **Pruebas de seguridad automáticas:** recorren las 302 rutas sin sesión (todas deben dar 401), con un cajero y con un supervisor (las de administración deben dar 403), fijan la lista de rutas públicas permitidas, prueban escapes de carpeta, nombres de copia manipulados y el bloqueo tras PIN erróneo.

## 1.4 — 15 de octubre de 2026

- **Reorganización interna, sin cambios visibles:** la lógica de negocio, que estaba en un único archivo de más de 6.000 líneas, se reparte en catorce módulos por áreas (licencia, usuarios, tarifas, caja, tickets, catálogo, equipos, facturas, integraciones, clientes, avisos, cobro online, documentos y sistema). Cada cambio futuro afecta a una parte más pequeña y es más fácil de revisar.

## 1.3 — 15 de octubre de 2026

- **Reorganización interna, sin cambios visibles:** las rutas del servidor, que estaban todas en un único archivo muy largo, pasan a siete módulos por áreas (sistema, acceso, caja, tickets, clientes, facturación y pantalla de cliente). Hace más seguro y rápido tocar cada parte en el futuro.
- **Pruebas en un navegador real:** recorren todas las pantallas y apartados de Ajustes, anular un bono, la ventana de factura de proveedor y el aviso de series, y fallan si aparece un error de JavaScript.

## 1.2 — 15 de octubre de 2026

- **Anular un bono:** ya no usa el cuadro del navegador. Es una ventana propia con el motivo obligatorio y el botón en rojo.
- **Errores que antes pasaban en silencio:** el programa anota en su registro (consola del servidor) los fallos que absorbe, como comprobar la licencia, las sesiones o la copia en la nube. Los graves aparecen además en la campana del administrador.
- **Paquetes de actualización equivocados:** si se sube uno de una versión anterior, o uno de la numeración nueva (1.x) sobre una instalación 4.x, el mensaje dice qué paquete hace falta. El paquete puente 4.x → 1.x no se acepta en instalaciones que ya son 1.x.
- **Ajustes → Abonados:** se quita «Listado» (duplicaba Clientes; la exportación sigue en Importar y exportar). Quedan «Tipos de bono» y «Avisos».
- **Numeración:** avisa al momento, y el servidor lo impide, si coinciden las series de facturas, proveedores y rectificativas.
- **Interno:** ventana de formulario común y etiqueta común del estado de factura.

## 1.1 — 15 de octubre de 2026

- **Facturas a proveedor más simples:** cada factura lleva un solo servicio y se paga siempre por transferencia (sin elegir método ni necesitar caja abierta). La ventana pide solo proveedor (ya elegido si se abre desde su ficha), servicio, cantidad, referencia y observaciones.
- **Ventana propia para la factura del proveedor:** en lugar del formulario de datos del cliente y la vista en formato ticket, muestra un resumen (proveedor, servicio, importes e IVA) con el email, A4, PDF, enviar y el estado de la factura.
- **Ficha del proveedor:** botón «Nueva factura» y lista de todas sus facturas con servicio, importe y estado (Generada, Enviada o Cobrada) que se cambia ahí mismo.
- **Facturas:** filtro «Todas / Solo proveedores / Sin proveedores».
- **Servicios de proveedor:** en Ajustes → Precios ya no piden precio (lo pone cada proveedor) y se muestran como «Según proveedor».

## 1.0 — 15 de octubre de 2026

Primera versión estable con la numeración nueva. Reúne todo lo desarrollado hasta ahora:

- **Cobro de parking:** entrada y salida por matrícula o ticket con QR, tarifas por tramos, horarios, hotel/reservas, precio fijo, máximo diario y redondeo; cobro en efectivo o tarjeta, ticket manual, tienda, descuentos y vales, pago con el móvil y devoluciones o rectificaciones.
- **Abonados y clientes:** bonos mensuales con renovación automática y suscripciones con pago automático, vehículos con foto, clientes sin abono con descuento fijo y **proveedores** con sus servicios y precios propios (solo factura, serie y numeración aparte).
- **Facturación:** factura simplificada o con datos del cliente, PDF en A4, envío por email, estado de cada factura (generada, enviada o cobrada), sello del garaje y registro encadenado preparado para VERI*FACTU.
- **Caja y personal:** turnos y arqueo, varios cajeros a la vez, control de turnos por QR, permisos a medida y auditoría.
- **Equipos:** impresoras de ticket y A4 (o solo en pantalla para pruebas), cajón, barrera, datáfono, pantalla de cliente, semáforo y cartel, caja móvil con lector de matrícula por cámara.
- **Sistema:** copias de seguridad (también cifradas en la nube), actualizaciones firmadas con historial de versiones descargable, licencia por módulos, modo demostración con datos de ejemplo y ajustes ordenados en siete apartados.
