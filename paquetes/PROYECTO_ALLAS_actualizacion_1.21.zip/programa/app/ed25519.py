"""Firma digital Ed25519 (RFC 8032) en Python puro, sin dependencias.

Se usa para que solo quien tiene la clave privada (el Gestor de licencias) pueda emitir
licencias y paquetes de actualización válidos. PROYECTO ALLAS solo lleva la clave pública,
con la que comprueba las firmas.
"""
import hashlib

_P = 2 ** 255 - 19
_L = 2 ** 252 + 27742317777372353535851937790883648493
_D = -121665 * pow(121666, _P - 2, _P) % _P
_I = pow(2, (_P - 1) // 4, _P)


def _h(m):
    return hashlib.sha512(m).digest()


def _inv(x):
    return pow(x, _P - 2, _P)


def _x_desde_y(y, signo):
    xx = (y * y - 1) * _inv(_D * y * y + 1) % _P
    x = pow(xx, (_P + 3) // 8, _P)
    if (x * x - xx) % _P:
        x = x * _I % _P
    if (x * x - xx) % _P:
        raise ValueError("punto no válido")
    if x == 0 and signo:
        raise ValueError("punto no válido")
    if (x & 1) != signo:
        x = _P - x
    return x


_BY = 4 * _inv(5) % _P
_BX = _x_desde_y(_BY, 0)
_B = (_BX, _BY, 1, _BX * _BY % _P)
_CERO = (0, 1, 1, 0)


def _sumar(p, q):
    x1, y1, z1, t1 = p
    x2, y2, z2, t2 = q
    a = (y1 - x1) * (y2 - x2) % _P
    b = (y1 + x1) * (y2 + x2) % _P
    c = t1 * 2 * _D * t2 % _P
    d = z1 * 2 * z2 % _P
    e, f, g, h = b - a, d - c, d + c, b + a
    return (e * f % _P, g * h % _P, f * g % _P, e * h % _P)


def _mult(s, p):
    q = _CERO
    while s > 0:
        if s & 1:
            q = _sumar(q, p)
        p = _sumar(p, p)
        s >>= 1
    return q


def _codificar(p):
    x, y, z, _ = p
    zi = _inv(z)
    x, y = x * zi % _P, y * zi % _P
    return (y | ((x & 1) << 255)).to_bytes(32, "little")


def _decodificar(s):
    if len(s) != 32:
        raise ValueError("longitud no válida")
    y = int.from_bytes(s, "little") & ((1 << 255) - 1)
    if y >= _P:
        raise ValueError("punto no válido")
    x = _x_desde_y(y, s[31] >> 7)
    return (x, y, 1, x * y % _P)


def _iguales(p, q):
    x1, y1, z1, _ = p
    x2, y2, z2, _ = q
    return (x1 * z2 - x2 * z1) % _P == 0 and (y1 * z2 - y2 * z1) % _P == 0


def _expandir(semilla):
    h = _h(semilla)
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def clave_publica(semilla):
    """Clave pública (32 bytes) a partir de la clave privada (semilla de 32 bytes)."""
    a, _ = _expandir(semilla)
    return _codificar(_mult(a, _B))


def firmar(semilla, mensaje):
    a, prefijo = _expandir(semilla)
    pub = _codificar(_mult(a, _B))
    r = int.from_bytes(_h(prefijo + mensaje), "little") % _L
    rr = _codificar(_mult(r, _B))
    k = int.from_bytes(_h(rr + pub + mensaje), "little") % _L
    return rr + ((r + k * a) % _L).to_bytes(32, "little")


def verificar(publica, mensaje, firma):
    """True si 'firma' (64 bytes) es válida para 'mensaje' con la clave 'publica'."""
    if len(firma) != 64 or len(publica) != 32:
        return False
    try:
        a = _decodificar(publica)
        r = _decodificar(firma[:32])
    except ValueError:
        return False
    s = int.from_bytes(firma[32:], "little")
    if s >= _L:
        return False
    k = int.from_bytes(_h(firma[:32] + publica + mensaje), "little") % _L
    return _iguales(_mult(s, _B), _sumar(r, _mult(k, a)))
