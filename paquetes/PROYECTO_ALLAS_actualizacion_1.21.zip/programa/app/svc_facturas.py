"""PROYECTO ALLAS · lógica de negocio: facturas, devoluciones, rectificativas, correo de facturas, numeración y proveedores (1.4: sale de servicios.py; se mezcla en la clase Parking)."""
import re

from . import logo as logos
from .utiles import ErrorNegocio, ROLES_SUPERVISION, _partir_txt, _plantilla, desglose_iva, email_valido, eur, fecha_es, iso, nif_valido, norm_matricula, parse, texto_duracion, texto_metodo


class SvcFacturas:
    # =================================================== facturas y email
    def _pago_completo(self, pago_id):
        """Reconstruye todo lo necesario para volver a generar la factura de un pago."""
        pago = self.db.q1("SELECT * FROM pagos WHERE id=?", (pago_id,))
        if not pago:
            raise ErrorNegocio("Factura no encontrada", 404)
        pago["destinatario"] = self.db.q1("SELECT * FROM facturas_destinatario WHERE pago_id=?", (pago_id,))
        if pago.get("usuario_id"):
            u = self.db.q1("SELECT nombre FROM usuarios WHERE id=?", (pago["usuario_id"],))
            pago["usuario_nombre"] = u and u["nombre"]
        pago["lineas_extra"] = self.db.q("SELECT nombre, precio_cent, cantidad, iva_pct, minutos_incluidos, descripcion "
                                         "FROM ticket_extras WHERE pago_id=? ORDER BY id", (pago_id,))
        if pago["concepto"] == "venta":
            pago["lineas_extra"] = self.db.q("SELECT nombre, precio_cent, cantidad, iva_pct, 0 minutos_incluidos, descripcion "
                                             "FROM ventas_lineas WHERE pago_id=? ORDER BY id", (pago_id,))
        iva_gen = float(self.cfg("iva_pct") or 21)
        estancia = pago["importe_cent"] - (pago["extras_cent"] or 0)
        if pago["concepto"] == "sustitutiva":
            # 4.0: la factura sustitutiva repite el contenido de la original con su propio número y destinatario
            base = self._pago_completo(pago["sustituye_id"])
            propio = {k: pago[k] for k in ("id", "serie", "numero", "fecha", "importe_cent", "metodo", "usuario_id",
                                            "turno_id", "motivo", "sustituye_id", "referencia")}
            base.update(propio)
            base["concepto_real"], base["destinatario"] = "sustitutiva", pago["destinatario"]
            base["sustituye"] = self.db.q1("SELECT id, serie, numero, fecha FROM pagos WHERE id=?", (pago["sustituye_id"],))
            return base
        if pago["concepto"] == "rectificativa":
            pago["original"] = self.db.q1("SELECT id, serie, numero, fecha, importe_cent, metodo, concepto FROM pagos WHERE id=?",
                                          (pago["rectifica_id"],))
            pago["desglose_iva"] = desglose_iva(self._lineas_devolucion(pago["rectifica_id"], -pago["importe_cent"]))
            pago["minutos_incluidos"] = 0
            return pago
        if pago["concepto"] == "venta" and pago.get("descuento_cent"):
            pago["desglose_iva"] = desglose_iva(self._lineas_iva_con_descuento(pago["lineas_extra"], pago["descuento_cent"]))
        else:
            pago["desglose_iva"] = desglose_iva([(estancia, iva_gen)] + [(e["precio_cent"] * e["cantidad"], e["iva_pct"])
                                                                         for e in pago["lineas_extra"]])
        pago["minutos_incluidos"] = min(pago["minutos"], sum((e["minutos_incluidos"] or 0) * e["cantidad"]
                                                             for e in pago["lineas_extra"]))
        return pago

    def _doc_de_pago(self, pago_id, copia=False):
        pago = self._pago_completo(pago_id)
        pago["copia"] = copia
        if pago["concepto"] == "rectificativa":
            return self._doc_rectificativa(pago), pago
        if pago["bono_id"]:
            bono = self.db.q1("SELECT b.*, p.nombre plan_nombre FROM bonos b JOIN planes_bono p ON p.id=b.plan_id "
                              "WHERE b.id=?", (pago["bono_id"],))
            return self._doc_recibo_bono(self.cliente(bono["cliente_id"]), bono, pago), pago
        if pago["concepto"] == "venta":
            return self._doc_recibo_venta(pago), pago
        tk = self.ticket(pago["ticket_id"])
        return self._doc_recibo(tk, pago, None), pago

    # ------------------------------------------------------------ 3.9: devoluciones (facturas rectificativas)
    def _lineas_devolucion(self, pago_id, importe):
        """Reparte una devolución (en positivo) entre los tipos de IVA de la factura original, en negativo."""
        orig = self._pago_completo(pago_id)
        total = orig["importe_cent"] or 1
        lineas, acumulado = [], 0
        desg = [d for d in orig["desglose_iva"] if d["total"]] or [{"pct": float(self.cfg("iva_pct") or 21), "total": total}]
        for i, d in enumerate(desg):
            parte = importe - acumulado if i == len(desg) - 1 else round(importe * d["total"] / total)
            acumulado += parte
            lineas.append((-parte, d["pct"]))
        return lineas

    def devoluciones_activas(self):
        """4.2: devoluciones (rectificativa por diferencias), opcional por separado."""
        return self.activo("devoluciones_activo", "facturacion")

    def rectificacion_activa(self):
        """4.2: rectificación de los datos de una factura (por sustitución), opcional por separado."""
        return self.activo("rectificacion_activo", "facturacion")

    def facturacion_activa(self):
        """Alguna de las dos (devoluciones o rectificación) en marcha."""
        return self.devoluciones_activas() or self.rectificacion_activa()

    def _exigir_facturacion(self, que="devoluciones"):
        if que == "devoluciones" and not self.devoluciones_activas():
            raise ErrorNegocio("Las devoluciones están desactivadas (Ajustes → Empresa → Preferencias → Opciones)", 409)
        if que == "rectificacion" and not self.rectificacion_activa():
            raise ErrorNegocio("La rectificación de facturas está desactivada (Ajustes → Empresa → Preferencias → Opciones)", 409)

    def devoluciones_de(self, pago_id):
        return self.db.q("SELECT id, serie, numero, fecha, -importe_cent importe_cent, metodo, motivo FROM pagos "
                         "WHERE rectifica_id=? AND COALESCE(rectificacion,'diferencias')='diferencias' ORDER BY id", (pago_id,))

    def devolver_pago(self, usuario, pago_id, importe_cent=None, metodo=None, motivo="", autorizado_por=None):
        """Devolución total o parcial de un cobro: factura rectificativa (serie aparte, importe negativo) que resta
        del turno de quien devuelve. Solo supervisor/administrador (o un cajero con su autorización)."""
        self._exigir_facturacion()
        actor = autorizado_por or usuario
        if actor["rol"] not in ROLES_SUPERVISION:
            raise ErrorNegocio("Las devoluciones necesitan la autorización de un supervisor", 403)
        motivo = (motivo or "").strip()
        if len(motivo) < 3:
            raise ErrorNegocio("Indique el motivo de la devolución")
        orig = self.db.q1("SELECT * FROM pagos WHERE id=?", (int(pago_id),))
        if not orig:
            raise ErrorNegocio("Factura no encontrada", 404)
        if orig["concepto"] == "rectificativa":
            raise ErrorNegocio("Esa factura ya es una rectificativa")
        sust = self.db.q1("SELECT serie, numero FROM pagos WHERE sustituye_id=?", (orig["id"],))
        if sust:
            raise ErrorNegocio(f"Esta factura se sustituyó por la {sust['serie']}-{sust['numero']:06d}: haga la devolución sobre esa")
        devuelto = -(self.db.q1("SELECT COALESCE(SUM(importe_cent),0) s FROM pagos WHERE rectifica_id=?", (orig["id"],))["s"])
        disponible = orig["importe_cent"] - devuelto
        if disponible <= 0:
            raise ErrorNegocio("Esta factura ya se ha devuelto entera")
        importe = disponible if importe_cent in (None, "") else int(importe_cent)
        if not 0 < importe <= disponible:
            raise ErrorNegocio(f"El importe a devolver debe estar entre 0,01 € y {eur(disponible)}")
        metodo = metodo or ("tarjeta" if orig["metodo"] == "online" else orig["metodo"])
        if metodo not in ("efectivo", "tarjeta", "transferencia", "online"):
            raise ErrorNegocio("Forma de devolución no válida")
        turno = None
        if metodo in ("efectivo", "tarjeta"):
            turno = self._exigir_turno(usuario)
            if metodo == "efectivo" and importe > turno["efectivo_esperado_actual_cent"]:
                raise ErrorNegocio(f"No hay tanto efectivo en su caja ({eur(turno['efectivo_esperado_actual_cent'])})")
        serie = (self.cfg("serie_rectificativa") or "R").strip().upper()[:4] or "R"
        if serie == (self.cfg("serie_factura") or "A"):
            serie = serie + "R"
        with self.db.transaccion() as c:
            pago = self._insertar_pago(c, turno, usuario, -importe, metodo, None, None, concepto="rectificativa",
                                       lineas=self._lineas_devolucion(orig["id"], importe), serie=serie)
            c.execute("UPDATE pagos SET rectifica_id=?, motivo=?, rectificacion='diferencias' WHERE id=?",
                      (orig["id"], motivo[:300], pago["id"]))
            dest = c.execute("SELECT * FROM facturas_destinatario WHERE pago_id=?", (orig["id"],)).fetchone()
            if dest:
                cols = [k for k in dest.keys() if k not in ("pago_id", "id")]
                c.execute(f"INSERT INTO facturas_destinatario(pago_id, {', '.join(cols)}) VALUES(?{', ?' * len(cols)})",
                          (pago["id"], *[dest[k] for k in cols]))
            self.auditar(c, actor["id"], "devolucion",
                         f"{pago['serie']}-{pago['numero']} rectifica {orig['serie']}-{orig['numero']} -{importe} {metodo} "
                         f"({motivo})" + (f" hecha por {usuario['usuario']}" if autorizado_por else ""))
        res = {"pago": self._pago_completo(pago["id"]), "devuelto_total_cent": devuelto + importe,
               "disponible_cent": disponible - importe}
        doc, _ = self._doc_de_pago(pago["id"])
        res["impresion"] = self._imprimir(doc, "rectificativa", cajon=(metodo == "efectivo"))
        return res

    def rectificar_factura(self, usuario, pago_id, datos, motivo="", autorizado_por=None):
        """4.0 · Rectificación por sustitución: para corregir los datos de una factura ya emitida (cliente, NIF,
        dirección…) sin mover dinero. Se emite una rectificativa que la anula (serie R) y una factura nueva con los
        datos correctos que la sustituye. Para cambiar el importe a favor del cliente: devolución (por diferencias)."""
        self._exigir_facturacion("rectificacion")
        actor = autorizado_por or usuario
        if actor["rol"] not in ROLES_SUPERVISION:
            raise ErrorNegocio("La rectificación de facturas necesita la autorización de un supervisor", 403)
        motivo = (motivo or "").strip()
        if len(motivo) < 3:
            raise ErrorNegocio("Indique el motivo de la rectificación")
        orig = self.db.q1("SELECT * FROM pagos WHERE id=?", (int(pago_id),))
        if not orig:
            raise ErrorNegocio("Factura no encontrada", 404)
        if orig["concepto"] == "rectificativa":
            raise ErrorNegocio("Una factura rectificativa no se rectifica: rectifique la factura original")
        sust = self.db.q1("SELECT serie, numero FROM pagos WHERE sustituye_id=?", (orig["id"],))
        if sust:
            raise ErrorNegocio(f"Ya se sustituyó por la {sust['serie']}-{sust['numero']:06d}: rectifique esa")
        if self.db.q1("SELECT 1 FROM pagos WHERE rectifica_id=? LIMIT 1", (orig["id"],)):
            raise ErrorNegocio("Esta factura tiene devoluciones: no se puede sustituir (haga una devolución si hace falta)")
        nombre = (datos.get("nombre") or "").strip()
        nif = (datos.get("nif") or "").upper().replace(" ", "").replace("-", "").replace(".", "") or None
        direccion = (datos.get("direccion") or "").strip() or None
        email = (datos.get("email") or "").strip() or None
        observ = (datos.get("observaciones") or "").strip()[:300] or None
        if email and not email_valido(email):
            raise ErrorNegocio("El email no es válido")
        if (nif or direccion) and not nombre:
            raise ErrorNegocio("Indique el nombre o razón social del cliente")
        actual = self.db.q1("SELECT nombre, nif, direccion, email, observaciones FROM facturas_destinatario WHERE pago_id=?",
                            (orig["id"],)) or {}
        if ({k: actual.get(k) for k in ("nombre", "nif", "direccion", "email", "observaciones")} ==
                {"nombre": nombre or None, "nif": nif, "direccion": direccion, "email": email, "observaciones": observ}):
            raise ErrorNegocio("Los datos son los mismos: no hay nada que rectificar")
        importe = orig["importe_cent"]
        completo = self._pago_completo(orig["id"])
        lineas_pos = [(d["total"], d["pct"]) for d in completo["desglose_iva"] if d["total"]] or [(importe, float(self.cfg("iva_pct") or 21))]
        serie_r = (self.cfg("serie_rectificativa") or "R").strip().upper()[:4] or "R"
        serie_f = self.cfg("serie_factura") or "A"
        if serie_r == serie_f:
            serie_r += "R"
        with self.db.transaccion() as c:
            r = self._insertar_pago(c, None, usuario, -importe, orig["metodo"], None, None, concepto="rectificativa",
                                    lineas=[(-t, pct) for t, pct in lineas_pos], serie=serie_r)
            c.execute("UPDATE pagos SET rectifica_id=?, motivo=?, rectificacion='sustitucion' WHERE id=?",
                      (orig["id"], motivo[:300], r["id"]))
            dest = c.execute("SELECT * FROM facturas_destinatario WHERE pago_id=?", (orig["id"],)).fetchone()
            if dest:
                cols = [k for k in dest.keys() if k != "pago_id"]
                c.execute(f"INSERT INTO facturas_destinatario(pago_id, {', '.join(cols)}) VALUES(?{', ?' * len(cols)})",
                          (r["id"], *[dest[k] for k in cols]))
            n = self._insertar_pago(c, None, usuario, importe, orig["metodo"], None, None, concepto="sustitutiva",
                                    lineas=lineas_pos, serie=serie_f, referencia=orig.get("referencia"))
            c.execute("UPDATE pagos SET sustituye_id=?, motivo=?, minutos=? WHERE id=?",
                      (orig["id"], motivo[:300], orig["minutos"], n["id"]))
            if nombre:
                c.execute("INSERT INTO facturas_destinatario(pago_id, nombre, nif, direccion, email, cliente_id, fecha, "
                          "usuario_id, observaciones) VALUES(?,?,?,?,?,?,?,?,?)",
                          (n["id"], nombre, nif, direccion, email, (dest["cliente_id"] if dest else None),
                           iso(self.ahora()), usuario["id"], observ))
            self.auditar(c, actor["id"], "factura_rectificar",
                         f"{orig['serie']}-{orig['numero']} → {r['serie']}-{r['numero']} + {n['serie']}-{n['numero']} ({motivo})"
                         + (f" hecha por {usuario['usuario']}" if autorizado_por else ""))
        doc_r, _ = self._doc_de_pago(r["id"])
        doc_n, _ = self._doc_de_pago(n["id"])
        return {"rectificativa": self._pago_completo(r["id"]), "nueva": self._pago_completo(n["id"]),
                "aviso_nif": (f"El NIF/CIF {nif} no parece válido: revíselo." if nif and not nif_valido(nif) else None),
                "impresion": self._imprimir(doc_n, "factura_sustitutiva"),
                "impresion_rectificativa": self._imprimir(doc_r, "rectificativa")}

    def _doc_rectificativa(self, pago, cfg=None):
        cfg = cfg or self._cfg_ticket()
        doc = self._cabecera(self._nuevo_doc(cfg), cfg)
        self._titulo(doc, "FACTURA RECTIFICATIVA")
        f = parse(pago["fecha"])
        doc.alinear("centro").linea(f"Nº {pago['serie']}-{pago['numero']:06d}  ·  {f.strftime('%d/%m/%Y %H:%M')}")
        if pago.get("copia"):
            doc.inverso().linea(" COPIA ").inverso(False)
        doc.alinear("izq").separador()
        dest = pago.get("destinatario")
        if dest:
            doc.negrita().linea("Cliente:").negrita(False)
            doc.lineas(dest["nombre"])
            if dest.get("nif"):
                doc.linea("NIF/CIF: " + dest["nif"])
            doc.separador()
        o = pago["original"]
        doc.par("Rectifica a", f"{o['serie']}-{o['numero']:06d}")
        doc.par("De fecha", parse(o["fecha"]).strftime("%d/%m/%Y %H:%M"))
        doc.par("Importe original", eur(o["importe_cent"]))
        if pago.get("rectificacion") == "sustitucion":
            doc.lineas("Rectificación por sustitución (anula la original; se emite factura nueva)")
        if pago.get("motivo"):
            doc.lineas("Motivo: " + pago["motivo"])
        doc.separador()
        self._bloque_total(doc, pago["importe_cent"], cfg, pago.get("desglose_iva"))
        if pago.get("rectificacion") == "sustitucion":
            doc.separador()
            return doc.cortar()
        doc.par("Devolución", texto_metodo(pago["metodo"]))
        doc.separador()
        doc.alinear("centro").espacio(forzar=True).linea("Firma del cliente:").espacio(2, forzar=True).linea("_" * 24).alinear("izq")
        return doc.cortar()

    def facturas(self, buscar="", limite=200):
        sql = ("SELECT p.id, p.serie, p.numero, p.fecha, p.importe_cent, p.metodo, p.concepto, t.matricula, p.rectifica_id, "
               "(SELECT -COALESCE(SUM(r.importe_cent),0) FROM pagos r WHERE r.rectifica_id=p.id AND r.rectificacion='diferencias') devuelto_cent, "
               "(SELECT s.serie || '-' || printf('%06d', s.numero) FROM pagos s WHERE s.sustituye_id=p.id) sustituida_por, p.rectificacion, "
               "COALESCE(d.nombre, cl.nombre) cliente, d.nombre dest_nombre, d.nif dest_nif, d.email dest_email, "
               "(SELECT estado FROM emails e WHERE e.pago_id=p.id ORDER BY e.id DESC LIMIT 1) email_estado, p.estado_factura "
               "FROM pagos p LEFT JOIN tickets t ON t.id=p.ticket_id LEFT JOIN bonos b ON b.id=p.bono_id "
               "LEFT JOIN clientes cl ON cl.id=b.cliente_id LEFT JOIN facturas_destinatario d ON d.pago_id=p.id")
        params = []
        if buscar:
            b = "%" + buscar.strip() + "%"
            sql += (" WHERE (p.serie || '-' || p.numero) LIKE ? OR t.matricula LIKE ? OR d.nombre LIKE ? "
                    "OR d.nif LIKE ? OR cl.nombre LIKE ? OR CAST(p.numero AS TEXT) = ?")
            params = [b, "%" + (norm_matricula(buscar) or "") + "%", b, b, b, buscar.strip().lstrip("0")]
        filas = self.db.q(sql + " ORDER BY p.id DESC LIMIT ?", params + [int(limite)])
        sp = self.cfg("serie_proveedor") or "P"
        for f in filas:
            f["proveedor"] = f["serie"] == sp and sp != (self.cfg("serie_factura") or "A")
        return filas

    def factura(self, pago_id):
        doc, pago = self._doc_de_pago(pago_id)
        pago["emails"] = self.db.q("SELECT * FROM emails WHERE pago_id=? ORDER BY id DESC", (pago_id,))
        pago["estado_factura"] = (self.db.q1("SELECT estado_factura FROM pagos WHERE id=?", (pago_id,)) or {}).get("estado_factura") or "generada"
        pago["proveedor"] = self.es_factura_proveedor(pago_id)
        pago["devoluciones"] = self.devoluciones_de(pago_id)   # 3.9
        pago["devuelto_cent"] = sum(d["importe_cent"] for d in pago["devoluciones"])
        s = self.db.q1("SELECT id, serie, numero, fecha FROM pagos WHERE sustituye_id=?", (pago_id,))   # 4.0
        pago["sustituida_por"] = s
        pago["vista"] = {"vista_previa": doc.texto(), "elementos": doc.elementos, "ancho": doc.ancho}
        if pago["destinatario"] and pago["destinatario"].get("cliente_id"):
            pago["cliente_guardado"] = self.db.q1("SELECT id, nombre, tipo FROM clientes WHERE id=?",
                                                  (pago["destinatario"]["cliente_id"],))
        # sugerencia: si la estancia o el bono es de un cliente conocido, sus datos
        if not pago["destinatario"]:
            cid = None
            if pago["bono_id"]:
                cid = self.db.q1("SELECT cliente_id FROM bonos WHERE id=?", (pago["bono_id"],))["cliente_id"]
            elif pago["ticket_id"]:
                r = self.db.q1("SELECT cliente_id, matricula FROM tickets WHERE id=?", (pago["ticket_id"],))
                cid = r["cliente_id"] or (self.db.q1("SELECT cliente_id FROM cliente_matriculas WHERE matricula=?",
                                                     (r["matricula"],)) or {}).get("cliente_id")
            if cid:
                c = self.db.q1("SELECT id, nombre, nif, direccion, email, tipo FROM clientes WHERE id=?", (cid,))
                pago["sugerencia"] = c
        return pago

    def guardar_destinatario(self, usuario, pago_id, datos):
        nombre = (datos.get("nombre") or "").strip()
        if not nombre:
            raise ErrorNegocio("Indique el nombre o razón social del cliente")
        nif = (datos.get("nif") or "").upper().replace(" ", "").replace("-", "").replace(".", "") or None
        aviso_nif = (f"El NIF/CIF {nif} no parece válido. Se ha guardado igualmente: revíselo si es un error."
                     if nif and not nif_valido(nif) else None)
        email = (datos.get("email") or "").strip() or None
        if email and not email_valido(email):
            raise ErrorNegocio("El email no es válido")
        direccion = (datos.get("direccion") or "").strip() or None
        pago = self.db.q1("SELECT id, concepto FROM pagos WHERE id=?", (pago_id,))
        if not pago:
            raise ErrorNegocio("Factura no encontrada", 404)
        if pago["concepto"] == "rectificativa":
            raise ErrorNegocio("Los datos de una factura rectificativa no se cambian")
        if self.db.q1("SELECT 1 FROM pagos WHERE sustituye_id=?", (pago_id,)):
            raise ErrorNegocio("Esta factura está sustituida por otra: cambie los datos en la nueva")
        if self.rectificacion_activa():
            # 4.0: con la rectificación en marcha, una factura ya emitida con datos del cliente no se reescribe:
            # se rectifica (rectificativa + factura nueva). Sí se pueden poner datos a una simplificada.
            antes = self.db.q1("SELECT nombre, nif, direccion, observaciones FROM facturas_destinatario WHERE pago_id=?", (pago_id,))
            obs_n = (datos.get("observaciones") or "").strip()[:300] or None
            if antes and (antes["nombre"], antes["nif"], antes["direccion"], antes["observaciones"]) != (nombre, nif, (datos.get("direccion") or "").strip() or None, obs_n):
                raise ErrorNegocio("Esta factura ya se emitió con otros datos del cliente. Para corregirlos use «Rectificar…» "
                                   "(se emite una factura rectificativa y otra nueva con los datos correctos).", 409)
        cliente_id = datos.get("cliente_id") or None
        with self.db.transaccion() as c:
            if datos.get("guardar_cliente"):
                cliente_id = self._cliente_de_factura(c, usuario, pago_id, cliente_id, nombre, nif, direccion, email)
            observ = (datos.get("observaciones") or "").strip()[:300] or None
            c.execute("INSERT INTO facturas_destinatario(pago_id, nombre, nif, direccion, email, cliente_id, fecha, usuario_id, "
                      "observaciones) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(pago_id) DO UPDATE SET nombre=excluded.nombre, "
                      "nif=excluded.nif, direccion=excluded.direccion, email=excluded.email, "
                      "cliente_id=excluded.cliente_id, fecha=excluded.fecha, usuario_id=excluded.usuario_id, "
                      "observaciones=excluded.observaciones",
                      (pago_id, nombre, nif, direccion, email, cliente_id, iso(self.ahora()),
                       usuario["id"], observ))
            self.auditar(c, usuario["id"], "factura_datos", f"pago={pago_id} {nombre} {nif or ''}"
                         + (" (NIF no válido)" if aviso_nif else ""))
        f = self.factura(pago_id)
        f["aviso"] = aviso_nif
        return f

    def _cliente_de_factura(self, c, usuario, pago_id, cliente_id, nombre, nif, direccion, email):
        """Guarda los datos de facturación en Clientes para reutilizarlos.
        Si ya existe (elegido en la lista o con el mismo NIF) se actualiza; si no, se crea
        como «cliente de facturación» (distinto de los abonados) con la matrícula del ticket."""
        if cliente_id:
            r = c.execute("SELECT nif FROM clientes WHERE id=?", (cliente_id,)).fetchone()
            if not r or (nif and r[0] and r[0] != nif):  # otro NIF = otra persona o empresa
                cliente_id = None
        if not cliente_id and nif:
            r = c.execute("SELECT id FROM clientes WHERE nif=? ORDER BY tipo='abonado' DESC, id LIMIT 1", (nif,)).fetchone()
            cliente_id = r[0] if r else None
        if cliente_id:
            c.execute("UPDATE clientes SET nombre=?, nif=COALESCE(?, nif), direccion=COALESCE(?, direccion), "
                      "email=COALESCE(?, email) WHERE id=?", (nombre, nif, direccion, email, cliente_id))
            accion = "actualizado"
        else:
            cliente_id = c.execute("INSERT INTO clientes(nombre, nif, email, direccion, activo, creado, tipo) "
                                   "VALUES(?,?,?,?,1,?, 'facturacion')",
                                   (nombre, nif, email, direccion, iso(self.ahora()))).lastrowid
            c.execute("UPDATE clientes SET codigo=? WHERE id=?", (self._codigo(cliente_id, "CL"), cliente_id))
            accion = "creado"
        # La matrícula de la estancia se asocia al cliente (si no es de otro) para que la
        # próxima vez sus datos salgan solos en la factura.
        r = c.execute("SELECT t.matricula FROM pagos p JOIN tickets t ON t.id=p.ticket_id WHERE p.id=?",
                      (pago_id,)).fetchone()
        if r and r[0] and not c.execute("SELECT 1 FROM cliente_matriculas WHERE matricula=?", (r[0],)).fetchone():
            c.execute("INSERT INTO cliente_matriculas(cliente_id, matricula) VALUES(?,?)", (cliente_id, r[0]))
        self.auditar(c, usuario["id"], "cliente_desde_factura", f"id={cliente_id} {nombre} ({accion})")
        return cliente_id

    def factura_vista(self, pago_id, dest):
        """Vista previa de la factura con unos datos de cliente aún sin guardar."""
        doc_pago = self._pago_completo(pago_id)
        nombre = (dest.get("nombre") or "").strip()
        doc_pago["destinatario"] = {"nombre": nombre, "nif": (dest.get("nif") or "").upper().replace(" ", ""),
                                    "direccion": (dest.get("direccion") or "").strip()} if nombre else None
        if doc_pago["bono_id"]:
            bono = self.db.q1("SELECT b.*, p.nombre plan_nombre FROM bonos b JOIN planes_bono p ON p.id=b.plan_id "
                              "WHERE b.id=?", (doc_pago["bono_id"],))
            doc = self._doc_recibo_bono(self.cliente(bono["cliente_id"]), bono, doc_pago)
        elif doc_pago["concepto"] == "venta":
            doc = self._doc_recibo_venta(doc_pago)
        else:
            doc = self._doc_recibo(self.ticket(doc_pago["ticket_id"]), doc_pago, None)
        return {"vista_previa": doc.texto(), "elementos": doc.elementos, "ancho": doc.ancho}

    def mensaje_factura(self, pago_id):
        """Asunto y texto del email (para abrirlo en Gmail o en el programa de correo)."""
        pago = self._pago_completo(pago_id)
        cfg = self.db.config()
        datos = {"numero": f"{pago['serie']}-{pago['numero']:06d}", "parking": cfg.get("nombre_parking", ""),
                 "nombre": (pago["destinatario"] or {}).get("nombre") or "cliente"}
        return {"asunto": _plantilla(cfg.get("email_asunto") or "Factura {numero}", datos),
                "texto": _plantilla(cfg.get("email_texto") or "", datos),
                "email": (pago["destinatario"] or {}).get("email") or "",
                "pdf": f"factura_{datos['numero']}.pdf"}

    def eml_factura(self, pago_id, destino=""):
        """Borrador de correo (.eml) con el PDF adjunto: al abrirlo, Outlook lo muestra listo para enviar."""
        from email.message import EmailMessage
        m = self.mensaje_factura(pago_id)
        pdf, nombre = self.pdf_factura(pago_id)
        msg = EmailMessage()
        msg["X-Unsent"] = "1"  # Outlook lo abre como mensaje nuevo editable
        msg["To"] = destino or m["email"]
        msg["Subject"] = m["asunto"]
        msg.set_content(m["texto"])
        msg.add_attachment(pdf, maintype="application", subtype="pdf", filename=nombre)
        return msg.as_bytes(), nombre[:-4] + ".eml"

    ESTADOS_FACTURA = ("generada", "enviada", "cobrada")

    def es_factura_proveedor(self, pago_id):
        r = self.db.q1("SELECT serie FROM pagos WHERE id=?", (pago_id,))
        sp = self.cfg("serie_proveedor") or "P"
        return bool(r) and r["serie"] == sp and sp != (self.cfg("serie_factura") or "A")

    def cambiar_estado_factura(self, usuario, pago_id, estado):
        """4.64: estado de la factura a mano: generada, enviada o cobrada."""
        if estado not in self.ESTADOS_FACTURA:
            raise ErrorNegocio("Estado de factura no válido")
        with self.db.transaccion() as c:
            r = c.execute("SELECT serie, numero, estado_factura FROM pagos WHERE id=?", (pago_id,)).fetchone()
            if not r:
                raise ErrorNegocio("Factura no encontrada", 404)
            c.execute("UPDATE pagos SET estado_factura=? WHERE id=?", (estado, pago_id))
            self.auditar(c, usuario["id"], "factura_estado", f"{r[0]}-{r[1]} {r[2]} -> {estado}")
        return {"estado_factura": estado}

    def _marcar_enviada(self, pago_id):
        """Al enviar la factura, si seguía «generada» pasa a «enviada» (si ya estaba cobrada, se queda así)."""
        self.db.ex("UPDATE pagos SET estado_factura='enviada' WHERE id=? AND estado_factura='generada'", (pago_id,))

    def registrar_envio_externo(self, usuario, pago_id, destino, medio):
        with self.db.transaccion() as c:
            self.auditar(c, usuario["id"], "factura_email_" + medio, f"pago={pago_id} -> {destino or '-'}")
        self._marcar_enviada(pago_id)

    def imprimir_factura(self, usuario, pago_id):
        if self.es_factura_proveedor(pago_id):   # 4.64: a un proveedor solo se le da factura A4 (imprimir, guardar o enviar)
            raise ErrorNegocio("Las facturas a proveedor no se imprimen en ticket: use A4, descargue el PDF o envíela por email")
        doc, pago = self._doc_de_pago(pago_id, copia=True)
        with self.db.transaccion() as c:
            self.auditar(c, usuario["id"], "factura_imprimir", f"{pago['serie']}-{pago['numero']}")
        return self._imprimir(doc, "factura")

    def pdf_factura(self, pago_id):
        """Factura A4 en PDF (tipografía Poppins), con los datos del cliente si los tiene."""
        from .pdf import factura_a_pdf
        datos = self.datos_pdf_factura(pago_id)
        return factura_a_pdf(datos), f"factura_{datos['numero']}.pdf"

    def datos_pdf_factura(self, pago_id):
        from . import VERSION_COMPLETA
        from .pdf import color_hex
        pago = self._pago_completo(pago_id)
        cfg = self.db.config()
        iva_gen = float(cfg.get("iva_pct") or 21)
        numero = f"{pago['serie']}-{pago['numero']:06d}"
        dest = pago["destinatario"]
        detalles, lineas = [], []
        if pago["bono_id"]:
            b = self.db.q1("SELECT b.*, p.nombre plan_nombre, c.nombre cliente_nombre FROM bonos b "
                           "JOIN planes_bono p ON p.id=b.plan_id JOIN clientes c ON c.id=b.cliente_id WHERE b.id=?",
                           (pago["bono_id"],))
            mats = [v["matricula"] for v in self.vehiculos_cliente(b["cliente_id"])]
            detalles += [("Abonado", b["cliente_nombre"])] + ([("Matrículas", ", ".join(mats))] if mats else [])
            parcial = self._parcial_bono(b, pago)
            lineas.append({"concepto": f"Bono {b['plan_nombre']}" + (" · pago parcial" if parcial else ""),
                           "detalle": f"Bono nº {self.numero_bono(b['numero'])} · "
                           f"del {fecha_es(b['desde'])} al {fecha_es(b['hasta'])}"
                           + (f" · importe del bono {eur(parcial['total_cent'])}, pendiente {eur(parcial['pendiente_cent'])}"
                              if parcial else ""), "cantidad": 1, "precio": pago["importe_cent"], "iva": iva_gen,
                           "importe": pago["importe_cent"]})
        elif pago["concepto"] == "rectificativa":
            o = pago["original"]
            detalles += [("Rectifica a", f"{o['serie']}-{o['numero']:06d} del {parse(o['fecha']).strftime('%d/%m/%Y %H:%M')}"),
                         ("Importe original", eur(o["importe_cent"]))]
            if pago.get("rectificacion") == "sustitucion":
                detalles.append(("Tipo", "Por sustitución (se emite factura nueva)"))
            if pago.get("motivo"):
                detalles.append(("Motivo", pago["motivo"]))
            for d in pago["desglose_iva"]:
                lineas.append({"concepto": "Devolución", "detalle": f"IVA {d['pct']:g} %", "cantidad": 1,
                               "precio": d["total"], "iva": d["pct"], "importe": d["total"]})
        elif pago["concepto"] == "venta":
            detalles.append(("Venta", "Tienda"))
            for e in pago["lineas_extra"]:
                lineas.append({"concepto": e["nombre"], "cantidad": e["cantidad"], "precio": e["precio_cent"],
                               "iva": e["iva_pct"], "importe": e["precio_cent"] * e["cantidad"],
                               "detalle": e.get("descripcion")})
        else:
            tk = self.ticket(pago["ticket_id"])
            if tk.get("matricula"):
                v = self.db.q1("SELECT marca, modelo FROM cliente_matriculas WHERE matricula=?", (tk["matricula"],))
                extra = " ".join(x for x in ((v or {}).get("marca"), (v or {}).get("modelo")) if x)
                detalles.append(("Matrícula", tk["matricula"] + (f"  ({extra})" if extra else "")))
            detalles.append(("Ticket", tk["codigo"] + ("  · manual" if tk.get("manual") else "")))
            detalles.append(("Entrada", parse(tk["entrada"]).strftime("%d/%m/%Y %H:%M")))
            if tk.get("salida"):
                detalles.append(("Salida", parse(tk["salida"]).strftime("%d/%m/%Y %H:%M")))
            detalles.append(("Tiempo", texto_duracion(pago["minutos"])))
            if tk.get("reserva_hasta"):   # 4.2
                detalles.append(("Reserva hasta", parse(tk["reserva_hasta"]).strftime("%d/%m/%Y %H:%M")
                                 + (f"  (nº {tk['reserva_ref']})" if tk.get("reserva_ref") else "")))
            estancia = pago["importe_cent"] - (pago["extras_cent"] or 0) - pago["recargo_cent"] + (pago.get("descuento_cent") or 0)
            if estancia or not pago["lineas_extra"]:
                det = f"{texto_duracion(pago['minutos'])} · tarifa {tk['tarifa_nombre']}"
                if tk.get("reserva_hasta"):
                    fin_r = parse(tk["reserva_hasta"])
                    det = (f"Tiempo fuera de la reserva (hasta el {fin_r.strftime('%d/%m %H:%M')}) · " if tk.get("reserva_desde") else f"Tiempo después de la reserva (desde el {fin_r.strftime('%d/%m %H:%M')}) · "
                           f"tarifa {self.tarifa(tk['reserva_tarifa_id'])['nombre'] if tk.get('reserva_tarifa_id') else tk['tarifa_nombre']}")
                if pago.get("minutos_incluidos"):
                    det += f" · {texto_duracion(pago['minutos_incluidos'])} incluidos en servicios"
                lineas.append({"concepto": "Estacionamiento", "detalle": det, "cantidad": 1, "precio": estancia,
                               "iva": iva_gen, "importe": estancia})
            if pago["recargo_cent"]:
                lineas.append({"concepto": "Recargo por ticket perdido", "cantidad": 1, "precio": pago["recargo_cent"],
                               "iva": iva_gen, "importe": pago["recargo_cent"]})
            for e in pago["lineas_extra"]:
                lineas.append({"concepto": e["nombre"], "cantidad": e["cantidad"], "precio": e["precio_cent"],
                               "iva": e["iva_pct"], "importe": e["precio_cent"] * e["cantidad"],
                               "detalle": " · ".join(x for x in (
                                   e.get("descripcion"),
                                   f"Incluye {texto_duracion(e['minutos_incluidos'] * e['cantidad'])} de parking"
                                   if e.get("minutos_incluidos") else None) if x) or None})
        if pago.get("descuento_cent") and not pago["bono_id"]:
            d = pago["descuento_cent"]
            lineas.append({"concepto": f"Descuento: {pago.get('descuento_nombre') or ''}".rstrip(": "), "cantidad": 1,
                           "precio": -d, "iva": iva_gen, "importe": -d})
        if pago.get("sustituye"):
            o = pago["sustituye"]
            detalles.insert(0, ("Sustituye a", f"{o['serie']}-{o['numero']:06d} del {parse(o['fecha']).strftime('%d/%m/%Y')}"))
        if cfg.get("factura_mostrar_detalle") == "0":   # 4.2: sin el recuadro de detalle (salvo lo que exige la ley)
            detalles = [d for d in detalles if d[0] in ("Sustituye a", "Rectifica a", "Importe original", "Tipo", "Motivo")]
        alto_logo = {"pequeno": 40, "mediano": 62, "grande": 90}.get(cfg.get("factura_logo_tam") or "mediano", 62)
        datos = {
            "empresa": {"nombre": cfg.get("nombre_parking", ""), "razon_social": cfg.get("razon_social"),
                        "nif": cfg.get("nif"), "direccion": cfg.get("direccion"), "telefono": cfg.get("telefono"),
                        "email": cfg.get("empresa_email"), "web": (cfg.get("empresa_web") or "").replace("https://", "").replace("http://", "")},
            "estilo": {"acento": color_hex(cfg.get("factura_color")) if cfg.get("factura_color") else None,
                       "cabecera_tabla": color_hex(cfg.get("factura_cabecera_tabla")) if cfg.get("factura_cabecera_tabla") else None,
                       "logo_alto": alto_logo},
            "notas": (cfg.get("factura_notas") or "").strip() or None,
            "titulo": ("DEMOSTRACIÓN · SIN VALIDEZ · " if self.demo else "") + (
                "FACTURA RECTIFICATIVA" if pago["concepto"] == "rectificativa" else
                (cfg.get("factura_titulo_completa") or "FACTURA") if dest else
                (cfg.get("factura_titulo_simplificada") or cfg.get("recibo_titulo") or "FACTURA SIMPLIFICADA")),
            "numero": numero, "fecha": parse(pago["fecha"]).strftime("%d/%m/%Y  %H:%M"),
            "cliente": dest, "detalles": detalles, "lineas": lineas, "desglose": pago["desglose_iva"],
            "total": pago["importe_cent"],
            "pago": {"metodo": texto_metodo(pago["metodo"]) + (f" · ref. {pago['referencia']}" if pago.get("referencia") else ""),
                     "entregado": pago["entregado_cent"],
                     "cambio": pago["cambio_cent"]},
            "pie": cfg.get("factura_pie") if cfg.get("factura_pie") is not None and cfg.get("factura_pie") != "" else cfg.get("recibo_pie", ""),
            "marca": VERSION_COMPLETA,
            "logo": logos.jpeg(self.carpeta_logo) if cfg.get("logo_factura") == "1" else None,
            "sello": logos.jpeg_sello(self.carpeta_logo) if cfg.get("sello_factura", "1") != "0" else None,
            "verifactu": self._qr_verifactu(pago_id),
        }
        plt = self.plantilla("factura")   # 4.9
        if plt:
            datos = self._aplicar_plantilla_a4(datos, plt)
        return datos

    def enviar_factura(self, usuario, pago_id, destino=None):
        """Encola el envío y lo intenta en el momento. Si no hay conexión queda pendiente."""
        pago = self._pago_completo(pago_id)
        destino = (destino or (pago["destinatario"] or {}).get("email") or "").strip()
        if not email_valido(destino):
            raise ErrorNegocio("Indique un email válido")
        if not self.cfg("smtp_servidor"):
            raise ErrorNegocio("Configure primero el servidor de correo en Ajustes → Email", 409)
        with self.db.transaccion() as c:
            eid = c.execute("INSERT INTO emails(pago_id, destino, creado, usuario_id) VALUES(?,?,?,?)",
                            (pago_id, destino, iso(self.ahora()), usuario["id"])).lastrowid
            self.auditar(c, usuario["id"], "factura_email", f"{pago['serie']}-{pago['numero']} -> {destino}")
        return self._procesar_email(eid)

    def _procesar_email(self, eid):
        e = self.db.q1("SELECT * FROM emails WHERE id=?", (eid,))
        try:
            pdf, nombre = self.pdf_factura(e["pago_id"])
            pago = self._pago_completo(e["pago_id"])
            cfg = self.db.config()
            numero = f"{pago['serie']}-{pago['numero']:06d}"
            datos = {"numero": numero, "parking": cfg.get("nombre_parking", ""),
                     "nombre": (pago["destinatario"] or {}).get("nombre") or "cliente"}
            asunto = _plantilla(cfg.get("email_asunto") or "Factura {numero}", datos)
            cuerpo = _plantilla(cfg.get("email_texto") or "", datos)
            from .correo import enviar
            enviar(cfg, e["destino"], asunto, cuerpo, [(nombre, pdf, "application/pdf")])
            self.db.ex("UPDATE emails SET estado='enviado', intentos=intentos+1, enviado=?, ultimo_error=NULL WHERE id=?",
                       (iso(self.ahora()), eid))
            self._marcar_enviada(e["pago_id"])
        except Exception as ex:  # sin conexión, servidor caído, credenciales... queda pendiente
            self.db.ex("UPDATE emails SET estado=CASE WHEN intentos+1>=20 THEN 'error' ELSE 'pendiente' END, "
                       "intentos=intentos+1, ultimo_error=? WHERE id=?", (str(ex)[:300], eid))
        return self.db.q1("SELECT * FROM emails WHERE id=?", (eid,))

    def reintentar_emails(self):
        pend = self.db.q("SELECT id FROM emails WHERE estado='pendiente' ORDER BY id")
        res = [self._procesar_email(p["id"]) for p in pend]
        self.reintentar_emails_reservas()   # 1.10: confirmaciones de reservas que no se pudieron enviar
        return res

    def probar_email(self, destino):
        if not email_valido(destino or ""):
            raise ErrorNegocio("Indique un email válido")
        from .correo import enviar
        cfg = self.db.config()
        try:
            enviar(cfg, destino, f"Prueba de correo - {cfg.get('nombre_parking', '')}",
                   "Si recibe este mensaje, el envío de facturas por email funciona.", [])
        except Exception as ex:
            raise ErrorNegocio(f"No se pudo enviar: {ex}")
        return {"ok": True}

    # ============================================================ numeración
    def numeracion(self):
        serie = self.cfg("serie_factura") or "A"
        ult_f = self.db.q1("SELECT MAX(numero) n FROM pagos WHERE serie=?", (serie,))["n"] or 0
        ult_t = self.db.q1("SELECT MAX(numero) n FROM tickets")["n"] or 0
        ult_b = self.db.q1("SELECT MAX(numero) n FROM bonos")["n"] or 0
        sig = lambda ult, k: max(ult + 1, int(self.cfg(k) or 1))  # noqa: E731
        serie_p = self.cfg("serie_proveedor") or "P"
        ult_p = self.db.q1("SELECT MAX(numero) n FROM pagos WHERE serie=?", (serie_p,))["n"] or 0
        return {"factura": {"serie": serie, "ultimo": ult_f, "siguiente": sig(ult_f, "factura_numero_inicial")},
                "proveedor": {"serie": serie_p, "ultimo": ult_p, "siguiente": sig(ult_p, "factura_proveedor_numero_inicial")},
                "rectificativa": {"serie": (self.cfg("serie_rectificativa") or "R").strip().upper()[:4] or "R"},
                "ticket": {"prefijo": self.cfg("ticket_prefijo") or "PK", "ultimo": ult_t,
                           "siguiente": sig(ult_t, "ticket_numero_inicial")},
                "bono": {"prefijo": self.cfg("bono_prefijo") or "B", "ultimo": ult_b,
                         "siguiente": sig(ult_b, "bono_numero_inicial")},
                "registro_integridad": self.cfg("registro_integridad") == "1"}

    def guardar_numeracion(self, actor_id, d):
        def entero(k, minimo, maximo, nombre):
            try:
                v = int(d.get(k))
            except (TypeError, ValueError):
                raise ErrorNegocio(f"{nombre}: número no válido")
            if not minimo <= v <= maximo:
                raise ErrorNegocio(f"{nombre}: el siguiente número debe estar entre {minimo} y {maximo}"
                                   + (f" (ya existen hasta el {minimo - 1})" if minimo > 1 else ""))
            return v
        serie = (d.get("factura_serie") or "").strip().upper()
        if not re.fullmatch(r"[A-Z0-9]{1,5}", serie):
            raise ErrorNegocio("Serie de facturas: de 1 a 5 letras o números (p. ej. A, T, 2026)")
        if serie == (self.cfg("serie_rectificativa") or "R").strip().upper():
            raise ErrorNegocio(f"La serie de las facturas ({serie}) es la misma que la de las rectificativas: elija otra distinta")
        ult_f = self.db.q1("SELECT MAX(numero) n FROM pagos WHERE serie=?", (serie,))["n"] or 0
        n_f = entero("factura_siguiente", ult_f + 1, 99_999_999, f"Facturas serie {serie}")
        serie_p = (d.get("proveedor_serie") or self.cfg("serie_proveedor") or "P").strip().upper()
        if not re.fullmatch(r"[A-Z0-9]{1,5}", serie_p):
            raise ErrorNegocio("Serie de facturas a proveedores: de 1 a 5 letras o números (p. ej. P, PR)")
        if serie_p in (serie, (self.cfg("serie_rectificativa") or "R").upper()):
            raise ErrorNegocio("La serie de las facturas a proveedores debe ser distinta de la de las facturas normales y las rectificativas")
        ult_p = self.db.q1("SELECT MAX(numero) n FROM pagos WHERE serie=?", (serie_p,))["n"] or 0
        n_p = entero("proveedor_siguiente", ult_p + 1, 99_999_999, f"Facturas a proveedores serie {serie_p}") \
            if d.get("proveedor_siguiente") not in (None, "") else max(ult_p + 1, int(self.cfg("factura_proveedor_numero_inicial") or 1))
        pre_t = (d.get("ticket_prefijo") or "").strip().upper()
        if not re.fullmatch(r"[A-Z]{1,3}", pre_t) or pre_t == "CL":
            raise ErrorNegocio("Prefijo de tickets: de 1 a 3 letras (sin acentos ni Ñ) y distinto de CL (tarjetas de abonado)")
        ult_t = self.db.q1("SELECT MAX(numero) n FROM tickets")["n"] or 0
        n_t = entero("ticket_siguiente", ult_t + 1, 9_999_999, "Tickets")
        pre_b = (d.get("bono_prefijo") or "").strip().upper()
        if not re.fullmatch(r"[A-Z0-9-]{1,5}", pre_b):
            raise ErrorNegocio("Prefijo de bonos: de 1 a 5 letras o números")
        ult_b = self.db.q1("SELECT MAX(numero) n FROM bonos")["n"] or 0
        n_b = entero("bono_siguiente", ult_b + 1, 99_999_999, "Bonos")
        integridad = "1" if d.get("registro_integridad") in (True, 1, "1") else "0"
        with self.db.transaccion() as c:
            for k, v in (("serie_factura", serie), ("factura_numero_inicial", n_f), ("serie_proveedor", serie_p),
                         ("factura_proveedor_numero_inicial", n_p), ("ticket_prefijo", pre_t),
                         ("ticket_numero_inicial", n_t), ("bono_prefijo", pre_b), ("bono_numero_inicial", n_b),
                         ("registro_integridad", integridad)):
                c.execute("INSERT INTO config(clave, valor) VALUES(?,?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor",
                          (k, str(v)))
            self.auditar(c, actor_id, "numeracion_guardar",
                         f"facturas {serie}-{n_f} · tickets {pre_t}{n_t} · bonos {pre_b}{n_b} · registro encadenado "
                         f"{'activado' if integridad == '1' else 'desactivado'}")
        return self.numeracion()

    # ============================================================ 4.58 · facturas a proveedores
    def proveedores(self):
        filas = self.db.q("SELECT id, nombre, nif, direccion, email, telefono FROM clientes WHERE proveedor=1 AND activo=1 "
                          "ORDER BY nombre COLLATE NOCASE")
        for f in filas:
            f["servicios"] = self.servicios_de_proveedor(f["id"])
        return filas

    def servicios_proveedor(self):
        iva_gen = float(self.cfg("iva_pct") or 21)
        filas = self.db.q("SELECT id, nombre, tipo, precio_cent, iva_pct, descripcion FROM productos "
                          "WHERE solo_proveedor=1 AND activo=1 AND eliminado=0 ORDER BY orden, nombre COLLATE NOCASE")
        for f in filas:
            f["iva_efectivo"] = f["iva_pct"] if f["iva_pct"] is not None else iva_gen
        return filas

    def facturar_proveedor(self, usuario, cliente_id, lineas, metodo=None, entregado_cent=None, referencia=None,
                           observaciones=None):
        """Factura completa a un proveedor por sus servicios específicos. Serie y numeración propias; nunca lleva bonos."""
        self._exigir_licencia()
        serie = (self.cfg("serie_proveedor") or "P").strip()[:6] or "P"
        if serie == (self.cfg("serie_factura") or "A") or serie == (self.cfg("serie_rectificativa") or "R"):
            raise ErrorNegocio("La serie de proveedores debe ser distinta de la de las facturas normales y de las rectificativas "
                               "(Ajustes → Empresa y cobro)")
        cli = self.db.q1("SELECT * FROM clientes WHERE id=? AND proveedor=1 AND activo=1", (cliente_id,))
        if not cli:
            raise ErrorNegocio("Elija un proveedor (se marca en la ficha del cliente)", 404)
        propios = {x["producto_id"]: x for x in self.servicios_de_proveedor(cliente_id)}
        for x in lineas or []:
            try:
                if int(x.get("producto_id")) not in propios:
                    raise ErrorNegocio("Ese servicio no está asignado a este proveedor: añádalo en su ficha (Editar datos)")
            except (TypeError, ValueError):
                raise ErrorNegocio("Servicio no válido")
        lineas = [dict(x, precio_cent=propios[int(x["producto_id"])]["precio_cent"]) for x in lineas or []]   # 4.62: vale aunque el servicio sea de precio variable
        if len(lineas) > 1:
            raise ErrorNegocio("Cada factura a proveedor lleva un solo servicio")
        ls = self._extras_manual(lineas, proveedor=True)
        if not ls:
            raise ErrorNegocio("Elija el servicio que se factura al proveedor")
        for l in ls:   # precio personalizado de este proveedor
            l["precio_cent"] = propios[l["producto_id"]]["precio_cent"]
        importe = sum(l["precio_cent"] * l["cantidad"] for l in ls)
        if importe <= 0:
            raise ErrorNegocio("El total de la factura es 0")
        # 1.1: las facturas a proveedor se pagan siempre por transferencia (no necesitan caja abierta); «Cobrada» se marca a mano
        metodo = "transferencia"
        referencia = self._metodo_bono("transferencia", referencia)
        turno = self.turno_de(usuario)
        entregado = cambio = None
        obs = (observaciones or "").strip()[:300] or None
        with self.db.transaccion() as c:
            pago = self._insertar_pago(c, turno, usuario, importe, metodo, entregado, cambio, extras=importe,
                                       lineas=[(l["precio_cent"] * l["cantidad"], l["iva_pct"]) for l in ls], concepto="venta",
                                       referencia=referencia, serie=serie)
            for l in ls:
                c.execute("INSERT INTO ventas_lineas(pago_id, producto_id, nombre, tipo, descripcion, precio_cent, cantidad, "
                          "iva_pct) VALUES(?,?,?,?,?,?,?,?)", (pago["id"], l["producto_id"], l["nombre"], l["tipo"],
                                                               l["descripcion"], l["precio_cent"], l["cantidad"], l["iva_pct"]))
            c.execute("INSERT INTO facturas_destinatario(pago_id, nombre, nif, direccion, email, cliente_id, fecha, usuario_id, "
                      "observaciones) VALUES(?,?,?,?,?,?,?,?,?)",
                      (pago["id"], cli["nombre"], cli["nif"], cli["direccion"], cli["email"], cli["id"], iso(self.ahora()),
                       usuario["id"], obs))
            self.auditar(c, usuario["id"], "factura_proveedor", f"{serie}-{pago['numero']} {cli['nombre']} {importe} {metodo} · "
                         + ", ".join(f"{l['cantidad']}x{l['nombre']}" for l in ls))
        return self.factura(pago["id"])

    @staticmethod
    def _lineas_iva_con_descuento(ls, desc_cent):
        """Reparte un descuento entre las líneas en proporción a su importe (para el desglose de IVA)."""
        bruto = sum(l["precio_cent"] * l["cantidad"] for l in ls) or 1
        lineas, quedan = [], desc_cent
        for i, l in enumerate(ls):
            sub = l["precio_cent"] * l["cantidad"]
            parte = quedan if i == len(ls) - 1 else round(desc_cent * sub / bruto)
            quedan -= parte
            lineas.append((sub - parte, l["iva_pct"]))
        return lineas

    def _doc_recibo_venta(self, pago, cfg=None):
        cfg = cfg or self._cfg_ticket()
        plt = self.plantilla("recibo")
        if plt:
            return self._doc_plantilla(plt, self._datos_recibo(None, pago, None, cfg, venta=True), cfg)
        doc = self._cabecera(self._nuevo_doc(cfg), cfg)
        self._cabecera_factura(doc, pago, cfg)
        for e in pago.get("lineas_extra") or []:
            nombre = (f"{e['cantidad']} x " if e["cantidad"] > 1 else "") + e["nombre"]
            doc.par(nombre, eur(e["precio_cent"] * e["cantidad"]))
            if e["cantidad"] > 1:
                doc.linea(f"   ({eur(e['precio_cent'])} / ud.)")
            if e.get("descripcion"):
                for l in _partir_txt(e["descripcion"], doc.ancho - 3):
                    doc.linea("   " + l)
        if pago.get("descuento_cent"):
            doc.par(f"Descuento {pago.get('descuento_nombre') or ''}".strip(), "-" + eur(pago["descuento_cent"]))
        doc.separador()
        self._bloque_total(doc, pago["importe_cent"], cfg, pago.get("desglose_iva"))
        self._bloque_pago(doc, pago, cfg).separador()
        self._pie_verifactu(doc, pago)
        doc.alinear("centro").espacio().lineas(cfg.get("recibo_pie", "")).alinear("izq")
        self._sello_ticket(doc, cfg)
        return doc.cortar()
