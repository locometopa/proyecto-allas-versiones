"""PROYECTO ALLAS · rutas de la API: arranque, ajustes, copias de seguridad, actualizaciones, licencia, demostración y datos de la instalación (se registran desde server.App._registrar)."""
import json
import os
import re
import shutil
import time
from . import NOMBRE
from . import __version__
from . import backup as copias
from . import errores
from .backup import hacer_backup
from .demo import USUARIOS_DEMO
from .servicios import ErrorNegocio
from .servicios import ROLES_SUPERVISION
from datetime import datetime


def registrar(app, r, p):
    from .server import CLAVE_OCULTA, CONFIG_EDITABLE, Respuesta, SESION_HORAS, ips_locales


    @r("GET", "/api/ping", publica=True)
    def ping(req):
        """4.27: la pantalla de carga (web/cargando.html, abierta como archivo) pregunta aquí si el servidor ya responde."""
        return Respuesta(json.dumps({"ok": True, "software": NOMBRE, "version": __version__}).encode(), "application/json",
                         {"Access-Control-Allow-Origin": "*", "Cache-Control": "no-store"})

    def version_nueva(u):
        """1.9.3: versión más reciente que la instalada (la deja la búsqueda automática de actualizaciones); solo para administradores."""
        if not u or u.get("rol") != "admin":
            return None
        try:
            nuevo = json.loads(p.cfg("actualizacion_aviso") or "null")
            if nuevo and act.version_tupla(str(nuevo["version"])) > act.version_tupla(__version__):
                return str(nuevo["version"])
        except Exception as e_:  # noqa: BLE001
            errores.fallo("server.version_nueva", e_)
        return None

    @r("GET", "/api/estado", publica=True)
    def estado(req):
        u = req.usuario
        cfg = p.db.config()
        return {"usuario": u, "primer_arranque": not p.hay_usuarios(),
                "demo": app.demo, "demo_disponible": bool(app.carpeta_base),
                "demo_usuarios": [{"usuario": x[1], "nombre": x[0], "pin": x[2], "rol": x[3]} for x in USUARIOS_DEMO]
                if app.demo else None,
                "turno": p.turno_de(u) if u else None,
                "turnos_abiertos": p.turnos_abiertos() if u else None,
                "ocupacion": p.ocupacion() if u else None,
                "nombre_parking": cfg["nombre_parking"],
                "software": NOMBRE, "version": __version__, "actualizacion_nueva": version_nueva(u),
                "salida_al_cobrar": cfg.get("salida_al_cobrar", "1") != "0",
                "imprimir_salida": cfg.get("ticket_salida_imprimir", "0") == "1",
                "llaves_mostrar": cfg.get("ticket_llaves_mostrar", "1") != "0",
                "llaves_defecto": cfg.get("ticket_llaves_defecto", "1") != "0",
                "email_metodo": cfg.get("email_metodo") or "gmail_web",
                "arqueo_defecto": cfg.get("arqueo_defecto", "1") != "0",
                "entrada_ajuste_max_min": int(cfg.get("entrada_ajuste_max_min") or 0),
                "tema": cfg.get("tema") or "claro",
                "pantalla_inicio": cfg.get("pantalla_inicio") or "entrada",
                "pagos_online": p.activo("pagos_online_activo", "pagos_online"),
                "ticket_perdido": cfg.get("ticket_perdido_activo", "1") != "0",
                "transferencia": cfg.get("transferencia_activa", "1") != "0",
                "registro_integridad": cfg.get("registro_integridad") == "1",
                "lpr": p.activo("lpr_activo", "madrid360"),
                "lpr_salida_accion": cfg.get("lpr_salida_accion") or "sugerir",
                "m360": p.activo("m360_activo", "madrid360"),
                "m360_luz": p.m360_luz(),
                "mensajes": p.msg_modo(),
                "verifactu": p.activo("verifactu_activo", "verifactu"),
                "descuentos": p.descuentos_activos(),
                "pantalla_cliente": p.activo("pantalla_cliente_activa", "pantalla_cliente"),
                "pantalla_cliente_modo": p.modo_pantalla_cliente(),
                "arqueo": p.config_arqueo(),
                "recordatorios": p.recordatorios_activos(),
                "vehiculo_fotos": cfg.get("vehiculo_fotos_activo", "1") != "0",
                "movil_red": cfg.get("movil_red") == "1",
                "barrera": p.activo("barrera_activa", "perifericos"),
                "datafono": p.activo("datafono_activo", "perifericos"),
                "devoluciones": p.devoluciones_activas(),
                "rectificacion": p.rectificacion_activa(),
                "confirmar_cierre": cfg.get("confirmar_cierre", "1") != "0",
                "modo_tactil": cfg.get("modo_tactil") or "auto",
                "color_acento": cfg.get("color_acento") or "azul",
                "zonas": p.zonas() if u else [],
                "tipos_vehiculo": [x.strip() for x in (cfg.get("tipos_vehiculo") or "Coche,Moto,Furgoneta,Autocaravana").split(",") if x.strip()]
                if cfg.get("tipos_vehiculo_activo") == "1" and p.tiene_modulo("tarifas_avanzadas") else [],
                "ticket_digital": cfg.get("ticket_digital_activo") == "1" and p.tiene_modulo("gestion"),
                "estado_vehiculo": cfg.get("estado_vehiculo_activo") == "1" and p.tiene_modulo("gestion"),
                "pago_movil": p.pago_movil_activo() if u else False,
                "reservas_online": bool(u) and p.reservas_online_activas(),
                "reservas_nuevas": p.n_reservas_por_revisar() if u and p.tiene_modulo("gestion") and p.reservas_online_activas()
                and "reservas" in p.permisos_de(u) else 0,
                "permisos": sorted(p.permisos_de(u)) if u else [],
                "ocultos": p.ocultos() if u else [],
                "ui_recargar": (cfg.get("ui_recargar") or "") if u else "",
                "a4": (cfg.get("a4_modo") or "") if u else "",
                "diseno": cfg.get("diseno") or "clasico",
                "lista_negra_modo": "bloquear" if cfg.get("lista_negra_modo") == "bloquear" else "avisar",
                "apps_externas": ([{k: a[k] for k in ("id", "nombre", "tipo", "icono", "color")}
                                   | ({"url": a["destino"]} if a["tipo"] == "web" else {})
                                   for a in p.apps_externas(u)] if u and p.tiene_modulo("gestion") else []),
                "licencia_tipo": (tipo_lic := p.tipo_licencia_info())[0], "licencia_color": tipo_lic[1],
                "modulos": p.modulos_activos() if u else None,
                "licencia": ({k: lic.get(k) for k in ("estado", "mensaje", "puede_operar", "dias_restantes",
                                                      "titular", "caduca", "estado_comprobacion")}
                             if u and (lic := p.estado_licencia()) else None),
                "ticket_entrada_copias": int(cfg.get("ticket_entrada_copias") or 1),
                "ahora": p.ahora().isoformat(timespec="seconds")}

    @r("POST", "/api/setup", publica=True)
    def setup(req):
        if p.hay_usuarios():
            raise ErrorNegocio("El sistema ya está configurado", 409)
        b = req.body
        uid = p.crear_usuario(b.get("nombre") or "Administrador", b.get("usuario") or "admin",
                              b.get("pin"), "admin")
        if not p.tarifas():
            p.guardar_tarifa({"nombre": "General", "gracia_min": 5, "maximo_diario_cent": 2000,
                              "por_defecto": True,
                              "tramos": [{"desde_min": 0, "hasta_min": None, "fraccion_min": 1,
                                          "precio_mil": 45}]}, uid)
        for k in ("nombre_parking", "razon_social", "nif", "direccion"):
            if b.get(k):
                p.db.set_cfg(k, b[k])
        u = p.autenticar(b.get("usuario") or "admin", b.get("pin"))
        return {"token": app.crear_sesion(u), "usuario": u}

    # --- primer arranque: empezar desde una copia de seguridad (2.5). Solo funciona mientras
    # no exista ningún usuario; en cuanto hay uno, estas rutas quedan bloqueadas.
    def _solo_sin_usuarios():
        if p.hay_usuarios():
            raise ErrorNegocio("El sistema ya está configurado", 409)

    def _copia_util(info):
        return info.get("usuarios", 0) > 0

    @r("GET", "/api/setup/copias", publica=True)
    def setup_copias(req):
        _solo_sin_usuarios()
        salida = []
        for c in copias.listar(app.backups):
            try:
                info = copias.validar(copias.ruta_segura(app.backups, c["archivo"]))
            except (ValueError, FileNotFoundError):
                continue
            if _copia_util(info):   # las copias del programa vacío no sirven para empezar
                salida.append({"archivo": c["archivo"], "fecha": c["fecha"], "tipo": c["tipo"], "tamano": c["tamano"],
                               "tickets": info["tickets"], "pagos": info["pagos"], "clientes": info["clientes"],
                               "usuarios": info["usuarios"], "ultimo_cobro": info["ultimo_cobro"]})
        return salida

    @r("POST", "/api/setup/subir", publica=True, crudo=True)
    def setup_subir(req):
        _solo_sin_usuarios()
        try:
            info = copias.guardar_subida(app.backups, req.raw)
        except ValueError as e:
            raise ErrorNegocio(str(e))
        if not _copia_util(info):
            try:
                os.remove(os.path.join(app.backups, info["archivo"]))
            except OSError:
                pass
            raise ErrorNegocio("Esta copia no contiene usuarios, así que no sirve para empezar. Elija una copia completa "
                               "o empiece de cero y restáurela después desde Ajustes.")
        return {k: info[k] for k in ("archivo", "tickets", "pagos", "clientes", "usuarios", "ultimo_cobro")}

    @r("POST", "/api/setup/restaurar", publica=True)
    def setup_restaurar(req):
        _solo_sin_usuarios()
        archivo = req.body.get("archivo", "")
        try:
            if not _copia_util(copias.validar(copias.ruta_segura(app.backups, archivo))):
                raise ValueError("Esta copia no contiene usuarios, así que no sirve para empezar.")
            res = copias.restaurar(p.db, app.backups, archivo, "primer arranque",
                                   int(p.cfg("backups_mantener") or 30), carpeta_logo=p.carpeta_logo)
        except (ValueError, FileNotFoundError) as e:
            raise ErrorNegocio(str(e))
        app.cerrar_todas_las_sesiones()
        return {**res, "nombre_parking": p.cfg("nombre_parking")}

    # --- 3.5: recordatorios, mensajes y avisos (icono 🔔)
    @r("GET", "/api/recordatorios")
    def recordatorios(req):
        if not p.recordatorios_activos():
            return {"activo": False, "pendientes": [], "sistema": [], "total": 0}
        pend = p.recordatorios_pendientes(req.usuario)
        sis = p.avisos_sistema(req.usuario, app.backups)
        return {"activo": True, "pendientes": pend, "sistema": sis, "total": len(pend) + len(sis)}

    @r("GET", "/api/recordatorios/todos")
    def recordatorios_todos(req):
        return {"recordatorios": p.recordatorios_lista(req.usuario),
                "usuarios": [{"id": u["id"], "nombre": u["nombre"], "rol": u["rol"]} for u in p.usuarios() if u["activo"]]}

    @r("POST", "/api/recordatorios")
    def recordatorio_nuevo(req):
        return p.guardar_recordatorio(req.usuario, req.body)

    @r("PUT", r"/api/recordatorios/(\d+)")
    def recordatorio_editar(req, rid):
        return p.guardar_recordatorio(req.usuario, req.body, int(rid))

    @r("DELETE", r"/api/recordatorios/(\d+)")
    def recordatorio_borrar(req, rid):
        return p.borrar_recordatorio(req.usuario, int(rid))

    @r("POST", r"/api/recordatorios/(\d+)/leido")
    def recordatorio_leido(req, rid):
        return p.leer_recordatorio(req.usuario, int(rid))

    @r("POST", r"/api/recordatorios/(\d+)/hecho")
    def recordatorio_hecho(req, rid):
        return p.hecho_recordatorio(req.usuario, int(rid), req.body.get("hecho", True) is not False)

    # --- 3.5: caja móvil / tablet (acceso desde la red local)
    @r("GET", "/api/movil/info", rol=("admin",))
    def movil_info(req):
        from .codigos import qr_svg
        ips = ips_locales()
        puerto = getattr(app, "puerto", None) or 8080
        urls = [f"http://{ip}:{puerto}/movil.html" for ip in ips]
        escuchando = getattr(app, "host", "127.0.0.1") not in ("127.0.0.1", "localhost")
        return {"activo": p.cfg("movil_red") == "1", "escuchando_red": escuchando,
                "turno_compartido": p.cfg("movil_turno_compartido") != "0", "ips": ips, "puerto": puerto,
                "urls": urls, "qr": qr_svg(urls[0], modulo=6) if urls else None,
                "reiniciar": (p.cfg("movil_red") == "1") != escuchando}

    # --- 3.4: modo demostración (datos de ejemplo en otra carpeta; los reales no se tocan)
    @r("POST", "/api/demo/activar", publica=True)
    def demo_activar(req):
        from . import demo
        if not app.carpeta_base:
            raise ErrorNegocio("El modo demostración solo está disponible al arrancar con ARRANCAR.bat (run.py)", 409)
        if app.demo and not req.body.get("regenerar"):
            raise ErrorNegocio("Ya está en el modo demostración", 409)
        if p.hay_usuarios() and not app.demo:
            # con datos reales: solo un administrador, con su PIN
            if not req.usuario or req.usuario["rol"] != "admin":
                raise ErrorNegocio("Solo un administrador puede activar la demostración", 403)
            app._comprobar_pin(req)
        try:
            demo.limpiar_opciones(req.body.get("opciones"))
        except ValueError as e:
            raise ErrorNegocio(str(e), 400)
        resumen = demo.preparar(app.carpeta_base, regenerar=bool(req.body.get("regenerar")),
                                opciones=req.body.get("opciones"))
        app.programar_reinicio(0.8)
        return {"ok": True, "resumen": resumen}

    @r("POST", "/api/demo/salir", publica=True)
    def demo_salir(req):
        from . import demo
        if not app.demo or not app.carpeta_base:
            raise ErrorNegocio("No está en el modo demostración", 409)
        demo.salir(app.carpeta_base)
        app.programar_reinicio(0.8)
        return {"ok": True}

    # --- copia cifrada en la nube
    @r("POST", "/api/nube/probar", rol=("admin",))
    def nube_probar(req):
        from . import nube
        ruta = hacer_backup(p.db, app.backups, int(p.cfg("backups_mantener") or 30), p.cfg("backup_destino_extra"),
                            tipo="manual", usuario=req.usuario["usuario"])
        try:
            hecho = nube.subir(p.db.config(), ruta)
        except nube.ErrorNube as e:
            p.db.set_cfg("nube_ultimo_error", str(e))
            raise ErrorNegocio(str(e))
        p.db.set_cfg("nube_ultimo", f"{p.ahora().isoformat(timespec='seconds')} {hecho}")
        p.db.set_cfg("nube_ultimo_error", "")
        return {"ok": True, "hecho": hecho}

    @r("GET", "/api/nube/estado", rol=("admin",))
    def nube_estado(req):
        return {"ultimo": p.cfg("nube_ultimo"), "error": p.cfg("nube_ultimo_error") or None,
                "clave": bool(p.cfg("nube_clave"))}

    @r("POST", "/api/nube/descifrar", rol=("admin",), crudo=True)
    def nube_descifrar(req):
        """Sube una copia cifrada (.allas-cifrada) con su contraseña: queda en la lista de copias para restaurarla."""
        from . import nube
        try:
            from urllib.parse import unquote
            datos = nube.descifrar(req.raw, unquote(req.clave_nube or ""))
            return copias.guardar_subida(app.backups, datos)
        except (nube.ErrorNube, ValueError) as e:
            raise ErrorNegocio(str(e))

    # --- pago desde el móvil del cliente (rutas públicas)
    @r("GET", "/api/publico/ticket", publica=True)
    def publico_ticket(req):
        return p.info_publica_ticket(req.query.get("c", ""))

    @r("POST", "/api/publico/pagar", publica=True)
    def publico_pagar(req):
        return p.crear_pago_movil(req.body.get("c", ""))

    @r("POST", "/api/publico/confirmar", publica=True)
    def publico_confirmar(req):
        ses = str(req.body.get("s") or "")
        if not re.fullmatch(r"cs_[A-Za-z0-9_]{6,200}", ses):
            raise ErrorNegocio("Pago no válido")
        r = p.confirmar_pago_movil(ses)
        return {"estado": r.get("estado"), "salida_limite": r.get("salida_limite")}

    # --- 4.1: aplicaciones externas (menú lateral)
    @r("GET", "/api/apps")
    def apps(req):
        return p.apps_externas(req.usuario)

    @r("GET", "/api/apps/todas", rol=("admin",))
    def apps_todas(req):
        return p.apps_externas(todas=True)

    @r("POST", "/api/apps", rol=("admin",))
    def app_nueva(req):
        return p.guardar_app_externa(req.usuario["id"], req.body)

    @r("PUT", r"/api/apps/(\d+)", rol=("admin",))
    def app_editar(req, aid):
        return p.guardar_app_externa(req.usuario["id"], req.body, int(aid))

    @r("DELETE", r"/api/apps/(\d+)", rol=("admin",))
    def app_borrar(req, aid):
        return p.borrar_app_externa(req.usuario["id"], int(aid))

    @r("POST", r"/api/apps/(\d+)/abrir")
    def app_abrir(req, aid):
        return p.abrir_app_externa(req.usuario, int(aid))

    # --- 4.1: Acerca de (copyright, licencia y datos del fabricante)
    @r("GET", "/api/acerca")
    def acerca(req):
        return p.acerca_de(req.usuario)

    @r("POST", "/api/acerca/fabricante", rol=("admin",))
    def acerca_fabricante(req):
        return p.guardar_fabricante(req.usuario["id"], req.body.get("texto") or "", "manual")

    @r("POST", "/api/preferencias/imprimir-salida")
    def pref_imprimir_salida(req):
        return p.guardar_imprimir_salida(req.usuario, bool(req.body.get("activo")))

    @r("POST", "/api/backups/probar-destino", rol=("admin",))
    def probar_destino(req):
        ruta = (req.body.get("ruta") or "").strip()
        if not ruta:
            raise ErrorNegocio("Escriba la carpeta")
        if not os.path.isdir(ruta):
            raise ErrorNegocio("No se encuentra esa carpeta: compruebe la ruta y que el NAS esté encendido y conectado")
        prueba = os.path.join(ruta, ".prueba_proyecto_allas")
        try:
            with open(prueba, "w") as f:
                f.write("ok")
            os.remove(prueba)
        except OSError as e:
            raise ErrorNegocio(f"La carpeta existe pero no se puede escribir en ella: {e}")
        return {"ok": True}

    # --- exportar / importar tarifas y servicios
    @r("GET", "/api/config/exportar", rol=("admin",))
    def config_exportar(req):
        datos = p.exportar_config()
        nombre = "tarifas_servicios_" + p.ahora().strftime("%Y%m%d-%H%M") + ".json"
        cuerpo = json.dumps(datos, ensure_ascii=False, indent=2).encode()
        return Respuesta(cuerpo, "application/json; charset=utf-8",
                         {"Content-Disposition": f'attachment; filename="{nombre}"'})

    @r("POST", "/api/config/importar", rol=("admin",))
    def config_importar(req):
        b = req.body
        que = b.get("que") or ["tarifas", "productos"]
        if not b.get("aplicar"):
            return p.importar_config(b.get("datos"), req.usuario["id"], b.get("modo", "combinar"), False, que)
        # comprobar primero (sin tocar nada) y, si es válido, copia de seguridad antes de aplicar
        p.importar_config(b.get("datos"), req.usuario["id"], b.get("modo", "combinar"), False, que)
        hacer_backup(p.db, app.backups, int(p.cfg("backups_mantener") or 30), p.cfg("backup_destino_extra"),
                     tipo="antes_de_importar", usuario=req.usuario["usuario"])
        return p.importar_config(b.get("datos"), req.usuario["id"], b.get("modo", "combinar"), True, que)

    # --- licencia
    @r("GET", "/api/licencia")
    def licencia(req):
        from .licencia import MODULOS, PLANES
        e = p.estado_licencia()
        if req.usuario["rol"] != "admin":
            e.pop("serial", None)
        e["catalogo"] = {"modulos": MODULOS, "planes": PLANES}   # para listar lo contratado y lo que no
        plan = None if p.demo else p.plan_supervision()
        if plan:   # 4.8: tipo de licencia reducido desde Supervisión
            e["limitada"] = {"plan": plan, "nombre": PLANES[plan]["nombre"], "modulos": p.modulos_activos()}
        return e

    @r("POST", "/api/licencia", rol=("admin",))
    def licencia_activar(req):
        return p.activar_licencia(req.usuario["id"], req.body.get("serial"))

    @r("POST", "/api/licencia/comprobar", rol=("admin",))
    def licencia_comprobar(req):
        return p.comprobar_licencia_online(req.usuario["id"])

    @r("POST", "/api/licencia/validacion", rol=("admin",))
    def licencia_validacion(req):
        return p.validar_codigo_licencia(req.usuario["id"], req.body.get("codigo"))

    @r("DELETE", "/api/licencia", rol=("admin",))
    def licencia_quitar(req):
        return p.quitar_licencia(req.usuario["id"])

    # --- actualizaciones (paquetes firmados, sin Internet)
    from . import actualizacion as act
    from .licencia_clave import CLAVE_PUBLICA
    clave_pub = bytes.fromhex(CLAVE_PUBLICA)
    carpeta_paquetes = os.path.join(app.raiz, "actualizaciones")
    carpeta_versiones = os.path.join(p.carpeta_datos, "versiones")

    def anteriores_instaladas():
        """4.25: versiones que se instalaron como actualización en este equipo (según la auditoría), sin la actual,
            con sus novedades del CHANGELOG y la fecha en que se instalaron."""
        historial = {h["version"]: h for h in act.historial_versiones(app.raiz, __version__, desde_historial())}
        salida = {}
        for f in p.db.q("SELECT fecha, detalle FROM auditoria WHERE accion='actualizacion_instalar' ORDER BY id"):
            nueva = (f["detalle"] or "").split("->")[-1].strip()
            if nueva and nueva != __version__ and nueva in historial:
                h = historial[nueva]
                salida[nueva] = {"version": nueva, "fecha": h["fecha"], "notas": h["notas"], "instalada": str(f["fecha"])[:10]}
        return sorted(salida.values(), key=lambda x: act.version_tupla(x["version"]), reverse=True)

    def desde_historial(todo=False):
        """1.13: primera versión que se muestra en el historial: la de la primera instalación, o la que se fijó al «Limpiar historial»."""
        c = [x for x in (p.cfg("version_inicial"), None if todo else p.cfg("actualizaciones_historial_desde")) if x]
        try:
            return max(c, key=act.version_tupla) if c else None
        except act.ErrorActualizacion:
            return p.cfg("version_inicial") or None

    def paquetes_estado():
        """Paquetes de la carpeta con su estado (instalada / anterior / disponible) y si se pueden instalar."""
        paquetes = act.paquetes_en_carpeta(carpeta_paquetes, clave_pub, __version__)
        for pq in paquetes:
            try:
                pq["tamano"] = os.path.getsize(os.path.join(carpeta_paquetes, pq["archivo"]))
            except OSError:
                pq["tamano"] = 0
            if "error" not in pq:
                v, hoy = act.version_tupla(pq["version"]), act.version_tupla(__version__)
                pq["estado"] = "instalada" if v == hoy else "anterior" if v < hoy else "disponible"   # 4.16: disponibles / ya instalados
                try:
                    act.comprobar(pq, __version__, p.estado_licencia())
                    pq["instalable"] = True
                except act.ErrorActualizacion as e:
                    pq["instalable"], pq["motivo"] = False, str(e)
            pq["limpiar"] = act.motivo_limpieza(pq)
        return paquetes

    @r("GET", "/api/actualizaciones", rol=("admin",))
    def actualizaciones(req):
        from . import FECHA_VERSION
        paquetes = paquetes_estado()
        guardadas = act.versiones_guardadas(carpeta_versiones)
        for g in guardadas:
            g["tamano"] = act.tamano_carpeta(os.path.join(carpeta_versiones, str(g["version"])))
        return {"version": __version__, "fecha_version": FECHA_VERSION, "paquetes": paquetes,
                "guardadas": guardadas, "carpeta": carpeta_paquetes,
                "historial": act.historial_versiones(app.raiz, __version__, desde_historial()),
                "historial_limpio": desde_historial() != desde_historial(True),
                "historial_total": len(act.historial_versiones(app.raiz, __version__, desde_historial(True))),
                "anteriores": anteriores_instaladas()}

    @r("POST", "/api/actualizaciones/limpiar", rol=("admin",))
    def actualizaciones_limpiar(req):
        """1.13: limpieza de actualizaciones. paquetes: «inutiles» (no válidos, ya instalados, anteriores o que no se pueden instalar),
        «todos» (también los pendientes de instalar) o una lista de nombres; copias: borra las copias de versiones anteriores;
        historial: «limpiar» (oculta lo anterior a la versión actual) o «restaurar». No toca la auditoría ni el programa instalado."""
        b = req.body
        quitar, borrados, liberado = b.get("paquetes"), 0, 0
        paquetes = {pq["archivo"]: pq for pq in paquetes_estado()}
        if quitar == "inutiles":
            elegidos = [n for n, pq in paquetes.items() if pq["limpiar"]]
        elif quitar == "todos":
            elegidos = list(paquetes)
        elif isinstance(quitar, list):
            elegidos = [os.path.basename(str(n)) for n in quitar if os.path.basename(str(n)) in paquetes]
        elif not quitar:
            elegidos = []
        else:
            raise ErrorNegocio("Indique qué paquetes limpiar")
        for n in elegidos:
            try:
                os.remove(os.path.join(carpeta_paquetes, n))
                borrados += 1
                liberado += paquetes[n]["tamano"]
            except OSError as e:
                errores.fallo("server.actualizaciones_limpiar", e)
        copias = 0
        if b.get("copias"):
            for g in act.versiones_guardadas(carpeta_versiones):
                d = os.path.join(carpeta_versiones, str(g["version"]))
                liberado += act.tamano_carpeta(d)
                shutil.rmtree(d, ignore_errors=True)
                copias += 1
        if b.get("historial") == "limpiar":
            p.db.set_cfg("actualizaciones_historial_desde", __version__)
        elif b.get("historial") == "restaurar":
            p.db.set_cfg("actualizaciones_historial_desde", "")
        if not (borrados or copias or b.get("historial")):
            raise ErrorNegocio("No hay nada que limpiar")
        with p.db.transaccion() as c:
            p.auditar(c, req.usuario["id"], "actualizacion_limpiar",
                      f"paquetes {borrados}, copias {copias}" + (f", historial {b['historial']}" if b.get("historial") else ""))
        return {"ok": True, "paquetes": borrados, "copias": copias, "liberado": liberado}

    @r("GET", "/api/actualizaciones/historial.txt", rol=("admin",))
    def actualizaciones_historial_txt(req):
        """4.62: historial completo de versiones como archivo de texto."""
        return Respuesta(act.texto_historial(app.raiz, __version__, desde_historial()).encode("utf-8"), "text/plain; charset=utf-8",
                         {"Content-Disposition": f'attachment; filename="historial_actualizaciones_{__version__}.txt"'})

    @r("POST", "/api/actualizaciones/subir", rol=("admin",), crudo=True)
    def actualizacion_subir(req):
        try:
            m, _ = act.leer_paquete(req.raw, clave_pub)
        except act.ErrorActualizacion as e:
            raise ErrorNegocio(str(e))
        os.makedirs(carpeta_paquetes, exist_ok=True)
        nombre = f"PROYECTO_ALLAS_actualizacion_{m['version']}.zip"
        with open(os.path.join(carpeta_paquetes, nombre), "wb") as f:
            f.write(req.raw)
        return {"archivo": nombre, "version": m["version"], "fecha": m["fecha"], "notas": m.get("notas", "")}

    # --- 4.0: actualizaciones online (experimental): las publica el Gestor de licencias del distribuidor
    def url_actualizaciones():
        url = (p.cfg("actualizaciones_url") or p.cfg("licencia_servidor") or "").strip()
        if not url and p.cfg("licencia_serial"):
            try:
                from .licencia import leer
                url = leer(p.cfg("licencia_serial"), clave_pub).get("url") or ""
            except Exception:  # noqa: BLE001
                url = ""
        url = url.rstrip("/")
        if url and not url.startswith(("http://", "https://")):
            url = "http://" + url
        return url

    def pedir(url, timeout=15):
        import urllib.request
        req = urllib.request.Request(url, headers={"User-Agent": f"PROYECTO-ALLAS/{__version__}"})
        return urllib.request.urlopen(req, timeout=timeout)

    def origen_actualizaciones():
        o = p.cfg("actualizaciones_origen")
        if o in ("github", "drive", "servidor"):
            return o
        return "servidor" if url_actualizaciones() else "github"

    def lista_online():
        """Consulta el servicio de actualizaciones (según el origen configurado). Devuelve (url, origen, lista)."""
        import urllib.error
        from . import drive, github_releases as gh
        origen = origen_actualizaciones()
        if origen == "github":
            try:
                lista = gh.listar(p.cfg("actualizaciones_github_repo") or "")
            except gh.ErrorGitHub as e:
                raise ErrorNegocio(str(e))
            url = "github"
        elif origen == "drive":
            try:
                lista = drive.listar(p.cfg("actualizaciones_drive_carpeta") or "", p.cfg("actualizaciones_drive_clave") or "")
            except drive.ErrorDrive as e:
                raise ErrorNegocio(str(e))
            url = "online"
        else:
            url = url_actualizaciones()
            if not url:
                raise ErrorNegocio("El servicio de actualizaciones no está configurado. Avise a su distribuidor.")
            try:
                with pedir(url + "/actualizaciones") as r:
                    lista = json.loads(r.read() or b"[]")
            except urllib.error.HTTPError as e:
                raise ErrorNegocio(f"El servicio de actualizaciones responde con error {e.code}"
                                   + (" (no publica actualizaciones)" if e.code == 404 else ""))
            except (urllib.error.URLError, OSError, ValueError) as e:
                raise ErrorNegocio(f"No se puede conectar con el servicio de actualizaciones: {getattr(e, 'reason', e)}")
        return url, origen, lista

    def comprobar_actualizacion_auto(forzar=False):
        """4.24: al arrancar y una vez al día busca una versión nueva y la deja como aviso en las notificaciones.
            Devuelve la versión nueva (str) o None. Nunca lanza: sin Internet simplemente no avisa."""
        try:
            if p.cfg("actualizaciones_auto") == "0" or p.oculto("actualizaciones_online"):
                return None
            ult = p.cfg("actualizaciones_ultima_comprobacion") or ""
            if not forzar and ult and (datetime.now() - datetime.fromisoformat(ult)).total_seconds() < 23 * 3600:
                return None
            _, _, lista = lista_online()
            actual = act.version_tupla(__version__)
            nuevas = []
            for x in lista if isinstance(lista, list) else []:
                try:
                    if act.version_tupla(str(x.get("version"))) > actual:
                        nuevas.append(x)
                except act.ErrorActualizacion:
                    continue
            nuevas.sort(key=lambda x: act.version_tupla(str(x["version"])), reverse=True)
            p.db.set_cfg("actualizaciones_ultima_comprobacion", datetime.now().isoformat(timespec="seconds"))
            p.db.set_cfg("actualizacion_aviso", json.dumps({"version": str(nuevas[0]["version"]), "fecha": nuevas[0].get("fecha")}) if nuevas else "")
            return str(nuevas[0]["version"]) if nuevas else None
        except Exception as e_:  # noqa: BLE001
            errores.fallo("server.comprobar_actualizacion_auto", e_)
            return None
    app.comprobar_actualizacion_auto = comprobar_actualizacion_auto

    cache_notas = {}   # 4.42: (id del archivo, versión) → novedades leídas del paquete

    @r("GET", "/api/actualizaciones/online", rol=("admin",))
    def actualizaciones_online(req):
        if p.oculto("actualizaciones_online"):
            raise ErrorNegocio("La búsqueda de actualizaciones online está desactivada (Sistema → Supervisión)", 403)
        url, origen, lista = lista_online()
        actual = act.version_tupla(__version__)
        ya = set(os.listdir(carpeta_paquetes)) if os.path.isdir(carpeta_paquetes) else set()
        salida = []
        for x in lista if isinstance(lista, list) else []:
            try:
                v = act.version_tupla(str(x.get("version")))
            except act.ErrorActualizacion:
                continue
            salida.append({"version": x.get("version"), "fecha": x.get("fecha"), "notas": x.get("notas") or "",
                           "archivo": os.path.basename(str(x.get("archivo") or "")), "tamano": x.get("tamano"), "id": x.get("id"),
                           "sha256": x.get("sha256"), "nueva": v > actual, "instalada": v == actual,
                           "descargada": bool({os.path.basename(str(x.get("archivo") or "")), f"PROYECTO_ALLAS_actualizacion_{x.get('version')}.zip"} & ya)})
        salida.sort(key=lambda x: act.version_tupla(x["version"]), reverse=True)
        nuevas = [x for x in salida if x["nueva"]]
        if nuevas and nuevas[0]["descargada"]:   # 4.29: con el paquete en el equipo, las novedades salen de su CHANGELOG (todas las versiones nuevas)
            for pq in act.paquetes_en_carpeta(carpeta_paquetes, clave_pub, __version__):
                if pq.get("version") == nuevas[0]["version"] and pq.get("cambios"):
                    nuevas[0]["cambios"] = pq["cambios"]
        if nuevas and not nuevas[0]["descargada"] and not nuevas[0].get("cambios") and not (nuevas[0]["notas"] or "").strip():
            # 4.42: el listado de Drive no trae notas: se leen del CHANGELOG del paquete (se descarga en memoria, solo para mostrarlas)
            n0 = nuevas[0]
            clave_c = (n0.get("id") or n0["archivo"], n0["version"])
            if clave_c not in cache_notas:
                try:
                    if origen in ("drive", "github"):
                        import io, zipfile
                        from . import drive, github_releases as gh
                        if origen == "github":
                            datos = gh.descargar(p.cfg("actualizaciones_github_repo") or "", n0.get("id") or "", act.MAX_PAQUETE)
                        else:
                            datos = drive.descargar(n0.get("id") or "", p.cfg("actualizaciones_drive_clave") or "", act.MAX_PAQUETE)
                        with zipfile.ZipFile(io.BytesIO(datos)) as z:
                            cache_notas[clave_c] = act.cambios_desde(z, __version__, n0["version"])
                    else:
                        cache_notas[clave_c] = ""
                except Exception:  # noqa: BLE001
                    cache_notas[clave_c] = ""
            if cache_notas[clave_c]:
                n0["cambios"] = cache_notas[clave_c]
        try:   # 4.24: una búsqueda a mano también actualiza el aviso de las notificaciones
            p.db.set_cfg("actualizaciones_ultima_comprobacion", datetime.now().isoformat(timespec="seconds"))
            p.db.set_cfg("actualizacion_aviso", json.dumps({"version": str(nuevas[0]["version"]), "fecha": nuevas[0].get("fecha")}) if nuevas else "")
        except Exception as e_:  # noqa: BLE001
            errores.fallo("server.actualizaciones_online", e_)
        return {"url": url, "origen": origen, "version": __version__, "paquetes": salida}

    @r("POST", "/api/actualizaciones/online/descargar", rol=("admin",))
    def actualizacion_descargar(req):
        import hashlib as _h
        import urllib.error
        from . import drive, github_releases as gh
        origen = origen_actualizaciones()
        nombre = os.path.basename(req.body.get("archivo") or "")
        if origen == "github":
            url = "github"
            try:
                datos = gh.descargar(p.cfg("actualizaciones_github_repo") or "", req.body.get("id") or "", act.MAX_PAQUETE)
            except gh.ErrorGitHub as e:
                raise ErrorNegocio(str(e))
        elif origen == "drive":
            url = "online"
            try:
                datos = drive.descargar(req.body.get("id") or "", p.cfg("actualizaciones_drive_clave") or "", act.MAX_PAQUETE)
            except drive.ErrorDrive as e:
                raise ErrorNegocio(str(e))
        else:
            url = url_actualizaciones()
            if not url or not nombre.endswith(".zip"):
                raise ErrorNegocio("Paquete no válido")
            try:
                with pedir(url + "/actualizaciones/" + nombre, timeout=120) as r:
                    datos = r.read(act.MAX_PAQUETE + 1)
            except (urllib.error.URLError, OSError) as e:
                raise ErrorNegocio(f"No se pudo descargar: {getattr(e, 'reason', e)}")
        if len(datos) > act.MAX_PAQUETE:
            raise ErrorNegocio("El paquete es demasiado grande")
        esperado = (req.body.get("sha256") or "").lower()
        if esperado and _h.sha256(datos).hexdigest() != esperado:
            raise ErrorNegocio("El paquete descargado está dañado (no coincide su huella). Vuelva a intentarlo.")
        try:
            m, _ = act.leer_paquete(datos, clave_pub)   # firma del fabricante: si no, no se guarda
        except act.ErrorActualizacion as e:
            raise ErrorNegocio("El paquete descargado no es válido: " + str(e))
        os.makedirs(carpeta_paquetes, exist_ok=True)
        destino = f"PROYECTO_ALLAS_actualizacion_{m['version']}.zip"
        with open(os.path.join(carpeta_paquetes, destino), "wb") as f:
            f.write(datos)
        with p.db.transaccion() as c:
            p.auditar(c, req.usuario["id"], "actualizacion_descargar", f"{m['version']} desde {url}")
        return {"archivo": destino, "version": m["version"]}

    @r("POST", "/api/actualizaciones/instalar", rol=("admin",))
    def actualizacion_instalar(req):
        nombre = os.path.basename(req.body.get("archivo") or "")
        ruta = os.path.join(carpeta_paquetes, nombre)
        if not nombre.endswith(".zip") or not os.path.isfile(ruta):
            raise ErrorNegocio("Paquete no encontrado", 404)
        with open(ruta, "rb") as f:
            datos = f.read()
        try:
            m, _ = act.leer_paquete(datos, clave_pub)
            ant = False   # 4.23: no se permite instalar versiones anteriores
            act.comprobar(m, __version__, p.estado_licencia(), ant)
        except act.ErrorActualizacion as e:
            raise ErrorNegocio(str(e))
        hacer_backup(p.db, app.backups, int(p.cfg("backups_mantener") or 30), p.cfg("backup_destino_extra"),
                     tipo="antes_de_actualizar", usuario=req.usuario["usuario"])
        try:
            m = act.instalar(app.raiz, datos, clave_pub, __version__, p.estado_licencia(), carpeta_versiones, ant)
        except act.ErrorActualizacion as e:
            raise ErrorNegocio(str(e))
        with p.db.transaccion() as c:
            p.auditar(c, req.usuario["id"], "actualizacion_instalar", f"{__version__} -> {m['version']}")
        app.programar_reinicio()
        return {"ok": True, "version": m["version"], "anterior": __version__, "reinicio": bool(app.srv)}

    @r("POST", "/api/actualizaciones/volver", rol=("admin",))
    def actualizacion_volver(req):
        raise ErrorNegocio("Volver a una versión anterior no está permitido desde el programa. Consulte a su distribuidor.", 403)
        v = str(req.body.get("version") or "")
        try:
            act.version_tupla(v)
            act.volver_a(app.raiz, carpeta_versiones, v, __version__)
        except act.ErrorActualizacion as e:
            raise ErrorNegocio(str(e))
        with p.db.transaccion() as c:
            p.auditar(c, req.usuario["id"], "actualizacion_volver", f"{__version__} -> {v}")
        app.programar_reinicio()
        return {"ok": True, "version": v, "reinicio": bool(app.srv)}

    # --- logo de la empresa
    @r("GET", "/api/logo")
    def logo_info(req):
        from . import logo as logos
        return logos.info(p.carpeta_logo) or {}

    @r("POST", "/api/logo", rol=("admin",))
    def logo_subir(req):
        b = req.body
        return p.guardar_logo(req.usuario["id"], b.get("jpeg"), b.get("ancho"), b.get("alto"), b.get("bits"))

    @r("DELETE", "/api/logo", rol=("admin",))
    def logo_borrar(req):
        return p.borrar_logo(req.usuario["id"])

    @r("GET", r"/api/logo/(ticket\.png|logo\.jpg)", publica=True)
    def logo_archivo(req, nombre):
        ruta = os.path.join(p.carpeta_logo, "logo_ticket.png" if nombre == "ticket.png" else "logo.jpg")
        if not os.path.isfile(ruta):
            raise ErrorNegocio("No hay logo", 404)
        with open(ruta, "rb") as f:
            return Respuesta(f.read(), "image/png" if nombre.endswith("png") else "image/jpeg",
                             {"Cache-Control": "no-cache"})

    # --- configuración y sistema
    @r("GET", "/api/config", rol=("admin",))
    def config(req):
        cfg = {k: v for k, v in p.db.config().items() if k in CONFIG_EDITABLE}
        for secreto in ("smtp_clave", "twilio_token", "nube_clave", "nube_webdav_clave", "actualizaciones_drive_clave"):
            if cfg.get(secreto):
                cfg[secreto] = CLAVE_OCULTA  # las contraseñas nunca salen del servidor
        return cfg

    @r("PUT", "/api/config", rol=("admin",))
    def config_guardar(req):
        cambios = {k: str(v) for k, v in req.body.items() if k in CONFIG_EDITABLE
                   and not (k in ("smtp_clave", "twilio_token", "nube_clave", "nube_webdav_clave", "actualizaciones_drive_clave") and v == CLAVE_OCULTA)}
        if cambios.get("m360_activo") == "1" and p.cfg("m360_activo") != "1":
            cambios["m360_desde"] = p.ahora().date().isoformat()   # desde cuándo hay que comunicar listados
        with p.db.transaccion() as c:
            for k, v in cambios.items():
                c.execute("INSERT INTO config(clave, valor) VALUES(?,?) "
                          "ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor", (k, v))
            p.auditar(c, req.usuario["id"], "config", ", ".join(
                f"{k}={'***' if k in ('smtp_clave', 'twilio_token', 'nube_clave', 'nube_webdav_clave', 'actualizaciones_drive_clave') else v}" for k, v in cambios.items()))
        return {"ok": True}

    @r("POST", "/api/impresora/prueba", rol=ROLES_SUPERVISION)
    def prueba(req):
        return p.prueba_impresora()

    @r("POST", "/api/backup", rol=ROLES_SUPERVISION)
    def backup(req):
        contenido = req.body.get("contenido") if isinstance(req.body, dict) else None
        try:
            ruta = hacer_backup(p.db, app.backups, int(p.cfg("backups_mantener") or 30),
                                p.cfg("backup_destino_extra"), tipo="manual", usuario=req.usuario["usuario"],
                                contenido=contenido, carpeta_logo=p.carpeta_logo)
        except ValueError as e:
            raise ErrorNegocio(str(e))
        return {"archivo": os.path.basename(ruta), "registro": copias.registro(app.backups, 1)}

    @r("PUT", "/api/backups/programa", rol=("admin",))
    def backup_programa(req):
        b = req.body
        modo = b.get("backup_auto_modo")
        if modo not in ("intervalo", "horas", "no"):
            raise ErrorNegocio("Elija cómo programar las copias")
        try:
            cada = int(b.get("backup_auto_cada_h") or 6)
        except (TypeError, ValueError):
            raise ErrorNegocio("Número de horas no válido")
        if not 1 <= cada <= 168:
            raise ErrorNegocio("Las horas entre copias deben estar entre 1 y 168")
        try:
            horas = copias.leer_horas(b.get("backup_auto_horas", ""))
        except ValueError as e:
            raise ErrorNegocio(str(e))
        dias = "".join(sorted({d for d in str(b.get("backup_auto_dias") or "") if d in "1234567"}))
        if modo == "horas" and not horas:
            raise ErrorNegocio("Indique al menos una hora (HH:MM)")
        if modo == "horas" and not dias:
            raise ErrorNegocio("Elija al menos un día de la semana")
        grupos = [g for g in (b.get("backup_auto_contenido") or []) if g in copias.TODOS]
        if not grupos:
            raise ErrorNegocio("Elija qué guardar en las copias programadas")
        valores = {"backup_auto_modo": modo, "backup_auto_cada_h": str(cada),
                   "backup_auto_horas": ",".join(horas) or "23:30", "backup_auto_dias": dias or "1234567",
                   "backup_auto_contenido": "" if set(grupos) == set(copias.TODOS) else ",".join(grupos)}
        if "backups_mantener" in b:
            try:
                mantener = int(b.get("backups_mantener") or 30)
            except (TypeError, ValueError):
                raise ErrorNegocio("Número de copias a conservar no válido")
            if mantener < 5:
                raise ErrorNegocio("Conserve al menos 5 copias")
            valores["backups_mantener"] = str(mantener)
        if "backup_destino_extra" in b:
            valores["backup_destino_extra"] = (b.get("backup_destino_extra") or "").strip()
        for k, v in valores.items():
            p.db.set_cfg(k, v)
        if modo == "intervalo":   # el intervalo empieza a contar al guardar
            from datetime import datetime as _dt
            p.db.set_cfg("backup_auto_ultima", _dt.now().astimezone().isoformat(timespec="seconds"))
        with p.db.transaccion() as c:
            p.auditar(c, req.usuario["id"], "copias_programar",
                      f"{modo} cada={cada}h horas={valores['backup_auto_horas']} dias={valores['backup_auto_dias']} "
                      f"contenido={valores['backup_auto_contenido'] or 'todo'}")
        return {"ok": True}

    @r("GET", "/api/backups/grupos", rol=ROLES_SUPERVISION)
    def backup_grupos(req):
        return [{k: g[k] for k in ("id", "nombre", "detalle")} for g in copias.GRUPOS]

    @r("GET", "/api/backups", rol=ROLES_SUPERVISION)
    def backups(req):
        reg = copias.registro(app.backups, 60)
        ultima = next((e for e in reg if e.get("tipo") not in ("restauracion", "subida")), None)
        from datetime import datetime as _dt
        cfg = p.db.config()
        ahora = _dt.now().astimezone()
        ult = copias.ultima_programada(p.db)
        prox = copias.proxima_copia(cfg, ahora, ult)
        programa = {**copias.programa(cfg), "ultima": ult.isoformat() if ult else None,
                    "backup_destino_extra": cfg.get("backup_destino_extra") or "",
                    "backups_mantener": cfg.get("backups_mantener") or "30",
                    "proxima": prox.isoformat(timespec="minutes") if prox else None}
        return {"copias": copias.listar(app.backups), "registro": reg, "ultima": ultima, "programa": programa,
                "ultima_ok": next((e for e in reg if e.get("ok") and e.get("tipo") not in ("restauracion", "subida")), None),
                "carpeta": os.path.abspath(app.backups), "extra": p.cfg("backup_destino_extra") or ""}

    @r("GET", r"/api/backups/([\w.-]+)/info", rol=ROLES_SUPERVISION)
    def backup_info(req, nombre):
        try:
            return copias.validar(copias.ruta_segura(app.backups, nombre))
        except (ValueError, FileNotFoundError) as e:
            raise ErrorNegocio(str(e))

    @r("GET", r"/api/backups/([\w.-]+)/descargar", rol=ROLES_SUPERVISION)
    def backup_descargar(req, nombre):
        try:
            ruta = copias.ruta_segura(app.backups, nombre)
        except (ValueError, FileNotFoundError) as e:
            raise ErrorNegocio(str(e), 404)
        with open(ruta, "rb") as f:
            datos = f.read()
        return Respuesta(datos, "application/octet-stream",
                         {"Content-Disposition": f'attachment; filename="{nombre}"'})

    @r("POST", "/api/backups/subir", rol=("admin",), crudo=True)
    def backup_subir(req):
        try:
            return copias.guardar_subida(app.backups, req.raw)
        except ValueError as e:
            raise ErrorNegocio(str(e))

    @r("POST", r"/api/backups/([\w.-]+)/eliminar", rol=("admin",))
    def backup_eliminar(req, nombre):
        try:
            return copias.eliminar(app.backups, nombre, req.usuario["usuario"])
        except (ValueError, FileNotFoundError) as e:
            raise ErrorNegocio(str(e), 404)

    # --- 3.2: el servidor funciona sin ventana; se apaga o reinicia desde aquí
    @r("GET", "/api/sistema/servidor", rol=("admin",))
    def sistema_servidor(req):
        import sys as _sys
        log = getattr(app, "archivo_log", None)
        host = getattr(app, "host", "127.0.0.1")
        try:
            ses = p.db.q("SELECT s.token_hash, s.creada, s.visto, s.origen, u.nombre, u.usuario, u.rol FROM sesiones s "
                         "JOIN usuarios u ON u.id=s.usuario_id WHERE s.visto >= ? ORDER BY s.visto DESC",
                         (time.time() - SESION_HORAS * 3600,))
        except Exception:  # noqa: BLE001
            ses = []
        ruta_db = getattr(p.db, "path", None)
        return {"oculto": bool(getattr(app, "oculto", False)), "inicio": getattr(app, "inicio", None),
                "puerto": app.srv.server_address[1] if app.srv else None, "log": log,
                "python": _sys.version.split()[0], "ejecutable": _sys.executable,
                "host": host, "red": host not in ("127.0.0.1", "localhost"),
                "ips": ips_locales() if host not in ("127.0.0.1", "localhost") else [],
                "base_datos": ruta_db, "tamano_db": os.path.getsize(ruta_db) if ruta_db and os.path.isfile(ruta_db) else None,
                "sesiones": [{"nombre": x["nombre"], "usuario": x["usuario"], "rol": x["rol"], "origen": x["origen"],
                              "creada": x["creada"], "visto": datetime.fromtimestamp(x["visto"]).astimezone().isoformat(timespec="seconds"),
                              "propia": x["token_hash"] == app._hash_tok(req.token)} for x in ses]}

    @r("GET", "/api/sistema/log", rol=("admin",))
    def sistema_log(req):
        log = getattr(app, "archivo_log", None)
        if not log or not os.path.isfile(log):
            return {"log": log, "lineas": []}
        with open(log, "rb") as f:
            f.seek(0, 2)
            f.seek(max(0, f.tell() - 64 * 1024))
            lineas = f.read().decode("utf-8", "replace").splitlines()
        return {"log": log, "lineas": lineas[-300:]}

    @r("POST", "/api/sistema/sesiones/cerrar", rol=("admin",))
    def sistema_cerrar_sesiones(req):
        """Cierra las sesiones de los demás puestos (la del administrador sigue abierta)."""
        propio = app._hash_tok(req.token)
        with app._lock:
            for t in [t for t in app.sesiones if t != req.token]:
                app.sesiones.pop(t, None)
        with p.db.transaccion() as c:
            n = c.execute("DELETE FROM sesiones WHERE token_hash<>?", (propio,)).rowcount
            p.auditar(c, req.usuario["id"], "sesiones_cerrar", f"{n} sesiones")
        return {"cerradas": n}

    @r("POST", "/api/sistema/apagar", rol=("admin",))
    def sistema_apagar(req):
        app._comprobar_pin(req)
        reiniciar = bool(req.body.get("reiniciar"))
        with p.db.transaccion() as c:
            p.auditar(c, req.usuario["id"], "servidor_reiniciar" if reiniciar else "servidor_apagar", "")
        app.programar_reinicio(1.0, reiniciar=reiniciar)
        return {"ok": True, "reiniciar": reiniciar}

    @r("POST", "/api/sistema/restablecer", rol=("admin",))
    def sistema_restablecer(req):
        # Borra TODO: se exige el PIN del administrador y escribir la frase de confirmación
        if (req.body.get("confirmacion") or "").strip().upper() != "BORRAR TODO":
            raise ErrorNegocio("Escriba BORRAR TODO para confirmar")
        app._comprobar_pin(req)
        res = copias.restablecer(p.db, app.backups, req.usuario["usuario"], int(p.cfg("backups_mantener") or 30))
        from . import logo as logos
        logos.borrar(p.carpeta_logo)
        logos.borrar(p.carpeta_logo, "sello")
        app.cerrar_todas_las_sesiones()
        return res

    @r("POST", "/api/backups/restaurar", rol=("admin",))
    def backup_restaurar(req):
        # Se pide de nuevo el PIN: restaurar sustituye TODOS los datos actuales.
        app._comprobar_pin(req)
        try:
            res = copias.restaurar(p.db, app.backups, req.body.get("archivo", ""), req.usuario["usuario"],
                                   int(p.cfg("backups_mantener") or 30), carpeta_logo=p.carpeta_logo)
        except (ValueError, FileNotFoundError) as e:
            raise ErrorNegocio(str(e))
        app.cerrar_todas_las_sesiones()  # los usuarios y turnos pueden haber cambiado: todos vuelven a entrar
        return res
