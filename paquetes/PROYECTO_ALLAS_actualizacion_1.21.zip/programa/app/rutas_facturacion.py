"""PROYECTO ALLAS · rutas de la API: facturas, devoluciones, correo de facturas, VERI*FACTU y Madrid 360 (se registran desde server.App._registrar)."""
from .servicios import ROLES_SUPERVISION


def registrar(app, r, p):
    from .server import CONFIG_EDITABLE, Respuesta


    # --- facturas: datos del cliente, reimpresión, PDF y email
    @r("GET", "/api/facturas")
    def facturas(req):
        return p.facturas(req.query.get("buscar", ""))

    @r("GET", r"/api/facturas/(\d+)")
    def factura(req, pid):
        return p.factura(int(pid))

    @r("PUT", r"/api/facturas/(\d+)/destinatario")
    def factura_destinatario(req, pid):
        return p.guardar_destinatario(req.usuario, int(pid), req.body)

    @r("PUT", r"/api/facturas/(\d+)/estado")
    def factura_estado(req, pid):
        return p.cambiar_estado_factura(req.usuario, int(pid), req.body.get("estado"))

    @r("POST", r"/api/facturas/(\d+)/imprimir")
    def factura_imprimir(req, pid):
        return p.imprimir_factura(req.usuario, int(pid))

    @r("GET", r"/api/facturas/(\d+)/pdf")
    def factura_pdf(req, pid):
        datos, nombre = p.pdf_factura(int(pid))
        modo = "attachment" if req.query.get("descargar") == "1" else "inline"
        return Respuesta(datos, "application/pdf", {"Content-Disposition": f'{modo}; filename="{nombre}"'})

    @r("POST", r"/api/facturas/(\d+)/vista")
    def factura_vista(req, pid):
        return p.factura_vista(int(pid), req.body)

    @r("GET", r"/api/facturas/(\d+)/mensaje")
    def factura_mensaje(req, pid):
        m = p.mensaje_factura(int(pid))
        p.registrar_envio_externo(req.usuario, int(pid), req.query.get("email") or m["email"],
                                  req.query.get("medio", "gmail"))
        return m

    @r("GET", r"/api/facturas/(\d+)/eml")
    def factura_eml(req, pid):
        datos, nombre = p.eml_factura(int(pid), req.query.get("email", ""))
        p.registrar_envio_externo(req.usuario, int(pid), req.query.get("email", ""), "outlook")
        return Respuesta(datos, "message/rfc822", {"Content-Disposition": f'attachment; filename="{nombre}"'})

    @r("POST", r"/api/facturas/(\d+)/email")
    def factura_email(req, pid):
        return p.enviar_factura(req.usuario, int(pid), req.body.get("email"))

    @r("POST", "/api/emails/reintentar")
    def emails_reintentar(req):
        return p.reintentar_emails()

    @r("POST", "/api/email/prueba", rol=("admin",))
    def email_prueba(req):
        return p.probar_email(req.body.get("email"))

    # --- 3.9: devoluciones con factura rectificativa
    @r("POST", r"/api/pagos/(\d+)/devolver")
    def devolver(req, pid):
        b = req.body
        aut = b.get("autorizacion")
        autorizado = None
        if req.usuario["rol"] not in ROLES_SUPERVISION and aut:
            autorizado = p.autenticar(aut.get("usuario", ""), aut.get("pin", ""), req.ip)
        return p.devolver_pago(req.usuario, int(pid), b.get("importe_cent"), b.get("metodo"), b.get("motivo", ""),
                               autorizado)

    @r("POST", r"/api/pagos/(\d+)/rectificar")
    def rectificar(req, pid):
        b = req.body
        aut = b.get("autorizacion")
        autorizado = None
        if req.usuario["rol"] not in ROLES_SUPERVISION and aut:
            autorizado = p.autenticar(aut.get("usuario", ""), aut.get("pin", ""), req.ip)
        return p.rectificar_factura(req.usuario, int(pid), b.get("datos") or {}, b.get("motivo", ""), autorizado)

    # --- VERI*FACTU (preparado)
    @r("GET", "/api/verifactu", rol=("admin",))
    def verifactu(req):
        return p.verifactu_estado()

    @r("GET", r"/api/verifactu/(\d+)\.xml", rol=("admin",))
    def verifactu_xml(req, rid):
        r = p.verifactu_xml(int(rid))
        return Respuesta(('<?xml version="1.0" encoding="UTF-8"?>\n' + r["xml"]).encode(), "application/xml",
                         {"Content-Disposition": f'attachment; filename="verifactu_{r["num_serie"]}.xml"'})

    # --- Madrid 360 (preparado)
    @r("GET", "/api/m360", rol=ROLES_SUPERVISION)
    def m360(req):
        return p.m360_estado()

    @r("GET", "/api/m360/listado.csv", rol=ROLES_SUPERVISION)
    def m360_csv(req):
        dia = req.query.get("dia", "")
        datos = p.m360_generar(req.usuario["id"], dia, req.query.get("enviado") == "1")
        return Respuesta(datos.encode("utf-8"), "text/csv; charset=utf-8",
                         {"Content-Disposition": f'attachment; filename="madrid360_{dia.replace("-", "")}.csv"'})

    @r("POST", "/api/m360/marcar", rol=ROLES_SUPERVISION)
    def m360_marcar(req):
        p.m360_generar(req.usuario["id"], req.body.get("dia", ""), True)
        return p.m360_estado()

    @r("POST", "/api/factura/muestra", rol=("admin",))
    def muestra_factura(req):   # 4.2: vista previa de la factura PDF con los ajustes sin guardar
        cambios = {k: v for k, v in (req.body.get("cambios") or {}).items() if k in CONFIG_EDITABLE}
        return Respuesta(p.muestra_factura_pdf(cambios), "application/pdf", {"Content-Disposition": 'inline; filename="muestra.pdf"'})

    @r("POST", "/api/ticket/muestra", rol=("admin",))
    def muestra(req):
        cambios = {k: v for k, v in (req.body.get("cambios") or {}).items() if k in CONFIG_EDITABLE}
        return p.muestra_ticket(req.body.get("tipo", "entrada"), cambios)

    @r("GET", "/api/facturacion/verificar", rol=ROLES_SUPERVISION)
    def verificar(req):
        return p.verificar_cadena()
