"""Clave pública del Gestor de licencias de PROYECTO ALLAS.

Con ella se comprueban las licencias (seriales) y los paquetes de actualización. La clave
privada correspondiente solo está en el Gestor de licencias. Si se generan claves nuevas en el
Gestor, este archivo debe sustituirse por el que exporta el Gestor.
"""
CLAVE_PUBLICA = "2e7ad80f4c13184f240c958f6fc488b53631cfc7286c91603355b14ddfb4c6b1"
