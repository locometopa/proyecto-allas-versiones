"""PROYECTO ALLAS 4.5 · arranque automático con Windows (normal o en modo quiosco)."""
import os
import sys

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NOMBRE_INICIO = "PROYECTO ALLAS.cmd"


def _sv():
    from . import servicios
    return servicios


def carpeta_inicio():
    """Carpeta «Inicio» del usuario de Windows (lo que hay dentro se abre al iniciar sesión)."""
    propia = os.environ.get("ALLAS_CARPETA_INICIO")   # pruebas
    if propia:
        return propia
    if sys.platform != "win32" or not os.environ.get("APPDATA"):
        return None
    return os.path.join(os.environ["APPDATA"], "Microsoft", "Windows", "Start Menu", "Programs", "Startup")


class Funciones45:
    def autoarranque(self):
        c = carpeta_inicio()
        if not c:
            return {"disponible": False, "activo": False, "modo": "normal",
                    "mensaje": "El arranque automático solo está disponible en Windows."}
        ruta = os.path.join(c, NOMBRE_INICIO)
        activo, modo = os.path.isfile(ruta), "normal"
        if activo:
            try:
                with open(ruta, encoding="utf-8", errors="replace") as f:
                    modo = "quiosco" if "quiosco" in f.read() else "normal"
            except OSError:
                pass
        return {"disponible": True, "activo": activo, "modo": modo, "carpeta": c, "programa": RAIZ}

    def guardar_autoarranque(self, actor_id, activo, modo="normal"):
        sv = _sv()
        c = carpeta_inicio()
        if not c:
            raise sv.ErrorNegocio("El arranque automático solo está disponible en Windows.")
        if modo not in ("normal", "quiosco"):
            raise sv.ErrorNegocio("Modo no válido")
        ruta = os.path.join(c, NOMBRE_INICIO)
        try:
            if activo:
                os.makedirs(c, exist_ok=True)
                bat = os.path.join(RAIZ, "ARRANCAR.bat")
                texto = ("@echo off\r\n"
                         "REM PROYECTO ALLAS: arranque automatico al iniciar Windows.\r\n"
                         "REM Se cambia en Ajustes - Sistema - Servidor (no edite este archivo).\r\n"
                         f'cd /d "{RAIZ}"\r\n'
                         f'start "PROYECTO ALLAS" /min "{bat}"{" quiosco" if modo == "quiosco" else ""}\r\n')
                with open(ruta, "w", encoding="ascii", errors="replace", newline="") as f:
                    f.write(texto)
            elif os.path.isfile(ruta):
                os.remove(ruta)
        except OSError as e:
            raise sv.ErrorNegocio(f"No se pudo cambiar el arranque automático: {e}")
        with self.db.transaccion() as cx:
            self.auditar(cx, actor_id, "autoarranque", f"{'activado' if activo else 'desactivado'} {modo if activo else ''}".strip())
        return self.autoarranque()
