"""PROYECTO ALLAS · lógica de negocio: construcción e impresión de tickets, recibos, tarjetas y facturas de muestra (1.4: sale de servicios.py; se mezcla en la clase Parking)."""
import json
from datetime import timedelta

from . import impresion
from . import logo as logos
from .utiles import ErrorNegocio, _partir_txt, desc_vehiculo, desglose_iva, duracion_corta, eur, fecha_es, fecha_larga, iso, parse, sumar_meses, texto_duracion, texto_metodo


class SvcDocumentos:
    # ========================================================== impresión
    # Todos los textos salen de la configuración (Ajustes -> Ticket). 'cfg' permite
    # pasar cambios aún sin guardar para la vista previa en vivo.
    def _cfg_ticket(self, cambios=None):
        cfg = self.db.config()
        cfg.update({k: str(v) for k, v in (cambios or {}).items()})
        return cfg

    def _nuevo_doc(self, cfg):
        doc = impresion.Ticket(int(cfg.get("impresora_ancho") or 42))
        sep = (cfg.get("ticket_separador") or "-")[:1]
        doc.sep = sep if sep in "-=·*_. " else "-"
        try:
            doc.lineas_corte = max(1, min(10, int(cfg.get("ticket_lineas_corte") or 2)))
        except ValueError:
            pass
        return doc

    def _sello_ticket(self, doc, cfg):
        """4.58: sello del garaje al final del ticket de cobro (si hay uno guardado y está activado)."""
        if cfg.get("sello_ticket", "1") == "0":
            return doc
        r = logos.raster(self.carpeta_logo, "sello")
        if r:
            doc.alinear("centro").espacio()
            doc.logo(*r, img="sello")
            doc.alinear("izq")
        return doc

    def _cabecera(self, doc, cfg):
        if cfg.get("logo_ticket") == "1":
            r = logos.raster(self.carpeta_logo)
            if r:
                doc.logo(*r)
        doc.alinear("centro")
        tam = cfg.get("ticket_nombre_tam") or "grande"   # 4.2: grande | alto | normal
        if cfg.get("ticket_cabecera_invertida", "1") == "1":
            doc.inverso()
        doc.negrita()
        if tam == "grande":
            doc.grande()
        elif tam == "alto":
            doc.alto()
        doc.linea(cfg["nombre_parking"]).negrita(False).grande(False).alto(False).inverso(False)
        doc.espacio()
        if self.demo:
            doc.negrita().lineas("*** DEMOSTRACION - SIN VALIDEZ ***").negrita(False)
        razon = cfg.get("razon_social", "") if cfg.get("ticket_mostrar_razon", "1") == "1" else ""
        nif = ("NIF " + cfg.get("nif", "")) if cfg.get("ticket_mostrar_nif", "1") == "1" or not cfg.get("razon_social") else ""
        if razon and nif and len(razon) + len(nif) + 3 <= doc.ancho:   # 4.43: razón social y NIF en la misma línea
            doc.negrita().linea(f"{razon} · {nif}").negrita(False)
        else:
            if razon:
                doc.negrita().lineas(razon).negrita(False)
            if nif:
                doc.linea(nif)
        if cfg.get("ticket_mostrar_direccion", "1") == "1" and cfg.get("direccion"):
            doc.lineas(cfg["direccion"])
        if cfg.get("ticket_mostrar_telefono", "1") == "1" and cfg.get("telefono"):
            doc.linea("Tel. " + cfg["telefono"])
        if cfg.get("ticket_mostrar_web", "0") == "1":
            for k in ("empresa_web", "empresa_email"):
                if cfg.get(k):
                    doc.lineas(cfg[k].replace("https://", "").replace("http://", ""))
        if cfg.get("ticket_cabecera_extra"):
            doc.lineas(cfg["ticket_cabecera_extra"])
        doc.alinear("izq").separador("=")
        return doc

    def _titulo(self, doc, texto):
        doc.alinear("centro").negrita().alto().lineas(texto).alto(False).negrita(False).alinear("izq")
        return doc

    def _codigo_doc(self, doc, codigo, cfg):
        tipo = cfg.get("ticket_codigo", "ambos")
        doc.alinear("centro")
        doc.codigo(codigo, tipo, int(cfg.get("ticket_qr_tam") or 6))
        if tipo == "qr":
            doc.negrita().linea(codigo).negrita(False)
        doc.alinear("izq")
        return doc

    @staticmethod
    def _txt_mil(mil):
        precio = f"{mil / 1000:.3f}".rstrip("0").rstrip(".").replace(".", ",")
        if "," in precio and len(precio.split(",")[-1]) < 2:
            precio += "0"
        return precio

    @classmethod
    def _texto_precio(cls, tarifa):
        tr = tarifa["tramos"]
        if not tr:
            return None
        if tarifa.get("modo") == "hibrida" and len(tr) == 2:   # 4.2
            t0, t1 = tr
            unidad = {1: "min", 60: "h"}.get(t1["fraccion_min"]) or duracion_corta(t1["fraccion_min"])
            return (f"{eur((t0['precio_mil'] + 5) // 10)} hasta {duracion_corta(t0['hasta_min'])}; "
                    f"después {cls._txt_mil(t1['precio_mil'])} €/{unidad}")
        t0 = tr[0]
        precio = f"{t0['precio_mil'] / 1000:.3f}".rstrip("0").rstrip(".").replace(".", ",")
        if len(precio.split(",")[-1]) < 2 and "," in precio:
            precio += "0"
        unidad = "min" if t0["fraccion_min"] == 1 else f"{t0['fraccion_min']} min"
        return f"{precio} €/{unidad}" + (" (1er tramo)" if len(tr) > 1 else "")

    def _precios_entrada(self, t):
        """4.43: líneas de precio del ticket de entrada (etiqueta, valor), lo más compactas posible; las usan el diseño de serie y la plantilla."""
        p = self._texto_precio(t)
        out = []
        if t.get("modo") == "hibrida" and len(t["tramos"]) == 2:
            t0, t1 = t["tramos"]
            out += [(f"Hasta {duracion_corta(t0['hasta_min'])}", eur((t0["precio_mil"] + 5) // 10)), ("Después", p.split("después ", 1)[1])]
        elif p:
            out.append(("Precio", p))
        gracia, maximo = t["gracia_min"], t["maximo_diario_cent"]
        if gracia and maximo is not None:
            out.append((f"Cortesía {gracia} min", f"máx. 24 h {eur(maximo)}"))
        elif gracia:
            out.append(("Cortesía", f"{gracia} min gratis"))
        elif maximo is not None:
            out.append(("Máximo por 24 h", eur(maximo)))
        if t.get("redondeo") and t["redondeo"] != "ninguno":
            out.append(("Importe redondeado", {"cercano": "a 0,05 €", "arriba": "a 0,05 € (arriba)", "abajo": "a 0,05 € (abajo)"}[t["redondeo"]]))
        return out

    def _url_tarifas(self, cfg):
        """4.44: dirección donde consultar las tarifas (vacía si no está activada)."""
        if cfg.get("ticket_tarifas_url_activo", "0") != "1":
            return ""
        return (cfg.get("ticket_tarifas_url") or "").strip()

    def _texto_llaves(self, cfg=None):
        nombre = ((cfg or {}).get("nombre_parking") or self.cfg("nombre_parking") or "El parking").strip()
        return f"{nombre} se queda con las llaves"

    def _doc_entrada(self, tk, duplicado=False, cfg=None):
        cfg = cfg or self._cfg_ticket()
        plt = self.plantilla("entrada")   # 4.9: plantilla del Editor de plantillas
        if plt:
            return self._doc_plantilla(plt, self._datos_entrada(tk, duplicado, cfg), cfg)
        doc = self._cabecera(self._nuevo_doc(cfg), cfg)
        ent = parse(tk["entrada"])
        self._titulo(doc, cfg.get("ticket_entrada_titulo") or "TICKET DE ENTRADA")
        if duplicado:
            doc.alinear("centro").inverso().linea(" DUPLICADO ").inverso(False).alinear("izq")
        if tk.get("manual"):
            doc.alinear("centro").inverso().linea(" ENTRADA MANUAL ").inverso(False).alinear("izq")
        # 4.38: la matrícula va arriba, en grande; la hora de entrada pasa a una línea normal
        if tk.get("matricula"):
            doc.alinear("centro").espacio().grande().negrita().linea(tk["matricula"]).negrita(False).grande(False)
            doc.alinear("izq").separador()
            doc.negrita().par("Entrada", ent.strftime("%d/%m/%Y %H:%M")).negrita(False)
            if tk.get("ajuste_min"):
                doc.linea(f"(hora ajustada en caja: {tk['ajuste_min']:+d} min)")
        else:
            doc.alinear("centro").espacio().grande().negrita().linea(ent.strftime("%H:%M")).negrita(False).grande(False)
            doc.linea(fecha_larga(ent))
            if tk.get("ajuste_min"):
                doc.linea(f"(hora ajustada en caja: {tk['ajuste_min']:+d} min)")
            doc.alinear("izq").separador()
        t = self.tarifa(tk["tarifa_id"])
        doc.par("Tarifa", t["nombre"])
        if tk.get("reserva_hasta"):   # 4.2: reserva / hotel
            fin = parse(tk["reserva_hasta"])
            if tk.get("reserva_desde"):   # 4.43
                doc.negrita().par("Reserva desde", parse(tk["reserva_desde"]).strftime("%d/%m/%Y %H:%M")).negrita(False)
            doc.negrita().par("Sin cargo hasta", fin.strftime("%d/%m/%Y %H:%M")).negrita(False)
            if tk.get("reserva_ref"):
                doc.par("Nº reserva", tk["reserva_ref"])
            texto_res = t.get("texto_ticket")
            t = self.tarifa(tk.get("reserva_tarifa_id") or self._tarifa_tras_reserva(t))
            t = {**t, "texto_ticket": texto_res or t.get("texto_ticket")}
            doc.par("Después", t["nombre"])
        if cfg.get("ticket_mostrar_precio", "0") == "1":
            for etiqueta, valor in self._precios_entrada(t):
                doc.par(etiqueta, valor)
        url_t = self._url_tarifas(cfg)
        if url_t:   # 4.44
            doc.alinear("centro").linea("Consulte las tarifas en:").negrita().linea(url_t).negrita(False).alinear("izq")
        if t.get("texto_ticket"):
            doc.separador().alinear("centro").negrita().lineas(t["texto_ticket"]).negrita(False).alinear("izq")
        if cfg.get("ticket_mostrar_cajero") == "1" and tk.get("usuario_entrada_nombre"):
            doc.par("Atendido por", tk["usuario_entrada_nombre"])
        if tk.get("llaves"):   # 4.38
            doc.separador().alinear("centro").negrita().lineas(self._texto_llaves(cfg)).negrita(False).alinear("izq")
        doc.separador()
        self._codigo_doc(doc, tk["codigo"], cfg)
        if cfg.get("ticket_qr_pago", "1") == "1" and tk.get("codigo") and self.pago_movil_activo():   # 4.3
            doc.separador().alinear("centro").negrita().linea("PAGUE CON SU MÓVIL").negrita(False)
            doc.lineas("Escanee este código con la cámara del móvil")
            doc.codigo(self.url_pago_ticket(tk["codigo"]), "qr", max(4, int(cfg.get("ticket_qr_tam") or 6) - 1)).alinear("izq")
        doc.separador().alinear("centro").lineas(cfg.get("ticket_entrada_pie", "")).alinear("izq")
        return doc.cortar()

    def _bloque_total(self, doc, total, cfg, desglose=None):
        if not desglose:
            desglose = desglose_iva([(total, float(cfg.get("iva_pct") or 21))])
        if len(desglose) == 1:
            d = desglose[0]
            doc.par(f"Base {eur(d['base'])}", f"IVA {d['pct']:g}% {eur(d['cuota'])}")   # 4.43: una sola línea
        else:  # varios tipos de IVA: una línea por tipo
            for d in desglose:
                doc.par(f"Base {d['pct']:g}%  {eur(d['base'])}", f"IVA {eur(d['cuota'])}")
        doc.inverso().alto().negrita().par(" TOTAL", eur(total) + " ").negrita(False).alto(False).inverso(False)
        return doc

    def _cabecera_factura(self, doc, pago, cfg):
        dest = pago.get("destinatario")
        titulo = (cfg.get("factura_titulo_completa") or "FACTURA") if dest else \
            (cfg.get("recibo_titulo") or "FACTURA SIMPLIFICADA")
        self._titulo(doc, titulo)
        f = parse(pago["fecha"])
        doc.alinear("centro").linea(f"Nº {pago['serie']}-{pago['numero']:06d}  ·  {f.strftime('%d/%m/%Y %H:%M')}")
        if pago.get("copia"):
            doc.inverso().linea(" COPIA ").inverso(False)
        if pago.get("sustituye"):
            o = pago["sustituye"]
            doc.linea(f"Sustituye a la {o['serie']}-{o['numero']:06d} del {parse(o['fecha']).strftime('%d/%m/%Y')}")
        doc.alinear("izq").separador()
        if dest:
            doc.negrita().linea("Cliente:").negrita(False)
            doc.lineas(dest["nombre"])
            if dest.get("nif"):
                doc.linea("NIF/CIF: " + dest["nif"])
            if dest.get("direccion"):
                doc.lineas(dest["direccion"])
            if dest.get("observaciones"):
                doc.lineas("Observaciones: " + dest["observaciones"])
            doc.separador()
        return f

    def _bloque_pago(self, doc, pago, cfg=None):
        doc.par("Forma de pago", texto_metodo(pago["metodo"]))
        if pago.get("referencia"):
            doc.par("Referencia", pago["referencia"])
        if pago["metodo"] == "efectivo" and (cfg or {}).get("recibo_mostrar_cambio", "1") == "1" \
                and pago.get("entregado_cent") is not None:
            doc.par("Entregado", eur(pago["entregado_cent"]))
            doc.par("Cambio", eur(pago["cambio_cent"]))
        if (cfg or {}).get("ticket_mostrar_cajero") == "1" and pago.get("usuario_nombre"):
            doc.par("Atendido por", pago["usuario_nombre"])
        return doc

    def _doc_recibo(self, tk, pago, limite, cfg=None):
        cfg = cfg or self._cfg_ticket()
        plt = self.plantilla("recibo")
        if plt:
            return self._doc_plantilla(plt, self._datos_recibo(tk, pago, limite, cfg), cfg)
        doc = self._cabecera(self._nuevo_doc(cfg), cfg)
        f = self._cabecera_factura(doc, pago, cfg)
        if tk.get("matricula"):
            doc.negrita().par("Matrícula", tk["matricula"]).negrita(False)
        doc.par("Ticket", tk["codigo"])
        if tk.get("manual"):
            doc.alinear("centro").inverso().linea(" TICKET MANUAL ").inverso(False).alinear("izq")
        doc.par("Entrada", parse(tk["entrada"]).strftime("%d/%m/%Y %H:%M"))
        if tk.get("salida") and tk.get("estado") == "salido":
            doc.par("Salida", parse(tk["salida"]).strftime("%d/%m/%Y %H:%M"))
        if pago.get("salida_prevista"):
            doc.par("Pagado hasta", parse(pago["salida_prevista"]).strftime("%d/%m/%Y %H:%M"))
        doc.par("Pago", f.strftime("%d/%m/%Y %H:%M"))
        doc.par("Tiempo", texto_duracion(pago["minutos"]))
        if pago.get("minutos_incluidos"):
            doc.par("Incluido en servicios", "-" + texto_duracion(pago["minutos_incluidos"]))
        doc.separador()
        total = pago["importe_cent"]
        extras = pago.get("extras_cent") or 0
        descuento = pago.get("descuento_cent") or 0
        estancia = total - extras - pago["recargo_cent"] + descuento
        if estancia or not extras:
            doc.par("Estacionamiento", eur(estancia))
        if pago["recargo_cent"]:
            doc.par("Recargo ticket perdido", eur(pago["recargo_cent"]))
        for e in pago.get("lineas_extra") or []:
            nombre = (f"{e['cantidad']} x " if e["cantidad"] > 1 else "") + e["nombre"]
            doc.par(nombre, eur(e["precio_cent"] * e["cantidad"]))
            if e["cantidad"] > 1:
                doc.linea(f"   ({eur(e['precio_cent'])} / ud.)")
            if e.get("descripcion"):
                for l in _partir_txt(e["descripcion"], doc.ancho - 3):
                    doc.linea("   " + l)
            if e.get("minutos_incluidos"):
                doc.linea(f"   (incluye {texto_duracion(e['minutos_incluidos'] * e['cantidad'])} de parking)")
        if descuento:
            doc.par(f"Descuento {pago.get('descuento_nombre') or ''}".strip(), "-" + eur(descuento))
        doc.separador()
        self._bloque_total(doc, total, cfg, pago.get("desglose_iva"))
        self._bloque_pago(doc, pago, cfg).separador()
        self._pie_verifactu(doc, pago)
        if limite:
            lim = parse(limite)
            hora_txt = lim.strftime("%H:%M") if lim.date() == self.ahora().date() else lim.strftime("%H:%M del %d/%m/%Y")
        salida = (cfg.get("recibo_salida_texto") or "").replace("{hora}", hora_txt) if limite else ""
        if salida:
            doc.alinear("centro").negrita().alto().lineas(salida).alto(False).negrita(False)
        doc.alinear("centro").espacio().lineas(cfg.get("recibo_pie", "")).alinear("izq")
        self._sello_ticket(doc, cfg)
        return doc.cortar()

    def _doc_recibo_bono(self, cli, bono, pago, cfg=None):
        cfg = cfg or self._cfg_ticket()
        plt = self.plantilla("bono")
        if plt:
            return self._doc_plantilla(plt, self._datos_bono(cli, bono, pago, cfg), cfg)
        doc = self._cabecera(self._nuevo_doc(cfg), cfg)
        f = self._cabecera_factura(doc, pago, cfg)
        doc.negrita().par("Cliente", cli["nombre"]).negrita(False)
        if cli.get("nif"):
            doc.par("NIF", cli["nif"])
        for v in cli.get("vehiculos") or [{"matricula": m} for m in cli.get("matriculas", [])]:
            doc.par("Vehículo", desc_vehiculo(v))
        doc.separador()
        doc.negrita().lineas("Bono " + bono["plan_nombre"]).negrita(False)
        if bono.get("numero"):
            doc.par("Nº de bono", self.numero_bono(bono["numero"]))
        doc.par(f"Del {fecha_es(bono['desde'])} al {fecha_es(bono['hasta'])}", eur(pago["importe_cent"]))
        parcial = self._parcial_bono(bono, pago)
        if parcial:
            doc.par("Importe del bono", eur(parcial["total_cent"]))
            doc.par("Pagado hasta hoy", eur(parcial["pagado_cent"]))
            doc.negrita().par("Queda pendiente", eur(parcial["pendiente_cent"])).negrita(False)
        doc.separador()
        self._bloque_total(doc, pago["importe_cent"], cfg)
        self._bloque_pago(doc, pago, cfg).separador()
        self._pie_verifactu(doc, pago)
        doc.alinear("centro").negrita().alto().linea(f"Válido hasta {fecha_es(bono['hasta'])}").alto(False).negrita(False)
        doc.espacio().lineas(cfg.get("recibo_pie", "")).alinear("izq")
        self._sello_ticket(doc, cfg)
        return doc.cortar()

    def _parcial_bono(self, bono, pago):
        """Si el pago no cubre el bono entero: total, pagado hasta ese pago y lo que quedaba pendiente."""
        if not pago or not pago.get("id") or pago["importe_cent"] >= bono["importe_cent"]:
            return None
        pagado = self.db.q1("SELECT COALESCE(SUM(importe_cent),0) n FROM pagos WHERE bono_id=? AND id<=?",
                            (bono["id"], pago["id"]))["n"]
        canc = bono.get("cancelado_cent") or 0
        return {"total_cent": bono["importe_cent"], "pagado_cent": pagado,
                "pendiente_cent": max(0, bono["importe_cent"] - pagado - canc)}

    def _doc_tarjeta(self, cli, cfg=None):
        cfg = cfg or self._cfg_ticket()
        plt = self.plantilla("tarjeta")
        if plt:
            return self._doc_plantilla(plt, self._datos_tarjeta(cli, cfg), cfg)
        doc = self._cabecera(self._nuevo_doc(cfg), cfg)
        doc.alinear("centro").inverso().negrita().alto().linea(cfg.get("tarjeta_titulo") or "TARJETA DE ABONADO")
        doc.alto(False).negrita(False).inverso(False).espacio()
        doc.negrita().alto().lineas(cli["nombre"]).alto(False).negrita(False)
        for v in cli.get("vehiculos") or [{"matricula": m} for m in cli.get("matriculas", [])]:
            doc.lineas(desc_vehiculo(v))
        b = cli.get("bono") or {}
        if b.get("hasta") and b.get("estado") in ("vigente", "caduca", "futuro"):
            doc.linea(f"Bono {b.get('plan', '')}").linea(f"Válido hasta {fecha_es(b['hasta'])}")
        doc.alinear("izq").separador()
        self._codigo_doc(doc, cli["codigo"], cfg)
        doc.separador().alinear("centro").lineas(cfg.get("tarjeta_pie", "")).alinear("izq")
        return doc.cortar()

    def _doc_cierre(self, r):
        cfg = self._cfg_ticket()
        doc = self._cabecera(self._nuevo_doc(cfg), cfg)
        self._titulo(doc, f"CIERRE DE CAJA · TURNO {r['id']}")
        doc.separador()
        doc.par("Cajero", r["usuario_nombre"])
        doc.par("Apertura", parse(r["apertura"]).strftime("%d/%m/%Y %H:%M"))
        doc.par("Cierre", parse(r["cierre"]).strftime("%d/%m/%Y %H:%M"))
        doc.separador()
        doc.par("Entradas emitidas", str(r["num_entradas"]))
        doc.par("Cobros de estancias", str(r["num_cobros"] - r.get("num_bonos", 0)))
        doc.par("Bonos vendidos", f"{r.get('num_bonos', 0)}  ({eur(r.get('cobrado_bonos_cent', 0))})")
        doc.par("Servicios y productos", eur(r.get("cobrado_extras_cent", 0)))
        doc.par("Cobrado efectivo", eur(r["cobrado_efectivo_cent"]))
        doc.par("Cobrado tarjeta", eur(r["cobrado_tarjeta_cent"]))
        doc.negrita().par("TOTAL COBRADO", eur(r["cobrado_efectivo_cent"] + r["cobrado_tarjeta_cent"])).negrita(False)
        doc.separador()
        doc.par("Fondo inicial", eur(r["fondo_inicial_cent"]))
        doc.par("Ingresos", eur(r["ingresos_cent"]))
        doc.par("Retiradas", eur(r["retiradas_cent"]))
        doc.par("Efectivo esperado", eur(r["efectivo_esperado_cent"]))
        if r.get("arqueo", 1):
            for titulo, campo in (("Fondo por billetes y monedas", "fondo_desglose"), ("Contado por billetes y monedas", "contado_desglose")):
                try:
                    des = json.loads(r.get(campo) or "{}")
                except ValueError:
                    des = {}
                if des:
                    doc.separador().negrita().linea(titulo).negrita(False)
                    for den in sorted(des, key=int, reverse=True):
                        d = int(den)
                        nombre = f"{d // 100} EUR" if d >= 100 else f"{d} cent"
                        doc.par(f"  {des[den]} x {nombre}", eur(d * des[den]))
            doc.separador()
            doc.par("Efectivo contado", eur(r["efectivo_contado_cent"]))
            doc.inverso().negrita().par(" DIFERENCIA", eur(r["diferencia_cent"]) + " ").negrita(False).inverso(False)
        else:
            doc.alinear("centro").negrita().linea("Turno sin arqueo de caja").negrita(False).alinear("izq")
        if r.get("observaciones"):
            doc.separador().lineas("Obs.: " + r["observaciones"])
        doc.espacio(2).linea("Firma: ____________________")
        return doc.cortar()

    def _doc_movimiento(self, tipo, importe, motivo, usuario):
        cfg = self._cfg_ticket()
        doc = self._cabecera(self._nuevo_doc(cfg), cfg)
        self._titulo(doc, tipo.upper() + " DE CAJA").separador()
        doc.par("Fecha", self.ahora().strftime("%d/%m/%Y %H:%M"))
        doc.par("Empleado", usuario["nombre"])
        doc.negrita().par("Importe", eur(importe)).negrita(False)
        if motivo:
            doc.lineas("Motivo: " + motivo)
        doc.espacio(2).linea("Firma: ____________________")
        return doc.cortar()

    def _copias_entrada(self):
        return max(1, min(5, self.cfg("ticket_entrada_copias", int) or 1))

    def _imprimir(self, doc, nombre, cajon=False, copias=1):
        if cajon:
            # el pulso del cajón va al principio para que se abra mientras imprime
            pin = self.cfg("cajon_pin", int) or 0
            doc.buf[5:5] = b"\x1bp" + bytes([pin]) + b"\x19\xfa"
            doc.preview.insert(0, "[ABRIR CAJÓN]")
            doc.elementos.insert(0, {"t": "cajon"})
        return self._enviar(doc, nombre, copias)

    def _enviar(self, doc, nombre, copias=1):
        base = {"vista_previa": doc.texto(), "elementos": doc.elementos, "ancho": doc.ancho, "copias": copias}
        modo = (self.cfg("impresora_modo") or "").strip()
        if modo == "pantalla" or (modo in ("dispositivo", "red", "windows") and not (self.cfg("impresora_destino") or "").strip()):
            # sin impresora (o sin configurar): el ticket se enseña en pantalla y no se gasta papel
            return {"ok": True, "destino": "pantalla", "pantalla": True, **base}
        try:
            # varias copias = el mismo ticket (con su corte) repetido en un solo envío
            destino = impresion.enviar(doc.bytes() * copias, self.cfg("impresora_modo"), self.cfg("impresora_destino"),
                                       nombre, doc.texto())
            return {"ok": True, "destino": destino, **base}
        except Exception as e:  # la operación ya está guardada: avisamos, no fallamos
            return {"ok": False, "error": f"Error de impresora: {e}", **base}

    def prueba_impresora(self):
        cfg = self._cfg_ticket()
        doc = self._cabecera(self._nuevo_doc(cfg), cfg)
        self._titulo(doc, "PRUEBA DE IMPRESORA")
        doc.alinear("centro").linea("Acentos: áéíóú ñ Ñ ç ü €").linea(self.ahora().strftime("%d/%m/%Y %H:%M:%S"))
        doc.inverso().linea(" Texto invertido ").inverso(False)
        doc.alinear("izq")
        self._codigo_doc(doc, self._codigo(1), dict(cfg, ticket_codigo="ambos"))
        doc.alinear("centro").linea("Si ve QR y código de barras, ambos")
        doc.linea("lectores (2D y láser/infrarrojo) sirven.")
        return self._enviar(doc.cortar(), "prueba")

    def muestra_factura_pdf(self, cambios=None):
        """4.2: factura PDF de ejemplo con los ajustes sin guardar (para la vista previa de Ajustes → Factura)."""
        from . import VERSION_COMPLETA
        from .pdf import color_hex, factura_a_pdf
        cfg = self._cfg_ticket(cambios)
        iva = float(cfg.get("iva_pct") or 21)
        ahora = self.ahora()
        lineas = [{"concepto": "Estacionamiento", "detalle": "1 h 37 min · tarifa General", "cantidad": 1, "precio": 441, "iva": iva, "importe": 441},
                  {"concepto": "Lavado exterior", "detalle": "Lavado a mano", "cantidad": 1, "precio": 1200, "iva": iva, "importe": 1200}]
        detalles = [("Matrícula", "1234ABC"), ("Ticket", self._codigo(123)), ("Entrada", (ahora - timedelta(minutes=97)).strftime("%d/%m/%Y %H:%M")),
                    ("Salida", ahora.strftime("%d/%m/%Y %H:%M")), ("Tiempo", texto_duracion(97))]
        if cfg.get("factura_mostrar_detalle") == "0":
            detalles = []
        datos = {
            "empresa": {"nombre": cfg.get("nombre_parking", ""), "razon_social": cfg.get("razon_social"), "nif": cfg.get("nif"),
                        "direccion": cfg.get("direccion"), "telefono": cfg.get("telefono"), "email": cfg.get("empresa_email"),
                        "web": (cfg.get("empresa_web") or "").replace("https://", "").replace("http://", "")},
            "estilo": {"acento": color_hex(cfg.get("factura_color")) if cfg.get("factura_color") else None,
                       "cabecera_tabla": color_hex(cfg.get("factura_cabecera_tabla")) if cfg.get("factura_cabecera_tabla") else None,
                       "logo_alto": {"pequeno": 40, "mediano": 62, "grande": 90}.get(cfg.get("factura_logo_tam") or "mediano", 62)},
            "notas": (cfg.get("factura_notas") or "").strip() or None,
            "titulo": "MUESTRA · " + (cfg.get("factura_titulo_completa") or "FACTURA"),
            "numero": f"{cfg.get('serie_factura') or 'A'}-000123", "fecha": ahora.strftime("%d/%m/%Y  %H:%M"),
            "cliente": {"nombre": "Transportes Ejemplo S.L.", "nif": "B12345674", "direccion": "C/ Mayor 1, 28013 Madrid",
                        "email": "admin@ejemplo.es", "observaciones": "Pedido 4521"},
            "detalles": detalles, "lineas": lineas, "desglose": desglose_iva([(1641, iva)]), "total": 1641,
            "pago": {"metodo": "Efectivo", "entregado": 2000, "cambio": 359},
            "pie": cfg.get("factura_pie") if cfg.get("factura_pie") else cfg.get("recibo_pie", ""), "marca": VERSION_COMPLETA,
            "logo": logos.jpeg(self.carpeta_logo) if cfg.get("logo_factura") == "1" else None,
            "sello": logos.jpeg_sello(self.carpeta_logo) if cfg.get("sello_factura", "1") != "0" else None, "verifactu": None}
        plt = self.plantilla("factura")   # 4.9
        if plt:
            datos = self._aplicar_plantilla_a4(datos, plt)
        return factura_a_pdf(datos)

    def muestra_ticket(self, tipo, cambios=None):
        """Vista previa con datos de ejemplo y textos sin guardar. No imprime ni escribe en la BD."""
        cfg = self._cfg_ticket(cambios)
        ahora = self.ahora()
        tar = self.db.q1("SELECT id FROM tarifas WHERE por_defecto=1 AND activa=1") or \
            self.db.q1("SELECT id FROM tarifas LIMIT 1")
        if not tar:
            raise ErrorNegocio("Cree primero una tarifa")
        tk = {"codigo": self._codigo(123), "matricula": "1234ABC", "tarifa_id": tar["id"],
              "entrada": iso(ahora - timedelta(minutes=97)), "usuario_entrada_nombre": "Ana García"}
        iva_gen = float(cfg.get("iva_pct") or 21)
        lineas_ej = [{"nombre": "Lavado exterior", "cantidad": 1, "precio_cent": 1200, "iva_pct": iva_gen,
                      "descripcion": "Lavado a mano con productos ecológicos"},
                     {"nombre": "Botella de agua 50 cl", "cantidad": 2, "precio_cent": 150, "iva_pct": 10.0}]
        pago = {"serie": cfg.get("serie_factura") or "A", "numero": 1, "fecha": iso(ahora), "minutos": 97, "usuario_nombre": "Ana García",
                "importe_cent": 441 + 1500, "recargo_cent": 0, "extras_cent": 1500, "metodo": "efectivo",
                "entregado_cent": 2000, "cambio_cent": 59, "lineas_extra": lineas_ej,
                "desglose_iva": desglose_iva([(441, iva_gen)] + [(e["precio_cent"] * e["cantidad"], e["iva_pct"])
                                                                  for e in lineas_ej])}
        cli = {"nombre": "Laura Martín Gómez", "nif": "12345678Z", "matriculas": ["1234ABC", "5678DEF"],
               "vehiculos": [{"matricula": "1234ABC", "marca": "Seat", "modelo": "Ibiza"},
                             {"matricula": "5678DEF", "marca": "Toyota", "modelo": "Corolla"}],
               "codigo": self._codigo(1, "CL"),
               "bono": {"estado": "vigente", "plan": "Mensual 24 horas",
                        "hasta": (sumar_meses(ahora.date(), 1) - timedelta(days=1)).isoformat()}}
        if tipo == "entrada":
            doc = self._doc_entrada(tk, cfg=cfg)
        elif tipo == "recibo":
            doc = self._doc_recibo(tk, pago, iso(ahora + timedelta(minutes=15)), cfg=cfg)
        elif tipo == "bono":
            bono = {"plan_nombre": "Mensual 24 horas", "desde": ahora.date().isoformat(),
                    "hasta": cli["bono"]["hasta"]}
            doc = self._doc_recibo_bono(cli, bono, dict(pago, importe_cent=9000, entregado_cent=10000, extras_cent=0,
                                                        cambio_cent=1000, lineas_extra=[], desglose_iva=None), cfg=cfg)
        elif tipo == "tarjeta":
            doc = self._doc_tarjeta(cli, cfg=cfg)
        else:
            raise ErrorNegocio("Tipo de ticket desconocido")
        return {"vista_previa": doc.texto(), "elementos": doc.elementos, "ancho": doc.ancho}
