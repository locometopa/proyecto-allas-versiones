"""PROYECTO ALLAS · lógica de negocio: VERI*FACTU, Madrid 360 y lectura de matrículas (LPR) (1.4: sale de servicios.py; se mezcla en la clase Parking)."""
from datetime import date, timedelta

from .utiles import ErrorNegocio, iso, norm_matricula, parse


class SvcIntegraciones:
    # ====================================================== VERI*FACTU (preparado)
    def _registro_verifactu(self, c, pago_id, serie, numero, fecha, total, desglose):
        from . import __version__
        from . import verifactu as vf
        nif = (self.cfg("nif") or "").upper().replace(" ", "").replace("-", "")
        ant = c.execute("SELECT num_serie, fecha_expedicion, huella FROM verifactu_registros ORDER BY id DESC LIMIT 1").fetchone()
        dest = c.execute("SELECT nombre, nif FROM facturas_destinatario WHERE pago_id=?", (pago_id,)).fetchone()
        cuota = sum(d["cuota"] for d in (desglose or []))
        conc = c.execute("SELECT concepto FROM pagos WHERE id=?", (pago_id,)).fetchone()
        rect = bool(conc and conc[0] == "rectificativa")   # 3.9: R5 = rectificativa de factura simplificada
        r = {"nif": nif, "num_serie": f"{serie}-{numero:06d}", "fecha_expedicion": parse(fecha).strftime("%d-%m-%Y"),
             "tipo_factura": "R5" if rect else ("F1" if dest and dest[1] else "F2"), "cuota_cent": cuota, "importe_cent": total,
             "huella_anterior": ant[2] if ant else None, "ant_num_serie": ant[0] if ant else None,
             "ant_fecha": ant[1] if ant else None, "fecha_generacion": iso(self.ahora())}
        r["huella"] = vf.huella_alta(nif, r["num_serie"], r["fecha_expedicion"], r["tipo_factura"], cuota, total,
                                     r["huella_anterior"], r["fecha_generacion"])
        xml = vf.xml_registro_alta(r, self.cfg("razon_social") or "", desglose or [], __version__,
                                   destinatario={"nombre": dest[0], "nif": dest[1]} if dest and dest[1] else None)
        c.execute("INSERT INTO verifactu_registros(pago_id, num_serie, fecha_expedicion, tipo_factura, cuota_cent, importe_cent, "
                  "huella_anterior, huella, fecha_generacion, xml) VALUES(?,?,?,?,?,?,?,?,?,?)",
                  (pago_id, r["num_serie"], r["fecha_expedicion"], r["tipo_factura"], cuota, total, r["huella_anterior"],
                   r["huella"], r["fecha_generacion"], xml))

    def _qr_verifactu(self, pago_id):
        if not self.activo("verifactu_activo", "verifactu"):
            return None
        r = self.db.q1("SELECT * FROM verifactu_registros WHERE pago_id=?", (pago_id,))
        if not r:
            return None
        from . import verifactu as vf
        nif = (self.cfg("nif") or "").upper()
        return {"url": vf.url_qr(nif, r["num_serie"], r["fecha_expedicion"], r["importe_cent"],
                                 self.cfg("verifactu_entorno") or "pruebas"), "huella": r["huella"]}

    def _pie_verifactu(self, doc, pago):
        q = self._qr_verifactu(pago["id"]) if pago.get("id") else None
        if q:
            doc.alinear("centro").linea("QR tributario:").alinear("izq")
            doc.qr(q["url"], 4)
            doc.alinear("centro").negrita().linea("VERI*FACTU").negrita(False)
            doc.lineas("Factura verificable en la sede electrónica de la AEAT").alinear("izq").separador()

    def verifactu_estado(self):
        regs = self.db.q("SELECT id, pago_id, num_serie, fecha_expedicion, tipo_factura, importe_cent, huella, estado, "
                         "fecha_generacion FROM verifactu_registros ORDER BY id DESC LIMIT 50")
        total = self.db.q1("SELECT COUNT(*) n, SUM(estado='pendiente') pend FROM verifactu_registros")
        return {"activo": self.cfg("verifactu_activo") == "1", "entorno": self.cfg("verifactu_entorno") or "pruebas",
                "nif": self.cfg("nif"), "razon_social": self.cfg("razon_social"), "registros": regs,
                "total": total["n"], "pendientes": total["pend"] or 0, "envio_disponible": False}

    def verifactu_xml(self, reg_id):
        r = self.db.q1("SELECT xml, num_serie FROM verifactu_registros WHERE id=?", (reg_id,))
        if not r:
            raise ErrorNegocio("Registro no encontrado", 404)
        return r

    # ================================================== Madrid 360 (ZBE Distrito Centro)
    def m360_lineas(self, dia):
        """Matrículas que han entrado en el aparcamiento ese día: «matrícula;AAAAMMDD;HH:MM» (una por entrada)."""
        try:
            date.fromisoformat(dia)
        except (TypeError, ValueError):
            raise ErrorNegocio("Día no válido")
        filas = self.db.q("SELECT matricula, entrada FROM tickets WHERE substr(entrada,1,10)=? AND estado<>'anulado' "
                          "AND matricula IS NOT NULL AND matricula<>'' ORDER BY entrada", (dia,))
        return [self._linea_matricula(f["matricula"], parse(f["entrada"])) for f in filas]

    def m360_estado(self, dias=10):
        hoy = self.ahora().date()
        lista = []
        for i in range(dias):
            d = (hoy - timedelta(days=i)).isoformat()
            n = self.db.q1("SELECT COUNT(*) n FROM tickets WHERE substr(entrada,1,10)=? AND estado<>'anulado' "
                           "AND matricula IS NOT NULL AND matricula<>''", (d,))["n"]
            env = self.db.q1("SELECT matriculas, estado, fecha, modo, detalle FROM m360_envios WHERE dia=?", (d,))
            lista.append({"dia": d, "matriculas": n, "envio": env})
        cfg = {k: self.cfg(k) or "" for k in ("m360_activo", "m360_codigo", "m360_modo", "m360_url", "m360_usuario",
                                              "m360_hora_envio")}
        cfg["m360_clave"] = "********" if self.cfg("m360_clave") else ""
        return {"activo": cfg["m360_activo"] == "1", "config": cfg, "dias": lista}

    def m360_luz(self):
        """Luz de estado de Madrid 360 para la barra superior (solo si está activado).
        verde: todo comunicado · ámbar: falta el listado de ayer · rojo: faltan días anteriores o falló un envío."""
        if not self.activo("m360_activo", "madrid360"):
            return None
        hoy = self.ahora().date()
        try:
            desde = date.fromisoformat(self.cfg("m360_desde") or "")
        except ValueError:
            desde = hoy - timedelta(days=7)
        desde = max(desde, hoy - timedelta(days=30))
        pendientes, errores = [], []
        d = hoy - timedelta(days=1)
        while d >= desde:
            dia = d.isoformat()
            n = self.db.q1("SELECT COUNT(*) n FROM tickets WHERE substr(entrada,1,10)=? AND estado<>'anulado' "
                           "AND matricula IS NOT NULL AND matricula<>''", (dia,))["n"]
            env = self.db.q1("SELECT estado FROM m360_envios WHERE dia=?", (dia,))
            if env and env["estado"] == "error":
                errores.append(dia)
            elif n and not (env and env["estado"] == "enviado"):
                pendientes.append(dia)
            d -= timedelta(days=1)
        ayer = (hoy - timedelta(days=1)).isoformat()
        if errores or any(p < ayer for p in pendientes):
            color = "rojo"
            texto = (f"Madrid 360: {len(pendientes) + len(errores)} día(s) sin comunicar"
                     + (" (envío fallido)" if errores else ""))
        elif pendientes:
            color, texto = "ambar", "Madrid 360: falta comunicar el listado de ayer"
        else:
            color, texto = "verde", "Madrid 360: listados al día"
        return {"color": color, "texto": texto, "pendientes": sorted(pendientes + errores)}

    def m360_generar(self, actor_id, dia, marcar_enviado=False):
        lineas = self.m360_lineas(dia)
        contenido = "\r\n".join(lineas) + ("\r\n" if lineas else "")
        estado = "enviado" if marcar_enviado else "generado"
        self.db.ex("INSERT INTO m360_envios(dia, matriculas, contenido, modo, estado, fecha, detalle) VALUES(?,?,?,?,?,?,?) "
                   "ON CONFLICT(dia) DO UPDATE SET matriculas=excluded.matriculas, contenido=excluded.contenido, "
                   "estado=CASE WHEN m360_envios.estado='enviado' AND excluded.estado<>'enviado' THEN 'enviado' ELSE excluded.estado END, "
                   "fecha=excluded.fecha, modo=excluded.modo, detalle=excluded.detalle",
                   (dia, len(lineas), contenido, "manual", estado, iso(self.ahora()),
                    "comunicado a mano en el portal del Ayuntamiento" if marcar_enviado else None))
        with self.db.transaccion() as c:
            self.auditar(c, actor_id, "m360_listado", f"{dia}: {len(lineas)} matrícula(s) ({estado})")
        return contenido

    def m360_enviar_automatico(self, dia):
        """Envío automático (PREPARADO): POST del listado a la dirección configurada. El Ayuntamiento debe facilitar
        el formato y la dirección definitivos; hasta entonces, usar el modo manual."""
        url = self.cfg("m360_url")
        if not url:
            raise ErrorNegocio("Falta la dirección de envío de Madrid 360")
        lineas = self.m360_lineas(dia)
        contenido = "\r\n".join(lineas) + ("\r\n" if lineas else "")
        import base64
        import urllib.request
        cab = {"Content-Type": "text/csv; charset=utf-8", "X-Codigo-Aparcamiento": self.cfg("m360_codigo") or ""}
        if self.cfg("m360_usuario"):
            cab["Authorization"] = "Basic " + base64.b64encode(
                f"{self.cfg('m360_usuario')}:{self.cfg('m360_clave') or ''}".encode()).decode()
        try:
            with urllib.request.urlopen(urllib.request.Request(url, data=contenido.encode(), headers=cab, method="POST"),
                                        timeout=30) as r:
                estado, det = "enviado", f"HTTP {r.status}"
        except Exception as e:  # noqa: BLE001
            estado, det = "error", str(e)[:300]
        self.db.ex("INSERT INTO m360_envios(dia, matriculas, contenido, modo, estado, fecha, detalle) VALUES(?,?,?,?,?,?,?) "
                   "ON CONFLICT(dia) DO UPDATE SET matriculas=excluded.matriculas, contenido=excluded.contenido, "
                   "estado=excluded.estado, fecha=excluded.fecha, modo=excluded.modo, detalle=excluded.detalle",
                   (dia, len(lineas), contenido, "automatico", estado, iso(self.ahora()), det))
        return estado

    # ================================================ lectores de matrículas (cámaras)
    def lpr_lectura(self, camara, matricula, confianza=None, origen=""):
        """Lectura enviada por una cámara (o su software) por HTTP. Devuelve lo que se ha hecho con ella."""
        if not self.activo("lpr_activo", "madrid360"):
            raise ErrorNegocio("El lector de matrículas por cámara está desactivado (Ajustes → Integraciones)", 409)
        if camara not in ("entrada", "salida"):
            raise ErrorNegocio("Cámara no válida: use «entrada» o «salida»")
        mat = norm_matricula(matricula)
        if not mat or not 4 <= len(mat) <= 12:
            raise ErrorNegocio("Matrícula no válida")
        conf = None if confianza in (None, "") else float(confianza)
        resultado = "registrada"
        if conf is not None and conf < float(self.cfg("lpr_confianza_min") or 0):
            resultado = "baja_confianza"
        elif camara == "entrada" and self.cfg("lpr_entrada_accion") == "emitir":
            t = self.turno_abierto()
            if not t:
                resultado = "sin_turno"
            else:
                usuario = self.db.q1("SELECT * FROM usuarios WHERE id=?", (t["usuario_id"],))
                try:
                    tk = self.emitir_ticket(usuario, mat)
                    resultado = f"ticket {tk['codigo']}"
                except ErrorNegocio as e:
                    resultado = f"no emitido: {e}"
        lid = self.db.ex("INSERT INTO lpr_lecturas(fecha, camara, matricula, confianza, origen, resultado) VALUES(?,?,?,?,?,?)",
                         (iso(self.ahora()), camara, mat, conf, (origen or "")[:60], resultado)).lastrowid
        return {"id": lid, "camara": camara, "matricula": mat, "confianza": conf, "resultado": resultado}

    def lpr_ultimas(self, desde_id=0, camara=None):
        sql, params = "SELECT * FROM lpr_lecturas WHERE id>?", [int(desde_id or 0)]
        if camara:
            sql += " AND camara=?"
            params.append(camara)
        return self.db.q(sql + " ORDER BY id DESC LIMIT 20", params)
