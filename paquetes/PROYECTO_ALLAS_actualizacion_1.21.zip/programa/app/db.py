"""Acceso a la base de datos SQLite: conexión, esquema y migraciones.

Principios:
- Importes SIEMPRE en céntimos (enteros). Precios por minuto en milésimas de euro.
- Fechas en ISO 8601 con zona horaria local (p.ej. 2026-10-09T13:07:00+02:00).
- WAL + synchronous=FULL: un corte de luz no debe perder un cobro ya confirmado.
"""
import os
import secrets
import sqlite3
import threading
from datetime import datetime

SCHEMA_VERSION = 42

SCHEMA = """
CREATE TABLE IF NOT EXISTS config (
    clave TEXT PRIMARY KEY,
    valor TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS usuarios (
    id          INTEGER PRIMARY KEY,
    nombre      TEXT NOT NULL,
    usuario     TEXT NOT NULL UNIQUE,
    pin_hash    TEXT NOT NULL,
    pin_salt    TEXT NOT NULL,
    rol         TEXT NOT NULL CHECK (rol IN ('admin','supervisor','cajero')),
    activo      INTEGER NOT NULL DEFAULT 1,
    creado      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tarifas (
    id                   INTEGER PRIMARY KEY,
    nombre               TEXT NOT NULL,
    gracia_min           INTEGER NOT NULL DEFAULT 0,      -- minutos gratis
    maximo_diario_cent   INTEGER,                         -- tope por cada 24 h (NULL = sin tope)
    activa               INTEGER NOT NULL DEFAULT 1,
    por_defecto          INTEGER NOT NULL DEFAULT 0
);

-- Tramos: desde el minuto 'desde_min' hasta 'hasta_min' (NULL = sin fin) se cobra
-- 'precio_mil' milésimas de euro por cada fracción de 'fraccion_min' minutos.
CREATE TABLE IF NOT EXISTS tarifa_tramos (
    id            INTEGER PRIMARY KEY,
    tarifa_id     INTEGER NOT NULL REFERENCES tarifas(id) ON DELETE CASCADE,
    desde_min     INTEGER NOT NULL,
    hasta_min     INTEGER,
    fraccion_min  INTEGER NOT NULL DEFAULT 1 CHECK (fraccion_min > 0),
    precio_mil    INTEGER NOT NULL CHECK (precio_mil >= 0)
);

CREATE TABLE IF NOT EXISTS turnos (
    id                    INTEGER PRIMARY KEY,
    usuario_id            INTEGER NOT NULL REFERENCES usuarios(id),
    apertura              TEXT NOT NULL,
    cierre                TEXT,
    fondo_inicial_cent    INTEGER NOT NULL DEFAULT 0,
    efectivo_esperado_cent INTEGER,
    efectivo_contado_cent INTEGER,
    diferencia_cent       INTEGER,
    observaciones         TEXT,
    estado                TEXT NOT NULL DEFAULT 'abierto' CHECK (estado IN ('abierto','cerrado'))
);
-- Solo puede haber un turno abierto a la vez (una caja).
CREATE UNIQUE INDEX IF NOT EXISTS ux_turno_abierto ON turnos(estado) WHERE estado = 'abierto';

CREATE TABLE IF NOT EXISTS tickets (
    id               INTEGER PRIMARY KEY,
    codigo           TEXT NOT NULL UNIQUE,      -- contenido del QR
    matricula        TEXT,
    entrada          TEXT NOT NULL,
    tarifa_id        INTEGER NOT NULL REFERENCES tarifas(id),
    estado           TEXT NOT NULL DEFAULT 'dentro'
                     CHECK (estado IN ('dentro','pagado','salido','anulado')),
    salida_limite    TEXT,                      -- hasta cuándo puede salir sin pagar más
    salida           TEXT,
    perdido          INTEGER NOT NULL DEFAULT 0,
    turno_entrada_id INTEGER REFERENCES turnos(id),
    usuario_entrada_id INTEGER REFERENCES usuarios(id),
    anulado_motivo   TEXT
);
CREATE INDEX IF NOT EXISTS ix_tickets_estado ON tickets(estado);
CREATE INDEX IF NOT EXISTS ix_tickets_matricula ON tickets(matricula);
CREATE INDEX IF NOT EXISTS ix_tickets_entrada ON tickets(entrada);

CREATE TABLE IF NOT EXISTS pagos (
    id               INTEGER PRIMARY KEY,
    ticket_id        INTEGER NOT NULL REFERENCES tickets(id),
    turno_id         INTEGER NOT NULL REFERENCES turnos(id),
    usuario_id       INTEGER NOT NULL REFERENCES usuarios(id),
    fecha            TEXT NOT NULL,
    minutos          INTEGER NOT NULL,
    importe_cent     INTEGER NOT NULL,
    recargo_cent     INTEGER NOT NULL DEFAULT 0,   -- p.ej. ticket perdido (incluido en importe)
    metodo           TEXT NOT NULL CHECK (metodo IN ('efectivo','tarjeta')),
    entregado_cent   INTEGER,
    cambio_cent      INTEGER,
    serie            TEXT NOT NULL,
    numero           INTEGER NOT NULL,
    UNIQUE (serie, numero)
);
CREATE INDEX IF NOT EXISTS ix_pagos_fecha ON pagos(fecha);
CREATE INDEX IF NOT EXISTS ix_pagos_turno ON pagos(turno_id);

-- Registro de facturación encadenado (base para cumplir el Reglamento de sistemas
-- de facturación / VERI*FACTU): cada factura simplificada lleva el hash de la anterior.
-- Es de solo inserción; un trigger impide modificar o borrar.
CREATE TABLE IF NOT EXISTS registros_facturacion (
    id            INTEGER PRIMARY KEY,
    pago_id       INTEGER NOT NULL UNIQUE REFERENCES pagos(id),
    serie         TEXT NOT NULL,
    numero        INTEGER NOT NULL,
    fecha         TEXT NOT NULL,
    nif_emisor    TEXT NOT NULL,
    base_cent     INTEGER NOT NULL,
    cuota_iva_cent INTEGER NOT NULL,
    total_cent    INTEGER NOT NULL,
    hash_anterior TEXT NOT NULL,
    hash          TEXT NOT NULL
);
CREATE TRIGGER IF NOT EXISTS trg_rf_no_update BEFORE UPDATE ON registros_facturacion
BEGIN SELECT RAISE(ABORT, 'Los registros de facturación son inalterables'); END;
CREATE TRIGGER IF NOT EXISTS trg_rf_no_delete BEFORE DELETE ON registros_facturacion
BEGIN SELECT RAISE(ABORT, 'Los registros de facturación son inalterables'); END;

CREATE TABLE IF NOT EXISTS movimientos_caja (
    id          INTEGER PRIMARY KEY,
    turno_id    INTEGER NOT NULL REFERENCES turnos(id),
    usuario_id  INTEGER NOT NULL REFERENCES usuarios(id),
    fecha       TEXT NOT NULL,
    tipo        TEXT NOT NULL CHECK (tipo IN ('retirada','ingreso','apertura_cajon')),
    importe_cent INTEGER NOT NULL DEFAULT 0,
    motivo      TEXT
);

CREATE TABLE IF NOT EXISTS auditoria (
    id         INTEGER PRIMARY KEY,
    fecha      TEXT NOT NULL,
    usuario_id INTEGER,
    accion     TEXT NOT NULL,
    detalle    TEXT
);
CREATE INDEX IF NOT EXISTS ix_auditoria_fecha ON auditoria(fecha);
"""

CONFIG_DEFECTO = {
    "nombre_parking": "PARKING CENTRO",
    "razon_social": "Mi Empresa S.L.",
    "nif": "B00000000",
    "direccion": "C/ Ejemplo 1, 28001 Madrid",
    "telefono": "",
    "capacidad": "120",
    "iva_pct": "21",
    "minutos_salida": "15",          # tiempo para salir tras pagar
    "recargo_perdido_cent": "2000",  # 20,00 € por ticket perdido
    "serie_factura": "A",
    "serie_proveedor": "P",           # 4.58: serie propia de las facturas a proveedores
    "factura_proveedor_numero_inicial": "1",
    "sello_ticket": "1", "sello_factura": "1",   # 4.58: el sello del garaje (si hay) sale en el cobro y en la factura
    "impresora_modo": "pantalla",    # pantalla | archivo | dispositivo | red | windows
    "impresora_destino": "salida_impresora",  # carpeta, /dev/usb/lp0, 192.168.1.50:9100 o nombre de impresora Windows
    "impresora_ancho": "42",         # caracteres por línea (80 mm ≈ 42/48, 58 mm ≈ 32)
    "cajon_pin": "0",                # 0 = pin 2, 1 = pin 5 del conector RJ11
    "mensaje_ticket": "Conserve este ticket. Gracias por su visita.",
    "backups_mantener": "30",
}


# ------------------------------------------------------------------ versión 2
# Clientes, bonos mensuales, textos de ticket configurables y pagos que pueden
# ser de un ticket (estancia) o de un bono.
SCHEMA_V2 = """
CREATE TABLE IF NOT EXISTS clientes (
    id         INTEGER PRIMARY KEY,
    codigo     TEXT UNIQUE,                 -- contenido del QR / código de barras de su tarjeta
    nombre     TEXT NOT NULL,
    nif        TEXT,
    telefono   TEXT,
    email      TEXT,
    direccion  TEXT,
    notas      TEXT,
    activo     INTEGER NOT NULL DEFAULT 1,
    creado     TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_clientes_nombre ON clientes(nombre);

CREATE TABLE IF NOT EXISTS cliente_matriculas (
    id         INTEGER PRIMARY KEY,
    cliente_id INTEGER NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
    matricula  TEXT NOT NULL UNIQUE           -- una matrícula pertenece a un solo cliente
);

CREATE TABLE IF NOT EXISTS planes_bono (
    id           INTEGER PRIMARY KEY,
    nombre       TEXT NOT NULL,
    descripcion  TEXT,
    precio_cent  INTEGER NOT NULL CHECK (precio_cent >= 0),
    meses        INTEGER NOT NULL DEFAULT 1 CHECK (meses BETWEEN 1 AND 12),
    activo       INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS bonos (
    id             INTEGER PRIMARY KEY,
    cliente_id     INTEGER NOT NULL REFERENCES clientes(id),
    plan_id        INTEGER NOT NULL REFERENCES planes_bono(id),
    desde          TEXT NOT NULL,             -- AAAA-MM-DD (incluido)
    hasta          TEXT NOT NULL,             -- AAAA-MM-DD (incluido)
    importe_cent   INTEGER NOT NULL,
    estado         TEXT NOT NULL DEFAULT 'activo' CHECK (estado IN ('activo','anulado')),
    creado         TEXT NOT NULL,
    usuario_id     INTEGER REFERENCES usuarios(id),
    anulado_motivo TEXT
);
CREATE INDEX IF NOT EXISTS ix_bonos_cliente ON bonos(cliente_id, hasta);

-- pagos: ticket_id pasa a ser opcional y se añade bono_id + concepto
CREATE TABLE pagos_v2 (
    id               INTEGER PRIMARY KEY,
    ticket_id        INTEGER REFERENCES tickets(id),
    bono_id          INTEGER REFERENCES bonos(id),
    concepto         TEXT NOT NULL DEFAULT 'estancia' CHECK (concepto IN ('estancia','bono')),
    turno_id         INTEGER NOT NULL REFERENCES turnos(id),
    usuario_id       INTEGER NOT NULL REFERENCES usuarios(id),
    fecha            TEXT NOT NULL,
    minutos          INTEGER NOT NULL DEFAULT 0,
    importe_cent     INTEGER NOT NULL,
    recargo_cent     INTEGER NOT NULL DEFAULT 0,
    metodo           TEXT NOT NULL CHECK (metodo IN ('efectivo','tarjeta')),
    entregado_cent   INTEGER,
    cambio_cent      INTEGER,
    serie            TEXT NOT NULL,
    numero           INTEGER NOT NULL,
    UNIQUE (serie, numero),
    CHECK ((ticket_id IS NOT NULL) OR (bono_id IS NOT NULL))
);
INSERT INTO pagos_v2(id, ticket_id, concepto, turno_id, usuario_id, fecha, minutos, importe_cent, recargo_cent,
                     metodo, entregado_cent, cambio_cent, serie, numero)
    SELECT id, ticket_id, 'estancia', turno_id, usuario_id, fecha, minutos, importe_cent, recargo_cent,
           metodo, entregado_cent, cambio_cent, serie, numero FROM pagos;
DROP TABLE pagos;
ALTER TABLE pagos_v2 RENAME TO pagos;
CREATE INDEX IF NOT EXISTS ix_pagos_fecha ON pagos(fecha);
CREATE INDEX IF NOT EXISTS ix_pagos_turno ON pagos(turno_id);
CREATE INDEX IF NOT EXISTS ix_pagos_ticket ON pagos(ticket_id);
CREATE INDEX IF NOT EXISTS ix_pagos_bono ON pagos(bono_id);

ALTER TABLE tickets ADD COLUMN cliente_id INTEGER REFERENCES clientes(id);
ALTER TABLE tickets ADD COLUMN bono_id INTEGER REFERENCES bonos(id);
CREATE INDEX IF NOT EXISTS ix_tickets_cliente ON tickets(cliente_id, estado);
"""

CONFIG_V2 = {
    # Aspecto y textos del ticket (Ajustes -> Ticket)
    "ticket_codigo": "ambos",            # qr | barras | ambos
    "ticket_qr_tam": "6",                # tamaño de módulo QR (3-8)
    "ticket_cabecera_invertida": "1",    # nombre en banda negra
    "ticket_cabecera_extra": "Abierto 24 horas",
    "ticket_mostrar_direccion": "1",
    "ticket_mostrar_precio": "0",          # 4.44: el ticket ya no lleva precios
    "ticket_tarifas_url_activo": "0",    # 4.44: en su lugar, una dirección para consultarlos (si se activa)
    "ticket_tarifas_url": "",
    "fichaje_qr_activo": "0",            # 4.49: control de turnos (jornada) por QR personal
    "ticket_entrada_titulo": "TICKET DE ENTRADA",
    "ticket_entrada_pie": "Conserve este ticket y páguelo en caja antes de recoger su vehículo.\n"
                          "En caso de pérdida se aplicará un recargo.",
    "recibo_titulo": "FACTURA SIMPLIFICADA",
    "recibo_salida_texto": "Puede salir hasta las {hora}",
    "recibo_pie": "Gracias por su visita\n¡Buen viaje!",
    "tarjeta_titulo": "TARJETA DE ABONADO",
    "tarjeta_pie": "Personal e intransferible.\nPresente esta tarjeta al entrar y al salir.",
}

PLANES_EJEMPLO = [
    ("Mensual 24 horas", "Acceso ilimitado todos los días", 9000, 1),
    ("Trimestral 24 horas", "Acceso ilimitado, 3 meses", 25000, 3),
]


# ------------------------------------------------------------------ versión 3
# Marca y modelo por vehículo, y tickets introducidos a mano.
SCHEMA_V3 = """
ALTER TABLE cliente_matriculas ADD COLUMN marca TEXT;
ALTER TABLE cliente_matriculas ADD COLUMN modelo TEXT;
ALTER TABLE tickets ADD COLUMN manual INTEGER NOT NULL DEFAULT 0;
ALTER TABLE tickets ADD COLUMN manual_motivo TEXT;
ALTER TABLE tickets ADD COLUMN manual_autoriza_id INTEGER REFERENCES usuarios(id);
"""


# ------------------------------------------------------------------ versión 4
# Servicios y productos que se añaden a la estancia (lavado, agua, recarga...).
SCHEMA_V4 = """
CREATE TABLE IF NOT EXISTS productos (
    id           INTEGER PRIMARY KEY,
    nombre       TEXT NOT NULL,
    tipo         TEXT NOT NULL DEFAULT 'servicio' CHECK (tipo IN ('servicio','producto')),
    precio_cent  INTEGER NOT NULL CHECK (precio_cent >= 0),   -- IVA incluido
    iva_pct      REAL,                                         -- NULL = IVA general de la empresa
    activo       INTEGER NOT NULL DEFAULT 1,
    orden        INTEGER NOT NULL DEFAULT 0
);

-- Líneas añadidas a una estancia. Mientras pago_id es NULL están pendientes de cobro;
-- al cobrar se enlazan con el pago (y su factura).
CREATE TABLE IF NOT EXISTS ticket_extras (
    id           INTEGER PRIMARY KEY,
    ticket_id    INTEGER NOT NULL REFERENCES tickets(id),
    producto_id  INTEGER REFERENCES productos(id),
    nombre       TEXT NOT NULL,              -- copiado: la factura no cambia si luego se edita el catálogo
    tipo         TEXT NOT NULL,
    precio_cent  INTEGER NOT NULL,
    cantidad     INTEGER NOT NULL CHECK (cantidad > 0),
    iva_pct      REAL NOT NULL,
    pago_id      INTEGER REFERENCES pagos(id),
    fecha        TEXT NOT NULL,
    usuario_id   INTEGER REFERENCES usuarios(id)
);
CREATE INDEX IF NOT EXISTS ix_extras_ticket ON ticket_extras(ticket_id);
CREATE INDEX IF NOT EXISTS ix_extras_pago ON ticket_extras(pago_id);

ALTER TABLE pagos ADD COLUMN extras_cent INTEGER NOT NULL DEFAULT 0;   -- parte del importe que son extras
"""

PRODUCTOS_EJEMPLO = [
    ("Lavado exterior", "servicio", 1200, None, 1),
    ("Lavado completo (interior y exterior)", "servicio", 2500, None, 2),
    ("Botella de agua 50 cl", "producto", 150, 10.0, 3),
]


# ------------------------------------------------------------------ versión 5
# Redondeo y texto por tarifa, minutos de parking incluidos en servicios,
# datos del destinatario en facturas y envío por email.
SCHEMA_V5 = """
ALTER TABLE tarifas ADD COLUMN redondeo TEXT NOT NULL DEFAULT 'ninguno';   -- ninguno | cercano | arriba | abajo (a 0,05 €)
ALTER TABLE tarifas ADD COLUMN texto_ticket TEXT;                          -- se imprime en el ticket de entrada
ALTER TABLE productos ADD COLUMN minutos_incluidos INTEGER NOT NULL DEFAULT 0;
ALTER TABLE ticket_extras ADD COLUMN minutos_incluidos INTEGER NOT NULL DEFAULT 0;

-- Datos del cliente que pide factura con sus datos (nombre, NIF, dirección, email)
CREATE TABLE IF NOT EXISTS facturas_destinatario (
    pago_id     INTEGER PRIMARY KEY REFERENCES pagos(id),
    nombre      TEXT NOT NULL,
    nif         TEXT,
    direccion   TEXT,
    email       TEXT,
    cliente_id  INTEGER REFERENCES clientes(id),
    fecha       TEXT NOT NULL,
    usuario_id  INTEGER REFERENCES usuarios(id)
);

-- Cola de envío de facturas por email (se reintenta si no hay conexión)
CREATE TABLE IF NOT EXISTS emails (
    id           INTEGER PRIMARY KEY,
    pago_id      INTEGER NOT NULL REFERENCES pagos(id),
    destino      TEXT NOT NULL,
    estado       TEXT NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('pendiente','enviado','error')),
    intentos     INTEGER NOT NULL DEFAULT 0,
    ultimo_error TEXT,
    creado       TEXT NOT NULL,
    enviado      TEXT,
    usuario_id   INTEGER REFERENCES usuarios(id)
);
CREATE INDEX IF NOT EXISTS ix_emails_estado ON emails(estado);
"""

CONFIG_V5 = {
    "smtp_servidor": "",          # p. ej. smtp.gmail.com
    "smtp_puerto": "587",
    "smtp_seguridad": "starttls", # starttls | ssl | ninguna
    "smtp_usuario": "",
    "smtp_clave": "",
    "smtp_remitente": "",         # dirección que aparece como remitente
    "email_asunto": "Su factura {numero} - {parking}",
    "email_texto": "Hola {nombre}:\n\nLe adjuntamos la factura {numero} de {parking}.\n\nGracias por su visita.",
    "factura_titulo_completa": "FACTURA",
}


class Database:
    """Envoltorio fino sobre sqlite3, seguro para el servidor multihilo."""

    def __init__(self, path):
        self.path = path
        d = os.path.dirname(os.path.abspath(path))
        os.makedirs(d, exist_ok=True)
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.conn.execute("PRAGMA journal_mode = WAL")
        self.conn.execute("PRAGMA synchronous = FULL")
        self._migrar()

    # --- transacciones -------------------------------------------------
    def _migrar_v10(self):
        """Cobros online (Stripe), avisos por email y descripción de servicios en factura."""
        self.conn.execute("PRAGMA foreign_keys = OFF")
        try:
            extra = ""
            cols = lambda t: {r[1] for r in self.conn.execute(f"PRAGMA table_info({t})")}  # noqa: E731
            if "descripcion" not in cols("productos"):
                extra += "ALTER TABLE productos ADD COLUMN descripcion TEXT; "
            if "descripcion" not in cols("ticket_extras"):
                extra += "ALTER TABLE ticket_extras ADD COLUMN descripcion TEXT; "
            if "enviar_facturas" not in cols("clientes"):
                extra += "ALTER TABLE clientes ADD COLUMN enviar_facturas INTEGER NOT NULL DEFAULT 1; "
            for c in ("ref_producto", "ref_precio", "ref_enlace", "url_enlace"):
                if c not in cols("planes_bono"):
                    extra += f"ALTER TABLE planes_bono ADD COLUMN {c} TEXT; "
            if "precio_enlace_cent" not in cols("planes_bono"):
                extra += "ALTER TABLE planes_bono ADD COLUMN precio_enlace_cent INTEGER; "
            rehacer = "" if "online_ref" in cols("pagos") else SCHEMA_V10.split("-- Suscripciones")[0]
            resto = "-- Suscripciones" + SCHEMA_V10.split("-- Suscripciones")[1]
            self.conn.executescript("BEGIN;" + rehacer + resto + extra + "PRAGMA user_version = 10; COMMIT;")
        except Exception:
            if self.conn.in_transaction:
                self.conn.execute("ROLLBACK")
            raise
        finally:
            self.conn.execute("PRAGMA foreign_keys = ON")
        for k, val in CONFIG_V10.items():
            self.conn.execute("INSERT OR IGNORE INTO config(clave, valor) VALUES(?,?)", (k, val))

    def _migrar_v11(self):
        """Numeración configurable (tickets, bonos, facturas), renovación automática de bonos,
        pago único online de renovaciones, ticket perdido y registro encadenado opcionales."""
        cols = lambda t: {r[1] for r in self.conn.execute(f"PRAGMA table_info({t})")}  # noqa: E731
        sql = ""
        if "numero" not in cols("tickets"):
            sql += "ALTER TABLE tickets ADD COLUMN numero INTEGER; UPDATE tickets SET numero=id; "
        if "numero" not in cols("bonos"):
            sql += "ALTER TABLE bonos ADD COLUMN numero INTEGER; UPDATE bonos SET numero=id; "
        if "pagado" not in cols("bonos"):
            sql += "ALTER TABLE bonos ADD COLUMN pagado INTEGER NOT NULL DEFAULT 1; "
        if "renovacion_auto" not in cols("clientes"):
            sql += "ALTER TABLE clientes ADD COLUMN renovacion_auto INTEGER NOT NULL DEFAULT 1; "
        for c in ("ref_precio_unico", "ref_enlace_unico", "url_enlace_unico"):
            if c not in cols("planes_bono"):
                sql += f"ALTER TABLE planes_bono ADD COLUMN {c} TEXT; "
        sql += "CREATE INDEX IF NOT EXISTS ix_tickets_numero ON tickets(numero); "
        self.conn.executescript("BEGIN; " + sql + "PRAGMA user_version = 11; COMMIT;")
        for k, val in (("registro_integridad", "0"), ("ticket_perdido_activo", "1"), ("ticket_prefijo", "PK"),
                       ("ticket_numero_inicial", "1"), ("bono_prefijo", "B"), ("bono_numero_inicial", "1"),
                       ("factura_numero_inicial", "1"), ("renovacion_dias_gracia", "7")):
            self.conn.execute("INSERT OR IGNORE INTO config(clave, valor) VALUES(?,?)", (k, val))

    def _migrar_v12(self):
        """Tienda, Madrid 360, lectores de matrículas y VERI*FACTU (preparados y desactivados)."""
        self.conn.execute("PRAGMA foreign_keys = OFF")
        try:
            sql_pagos = SCHEMA_V12
            fila = self.conn.execute("SELECT sql FROM sqlite_master WHERE name='pagos'").fetchone()
            if fila and "'venta'" in fila[0]:
                sql_pagos = ""
            self.conn.executescript("BEGIN;" + sql_pagos + SCHEMA_V12_TABLAS + "PRAGMA user_version = 12; COMMIT;")
        except Exception:
            if self.conn.in_transaction:
                self.conn.execute("ROLLBACK")
            raise
        finally:
            self.conn.execute("PRAGMA foreign_keys = ON")
        for k, val in CONFIG_V12.items():
            self.conn.execute("INSERT OR IGNORE INTO config(clave, valor) VALUES(?,?)", (k, val))
        self.conn.execute("INSERT OR IGNORE INTO config(clave, valor) VALUES('lpr_token', ?)", (secrets.token_urlsafe(18),))

    def _migrar_v14(self):
        """1.8: pago de bonos por transferencia bancaria (manual)."""
        self.conn.execute("PRAGMA foreign_keys = OFF")
        try:
            fila = self.conn.execute("SELECT sql FROM sqlite_master WHERE name='pagos'").fetchone()
            sql = "" if fila and "'transferencia'" in fila[0] else SCHEMA_V14
            self.conn.executescript("BEGIN;" + sql + "PRAGMA user_version = 14; COMMIT;")
        except Exception:
            if self.conn.in_transaction:
                self.conn.execute("ROLLBACK")
            raise
        finally:
            self.conn.execute("PRAGMA foreign_keys = ON")
        for k, val in (("transferencia_activa", "1"), ("transferencia_iban", ""), ("transferencia_titular", "")):
            self.conn.execute("INSERT OR IGNORE INTO config(clave, valor) VALUES(?,?)", (k, val))

    def _migrar_v19(self):
        """3.9: devoluciones (facturas rectificativas en «pagos»), varios turnos a la vez, bloqueo de PIN,
        sesiones que sobreviven al reinicio, tarifas por horario y descuentos de comercios."""
        cols = {r[1] for r in self.conn.execute("PRAGMA table_info(pagos)")}
        tabla_pagos = ""
        if "rectifica_id" not in cols:
            tabla_pagos = SCHEMA_V19_PAGOS
        tar = {r[1] for r in self.conn.execute("PRAGMA table_info(tarifas)")}
        alter = "".join(f"ALTER TABLE tarifas ADD COLUMN {c}; " for c, n in (
            ("horario_dias TEXT", "horario_dias"), ("horario_desde TEXT", "horario_desde"),
            ("horario_hasta TEXT", "horario_hasta")) if n not in tar)
        if "comercio" not in {r[1] for r in self.conn.execute("PRAGMA table_info(descuentos)")}:
            alter += "ALTER TABLE descuentos ADD COLUMN comercio TEXT; "
        self.conn.execute("PRAGMA foreign_keys = OFF")
        try:
            self.conn.executescript("BEGIN;" + tabla_pagos + alter + """
DROP INDEX IF EXISTS ux_turno_abierto;
CREATE UNIQUE INDEX IF NOT EXISTS ux_turno_abierto_usuario ON turnos(usuario_id) WHERE estado = 'abierto';
CREATE TABLE IF NOT EXISTS sesiones (
    token_hash TEXT PRIMARY KEY,              -- SHA-256 del token (el token no se guarda)
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id),
    creada     TEXT NOT NULL,
    visto      REAL NOT NULL,
    origen     TEXT
);
CREATE TABLE IF NOT EXISTS bloqueos_acceso (
    clave  TEXT PRIMARY KEY,                  -- usuario:<nombre> | ip:<dirección>
    fallos INTEGER NOT NULL DEFAULT 0,
    ultimo TEXT,
    hasta  TEXT                               -- bloqueado hasta esta fecha y hora
);
PRAGMA user_version = 19; COMMIT;""")
        except Exception:
            if self.conn.in_transaction:
                self.conn.execute("ROLLBACK")
            raise
        finally:
            self.conn.execute("PRAGMA foreign_keys = ON")

    def _migrar_v20(self):
        """4.0: rectificación de facturas por sustitución (factura nueva que sustituye a otra, sin cobro)."""
        cols = {r[1] for r in self.conn.execute("PRAGMA table_info(pagos)")}
        sql = "" if "sustituye_id" in cols else SCHEMA_V20_PAGOS
        # las devoluciones pasan a ser opcionales: quien ya las usaba (3.9) las sigue teniendo
        if self.conn.execute("SELECT 1 FROM pagos WHERE concepto='rectificativa' LIMIT 1").fetchone():
            sql += "INSERT OR IGNORE INTO config(clave, valor) VALUES('devoluciones_activo', '1');"
        self.conn.execute("PRAGMA foreign_keys = OFF")
        try:
            self.conn.executescript("BEGIN;" + sql + "PRAGMA user_version = 20; COMMIT;")
        except Exception:
            if self.conn.in_transaction:
                self.conn.execute("ROLLBACK")
            raise
        finally:
            self.conn.execute("PRAGMA foreign_keys = ON")

    def _migrar_v23(self):
        """4.3: reservas de plataformas, zonas, tipo de vehículo, tarifas de evento, estado del vehículo,
        permisos por usuario y pagos desde el móvil."""
        def columnas(t):
            return {r[1] for r in self.conn.execute(f"PRAGMA table_info({t})")}
        alter = ""
        for tabla, cols in (("tarifas", (("tipo_vehiculo", "TEXT"), ("evento_desde", "TEXT"), ("evento_hasta", "TEXT"))),
                            ("tickets", (("tipo_vehiculo", "TEXT"), ("zona_id", "INTEGER"), ("estado_nota", "TEXT"),
                                         ("reserva_prevista_id", "INTEGER"), ("telefono_digital", "TEXT"))),
                            ("usuarios", (("permisos", "TEXT"),))):
            existentes = columnas(tabla)
            for col, tipo in cols:
                if col not in existentes:
                    alter += f"ALTER TABLE {tabla} ADD COLUMN {col} {tipo};"
        self.conn.executescript("BEGIN;" + alter + SCHEMA_V23 + "PRAGMA user_version = 23; COMMIT;")

    def transaccion(self):
        return _Tx(self)

    def q(self, sql, params=()):
        with self._lock:
            return [dict(r) for r in self.conn.execute(sql, params).fetchall()]

    def q1(self, sql, params=()):
        with self._lock:
            r = self.conn.execute(sql, params).fetchone()
            return dict(r) if r else None

    def ex(self, sql, params=()):
        with self._lock:
            return self.conn.execute(sql, params)

    # --- configuración --------------------------------------------------
    def config(self):
        return {r["clave"]: r["valor"] for r in self.q("SELECT clave, valor FROM config")}

    def get_cfg(self, clave, defecto=None):
        r = self.q1("SELECT valor FROM config WHERE clave=?", (clave,))
        return r["valor"] if r else defecto

    def set_cfg(self, clave, valor):
        self.ex("INSERT INTO config(clave, valor) VALUES(?,?) "
                "ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor", (clave, str(valor)))

    # --- migraciones ----------------------------------------------------
    def _migrar(self):
        with self._lock:
            v = self.conn.execute("PRAGMA user_version").fetchone()[0]
            if v < 1:
                self.conn.executescript(SCHEMA)
                for k, val in CONFIG_DEFECTO.items():
                    self.conn.execute("INSERT OR IGNORE INTO config(clave, valor) VALUES(?,?)", (k, val))
                # Secreto para firmar los códigos QR (evita tickets falsificados).
                self.conn.execute("INSERT OR IGNORE INTO config(clave, valor) VALUES('secreto_qr', ?)",
                                  (secrets.token_hex(16),))
                self.conn.execute("PRAGMA user_version = 1")
                v = 1
            if v < 2:
                self.conn.execute("PRAGMA foreign_keys = OFF")
                try:
                    self.conn.executescript("BEGIN;" + SCHEMA_V2 + "PRAGMA user_version = 2; COMMIT;")
                except Exception:
                    if self.conn.in_transaction:
                        self.conn.execute("ROLLBACK")
                    raise
                finally:
                    self.conn.execute("PRAGMA foreign_keys = ON")
                anterior = self.conn.execute("SELECT valor FROM config WHERE clave='mensaje_ticket'").fetchone()
                for k, val in CONFIG_V2.items():
                    if k == "ticket_entrada_pie" and anterior and anterior[0] != CONFIG_DEFECTO["mensaje_ticket"]:
                        val = anterior[0]  # respetar el texto que el cliente ya había personalizado
                    self.conn.execute("INSERT OR IGNORE INTO config(clave, valor) VALUES(?,?)", (k, val))
                if not self.conn.execute("SELECT 1 FROM planes_bono").fetchone():
                    self.conn.executemany("INSERT INTO planes_bono(nombre, descripcion, precio_cent, meses) "
                                          "VALUES(?,?,?,?)", PLANES_EJEMPLO)
            if v < 3:
                self.conn.executescript("BEGIN;" + SCHEMA_V3 + "PRAGMA user_version = 3; COMMIT;")
            if v < 4:
                self.conn.executescript("BEGIN;" + SCHEMA_V4 + "PRAGMA user_version = 4; COMMIT;")
                if not self.conn.execute("SELECT 1 FROM productos").fetchone():
                    self.conn.executemany("INSERT INTO productos(nombre, tipo, precio_cent, iva_pct, orden) "
                                          "VALUES(?,?,?,?,?)", PRODUCTOS_EJEMPLO)
            if v < 5:
                self.conn.executescript("BEGIN;" + SCHEMA_V5 + "PRAGMA user_version = 5; COMMIT;")
                # Corrección: la versión anterior guardaba por error IVA 0 % al crear o editar
                # servicios desde la pantalla sin tocar el IVA. Se vuelve al IVA general.
                n = self.conn.execute("UPDATE productos SET iva_pct=NULL WHERE iva_pct=0").rowcount
                if n:
                    self.conn.execute("INSERT INTO auditoria(fecha, accion, detalle) VALUES(datetime('now','localtime'),"
                                      "'correccion_iva', ?)", (f"{n} servicio(s)/producto(s) con IVA 0 % pasan al IVA general",))
                for k, val in CONFIG_V5.items():
                    self.conn.execute("INSERT OR IGNORE INTO config(clave, valor) VALUES(?,?)", (k, val))
            if v < 6:
                # Arqueo de caja opcional por turno
                cols = {r[1] for r in self.conn.execute("PRAGMA table_info(turnos)")}
                alter = "" if "arqueo" in cols else "ALTER TABLE turnos ADD COLUMN arqueo INTEGER NOT NULL DEFAULT 1; "
                self.conn.executescript("BEGIN; " + alter + "PRAGMA user_version = 6; COMMIT;")
            if v < 7:
                # Clientes de facturación (distintos de los abonados) y borrado de servicios
                alter = ""
                if "tipo" not in {r[1] for r in self.conn.execute("PRAGMA table_info(clientes)")}:
                    alter += ("ALTER TABLE clientes ADD COLUMN tipo TEXT NOT NULL DEFAULT 'abonado' "
                              "CHECK (tipo IN ('abonado','facturacion')); ")
                if "eliminado" not in {r[1] for r in self.conn.execute("PRAGMA table_info(productos)")}:
                    alter += "ALTER TABLE productos ADD COLUMN eliminado INTEGER NOT NULL DEFAULT 0; "
                self.conn.executescript("BEGIN; " + alter + "PRAGMA user_version = 7; COMMIT;")
            if v < 8:
                # Copias del ticket de entrada y ajuste de la hora de entrada (sumar/restar minutos)
                alter = ""
                if "ajuste_min" not in {r[1] for r in self.conn.execute("PRAGMA table_info(tickets)")}:
                    alter = "ALTER TABLE tickets ADD COLUMN ajuste_min INTEGER NOT NULL DEFAULT 0; "
                self.conn.executescript("BEGIN; " + alter + "PRAGMA user_version = 8; COMMIT;")
                for k, val in (("ticket_entrada_copias", "1"), ("entrada_ajuste_max_min", "120")):
                    self.conn.execute("INSERT OR IGNORE INTO config(clave, valor) VALUES(?,?)", (k, val))
            if v < 9:
                # v1.3: borrar tarifas, logo, tema, pantalla de inicio y licencia
                alter = ""
                if "eliminada" not in {r[1] for r in self.conn.execute("PRAGMA table_info(tarifas)")}:
                    alter = "ALTER TABLE tarifas ADD COLUMN eliminada INTEGER NOT NULL DEFAULT 0; "
                self.conn.executescript("BEGIN; " + alter + "PRAGMA user_version = 9; COMMIT;")
                # Fecha de instalación (inicio del periodo de prueba): la del primer ticket si ya se usaba
                primero = self.conn.execute("SELECT MIN(entrada) FROM tickets").fetchone()[0]
                instalacion = (primero or datetime.now().astimezone().isoformat(timespec="seconds"))[:10]
                for k, val in (("logo_ticket", "0"), ("logo_factura", "0"), ("tema", "claro"),
                               ("pantalla_inicio", "entrada"), ("fecha_instalacion", instalacion)):
                    self.conn.execute("INSERT OR IGNORE INTO config(clave, valor) VALUES(?,?)", (k, val))
            if v < 10:
                self._migrar_v10()
            if v < 11:
                self._migrar_v11()
            if v < 12:
                self._migrar_v12()
            if v < 13:
                # 1.7: deudas de abonados canceladas a mano y pagos parciales de bonos
                cols = {r[1] for r in self.conn.execute("PRAGMA table_info(bonos)")}
                alter = ""
                if "cancelado_cent" not in cols:
                    alter += ("ALTER TABLE bonos ADD COLUMN cancelado_cent INTEGER NOT NULL DEFAULT 0; "
                              "ALTER TABLE bonos ADD COLUMN cancelado_motivo TEXT; ")
                self.conn.executescript("BEGIN; " + alter + "PRAGMA user_version = 13; COMMIT;")
            if v < 14:
                self._migrar_v14()
            if v < 15:
                # 2.2: comunicados generales por email a los abonados
                self.conn.executescript("""BEGIN;
CREATE TABLE IF NOT EXISTS comunicados (
    id          INTEGER PRIMARY KEY,
    fecha       TEXT NOT NULL,
    usuario_id  INTEGER REFERENCES usuarios(id),
    asunto      TEXT NOT NULL,
    texto       TEXT NOT NULL,
    filtro      TEXT NOT NULL,
    medio       TEXT NOT NULL,              -- smtp | gmail
    total       INTEGER NOT NULL DEFAULT 0, -- destinatarios con email válido
    enviados    INTEGER NOT NULL DEFAULT 0,
    errores     INTEGER NOT NULL DEFAULT 0,
    sin_email   INTEGER NOT NULL DEFAULT 0,
    estado      TEXT NOT NULL DEFAULT 'enviando'   -- enviando | terminado
);
PRAGMA user_version = 15; COMMIT;""")
            if v < 16:
                # 3.1: fotos de los productos y descuentos
                cols = {r[1] for r in self.conn.execute("PRAGMA table_info(pagos)")}
                alter = "".join(f"ALTER TABLE pagos ADD COLUMN {c}; " for c, n in (
                    ("descuento_cent INTEGER NOT NULL DEFAULT 0", "descuento_cent"), ("descuento_id INTEGER", "descuento_id"),
                    ("descuento_nombre TEXT", "descuento_nombre")) if n not in cols)
                self.conn.executescript("""BEGIN;
CREATE TABLE IF NOT EXISTS producto_fotos (
    producto_id INTEGER PRIMARY KEY REFERENCES productos(id),
    tipo        TEXT NOT NULL,                 -- image/jpeg | image/png
    datos       BLOB NOT NULL,                 -- ya reducida en el navegador (pocos KB)
    actualizado TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS descuentos (
    id        INTEGER PRIMARY KEY,
    nombre    TEXT NOT NULL,
    tipo      TEXT NOT NULL CHECK (tipo IN ('porcentaje','importe','minutos')),
    valor     INTEGER NOT NULL CHECK (valor > 0),   -- % · céntimos · minutos gratis
    ambito    TEXT NOT NULL DEFAULT 'estancia' CHECK (ambito IN ('estancia','tienda','todo')),
    codigo    TEXT,                                 -- opcional: se puede escanear o teclear
    activo    INTEGER NOT NULL DEFAULT 1,
    eliminado INTEGER NOT NULL DEFAULT 0,
    orden     INTEGER NOT NULL DEFAULT 0
);
""" + alter + "PRAGMA user_version = 16; COMMIT;")
            if v < 17:
                # 3.2: vales de descuento imprimibles y publicidad de la pantalla de cliente
                cols = {r[1] for r in self.conn.execute("PRAGMA table_info(pagos)")}
                alter = "" if "vale_id" in cols else "ALTER TABLE pagos ADD COLUMN vale_id INTEGER; "
                self.conn.executescript("""BEGIN;
CREATE TABLE IF NOT EXISTS vales (
    id           INTEGER PRIMARY KEY,
    codigo       TEXT NOT NULL UNIQUE,              -- se imprime en QR / código de barras
    descuento_id INTEGER NOT NULL REFERENCES descuentos(id),
    usos_max     INTEGER,                           -- 1 = un solo uso · NULL = ilimitado
    usos         INTEGER NOT NULL DEFAULT 0,
    caduca       TEXT,                              -- AAAA-MM-DD (incluido) o NULL
    nota         TEXT,
    lote         TEXT NOT NULL,                     -- vales generados juntos
    creado       TEXT NOT NULL,
    usuario_id   INTEGER REFERENCES usuarios(id),
    anulado      TEXT
);
CREATE TABLE IF NOT EXISTS publicidad (
    id          INTEGER PRIMARY KEY,
    titulo      TEXT,
    texto       TEXT,
    tipo        TEXT NOT NULL,
    datos       BLOB NOT NULL,
    orden       INTEGER NOT NULL DEFAULT 0,
    activo      INTEGER NOT NULL DEFAULT 1,
    actualizado TEXT NOT NULL
);
""" + alter + "PRAGMA user_version = 17; COMMIT;")
            if v < 18:
                # 3.5: observaciones en factura, arqueo por billetes y monedas, fotos de vehículos y recordatorios
                cols = lambda t: {r[1] for r in self.conn.execute(f"PRAGMA table_info({t})")}  # noqa: E731
                alter = ""
                if "observaciones" not in cols("facturas_destinatario"):
                    alter += "ALTER TABLE facturas_destinatario ADD COLUMN observaciones TEXT; "
                for c in ("fondo_desglose", "contado_desglose"):
                    if c not in cols("turnos"):
                        alter += f"ALTER TABLE turnos ADD COLUMN {c} TEXT; "
                self.conn.executescript("""BEGIN;
CREATE TABLE IF NOT EXISTS vehiculo_fotos (
    cliente_id  INTEGER NOT NULL REFERENCES clientes(id),
    matricula   TEXT NOT NULL,
    tipo        TEXT NOT NULL,
    datos       BLOB NOT NULL,
    actualizado TEXT NOT NULL,
    PRIMARY KEY (cliente_id, matricula)
);
CREATE TABLE IF NOT EXISTS recordatorios (
    id          INTEGER PRIMARY KEY,
    titulo      TEXT NOT NULL,
    texto       TEXT,
    fecha       TEXT NOT NULL,          -- desde cuándo se muestra
    para        TEXT NOT NULL DEFAULT 'todos',   -- todos | rol:<rol> | usuario:<id>
    creado      TEXT NOT NULL,
    creado_por  INTEGER REFERENCES usuarios(id),
    hecho       TEXT,                   -- fecha en que se marcó como hecho (para todos)
    hecho_por   INTEGER REFERENCES usuarios(id)
);
CREATE TABLE IF NOT EXISTS recordatorio_leidos (
    recordatorio_id INTEGER NOT NULL REFERENCES recordatorios(id),
    usuario_id      INTEGER NOT NULL REFERENCES usuarios(id),
    fecha           TEXT NOT NULL,
    PRIMARY KEY (recordatorio_id, usuario_id)
);
""" + alter + "PRAGMA user_version = 18; COMMIT;")
            if v < 19:
                self._migrar_v19()
            if v < 20:
                self._migrar_v20()
            if v < 21:
                self.conn.executescript("BEGIN;" + SCHEMA_V21 + "PRAGMA user_version = 21; COMMIT;")
            if v < 22:
                cols = {r[1] for r in self.conn.execute("PRAGMA table_info(tarifas)")}
                alter = "" if "modo" in cols else "ALTER TABLE tarifas ADD COLUMN modo TEXT NOT NULL DEFAULT 'tramos';"
                # 4.2: tarifa de reservas / hotel (el tiempo reservado no se cobra; después, la tarifa del parking)
                for col, tipo in (("reserva_modo", "TEXT"), ("reserva_min", "INTEGER"), ("reserva_noches", "INTEGER"),
                                  ("reserva_hora", "TEXT"), ("tarifa_despues_id", "INTEGER")):
                    if col not in cols:
                        alter += f"ALTER TABLE tarifas ADD COLUMN {col} {tipo};"
                cols_t = {r[1] for r in self.conn.execute("PRAGMA table_info(tickets)")}
                for col, tipo in (("reserva_hasta", "TEXT"), ("reserva_ref", "TEXT"), ("reserva_tarifa_id", "INTEGER")):
                    if col not in cols_t:
                        alter += f"ALTER TABLE tickets ADD COLUMN {col} {tipo};"
                # 4.2: devoluciones y rectificación se activan por separado; quien tenía las dos juntas las conserva
                self.conn.executescript("BEGIN;" + alter + "INSERT OR IGNORE INTO config(clave, valor) "
                                        "SELECT 'rectificacion_activo', valor FROM config WHERE clave='devoluciones_activo';"
                                        "PRAGMA user_version = 22; COMMIT;")
            if v < 23:
                self._migrar_v23()
            if v < 24:   # 4.5: color de cada zona
                cols = {r[1] for r in self.conn.execute("PRAGMA table_info(zonas)")}
                self.conn.executescript("BEGIN;" + ("" if "color" in cols else "ALTER TABLE zonas ADD COLUMN color TEXT;")
                                        + "PRAGMA user_version = 24; COMMIT;")
            if v < 25:   # 4.38: «Deja las llaves» (se refleja en el ticket de entrada)
                cols = {r[1] for r in self.conn.execute("PRAGMA table_info(tickets)")}
                self.conn.executescript("BEGIN;" + ("" if "llaves" in cols else "ALTER TABLE tickets ADD COLUMN llaves INTEGER NOT NULL DEFAULT 0;")
                                        + "PRAGMA user_version = 25; COMMIT;")
            if v < 26:   # 4.43: orden de las tarifas y reserva por fecha (con fecha de entrada reservada)
                ct = {r[1] for r in self.conn.execute("PRAGMA table_info(tarifas)")}
                ck = {r[1] for r in self.conn.execute("PRAGMA table_info(tickets)")}
                self.conn.executescript("BEGIN;" + ("" if "orden" in ct else "ALTER TABLE tarifas ADD COLUMN orden INTEGER NOT NULL DEFAULT 0;")
                                        + ("" if "reserva_desde" in ck else "ALTER TABLE tickets ADD COLUMN reserva_desde TEXT;")
                                        + "UPDATE tarifas SET reserva_modo='fecha' WHERE reserva_modo='horas';"
                                        + "PRAGMA user_version = 26; COMMIT;")
            if v < 27:   # 4.44: se quitan los precios de los tickets de entrada (queda la opción de mostrarlos en Ajustes)
                self.conn.executescript("BEGIN;INSERT INTO config(clave, valor) VALUES('ticket_mostrar_precio','0') "
                                        "ON CONFLICT(clave) DO UPDATE SET valor='0';PRAGMA user_version = 27; COMMIT;")
            if v < 28:   # 4.49: usuarios eliminados (archivados), QR personal y fichajes de jornada
                cu = {r[1] for r in self.conn.execute("PRAGMA table_info(usuarios)")}
                self.conn.executescript("BEGIN;" + ("" if "eliminado" in cu else "ALTER TABLE usuarios ADD COLUMN eliminado INTEGER NOT NULL DEFAULT 0;")
                                        + ("" if "qr_token" in cu else "ALTER TABLE usuarios ADD COLUMN qr_token TEXT;")
                                        + "CREATE TABLE IF NOT EXISTS fichajes (id INTEGER PRIMARY KEY, usuario_id INTEGER NOT NULL, entrada TEXT NOT NULL, "
                                          "salida TEXT, origen TEXT, cerrado_por INTEGER);"
                                          "CREATE INDEX IF NOT EXISTS ix_fichajes_usuario ON fichajes(usuario_id, entrada);"
                                        + "PRAGMA user_version = 28; COMMIT;")
            if v < 29:   # 4.50: comentarios internos por matrícula
                self.conn.executescript("BEGIN;CREATE TABLE IF NOT EXISTS notas_vehiculo (matricula TEXT PRIMARY KEY, nota TEXT NOT NULL, "
                                        "usuario_id INTEGER, actualizada TEXT NOT NULL);PRAGMA user_version = 29; COMMIT;")
            if v < 30:   # 4.53: fichajes ligados al turno de caja; los QR anteriores (códigos largos) se sustituyen por los de 12 dígitos
                cf = {r[1] for r in self.conn.execute("PRAGMA table_info(fichajes)")}
                self.conn.executescript("BEGIN;" + ("" if "turno_id" in cf else "ALTER TABLE fichajes ADD COLUMN turno_id INTEGER;")
                                        + "UPDATE usuarios SET qr_token=NULL WHERE qr_token IS NOT NULL;PRAGMA user_version = 30; COMMIT;")
            if v < 31:   # 4.54: descuento fijo en % por cliente (0 = sin descuento)
                cc = {r[1] for r in self.conn.execute("PRAGMA table_info(clientes)")}
                self.conn.executescript("BEGIN;" + ("" if "descuento_pct" in cc else "ALTER TABLE clientes ADD COLUMN descuento_pct REAL NOT NULL DEFAULT 0;")
                                        + "PRAGMA user_version = 31; COMMIT;")
            if v < 32:   # 4.58: clientes proveedor y servicios reservados a proveedores
                cc = {r[1] for r in self.conn.execute("PRAGMA table_info(clientes)")}
                pc = {r[1] for r in self.conn.execute("PRAGMA table_info(productos)")}
                self.conn.executescript("BEGIN;" + ("" if "proveedor" in cc else "ALTER TABLE clientes ADD COLUMN proveedor INTEGER NOT NULL DEFAULT 0;")
                                        + ("" if "solo_proveedor" in pc else "ALTER TABLE productos ADD COLUMN solo_proveedor INTEGER NOT NULL DEFAULT 0;")
                                        + "PRAGMA user_version = 32; COMMIT;")
                # impresora sin tocar (archivo en la carpeta de fábrica) -> en pantalla, para no gastar papel ni acumular archivos
                self.conn.execute("UPDATE config SET valor='pantalla' WHERE clave='impresora_modo' AND valor='archivo' AND "
                                  "COALESCE((SELECT valor FROM config WHERE clave='impresora_destino'), 'salida_impresora')='salida_impresora'")
            if v < 33:   # 4.60: servicios de cada proveedor con su precio personalizado
                self.conn.executescript("BEGIN; CREATE TABLE IF NOT EXISTS proveedor_servicios ("
                                        "cliente_id INTEGER NOT NULL REFERENCES clientes(id) ON DELETE CASCADE, "
                                        "producto_id INTEGER NOT NULL REFERENCES productos(id), precio_cent INTEGER NOT NULL CHECK (precio_cent >= 0), "
                                        "PRIMARY KEY (cliente_id, producto_id)); PRAGMA user_version = 33; COMMIT;")
            if v < 34:   # 4.62: servicios sin precio fijo (el precio se pide al seleccionarlos)
                pc = {r[1] for r in self.conn.execute("PRAGMA table_info(productos)")}
                self.conn.executescript("BEGIN;" + ("" if "precio_variable" in pc else "ALTER TABLE productos ADD COLUMN precio_variable INTEGER NOT NULL DEFAULT 0;")
                                        + "PRAGMA user_version = 34; COMMIT;")
            if v < 35:   # 4.64: estado de cada factura (generada, enviada o cobrada)
                pc = {r[1] for r in self.conn.execute("PRAGMA table_info(pagos)")}
                self.conn.executescript("BEGIN;" + ("" if "estado_factura" in pc else
                    "ALTER TABLE pagos ADD COLUMN estado_factura TEXT NOT NULL DEFAULT 'generada';"
                    "UPDATE pagos SET estado_factura='cobrada' WHERE metodo IN ('efectivo','tarjeta');"
                    "UPDATE pagos SET estado_factura='enviada' WHERE estado_factura='generada' AND id IN (SELECT pago_id FROM emails WHERE estado='enviado');")
                    + "PRAGMA user_version = 35; COMMIT;")
            if v < 36:   # 1.0: versión con la que empezó la instalación (el historial de cambios no se ve más atrás)
                from . import __version__ as _v
                self.conn.executescript("BEGIN; INSERT OR IGNORE INTO config(clave, valor) VALUES('version_inicial', '"
                                        + "".join(ch for ch in str(_v) if ch.isdigit() or ch == ".") + "'); PRAGMA user_version = 36; COMMIT;")
            if v < 37:   # 1.8: reservas online (origen, zona, contacto, código, importe, pago) y cupo online por zona
                cols = {r[1] for r in self.conn.execute("PRAGMA table_info(reservas_previstas)")}
                sql = "BEGIN;"
                for nombre, ddl in (("origen", "TEXT NOT NULL DEFAULT 'plataforma'"), ("zona_id", "INTEGER REFERENCES zonas(id)"),
                                    ("tipo_vehiculo", "TEXT"), ("email", "TEXT"), ("telefono", "TEXT"), ("codigo", "TEXT"),
                                    ("importe_cent", "INTEGER NOT NULL DEFAULT 0"), ("pago", "TEXT NOT NULL DEFAULT 'ninguno'"),
                                    ("cancelada", "TEXT")):
                    if nombre not in cols:
                        sql += f"ALTER TABLE reservas_previstas ADD COLUMN {nombre} {ddl};"
                zc = {r[1] for r in self.conn.execute("PRAGMA table_info(zonas)")}
                if "cupo_online" not in zc:
                    sql += "ALTER TABLE zonas ADD COLUMN cupo_online INTEGER NOT NULL DEFAULT 0;"
                sql += ("CREATE UNIQUE INDEX IF NOT EXISTS ux_reservas_codigo ON reservas_previstas(codigo) WHERE codigo IS NOT NULL;"
                        "PRAGMA user_version = 37; COMMIT;")
                self.conn.executescript(sql)
            if v < 38:   # 1.9: plazas por reserva online
                cols = {r[1] for r in self.conn.execute("PRAGMA table_info(reservas_previstas)")}
                self.conn.executescript("BEGIN;" + ("" if "plazas" in cols else
                                        "ALTER TABLE reservas_previstas ADD COLUMN plazas INTEGER NOT NULL DEFAULT 1;")
                                        + "PRAGMA user_version = 38; COMMIT;")
            if v < 39:   # 1.10: reservas desde la página pública (estado del email de confirmación y aceptación de condiciones)
                cols = {r[1] for r in self.conn.execute("PRAGMA table_info(reservas_previstas)")}
                sql = "BEGIN;"
                for nombre, ddl in (("email_estado", "TEXT"), ("email_intentos", "INTEGER NOT NULL DEFAULT 0"), ("condiciones", "TEXT")):
                    if nombre not in cols:
                        sql += f"ALTER TABLE reservas_previstas ADD COLUMN {nombre} {ddl};"
                self.conn.executescript(sql + "PRAGMA user_version = 39; COMMIT;")
            if v < 40:   # 1.11: reservas de clientes pendientes de que el personal las confirme o cancele (aviso con ventana)
                cols = {r[1] for r in self.conn.execute("PRAGMA table_info(reservas_previstas)")}
                self.conn.executescript("BEGIN;" + ("" if "revisada" in cols else
                                        "ALTER TABLE reservas_previstas ADD COLUMN revisada INTEGER NOT NULL DEFAULT 1;")
                                        + "PRAGMA user_version = 40; COMMIT;")
            if v < 41:   # 1.12: señal / pago anticipado de las reservas online
                cols = {r[1] for r in self.conn.execute("PRAGMA table_info(reservas_previstas)")}
                sql = "BEGIN;"
                for nombre, ddl in (("senal_cent", "INTEGER NOT NULL DEFAULT 0"), ("pago_limite", "TEXT"), ("pago_fecha", "TEXT"), ("pago_metodo", "TEXT")):
                    if nombre not in cols:
                        sql += f"ALTER TABLE reservas_previstas ADD COLUMN {nombre} {ddl};"
                self.conn.executescript(sql + "PRAGMA user_version = 41; COMMIT;")
            if v < 42:   # 1.18: pago online de la señal (Stripe), no presentados, recordatorio y modificaciones
                cols = {r[1] for r in self.conn.execute("PRAGMA table_info(reservas_previstas)")}
                sql = "BEGIN;"
                for nombre, ddl in (("pago_sesion", "TEXT"), ("pago_ref", "TEXT"), ("noshow", "INTEGER NOT NULL DEFAULT 0"),
                                    ("recordatorio", "TEXT"), ("modificada", "TEXT"), ("senal_pago_id", "INTEGER"),
                                    ("senal_devuelta_ref", "TEXT")):
                    if nombre not in cols:
                        sql += f"ALTER TABLE reservas_previstas ADD COLUMN {nombre} {ddl};"
                self.conn.executescript(sql + "PRAGMA user_version = 42; COMMIT;")
            # Futuras migraciones: if v < 43: ... ; PRAGMA user_version = 43


SCHEMA_V23 = """
-- 4.3: reservas que llegan de plataformas (Parclick, ElParking, hoteles…) y se aplican solas al entrar la matrícula
CREATE TABLE IF NOT EXISTS reservas_previstas (
    id          INTEGER PRIMARY KEY,
    matricula   TEXT NOT NULL,
    desde       TEXT NOT NULL,
    hasta       TEXT NOT NULL,
    ref         TEXT,
    plataforma  TEXT,
    cliente     TEXT,
    nota        TEXT,
    tarifa_id   INTEGER REFERENCES tarifas(id),
    estado      TEXT NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('pendiente','usada','cancelada')),
    ticket_id   INTEGER REFERENCES tickets(id),
    creada      TEXT NOT NULL,
    usuario_id  INTEGER REFERENCES usuarios(id),
    lote        TEXT
);
CREATE INDEX IF NOT EXISTS ix_reservas_prev_mat ON reservas_previstas(matricula, estado);
CREATE TABLE IF NOT EXISTS zonas (
    id        INTEGER PRIMARY KEY,
    nombre    TEXT NOT NULL,
    capacidad INTEGER NOT NULL DEFAULT 0,
    orden     INTEGER NOT NULL DEFAULT 0,
    activa    INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS ticket_fotos (
    id         INTEGER PRIMARY KEY,
    ticket_id  INTEGER NOT NULL REFERENCES tickets(id),
    archivo    TEXT NOT NULL,
    fecha      TEXT NOT NULL,
    usuario_id INTEGER REFERENCES usuarios(id)
);
CREATE TABLE IF NOT EXISTS pagos_movil (
    id          INTEGER PRIMARY KEY,
    ticket_id   INTEGER NOT NULL REFERENCES tickets(id),
    sesion      TEXT NOT NULL UNIQUE,
    importe_cent INTEGER NOT NULL,
    calculo_en  TEXT NOT NULL,
    creada      TEXT NOT NULL,
    estado      TEXT NOT NULL DEFAULT 'pendiente',   -- pendiente | pagado | caducado | error
    pago_id     INTEGER REFERENCES pagos(id),
    detalle     TEXT
);
"""


SCHEMA_V21 = """
-- 4.1: lista negra de matrículas y accesos a aplicaciones externas desde el menú lateral
CREATE TABLE IF NOT EXISTS lista_negra (
    id         INTEGER PRIMARY KEY,
    matricula  TEXT NOT NULL,                 -- normalizada (sin espacios ni guiones, en mayúsculas)
    motivo     TEXT NOT NULL,
    nota       TEXT,
    creada     TEXT NOT NULL,
    usuario_id INTEGER REFERENCES usuarios(id),
    activa     INTEGER NOT NULL DEFAULT 1,
    retirada   TEXT,
    retirada_por INTEGER REFERENCES usuarios(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_lista_negra_activa ON lista_negra(matricula) WHERE activa=1;
CREATE TABLE IF NOT EXISTS apps_externas (
    id         INTEGER PRIMARY KEY,
    nombre     TEXT NOT NULL,
    tipo       TEXT NOT NULL CHECK (tipo IN ('web','programa')),
    destino    TEXT NOT NULL,                 -- URL o ruta del programa / documento / carpeta
    argumentos TEXT,
    icono      TEXT,
    color      TEXT,
    roles      TEXT NOT NULL DEFAULT 'admin,supervisor,cajero',
    orden      INTEGER NOT NULL DEFAULT 0,
    activa     INTEGER NOT NULL DEFAULT 1
);
"""


SCHEMA_V10 = """
-- pagos: admite cobros online (sin turno de caja ni cajero) y guarda la factura de Stripe
CREATE TABLE pagos_v10 (
    id               INTEGER PRIMARY KEY,
    ticket_id        INTEGER REFERENCES tickets(id),
    bono_id          INTEGER REFERENCES bonos(id),
    concepto         TEXT NOT NULL DEFAULT 'estancia' CHECK (concepto IN ('estancia','bono')),
    turno_id         INTEGER REFERENCES turnos(id),          -- NULL = cobro online
    usuario_id       INTEGER REFERENCES usuarios(id),        -- NULL = cobro online
    fecha            TEXT NOT NULL,
    minutos          INTEGER NOT NULL DEFAULT 0,
    importe_cent     INTEGER NOT NULL,
    recargo_cent     INTEGER NOT NULL DEFAULT 0,
    metodo           TEXT NOT NULL CHECK (metodo IN ('efectivo','tarjeta','online')),
    entregado_cent   INTEGER,
    cambio_cent      INTEGER,
    serie            TEXT NOT NULL,
    numero           INTEGER NOT NULL,
    extras_cent      INTEGER NOT NULL DEFAULT 0,
    online_ref       TEXT UNIQUE,                            -- id de la factura en la plataforma de pago
    UNIQUE (serie, numero),
    CHECK ((ticket_id IS NOT NULL) OR (bono_id IS NOT NULL))
);
INSERT INTO pagos_v10(id, ticket_id, bono_id, concepto, turno_id, usuario_id, fecha, minutos, importe_cent, recargo_cent,
                      metodo, entregado_cent, cambio_cent, serie, numero, extras_cent)
    SELECT id, ticket_id, bono_id, concepto, turno_id, usuario_id, fecha, minutos, importe_cent, recargo_cent,
           metodo, entregado_cent, cambio_cent, serie, numero, extras_cent FROM pagos;
DROP TABLE pagos;
ALTER TABLE pagos_v10 RENAME TO pagos;
CREATE INDEX IF NOT EXISTS ix_pagos_fecha ON pagos(fecha);
CREATE INDEX IF NOT EXISTS ix_pagos_turno ON pagos(turno_id);
CREATE INDEX IF NOT EXISTS ix_pagos_ticket ON pagos(ticket_id);
CREATE INDEX IF NOT EXISTS ix_pagos_bono ON pagos(bono_id);

-- Suscripciones de abonados con cargo automático (Stripe)
CREATE TABLE IF NOT EXISTS suscripciones (
    id                 INTEGER PRIMARY KEY,
    cliente_id         INTEGER NOT NULL REFERENCES clientes(id),
    plan_id            INTEGER NOT NULL REFERENCES planes_bono(id),
    ref_suscripcion    TEXT NOT NULL UNIQUE,     -- sub_... en Stripe
    ref_cliente        TEXT,                     -- cus_... en Stripe
    estado             TEXT NOT NULL DEFAULT 'activa'
                       CHECK (estado IN ('activa','impagada','cancelada','incompleta')),
    periodo_fin        TEXT,
    cancelar_al_final  INTEGER NOT NULL DEFAULT 0,
    creada             TEXT NOT NULL,
    actualizada        TEXT
);
CREATE INDEX IF NOT EXISTS ix_suscripciones_cliente ON suscripciones(cliente_id);

-- Avisos enviados por email (para no repetirlos)
CREATE TABLE IF NOT EXISTS avisos (
    id          INTEGER PRIMARY KEY,
    cliente_id  INTEGER REFERENCES clientes(id),
    tipo        TEXT NOT NULL,          -- caducidad | pago_pendiente | factura
    referencia  TEXT NOT NULL,
    destino     TEXT,
    fecha       TEXT NOT NULL,
    estado      TEXT NOT NULL DEFAULT 'enviado',
    detalle     TEXT,
    UNIQUE (tipo, referencia)
);
"""

SCHEMA_V12 = """
-- pagos: admite ventas de tienda (sin ticket ni bono)
CREATE TABLE pagos_v12 (
    id               INTEGER PRIMARY KEY,
    ticket_id        INTEGER REFERENCES tickets(id),
    bono_id          INTEGER REFERENCES bonos(id),
    concepto         TEXT NOT NULL DEFAULT 'estancia' CHECK (concepto IN ('estancia','bono','venta')),
    turno_id         INTEGER REFERENCES turnos(id),
    usuario_id       INTEGER REFERENCES usuarios(id),
    fecha            TEXT NOT NULL,
    minutos          INTEGER NOT NULL DEFAULT 0,
    importe_cent     INTEGER NOT NULL,
    recargo_cent     INTEGER NOT NULL DEFAULT 0,
    metodo           TEXT NOT NULL CHECK (metodo IN ('efectivo','tarjeta','online')),
    entregado_cent   INTEGER,
    cambio_cent      INTEGER,
    serie            TEXT NOT NULL,
    numero           INTEGER NOT NULL,
    extras_cent      INTEGER NOT NULL DEFAULT 0,
    online_ref       TEXT UNIQUE,
    UNIQUE (serie, numero),
    CHECK ((ticket_id IS NOT NULL) OR (bono_id IS NOT NULL) OR concepto = 'venta')
);
INSERT INTO pagos_v12 SELECT id, ticket_id, bono_id, concepto, turno_id, usuario_id, fecha, minutos, importe_cent,
    recargo_cent, metodo, entregado_cent, cambio_cent, serie, numero, extras_cent, online_ref FROM pagos;
DROP TABLE pagos;
ALTER TABLE pagos_v12 RENAME TO pagos;
CREATE INDEX IF NOT EXISTS ix_pagos_fecha ON pagos(fecha);
CREATE INDEX IF NOT EXISTS ix_pagos_turno ON pagos(turno_id);
CREATE INDEX IF NOT EXISTS ix_pagos_ticket ON pagos(ticket_id);
CREATE INDEX IF NOT EXISTS ix_pagos_bono ON pagos(bono_id);
"""

SCHEMA_V19_PAGOS = """
-- pagos: admite facturas rectificativas (devoluciones): importe negativo, concepto 'rectificativa'
CREATE TABLE pagos_v19 (
    id               INTEGER PRIMARY KEY,
    ticket_id        INTEGER REFERENCES tickets(id),
    bono_id          INTEGER REFERENCES bonos(id),
    concepto         TEXT NOT NULL DEFAULT 'estancia' CHECK (concepto IN ('estancia','bono','venta','rectificativa')),
    turno_id         INTEGER REFERENCES turnos(id),
    usuario_id       INTEGER REFERENCES usuarios(id),
    fecha            TEXT NOT NULL,
    minutos          INTEGER NOT NULL DEFAULT 0,
    importe_cent     INTEGER NOT NULL,
    recargo_cent     INTEGER NOT NULL DEFAULT 0,
    metodo           TEXT NOT NULL CHECK (metodo IN ('efectivo','tarjeta','online','transferencia')),
    entregado_cent   INTEGER,
    cambio_cent      INTEGER,
    serie            TEXT NOT NULL,
    numero           INTEGER NOT NULL,
    extras_cent      INTEGER NOT NULL DEFAULT 0,
    online_ref       TEXT UNIQUE,
    referencia       TEXT,
    descuento_cent   INTEGER NOT NULL DEFAULT 0,
    descuento_id     INTEGER,
    descuento_nombre TEXT,
    vale_id          INTEGER,
    rectifica_id     INTEGER REFERENCES pagos(id),
    motivo           TEXT,
    UNIQUE (serie, numero),
    CHECK ((ticket_id IS NOT NULL) OR (bono_id IS NOT NULL) OR concepto IN ('venta','rectificativa'))
);
INSERT INTO pagos_v19 SELECT id, ticket_id, bono_id, concepto, turno_id, usuario_id, fecha, minutos, importe_cent,
    recargo_cent, metodo, entregado_cent, cambio_cent, serie, numero, extras_cent, online_ref, referencia,
    descuento_cent, descuento_id, descuento_nombre, vale_id, NULL, NULL FROM pagos;
DROP TABLE pagos;
ALTER TABLE pagos_v19 RENAME TO pagos;
CREATE INDEX IF NOT EXISTS ix_pagos_fecha ON pagos(fecha);
CREATE INDEX IF NOT EXISTS ix_pagos_turno ON pagos(turno_id);
CREATE INDEX IF NOT EXISTS ix_pagos_ticket ON pagos(ticket_id);
CREATE INDEX IF NOT EXISTS ix_pagos_bono ON pagos(bono_id);
CREATE INDEX IF NOT EXISTS ix_pagos_rectifica ON pagos(rectifica_id);
"""

SCHEMA_V20_PAGOS = """
-- pagos: facturas que sustituyen a otras (rectificación por sustitución) y tipo de rectificación
CREATE TABLE pagos_v20 (
    id               INTEGER PRIMARY KEY,
    ticket_id        INTEGER REFERENCES tickets(id),
    bono_id          INTEGER REFERENCES bonos(id),
    concepto         TEXT NOT NULL DEFAULT 'estancia' CHECK (concepto IN ('estancia','bono','venta','rectificativa','sustitutiva')),
    turno_id         INTEGER REFERENCES turnos(id),
    usuario_id       INTEGER REFERENCES usuarios(id),
    fecha            TEXT NOT NULL,
    minutos          INTEGER NOT NULL DEFAULT 0,
    importe_cent     INTEGER NOT NULL,
    recargo_cent     INTEGER NOT NULL DEFAULT 0,
    metodo           TEXT NOT NULL CHECK (metodo IN ('efectivo','tarjeta','online','transferencia')),
    entregado_cent   INTEGER,
    cambio_cent      INTEGER,
    serie            TEXT NOT NULL,
    numero           INTEGER NOT NULL,
    extras_cent      INTEGER NOT NULL DEFAULT 0,
    online_ref       TEXT UNIQUE,
    referencia       TEXT,
    descuento_cent   INTEGER NOT NULL DEFAULT 0,
    descuento_id     INTEGER,
    descuento_nombre TEXT,
    vale_id          INTEGER,
    rectifica_id     INTEGER REFERENCES pagos(id),
    motivo           TEXT,
    rectificacion    TEXT,                              -- diferencias (devolución) | sustitucion
    sustituye_id     INTEGER REFERENCES pagos(id),      -- factura sustitutiva: la que corrige
    UNIQUE (serie, numero),
    CHECK ((ticket_id IS NOT NULL) OR (bono_id IS NOT NULL) OR concepto IN ('venta','rectificativa','sustitutiva'))
);
INSERT INTO pagos_v20 SELECT id, ticket_id, bono_id, concepto, turno_id, usuario_id, fecha, minutos, importe_cent,
    recargo_cent, metodo, entregado_cent, cambio_cent, serie, numero, extras_cent, online_ref, referencia,
    descuento_cent, descuento_id, descuento_nombre, vale_id, rectifica_id, motivo,
    CASE WHEN concepto='rectificativa' THEN 'diferencias' END, NULL FROM pagos;
DROP TABLE pagos;
ALTER TABLE pagos_v20 RENAME TO pagos;
CREATE INDEX IF NOT EXISTS ix_pagos_fecha ON pagos(fecha);
CREATE INDEX IF NOT EXISTS ix_pagos_turno ON pagos(turno_id);
CREATE INDEX IF NOT EXISTS ix_pagos_ticket ON pagos(ticket_id);
CREATE INDEX IF NOT EXISTS ix_pagos_bono ON pagos(bono_id);
CREATE INDEX IF NOT EXISTS ix_pagos_rectifica ON pagos(rectifica_id);
CREATE INDEX IF NOT EXISTS ix_pagos_sustituye ON pagos(sustituye_id);
"""

SCHEMA_V14 = """
-- pagos: admite la transferencia bancaria (registrada a mano) y su referencia
CREATE TABLE pagos_v14 (
    id               INTEGER PRIMARY KEY,
    ticket_id        INTEGER REFERENCES tickets(id),
    bono_id          INTEGER REFERENCES bonos(id),
    concepto         TEXT NOT NULL DEFAULT 'estancia' CHECK (concepto IN ('estancia','bono','venta')),
    turno_id         INTEGER REFERENCES turnos(id),
    usuario_id       INTEGER REFERENCES usuarios(id),
    fecha            TEXT NOT NULL,
    minutos          INTEGER NOT NULL DEFAULT 0,
    importe_cent     INTEGER NOT NULL,
    recargo_cent     INTEGER NOT NULL DEFAULT 0,
    metodo           TEXT NOT NULL CHECK (metodo IN ('efectivo','tarjeta','online','transferencia')),
    entregado_cent   INTEGER,
    cambio_cent      INTEGER,
    serie            TEXT NOT NULL,
    numero           INTEGER NOT NULL,
    extras_cent      INTEGER NOT NULL DEFAULT 0,
    online_ref       TEXT UNIQUE,
    referencia       TEXT,
    UNIQUE (serie, numero),
    CHECK ((ticket_id IS NOT NULL) OR (bono_id IS NOT NULL) OR concepto = 'venta')
);
INSERT INTO pagos_v14 SELECT id, ticket_id, bono_id, concepto, turno_id, usuario_id, fecha, minutos, importe_cent,
    recargo_cent, metodo, entregado_cent, cambio_cent, serie, numero, extras_cent, online_ref, NULL FROM pagos;
DROP TABLE pagos;
ALTER TABLE pagos_v14 RENAME TO pagos;
CREATE INDEX IF NOT EXISTS ix_pagos_fecha ON pagos(fecha);
CREATE INDEX IF NOT EXISTS ix_pagos_turno ON pagos(turno_id);
CREATE INDEX IF NOT EXISTS ix_pagos_ticket ON pagos(ticket_id);
CREATE INDEX IF NOT EXISTS ix_pagos_bono ON pagos(bono_id);
"""

SCHEMA_V12_TABLAS = """
-- Tienda: líneas de una venta sin estancia
CREATE TABLE IF NOT EXISTS ventas_lineas (
    id           INTEGER PRIMARY KEY,
    pago_id      INTEGER NOT NULL REFERENCES pagos(id),
    producto_id  INTEGER REFERENCES productos(id),
    nombre       TEXT NOT NULL,
    tipo         TEXT NOT NULL DEFAULT 'producto',
    descripcion  TEXT,
    precio_cent  INTEGER NOT NULL,
    cantidad     INTEGER NOT NULL,
    iva_pct      REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_ventas_pago ON ventas_lineas(pago_id);

-- Madrid 360 (ZBE Distrito Centro): listado diario de matrículas comunicado al Ayuntamiento
CREATE TABLE IF NOT EXISTS m360_envios (
    id         INTEGER PRIMARY KEY,
    dia        TEXT NOT NULL UNIQUE,      -- AAAA-MM-DD
    matriculas INTEGER NOT NULL,
    contenido  TEXT NOT NULL,
    modo       TEXT NOT NULL,             -- manual | automatico
    estado     TEXT NOT NULL,             -- generado | enviado | error
    fecha      TEXT NOT NULL,
    detalle    TEXT
);

-- Lecturas de los lectores de matrículas por cámara (LPR/ANPR)
CREATE TABLE IF NOT EXISTS lpr_lecturas (
    id         INTEGER PRIMARY KEY,
    fecha      TEXT NOT NULL,
    camara     TEXT NOT NULL,             -- entrada | salida
    matricula  TEXT NOT NULL,
    confianza  REAL,
    origen     TEXT,
    resultado  TEXT
);
CREATE INDEX IF NOT EXISTS ix_lpr_fecha ON lpr_lecturas(fecha);

-- VERI*FACTU: registros de facturación (alta) con huella encadenada según la Orden HAC/1177/2024
CREATE TABLE IF NOT EXISTS verifactu_registros (
    id                INTEGER PRIMARY KEY,
    pago_id           INTEGER NOT NULL UNIQUE REFERENCES pagos(id),
    num_serie         TEXT NOT NULL,
    fecha_expedicion  TEXT NOT NULL,      -- dd-mm-aaaa
    tipo_factura      TEXT NOT NULL,      -- F1 completa | F2 simplificada
    cuota_cent        INTEGER NOT NULL,
    importe_cent      INTEGER NOT NULL,
    huella_anterior   TEXT,
    huella            TEXT NOT NULL,
    fecha_generacion  TEXT NOT NULL,      -- FechaHoraHusoGenRegistro
    xml               TEXT NOT NULL,
    estado            TEXT NOT NULL DEFAULT 'pendiente',   -- pendiente | enviado | error
    respuesta         TEXT,
    enviado           TEXT
);
"""

CONFIG_V12 = {
    "m360_activo": "0", "m360_codigo": "", "m360_modo": "manual", "m360_url": "", "m360_usuario": "",
    "m360_clave": "", "m360_hora_envio": "23:30",
    "lpr_activo": "0", "lpr_entrada_accion": "sugerir", "lpr_salida_accion": "sugerir", "lpr_confianza_min": "80",
    "verifactu_activo": "0", "verifactu_entorno": "pruebas", "verifactu_envio": "0",
}


CONFIG_V10 = {
    "stripe_clave": "",
    "pagos_online_activo": "0",
    "avisos_activos": "1",
    "avisos_caducidad_dias": "5",
    "facturas_bono_email": "1",
}


class _Tx:
    """with db.transaccion() as c: ...  -> BEGIN IMMEDIATE / COMMIT / ROLLBACK"""

    def __init__(self, db):
        self.db = db

    def __enter__(self):
        self.db._lock.acquire()
        self.db.conn.execute("BEGIN IMMEDIATE")
        return self.db.conn

    def __exit__(self, exc_type, exc, tb):
        try:
            if exc_type:
                self.db.conn.execute("ROLLBACK")
            else:
                self.db.conn.execute("COMMIT")
        finally:
            self.db._lock.release()
        return False
