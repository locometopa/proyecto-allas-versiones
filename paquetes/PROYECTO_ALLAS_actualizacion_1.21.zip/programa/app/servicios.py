"""Lógica de negocio del parking. El servidor HTTP solo traduce peticiones a estos métodos.

Todas las operaciones que cambian dinero o estado van en una transacción
(BEGIN IMMEDIATE) y dejan rastro en 'auditoria'.

1.4: la clase Parking se reparte en mezclas por áreas (svc_*.py); aquí queda su núcleo y la unión de todas.
"""
import csv  # noqa: F401  (los módulos y las pruebas acceden a estos nombres como servicios.X)
import hashlib  # noqa: F401
import hmac  # noqa: F401
import io  # noqa: F401
import json  # noqa: F401
import re  # noqa: F401
import os
import secrets  # noqa: F401
from datetime import date, datetime, timedelta  # noqa: F401

from . import impresion  # noqa: F401
from . import logo as logos  # noqa: F401
from .tarifas import REDONDEOS, calcular_importe, minutos_estancia, validar_tramos  # noqa: F401
from . import errores  # noqa: F401
from .funciones43 import Funciones43
from .funciones44 import Funciones44
from .funciones45 import Funciones45
from .funciones49 import Funciones49
from .funciones50 import Funciones50
from .svc_sistema import SvcSistema
from .svc_licencia import SvcLicencia
from .svc_usuarios import SvcUsuarios
from .svc_tarifas import SvcTarifas
from .svc_caja import SvcCaja
from .svc_tickets import SvcTickets
from .svc_catalogo import SvcCatalogo
from .svc_equipos import SvcEquipos
from .svc_facturas import SvcFacturas
from .svc_integraciones import SvcIntegraciones
from .svc_clientes import SvcClientes
from .svc_avisos import SvcAvisos
from .svc_online import SvcOnline
from .svc_documentos import SvcDocumentos
from .svc_tablas import SvcTablas
from .svc_reservas import SvcReservas
from .svc_horario import SvcHorario
from .svc_reservas_publicas import SvcReservasPublicas
from .svc_reservas_despues import SvcReservasDespues
from .svc_reservas_pago import SvcReservasPago
from .utiles import (  # noqa: F401  (se vuelven a exportar: otros módulos las importan de aquí)
    texto_metodo, ErrorNegocio, ROLES_SUPERVISION, _norm_txt, eur, hash_pin, iso, parse, norm_matricula, desglose_iva,
    _plantilla, email_valido, nif_valido, _partir_txt, texto_duracion, duracion_corta, desc_vehiculo, fecha_es, DIAS,
    MESES, fecha_larga, sumar_meses,
)


class Parking(SvcSistema, SvcLicencia, SvcUsuarios, SvcTarifas, SvcCaja, SvcTickets, SvcCatalogo, SvcEquipos, SvcFacturas,
              SvcIntegraciones, SvcClientes, SvcAvisos, SvcOnline, SvcDocumentos, SvcTablas, SvcReservas, SvcHorario, SvcReservasPublicas, SvcReservasDespues, SvcReservasPago,
              Funciones50, Funciones49, Funciones45, Funciones44, Funciones43):
    def __init__(self, db, reloj=None, demo=False, licencia_real=None):
        self.db = db
        self.reloj = reloj or (lambda: datetime.now().astimezone().replace(microsecond=0))
        self.demo = demo   # 3.4: base de demostración (la decide run.py por la carpeta, nunca un dato de la base)
        # 3.5: en la demo manda la licencia (o la prueba) de los datos reales: (serial, fecha_instalacion)
        self.licencia_real = licencia_real

    # =========================================================== utilidades
    @property
    def carpeta_datos(self):
        return os.path.dirname(os.path.abspath(self.db.path))

    def ahora(self):
        return self.reloj()

    def auditar(self, c, usuario_id, accion, detalle=""):
        c.execute("INSERT INTO auditoria(fecha, usuario_id, accion, detalle) VALUES(?,?,?,?)",
                  (iso(self.ahora()), usuario_id, accion, detalle))

    def cfg(self, clave, tipo=str):
        v = self.db.get_cfg(clave)
        return tipo(v) if v is not None else None
