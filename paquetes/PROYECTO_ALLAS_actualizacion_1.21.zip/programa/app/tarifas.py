"""Motor de tarifas. Funciones puras, sin acceso a base de datos (fáciles de probar).

Modelo:
  - gracia_min: si la estancia total es <= gracia, el importe es 0.
  - tramos: lista de dicts {desde_min, hasta_min|None, fraccion_min, precio_mil}.
    Cada minuto de estancia cae en un tramo; se cobran fracciones iniciadas.
  - maximo_diario_cent: tope por cada bloque de 24 h desde la entrada.

La Ley 40/2002 (modif. Ley 44/2006) exige en España cobrar por minuto efectivo:
por eso la tarifa por defecto usa fracción de 1 minuto.
"""
import math
from datetime import datetime

MIN_DIA = 24 * 60


def minutos_estancia(entrada: datetime, salida: datetime) -> int:
    """Minutos iniciados (redondeo hacia arriba). Nunca negativo."""
    seg = (salida - entrada).total_seconds()
    if seg <= 0:
        return 0
    return math.ceil(seg / 60)


def _coste_mil(minutos: int, tramos: list) -> int:
    """Coste en milésimas de euro de 'minutos' dentro de un mismo día."""
    total = 0
    for t in sorted(tramos, key=lambda x: x["desde_min"]):
        desde = t["desde_min"]
        hasta = t["hasta_min"] if t["hasta_min"] is not None else math.inf
        if minutos <= desde:
            break
        en_tramo = min(minutos, hasta) - desde
        fracciones = math.ceil(en_tramo / t["fraccion_min"])
        total += fracciones * t["precio_mil"]
    return total


def _mil_a_cent(mil: int) -> int:
    """Redondeo comercial (mitad hacia arriba) de milésimas a céntimos."""
    return (mil + 5) // 10


REDONDEOS = ("ninguno", "cercano", "arriba", "abajo")


def redondear_5(cent: int, modo: str) -> int:
    """Redondea a múltiplos de 5 céntimos (importes acabados en 0 o 5).
    cercano: 2,72 -> 2,70 · 2,73 -> 2,75 | arriba: 2,71 -> 2,75 | abajo: 2,74 -> 2,70"""
    if not modo or modo == "ninguno" or cent % 5 == 0:
        return cent
    if modo == "arriba":
        return cent + (5 - cent % 5)
    if modo == "abajo":
        return cent - cent % 5
    return (cent + 2) // 5 * 5  # cercano: 1-2 céntimos hacia abajo, 3-4 hacia arriba


def calcular_importe(minutos: int, tarifa: dict, tramos: list) -> int:
    """Importe en céntimos para una estancia de 'minutos' (con el redondeo de la tarifa)."""
    return redondear_5(_importe_sin_redondeo(minutos, tarifa, tramos), tarifa.get("redondeo") or "ninguno")


def _importe_sin_redondeo(minutos: int, tarifa: dict, tramos: list) -> int:
    if minutos <= 0 or minutos <= (tarifa.get("gracia_min") or 0):
        return 0
    tope = tarifa.get("maximo_diario_cent")
    dias, resto = divmod(minutos, MIN_DIA)
    coste_dia_completo = _mil_a_cent(_coste_mil(MIN_DIA, tramos))
    coste_resto = _mil_a_cent(_coste_mil(resto, tramos))
    if tope is not None:
        coste_dia_completo = min(coste_dia_completo, tope)
        coste_resto = min(coste_resto, tope)
    return dias * coste_dia_completo + coste_resto


def validar_tramos(tramos: list) -> None:
    """Lanza ValueError si los tramos no son contiguos desde el minuto 0."""
    if not tramos:
        raise ValueError("La tarifa necesita al menos un tramo")
    ts = sorted(tramos, key=lambda x: x["desde_min"])
    if ts[0]["desde_min"] != 0:
        raise ValueError("El primer tramo debe empezar en el minuto 0")
    for a, b in zip(ts, ts[1:]):
        if a["hasta_min"] is None or a["hasta_min"] != b["desde_min"]:
            raise ValueError("Los tramos deben ser contiguos (el 'hasta' de uno = 'desde' del siguiente)")
    if ts[-1]["hasta_min"] is not None:
        raise ValueError("El último tramo debe quedar abierto (sin 'hasta')")
    for t in ts:
        if t["fraccion_min"] <= 0 or t["precio_mil"] < 0:
            raise ValueError("Fracción debe ser > 0 y precio >= 0")
        if t["hasta_min"] is not None and t["hasta_min"] <= t["desde_min"]:
            raise ValueError("'hasta' debe ser mayor que 'desde'")
