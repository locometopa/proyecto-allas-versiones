"""PROYECTO ALLAS 1.8 · rutas de las reservas online (todas con sesión; el interruptor está en Ajustes → Reservas online)."""

import os

from .utiles import ErrorNegocio


def registrar(app, r, p):
    from .server import Respuesta

    @r("GET", "/api/reservas-online/estado")
    def estado(req):
        return {"activas": p.reservas_online_activas(), "max_plazas": p._ajuste_res("reservas_max_plazas")}

    @r("GET", "/api/reservas-online/config", rol=("admin",))
    def config(req):
        return p.config_reservas_online()

    @r("PUT", "/api/reservas-online/config", rol=("admin",))
    def config_guardar(req):
        res = p.guardar_config_reservas_online(req.usuario, req.body)
        app.agente.reiniciar()   # 1.18: aplica al momento los ajustes del servidor en la nube
        return res

    @r("GET", "/api/reservas-online/resumen")
    def resumen(req):
        p._exigir_reservas_online()
        return p.resumen_reservas_online()

    @r("GET", "/api/reservas-online/disponibilidad")
    def disponibilidad(req):
        q = req.query
        return p.disponibilidad_reservas(q.get("zona_id") or None, q.get("desde"), q.get("hasta"), plazas=q.get("plazas") or 1)

    @r("GET", "/api/reservas-online/calendario")
    def calendario(req):
        q = req.query
        return p.calendario_reservas(q.get("zona_id") or None, q.get("desde"), q.get("dias") or 31)

    @r("POST", "/api/reservas-online/presupuesto")
    def presupuesto(req):
        return p.presupuesto_reserva(req.body)

    @r("POST", "/api/reservas-online")
    def crear(req):
        return p.crear_reserva_online(req.usuario, req.body)

    # --- 1.11: avisos al personal (reserva de un vehículo o de un código QR; reservas nuevas de clientes)
    @r("GET", "/api/reservas-online/aviso")
    def aviso(req):
        return p.aviso_reserva(req.query.get("q"))

    @r("GET", "/api/reservas-online/por-revisar")
    def por_revisar(req):
        p._exigir_permiso(req.usuario, "reservas")
        return p.reservas_por_revisar()

    @r("GET", "/api/reservas-online/llegadas")
    def llegadas(req):
        return p.reservas_llegadas()

    @r("POST", r"/api/reservas-online/(\d+)/senal")
    def senal_cobrada(req, rid):
        return p.marcar_senal_cobrada(req.usuario, int(rid), req.body.get("metodo"))

    @r("POST", r"/api/reservas-online/(\d+)/senal-devuelta")
    def senal_devuelta(req, rid):
        return p.marcar_senal_devuelta(req.usuario, int(rid))

    @r("POST", r"/api/reservas-online/(\d+)/senal-reembolsar")
    def senal_reembolsar(req, rid):
        return p.reembolsar_senal(req.usuario, int(rid))

    @r("GET", "/api/reservas-online/web-pruebas", rol=("admin",))
    def web_pruebas_estado(req):
        return app.web_pruebas.estado()

    @r("POST", "/api/reservas-online/web-pruebas", rol=("admin",))
    def web_pruebas_cambiar(req):
        """1.16: activa o desactiva la web local de pruebas (activa=true/false; red=true la abre a otros dispositivos de la red, p. ej. el móvil)."""
        activa = req.body.get("activa") in (True, 1, "1", "true")
        red = req.body.get("red") in (True, 1, "1", "true")
        try:
            app.web_pruebas.activar(red) if activa else app.web_pruebas.parar()
        except OSError as e:
            raise ErrorNegocio(f"No se pudo activar la web de pruebas: {e}", 409)
        with p.db.transaccion() as c:
            p.auditar(c, req.usuario["id"], "reservas_web_pruebas", ("activada" + (" (red)" if red else "")) if activa else "desactivada")
        return app.web_pruebas.estado()

    @r("GET", "/api/reservas-online/kit.zip", rol=("admin",))
    def kit_web(req):
        """1.14: kit para la web del aparcamiento (carpeta integracion_web) con la dirección del programa ya puesta."""
        return Respuesta(p.kit_web_reservas(os.path.join(app.raiz, "scripts", "integracion_web")), "application/zip",
                         {"Content-Disposition": 'attachment; filename="reservas_para_mi_web.zip"'})

    @r("GET", "/api/reservas-online/relay", rol=("admin",))
    def relay_estado(req):
        return app.agente.estado()

    @r("POST", "/api/reservas-online/relay", rol=("admin",))
    def relay_aplicar(req):
        """1.18: aplica los ajustes del servidor en la nube (arranca o para el agente) y, si se pide, prueba la conexión."""
        app.agente.reiniciar()
        res = app.agente.estado()
        if req.body.get("probar"):
            res["prueba"] = app.agente.probar()
        return res

    @r("GET", "/api/reservas-online/servidor.zip", rol=("admin",))
    def servidor_zip(req):
        """1.18: servidor intermedio para subir a Internet (sin la clave)."""
        return Respuesta(p.kit_servidor_reservas(os.path.join(app.raiz, "scripts", "servidor_reservas"), os.path.join(app.raiz, "scripts", "integracion_web")),
                         "application/zip", {"Content-Disposition": 'attachment; filename="servidor_reservas.zip"'})

    @r("POST", r"/api/reservas-online/(\d+)/confirmar")
    def confirmar(req, rid):
        return p.confirmar_reserva_online(req.usuario, int(rid))

    @r("PUT", r"/api/reservas-online/(\d+)")
    def modificar(req, rid):
        """1.18: el personal cambia fechas, zona o tipo de una reserva pendiente."""
        return p.modificar_reserva_online(req.usuario, int(rid), req.body)

    @r("GET", "/api/reservas-online/informe")
    def informe(req):
        p._exigir_permiso(req.usuario, "reservas")
        return p.informe_reservas(req.query.get("desde"), req.query.get("hasta"))

    @r("GET", "/api/reservas-online/informe.csv")
    def informe_csv(req):
        p._exigir_permiso(req.usuario, "reservas")
        return Respuesta(p.informe_reservas_csv(req.query.get("desde"), req.query.get("hasta")), "text/csv; charset=utf-8",
                         {"Content-Disposition": 'attachment; filename="informe_reservas.csv"'})

    @r("DELETE", r"/api/reservas-online/(\d+)")
    def cancelar(req, rid):
        return p.cancelar_reserva_online(req.usuario, int(rid))

    # --- 1.9: horario del parking
    @r("GET", "/api/horario")
    def horario(req):
        return p.config_horario()

    @r("PUT", "/api/horario", rol=("admin",))
    def horario_guardar(req):
        return p.guardar_horario(req.usuario, req.body)

    @r("POST", r"/api/reservas-online/(\d+)/email")
    def reenviar_email(req, rid):
        return p.reenviar_email_reserva(req.usuario, int(rid), getattr(req, "host", None))

    # --- 1.10: página pública de reservas (sin sesión; limitadas por IP y solo con el interruptor activado en Ajustes)
    @r("GET", "/api/publico/reservas/config", publica=True)
    def pub_config(req):
        return p.pub_config()

    @r("POST", "/api/publico/reservas/consulta", publica=True)
    def pub_consulta(req):
        return p.pub_consulta(req.body, req.ip)

    @r("POST", "/api/publico/reservas", publica=True)
    def pub_crear(req):
        return p.pub_crear(req.body, req.ip, getattr(req, "host", None))

    @r("POST", "/api/publico/reservas/ver", publica=True)
    def pub_ver(req):
        return p.pub_ver(req.body.get("codigo"), req.body.get("matricula"), req.ip)

    @r("POST", "/api/publico/reservas/cancelar", publica=True)
    def pub_cancelar(req):
        return p.pub_cancelar(req.body.get("codigo"), req.body.get("matricula"), req.ip)

    @r("POST", "/api/publico/reservas/modificar", publica=True)
    def pub_modificar(req):
        return p.pub_modificar(req.body, req.ip)

    @r("POST", "/api/publico/reservas/pagar", publica=True)
    def pub_pagar(req):
        return p.pub_pagar(req.body, req.ip)

    @r("POST", "/api/publico/reservas/pago-confirmar", publica=True)
    def pub_pago_confirmar(req):
        return p.pub_pago_confirmar(req.body, req.ip)
