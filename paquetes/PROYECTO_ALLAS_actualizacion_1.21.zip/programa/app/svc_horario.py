"""PROYECTO ALLAS 1.9 · horario del parking: con el interruptor activado no se dan entradas ni salidas fuera de horario.

El horario se guarda por día de la semana (una franja por día, que puede cruzar la medianoche, o 24 h) y una lista de
festivos, que tienen el mismo horario que los domingos. Cerrar «a las 00:00» es cerrar a medianoche. Los supervisores y administradores no se bloquean (para poder sacar un coche en una urgencia).
"""
import json
import re
from datetime import date, datetime, timedelta

from .utiles import ErrorNegocio

DIAS = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
HORA_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")
ROLES_SIN_BLOQUEO = ("admin", "supervisor")


def _min(hhmm):
    h, m = hhmm.split(":")
    return int(h) * 60 + int(m)


def semana_defecto():
    return {str(i): {"abierto": True, "desde": "08:00", "hasta": "22:00", "24h": False} for i in range(1, 8)}


class SvcHorario:
    def horario_activo(self):
        return self.cfg("horario_activo") == "1"

    def _horario_semana(self):
        try:
            sem = json.loads(self.cfg("horario_semana") or "")
        except ValueError:
            sem = None
        base = semana_defecto()
        if isinstance(sem, dict):
            for k in base:
                if isinstance(sem.get(k), dict):
                    base[k] = {**base[k], **sem[k]}
        return base

    def _horario_cerrados(self):
        try:
            v = json.loads(self.cfg("horario_cerrados") or "[]")
        except ValueError:
            v = []
        return sorted({str(x) for x in v if isinstance(x, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", x)})

    def config_horario(self):
        return {"activo": self.horario_activo(), "semana": self._horario_semana(), "cerrados": self._horario_cerrados(),
                "dias": DIAS, "abierto_ahora": self.parking_abierto()[0]}

    def guardar_horario(self, usuario, datos):
        sem = {}
        for i in range(1, 8):
            d = (datos.get("semana") or {}).get(str(i)) or {}
            abierto, todo = bool(d.get("abierto")), bool(d.get("24h"))
            desde, hasta = str(d.get("desde") or "08:00"), str(d.get("hasta") or "22:00")
            if abierto and not todo:
                if not HORA_RE.match(desde) or not HORA_RE.match(hasta):
                    raise ErrorNegocio(f"{DIAS[i - 1].capitalize()}: hora no válida (use HH:MM)")
                if desde == hasta:
                    raise ErrorNegocio(f"{DIAS[i - 1].capitalize()}: la hora de apertura y la de cierre no pueden ser iguales (para todo el día marque «24 h»)")
            sem[str(i)] = {"abierto": abierto, "desde": desde if HORA_RE.match(desde) else "08:00",
                           "hasta": hasta if HORA_RE.match(hasta) else "22:00", "24h": todo}
        cerrados = []
        for x in datos.get("cerrados") or []:
            x = str(x).strip()
            if not x:
                continue
            try:
                date.fromisoformat(x)
            except ValueError:
                raise ErrorNegocio(f"Día cerrado no válido: {x} (use AAAA-MM-DD)")
            cerrados.append(x)
        activo = "1" if datos.get("activo") in (True, 1, "1", "true") else "0"
        with self.db.transaccion() as c:
            for k, v in (("horario_activo", activo), ("horario_semana", json.dumps(sem)),
                         ("horario_cerrados", json.dumps(sorted(set(cerrados))))):
                c.execute("INSERT INTO config(clave, valor) VALUES(?,?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor", (k, v))
            self.auditar(c, usuario["id"], "horario", f"activo={activo} cerrados={len(set(cerrados))}")
        return self.config_horario()

    # ------------------------------------------------------------ consulta
    @staticmethod
    def _franja_dia(sem, festivos, dia):
        """Horario que rige un día: el de su día de la semana, o el del domingo si es festivo."""
        return sem["7" if dia.isoformat() in festivos else str(dia.isoweekday())]

    @classmethod
    def _abierto_en(cls, sem, festivos, momento):
        dia = momento.date()
        t = momento.hour * 60 + momento.minute
        d = cls._franja_dia(sem, festivos, dia)
        if d["abierto"]:
            if d["24h"]:
                return True
            a, b = _min(d["desde"]), _min(d["hasta"])
            if (a < b and a <= t < b) or (a > b and t >= a):
                return True
        ayer = dia - timedelta(days=1)   # franja que empezó ayer y cruza la medianoche
        d = cls._franja_dia(sem, festivos, ayer)
        if d["abierto"] and not d["24h"]:
            a, b = _min(d["desde"]), _min(d["hasta"])
            if a > b and t < b:
                return True
        return False

    def _texto_horario_dia(self, momento):
        sem, festivos = self._horario_semana(), self._horario_cerrados()
        festivo = momento.date().isoformat() in festivos
        d = self._franja_dia(sem, festivos, momento.date())
        if not d["abierto"]:
            return "hoy es festivo y los festivos tienen horario de domingo: cerrado" if festivo else f"el {DIAS[momento.isoweekday() - 1]} está cerrado"
        return "hoy abre las 24 horas" if d["24h"] else f"horario de hoy{' (festivo)' if festivo else ''}: {d['desde']} a {d['hasta']}"

    def parking_abierto(self, momento=None):
        """(abierto, texto). Sin horario configurado el parking está siempre abierto."""
        if not self.horario_activo():
            return True, ""
        momento = momento or self.ahora()
        if self._abierto_en(self._horario_semana(), self._horario_cerrados(), momento):
            return True, ""
        return False, self._texto_horario_dia(momento)

    def _exigir_abierto(self, usuario, que="operar"):
        """Entradas y salidas: bloqueadas fuera de horario (salvo supervisores y administradores)."""
        if not self.horario_activo() or (usuario or {}).get("rol") in ROLES_SIN_BLOQUEO:
            return
        abierto, texto = self.parking_abierto()
        if not abierto:
            raise ErrorNegocio(f"El parking está cerrado: no se pueden dar entradas ni salidas ({texto}). "
                               "Un supervisor puede hacerlo si es una urgencia.", 409)

    def abierto_en_momentos(self, *momentos):
        """Para reservas: todos los momentos deben caer en horario de apertura. (La salida a la hora exacta de cierre es válida:
        quien se va a las 00:00 sale cuando cierra; por eso quien llama pasa la salida un minuto antes.)"""
        if not self.horario_activo():
            return True
        sem, cerrados = self._horario_semana(), self._horario_cerrados()
        return all(self._abierto_en(sem, cerrados, m) for m in momentos)
