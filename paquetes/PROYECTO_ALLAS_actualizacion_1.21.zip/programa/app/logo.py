"""Logo personalizado de la empresa.

El navegador prepara la imagen al subirla (así no hace falta ninguna librería de imágenes):
  - logo.jpg     : versión en color para la factura PDF (fondo blanco, máx. 1200 px)
  - logo.bin     : versión en blanco y negro (1 bit por punto) para la impresora térmica
Aquí se validan, se guardan en la carpeta de datos y se genera la vista previa PNG del ticket.
"""
import json
import os
import struct
import zlib

MAX_JPEG = 3 * 1024 * 1024
MAX_ANCHO_TICKET = 576   # puntos de una impresora de 80 mm
MAX_ALTO_TICKET = 400


class ErrorLogo(ValueError):
    pass


def dimensiones_jpeg(datos):
    """(ancho, alto) leyendo el marcador SOF del JPEG; error si no es un JPEG válido."""
    if not datos.startswith(b"\xff\xd8"):
        raise ErrorLogo("La imagen para la factura no es un JPEG válido")
    i = 2
    while i + 9 < len(datos):
        if datos[i] != 0xFF:
            i += 1
            continue
        marca = datos[i + 1]
        if marca in (0xD8, 0x01) or 0xD0 <= marca <= 0xD7:
            i += 2
            continue
        largo = struct.unpack(">H", datos[i + 2:i + 4])[0]
        if marca in (0xC0, 0xC1, 0xC2):
            alto, ancho = struct.unpack(">HH", datos[i + 5:i + 9])
            componentes = datos[i + 9] if i + 9 < len(datos) else 3
            return ancho, alto, componentes
        i += 2 + largo
    raise ErrorLogo("No se pudo leer el tamaño del JPEG")


def png_1bit(ancho, alto, bits):
    """PNG en blanco y negro a partir de los bits ESC/POS (1 = negro)."""
    fila = ancho // 8
    crudo = b"".join(b"\x00" + bytes(255 - b for b in bits[y * fila:(y + 1) * fila]) for y in range(alto))

    def trozo(tipo, d):
        return struct.pack(">I", len(d)) + tipo + d + struct.pack(">I", zlib.crc32(tipo + d) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + trozo(b"IHDR", struct.pack(">IIBBBBB", ancho, alto, 1, 0, 0, 0, 0))
            + trozo(b"IDAT", zlib.compress(crudo, 9)) + trozo(b"IEND", b""))


def guardar(carpeta, jpeg, ancho_t, alto_t, bits, base="logo"):
    if len(jpeg) > MAX_JPEG:
        raise ErrorLogo("La imagen es demasiado grande (máximo 3 MB)")
    ancho_j, alto_j, comp = dimensiones_jpeg(jpeg)
    ancho_t, alto_t = int(ancho_t), int(alto_t)
    if ancho_t % 8 or not 8 <= ancho_t <= MAX_ANCHO_TICKET or not 1 <= alto_t <= MAX_ALTO_TICKET:
        raise ErrorLogo("Tamaño del logo para el ticket no válido")
    if len(bits) != ancho_t // 8 * alto_t:
        raise ErrorLogo("Los datos del logo para el ticket están incompletos")
    os.makedirs(carpeta, exist_ok=True)
    with open(os.path.join(carpeta, base + ".jpg"), "wb") as f:
        f.write(jpeg)
    with open(os.path.join(carpeta, base + ".bin"), "wb") as f:
        f.write(bits)
    with open(os.path.join(carpeta, base + "_ticket.png"), "wb") as f:
        f.write(png_1bit(ancho_t, alto_t, bits))
    info = {"jpeg_ancho": ancho_j, "jpeg_alto": alto_j, "jpeg_componentes": comp,
            "ticket_ancho": ancho_t, "ticket_alto": alto_t, "version": int.from_bytes(os.urandom(3), "big")}
    with open(os.path.join(carpeta, base + ".json"), "w") as f:
        json.dump(info, f)
    return info


def info(carpeta, base="logo"):
    try:
        with open(os.path.join(carpeta, base + ".json")) as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def raster(carpeta, base="logo"):
    i = info(carpeta, base)
    if not i:
        return None
    try:
        with open(os.path.join(carpeta, base + ".bin"), "rb") as f:
            return i["ticket_ancho"], i["ticket_alto"], f.read(), i["version"]
    except OSError:
        return None


def jpeg(carpeta):
    """Logo de la factura PDF: el propio de la factura (4.4) o, si no hay, el que se subió con el ticket."""
    propio = jpeg_factura(carpeta)
    if propio:
        return propio
    i = info(carpeta)
    if not i:
        return None
    try:
        with open(os.path.join(carpeta, "logo.jpg"), "rb") as f:
            return {"jpeg": f.read(), "ancho": i["jpeg_ancho"], "alto": i["jpeg_alto"],
                    "componentes": i.get("jpeg_componentes", 3)}
    except OSError:
        return None


def borrar(carpeta, base="logo"):
    for n in (base + ".jpg", base + ".bin", base + "_ticket.png", base + ".json"):
        try:
            os.remove(os.path.join(carpeta, n))
        except OSError:
            pass


# ------------------------------------------------------------------ 4.4 · logo propio de la factura (en color)
def guardar_factura(carpeta, datos):
    if len(datos) > MAX_JPEG:
        raise ErrorLogo("La imagen es demasiado grande (máximo 3 MB)")
    ancho, alto, comp = dimensiones_jpeg(datos)
    os.makedirs(carpeta, exist_ok=True)
    with open(os.path.join(carpeta, "logo_factura.jpg"), "wb") as f:
        f.write(datos)
    i = {"ancho": ancho, "alto": alto, "componentes": comp, "version": int.from_bytes(os.urandom(3), "big")}
    with open(os.path.join(carpeta, "logo_factura.json"), "w") as f:
        json.dump(i, f)
    return i


def info_factura(carpeta):
    try:
        with open(os.path.join(carpeta, "logo_factura.json")) as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def jpeg_factura(carpeta):
    i = info_factura(carpeta)
    if not i:
        return None
    try:
        with open(os.path.join(carpeta, "logo_factura.jpg"), "rb") as f:
            return {"jpeg": f.read(), "ancho": i["ancho"], "alto": i["alto"], "componentes": i.get("componentes", 3)}
    except OSError:
        return None


def borrar_factura(carpeta):
    for n in ("logo_factura.jpg", "logo_factura.json"):
        try:
            os.remove(os.path.join(carpeta, n))
        except OSError:
            pass


# ------------------------------------------------------------------ 4.58 · sello del garaje (en el ticket de cobro y en la factura)
def jpeg_sello(carpeta):
    i = info(carpeta, "sello")
    if not i:
        return None
    try:
        with open(os.path.join(carpeta, "sello.jpg"), "rb") as f:
            return {"jpeg": f.read(), "ancho": i["jpeg_ancho"], "alto": i["jpeg_alto"],
                    "componentes": i.get("jpeg_componentes", 3)}
    except OSError:
        return None
