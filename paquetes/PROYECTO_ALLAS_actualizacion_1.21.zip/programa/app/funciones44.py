"""PROYECTO ALLAS 4.4 · funciones nuevas de la clase Parking (se mezclan con ella en servicios.py):

- menú de Supervisión (contraseña maestra del fabricante o propia de la licencia) para ocultar menús y opciones
- exportar tarifas, servicios y productos por separado; clientes abonados y no abonados por separado
- borrar de una vez los clientes que no son abonados
- semáforo y cartel de LIBRE / COMPLETO
- impresora A4 para las facturas
- estabilidad: comprobación de la base de datos al arrancar y registro de errores de las pantallas
"""
import collections
import json
import os
import re
import subprocess
import sys
import threading
import time
from datetime import datetime
from . import errores


def _sv():
    from . import servicios
    return servicios


# ------------------------------------------------------------------ supervisión
# Lo que se oculta por defecto en una instalación nueva (se puede mostrar desde Supervisión)
OCULTOS_DEFECTO = ["licencia_online"]   # 4.27: la búsqueda de actualizaciones online viene activada de fábrica
_ID_OCULTO = re.compile(r"^[a-z0-9_:.\-]{1,60}$")
_FALLOS_SUP = {}          # ip → [nº de fallos, momento del primero]
_LOCK_SUP = threading.Lock()
MAX_FALLOS_SUP, BLOQUEO_SUP = 5, 15 * 60
# 4.8: contraseña de fábrica, mientras el fabricante no fije una (maestra o de la licencia) en el Gestor de licencias
CLAVE_SUPERVISION_DEFECTO = "8888"

# ------------------------------------------------------------------ errores de las pantallas (memoria)
ERRORES_CLIENTE = collections.deque(maxlen=100)

# ------------------------------------------------------------------ semáforo / cartel
SENALES = ("semaforo", "cartel")
NOMBRE_SENAL = {"semaforo": "Semáforo", "cartel": "Cartel LIBRE / COMPLETO"}
_LOCK_SENAL = threading.Lock()


class Funciones44:
    # ============================================================== supervisión
    def huellas_supervision(self):
        """[(origen, huella)]: la de la licencia (en el serial) y la maestra del fabricante."""
        r = []
        serial = self.cfg("licencia_serial")
        if serial:
            try:
                from .licencia import leer
                from .licencia_clave import CLAVE_PUBLICA
                h = leer(serial, bytes.fromhex(CLAVE_PUBLICA)).get("supervision")
                if h:
                    r.append(("licencia", h))
            except Exception as e_:  # noqa: BLE001
                errores.fallo("funciones44.huellas_supervision", e_)
        try:
            m = self.datos_fabricante().get("supervision")
            if m:
                r.append(("maestra", m))
        except Exception as e_:  # noqa: BLE001
            errores.fallo("funciones44.huellas_supervision", e_)
        return r

    def supervision_configurada(self):
        return bool(self.huellas_supervision())

    # 4.8: tipo de licencia elegido desde Supervisión (solo puede recortar lo que incluye la licencia)
    def plan_supervision(self):
        from .licencia import PLANES
        v = self.cfg("supervision_plan") or ""
        return v if v in PLANES else None

    def planes_supervision(self):
        from .licencia import PLANES
        lic = set(self.estado_licencia().get("modulos") or [])
        return [{"id": k, "nombre": v["nombre"], "color": v["color"], "modulos": list(v["modulos"]),
                 "disponible": set(v["modulos"]) <= lic} for k, v in PLANES.items()]

    def guardar_plan_supervision(self, actor_id, plan):
        from .licencia import PLANES
        sv = _sv()
        plan = plan or ""
        if plan and plan not in PLANES:
            raise sv.ErrorNegocio("Tipo de licencia desconocido")
        if plan and not next(x for x in self.planes_supervision() if x["id"] == plan)["disponible"]:
            raise sv.ErrorNegocio(f"La licencia no incluye todos los módulos de «{PLANES[plan]['nombre']}»: "
                                  "solo se puede elegir un tipo igual o más reducido que el contratado.")
        with self.db.transaccion() as c:
            c.execute("INSERT OR REPLACE INTO config(clave, valor) VALUES('supervision_plan', ?)", (plan,))
            self.auditar(c, actor_id, "supervision_plan", PLANES[plan]["nombre"] if plan else "Según la licencia")
        self._cache_modulos = None
        return {"plan": plan or None, "modulos": self.modulos_activos(), "tipo": self.tipo_licencia()}

    def comprobar_clave_supervision(self, clave, ip=None):
        """→ origen de la contraseña ('licencia' | 'maestra'). Tras 5 fallos desde un equipo, 15 min bloqueado."""
        from .licencia import comprobar_supervision
        sv = _sv()
        clave_ip = ip or "local"
        with _LOCK_SUP:
            n, t0 = _FALLOS_SUP.get(clave_ip, (0, 0))
            if n >= MAX_FALLOS_SUP and time.time() - t0 < BLOQUEO_SUP:
                raise sv.ErrorNegocio("Demasiados intentos. Espere 15 minutos.", 429)
        huellas = self.huellas_supervision()
        if not huellas:   # 4.8: la de fábrica, hasta que se fije otra en el Gestor de licencias
            import hmac
            if hmac.compare_digest((clave or "").encode(), CLAVE_SUPERVISION_DEFECTO.encode()):
                with _LOCK_SUP:
                    _FALLOS_SUP.pop(clave_ip, None)
                return "defecto"
        for origen, h in huellas:
            if comprobar_supervision(clave or "", h):
                with _LOCK_SUP:
                    _FALLOS_SUP.pop(clave_ip, None)
                return origen
        with _LOCK_SUP:
            n, t0 = _FALLOS_SUP.get(clave_ip, (0, time.time()))
            if time.time() - t0 >= BLOQUEO_SUP:
                n, t0 = 0, time.time()
            _FALLOS_SUP[clave_ip] = (n + 1, t0)
        raise sv.ErrorNegocio("Contraseña de supervisión incorrecta", 403)

    def ocultos(self):
        v = self.cfg("supervision_ocultos")
        if v and self.cfg("supervision_mig_act") is None:   # 4.27: una sola vez, se activa la búsqueda online en instalaciones anteriores
            try:
                lista = [x for x in json.loads(v) if x != "actualizaciones_online"]
                self.db.set_cfg("supervision_ocultos", json.dumps(lista))
            except ValueError:
                pass
            self.db.set_cfg("supervision_mig_act", "1")
            v = self.cfg("supervision_ocultos")
        if v is None or v == "":
            return list(OCULTOS_DEFECTO)
        try:
            lista = json.loads(v)
            return [x for x in lista if isinstance(x, str) and _ID_OCULTO.match(x)]
        except ValueError:
            return list(OCULTOS_DEFECTO)

    def oculto(self, ident):
        return ident in self.ocultos()

    def guardar_ocultos(self, actor_id, lista):
        sv = _sv()
        if not isinstance(lista, list) or len(lista) > 400:
            raise sv.ErrorNegocio("Lista no válida")
        limpia = sorted({x for x in lista if isinstance(x, str) and _ID_OCULTO.match(x)})
        antes = set(self.ocultos())
        with self.db.transaccion() as c:
            c.execute("INSERT OR REPLACE INTO config(clave, valor) VALUES('supervision_ocultos', ?)", (json.dumps(limpia),))
            cambios = [f"-{x}" for x in sorted(antes - set(limpia))] + [f"+{x}" for x in sorted(set(limpia) - antes)]
            self.auditar(c, actor_id, "supervision_ocultos", " ".join(cambios)[:900] or "sin cambios")
        return {"ocultos": limpia}

    # ============================================================== pantalla de cliente: más personalización
    TRANSICIONES = ("fundido", "deslizar", "zoom", "ninguna")

    def estilo_pantalla_cliente(self):
        g = self.cfg
        def num(k, d, a, b):
            try:
                return max(a, min(b, int(g(k) or d)))
            except ValueError:
                return d
        color = (g("pantalla_cliente_color") or "").strip()
        return {"transicion": g("pantalla_cliente_transicion") if g("pantalla_cliente_transicion") in self.TRANSICIONES else "fundido",
                "transicion_ms": num("pantalla_cliente_transicion_ms", 1000, 200, 4000),
                "aleatorio": g("pantalla_cliente_orden") == "aleatorio",
                "ajuste": "completa" if g("pantalla_cliente_ajuste") == "completa" else "cubrir",
                "movimiento": g("pantalla_cliente_movimiento") == "1",
                "rotulo": g("pantalla_cliente_rotulo") if g("pantalla_cliente_rotulo") in ("abajo", "arriba", "oculto") else "abajo",
                "pie": g("pantalla_cliente_pie") != "0",
                "progreso": g("pantalla_cliente_progreso") == "1",
                "color": color if re.fullmatch(r"#[0-9a-fA-F]{6}", color) else "",
                "tema": "claro" if g("pantalla_cliente_tema") == "claro" else "oscuro"}

    EJEMPLOS_PUBLICIDAD = (("ejemplo_bienvenida.jpg", "Bienvenido · abierto 24 horas", "Aparque con tranquilidad, todos los días del año"),
                           ("ejemplo_abono.jpg", "Abono mensual", "Su plaza cuando la necesite · pregunte en caja"),
                           ("ejemplo_lavado.jpg", "Lavado mientras aparca", "Recoja su coche limpio a la salida"),
                           ("ejemplo_movil.jpg", "Pague con su móvil", "Escanee el código de su ticket y salga sin pasar por caja"))

    def poner_publicidad_ejemplo(self, actor_id=None):
        carpeta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "publicidad_ejemplo")
        n = 0
        existentes = {a["titulo"] for a in self.anuncios()}
        for archivo, titulo, texto in self.EJEMPLOS_PUBLICIDAD:
            if titulo in existentes:
                continue
            try:
                with open(os.path.join(carpeta, archivo), "rb") as f:
                    datos = f.read()
            except OSError:
                continue
            self.guardar_anuncio(actor_id, {"titulo": titulo, "texto": texto}, datos)
            n += 1
        self.db.set_cfg("publicidad_ejemplo", "1")
        return {"anadidos": n}

    def carpeta_imagenes_ejemplo(self):
        """Carpeta con fotos de ejemplo para cargar a mano desde «Añadir fotos…»."""
        ruta = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "imagenes_ejemplo")
        try:
            n = len([f for f in os.listdir(ruta) if f.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))])
        except OSError:
            return {"ruta": "", "archivos": 0}
        return {"ruta": ruta, "archivos": n}

    def asegurar_publicidad_ejemplo(self):
        """Una sola vez: si no hay ningún anuncio, se ponen los de ejemplo (se pueden quitar)."""
        if self.cfg("publicidad_ejemplo") or getattr(self, "demo", False):
            return None
        if self.db.q1("SELECT COUNT(*) n FROM publicidad")["n"]:
            self.db.set_cfg("publicidad_ejemplo", "1")
            return None
        return self.poner_publicidad_ejemplo()

    def quitar_publicidad_ejemplo(self, actor_id):
        titulos = [t for _, t, _ in self.EJEMPLOS_PUBLICIDAD]
        with self.db.transaccion() as c:
            n = c.execute(f"DELETE FROM publicidad WHERE titulo IN ({','.join('?' * len(titulos))})", titulos).rowcount
            self.auditar(c, actor_id, "publicidad_quitar_ejemplos", str(n))
        return {"quitados": n}

    # ============================================================== exportar por separado
    def exportar_config_parte(self, que):
        """que: tarifas | servicios | productos | todo."""
        sv = _sv()
        if que not in ("tarifas", "servicios", "productos", "todo"):
            raise sv.ErrorNegocio("Indique qué exportar: tarifas, servicios o productos")
        d = self.exportar_config()
        if que == "tarifas":
            d["productos"] = []
        elif que in ("servicios", "productos"):
            d["tarifas"] = []
            tipo = "servicio" if que == "servicios" else "producto"
            d["productos"] = [x for x in d["productos"] if x.get("tipo") == tipo]
        d["contenido"] = que
        return d

    def exportar_clientes_tipo_csv(self, tipo=None):
        """Clientes de un tipo ('abonado' | 'facturacion') o todos, con las columnas de la plantilla de importación."""
        texto = self.exportar_clientes_csv()
        if tipo not in ("abonado", "facturacion"):
            return texto
        lineas = texto.lstrip("﻿").split("\r\n")
        cab, filas = lineas[0], [x for x in lineas[1:] if x]
        idx = cab.split(";").index("tipo")
        import csv
        import io
        sal = io.StringIO()
        w = csv.writer(sal, delimiter=";", lineterminator="\r\n")
        w.writerow(cab.split(";"))
        for f in csv.reader(io.StringIO("\r\n".join(filas)), delimiter=";"):
            if len(f) > idx and f[idx] == tipo:
                w.writerow(f)
        return "﻿" + sal.getvalue()

    # ============================================================== clientes que no son abonados
    def _sql_no_abonados(self):
        return ("SELECT c.id, c.nombre FROM clientes c WHERE COALESCE(c.tipo,'facturacion') <> 'abonado' "
                "AND NOT EXISTS (SELECT 1 FROM bonos b WHERE b.cliente_id=c.id) "
                "AND NOT EXISTS (SELECT 1 FROM suscripciones s WHERE s.cliente_id=c.id) "
                "AND NOT EXISTS (SELECT 1 FROM tickets t WHERE t.cliente_id=c.id AND t.estado IN ('dentro','pagado'))")

    def resumen_no_abonados(self):
        filas = self.db.q(self._sql_no_abonados())
        total_no_ab = self.db.q1("SELECT COUNT(*) n FROM clientes WHERE COALESCE(tipo,'facturacion') <> 'abonado'")["n"]
        facturas = self.db.q1("SELECT COUNT(*) n FROM facturas_destinatario WHERE cliente_id IN (" + self._sql_no_abonados().replace(
            "SELECT c.id, c.nombre", "SELECT c.id") + ")")["n"]
        return {"borrables": len(filas), "no_abonados": total_no_ab, "se_quedan": total_no_ab - len(filas), "facturas": facturas,
                "ejemplos": [f["nombre"] for f in filas[:8]]}

    def borrar_clientes_no_abonados(self, actor_id, confirmacion):
        """Borra los clientes de facturación (horas, productos, servicios) con sus vehículos y fotos. Las facturas ya emitidas
        no cambian: guardan su propia copia del nombre, NIF y dirección (obligatorio conservarlas)."""
        sv = _sv()
        if (confirmacion or "").strip().upper() != "BORRAR":
            raise sv.ErrorNegocio("Escriba BORRAR para confirmar")
        with self.db.transaccion() as c:
            ids = [r[0] for r in c.execute(self._sql_no_abonados()).fetchall()]
            for i in range(0, len(ids), 500):
                lote = ids[i:i + 500]
                marcas = ",".join("?" * len(lote))
                c.execute(f"UPDATE facturas_destinatario SET cliente_id=NULL WHERE cliente_id IN ({marcas})", lote)
                c.execute(f"UPDATE tickets SET cliente_id=NULL WHERE cliente_id IN ({marcas})", lote)
                c.execute(f"UPDATE avisos SET cliente_id=NULL WHERE cliente_id IN ({marcas})", lote)
                c.execute(f"DELETE FROM vehiculo_fotos WHERE cliente_id IN ({marcas})", lote)
                c.execute(f"DELETE FROM cliente_matriculas WHERE cliente_id IN ({marcas})", lote)
                c.execute(f"DELETE FROM clientes WHERE id IN ({marcas})", lote)
            self.auditar(c, actor_id, "clientes_borrar_no_abonados", f"{len(ids)} cliente(s)")
        return {"borrados": len(ids)}

    # ============================================================== semáforo y cartel LIBRE / COMPLETO
    def cfg_senal(self, pref):
        g = lambda k, d="": self.cfg(f"{pref}_{k}") or d  # noqa: E731
        return {"activo": self.cfg(f"{pref}_activo") == "1", "conexion": g("conexion", "http"), "destino": g("destino"),
                "libre": g("libre"), "completo": g("completo"), "baudios": g("baudios", "9600"),
                "margen": int(g("margen", "0") or 0), "ambito": g("ambito", "total")}

    def estado_ocupacion_senal(self, ambito="total", margen=0):
        """'libre' | 'completo' y las plazas libres según el ámbito: total, rotacion (sin las de abonados) o zona:<id>."""
        oc = self.ocupacion()
        cap, ocupadas = oc.get("capacidad") or 0, oc["ocupadas"]
        if ambito == "rotacion" and oc.get("plazas_abonados"):
            cap, ocupadas = max(0, cap - oc["plazas_abonados"]), oc.get("rotacion", ocupadas)
        elif ambito.startswith("zona:"):
            z = next((z for z in oc.get("zonas") or [] if str(z["id"]) == ambito[5:]), None)
            if z:
                cap, ocupadas = z.get("capacidad") or 0, z["ocupadas"]
        if not cap:
            return "libre", None
        libres = max(0, cap - ocupadas)
        return ("completo" if libres <= max(0, margen) else "libre"), libres

    def enviar_senal(self, pref, estado, motivo="cambio"):
        from . import perifericos
        cfg = self.cfg_senal(pref)
        try:
            r = perifericos.enviar_senal(cfg, estado)
            self.db.set_cfg(f"{pref}_estado", estado)
            self.db.set_cfg(f"{pref}_ultimo", f"{_sv().iso(self.ahora())} {estado} ({motivo}): {r}")
            self.db.set_cfg(f"{pref}_ultimo_error", "")
            return r
        except Exception as e:  # noqa: BLE001
            self.db.set_cfg(f"{pref}_ultimo_error", f"{_sv().iso(self.ahora())} {estado}: {e}")
            raise

    def senales_tick(self, forzar=False):
        """Lo llama un hilo cada pocos segundos: si cambia LIBRE/COMPLETO, se manda la orden (y cada 10 min se repite)."""
        hecho = {}
        with _LOCK_SENAL:
            for pref in SENALES:
                cfg = self.cfg_senal(pref)
                if not cfg["activo"] or not cfg["destino"]:
                    continue
                estado, _ = self.estado_ocupacion_senal(cfg["ambito"], cfg["margen"])
                anterior = self.cfg(f"{pref}_estado")
                ultimo = self.cfg(f"{pref}_envio_ts", float) if self.cfg(f"{pref}_envio_ts") else 0
                if forzar or estado != anterior or time.time() - ultimo > 600:
                    try:
                        self.enviar_senal(pref, estado, "cambio" if estado != anterior else "repaso")
                        hecho[pref] = estado
                    except Exception as e:  # noqa: BLE001
                        hecho[pref] = f"error: {e}"
                    self.db.set_cfg(f"{pref}_envio_ts", str(time.time()))
        return hecho

    def probar_senal(self, actor_id, pref, estado):
        sv = _sv()
        if pref not in SENALES or estado not in ("libre", "completo"):
            raise sv.ErrorNegocio("Señal o estado no válidos")
        cfg = self.cfg_senal(pref)
        if not cfg["destino"]:
            raise sv.ErrorNegocio("Indique primero la dirección, el puerto o el programa")
        try:
            r = self.enviar_senal(pref, estado, "prueba")
        except Exception as e:  # noqa: BLE001
            raise sv.ErrorNegocio(f"No responde: {e}")
        with self.db.transaccion() as c:
            self.auditar(c, actor_id, f"{pref}_probar", estado)
        # la próxima comprobación vuelve a poner el estado real
        self.db.set_cfg(f"{pref}_envio_ts", "0")
        return {"ok": True, "respuesta": r}

    def estado_senales(self):
        r = {}
        for pref in SENALES:
            cfg = self.cfg_senal(pref)
            estado, libres = self.estado_ocupacion_senal(cfg["ambito"], cfg["margen"])
            r[pref] = {"activo": cfg["activo"], "estado_real": estado, "libres": libres, "enviado": self.cfg(f"{pref}_estado"),
                       "ultimo": self.cfg(f"{pref}_ultimo"), "error": self.cfg(f"{pref}_ultimo_error")}
        return r

    # ============================================================== impresora A4 para las facturas
    def cfg_a4(self):
        return {"modo": self.cfg("a4_modo") or "", "impresora": self.cfg("a4_impresora") or "",
                "programa": self.cfg("a4_programa") or "", "completas": self.cfg("a4_completas") == "1"}

    def a4_para_factura(self, pago_id):
        """True si esta factura se imprime en A4 al pulsar «Imprimir» (factura con datos del cliente y A4 configurada)."""
        a4 = self.cfg_a4()
        if not a4["modo"] or a4["modo"] == "navegador" or not a4["completas"]:
            return False
        return bool(self.db.q1("SELECT 1 FROM facturas_destinatario WHERE pago_id=?", (pago_id,)))

    def imprimir_factura_a4(self, usuario, pago_id):
        sv = _sv()
        a4 = self.cfg_a4()
        if not a4["modo"] and self.es_factura_proveedor(pago_id):
            a4 = dict(a4, modo="navegador")   # 4.64: un proveedor siempre puede imprimir su factura en A4 desde el navegador
        if not a4["modo"]:
            raise sv.ErrorNegocio("Configure la impresora A4 en Ajustes → Equipos → Impresoras y cajón")
        if a4["modo"] == "navegador":
            return {"modo": "navegador", "url": f"/api/facturas/{int(pago_id)}/pdf"}
        datos, nombre = self.pdf_factura(int(pago_id))
        carpeta = os.path.join(os.path.dirname(self.db.path), "imprimir_a4")
        if a4["modo"] == "archivo":
            carpeta = a4["impresora"] or carpeta
        os.makedirs(carpeta, exist_ok=True)
        ruta = os.path.join(carpeta, datetime.now().strftime("%Y%m%d-%H%M%S-") + nombre)
        with open(ruta, "wb") as f:
            f.write(datos)
        try:
            if a4["modo"] == "windows":
                _imprimir_pdf_windows(ruta, a4["impresora"])
            elif a4["modo"] == "programa":
                if not a4["programa"]:
                    raise RuntimeError("Indique la orden del programa de impresión")
                from .perifericos import _programa
                r = _programa(a4["programa"], {"archivo": ruta, "impresora": a4["impresora"]}, timeout=60)
                if r.returncode != 0:
                    raise RuntimeError(f"el programa terminó con error {r.returncode}")
            elif a4["modo"] != "archivo":
                raise RuntimeError("Modo de impresión A4 desconocido")
        except Exception as e:  # noqa: BLE001
            raise sv.ErrorNegocio(f"No se pudo imprimir en A4: {e}")
        finally:
            if a4["modo"] != "archivo":
                threading.Timer(120, _borrar, (ruta,)).start()   # el programa de impresión ya lo ha leído
        with self.db.transaccion() as c:
            self.auditar(c, usuario["id"] if usuario else None, "factura_imprimir_a4", nombre)
        return {"modo": a4["modo"], "impreso": True, "archivo": nombre}

    # ============================================================== caja móvil: matrícula desde una foto
    def leer_matricula_foto(self, datos):
        """OCR de la foto de una matrícula: con el OCR que trae Windows 10/11 (o tesseract, si está instalado)."""
        sv = _sv()
        if not datos or len(datos) > 8 * 1024 * 1024:
            raise sv.ErrorNegocio("Foto no válida (máximo 8 MB)")
        if not (datos[:3] == b"\xff\xd8\xff" or datos[:8] == b"\x89PNG\r\n\x1a\n"):
            raise sv.ErrorNegocio("La foto debe ser JPG o PNG")
        carpeta = os.path.join(os.path.dirname(self.db.path), "tmp_ocr")
        os.makedirs(carpeta, exist_ok=True)
        ruta = os.path.join(carpeta, f"m{int(time.time() * 1000)}{'.jpg' if datos[:2] == b'\xff\xd8' else '.png'}")
        with open(ruta, "wb") as f:
            f.write(datos)
        try:
            texto = ocr_imagen(ruta)
        except RuntimeError as e:
            raise sv.ErrorNegocio(str(e), 501)
        finally:
            _borrar(ruta)
        cand = extraer_matriculas(texto)
        return {"matricula": cand[0] if cand else None, "candidatos": cand[:5], "texto": (texto or "").strip()[:300]}

    # ============================================================== estabilidad
    def comprobar_integridad(self):
        """PRAGMA quick_check (solo lectura). Se guarda el resultado para la campana."""
        try:
            filas = self.db.conn.execute("PRAGMA quick_check(20)").fetchall()
            res = "ok" if filas and filas[0][0] == "ok" else "; ".join(str(f[0]) for f in filas)[:500]
        except Exception as e:  # noqa: BLE001
            res = f"no se pudo comprobar: {e}"
        self.db.set_cfg("integridad_resultado", res)
        self.db.set_cfg("integridad_fecha", _sv().iso(self.ahora()))
        return res

    def registrar_error_cliente(self, d, usuario=None, ip=None):
        e = {"fecha": _sv().iso(self.ahora()), "usuario": (usuario or {}).get("usuario"), "ip": ip,
             "mensaje": str(d.get("mensaje") or "")[:500], "origen": str(d.get("origen") or "")[:200],
             "linea": d.get("linea") if isinstance(d.get("linea"), int) else None, "pantalla": str(d.get("pantalla") or "")[:60],
             "pila": str(d.get("pila") or "")[:1500]}
        if not e["mensaje"]:
            return {"ok": False}
        repetido = ERRORES_CLIENTE and ERRORES_CLIENTE[-1]["mensaje"] == e["mensaje"] and ERRORES_CLIENTE[-1]["origen"] == e["origen"]
        if not repetido:
            ERRORES_CLIENTE.append(e)
            print(f"[pantalla] {e['fecha']} {e['usuario'] or '-'} {e['pantalla']}: {e['mensaje']} ({e['origen']}:{e['linea']})")
        return {"ok": True}

    def errores_cliente(self):
        return list(reversed(ERRORES_CLIENTE))

    def avisos44(self):
        avisos = []
        r = self.cfg("integridad_resultado")
        if r and r != "ok":
            avisos.append({"id": "integridad", "nivel": "rojo", "titulo": "La base de datos tiene errores",
                           "texto": f"Comprobación al arrancar ({(self.cfg('integridad_fecha') or '')[:16].replace('T', ' ')}): {r}. "
                                    "Haga una copia de seguridad y avise a su distribuidor.", "ir": "copias"})
        for pref in SENALES:
            if self.cfg(f"{pref}_activo") == "1" and self.cfg(f"{pref}_ultimo_error"):
                avisos.append({"id": pref, "nivel": "aviso", "titulo": f"{NOMBRE_SENAL[pref]}: no responde",
                               "texto": self.cfg(f"{pref}_ultimo_error"), "ir": "semaforo"})
        return avisos


def _borrar(ruta):
    try:
        os.remove(ruta)
    except OSError:
        pass


def _imprimir_pdf_windows(ruta, impresora=""):
    """Imprime el PDF con el programa de PDF de Windows (verbo «printto»/«print»). Sin programa de PDF que lo admita,
    falla: se puede usar el modo «programa» con SumatraPDF."""
    if sys.platform != "win32":
        raise RuntimeError("La impresión directa en A4 solo funciona en Windows")
    import ctypes
    verbo, params = ("printto", f'"{impresora}"') if impresora else ("print", None)
    r = ctypes.windll.shell32.ShellExecuteW(None, verbo, ruta, params, os.path.dirname(ruta), 0)
    if r <= 32:
        raise RuntimeError("Windows no tiene un programa de PDF que imprima directamente "
                           "(instale SumatraPDF o Adobe Reader, o use el modo «Abrir el PDF»)")


# ------------------------------------------------------------------ OCR (matrículas)
_PS_OCR = r"""
param([string]$ruta)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Esperar($op, $tipo) { $t = $asTask.MakeGenericMethod($tipo).Invoke($null, @($op)); $t.Wait(-1) | Out-Null; $t.Result }
[Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime] | Out-Null
[Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime] | Out-Null
[Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics, ContentType = WindowsRuntime] | Out-Null
[Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime] | Out-Null
$archivo = Esperar ([Windows.Storage.StorageFile]::GetFileFromPathAsync($ruta)) ([Windows.Storage.StorageFile])
$flujo = Esperar ($archivo.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
$dec = Esperar ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($flujo)) ([Windows.Graphics.Imaging.BitmapDecoder])
$bmp = Esperar ($dec.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
$motor = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
if ($motor -eq $null) { $motor = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new('en-US')) }
if ($motor -eq $null) { Write-Error 'Windows no tiene ningún idioma con reconocimiento de texto (OCR) instalado' ; exit 3 }
$res = Esperar ($motor.RecognizeAsync($bmp)) ([Windows.Media.Ocr.OcrResult])
foreach ($l in $res.Lines) { $l.Text }
"""


def ocr_imagen(ruta):
    """Texto de una imagen. tesseract si está instalado; si no, el OCR de Windows 10/11 (PowerShell)."""
    import shutil
    tess = shutil.which("tesseract")
    if tess:
        salida = []
        for psm in ("7", "11"):
            r = subprocess.run([tess, ruta, "stdout", "--psm", psm], capture_output=True, timeout=30, **_sin_ventana())
            salida.append(r.stdout.decode("utf-8", "replace"))
        return "\n".join(salida)
    if os.name == "nt":
        script = os.path.join(os.path.dirname(ruta), "ocr_allas.ps1")
        if not os.path.isfile(script):
            with open(script, "w", encoding="utf-8-sig") as f:
                f.write(_PS_OCR)
        try:
            r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", script, "-ruta", ruta],
                               capture_output=True, timeout=40, **_sin_ventana())
        except (OSError, subprocess.TimeoutExpired) as e:
            raise RuntimeError(f"No se pudo usar el reconocimiento de texto de Windows: {e}")
        if r.returncode != 0:
            err = r.stderr.decode("utf-8", "replace").strip().splitlines()
            raise RuntimeError("El reconocimiento de texto de Windows no está disponible" + (f": {err[0][:160]}" if err else ""))
        return r.stdout.decode("utf-8", "replace")
    raise RuntimeError("Leer matrículas de una foto necesita Windows 10/11 (o tesseract instalado) en el PC del parking")


def _sin_ventana():
    return {"creationflags": 0x08000000} if os.name == "nt" else {}


_A_DIGITO = {"O": "0", "Q": "0", "D": "0", "U": "0", "I": "1", "L": "1", "J": "1", "T": "7", "Z": "2", "S": "5", "B": "8", "G": "6", "A": "4"}
_A_LETRA = {"0": "D", "8": "B", "5": "S", "2": "Z", "6": "G", "1": "L", "4": "A", "7": "T"}
_LETRAS_ACTUALES = set("BCDFGHJKLMNPRSTVWXYZ")


def extraer_matriculas(texto):
    """Matrículas españolas en un texto de OCR: 1234 BCD (actual), M 1234 AB (antigua) u otras de 5 a 8 caracteres."""
    vistas, res = set(), []

    def poner(m, peso):
        if m not in vistas:
            vistas.add(m)
            res.append((peso, m))
    for linea in (texto or "").upper().splitlines():
        s = re.sub(r"[^0-9A-Z]", "", linea.replace("Ñ", "N"))
        for i in range(0, max(0, len(s) - 6)):
            v = s[i:i + 7]
            num = "".join(_A_DIGITO.get(c, c) for c in v[:4])
            let = "".join(_A_LETRA.get(c, c) for c in v[4:])
            cambios = sum(a != b for a, b in zip(v, num + let))
            if num.isdigit() and all(c in _LETRAS_ACTUALES for c in let) and cambios <= 2:
                poner(num + let, 10 - cambios - (2 if i else 0))
        for m in re.finditer(r"([A-Z]{1,2})(\d{4})([A-Z]{1,2})", s):
            poner("".join(m.groups()), 4)
        if 5 <= len(s) <= 8 and sum(c.isdigit() for c in s) >= 3 and any(c.isalpha() for c in s):
            poner(s, 2)
        for tok in re.findall(r"[0-9A-Z]{5,8}", " ".join(re.sub(r"[^0-9A-Z]", " ", linea).split())):
            if sum(c.isdigit() for c in tok) >= 3 and any(c.isalpha() for c in tok):
                poner(tok, 1)
    return [m for _, m in sorted(res, key=lambda x: -x[0])]


def lanzar_vigilancia_senales(db_factory, intervalo=3):
    """Hilo de run.py: cada pocos segundos mira la ocupación y actualiza el semáforo / cartel si están activados."""
    def bucle():
        while True:
            time.sleep(intervalo)
            try:
                pk = db_factory()
                if any(pk.cfg(f"{p}_activo") == "1" for p in SENALES):
                    pk.senales_tick()
            except Exception as e:  # noqa: BLE001
                print("Semáforo / cartel:", e)
    t = threading.Thread(target=bucle, daemon=True, name="senales")
    t.start()
    return t
