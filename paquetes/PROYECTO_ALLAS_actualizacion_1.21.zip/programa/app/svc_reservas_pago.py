"""PROYECTO ALLAS 1.18 · pago online de la señal de las reservas (Stripe) y su descuento al salir.

Flujo: el cliente pulsa «Pagar ahora» en la página de reservas → se crea una sesión de Checkout por el importe exacto de la señal →
al volver (o cuando el programa consulta Stripe cada pocos minutos) la reserva pasa a «pagada» con método «Tarjeta (online)».
Si se cancela una reserva pagada con tarjeta, la señal se devuelve sola por Stripe. Cuando el vehículo entra, la señal pagada
se anota como pago anticipado del ticket (factura simplificada, método online/transferencia) y así se descuenta sola al salir.
"""
from datetime import timedelta

from .utiles import ErrorNegocio, parse

METODO_ONLINE = "Tarjeta (online)"


class SvcReservasPago:
    # ============================================================ ajustes
    def pago_online_reservas_activo(self):
        return (self.cfg("reservas_pago_online") == "1" and bool((self.cfg("stripe_clave") or "").strip())
                and self.activo("pagos_online_activo", "pagos_online"))

    def _exigir_pago_online(self):
        if not self.pago_online_reservas_activo():
            raise ErrorNegocio("El pago con tarjeta de las reservas no está disponible.", 409)

    # ============================================================ pagar (lo pide el cliente)
    def pub_pagar(self, datos, ip):
        """Crea (o recupera) la sesión de pago de la señal y devuelve su dirección."""
        rid = self._buscar_publica(datos.get("codigo"), datos.get("matricula"), ip)
        self._limitar(("pagar", ip), 20, 3600)
        self._exigir_pago_online()
        base = (self.cfg("reservas_web_url") or "").strip()
        if not base:
            raise ErrorNegocio("Falta la página de reservas de la web (Ajustes → Reservas online → Web de clientes)", 409)
        r = self.db.q1("SELECT * FROM reservas_previstas WHERE id=?", (rid,))
        if self.confirmar_senal_stripe(rid) == "pagada":
            return {"pagada": True, "reserva": self._vista_publica(rid)}
        r = self.db.q1("SELECT * FROM reservas_previstas WHERE id=?", (rid,))
        if r["estado"] not in ("pendiente", "usada") or r["pago"] != "pendiente_pago" or r["senal_cent"] <= 0:
            raise ErrorNegocio("Esta reserva no tiene ningún pago pendiente", 409)
        st = self._stripe()
        if r["pago_sesion"]:   # ya había una abierta: se reutiliza para no pagar dos veces
            try:
                s = st.sesion(r["pago_sesion"])
                if s.get("status") == "open" and s.get("url"):
                    return {"url": s["url"]}
            except Exception as e:  # noqa: BLE001  no se pudo ver la sesión anterior: se crea una nueva
                from . import errores
                errores.fallo("reservas.stripe", e)
        sep = "&" if "?" in base else "?"
        ses = st.crear_sesion_pago(
            r["senal_cent"], f"Reserva {r['codigo']} · {self.cfg('nombre_parking') or 'Parking'}",
            f"{base}{sep}c={r['codigo']}&pago=ok&s={{CHECKOUT_SESSION_ID}}", f"{base}{sep}c={r['codigo']}&pago=cancelado",
            {"reserva": r["codigo"], "tipo": "senal", "origen": "PROYECTO ALLAS"}, email=r["email"] or None)
        self.db.ex("UPDATE reservas_previstas SET pago_sesion=? WHERE id=?", (ses["id"], rid))
        return {"url": ses["url"]}

    def pub_pago_confirmar(self, datos, ip):
        rid = self._buscar_publica(datos.get("codigo"), datos.get("matricula"), ip)
        self._limitar(("pagar-ok", ip), 60, 3600)
        estado = self.confirmar_senal_stripe(rid) if self.pago_online_reservas_activo() else "desactivado"
        return {"estado": estado, "reserva": self._vista_publica(rid)}

    # ============================================================ confirmar con Stripe
    def confirmar_senal_stripe(self, rid):
        """Pregunta a Stripe si la sesión de la reserva está pagada. Devuelve: pagada | pendiente | caducada | devuelta | error | sin_sesion."""
        r = self.db.q1("SELECT * FROM reservas_previstas WHERE id=?", (int(rid),))
        if not r or not r["pago_sesion"]:
            return "pagada" if r and r["pago"] == "pagada" else "sin_sesion"
        if r["pago_ref"]:
            return "pagada" if r["pago"] == "pagada" else "devuelta"
        s = self._stripe().sesion(r["pago_sesion"])
        if s.get("payment_status") != "paid":
            if s.get("status") == "expired":
                self.db.ex("UPDATE reservas_previstas SET pago_sesion=NULL WHERE id=? AND pago_ref IS NULL", (r["id"],))
                return "caducada"
            return "pendiente"
        pi = (s.get("payment_intent") or "")[:80]
        meta = s.get("metadata") or {}
        importe = int(s.get("amount_total") or 0)
        correcto = meta.get("reserva") == r["codigo"] and importe == r["senal_cent"]
        with self.db.transaccion() as c:
            f = c.execute("SELECT estado, pago, pago_ref FROM reservas_previstas WHERE id=?", (r["id"],)).fetchone()
            if f["pago_ref"]:
                return "pagada"
            if correcto and f["estado"] in ("pendiente", "usada") and f["pago"] == "pendiente_pago":
                c.execute("UPDATE reservas_previstas SET pago='pagada', pago_fecha=?, pago_metodo=?, pago_limite=NULL, pago_ref=? WHERE id=?",
                          (self.ahora().isoformat(timespec="seconds"), METODO_ONLINE, pi, r["id"]))
                self.auditar(c, None, "reserva_senal_cobrada", f"{r['codigo']} {importe / 100:.2f} € ({METODO_ONLINE}) {s['id']}")
                self.aplicar_senal_a_ticket(c, r["id"])
                return "pagada"
            # Pagó, pero la reserva ya no admite la señal (cancelada, caducada o con otro importe): se devuelve el dinero
            c.execute("UPDATE reservas_previstas SET pago_ref=?, pago=CASE WHEN ?=1 THEN pago ELSE 'a_devolver' END WHERE id=?",
                      (pi, 1 if f["pago"] == "pagada" else 0, r["id"]))
            self.auditar(c, None, "reserva_senal_sin_reserva", f"{r['codigo']} pagado {importe / 100:.2f} € sin poder aplicarlo: se devuelve")
        self.reembolsar_senal_auto(r["id"], importe)
        return "devuelta"

    def sincronizar_senales_stripe(self):
        """Por si el cliente pagó y cerró el navegador: revisa las sesiones abiertas de los últimos 3 días."""
        if not self.pago_online_reservas_activo():
            return 0
        desde = (self.ahora() - timedelta(days=3)).isoformat(timespec="seconds")
        n = 0
        for f in self.db.q("SELECT id FROM reservas_previstas WHERE pago_sesion IS NOT NULL AND pago_ref IS NULL AND creada>=? "
                           "AND pago IN ('pendiente_pago','en_parking','a_devolver') LIMIT 100", (desde,)):
            try:
                if self.confirmar_senal_stripe(f["id"]) in ("pagada", "devuelta"):
                    n += 1
            except Exception as e:  # noqa: BLE001  sin conexión: se reintenta en la siguiente pasada
                from . import errores
                errores.fallo("reservas.stripe", e)
        return n

    # ============================================================ devolver
    def reembolsar_senal_auto(self, rid, importe_cent=None):
        """Devuelve por Stripe la señal pagada con tarjeta. Si no se puede, queda «Devolver señal» para hacerlo a mano."""
        r = self.db.q1("SELECT * FROM reservas_previstas WHERE id=?", (int(rid),))
        if not r or not r["pago_ref"] or r["pago"] == "devuelta" or r["senal_devuelta_ref"]:
            return False
        try:
            rf = self._stripe().reembolsar(r["pago_ref"], importe_cent, {"reserva": r["codigo"], "origen": "PROYECTO ALLAS"})
        except Exception as e:  # noqa: BLE001
            from . import errores
            errores.fallo("reservas.reembolso", e)
            return False
        with self.db.transaccion() as c:
            c.execute("UPDATE reservas_previstas SET pago='devuelta', senal_devuelta_ref=? WHERE id=?", ((rf.get("id") or "")[:80], r["id"]))
            self.auditar(c, None, "reserva_senal_reembolso", f"{r['codigo']} {((importe_cent or r['senal_cent']) / 100):.2f} € devueltos por Stripe {rf.get('id', '')}")
        return True

    def reembolsar_senal(self, usuario, rid):
        """El personal pide la devolución por Stripe de una señal «por devolver» (cuando la automática falló)."""
        self._exigir_permiso(usuario, "reservas")
        r = self.db.q1("SELECT * FROM reservas_previstas WHERE id=?", (int(rid),))
        if not r or r["pago"] != "a_devolver":
            raise ErrorNegocio("Esta reserva no tiene una señal por devolver", 409)
        if not r["pago_ref"]:
            raise ErrorNegocio("La señal no se pagó con tarjeta online: devuélvala a mano y márquela como devuelta", 409)
        self._exigir_pago_online()
        try:
            rf = self._stripe().reembolsar(r["pago_ref"], None, {"reserva": r["codigo"], "origen": "PROYECTO ALLAS"})
        except Exception as e:  # noqa: BLE001
            raise ErrorNegocio(f"No se pudo devolver por Stripe: {e}", 409)
        with self.db.transaccion() as c:
            c.execute("UPDATE reservas_previstas SET pago='devuelta', senal_devuelta_ref=? WHERE id=?", ((rf.get("id") or "")[:80], r["id"]))
            self.auditar(c, usuario["id"], "reserva_senal_reembolso", f"{r['codigo']} {r['senal_cent'] / 100:.2f} € devueltos por Stripe")
        return {"ok": True}

    def cerrar_sesion_pago(self, sesion):
        """Cierra en Stripe la sesión de pago de una reserva cancelada o cambiada (no pasa nada si no se puede)."""
        if not sesion or not self.pago_online_reservas_activo():
            return
        try:
            self._stripe().expirar_sesion(sesion)
        except Exception as e:  # noqa: BLE001
            from . import errores
            errores.fallo("reservas.stripe", e)

    # ============================================================ descontar al salir
    def aplicar_senal_a_ticket(self, c, rid):
        """Si la reserva ya se usó (el vehículo está dentro) y tiene la señal pagada, la anota como pago anticipado del ticket:
        así «lo ya pagado» la descuenta sola al cobrar la salida. Se hace una sola vez por reserva."""
        f = c.execute("SELECT id, codigo, estado, pago, senal_cent, pago_metodo, pago_ref, pago_sesion, ticket_id, senal_pago_id "
                      "FROM reservas_previstas WHERE id=?", (int(rid),)).fetchone()
        if not f or f["estado"] != "usada" or f["pago"] != "pagada" or f["senal_cent"] <= 0 or f["senal_pago_id"] or not f["ticket_id"]:
            return None
        tk = c.execute("SELECT estado FROM tickets WHERE id=?", (f["ticket_id"],)).fetchone()
        if not tk or tk["estado"] not in ("dentro", "pagado"):
            return None
        online = bool(f["pago_ref"])
        ref = f"Señal reserva {f['codigo']}" + ("" if online else f" ({f['pago_metodo'] or 'mostrador'})")
        iva = float(self.cfg("iva_pct") or 21)
        pago = self._insertar_pago(c, None, None, f["senal_cent"], "online" if online else "transferencia", None, None, ticket_id=f["ticket_id"],
                                   minutos=0, lineas=[(f["senal_cent"], iva)], online_ref=f["pago_sesion"] if online else None, referencia=ref[:60])
        if not online:
            c.execute("UPDATE pagos SET estado_factura='cobrada' WHERE id=?", (pago["id"],))
        c.execute("UPDATE reservas_previstas SET senal_pago_id=? WHERE id=?", (pago["id"], f["id"]))
        self.auditar(c, None, "reserva_senal_aplicada", f"{f['codigo']} {f['senal_cent'] / 100:.2f} € como pago anticipado del ticket {f['ticket_id']}")
        return pago
