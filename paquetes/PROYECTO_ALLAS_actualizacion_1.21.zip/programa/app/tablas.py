"""Tablas en CSV, Excel (.xlsx y .xls antiguo) y PDF, y lectura de .xls, sin librerías externas (1.6).

- `Tabla` describe un listado: título, columnas (nombre, ancho relativo, alineación) y filas de texto o números.
- `a_csv`, `a_xlsx`, `a_xls` y `a_pdf` la escriben. El .xlsx es un zip de XML; el .xls es un libro BIFF8 dentro de un archivo
  compuesto OLE2 (el formato de Excel 97-2003), con cabecera fija, formato de importes y primera fila inmovilizada.
- `leer_xls` lee la primera hoja de un .xls (BIFF8 con cadenas compartidas, números RK, fechas, fórmulas con resultado en caché).
"""
import csv
import io
import re
import struct
import zipfile
from datetime import datetime, timedelta
from xml.sax.saxutils import escape

MAX_FILAS_XLS = 65535


class Tabla:
    """columnas: [(título, ancho relativo, 'izq'|'der')]; filas: listas de str | int | float | None (los float son importes/decimales)."""

    def __init__(self, titulo, columnas, filas, subtitulo="", resumen="", hoja=None, empresa=""):
        self.titulo, self.subtitulo, self.resumen, self.empresa = titulo, subtitulo, resumen, empresa
        self.columnas = [(c[0], c[1] if len(c) > 1 else 10, c[2] if len(c) > 2 else "izq") for c in columnas]
        self.filas = [list(f) + [""] * (len(columnas) - len(f)) for f in filas]
        self.hoja = (hoja or titulo or "Datos")

    def nombres(self):
        return [c[0] for c in self.columnas]


def _hoja_valida(t):
    n = re.sub(r"[\[\]\*\?:/\\]", " ", str(t or "Datos")).strip()[:31]
    return n or "Datos"


def _txt(v):
    if v is None:
        return ""
    if isinstance(v, bool):
        return "Sí" if v else "No"
    if isinstance(v, float):
        return f"{v:.2f}".replace(".", ",")
    return str(v)


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


# ============================================================================ CSV
def a_csv(t, separador=";"):
    """CSV para Excel en español: UTF-8 con BOM, punto y coma, coma decimal."""
    s = io.StringIO()
    w = csv.writer(s, delimiter=separador, lineterminator="\r\n")
    w.writerow(t.nombres())
    for f in t.filas:
        w.writerow([_txt(v) for v in f])
    return ("﻿" + s.getvalue()).encode("utf-8")


# ============================================================================ XLSX
def _col_letra(i):
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def _ancho_cols(t):
    total = sum(c[1] for c in t.columnas) or 1
    out = []
    for i, c in enumerate(t.columnas):
        maxlen = max([len(c[0])] + [len(_txt(f[i])) for f in t.filas[:300]])
        rel = 12 + 60 * c[1] / total * len(t.columnas) / max(len(t.columnas), 1)
        out.append(max(8, min(60, max(maxlen + 2, min(rel, 30)))))
    return out


def a_xlsx(t):
    anchos = _ancho_cols(t)
    filas = []
    cab = "".join(f'<c r="{_col_letra(i)}1" s="1" t="inlineStr"><is><t xml:space="preserve">{escape(n)}</t></is></c>' for i, n in enumerate(t.nombres()))
    filas.append(f'<row r="1" ht="20" customHeight="1">{cab}</row>')
    for r, f in enumerate(t.filas, start=2):
        celdas = []
        for i, v in enumerate(f):
            ref = f"{_col_letra(i)}{r}"
            if v is None or v == "":
                continue
            if _num(v):
                celdas.append(f'<c r="{ref}" s="{2 if isinstance(v, float) else 0}"><v>{v!r}</v></c>')
            else:
                celdas.append(f'<c r="{ref}" t="inlineStr"><is><t xml:space="preserve">{escape(_txt(v))}</t></is></c>')
        filas.append(f'<row r="{r}">{"".join(celdas)}</row>')
    ultima = f"{_col_letra(len(t.columnas) - 1)}{len(t.filas) + 1}"
    cols = "".join(f'<col min="{i + 1}" max="{i + 1}" width="{w:.1f}" customWidth="1"/>' for i, w in enumerate(anchos))
    hoja = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            f'<dimension ref="A1:{ultima}"/>'
            '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
            f'<sheetFormatPr defaultRowHeight="15"/><cols>{cols}</cols><sheetData>{"".join(filas)}</sheetData>'
            f'<autoFilter ref="A1:{ultima}"/></worksheet>')
    estilos = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
               '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
               '<numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.00"/></numFmts>'
               '<fonts count="2"><font><sz val="10"/><name val="Arial"/></font><font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Arial"/></font></fonts>'
               '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
               '<fill><patternFill patternType="solid"><fgColor rgb="FF1F2937"/><bgColor indexed="64"/></patternFill></fill></fills>'
               '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
               '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
               '<cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
               '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"><alignment vertical="center"/></xf>'
               '<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs>'
               '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>')
    libro = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
             '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
             'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
             f'<sheets><sheet name="{escape(_hoja_valida(t.hoja))}" sheetId="1" r:id="rId1"/></sheets></workbook>')
    s = io.BytesIO()
    with zipfile.ZipFile(s, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                   '<Default Extension="xml" ContentType="application/xml"/>'
                   '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                   '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                   '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>')
        z.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr("xl/workbook.xml", libro)
        z.writestr("xl/_rels/workbook.xml.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
                   '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>')
        z.writestr("xl/worksheets/sheet1.xml", hoja)
        z.writestr("xl/styles.xml", estilos)
    return s.getvalue()


# ============================================================================ XLS (BIFF8 en un archivo compuesto OLE2)
def _rec(tipo, datos=b""):
    return struct.pack("<HH", tipo, len(datos)) + datos


def _cadena16(s):
    """Cadena BIFF8 con longitud de 2 bytes: comprimida (Latin-1) si se puede, UTF-16 si no."""
    s = s[:32767]
    try:
        return struct.pack("<HB", len(s), 0) + s.encode("latin-1")
    except UnicodeEncodeError:
        return struct.pack("<HB", len(s), 1) + s.encode("utf-16-le")


def _cadena8(s):
    s = s[:255]
    try:
        return struct.pack("<BB", len(s), 0) + s.encode("latin-1")
    except UnicodeEncodeError:
        return struct.pack("<BB", len(s), 1) + s.encode("utf-16-le")


def _xf(fuente, formato, estilo=False, padre=0, horiz=0, relleno=False, usados=0):
    flags = 0x0001 | (0x0004 if estilo else 0) | ((0xFFF if estilo else padre) << 4)
    borde2 = (0x1 << 26) if relleno else 0   # patrón sólido
    color = (0x12 | (0x41 << 7)) if relleno else (0x40 | (0x41 << 7))   # primer plano / fondo
    return _rec(0x00E0, struct.pack("<HHHBBBBHHIH", fuente, formato, flags, horiz | (0x20 if relleno else 0), 0, 0, usados,
                                      0, 0, borde2, color))


def _libro_biff(t):
    if len(t.filas) + 1 > MAX_FILAS_XLS:
        raise ValueError(f"El formato .xls admite como máximo {MAX_FILAS_XLS - 1} filas; use .xlsx o .csv")
    ncol = min(len(t.columnas), 256)

    def font(negrita, color):   # alto, flags, color, peso, escape, subrayado, familia, juego, reservado + nombre
        return _rec(0x0031, struct.pack("<HHHHHBBBB", 200, 0, color, 700 if negrita else 400, 0, 0, 0, 0, 0)
                    + bytes([5, 0]) + b"Arial")

    # ---- parte global
    g = [_rec(0x0809, struct.pack("<HHHHII", 0x0600, 0x0005, 0x0DBB, 0x07CC, 1, 6)),
         _rec(0x0042, struct.pack("<H", 0x04B0)),
         _rec(0x003D, struct.pack("<HHHHHHHHH", 0, 0, 0x3C00, 0x2400, 0x0038, 0, 0, 1, 0x0258)),
         font(False, 0x7FFF), font(True, 0x7FFF), font(True, 9), font(False, 0x7FFF)]   # fuentes 0 a 3
    for _ in range(15):
        g.append(_xf(0, 0, estilo=True))
    g.append(_xf(0, 0))                                   # 15: celda normal
    g.append(_xf(2, 0, relleno=True, usados=0xC0))        # 16: cabecera (blanco y negrita sobre azul oscuro)
    g.append(_xf(0, 4, usados=0x04))                      # 17: importe #,##0.00 (formato 4 de serie)
    g.append(_rec(0x0293, struct.pack("<HBB", 0x8000, 0, 0xFF)))   # estilo «Normal»
    sitio_boundsheet = len(b"".join(g))
    g.append(_rec(0x0085, struct.pack("<IBB", 0, 0, 0) + _cadena8(_hoja_valida(t.hoja))))
    g.append(_rec(0x000A))
    globales = b"".join(g)

    # ---- hoja
    nfilas = len(t.filas) + 1
    s = [_rec(0x0809, struct.pack("<HHHHII", 0x0600, 0x0010, 0x0DBB, 0x07CC, 1, 6)),
         _rec(0x020B, struct.pack("<IIII", 0, 0, nfilas, 0)),
         _rec(0x0055, struct.pack("<H", 8))]
    for i, ancho in enumerate(_ancho_cols(t)[:ncol]):
        s.append(_rec(0x007D, struct.pack("<HHHHHH", i, i, int(ancho * 256), 15, 0, 0)))
    s.append(_rec(0x0200, struct.pack("<IIHHH", 0, nfilas, 0, ncol, 0)))

    def celdas(r, valores, xf_fn):
        out = []
        for c in range(ncol):
            v = valores[c] if c < len(valores) else None
            if v is None or v == "":
                continue
            xf = xf_fn(v)
            if _num(v):
                out.append(_rec(0x0203, struct.pack("<HHHd", r, c, xf, float(v))))
            else:
                out.append(_rec(0x0204, struct.pack("<HHH", r, c, xf) + _cadena16(_txt(v))))
        return b"".join(out)

    todas = [(0, t.nombres(), lambda v: 16)] + [(i + 1, f, lambda v: 17 if isinstance(v, float) else 15)
                                                for i, f in enumerate(t.filas)]
    for ini in range(0, len(todas), 32):   # las filas se escriben en bloques de 32: primero sus registros ROW y luego sus celdas
        bloque = todas[ini:ini + 32]
        for r, _v, _f in bloque:
            s.append(_rec(0x0208, struct.pack("<HHHHHHHH", r, 0, ncol, 0x0140 if r == 0 else 0x00FF, 0, 0, 0x0100, 0)))
        for r, valores, xf_fn in bloque:
            s.append(celdas(r, valores, xf_fn))
    s.append(_rec(0x023E, struct.pack("<HHHIHHI", 0x06BE, 0, 0, 0x40, 0, 0, 0)))   # ventana con la primera fila inmovilizada
    s.append(_rec(0x0041, struct.pack("<HHHHBB", 0, 1, 1, 0, 2, 0)))
    s.append(_rec(0x000A))
    hoja = b"".join(s)
    # el desplazamiento de la hoja se escribe en el BOUNDSHEET ahora que se sabe cuánto mide la parte global
    globales = globales[:sitio_boundsheet + 4] + struct.pack("<I", len(globales)) + globales[sitio_boundsheet + 8:]
    return globales + hoja


def _ole2(flujo):
    """Archivo compuesto OLE2 de sectores de 512 bytes con un único flujo «Workbook» (relleno hasta 4096 para que no sea un mini-flujo)."""
    if len(flujo) < 4096:
        flujo = flujo + b"\x00" * (4096 - len(flujo))
    sec = 512
    n_datos = -(-len(flujo) // sec)
    flujo += b"\x00" * (n_datos * sec - len(flujo))
    n_fat = 1
    while n_fat * 128 < n_datos + n_fat + 1:   # los datos, los propios sectores FAT y un sector de directorio
        n_fat += 1
    if n_fat > 109:
        raise ValueError("El libro es demasiado grande para el formato .xls; use .xlsx o .csv")
    n_total = n_datos + n_fat + 1
    FIN, FAT_, LIBRE = 0xFFFFFFFE, 0xFFFFFFFD, 0xFFFFFFFF
    fat = [LIBRE] * (n_fat * 128)
    for i in range(n_datos):
        fat[i] = i + 1 if i < n_datos - 1 else FIN
    for k in range(n_fat):
        fat[n_datos + k] = FAT_
    sec_dir = n_datos + n_fat
    fat[sec_dir] = FIN
    cab = bytearray(512)
    cab[0:8] = bytes.fromhex("D0CF11E0A1B11AE1")
    struct.pack_into("<HHHHH", cab, 24, 0x003E, 0x0003, 0xFFFE, 9, 6)
    struct.pack_into("<IIIIIIIII", cab, 40, 0, n_fat, sec_dir, 0, 4096, FIN, 0, FIN, 0)
    difat = [n_datos + k for k in range(n_fat)] + [LIBRE] * (109 - n_fat)
    struct.pack_into("<109I", cab, 76, *difat)
    def entrada(nombre, tipo, izq, der, hijo, inicio, tam, color=1):
        e = bytearray(128)
        nb = nombre.encode("utf-16-le")
        e[0:len(nb)] = nb
        struct.pack_into("<HBBIII", e, 64, len(nb) + 2 if nombre else 0, tipo, color, izq, der, hijo)
        struct.pack_into("<I", e, 116, inicio)
        struct.pack_into("<I", e, 120, tam)
        return bytes(e)
    NINGUNO = 0xFFFFFFFF
    directorio = (entrada("Root Entry", 5, NINGUNO, NINGUNO, 1, FIN, 0)
                  + entrada("Workbook", 2, NINGUNO, NINGUNO, NINGUNO, 0, len(flujo))
                  + entrada("", 0, NINGUNO, NINGUNO, NINGUNO, 0, 0, 0) * 2)
    directorio = directorio.ljust(512, b"\x00")
    fat_bytes = struct.pack(f"<{len(fat)}I", *fat)
    return bytes(cab) + flujo + fat_bytes + directorio


def a_xls(t):
    return _ole2(_libro_biff(t))


# ============================================================================ PDF
def a_pdf(t, marca="", logo=None, horizontal=None):
    from . import pdf
    cols = [(c[0], c[1], c[2]) for c in t.columnas]
    if horizontal is None:
        horizontal = len(cols) > 5
    return pdf.listado_a_pdf({"titulo": t.titulo, "subtitulo": t.subtitulo, "empresa": t.empresa, "columnas": cols,
                              "filas": [[_txt(v) for v in f] for f in t.filas], "resumen": t.resumen, "marca": marca,
                              "horizontal": horizontal, "logo": logo})


FORMATOS = {
    "csv": ("text/csv; charset=utf-8", lambda t, **k: a_csv(t)),
    "xlsx": ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", lambda t, **k: a_xlsx(t)),
    "xls": ("application/vnd.ms-excel", lambda t, **k: a_xls(t)),
    "pdf": ("application/pdf", lambda t, **k: a_pdf(t, **k)),
}


# ============================================================================ lectura de .xls
def _flujo_ole2(datos):
    if datos[:8] != bytes.fromhex("D0CF11E0A1B11AE1"):
        raise ValueError("El archivo no es un Excel .xls válido. Ábralo en Excel y guárdelo como .xlsx o .csv.")
    sh = struct.unpack_from("<H", datos, 30)[0]
    sec = 1 << sh
    msh = struct.unpack_from("<H", datos, 32)[0]
    n_fat, sec_dir, _, corte, sec_minifat, n_minifat, sec_difat, n_difat = struct.unpack_from("<IIIIIIII", datos, 44)[0:8] if False else (
        struct.unpack_from("<I", datos, 44)[0], struct.unpack_from("<I", datos, 48)[0], 0, struct.unpack_from("<I", datos, 56)[0],
        struct.unpack_from("<I", datos, 60)[0], struct.unpack_from("<I", datos, 64)[0], struct.unpack_from("<I", datos, 68)[0],
        struct.unpack_from("<I", datos, 72)[0])
    def sector(i):
        ini = (i + 1) * sec
        return datos[ini:ini + sec]
    difat = list(struct.unpack_from("<109I", datos, 76))
    s = sec_difat
    for _ in range(n_difat):
        bloque = struct.unpack(f"<{sec // 4}I", sector(s))
        difat += list(bloque[:-1])
        s = bloque[-1]
    fat = []
    for i in difat:
        if i < 0xFFFFFFFA:
            fat += list(struct.unpack(f"<{sec // 4}I", sector(i)))
    def cadena(inicio):
        out, vistos = [], set()
        while inicio < 0xFFFFFFFA and inicio not in vistos and inicio < len(fat):
            vistos.add(inicio)
            out.append(inicio)
            inicio = fat[inicio]
        return out
    dir_datos = b"".join(sector(i) for i in cadena(sec_dir))
    entradas = []
    for k in range(0, len(dir_datos), 128):
        e = dir_datos[k:k + 128]
        if len(e) < 128:
            break
        ln = struct.unpack_from("<H", e, 64)[0]
        nombre = e[:max(ln - 2, 0)].decode("utf-16-le", "replace")
        entradas.append((nombre, e[66], struct.unpack_from("<I", e, 116)[0], struct.unpack_from("<I", e, 120)[0]))
    raiz = next((e for e in entradas if e[1] == 5), None)
    libro = next((e for e in entradas if e[1] == 2 and e[0] in ("Workbook", "Book")), None)
    if not libro:
        raise ValueError("El archivo .xls no contiene ningún libro de Excel. Guárdelo como .xlsx o .csv.")
    nombre, _, inicio, tam = libro
    if tam < corte:   # mini-flujo
        mini_raiz = b"".join(sector(i) for i in cadena(raiz[2]))
        minifat = []
        for i in cadena(sec_minifat):
            minifat += list(struct.unpack(f"<{sec // 4}I", sector(i)))
        msec = 1 << msh
        out, vistos, i = [], set(), inicio
        while i < 0xFFFFFFFA and i not in vistos and i < len(minifat):
            vistos.add(i)
            out.append(mini_raiz[i * msec:(i + 1) * msec])
            i = minifat[i]
        return b"".join(out)[:tam]
    return b"".join(sector(i) for i in cadena(inicio))[:tam]


def _rk(v):
    n = (v >> 2) & 0x3FFFFFFF
    if v & 2:
        x = float(n if n < 0x20000000 else n - 0x40000000)
    else:
        x = struct.unpack("<d", struct.pack("<Q", (v & 0xFFFFFFFC) << 32))[0]
    return x / 100 if v & 1 else x


FORMATOS_FECHA = set(range(14, 23)) | set(range(27, 37)) | set(range(45, 48)) | set(range(50, 59))


def _es_formato_fecha(codigo):
    c = re.sub(r'"[^"]*"|\[[^\]]*\]|\\.', "", codigo.lower())
    return bool(re.search(r"[dmyhs]", c)) and not re.search(r"[#0?]", c)


def _num_txt(x, fecha=False):
    if fecha and 0 < x < 2958466:
        d = datetime(1899, 12, 30) + timedelta(days=x)
        return d.strftime("%d/%m/%Y") if x == int(x) else d.strftime("%d/%m/%Y %H:%M")
    if x == int(x) and abs(x) < 1e15:
        return str(int(x))
    return repr(round(x, 10)).rstrip("0").rstrip(".") if "e" not in repr(x) else repr(x)


def leer_xls(datos):
    b = _flujo_ole2(datos)
    # ---- registros (con las continuaciones ya unidas donde importa)
    regs, pos = [], 0
    while pos + 4 <= len(b):
        tipo, ln = struct.unpack_from("<HH", b, pos)
        regs.append((tipo, b[pos + 4:pos + 4 + ln], pos))
        pos += 4 + ln
    sst, formatos, xf_fmt, hojas = [], {}, [], []
    i = 0
    while i < len(regs):
        tipo, d, off = regs[i]
        if tipo == 0x00FC:   # SST + CONTINUE
            partes = [d]
            j = i + 1
            while j < len(regs) and regs[j][0] == 0x003C:
                partes.append(regs[j][1]); j += 1
            sst = _leer_sst(partes)
            i = j
            continue
        if tipo == 0x041E and len(d) >= 4:
            n = struct.unpack_from("<H", d, 2)[0]
            f = d[5:5 + n * 2] if d[4] & 1 else d[5:5 + n]
            formatos[struct.unpack_from("<H", d, 0)[0]] = f.decode("utf-16-le" if d[4] & 1 else "latin-1", "replace")
        elif tipo == 0x00E0 and len(d) >= 4:
            xf_fmt.append(struct.unpack_from("<H", d, 2)[0])
        elif tipo == 0x0085 and len(d) >= 8:
            hojas.append((struct.unpack_from("<I", d, 0)[0], d[4], d[5]))
        i += 1
    if not hojas:
        raise ValueError("El archivo .xls no tiene ninguna hoja. Guárdelo como .xlsx o .csv.")
    inicio = next((h[0] for h in hojas if h[2] == 0 and h[1] == 0), hojas[0][0])
    def es_fecha(xf):
        if xf >= len(xf_fmt):
            return False
        f = xf_fmt[xf]
        return f in FORMATOS_FECHA or (f in formatos and _es_formato_fecha(formatos[f]))
    celdas, pos, ultima_formula = {}, inicio, None
    while pos + 4 <= len(b):
        tipo, ln = struct.unpack_from("<HH", b, pos)
        d = b[pos + 4:pos + 4 + ln]
        pos += 4 + ln
        if tipo == 0x0809 and pos - 4 - ln != inicio:
            break
        if tipo == 0x000A:
            break
        if tipo == 0x00FD and len(d) >= 10:
            r, c, xf, k = struct.unpack_from("<HHHI", d, 0)
            celdas[(r, c)] = sst[k] if k < len(sst) else ""
        elif tipo == 0x0204 and len(d) >= 9:
            r, c, xf, n = struct.unpack_from("<HHHH", d, 0)
            celdas[(r, c)] = (d[9:9 + n * 2].decode("utf-16-le", "replace") if d[8] & 1 else d[9:9 + n].decode("latin-1", "replace"))
        elif tipo == 0x0203 and len(d) >= 14:
            r, c, xf = struct.unpack_from("<HHH", d, 0)
            celdas[(r, c)] = _num_txt(struct.unpack_from("<d", d, 6)[0], es_fecha(xf))
        elif tipo == 0x027E and len(d) >= 10:
            r, c, xf, v = struct.unpack_from("<HHHI", d, 0)
            celdas[(r, c)] = _num_txt(_rk(v), es_fecha(xf))
        elif tipo == 0x00BD and len(d) >= 6:
            r, c0 = struct.unpack_from("<HH", d, 0)
            c1 = struct.unpack_from("<H", d, len(d) - 2)[0]
            for k, c in enumerate(range(c0, c1 + 1)):
                xf, v = struct.unpack_from("<HI", d, 4 + 6 * k)
                celdas[(r, c)] = _num_txt(_rk(v), es_fecha(xf))
        elif tipo == 0x0205 and len(d) >= 8:
            r, c, xf, v, esr = struct.unpack_from("<HHHBB", d, 0)
            celdas[(r, c)] = "" if esr else ("1" if v else "0")
        elif tipo == 0x0006 and len(d) >= 14:
            r, c, xf = struct.unpack_from("<HHH", d, 0)
            if d[12:14] == b"\xff\xff" and d[6] == 0:
                ultima_formula = (r, c)
            elif d[12:14] == b"\xff\xff":
                celdas[(r, c)] = ""
            else:
                celdas[(r, c)] = _num_txt(struct.unpack_from("<d", d, 6)[0], es_fecha(xf))
        elif tipo == 0x0207 and ultima_formula and len(d) >= 3:
            n = struct.unpack_from("<H", d, 0)[0]
            celdas[ultima_formula] = d[3:3 + n * 2].decode("utf-16-le", "replace") if d[2] & 1 else d[3:3 + n].decode("latin-1", "replace")
            ultima_formula = None
    if not celdas:
        return []
    nf, nc = max(k[0] for k in celdas) + 1, max(k[1] for k in celdas) + 1
    return [[celdas.get((r, c), "") for c in range(nc)] for r in range(nf)]


def _leer_sst(partes):
    """Tabla de cadenas compartidas. Una cadena puede continuar en el siguiente CONTINUE, que repite el byte de opciones."""
    total, unicas = struct.unpack_from("<II", partes[0], 0)
    cuerpo = [(partes[0], 8)] + [(p, 0) for p in partes[1:]]
    pi, po = 0, 8
    def datos_actual():
        return cuerpo[pi][0]
    def avanzar_trozo():
        nonlocal pi, po
        pi += 1
        po = 0
    out = []
    for _ in range(unicas):
        while pi < len(cuerpo) and po >= len(cuerpo[pi][0]):
            avanzar_trozo()
        if pi >= len(cuerpo):
            break
        d = datos_actual()
        if po + 3 > len(d):
            break
        n, flags = struct.unpack_from("<HB", d, po)
        po += 3
        ricos = struct.unpack_from("<H", d, po)[0] if flags & 8 else 0
        po += 2 if flags & 8 else 0
        fonetico = struct.unpack_from("<I", d, po)[0] if flags & 4 else 0
        po += 4 if flags & 4 else 0
        texto, restantes, ancho = [], n, 2 if flags & 1 else 1
        while restantes > 0:
            d = datos_actual()
            if po >= len(d):   # sigue en el CONTINUE: empieza con su propio byte de opciones
                avanzar_trozo()
                if pi >= len(cuerpo):
                    break
                d = datos_actual()
                ancho = 2 if d[po] & 1 else 1
                po += 1
            disponibles = (len(d) - po) // ancho
            toma = min(restantes, disponibles)
            trozo = d[po:po + toma * ancho]
            texto.append(trozo.decode("utf-16-le" if ancho == 2 else "latin-1", "replace"))
            po += toma * ancho
            restantes -= toma
        saltar = ricos * 4 + fonetico
        while saltar > 0 and pi < len(cuerpo):
            d = datos_actual()
            gasta = min(saltar, len(d) - po)
            po += gasta
            saltar -= gasta
            if saltar > 0:
                avanzar_trozo()
        out.append("".join(texto))
    return out
