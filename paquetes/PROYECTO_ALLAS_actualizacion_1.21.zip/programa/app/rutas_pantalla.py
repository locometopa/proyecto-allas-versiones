"""PROYECTO ALLAS · rutas de la API: pantalla de cliente, visor, publicidad e impresoras (se registran desde server.App._registrar)."""
import os


def registrar(app, r, p):
    from .server import Respuesta


    # --- 3.2: pantalla de cliente (segundo monitor) y publicidad
    @r("GET", "/api/pantalla-cliente", publica=True)
    def pantalla_cliente(req):
        return p.pantalla_cliente()

    # --- 3.3: visor TPV de texto
    @r("POST", "/api/visor")
    def visor_mostrar(req):
        return p.mostrar_visor(req.body.get("d") or {})

    @r("GET", "/api/visor")
    def visor_estado(req):
        return p.estado_visor()

    @r("POST", "/api/visor/prueba", rol=("admin",))
    def visor_prueba(req):
        return p.probar_visor(req.body if isinstance(req.body, dict) else None)

    @r("GET", "/api/impresoras", rol=("admin",))
    def impresoras_instaladas(req):
        from . import impresion
        try:
            lista = impresion.impresoras_sistema()
        except Exception as e:  # noqa: BLE001
            return {"impresoras": [], "error": str(e)}
        return {"impresoras": lista, "windows": os.name == "nt"}

    @r("GET", "/api/visor/puertos", rol=("admin",))
    def visor_puertos(req):
        return p.puertos_visor()

    @r("GET", r"/api/pantalla-cliente/foto/(\d+)", publica=True)
    @r("GET", r"/api/publicidad/(\d+)/imagen", publica=True)   # ruta antigua (la bloquean los bloqueadores de anuncios)
    def publicidad_imagen(req, aid):
        datos, tipo = p.imagen_anuncio(int(aid))
        return Respuesta(datos, tipo, {"Cache-Control": "public, max-age=86400"})

    @r("GET", "/api/publicidad", rol=("admin",))
    def publicidad(req):
        return p.anuncios()

    @r("GET", "/api/publicidad/carpeta-ejemplos", rol=("admin",))
    def publicidad_carpeta_ejemplos(req):
        return p.carpeta_imagenes_ejemplo()

    @r("POST", "/api/publicidad", rol=("admin",), crudo=True)
    def publicidad_nuevo(req):
        return {"id": p.guardar_anuncio(req.usuario["id"], req.query, req.raw)}

    @r("POST", r"/api/publicidad/(\d+)/imagen", rol=("admin",), crudo=True)
    def publicidad_cambiar_imagen(req, aid):
        return {"id": p.guardar_anuncio(req.usuario["id"], None, req.raw, int(aid))}

    @r("PUT", r"/api/publicidad/(\d+)", rol=("admin",))
    def publicidad_editar(req, aid):
        return {"id": p.guardar_anuncio(req.usuario["id"], req.body, None, int(aid))}

    @r("POST", r"/api/publicidad/(\d+)/mover", rol=("admin",))
    def publicidad_mover(req, aid):
        return p.mover_anuncio(req.usuario["id"], int(aid), req.body.get("sentido"))

    @r("DELETE", r"/api/publicidad/(\d+)", rol=("admin",))
    def publicidad_eliminar(req, aid):
        return p.eliminar_anuncio(req.usuario["id"], int(aid))
