"""Servidor HTTP local: sirve la interfaz (web/) y la API JSON (/api/...).

Solo biblioteca estándar. Escucha por defecto en 127.0.0.1 (el propio PC de caja).
"""
import hashlib
import json
import mimetypes
import os
import re
import secrets
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from . import __version__
from .backup import hacer_backup  # noqa: F401  (rutas44 lo toma de aquí)
from .servicios import ErrorNegocio
from . import errores

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WEB = os.path.join(RAIZ, "web")
SESION_HORAS = 14

CONFIG_EDITABLE = {"serie_proveedor", "factura_proveedor_numero_inicial", "sello_ticket", "sello_factura", "pantalla_cliente_transicion", "pantalla_cliente_transicion_ms", "pantalla_cliente_orden", "pantalla_cliente_ajuste", "pantalla_cliente_movimiento", "pantalla_cliente_rotulo", "pantalla_cliente_pie", "pantalla_cliente_progreso", "pantalla_cliente_color", "pantalla_cliente_tema", "factura_titulo_simplificada", "a4_modo", "a4_impresora", "a4_programa", "a4_completas", "semaforo_activo", "semaforo_conexion", "semaforo_destino", "semaforo_libre", "semaforo_completo", "semaforo_baudios", "semaforo_margen", "semaforo_ambito", "cartel_activo", "cartel_conexion", "cartel_destino", "cartel_libre", "cartel_completo", "cartel_baudios", "cartel_margen", "cartel_ambito", "reservas_margen_min", "plazas_abonados", "alerta_ocupacion_pct", "alerta_dias_dentro", "alerta_efectivo_cent", "alertas_activas", "cierre_email", "cierre_email_activo", "pago_movil_activo", "pago_movil_url", "pago_movil_minutos", "ticket_qr_pago", "tipos_vehiculo", "tipos_vehiculo_activo", "ticket_digital_activo", "estado_vehiculo_activo", "nube_activo", "nube_destino", "nube_carpeta", "nube_mantener", "nube_webdav_url", "nube_webdav_usuario", "nube_webdav_clave", "nube_clave", "rectificacion_activo", "confirmar_cierre", "factura_color", "factura_cabecera_tabla", "factura_logo_tam", "factura_pie", "factura_notas", "factura_titulo_completa", "factura_mostrar_detalle", "empresa_email", "empresa_web", "ticket_nombre_tam", "ticket_mostrar_razon", "ticket_mostrar_nif", "ticket_mostrar_telefono", "ticket_mostrar_web", "ticket_separador", "ticket_matricula_grande", "ticket_mostrar_cajero", "ticket_salida_imprimir", "ticket_llaves_mostrar", "ticket_llaves_defecto", "recibo_mostrar_cambio", "ticket_lineas_corte", "lista_negra_modo", "color_acento", "diseno", "devoluciones_activo", "actualizaciones_url", "actualizaciones_auto", "actualizaciones_origen", "actualizaciones_drive_carpeta", "actualizaciones_github_repo", "actualizaciones_drive_clave", "modo_tactil", "barrera_activa", "barrera_conexion", "barrera_destino", "barrera_abrir", "barrera_cerrar", "barrera_pulso_ms", "barrera_baudios", "barrera_eventos", "datafono_activo", "datafono_modo", "datafono_destino", "datafono_timeout", "serie_rectificativa", "acceso_intentos", "acceso_bloqueo_min", "licencia_servidor", "visor_modelo", "movil_red", "movil_turno_compartido", "recordatorios_activo", "vehiculo_fotos_activo", "arqueo_desglose_cierre", "arqueo_desglose_apertura", "arqueo_denominaciones", "arqueo_fondo_predefinido",
                   "pantalla_cliente_modo", "visor_conexion", "visor_destino", "visor_baudios", "visor_formato", "visor_protocolo",
                   "visor_columnas", "visor_reposo1", "visor_reposo2", "visor_efecto", "visor_velocidad", "descuentos_activo", "pantalla_cliente_activa", "pantalla_cliente_bienvenida",
                   "pantalla_cliente_gracias", "pantalla_cliente_segundos", "nombre_parking", "razon_social", "nif", "direccion", "telefono", "capacidad", "iva_pct",
                   "minutos_salida", "recargo_perdido_cent", "serie_factura", "impresora_modo",
                   "impresora_destino", "impresora_ancho", "cajon_pin", "mensaje_ticket", "backups_mantener",
                   "backup_destino_extra",
                   "ticket_codigo", "ticket_qr_tam", "ticket_cabecera_invertida", "ticket_cabecera_extra",
                   "ticket_mostrar_direccion", "ticket_mostrar_precio", "ticket_tarifas_url_activo", "fichaje_qr_activo", "fichaje_auto_turno", "fichaje_confirmar_salida", "fichaje_qr_mostrar_parking", "fichaje_qr_mostrar_nombre", "fichaje_qr_texto_sup", "fichaje_qr_texto_inf", "fichaje_qr_texto_pie", "fichaje_qr_tam", "ticket_tarifas_url", "ticket_entrada_titulo",
                   "ticket_entrada_pie", "recibo_titulo", "recibo_salida_texto", "recibo_pie",
                   "tarjeta_titulo", "tarjeta_pie", "ticket_entrada_copias", "entrada_ajuste_max_min", "logo_ticket", "logo_factura", "tema", "pantalla_inicio", "facturas_bono_email", "m360_activo", "m360_codigo", "m360_modo", "m360_url", "m360_usuario", "m360_clave", "m360_hora_envio", "lpr_activo", "lpr_entrada_accion", "lpr_salida_accion", "lpr_confianza_min", "verifactu_activo", "verifactu_entorno", "transferencia_activa", "transferencia_iban", "transferencia_titular", "ticket_perdido_activo", "renovacion_dias_gracia", "aviso_renovacion_asunto", "aviso_renovacion_texto", "avisos_activos", "avisos_caducidad_dias", "aviso_caducidad_asunto", "aviso_caducidad_texto", "aviso_pago_pendiente_asunto", "aviso_pago_pendiente_texto", "aviso_deuda_asunto", "aviso_deuda_texto", "msg_modo", "msg_canal", "msg_avisos_auto", "msg_prefijo", "msg_deuda_texto", "twilio_sid", "twilio_token", "twilio_desde_sms", "twilio_desde_whatsapp",
                   "smtp_servidor", "smtp_puerto", "smtp_seguridad", "smtp_usuario", "smtp_clave", "smtp_remitente",
                   "email_asunto", "email_texto", "factura_titulo_completa", "salida_al_cobrar", "email_metodo"}
CLAVE_OCULTA = "********"


# 3.0 · qué módulo de la licencia necesita cada grupo de rutas (el resto es la base)
RUTAS_MODULO = [
    ("pagos_online", (r"/api/pagos-online", r"/api/clientes/(\d+)/suscripcion", r"/api/suscripciones/")),
    ("mensajeria", (r"/api/comunicados", r"/api/clientes/(\d+)/recordatorio-mensaje", r"/api/mensajes/")),
    ("abonados", (r"/api/avisos", r"/api/abonados", r"/api/export/abonados", r"/api/bonos/", r"/api/clientes/(\d+)/recordatorio",
                  r"/api/clientes/(\d+)/cancelar-deudas", r"/api/renovaciones", r"/api/clientes/(\d+)/periodo",
                  r"/api/clientes/(\d+)/bono", r"/api/clientes/(\d+)/entrada", r"/api/clientes/(\d+)/tarjeta", r"/api/planes",
                  r"/api/clientes/(\d+)/vehiculos")),
    ("tienda", (r"/api/tienda/",)),
    ("madrid360", (r"/api/m360", r"/api/lpr/")),
    ("verifactu", (r"/api/verifactu",)),
    ("movil", (r"/api/movil",)),
    ("descuentos", (r"/api/descuentos", r"/api/vales")),
    ("perifericos", (r"/api/barrera", r"/api/datafono")),
    ("facturacion", (r"/api/pagos/",)),
    # 4.7: «Gestión ampliada» (sin ella, licencia Lite). Las tuplas: basta con uno de los módulos.
    ("gestion", (r"/api/tickets/manual", r"/api/tickets/(\d+)/extras", r"/api/extras", r"/api/reservas-previstas", r"/api/reservas-online", r"/api/lista-negra",
                 r"/api/historial", r"/api/estadisticas", r"/api/informes/", r"/api/auditoria", r"/api/apps", r"/api/senales",
                 r"/api/zonas", r"/api/config/exportar", r"/api/config/importar", r"/api/facturacion/")),
    (("gestion", "abonados"), (r"/api/clientes",)),
    (("gestion", "tienda"), (r"/api/productos", r"/api/facturas", r"/api/proveedores")),
]


def ips_locales():
    """Direcciones IPv4 de este PC en la red local (la de la salida por defecto primero)."""
    import socket
    ips = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))   # no envía nada: solo elige la interfaz
        ips.append(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
            if ip not in ips:
                ips.append(ip)
    except OSError:
        pass
    return [ip for ip in ips if not ip.startswith("127.")]


def es_local(ip):
    return ip in ("::1", "localhost") or ip.startswith("127.") or ip.startswith("::ffff:127.")


def es_privada(ip):
    import ipaddress
    try:
        a = ipaddress.ip_address(ip.replace("::ffff:", "") if ip.startswith("::ffff:") and "." in ip else ip)
    except ValueError:
        return False
    return a.is_private or a.is_link_local or a.is_loopback


RUTAS_PAGO_MOVIL = ("/pagar", "/pagar.html", "/favicon.svg", "/favicon.ico")
# 1.14: el programa ya no sirve la página de reservas: la web del aparcamiento usa la API /api/publico/reservas (kit en integracion_web/)
PREFIJO_RESERVAS = "/api/publico/reservas"

# 4.3: permisos por usuario — (método, expresión de la ruta, permiso). Sustituyen a la comprobación de rol de esas rutas.
PERMISO_RUTAS = [
    # (anular tickets se comprueba en el servicio: un cajero puede anular con el PIN de un supervisor)
    ("POST", r"^/api/tickets/manual(/calcular)?$", "ticket_manual"),
    ("POST", r"^/api/tickets/\d+/(tarifa|matricula|reserva)$", "cambiar_tarifa"),
    ("POST", r"^/api/tickets/\d+/descuento$", "descuentos"),
    ("POST", r"^/api/caja/abrir$", "abrir_cajon"),
    ("POST", r"^/api/caja/movimiento$", "movimientos_caja"),
    ("GET", r"^/api/(informe(\.csv)?|estadisticas|auditoria(/buscar|\.csv)?|informes/.*)$", "ver_informes"),
    ("POST", r"^/api/informes/cierre/enviar$", "ver_informes"),
    ("GET", r"^/api/turnos(/\d+)?$", "turnos_ajenos"),
    ("*", r"^/api/lista-negra(/\d+)?$", "lista_negra"),
    ("POST", r"^/api/clientes/\d+/bono$", "abonados"),
    ("POST", r"^/api/bonos/\d+/cobrar$", "abonados"),
    ("GET", r"^/api/(historial|clientes/exportar|m360/listado)\.csv$", "exportar"),
]


def dentro_de(base, ruta):
    """1.5: ¿está 'ruta' dentro de la carpeta 'base'? (comparando carpetas enteras, no el principio del texto)."""
    try:
        return os.path.commonpath([os.path.abspath(ruta), os.path.abspath(base)]) == os.path.abspath(base)
    except ValueError:   # otra unidad en Windows
        return False


# 1.5: cabeceras de seguridad en todas las respuestas; la política CSP solo en las páginas HTML.
# Los estilos en línea (style="…") los genera la propia interfaz, por eso style-src admite 'unsafe-inline'; los scripts, no.
CABECERAS_SEGURIDAD = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "SAMEORIGIN",
    "Referrer-Policy": "no-referrer",
    "Permissions-Policy": "camera=(self), microphone=(), geolocation=(), payment=()",
}
CSP = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; "
       "font-src 'self' data:; connect-src 'self'; frame-src 'self' blob:; media-src 'self' blob:; object-src 'none'; "
       "base-uri 'self'; form-action 'self'; frame-ancestors 'self'")


def permiso_de_ruta(metodo, ruta):
    for m, patron, permiso in PERMISO_RUTAS:
        if m == "*" and metodo == "GET":
            continue   # consultar la lista negra es libre (se avisa en Entrada)
        if (m == metodo or m == "*") and re.match(patron, ruta):
            return permiso
    return None


def modulo_de_ruta(patron):
    for modulo, prefijos in RUTAS_MODULO:   # el orden importa: recordatorio-mensaje antes que recordatorio
        if any(patron.startswith(pr) for pr in prefijos):
            return modulo
    return None


class App:
    def __init__(self, parking, carpeta_backups):
        self.p = parking
        self.backups = carpeta_backups
        self.sesiones = {}
        self._lock = threading.Lock()
        self.rutas = []
        self.srv = None            # lo asigna run.py; se usa para reiniciar tras una actualización
        self.puerto = None         # puerto en el que escucha (lo fija servir)
        from .agente_reservas import AgenteReservas
        self.agente = AgenteReservas(self)   # 1.18: conexión saliente con el servidor intermedio de reservas (apagada hasta configurarla)
        from .web_pruebas import WebPruebas
        self.web_pruebas = WebPruebas(self)   # 1.16: web local de pruebas de las reservas (apagada hasta que se active en Ajustes)
        self.reiniciar = False
        self.raiz = RAIZ
        self.carpeta_base = None   # 3.4: carpeta «datos» real (la asigna run.py); la demo vive en <datos>/demo
        self.demo = bool(getattr(parking, "demo", False))
        self._registrar()

    def _comprobar_pin(self, req):
        """Pide de nuevo el PIN para operaciones delicadas. Un PIN erróneo NO cierra la sesión (403, no 401)."""
        try:
            self.p.autenticar(req.usuario["usuario"], req.body.get("pin", ""), getattr(req, "ip", None))
        except ErrorNegocio as e:
            if e.codigo == 429:
                raise
            raise ErrorNegocio("PIN incorrecto", 403)

    def programar_reinicio(self, segundos=1.0, reiniciar=True):
        """Para el servidor; run.py lo vuelve a arrancar con el programa nuevo (o se apaga si reiniciar=False)."""
        def parar():
            self.reiniciar = reiniciar
            self.web_pruebas.parar()
            self.agente.parar()
            if self.srv:
                self.srv.shutdown()
        threading.Timer(segundos, parar).start()

    # ------------------------------------------------------------ sesiones
    # 3.9: las sesiones se guardan (solo el resumen SHA-256 del token) y sobreviven a un reinicio del programa
    @staticmethod
    def _hash_tok(tok):
        return hashlib.sha256((tok or "").encode()).hexdigest()

    def crear_sesion(self, usuario, origen=None):
        tok = secrets.token_urlsafe(24)
        ahora = time.time()
        with self._lock:
            self.sesiones[tok] = {"usuario": usuario, "visto": ahora, "guardado": ahora}
        try:
            with self.p.db.transaccion() as c:
                c.execute("DELETE FROM sesiones WHERE visto < ?", (ahora - SESION_HORAS * 3600,))
                c.execute("INSERT INTO sesiones(token_hash, usuario_id, creada, visto, origen) VALUES(?,?,?,?,?)",
                          (self._hash_tok(tok), usuario["id"], datetime.now().astimezone().isoformat(timespec="seconds"),
                           ahora, origen))
        except Exception as e_:  # noqa: BLE001  (sin tabla: base antigua en pruebas)
            errores.fallo("server.crear_sesion", e_)
        return tok

    def usuario_de(self, tok):
        if not tok:
            return None
        ahora = time.time()
        with self._lock:
            s = self.sesiones.get(tok)
        if not s:   # quizá de antes de un reinicio
            try:
                r = self.p.db.q1("SELECT s.visto, u.id, u.nombre, u.usuario, u.rol FROM sesiones s JOIN usuarios u "
                                 "ON u.id=s.usuario_id AND u.activo=1 WHERE s.token_hash=?", (self._hash_tok(tok),))
            except Exception:  # noqa: BLE001
                r = None
            if not r:
                return None
            s = {"usuario": {k: r[k] for k in ("id", "nombre", "usuario", "rol")}, "visto": r["visto"], "guardado": r["visto"]}
            with self._lock:
                self.sesiones[tok] = s
        if ahora - s["visto"] > SESION_HORAS * 3600:
            self.cerrar_sesion(tok)
            return None
        s["visto"] = ahora
        if ahora - s["guardado"] > 300:   # se apunta la actividad cada 5 min, no en cada petición
            s["guardado"] = ahora
            try:
                with self.p.db.transaccion() as c:
                    c.execute("UPDATE sesiones SET visto=? WHERE token_hash=?", (ahora, self._hash_tok(tok)))
            except Exception as e_:  # noqa: BLE001
                errores.fallo("server.usuario_de", e_, grave=True)
        return s["usuario"]

    def cerrar_sesion(self, tok):
        with self._lock:
            self.sesiones.pop(tok or "", None)
        try:
            with self.p.db.transaccion() as c:
                c.execute("DELETE FROM sesiones WHERE token_hash=?", (self._hash_tok(tok),))
        except Exception as e_:  # noqa: BLE001
            errores.fallo("server.cerrar_sesion", e_, grave=True)

    def cerrar_todas_las_sesiones(self):
        with self._lock:
            self.sesiones.clear()
        try:
            with self.p.db.transaccion() as c:
                c.execute("DELETE FROM sesiones")
        except Exception as e_:  # noqa: BLE001
            errores.fallo("server.cerrar_todas_las_sesiones", e_)

    # -------------------------------------------------------------- rutas
    def ruta(self, metodo, patron, rol=None, publica=False, crudo=False, modulo=None):
        def deco(f):
            f.crudo = crudo  # el cuerpo llega como bytes (subida de archivos), no como JSON
            f.modulo = modulo or modulo_de_ruta(patron)  # 3.0: módulo de la licencia que necesita
            self.rutas.append((metodo, re.compile("^" + patron + "$"), f, rol, publica))
            return f
        return deco

    def _registrar(self):
        p, r = self.p, self.ruta
        from . import rutas44   # 4.4: se registran antes, así pueden sustituir a alguna anterior
        rutas44.registrar(self, r, p)
        from . import rutas50   # 4.49: eliminar usuarios y fichaje por QR
        rutas50.registrar(self, r, p)
        from . import rutas58   # 4.58: facturas a proveedores y sello del garaje
        rutas58.registrar(self, r, p)
        from . import rutas_sistema   # 1.3: el resto de rutas, por áreas (el orden no importa: no se solapan)
        from . import rutas_acceso
        from . import rutas_caja
        from . import rutas_tickets
        from . import rutas_clientes
        from . import rutas_facturacion
        from . import rutas_pantalla
        from . import rutas_tablas, rutas_reservas
        for modulo in (rutas_sistema, rutas_acceso, rutas_caja, rutas_tickets, rutas_clientes, rutas_facturacion, rutas_pantalla, rutas_tablas, rutas_reservas):
            modulo.registrar(self, r, p)


class Respuesta:
    def __init__(self, cuerpo, tipo, cabeceras=None):
        self.cuerpo, self.tipo, self.cabeceras = cuerpo, tipo, cabeceras or {}


class Peticion:
    pass


def crear_handler(app):
    class Handler(BaseHTTPRequestHandler):
        server_version = f"ProyectoAllas/{__version__}"

        def log_message(self, fmt, *args):  # silencioso salvo errores
            pass

        def _responder(self, codigo, cuerpo, tipo="application/json; charset=utf-8", cabeceras=None):
            self.send_response(codigo)
            self.send_header("Content-Type", tipo)
            self.send_header("Content-Length", str(len(cuerpo)))
            self.send_header("Cache-Control", "no-store")
            for k, v in CABECERAS_SEGURIDAD.items():   # 1.5
                self.send_header(k, v)
            if tipo.startswith("text/html"):
                self.send_header("Content-Security-Policy", CSP)
            for k, v in (cabeceras or {}).items():
                self.send_header(k, v)
            for k, v in self._cabeceras_cors().items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(cuerpo)

        def _cabeceras_cors(self):
            """1.14: la API de reservas la puede llamar la web del aparcamiento si su origen está en la lista de Ajustes (o «*»)."""
            origen = self.headers.get("Origin")
            if not origen or not self._ruta_reservas():
                return {}
            permitidos = [x.strip().rstrip("/").lower() for x in (app.p.cfg("reservas_origenes") or "").split(",") if x.strip()]
            if "*" in permitidos:
                return {"Access-Control-Allow-Origin": "*"}
            if origen.rstrip("/").lower() in permitidos:
                return {"Access-Control-Allow-Origin": origen.rstrip("/"), "Vary": "Origin"}
            return {}

        def do_OPTIONS(self):
            if not self._ruta_reservas() or self._remoto_bloqueado():
                return self._responder(404, b"", "text/plain")
            cab = self._cabeceras_cors()
            if cab:
                extra = {"Access-Control-Allow-Methods": "GET, POST, OPTIONS", "Access-Control-Allow-Headers": "Content-Type", "Access-Control-Max-Age": "600"}
            self._responder(204 if cab else 403, b"", "text/plain", extra if cab else None)   # (el Allow-Origin lo añade _responder)

        def _json(self, codigo, obj):
            self._responder(codigo, json.dumps(obj, ensure_ascii=False).encode("utf-8"))

        def _es_publico(self):
            """4.3: petición que llega desde Internet (IP pública, a través de un proxy/túnel o con el nombre público)."""
            ip = self.client_address[0]
            if self.headers.get("X-Forwarded-For") or self.headers.get("CF-Connecting-IP"):
                return True
            url = app.p.cfg("pago_movil_url") or ""
            host_pub = urlparse(url if "://" in url else "https://" + url).hostname if url else None
            host = (self.headers.get("Host") or "").split(":")[0].lower()
            if host_pub and host == host_pub.lower() and host not in ("127.0.0.1", "localhost"):
                return True
            return not (es_local(ip) or es_privada(ip))

        def _ruta_reservas(self):
            ruta = urlparse(self.path).path
            return ruta.startswith(PREFIJO_RESERVAS)

        def _ruta_publica(self):
            ruta = urlparse(self.path).path
            return (ruta in RUTAS_PAGO_MOVIL or ruta.startswith("/api/publico/")) and not self._ruta_reservas()

        def _remoto_bloqueado(self):
            """3.5: desde otro equipo solo se entra si se arrancó con --host o con la caja móvil activada.
            4.3: desde Internet solo la página de pago del ticket (si está activada); nada más del programa."""
            publico = self._es_publico()
            if self._ruta_reservas():   # 1.14: solo con las reservas desde la web activadas; desde Internet solo si se permitió en Ajustes
                if not app.p.reservas_publicas_activas():
                    return "No disponible."
                return None if (not publico or app.p.cfg("reservas_internet") == "1") else "No disponible."
            if publico or (self._ruta_publica() and not es_local(self.client_address[0])):
                if self._ruta_publica() and app.p.cfg("pago_movil_activo") == "1":
                    return None
                return "No disponible."
            if es_local(self.client_address[0]) or getattr(app, "red_explicita", False):
                return None
            if app.p.cfg("movil_red") != "1":
                return "El acceso desde otros equipos está desactivado (Ajustes → Equipos → Caja móvil)."
            if not app.p.tiene_modulo("movil"):
                return "El módulo «Caja móvil / tablet» no está incluido en la licencia."
            return None

        def _ip_cliente(self):
            """1.14: tras un proxy de confianza (Ajustes → Reservas online) la IP real es la última de X-Forwarded-For que no sea del proxy;
            así el límite por IP de las reservas funciona por cliente y no por proxy."""
            ip = self.client_address[0]
            if not self._ruta_reservas():
                return ip
            wp = app.web_pruebas
            if wp.activa and es_local(ip) and self.headers.get("X-Allas-Prueba") == wp.token:   # 1.16: petición de la web local de pruebas
                return "prueba-local"
            if es_local(ip) and app.agente.activo() and secrets.compare_digest(self.headers.get("X-Allas-Relay") or "", app.agente.token_local):
                import ipaddress   # 1.18: llega por el agente del servidor intermedio: la IP real del cliente la pone el agente
                try:
                    return str(ipaddress.ip_address((self.headers.get("X-Allas-IP") or "").strip()))
                except ValueError:
                    return "relay-desconocida"
            proxies = {x.strip() for x in (app.p.cfg("reservas_proxies") or "").split(",") if x.strip()}
            if ip in proxies:
                for x in reversed([y.strip() for y in (self.headers.get("X-Forwarded-For") or "").split(",") if y.strip()]):
                    if x not in proxies:
                        return x
            return ip

        def _api(self, metodo):
            url = urlparse(self.path)
            bloqueo = self._remoto_bloqueado()
            if bloqueo:
                return self._json(403, {"error": bloqueo})
            for m, patron, f, rol, publica in app.rutas:
                if m != metodo:
                    continue
                mt = patron.match(url.path)
                if not mt:
                    continue
                req = Peticion()
                req.query = {k: v[0] for k, v in parse_qs(url.query).items()}
                req.ip = self._ip_cliente()
                req.host = self.headers.get("Host")
                req.token = self.headers.get("X-Token") or req.query.get("token")
                req.headers_camara = self.headers.get("X-Token-Camara") or req.query.get("token_camara")
                req.clave_nube = self.headers.get("X-Clave")
                req.usuario = app.usuario_de(req.token)
                if req.usuario and self.headers.get("X-Caja-Movil") == "1":
                    req.usuario = {**req.usuario, "_movil": True}
                if not publica and not req.usuario:
                    return self._json(401, {"error": "Sesión caducada. Vuelva a entrar."})
                permiso = permiso_de_ruta(metodo, url.path) if req.usuario else None   # 4.3: permisos por usuario
                if permiso:
                    if not app.p.puede(req.usuario, permiso):
                        from .funciones43 import NOMBRES_PERMISO
                        return self._json(403, {"error": f"No tiene permiso: {NOMBRES_PERMISO.get(permiso, permiso)}"})
                elif rol and req.usuario["rol"] not in rol:
                    return self._json(403, {"error": "No tiene permiso para esta operación"})
                mods = f.modulo if isinstance(f.modulo, tuple) else (f.modulo,) if f.modulo else ()
                if mods and not any(app.p.tiene_modulo(m) for m in mods):
                    from .licencia import NOMBRE_MODULO
                    return self._json(403, {"error": f"El módulo «{NOMBRE_MODULO.get(mods[0], mods[0])}» no está incluido "
                                                     "en su licencia (Ajustes → Sistema → Licencia).", "modulo": mods[0]})
                n = int(self.headers.get("Content-Length") or 0)
                try:
                    if getattr(f, "crudo", False):
                        if n > 2_000_000_000:
                            return self._json(413, {"error": "Archivo demasiado grande"})
                        req.raw, req.body = self.rfile.read(n) if n else b"", {}
                    else:
                        req.body = json.loads(self.rfile.read(n) or b"{}") if n else {}
                    res = f(req, *mt.groups())
                except ErrorNegocio as e:
                    return self._json(e.codigo, {**getattr(e, "datos", {}), "error": str(e)})
                except (ValueError, KeyError, TypeError) as e:
                    return self._json(400, {"error": f"Datos no válidos: {e}"})
                except Exception as e:
                    import traceback
                    traceback.print_exc()
                    return self._json(500, {"error": f"Error interno: {e}"})
                if isinstance(res, Respuesta):
                    return self._responder(200, res.cuerpo, res.tipo, res.cabeceras)
                return self._json(200, res)
            self._json(404, {"error": "Ruta no encontrada"})

        def _estatico(self):
            bloqueo = self._remoto_bloqueado()
            if bloqueo:
                return self._responder(403, ("<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width'>"
                                             f"<body style='font-family:sans-serif;padding:24px'><h2>PROYECTO ALLAS</h2><p>{bloqueo}</p>").encode(),
                                       "text/html; charset=utf-8")
            ruta = urlparse(self.path).path
            if ruta == "/":
                ruta = "/index.html"
            if ruta == "/pagar":
                ruta = "/pagar.html"
            archivo = os.path.normpath(os.path.join(WEB, ruta.lstrip("/")))
            if not dentro_de(WEB, archivo) or not os.path.isfile(archivo):   # 1.5: «web2» ya no cuela como «web»
                return self._responder(404, b"No encontrado", "text/plain")
            tipo = {".webmanifest": "application/manifest+json", ".svg": "image/svg+xml",
                    ".ico": "image/x-icon", ".js": "text/javascript", ".css": "text/css"}.get(
                os.path.splitext(archivo)[1].lower()) or mimetypes.guess_type(archivo)[0] or "application/octet-stream"
            if tipo.startswith("text/") or tipo.endswith("javascript"):
                tipo += "; charset=utf-8"
            with open(archivo, "rb") as f:
                self._responder(200, f.read(), tipo)

        def do_GET(self):
            if self.path.startswith("/api/"):
                return self._api("GET")
            self._estatico()

        def do_POST(self):
            self._api("POST")

        def do_PUT(self):
            self._api("PUT")

        def do_DELETE(self):
            self._api("DELETE")

    return Handler


class ServidorExclusivo(ThreadingHTTPServer):
    """4.8: el puerto se abre en exclusiva. En Windows, SO_REUSEADDR deja abrir un puerto que ya usa otro
    programa (y las peticiones irían a uno u otro al azar); con SO_EXCLUSIVEADDRUSE la apertura falla y se
    prueba otro puerto."""
    allow_reuse_address = os.name != "nt"

    def server_bind(self):
        import socket
        excl = getattr(socket, "SO_EXCLUSIVEADDRUSE", None)
        if os.name == "nt" and excl is not None:
            try:
                self.socket.setsockopt(socket.SOL_SOCKET, excl, 1)
            except OSError:
                pass
        super().server_bind()


def puerto_en_uso(puerto, host="127.0.0.1", espera=0.3):
    """4.8: ¿hay algún programa escuchando ya en ese puerto? (se intenta conectar)."""
    import socket
    if not puerto:
        return False
    try:
        with socket.create_connection((host, puerto), timeout=espera):
            return True
    except OSError:
        return False


def servir(app, host="127.0.0.1", puerto=8080):
    if puerto_en_uso(puerto):
        raise OSError(f"el puerto {puerto} ya lo usa otro programa")
    srv = ServidorExclusivo((host, puerto), crear_handler(app))
    srv.daemon_threads = True
    app.puerto = srv.server_address[1]
    app.agente.reiniciar()   # 1.18: si hay servidor intermedio configurado, empieza a atender sus peticiones
    return srv
