"""PROYECTO ALLAS · lógica de negocio: datos de la instalación, logo, aplicaciones externas, fabricante, importar/exportar configuración y tareas periódicas (1.4: sale de servicios.py; se mezcla en la clase Parking)."""
import os
import re

from . import logo as logos
from .utiles import ErrorNegocio, iso


class SvcSistema:
    @property
    def carpeta_logo(self):
        return os.path.join(self.carpeta_datos, "logo")

    def guardar_logo(self, actor_id, jpeg_b64, ancho, alto, bits_b64):
        import base64
        try:
            jpeg, bits = base64.b64decode(jpeg_b64 or ""), base64.b64decode(bits_b64 or "")
            info = logos.guardar(self.carpeta_logo, jpeg, ancho, alto, bits)
        except (ValueError, TypeError) as e:
            raise ErrorNegocio(str(e) or "Imagen no válida")
        with self.db.transaccion() as c:
            self.auditar(c, actor_id, "logo_guardar", f"ticket {info['ticket_ancho']}x{info['ticket_alto']} "
                         f"pdf {info['jpeg_ancho']}x{info['jpeg_alto']}")
        return info

    def borrar_logo(self, actor_id):
        logos.borrar(self.carpeta_logo)
        with self.db.transaccion() as c:
            c.execute("UPDATE config SET valor='0' WHERE clave IN ('logo_ticket','logo_factura')")
            self.auditar(c, actor_id, "logo_borrar", "")
        return {"ok": True}

    # ------------------------------------------------------------------ 4.1 · aplicaciones externas (menú lateral)
    def apps_externas(self, usuario=None, todas=False):
        filas = self.db.q("SELECT * FROM apps_externas" + ("" if todas else " WHERE activa=1") + " ORDER BY orden, id")
        if usuario and not todas:
            filas = [a for a in filas if usuario["rol"] in (a["roles"] or "").split(",")]
        return filas

    def guardar_app_externa(self, actor_id, datos, aid=None):
        nombre = (datos.get("nombre") or "").strip()[:40]
        if not nombre:
            raise ErrorNegocio("Indique el nombre del botón")
        tipo = datos.get("tipo") if datos.get("tipo") in ("web", "programa") else None
        if not tipo:
            raise ErrorNegocio("Elija si abre una web o un programa")
        destino = (datos.get("destino") or "").strip()[:500]
        if not destino:
            raise ErrorNegocio("Indique la dirección web o la ruta del programa")
        if tipo == "web":
            if not re.match(r"^[a-z][a-z0-9+.-]*:", destino, re.I):
                destino = "https://" + destino
            if not destino.lower().startswith(("http://", "https://", "mailto:", "tel:")):
                raise ErrorNegocio("La dirección web debe empezar por http:// o https://")
        roles = [r for r in (datos.get("roles") or ["admin", "supervisor", "cajero"]) if r in ("admin", "supervisor", "cajero")]
        if not roles:
            raise ErrorNegocio("Elija quién puede usar el botón")
        valores = (nombre, tipo, destino, (datos.get("argumentos") or "").strip()[:500] or None,
                   (datos.get("icono") or "").strip()[:4] or None, (datos.get("color") or "").strip()[:9] or None,
                   ",".join(roles), int(datos.get("orden") or 0), 0 if datos.get("activa") is False else 1)
        with self.db.transaccion() as c:
            if aid:
                if not c.execute("UPDATE apps_externas SET nombre=?, tipo=?, destino=?, argumentos=?, icono=?, color=?, roles=?, "
                                 "orden=?, activa=? WHERE id=?", (*valores, int(aid))).rowcount:
                    raise ErrorNegocio("No encontrada", 404)
            else:
                aid = c.execute("INSERT INTO apps_externas(nombre, tipo, destino, argumentos, icono, color, roles, orden, activa) "
                                "VALUES(?,?,?,?,?,?,?,?,?)", valores).lastrowid
            self.auditar(c, actor_id, "app_externa_guardar", f"{nombre}: {destino}")
        return self.db.q1("SELECT * FROM apps_externas WHERE id=?", (int(aid),))

    def borrar_app_externa(self, actor_id, aid):
        with self.db.transaccion() as c:
            f = c.execute("SELECT nombre FROM apps_externas WHERE id=?", (int(aid),)).fetchone()
            if not f:
                raise ErrorNegocio("No encontrada", 404)
            c.execute("DELETE FROM apps_externas WHERE id=?", (int(aid),))
            self.auditar(c, actor_id, "app_externa_borrar", f[0])
        return {"ok": True}

    def abrir_app_externa(self, usuario, aid, lanzar=None):
        """Los programas se abren en el PC donde funciona el servidor del programa (la caja principal)."""
        a = self.db.q1("SELECT * FROM apps_externas WHERE id=? AND activa=1", (int(aid),))
        if not a or usuario["rol"] not in (a["roles"] or "").split(","):
            raise ErrorNegocio("Aplicación no disponible", 404)
        if a["tipo"] == "web":
            return {"tipo": "web", "url": a["destino"]}
        from . import perifericos
        try:
            (lanzar or perifericos.lanzar_programa)(a["destino"], a.get("argumentos") or "")
        except (OSError, ValueError) as e:
            raise ErrorNegocio(f"No se pudo abrir «{a['nombre']}»: {e}")
        with self.db.transaccion() as c:
            self.auditar(c, usuario["id"], "app_externa_abrir", a["nombre"])
        return {"tipo": "programa", "ok": True, "nombre": a["nombre"]}

    # ------------------------------------------------------------------ 4.1 · Acerca de / datos del fabricante
    FABRICANTE_DEFECTO = {"nombre": "PROYECTO ALLAS", "derechos": "Todos los derechos reservados."}
    ARCHIVO_FABRICANTE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fabricante.json")

    def _fabricante_valido(self, texto):
        from .licencia import ErrorLicencia, leer_fabricante
        from .licencia_clave import CLAVE_PUBLICA
        try:
            return leer_fabricante(texto, bytes.fromhex(CLAVE_PUBLICA))
        except (ErrorLicencia, ValueError):
            return None

    def datos_fabricante(self):
        """Los datos firmados más recientes: los que vienen con el programa (app/fabricante.json), los recibidos
        del servidor de licencias o los cargados a mano. Sin ninguno, unos datos genéricos."""
        candidatos = []
        try:
            with open(self.ARCHIVO_FABRICANTE, encoding="utf-8") as f:
                d = self._fabricante_valido(f.read())
            if d:
                candidatos.append((d.get("fecha") or "", 0, "programa", d))
        except OSError:
            pass
        guardado = self.cfg("fabricante")
        if guardado:
            d = self._fabricante_valido(guardado)
            if d:
                candidatos.append((d.get("fecha") or "", 1, self.cfg("fabricante_origen") or "servidor", d))
        if not candidatos:
            return {**self.FABRICANTE_DEFECTO, "copyright": f"© {self.ahora().year} PROYECTO ALLAS", "origen": "predeterminado"}
        _, _, origen, d = max(candidatos, key=lambda x: (x[0], x[1]))
        return {**self.FABRICANTE_DEFECTO, **d, "origen": origen}

    def guardar_fabricante(self, actor_id, texto, origen="manual"):
        d = self._fabricante_valido(texto or "")
        if not d:
            raise ErrorNegocio("El archivo no contiene datos del fabricante firmados por su distribuidor")
        previo = self._fabricante_valido(self.cfg("fabricante") or "")
        if origen == "servidor" and previo and (previo.get("fecha") or "") >= (d.get("fecha") or ""):
            return self.datos_fabricante()   # ya están
        with self.db.transaccion() as c:
            for k, v in (("fabricante", texto), ("fabricante_origen", origen)):
                c.execute("INSERT INTO config(clave, valor) VALUES(?,?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor", (k, v))
            if actor_id:
                self.auditar(c, actor_id, "fabricante_cargar", d.get("nombre") or "")
        return self.datos_fabricante()

    def acerca_de(self, usuario=None):
        from . import FECHA_VERSION, NOMBRE, __version__
        lic = self.estado_licencia()
        datos_lic = {k: lic.get(k) for k in ("estado", "mensaje", "numero", "titular", "tipo", "caduca", "actualizaciones_hasta",
                                              "puestos", "plan_nombre", "dias_restantes", "id_equipo")}
        from .licencia import NOMBRE_MODULO
        datos_lic["modulos"] = [NOMBRE_MODULO.get(m, m) for m in (lic.get("modulos") or [])]
        if lic.get("comprobacion"):
            datos_lic["ultima_comprobacion"] = lic["comprobacion"].get("ultima")
        return {"software": NOMBRE, "version": __version__, "fecha_version": FECHA_VERSION,
                "fabricante": {k: v for k, v in self.datos_fabricante().items() if k != "supervision"}, "licencia": datos_lic,
                "parking": self.cfg("nombre_parking") or ""}

    # ============================ exportar / importar tarifas y servicios
    FORMATO_CONFIG = "proyecto-allas/tarifas-servicios"

    def exportar_config(self):
        from . import __version__
        tarifas = []
        todas = self.tarifas()
        nombres = {t["id"]: t["nombre"] for t in todas}
        for t in todas:
            if not t["activa"]:
                continue  # las inactivas son versiones antiguas guardadas para tickets ya emitidos
            x = {k: t.get(k) for k in ("nombre", "gracia_min", "maximo_diario_cent", "por_defecto",
                                       "redondeo", "texto_ticket", "horario_dias", "horario_desde",
                                       "horario_hasta", "modo", "tipo_vehiculo", "evento_desde", "evento_hasta")} | {"tramos": t["tramos"]}
            if t.get("modo") == "reserva":
                x |= {k: t[k] for k in ("reserva_modo", "reserva_min", "reserva_noches", "reserva_hora")}
                x["tarifa_despues"] = nombres.get(t.get("tarifa_despues_id"))
            tarifas.append(x)
        productos = [{k: p[k] for k in ("nombre", "tipo", "precio_cent", "iva_pct", "activo", "orden",
                                        "minutos_incluidos", "descripcion")} for p in self.productos()]
        return {"formato": self.FORMATO_CONFIG, "version_formato": 1, "software": f"PROYECTO ALLAS {__version__}",
                "empresa": self.cfg("razon_social") or "", "fecha": iso(self.ahora()),
                "tarifas": tarifas, "productos": productos}

    @staticmethod
    def _tarifa_igual(actual, v):
        claves = ("gracia_min", "maximo_diario_cent", "redondeo", "texto_ticket", "horario_dias", "horario_desde", "horario_hasta",
                  "tipo_vehiculo", "evento_desde", "evento_hasta")
        if (actual.get("modo") or "tramos") != (v.get("modo") or "tramos"):
            return False
        if v.get("modo") == "reserva" and any(actual.get(k) != v.get(k) for k in ("reserva_modo", "reserva_min", "reserva_noches", "reserva_hora")):
            return False
        tramos = [{k: t[k] for k in ("desde_min", "hasta_min", "fraccion_min", "precio_mil")} for t in actual["tramos"]]
        return all(actual.get(k) == v.get(k) for k in claves) and tramos == v["tramos"] \
            and bool(actual["por_defecto"]) == bool(v["por_defecto"])

    def importar_config(self, datos, actor_id, modo="combinar", aplicar=False, que=("tarifas", "productos")):
        """Importa un fichero de exportar_config.
        modo 'combinar': actualiza las que tienen el mismo nombre y añade las nuevas.
        modo 'reemplazar': además desactiva las tarifas y elimina los servicios que no vengan en el fichero.
        Con aplicar=False solo devuelve lo que haría (vista previa)."""
        if not isinstance(datos, dict) or datos.get("formato") != self.FORMATO_CONFIG:
            raise ErrorNegocio("El fichero no es una exportación de tarifas y servicios de PROYECTO ALLAS")
        if modo not in ("combinar", "reemplazar"):
            raise ErrorNegocio("Modo de importación no válido")
        que = [q for q in que if q in ("tarifas", "productos", "servicios", "articulos")]
        # 4.4: «servicios» y «articulos» (productos de tienda) por separado; «productos» = los dos (ficheros antiguos)
        tipos = ({"servicio", "producto"} if "productos" in que else set()) | ({"servicio"} if "servicios" in que else set()) \
            | ({"producto"} if "articulos" in que else set())
        tarifas = [self._validar_tarifa(t | {"activa": True}) for t in (datos.get("tarifas") or [])] \
            if "tarifas" in que else []
        tarifas.sort(key=lambda t: t.get("modo") == "reserva")   # las de reserva, después de la tarifa a la que remiten
        productos = [x for x in (self._validar_producto(p) for p in (datos.get("productos") or [])) if x["tipo"] in tipos]
        for lista, que_es in ((tarifas, "tarifa"), (productos, "servicio")):
            nombres = [x["nombre"].lower() for x in lista]
            dup = {n for n in nombres if nombres.count(n) > 1}
            if dup:
                raise ErrorNegocio(f"El fichero repite el nombre de {que_es}: {', '.join(sorted(dup))}")
        if "tarifas" in que and modo == "reemplazar" and not tarifas:
            raise ErrorNegocio("El fichero no tiene tarifas: no se pueden reemplazar las actuales")
        if tarifas and sum(t["por_defecto"] for t in tarifas) > 1:
            raise ErrorNegocio("El fichero tiene más de una tarifa por defecto")
        if modo == "reemplazar" and tarifas and not any(t["por_defecto"] for t in tarifas):
            tarifas[0]["por_defecto"] = 1

        acciones = []
        with self.db.transaccion() as c:
            actuales_t = {t["nombre"].lower(): t for t in self.tarifas() if t["activa"]}
            for v in tarifas:
                act = actuales_t.get(v["nombre"].lower())
                if act and self._tarifa_igual(act, v):
                    acciones.append({"tipo": "tarifa", "nombre": v["nombre"], "accion": "igual"})
                    continue
                acciones.append({"tipo": "tarifa", "nombre": v["nombre"], "accion": "actualizar" if act else "nueva"})
                self._escribir_tarifa(c, v, act["id"] if act else None)
            if "tarifas" in que and modo == "reemplazar":
                en_fichero = {t["nombre"].lower() for t in tarifas}
                for n, t in actuales_t.items():
                    if n not in en_fichero:
                        acciones.append({"tipo": "tarifa", "nombre": t["nombre"], "accion": "desactivar"})
                        c.execute("UPDATE tarifas SET activa=0, por_defecto=0 WHERE id=?", (t["id"],))
            actuales_p = {p["nombre"].lower(): p for p in self.productos() if p["tipo"] in tipos or not tipos}
            for v in productos:
                act = actuales_p.get(v["nombre"].lower())
                if act and all(act[k] == v[k] for k in v):
                    acciones.append({"tipo": v["tipo"], "nombre": v["nombre"], "accion": "igual"})
                    continue
                acciones.append({"tipo": v["tipo"], "nombre": v["nombre"], "accion": "actualizar" if act else "nueva"})
                self._escribir_producto(c, v, act["id"] if act else None)
            if tipos and modo == "reemplazar":
                en_fichero = {p["nombre"].lower() for p in productos}
                for n, p in actuales_p.items():
                    if n not in en_fichero:
                        acciones.append({"tipo": p["tipo"], "nombre": p["nombre"], "accion": "eliminar"})
                        self._quitar_producto(c, p["id"])
            if not c.execute("SELECT 1 FROM tarifas WHERE por_defecto=1 AND activa=1").fetchone():
                raise ErrorNegocio("Tras importar no quedaría ninguna tarifa activa por defecto")
            cambios = [a for a in acciones if a["accion"] != "igual"]
            if aplicar:
                self.auditar(c, actor_id, "config_importar",
                             f"modo={modo} " + "; ".join(f"{a['tipo']} {a['nombre']}: {a['accion']}" for a in cambios))
            else:
                c.execute("ROLLBACK")      # vista previa: se deshace todo
                c.execute("BEGIN IMMEDIATE")  # el gestor de la transacción hará COMMIT de una vacía
        return {"aplicado": bool(aplicar), "modo": modo, "acciones": acciones, "cambios": len(cambios),
                "origen": {k: datos.get(k) for k in ("software", "empresa", "fecha")}}

    @staticmethod
    def _precio_de_producto(prod, precio_cent):
        """4.62: precio de una línea. Con precio fijo manda el del catálogo; si el servicio no lo tiene, hay que indicarlo al venderlo."""
        if not prod["precio_variable"]:
            return prod["precio_cent"]
        try:
            precio = int(precio_cent)
        except (TypeError, ValueError):
            precio = 0
        if not 0 < precio <= 10_000_000:
            raise ErrorNegocio(f"«{prod['nombre']}» no tiene precio fijo: indique el precio al seleccionarlo")
        return precio

    def tarea_periodica(self):
        """Cada pocos minutos (hilo de run.py): sincroniza Stripe y, una vez al día, envía avisos de caducidad."""
        abonados = self.tiene_modulo("abonados")
        hecho = {"renovados": len(self.renovar_bonos_automaticos())} if abonados else {}
        lic = self.comprobacion_automatica()   # 3.8
        if lic:
            hecho["licencia"] = lic
        if abonados and self.activo("pagos_online_activo", "pagos_online"):
            try:
                hecho["stripe"] = self.sincronizar_pagos_online()
            except ErrorNegocio as e:
                hecho["stripe_error"] = str(e)
        if self.cfg("pago_movil_activo") == "1" and self.cfg("stripe_clave"):   # 4.3
            try:
                hecho["pagos_movil"] = self.sincronizar_pagos_movil()
            except Exception as e:  # noqa: BLE001
                hecho["pagos_movil_error"] = str(e)
        if self.reservas_online_activas():   # 1.18: no presentados, recordatorios de reservas y pagos de señal
            for nombre, f in (("reservas_liberadas", self.liberar_no_presentadas), ("reservas_recordatorios", self.enviar_recordatorios_reservas),
                              ("reservas_senales", self.sincronizar_senales_stripe)):
                try:
                    hecho[nombre] = f()
                except Exception as e:  # noqa: BLE001
                    hecho[nombre + "_error"] = str(e)
        hoy = self.ahora().date().isoformat()
        if self.activo("m360_activo", "madrid360") and self.cfg("m360_modo") == "automatico" and \
                self.ahora().strftime("%H:%M") >= (self.cfg("m360_hora_envio") or "23:30"):
            env = self.db.q1("SELECT estado FROM m360_envios WHERE dia=?", (hoy,))
            if not env or env["estado"] != "enviado":
                hecho["m360"] = self.m360_enviar_automatico(hoy)
        if abonados and self.cfg("avisos_activos") == "1" and self.smtp_listo() and self.cfg("avisos_ultimo_dia") != hoy \
                and self.ahora().hour >= 9:
            try:
                hecho["avisos"] = self.enviar_avisos()
                self.db.set_cfg("avisos_ultimo_dia", hoy)
            except ErrorNegocio as e:
                hecho["avisos_error"] = str(e)
        return hecho
