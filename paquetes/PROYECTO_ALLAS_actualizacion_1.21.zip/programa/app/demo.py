"""Cuenta de DEMOSTRACIÓN: crea una base de datos de ejemplo, aparte de la real.

La demo vive en <datos>/demo/ (su propia base, copias y logo). Mientras está activa existe el archivo
<datos>/modo_demo y run.py arranca con esa carpeta; los datos reales no se tocan. Todo lo que se
imprime lleva «DEMOSTRACIÓN - SIN VALIDEZ».

Usuarios de la demo:  admin / 1234 (administrador) · supervisor / 2222 · caja / 1111 (cajero)
"""
import os
import random
import shutil
import tempfile
from datetime import date, datetime, timedelta

from .db import Database

USUARIOS_DEMO = [("Ana García", "admin", "1234", "admin"), ("Sergio Martín", "supervisor", "2222", "supervisor"),
                 ("Carlos López", "caja", "1111", "cajero")]
FOTOS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "demo_fotos")
ARCHIVO_MODO = "modo_demo"

NOMBRES = ["Lucía Fernández Ruiz", "Javier Moreno Gil", "Marta Sánchez Vidal", "Pablo Romero Díaz", "Elena Navarro Cano",
           "Daniel Torres Prieto", "Carmen Ortega León", "Álvaro Castro Molina", "Isabel Rubio Herrera",
           "Miguel Ángel Serrano", "Laura Domínguez Pastor", "Raúl Iglesias Marín"]
EMPRESAS = [("Talleres Hermanos Ruiz S.L.", "B87654321", "Calle del Taller 12, Madrid"),
            ("Clínica Dental Sonrisa S.L.", "B11223344", "Avenida Central 45, Madrid"),
            ("Asesoría Gómez y Asociados", "B55667788", "Plaza Mayor 3, Madrid")]
COCHES = [("Seat", "Ibiza"), ("Renault", "Clio"), ("Toyota", "Corolla"), ("Volkswagen", "Golf"), ("Peugeot", "208"),
          ("Kia", "Sportage"), ("Dacia", "Sandero"), ("Ford", "Focus"), ("Hyundai", "Tucson"), ("BMW", "Serie 1"),
          ("Citroën", "C3"), ("Mercedes", "Clase A"), ("Opel", "Corsa"), ("Nissan", "Qashqai"), ("Tesla", "Model 3")]
LETRAS = "BCDFGHJKLMNPRSTVWXYZ"


class Reloj:
    def __init__(self, t):
        self.t = t

    def __call__(self):
        return self.t


def _matricula(rnd):
    return f"{rnd.randint(0, 9999):04d}{''.join(rnd.choice(LETRAS) for _ in range(3))}"


def _mat_unica(rnd, usadas):
    while True:
        m = _matricula(rnd)
        if m not in usadas:
            usadas.add(m)
            return m


def _foto(nombre):
    try:
        with open(os.path.join(FOTOS, nombre), "rb") as f:
            return f.read()
    except OSError:
        return None


APELLIDOS = ["García", "Fernández", "González", "Rodríguez", "López", "Martínez", "Sánchez", "Pérez", "Gómez", "Jiménez",
             "Ruiz", "Hernández", "Díaz", "Moreno", "Álvarez", "Romero", "Alonso", "Gutiérrez", "Navarro", "Torres"]
PILA = ["Antonio", "María", "José", "Manuel", "Francisco", "Javier", "Carlos", "Pedro", "Luis", "Laura", "Carmen", "Ana",
        "Lucía", "Marta", "Elena", "Isabel", "Paula", "Sara", "Rosa", "Pilar", "Raúl", "Sergio", "Pablo", "Diego", "Irene"]
LIMITES_DEMO = {"clientes": (1, 500), "bonos": (0, 500), "dentro": (0, 120), "dias": (5, 90)}


def limpiar_opciones(o):
    """Normaliza las cantidades pedidas para la demo (None = las de siempre)."""
    o = o or {}
    r = {}
    for k, (mn, mx) in LIMITES_DEMO.items():
        v = o.get(k)
        if v in (None, ""):
            continue
        try:
            r[k] = max(mn, min(mx, int(v)))
        except (TypeError, ValueError):
            raise ValueError(f"Cantidad no válida: {k}")
    return r


def crear_base_demo(ruta_db, dias=28, semilla=2026, ahora=None, clientes=None, bonos=None, dentro=None):
    """Crea (o recrea) la base de demostración en 'ruta_db'. Devuelve un resumen.
    clientes / bonos / dentro: cantidad de clientes, de bonos vendidos y de vehículos que quedan dentro (None = los de siempre)."""
    from .servicios import Parking
    rnd = random.Random(semilla)
    ahora = (ahora or datetime.now().astimezone()).replace(second=0, microsecond=0)
    carpeta = os.path.dirname(os.path.abspath(ruta_db))
    os.makedirs(carpeta, exist_ok=True)
    tmp = tempfile.NamedTemporaryFile(prefix="demo-", suffix=".db", dir=carpeta, delete=False)
    tmp.close()
    os.remove(tmp.name)
    db = Database(tmp.name)
    reloj = Reloj(ahora - timedelta(days=dias + 1))
    p = Parking(db, reloj)
    p.demo = True
    nada = {"ok": True, "vista_previa": "", "elementos": [], "ancho": 42, "copias": 1}
    p._imprimir = lambda *a, **k: dict(nada)   # al generar no se imprime nada
    p._enviar = lambda *a, **k: dict(nada)
    try:
        # ---- empresa y ajustes
        for k, v in {"nombre_parking": "PARKING DEMO CENTRO", "razon_social": "Demostración Parking S.L.",
                     "nif": "B00000000", "direccion": "Calle de Ejemplo 1, 28001 Madrid", "telefono": "910 000 000",
                     "capacidad": "120", "serie_factura": "D", "fecha_instalacion": ahora.date().isoformat(),
                     "registro_integridad": "1", "descuentos_activo": "1", "pantalla_cliente_activa": "1",
                     "pantalla_cliente_modo": "monitor", "pantalla_cliente_bienvenida": "Bienvenido a Parking Demo Centro",
                     "impresora_modo": "archivo", "impresora_destino": os.path.join(carpeta, "salida_impresora"),
                     "efectivo_exigir_entregado": "1", "entrada_ajuste_max_min": "60",
                     "ticket_cabecera_extra": "Abierto 24 horas"}.items():
            db.set_cfg(k, v)
        ids = {}
        for nombre, usuario, pin, rol in USUARIOS_DEMO:
            ids[usuario] = p.crear_usuario(nombre, usuario, pin, rol)
        admin = p.autenticar("admin", "1234")
        caja = p.autenticar("caja", "1111")
        a = admin["id"]

        # ---- tarifas
        tg = p.guardar_tarifa({"nombre": "General", "por_defecto": True, "gracia_min": 5, "maximo_diario_cent": 2000,
                               "tramos": [{"desde_min": 0, "hasta_min": None, "fraccion_min": 1, "precio_mil": 45}]}, a)
        p.guardar_tarifa({"nombre": "Larga estancia", "gracia_min": 5, "maximo_diario_cent": 1200,
                          "tramos": [{"desde_min": 0, "hasta_min": None, "fraccion_min": 1, "precio_mil": 30}]}, a)
        tm = p.guardar_tarifa({"nombre": "Motos", "gracia_min": 10, "maximo_diario_cent": 800,
                               "tramos": [{"desde_min": 0, "hasta_min": None, "fraccion_min": 1, "precio_mil": 20}]}, a)

        # ---- productos y servicios con foto
        existentes = {x["nombre"]: x["id"] for x in p.productos()}
        nuevos = [("Café para llevar", "producto", 150, 10, 0, "Café recién hecho de la máquina de la entrada"),
                  ("Recarga eléctrica 1 h", "servicio", 600, None, 60, "Punto de recarga de la planta -1; incluye 1 h de parking"),
                  ("Ambientador", "producto", 300, None, 0, None)]
        for nombre, tipo, precio, iva, mins, desc in nuevos:
            existentes[nombre] = p.guardar_producto({"nombre": nombre, "tipo": tipo, "precio_cent": precio,
                                                     "iva_pct": iva if iva is not None else "", "minutos_incluidos": mins,
                                                     "descripcion": desc}, a)
        fotos = {"Lavado exterior": "lavado_exterior.jpg", "Lavado completo (interior y exterior)": "lavado_completo.jpg",
                 "Botella de agua 50 cl": "agua.jpg", "Café para llevar": "cafe.jpg", "Recarga eléctrica 1 h": "recarga.jpg",
                 "Ambientador": "ambientador.jpg"}
        for nombre, archivo in fotos.items():
            datos = _foto(archivo)
            if datos and nombre in existentes:
                p.guardar_foto_producto(existentes[nombre], datos, a)
        prods = p.productos()

        # ---- publicidad para la pantalla de cliente
        for archivo, titulo, texto in (("anuncio_lavado.jpg", "Lavado a mano mientras aparca", "Desde 12 € · pregunte en caja"),
                                       ("anuncio_abono.jpg", "Abono mensual 24 h", "Aparque cuando quiera por 85 € al mes")):
            datos = _foto(archivo)
            if datos:
                p.guardar_anuncio(a, {"titulo": titulo, "texto": texto}, datos)

        # ---- descuentos y bonos
        d_cine = p.guardar_descuento({"nombre": "Cliente del cine", "tipo": "porcentaje", "valor": 10, "codigo": "CINE"}, a)
        d_vale = p.guardar_descuento({"nombre": "Vale de 2 €", "tipo": "importe", "valor": 200, "ambito": "todo"}, a)
        p.guardar_descuento({"nombre": "1 hora gratis con compra", "tipo": "minutos", "valor": 60}, a)
        planes = [p.guardar_plan({"nombre": "Mensual 24 h", "precio_cent": 8500, "meses": 1}, a),
                  p.guardar_plan({"nombre": "Mensual diurno", "precio_cent": 6000, "meses": 1,
                                  "descripcion": "De lunes a viernes, de 8 a 20 h"}, a),
                  p.guardar_plan({"nombre": "Trimestral 24 h", "precio_cent": 23000, "meses": 3}, a)]

        # ---- clientes
        abonados = []
        n_total = 15 if clientes is None else clientes
        n_abon = max(1, n_total - 3) if n_total >= 6 else n_total
        empresas = EMPRESAS[:n_total - n_abon] if n_total - n_abon <= 3 else [
            (f"Empresa {j + 1} S.L.", f"B{rnd.randint(10000000, 99999999)}", "Calle del Comercio 1, Madrid") for j in range(n_total - n_abon)]
        nombres = [NOMBRES[i] if i < len(NOMBRES) else f"{rnd.choice(PILA)} {rnd.choice(APELLIDOS)} {rnd.choice(APELLIDOS)}"
                   for i in range(n_abon)]
        matriculas_demo = set()
        for i, nombre in enumerate(nombres):
            marca, modelo = COCHES[i % len(COCHES)]
            tel = f"6{rnd.randint(10000000, 99999999)}"
            email = nombre.split()[0].lower().translate(str.maketrans("áéíóúñ", "aeioun")) + f".demo{i}@ejemplo.com"
            cid = p.guardar_cliente({"nombre": nombre, "tipo": "abonado", "telefono": tel, "email": email,
                                     "renovacion_auto": i not in (3,) and bonos is None, "enviar_facturas": False,
                                     "vehiculos": [{"matricula": _mat_unica(rnd, matriculas_demo), "marca": marca, "modelo": modelo}]}, a)
            abonados.append(cid)
        for nombre, nif, dirc in empresas:
            p.guardar_cliente({"nombre": nombre, "tipo": "facturacion", "nif": nif, "direccion": dirc,
                               "email": "administracion@ejemplo.com", "enviar_facturas": False}, a)

        # ---- historial día a día: turnos, entradas, cobros, tienda y bonos
        def momento(d, h, m=0):
            return datetime(d.year, d.month, d.day, h, m, tzinfo=ahora.tzinfo)

        inicio = (ahora - timedelta(days=dias)).date()
        dentro_l = []        # tickets que se quedan dentro
        resumen = {"tickets": 0, "cobros": 0, "ventas": 0, "bonos": 0}
        venta_bonos = {}     # día -> [(cliente, plan, importe_parcial)]
        con_bono = set(rnd.sample(range(len(abonados)), min(bonos, len(abonados)))) if bonos is not None else None
        for i, cid in enumerate(abonados):
            if con_bono is not None and i not in con_bono:
                continue
            if i == 3:       # bono caducado y sin renovación automática
                dia = inicio + timedelta(days=1)
            elif i == 7:     # renovación pendiente de pago (se crea sola al caducar)
                dia = inicio + timedelta(days=2)
            else:
                dia = inicio + timedelta(days=rnd.randint(3, max(3, dias)))
            if dia >= ahora.date():   # el día de hoy puede estar a medias (de madrugada no daría tiempo a vender): se pasa a ayer
                dia = ahora.date() - timedelta(days=1)
            venta_bonos.setdefault(dia, []).append((cid, planes[1] if i % 4 == 1 else planes[2] if i == 5 else planes[0],
                                                    3000 if i == 9 else None))

        # el último día con turno: parte de sus vehículos se quedan dentro (para probar la Salida)
        ultimo = ahora.date() if ahora >= momento(ahora.date(), 9, 0) else ahora.date() - timedelta(days=1)
        dia = inicio
        while dia <= ahora.date():
            apertura = momento(dia, 7, 30)
            cierre = min(momento(dia, 22, 45), ahora - timedelta(minutes=5))
            if apertura >= cierre:
                break
            reloj.t = apertura
            p.abrir_turno(caja, 15000)
            eventos = []
            n = rnd.randint(28, 46) + (8 if dia.weekday() == 4 else 0) - (10 if dia.weekday() == 6 else 0)
            for _ in range(n):
                ent = apertura + timedelta(minutes=rnd.randint(5, 13 * 60))
                if ent >= cierre:
                    continue
                dur = int(min(rnd.lognormvariate(4.4, 0.75), 600))
                sal = ent + timedelta(minutes=max(8, dur))
                eventos.append((ent, "entrada", sal))
            for _ in range(rnd.randint(2, 6)):
                eventos.append((apertura + timedelta(minutes=rnd.randint(10, 14 * 60)), "tienda", None))
            for cid, plan, parcial in venta_bonos.get(dia, []):
                eventos.append((min(apertura + timedelta(minutes=rnd.randint(30, 600)), cierre - timedelta(minutes=1)), "bono", (cid, plan, parcial)))
            eventos = [e for e in eventos if e[0] < cierre]
            eventos.sort(key=lambda e: e[0])
            pendientes = []
            for t, tipo, extra in eventos:
                # primero, las salidas que tocan antes de este momento
                for sal, tk in sorted([x for x in pendientes if x[0] <= t], key=lambda x: x[0]):
                    reloj.t = sal
                    _cobrar(p, caja, tk, rnd, prods, d_cine, resumen)
                    pendientes.remove((sal, tk))
                reloj.t = t
                if tipo == "entrada":
                    tarifa = tm if rnd.random() < 0.06 else None
                    tk = p.emitir_ticket(caja, _matricula(rnd), tarifa_id=tarifa, forzar_ticket=True)
                    resumen["tickets"] += 1
                    if dia == ultimo and (dentro is None or len(dentro_l) < dentro) and (extra >= cierre or rnd.random() < 0.45):
                        dentro_l.append(tk)
                    elif extra < cierre:
                        pendientes.append((extra, tk))
                    else:
                        pendientes.append((cierre - timedelta(minutes=rnd.randint(1, 10)), tk))
                elif tipo == "tienda":
                    lineas = [{"producto_id": x["id"], "cantidad": rnd.choice((1, 1, 1, 2))}
                              for x in rnd.sample([x for x in prods if x["tipo"] == "producto"], rnd.choice((1, 1, 2)))]
                    total = sum(next(x for x in prods if x["id"] == l["producto_id"])["precio_cent"] * l["cantidad"] for l in lineas)
                    metodo = rnd.choice(("efectivo", "tarjeta"))
                    p.vender_tienda(caja, lineas, metodo, _billete(total) if metodo == "efectivo" else None)
                    resumen["ventas"] += 1
                elif tipo == "bono":
                    cid, plan, parcial = extra
                    precio = next(x for x in p.planes() if x["id"] == plan)["precio_cent"] if hasattr(p, "planes") else None
                    imp = parcial or precio
                    metodo = rnd.choice(("tarjeta", "efectivo"))
                    # los abonados 3 y 7 compraron un bono que empezó antes: ya ha vencido (uno sin renovar, otro pendiente de pago)
                    desde = dia - timedelta(days=14) if cid in abonados[3:4] + abonados[7:8] else dia
                    p.vender_bono(caja, cid, plan, desde=desde.isoformat(), metodo=metodo,
                                  entregado_cent=_billete(imp) if metodo == "efectivo" and imp else None,
                                  importe_cent=parcial)
                    resumen["bonos"] += 1
            for sal, tk in sorted(pendientes, key=lambda x: x[0]):
                reloj.t = max(sal, reloj.t)
                _cobrar(p, caja, tk, rnd, prods, d_cine, resumen)
            reloj.t = cierre
            t = p.turno_abierto(caja)
            p.cerrar_turno(caja, t["efectivo_esperado_actual_cent"] + rnd.choice((0, 0, 0, -50, 100)))
            dia += timedelta(days=1)

        # ---- si se pidió una cantidad concreta de vehículos dentro, se completan (algunos son abonados con bono vigente)
        if dentro is not None and len(dentro_l) < dentro:
            reloj.t = ahora - timedelta(minutes=3)
            p.abrir_turno(caja, 15000, arqueo=False)
            hoy = ahora.date().isoformat()
            ya = {r["matricula"] for r in db.q("SELECT matricula FROM tickets WHERE estado='dentro'")}
            vig = [r["matricula"] for r in db.q(
                "SELECT cm.matricula FROM cliente_matriculas cm JOIN bonos b ON b.cliente_id=cm.cliente_id "
                "WHERE b.estado='activo' AND b.desde<=? AND b.hasta>=?", (hoy, hoy)) if r["matricula"] not in ya]
            rnd.shuffle(vig)
            falta = dentro - len(dentro_l)
            for m in vig[:int(falta * 0.4)] + [None] * falta:
                if len(dentro_l) >= dentro:
                    break
                if m is None:
                    m = _mat_unica(rnd, matriculas_demo)
                try:
                    tk = p.emitir_ticket(caja, m) if m in vig else p.emitir_ticket(caja, m, forzar_ticket=True)
                except Exception:
                    continue
                db.ex("UPDATE tickets SET entrada=? WHERE id=?",
                      ((ahora - timedelta(minutes=rnd.randint(10, 3 * 24 * 60))).isoformat(), tk["id"]))
                dentro_l.append(tk)
            t = p.turno_abierto(caja)
            p.cerrar_turno(caja, t["efectivo_esperado_actual_cent"])

        # ---- vales de ejemplo y abonados con bono vencido o pendiente
        reloj.t = ahora - timedelta(minutes=2)
        p.generar_vales(admin, d_vale, cantidad=5, usos_max=1, caduca=(ahora.date() + timedelta(days=60)).isoformat(),
                        nota="Promoción de apertura", imprimir=False)
        p.generar_vales(admin, d_cine, cantidad=2, usos_max=0, nota="Cine Avenida (uso ilimitado)", imprimir=False)
        p.renovar_bonos_automaticos()
        # ---- 3.5: recordatorios de ejemplo (🔔)
        p.guardar_recordatorio(admin, {"titulo": "Revisar la barrera de salida",
                                       "texto": "Hace ruido al subir. Si sigue, llamar al técnico (912 345 678).", "para": "todos"})
        p.guardar_recordatorio(admin, {"titulo": "Cambiar el rollo de la impresora de tickets", "para": "rol:cajero"})
        p.guardar_recordatorio(admin, {"titulo": "Arqueo del fin de semana", "texto": "Contar el cambio de la caja fuerte.",
                                       "para": "todos", "fecha": (ahora + timedelta(days=2)).replace(hour=9, minute=0).isoformat()})
        db.set_cfg("fecha_instalacion", ahora.date().isoformat())
        resumen["dentro"] = len(dentro_l)
        resumen["clientes"] = len(abonados) + len(empresas)
    finally:
        db.conn.close()
    # sustituir la demo anterior (si la había) por la nueva
    for sufijo in ("", "-wal", "-shm"):
        try:
            os.remove(ruta_db + sufijo)
        except OSError:
            pass
    os.replace(tmp.name, ruta_db)
    for sufijo in ("-wal", "-shm"):
        try:
            os.remove(tmp.name + sufijo)
        except OSError:
            pass
    return resumen


def _billete(importe):
    for b in (500, 1000, 2000, 5000):
        if b >= importe:
            return b
    return importe


def _cobrar(p, usuario, tk, rnd, prods, d_cine, resumen):
    from .servicios import ErrorNegocio
    try:
        if rnd.random() < 0.08:
            serv = [x for x in prods if x["tipo"] == "servicio"]
            if serv:
                p.anadir_extra(usuario, tk["id"], rnd.choice(serv)["id"], 1)
        c = p.consultar(tk["codigo"])
        liq = c.get("liquidacion") or {}
        if not liq.get("pendiente_cent"):
            p.registrar_salida(usuario, tk["id"]) if hasattr(p, "registrar_salida") else None
            return
        dto = d_cine if rnd.random() < 0.05 and liq.get("pendiente_estancia_cent") else None
        neto = liq["pendiente_cent"] - (next((o["descuento_cent"] for o in liq.get("descuentos", []) if o["id"] == dto), 0) if dto else 0)
        metodo = "efectivo" if rnd.random() < 0.55 else "tarjeta"
        p.cobrar(usuario, tk["id"], metodo, _billete(neto) if metodo == "efectivo" and neto > 0 else None,
                 calculo_en=c["calculo_en"], descuento_id=dto)
        resumen["cobros"] += 1
    except ErrorNegocio:
        pass


# ------------------------------------------------------------------ activar / salir
def activa(carpeta_base):
    return os.path.isfile(os.path.join(carpeta_base, ARCHIVO_MODO))


def carpeta_demo(carpeta_base):
    return os.path.join(carpeta_base, "demo")


def preparar(carpeta_base, regenerar=False, opciones=None):
    """Crea la demo si no existe (o si se pide regenerarla) y la marca como activa para el próximo arranque.
    La base nueva se deja como parking.nuevo.db: run.py la pone en su sitio al arrancar (la actual puede estar abierta)."""
    carpeta = carpeta_demo(carpeta_base)
    resumen = None
    if regenerar or not os.path.isfile(os.path.join(carpeta, "parking.db")):
        resumen = crear_base_demo(os.path.join(carpeta, "parking.nuevo.db"), **limpiar_opciones(opciones))
    with open(os.path.join(carpeta_base, ARCHIVO_MODO), "w", encoding="utf-8") as f:
        f.write(date.today().isoformat())
    return resumen


def instalar_nueva(carpeta):
    """Al arrancar en modo demo: si hay una demo recién generada, sustituye a la anterior."""
    nueva = os.path.join(carpeta, "parking.nuevo.db")
    if not os.path.isfile(nueva):
        return False
    ruta = os.path.join(carpeta, "parking.db")
    for sufijo in ("-wal", "-shm", ""):
        try:
            os.remove(ruta + sufijo)
        except OSError:
            pass
    os.replace(nueva, ruta)
    shutil.rmtree(os.path.join(carpeta, "logo"), ignore_errors=True)
    return True


def salir(carpeta_base):
    try:
        os.remove(os.path.join(carpeta_base, ARCHIVO_MODO))
    except OSError:
        pass
