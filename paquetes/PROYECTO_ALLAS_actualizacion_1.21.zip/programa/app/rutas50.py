"""PROYECTO ALLAS 4.53 · rutas de eliminar usuarios y del control de turnos por QR (se registran desde server.App._registrar)."""


def registrar(app, r, p):
    from .server import Respuesta

    @r("DELETE", r"/api/usuarios/(\d+)", rol=("admin",))
    def usuario_eliminar(req, uid):
        res = p.eliminar_usuario(int(uid), req.usuario["id"])
        with app._lock:   # cierra sus sesiones abiertas
            for tok in [t for t, s in app.sesiones.items() if s["usuario"]["id"] == int(uid)]:
                app.sesiones.pop(tok, None)
        return res

    # ------------------------------------------------------------------ QR personal
    @r("GET", r"/api/usuarios/(\d+)/qr", rol=("admin",))
    def usuario_qr(req, uid):
        return p.qr_datos(int(uid))

    @r("POST", r"/api/usuarios/(\d+)/qr/regenerar", rol=("admin",))
    def usuario_qr_regenerar(req, uid):
        return p.qr_datos(int(uid), regenerar=True)

    @r("POST", r"/api/usuarios/(\d+)/qr/imprimir", rol=("admin",))
    def usuario_qr_imprimir(req, uid):
        return p.imprimir_qr_usuario(req.usuario, int(uid), (req.body or {}).get("lineas_corte"))

    @r("GET", r"/api/usuarios/(\d+)/qr.pdf", rol=("admin",))
    def usuario_qr_pdf(req, uid):
        return Respuesta(p.pdf_qr_usuario(int(uid)), "application/pdf", {"Content-Disposition": f'attachment; filename="qr_fichaje_{int(uid)}.pdf"'})

    @r("POST", r"/api/usuarios/(\d+)/qr/email", rol=("admin",))
    def usuario_qr_email(req, uid):
        return p.enviar_qr_usuario(req.usuario, int(uid), (req.body or {}).get("destino"))

    # ------------------------------------------------------------------ fichar con el lector del equipo (4.51: ya no hay página pública)
    @r("POST", "/api/fichar")
    def fichar(req):
        return p.fichar((req.body or {}).get("codigo") or "", f"lector · {req.usuario['usuario']}")

    @r("POST", "/api/fichar/previa")
    def fichar_previa(req):
        return p.fichaje_previa((req.body or {}).get("codigo") or "", f"lector · {req.usuario['usuario']}")

    @r("GET", "/api/fichaje/panel")
    def fichaje_panel(req):
        return p.fichaje_panel(req.usuario)

    # ------------------------------------------------------------------ listado
    @r("GET", "/api/fichajes", rol=("admin", "supervisor"))
    def fichajes(req):
        q = req.query
        return p.fichajes(q.get("desde"), q.get("hasta"), q.get("usuario_id"))

    @r("GET", "/api/fichajes.csv", rol=("admin", "supervisor"))
    def fichajes_csv(req):
        q = req.query
        nombre = f"fichajes_{p.ahora():%Y%m%d}.csv"
        return Respuesta(p.fichajes_csv(q.get("desde"), q.get("hasta"), q.get("usuario_id")).encode("utf-8"), "text/csv; charset=utf-8",
                         {"Content-Disposition": f'attachment; filename="{nombre}"'})

    @r("POST", r"/api/fichajes/(\d+)/cerrar", rol=("admin", "supervisor"))
    def fichaje_cerrar(req, fid):
        return p.cerrar_fichaje(int(fid), req.usuario["id"])

    # ------------------------------------------------------------------ 4.50: comentarios internos e historial del vehículo
    @r("GET", "/api/vehiculo/nota")
    def vehiculo_nota(req):
        return {"nota": p.nota_vehiculo(req.query.get("matricula"))}

    @r("PUT", "/api/vehiculo/nota")
    def vehiculo_nota_guardar(req):
        return p.guardar_nota_vehiculo(req.usuario, (req.body or {}).get("matricula"), (req.body or {}).get("nota"))

    @r("GET", "/api/vehiculo/historial")
    def vehiculo_historial(req):
        return p.historial_vehiculo(req.query.get("matricula"))
