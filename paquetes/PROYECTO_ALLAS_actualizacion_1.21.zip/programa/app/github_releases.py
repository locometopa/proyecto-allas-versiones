"""Actualizaciones desde las «releases» de un repositorio público de GitHub (1.21).

El distribuidor publica cada versión como una release (etiqueta vX.Y) con el paquete firmado
PROYECTO_ALLAS_actualizacion_X.Y.zip como archivo adjunto y las novedades en el texto de la release.
El programa consulta la API pública (sin cuenta ni token) y solo guarda un paquete si la firma del fabricante es
correcta, igual que con los demás orígenes. Sin dependencias: urllib. ALLAS_GITHUB_API cambia la dirección (pruebas)."""
import json
import os
import re
import urllib.error
import urllib.request

API = "https://api.github.com"
REPO_DEFECTO = "locometopa/proyecto-allas-versiones"
_REPO = re.compile(r"^[A-Za-z0-9_.\-]{1,100}/[A-Za-z0-9_.\-]{1,100}$")
_NOMBRE = re.compile(r"actualizaci[oó]n[_\- ]v?(\d+(?:\.\d+)+)\.zip$", re.I)


class ErrorGitHub(Exception):
    pass


def base():
    return (os.environ.get("ALLAS_GITHUB_API") or API).rstrip("/")


def repo_valido(texto):
    """Acepta «usuario/repositorio» o el enlace https://github.com/usuario/repositorio."""
    t = (texto or "").strip() or REPO_DEFECTO
    t = re.sub(r"^https?://github\.com/", "", t).strip("/")
    t = re.sub(r"\.git$", "", t)
    if not _REPO.match(t):
        raise ErrorGitHub("El repositorio de actualizaciones no es válido (use usuario/repositorio).")
    return t


def _pedir(url, timeout, aceptar="application/vnd.github+json"):
    req = urllib.request.Request(url, headers={"User-Agent": "PROYECTO-ALLAS", "Accept": aceptar,
                                               "X-GitHub-Api-Version": "2022-11-28"})
    try:
        return urllib.request.urlopen(req, timeout=timeout)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise ErrorGitHub("No se encuentra el repositorio de actualizaciones (404). Avise a su distribuidor.")
        if e.code in (403, 429):
            raise ErrorGitHub("GitHub limita las consultas desde esta conexión. Inténtelo de nuevo dentro de un rato.")
        raise ErrorGitHub(f"GitHub responde con error {e.code}.")
    except (urllib.error.URLError, OSError) as e:
        raise ErrorGitHub(f"No se puede conectar con GitHub: {getattr(e, 'reason', e)}")


def listar(repo):
    """Releases publicadas: [{version, fecha, notas, archivo, tamano, id, sha256}] (una por versión)."""
    repo = repo_valido(repo)
    with _pedir(f"{base()}/repos/{repo}/releases?per_page=100", 20) as r:
        try:
            datos = json.loads(r.read(5_000_000) or b"[]")
        except ValueError:
            raise ErrorGitHub("Respuesta no válida de GitHub")
    vistos = {}
    for rel in datos if isinstance(datos, list) else []:
        if rel.get("draft") or rel.get("prerelease"):
            continue
        for a in rel.get("assets") or []:
            m = _NOMBRE.search(a.get("name") or "")
            if not m or a.get("id") is None:
                continue
            dg = str(a.get("digest") or "")
            vistos.setdefault(m.group(1), {
                "version": m.group(1), "fecha": (rel.get("published_at") or rel.get("created_at") or "")[:10],
                "notas": (rel.get("body") or "")[:4000], "archivo": a["name"], "tamano": a.get("size"),
                "id": str(a["id"]), "sha256": dg[7:].lower() if dg.startswith("sha256:") else None})
    return list(vistos.values())


def descargar(repo, asset_id, maximo):
    repo = repo_valido(repo)
    if not re.match(r"^\d{1,15}$", str(asset_id or "")):
        raise ErrorGitHub("Paquete no válido")
    with _pedir(f"{base()}/repos/{repo}/releases/assets/{asset_id}", 180, "application/octet-stream") as r:
        datos = r.read(maximo + 1)
    if datos[:2] != b"PK":
        raise ErrorGitHub("GitHub no entregó el paquete. Inténtelo más tarde o avise a su distribuidor.")
    if len(datos) > maximo:
        raise ErrorGitHub("El paquete es demasiado grande")
    return datos
