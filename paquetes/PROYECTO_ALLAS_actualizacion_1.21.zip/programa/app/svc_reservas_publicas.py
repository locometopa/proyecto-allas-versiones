"""PROYECTO ALLAS 1.10 · API pública de reservas (la usa la web del aparcamiento; desde 1.14 el programa ya no sirve la página).

La lógica de las reservas sigue en svc_reservas.py; aquí solo está lo que cambia al abrirla al público: validación estricta de los
datos, límite de peticiones, campo trampa contra robots, búsqueda de la reserva con código + matrícula y email de confirmación.
Las rutas son públicas (sin sesión) y solo existen si se activan en Ajustes → Conexiones → Reservas online.
"""
import re
import threading
import time
from datetime import timedelta

from .utiles import ErrorNegocio, email_valido, norm_matricula, parse

CONDICIONES_DEFECTO = ("Reserva de una plaza en la zona elegida entre la fecha y hora de entrada y de salida indicadas. "
                       "{pago}Puede cancelarla gratis hasta {horas} horas antes de la entrada; "
                       "después, avise al parking. Sus datos (nombre, email, teléfono y matrícula) solo se usan para gestionar esta reserva.")
TEXTO_PAGO = {"parking": "El pago se hace en el parking, con la tarifa vigente. ",
              "senal": "Para mantener la reserva hay que pagar la señal indicada dentro del plazo; si no se paga, la reserva se cancela sola. "
                       "La señal se descuenta del importe final y el resto se paga en el parking. ",
              "total": "Para mantener la reserva hay que pagar su importe por adelantado dentro del plazo; si no se paga, la reserva se cancela sola. "}
MAX_PENDIENTES_EMAIL = 3
IP_PRUEBA = "prueba-local"   # la pone el servidor a las peticiones de la web local de pruebas (ver server._ip_cliente)
HOST_VALIDO = re.compile(r"^[A-Za-z0-9.\-\[\]:]{1,100}$")


CAMPOS_PUBLICOS = ("matricula", "desde", "hasta", "zona_id", "tipo_vehiculo", "nombre", "email", "telefono", "web", "codigo")


def limpiar_publico(datos):
    """Solo los campos conocidos y solo texto o números: lo que llega de Internet nunca se da por bueno."""
    datos = datos if isinstance(datos, dict) else {}
    limpio = {k: (str(datos[k])[:200] if isinstance(datos.get(k), (str, int)) and not isinstance(datos.get(k), bool) else "") for k in CAMPOS_PUBLICOS}
    limpio["acepta"] = datos.get("acepta") in (True, 1, "1", "true")
    return limpio


class SvcReservasPublicas:
    # ============================================================ activación y límites
    def reservas_publicas_activas(self):
        return self.reservas_online_activas() and self.cfg("reservas_publicas_activas") == "1"

    def _exigir_publicas(self):
        if not self.reservas_publicas_activas():
            raise ErrorNegocio("Las reservas online no están disponibles.", 404)

    def _limitar(self, clave, maximo, ventana_s):
        """Límite de peticiones en memoria (por IP o por email): más de «maximo» en «ventana_s» segundos → error 429."""
        if IP_PRUEBA in clave:   # 1.16: desde la web local de pruebas no se limitan las peticiones
            return
        if not hasattr(self, "_lim_lock"):
            self._lim_lock, self._lim = threading.Lock(), {}
        ahora = time.monotonic()
        with self._lim_lock:
            marcas = [t for t in self._lim.get(clave, []) if ahora - t < ventana_s]
            if len(marcas) >= maximo:
                self._lim[clave] = marcas
                raise ErrorNegocio("Demasiadas peticiones. Inténtelo de nuevo en unos minutos.", 429)
            marcas.append(ahora)
            self._lim[clave] = marcas
            if len(self._lim) > 5000:   # no crece sin fin
                for k in [k for k, v in self._lim.items() if not v or ahora - v[-1] > 3600]:
                    self._lim.pop(k, None)

    # ============================================================ datos para la página
    def pub_config(self):
        self._exigir_publicas()
        zonas = [{"id": z["id"], "nombre": z["nombre"]} for z in self.zonas() if int(z.get("cupo_online") or 0) > 0]
        con_zonas = bool(self.zonas())
        if con_zonas and not zonas:
            raise ErrorNegocio("Las reservas online no están disponibles.", 404)
        horas = self._ajuste_res("reservas_cancel_horas")
        pago = self._config_pago()
        cond = (self.cfg("reservas_condiciones") or "").strip() or CONDICIONES_DEFECTO.format(horas=horas, pago=TEXTO_PAGO[pago["pago_modo"]])
        tipos = [x.strip() for x in (self.cfg("tipos_vehiculo") or "").split(",") if x.strip()] if self.cfg("tipos_vehiculo_activo") == "1" else []
        horario = None
        if self.horario_activo():
            from .svc_horario import DIAS
            sem = self._horario_semana()
            horario = [{"dia": DIAS[i - 1], "texto": ("24 horas" if sem[str(i)]["24h"] else f"{sem[str(i)]['desde']} - {sem[str(i)]['hasta']}")
                        if sem[str(i)]["abierto"] else "Cerrado"} for i in range(1, 8)]
        return {"parking": self.cfg("nombre_parking") or "Parking", "zonas": zonas, "tipos": tipos, "horario": horario,
                "antelacion_min_min": self._ajuste_res("reservas_antelacion_min_min"), "antelacion_max_dias": self._ajuste_res("reservas_antelacion_max_dias"),
                "max_dias": self._ajuste_res("reservas_max_dias"), "min_minutos": self._ajuste_res("reservas_min_minutos"), "cancelar_horas": horas, "condiciones": cond,
                "pago_online": self.pago_online_reservas_activo(), "pago_modo": pago["pago_modo"], "pago_horas": pago["pago_horas"], "pago_instrucciones": pago["pago_instrucciones"]}

    def pub_consulta(self, datos, ip):
        """Disponibilidad y precio para unas fechas (sin dar el número exacto de plazas libres)."""
        self._exigir_publicas()
        datos = limpiar_publico(datos)
        self._limitar(("consulta", ip), 120, 600)
        zona = self._zona_publica(datos.get("zona_id"))
        d = {"desde": datos.get("desde"), "hasta": datos.get("hasta"), "zona_id": zona, "tipo_vehiculo": self._tipo_publico(datos.get("tipo_vehiculo"))}
        disp = self.disponibilidad_reservas(zona, d["desde"], d["hasta"], origen="web")
        pr = self.presupuesto_reserva(d, origen="web")
        estado = "completo" if not disp["disponible"] else "pocas" if disp["libres"] <= 2 else "libre"
        senal = self.senal_para(pr["importe_cent"])
        return {"estado": estado, "importe_cent": pr["importe_cent"], "minutos": pr["minutos"], "senal_cent": senal}

    def _zona_publica(self, zona_id):
        zonas = [z for z in self.zonas() if int(z.get("cupo_online") or 0) > 0]
        if not self.zonas():
            return None
        try:
            zid = int(zona_id)
        except (TypeError, ValueError):
            raise ErrorNegocio("Elija la zona")
        if zid not in {z["id"] for z in zonas}:
            raise ErrorNegocio("Zona no válida")
        return zid

    def _tipo_publico(self, tipo):
        tipo = (str(tipo or "").strip()[:30] or None)
        if self.cfg("tipos_vehiculo_activo") == "1":
            tipos = [x.strip() for x in (self.cfg("tipos_vehiculo") or "").split(",") if x.strip()]
            if tipos and tipo not in tipos:
                raise ErrorNegocio("Elija el tipo de vehículo")
        else:
            tipo = None
        return tipo

    # ============================================================ crear, ver y cancelar
    def pub_crear(self, datos, ip, host=None):
        self._exigir_publicas()
        datos = limpiar_publico(datos)
        if str(datos.get("web") or "").strip():   # campo trampa: los robots lo rellenan
            raise ErrorNegocio("Solicitud no válida")
        self._limitar(("crear", ip), 6, 3600)
        nombre = str(datos.get("nombre") or "").strip()[:80]
        email = str(datos.get("email") or "").strip().lower()[:120]
        if len(nombre) < 2:
            raise ErrorNegocio("Indique su nombre")
        if not email_valido(email):
            raise ErrorNegocio("Indique un email válido: allí se envía la confirmación")
        if not datos.get("acepta"):
            raise ErrorNegocio("Debe aceptar las condiciones de la reserva")
        if ip != IP_PRUEBA:
            self._limitar(("crear-email", email), 4, 3600)
        n = 0 if ip == IP_PRUEBA else self.db.q1("SELECT COUNT(*) n FROM reservas_previstas WHERE origen='web' AND estado='pendiente' AND lower(email)=?", (email,))["n"]   # (en la web de pruebas se puede repetir el email)
        if n >= MAX_PENDIENTES_EMAIL:
            raise ErrorNegocio(f"Ya tiene {MAX_PENDIENTES_EMAIL} reservas pendientes con este email. Cancele alguna o espere a usarlas.", 409)
        zona = self._zona_publica(datos.get("zona_id"))
        r = self.crear_reserva_online(None, {"matricula": datos.get("matricula"), "desde": datos.get("desde"), "hasta": datos.get("hasta"),
                                             "zona_id": zona, "tipo_vehiculo": self._tipo_publico(datos.get("tipo_vehiculo")), "plazas": 1,
                                             "cliente": nombre, "email": email, "telefono": datos.get("telefono")}, origen="web")
        self.db.ex("UPDATE reservas_previstas SET condiciones=?, email_estado='pendiente' WHERE id=?", (self.ahora().isoformat(timespec="seconds"), r["id"]))
        base = self._base_publica(host)
        if getattr(self, "email_sincrono", False) or not (self.cfg("smtp_servidor") or "").strip():   # sin correo no hay nada que esperar
            self.enviar_email_reserva(r["id"], base)
        else:
            threading.Thread(target=self.enviar_email_reserva, args=(r["id"], base), daemon=True).start()
        return self._vista_publica(r["id"])

    def _buscar_publica(self, codigo, matricula, ip):
        self._exigir_publicas()
        self._limitar(("buscar", ip), 40, 600)
        cod = re.sub(r"[^A-Z0-9-]", "", str(codigo or "").upper())[:12] if isinstance(codigo, str) else ""
        mat = norm_matricula(matricula) if isinstance(matricula, str) else None
        r = self.db.q1("SELECT id FROM reservas_previstas WHERE codigo=? AND matricula=? AND origen IN ('mostrador','web')", (cod, mat)) if cod and mat else None
        if not r:
            raise ErrorNegocio("No encontramos esa reserva. Compruebe el código y la matrícula.", 404)
        return r["id"]

    def pub_ver(self, codigo, matricula, ip):
        rid = self._buscar_publica(codigo, matricula, ip)
        if self.pago_online_reservas_activo() and self.db.q1("SELECT 1 x FROM reservas_previstas WHERE id=? AND pago='pendiente_pago' AND pago_sesion IS NOT NULL", (rid,)):
            try:
                self.confirmar_senal_stripe(rid)   # puede que acabe de pagar
            except Exception as e:  # noqa: BLE001
                from . import errores
                errores.fallo("reservas.stripe", e)
        return self._vista_publica(rid)

    def pub_cancelar(self, codigo, matricula, ip):
        rid = self._buscar_publica(codigo, matricula, ip)
        self._limitar(("cancelar", ip), 10, 3600)
        self.cancelar_reserva_online(None, rid, como_cliente=True)
        return self._vista_publica(rid)

    def _vista_publica(self, rid):
        from .codigos import qr_svg
        r = self.db.q1("SELECT r.*, z.nombre zona_nombre FROM reservas_previstas r LEFT JOIN zonas z ON z.id=r.zona_id WHERE r.id=?", (int(rid),))
        limite = parse(r["desde"]) - timedelta(hours=self._ajuste_res("reservas_cancel_horas"))
        return {"codigo": r["codigo"], "matricula": r["matricula"], "desde": r["desde"], "hasta": r["hasta"], "zona": r["zona_nombre"],
                "tipo_vehiculo": r["tipo_vehiculo"], "estado": r["estado"], "importe_cent": r["importe_cent"], "email": r["email"],
                "email_estado": r["email_estado"], "parking": self.cfg("nombre_parking") or "",
                "no_presentada": bool(r["noshow"]), "puede_cancelar": r["estado"] == "pendiente" and self.ahora() <= limite, "limite_cancelacion": limite.isoformat(timespec="seconds"),
                "pago": r["pago"], "senal_cent": r["senal_cent"], "pago_limite": r["pago_limite"], "pago_metodo": r["pago_metodo"],
                "puede_pagar_online": bool(r["estado"] in ("pendiente", "usada") and r["pago"] == "pendiente_pago" and r["senal_cent"] > 0
                                           and self.pago_online_reservas_activo() and (self.cfg("reservas_web_url") or "").strip()),
                "pago_instrucciones": self.cfg("reservas_pago_instrucciones") if r["pago"] == "pendiente_pago" else "",
                "qr": qr_svg(r["codigo"], modulo=5)}

    # ============================================================ kit para la web del aparcamiento
    def kit_web_reservas(self, carpeta):
        """Zip con la carpeta integracion_web; en reservas.html pone la dirección del programa (Ajustes → Reservas online)."""
        import io
        import json as _json
        import os
        import zipfile
        api = (self.cfg("reservas_url_publica") or "").strip().rstrip("/")
        if not os.path.isdir(carpeta):
            raise ErrorNegocio("El kit para la web no está en esta instalación", 404)
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            for nombre in sorted(os.listdir(carpeta)):
                ruta = os.path.join(carpeta, nombre)
                if not os.path.isfile(ruta):
                    continue
                with open(ruta, "rb") as fh:
                    datos = fh.read()
                if nombre == "reservas.html" and api:
                    datos = datos.replace(b'window.ALLAS_API = window.ALLAS_API || "";', ("window.ALLAS_API = " + _json.dumps(api) + ";").encode("utf-8"))
                z.writestr("reservas_para_mi_web/" + nombre, datos)
        return buf.getvalue()

    def kit_servidor_reservas(self, carpeta_servidor, carpeta_web):
        """1.18: zip con el servidor intermedio (relay.py), la página de reservas lista para servirlo y las instrucciones.
        No lleva la clave: se pone en el servidor con la variable ALLAS_RELAY_TOKEN."""
        import io
        import os
        import zipfile
        if not os.path.isdir(carpeta_servidor) or not os.path.isdir(carpeta_web):
            raise ErrorNegocio("El servidor de reservas no está en esta instalación", 404)
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            for nombre in sorted(os.listdir(carpeta_servidor)):
                ruta = os.path.join(carpeta_servidor, nombre)
                if os.path.isfile(ruta) and nombre != "__pycache__":
                    with open(ruta, "rb") as fh:
                        z.writestr("servidor_reservas/" + nombre, fh.read())
            for nombre in sorted(os.listdir(carpeta_web)):
                ruta = os.path.join(carpeta_web, nombre)
                if os.path.isfile(ruta):
                    with open(ruta, "rb") as fh:
                        z.writestr("servidor_reservas/web/" + nombre, fh.read())   # (ALLAS_API vacío: la página llama al mismo servidor)
        return buf.getvalue()

    # ============================================================ email de confirmación
    def _base_publica(self, host=None):
        """1.14: página de reservas de la web del aparcamiento (donde el cliente ve o cancela su reserva). Vacía = el email no lleva enlace."""
        return (self.cfg("reservas_web_url") or "").strip()

    def enviar_email_reserva(self, rid, base=""):
        """Confirmación por email. Sin servidor de correo configurado no se envía (la reserva se ve igualmente en pantalla)."""
        r = self.db.q1("SELECT r.*, z.nombre zona_nombre FROM reservas_previstas r LEFT JOIN zonas z ON z.id=r.zona_id WHERE r.id=?", (int(rid),))
        if not r or not r["email"]:
            return None
        cfg = self.db.config()
        if not (cfg.get("smtp_servidor") or "").strip():
            self.db.ex("UPDATE reservas_previstas SET email_estado='sin_correo' WHERE id=?", (r["id"],))
            return "sin_correo"
        fmt = lambda s: parse(s).strftime("%d/%m/%Y %H:%M")   # noqa: E731
        enlace = f"\nPara ver, modificar o cancelar su reserva: {base}{'&' if '?' in base else '?'}c={r['codigo']}\n" if base else ""
        texto = (f"Hola {r['cliente'] or ''},\n\nSu reserva en {cfg.get('nombre_parking') or 'el parking'} está confirmada.\n\n"
                 f"Código: {r['codigo']}\nMatrícula: {r['matricula']}\nEntrada: {fmt(r['desde'])}\nSalida: {fmt(r['hasta'])}\n"
                 + (f"Zona: {r['zona_nombre']}\n" if r["zona_nombre"] else "")
                 + self._texto_pago_email(r)
                 + f"{enlace}\n"
                 f"Puede cambiar las fechas o cancelarla gratis hasta {self._ajuste_res('reservas_cancel_horas')} horas antes de la entrada.\n"
                 "Adjuntamos el código QR de su reserva.\n")
        try:
            from .correo import enviar
            from .codigos import qr_png
            enviar(cfg, r["email"], f"Reserva confirmada {r['codigo']} · {cfg.get('nombre_parking') or 'Parking'}", texto,
                   [(f"reserva-{r['codigo']}.png", qr_png(r["codigo"]), "image/png")])   # 1.18: el QR va adjunto
            self.db.ex("UPDATE reservas_previstas SET email_estado='enviado', email_intentos=email_intentos+1 WHERE id=?", (r["id"],))
            return "enviado"
        except Exception as ex:  # noqa: BLE001  sin conexión, credenciales… queda pendiente para reintentar
            estado = "error" if r["email_intentos"] + 1 >= 5 else "pendiente"
            self.db.ex("UPDATE reservas_previstas SET email_estado=?, email_intentos=email_intentos+1 WHERE id=?", (estado, r["id"]))
            from . import errores
            errores.fallo("reservas.email", ex)
            return estado

    def _texto_pago_email(self, r):
        """Qué se paga y cuándo, según la forma de cobro de la reserva."""
        total = f"Importe estimado: {r['importe_cent'] / 100:.2f} €\n"
        if r["pago"] == "pendiente_pago":
            lim = parse(r["pago_limite"]).strftime("%d/%m/%Y %H:%M") if r["pago_limite"] else ""
            ins = (self.cfg("reservas_pago_instrucciones") or "").strip()
            return (total + f"Señal a pagar para mantener la reserva: {r['senal_cent'] / 100:.2f} €" + (f", antes del {lim}" if lim else "")
                    + ". Si no se paga a tiempo, la reserva se cancela sola.\n" + (f"Cómo pagarla: {ins}\n" if ins else "")
                    + f"El resto ({max(0, r['importe_cent'] - r['senal_cent']) / 100:.2f} €) se paga en el parking.\n")
        if r["pago"] == "pagada":
            return total + f"Señal pagada: {r['senal_cent'] / 100:.2f} € (se descuenta del importe final).\n"
        return total.replace("Importe estimado:", "Importe estimado a pagar en el parking:")

    def reintentar_emails_reservas(self):
        self.caducar_reservas_sin_pago()
        base = self._base_publica()
        for x in self.db.q("SELECT id FROM reservas_previstas WHERE email_estado='pendiente' AND estado='pendiente' ORDER BY id LIMIT 50"):
            self.enviar_email_reserva(x["id"], base)

    def reenviar_email_reserva(self, usuario, rid, host=None):
        self._exigir_permiso(usuario, "reservas")
        r = self.db.q1("SELECT email, estado FROM reservas_previstas WHERE id=? AND origen IN ('mostrador','web')", (int(rid),))
        if not r or not r["email"]:
            raise ErrorNegocio("Esta reserva no tiene email", 409)
        if r["estado"] != "pendiente":
            raise ErrorNegocio("Solo se reenvía la confirmación de reservas pendientes", 409)
        return {"estado": self.enviar_email_reserva(rid, self._base_publica(host))}
