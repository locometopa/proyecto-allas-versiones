"""PROYECTO ALLAS · lógica de negocio: pantalla de cliente, visor, anuncios, barrera y datáfono (1.4: sale de servicios.py; se mezcla en la clase Parking)."""
from .utiles import ErrorNegocio, iso


class SvcEquipos:
    # ============================ pantalla de cliente y publicidad (3.2)
    PUBLI_MAX = 1_500_000

    def pantalla_cliente(self):
        """Lo que necesita la ventana del cliente (no lleva datos privados: es pública en la red local)."""
        from . import __version__
        return {"activa": self.activo("pantalla_cliente_activa", "pantalla_cliente"),
                "nombre_parking": self.cfg("nombre_parking") or "",
                "bienvenida": self.cfg("pantalla_cliente_bienvenida") or "Bienvenido",
                "gracias": self.cfg("pantalla_cliente_gracias") or "¡Gracias por su visita!",
                "segundos": max(3, min(120, self.cfg("pantalla_cliente_segundos", int) or 8)),
                "anuncios": self.anuncios(solo_activos=True), **self.estilo_pantalla_cliente(), "version": __version__}

    # ---------------------------------------------------------- visor TPV de texto (3.3)
    def modo_pantalla_cliente(self):
        m = self.cfg("pantalla_cliente_modo") or "monitor"
        return m if m in ("monitor", "visor", "ambos") else "monitor"

    def visor_activo(self):
        return self.activo("pantalla_cliente_activa", "pantalla_cliente") and self.modo_pantalla_cliente() in ("visor", "ambos")

    def cfg_visor(self, cambios=None):
        from .visor import EFECTOS, VELOCIDADES
        c = self._cfg_visor()
        for k, v in (cambios or {}).items():   # 4.11: probar con lo que se ve en pantalla, sin guardar
            if k in c and isinstance(v, (str, int)) and str(v) != "":
                c[k] = int(v) if k in ("baudios", "columnas") and str(v).isdigit() else v
        c["columnas"] = max(8, min(40, int(c["columnas"] or 20)))
        from .visor import FORMATOS_SERIE
        if str(c.get("formato")).upper() not in FORMATOS_SERIE:
            c["formato"] = "8N1"
        if c["efecto"] not in EFECTOS:
            c["efecto"] = "ninguno"
        if c["velocidad"] not in VELOCIDADES:
            c["velocidad"] = "normal"
        return c

    def _cfg_visor(self):
        return {"efecto": self.cfg("visor_efecto") or "ninguno", "velocidad": self.cfg("visor_velocidad") or "normal", "conexion": self.cfg("visor_conexion") or "archivo", "destino": self.cfg("visor_destino") or "",
                "baudios": self.cfg("visor_baudios", int) or 9600, "protocolo": self.cfg("visor_protocolo") or "epson", "formato": self.cfg("visor_formato") or "8N1",
                "columnas": self.cfg("visor_columnas", int) or 20,
                "reposo1": self.cfg("visor_reposo1") or self.cfg("nombre_parking") or "",
                "reposo2": self.cfg("visor_reposo2") or self.cfg("pantalla_cliente_bienvenida") or "Bienvenido",
                "bienvenida": self.cfg("pantalla_cliente_bienvenida") or "Bienvenido",
                "gracias": self.cfg("pantalla_cliente_gracias") or "Gracias"}

    def mostrar_visor(self, datos):
        """Lo que se está cobrando, en el visor (mismo mensaje que la pantalla de cliente)."""
        from . import visor
        if not self.visor_activo():
            return {"activo": False}
        cfg = self.cfg_visor()
        l1, l2 = visor.lineas(datos if isinstance(datos, dict) else {}, cfg)
        visor.VISOR.mostrar(l1, l2, cfg, crudos=visor.textos_libres(datos if isinstance(datos, dict) else {}, cfg))
        return {"activo": True, "lineas": [l1, l2]}

    def probar_visor(self, cambios=None):
        """Escribe un mensaje de prueba en el visor con los ajustes indicados (o los guardados) y devuelve los cuadros del efecto
        para que la pantalla los reproduzca en el visor de muestra."""
        from . import visor
        cambios = dict(cambios or {})
        solo_ver = bool(cambios.pop("solo_ver", False))
        lineas_prueba = cambios.pop("lineas", None)   # solo calcular los cuadros (sin visor conectado)
        cfg = self.cfg_visor(cambios)
        cols = cfg["columnas"]
        texto = ("PROYECTO ALLAS", "Visor conectado")
        if isinstance(lineas_prueba, (list, tuple)) and len(lineas_prueba) == 2:   # asistente de ajuste: textos para reconocer los fallos
            texto = (str(lineas_prueba[0])[:40], str(lineas_prueba[1])[:40])
        l1, l2 = visor.centro(texto[0], cols), visor.centro(texto[1], cols)
        crudos = (cfg.get("reposo1") or texto[0], cfg.get("reposo2") or texto[1]) if cfg["efecto"] != "ninguno" else (None, None)
        destino = None
        if not solo_ver:
            try:
                destino = visor.VISOR.mostrar(l1, l2, cfg, esperar=True, crudos=crudos)
            except Exception as e:
                raise ErrorNegocio(f"No se puede escribir en el visor ({cfg['conexion']} {cfg['destino'] or ''}): {e}")
        efecto_ok = cfg["efecto"] != "ninguno" and visor.efectos_permitidos(cfg["conexion"])
        cuadros, repetir = visor.fotogramas(l1, l2, cols, cfg["efecto"], crudos) if efecto_ok else ([(l1, l2)], False)
        return {"ok": True, "destino": destino, "lineas": [l1, l2], "columnas": cols,
                "cuadros": [list(c) for c in cuadros[:400]], "repetir": repetir,
                "ritmo_ms": int(visor.VELOCIDADES.get(cfg["velocidad"], 0.28) * 1000)}

    def puertos_visor(self):
        from . import visor
        return {"puertos": visor.puertos_serie(), "efectos": visor.EFECTOS}

    def estado_visor(self):
        from . import visor
        return {"activo": self.visor_activo(), "lineas": list(visor.VISOR.ultimo), "error": visor.VISOR.error,
                "columnas": self.cfg_visor()["columnas"]}

    def anuncios(self, solo_activos=False):
        return self.db.q("SELECT id, titulo, texto, orden, activo, actualizado FROM publicidad"
                         + (" WHERE activo=1" if solo_activos else "") + " ORDER BY orden, id")

    def guardar_anuncio(self, actor_id, datos=None, imagen=None, aid=None):
        datos = datos or {}
        titulo = (datos.get("titulo") or "").strip()[:80] or None
        texto = (datos.get("texto") or "").strip()[:200] or None
        with self.db.transaccion() as c:
            if aid:
                if not c.execute("SELECT 1 FROM publicidad WHERE id=?", (aid,)).fetchone():
                    raise ErrorNegocio("Anuncio no encontrado", 404)
                c.execute("UPDATE publicidad SET titulo=?, texto=?, activo=?, orden=COALESCE(?, orden), actualizado=? WHERE id=?",
                          (titulo, texto, 0 if datos.get("activo") in (False, 0, "0") else 1,
                           int(datos["orden"]) if str(datos.get("orden", "")).lstrip("-").isdigit() else None,
                           iso(self.ahora()), aid))
            if imagen is not None:
                if len(imagen) > self.PUBLI_MAX:
                    raise ErrorNegocio("La imagen es demasiado grande (máximo 1,5 MB)")
                tipo = self._tipo_imagen(imagen)
                if aid:
                    c.execute("UPDATE publicidad SET tipo=?, datos=?, actualizado=? WHERE id=?", (tipo, imagen, iso(self.ahora()), aid))
                else:
                    orden = (c.execute("SELECT MAX(orden) FROM publicidad").fetchone()[0] or 0) + 1
                    aid = c.execute("INSERT INTO publicidad(titulo, texto, tipo, datos, orden, actualizado) VALUES(?,?,?,?,?,?)",
                                    (titulo, texto, tipo, imagen, orden, iso(self.ahora()))).lastrowid
            elif not aid:
                raise ErrorNegocio("Elija una foto para el anuncio")
            self.auditar(c, actor_id, "publicidad_guardar", f"id={aid} {titulo or ''}")
        return aid

    def mover_anuncio(self, actor_id, aid, sentido):
        filas = self.anuncios()
        ids = [f["id"] for f in filas]
        if aid not in ids:
            raise ErrorNegocio("Anuncio no encontrado", 404)
        i = ids.index(aid)
        j = i - 1 if sentido == "arriba" else i + 1
        if 0 <= j < len(ids):
            ids[i], ids[j] = ids[j], ids[i]
        with self.db.transaccion() as c:
            for n, x in enumerate(ids):
                c.execute("UPDATE publicidad SET orden=? WHERE id=?", (n, x))
        return {"ok": True}

    def eliminar_anuncio(self, actor_id, aid):
        with self.db.transaccion() as c:
            if not c.execute("DELETE FROM publicidad WHERE id=?", (aid,)).rowcount:
                raise ErrorNegocio("Anuncio no encontrado", 404)
            self.auditar(c, actor_id, "publicidad_eliminar", f"id={aid}")
        return {"ok": True}

    def imagen_anuncio(self, aid):
        r = self.db.q1("SELECT tipo, datos FROM publicidad WHERE id=?", (aid,))
        if not r:
            raise ErrorNegocio("Anuncio no encontrado", 404)
        return r["datos"], r["tipo"]

    # ------------------------------------------------------------ 3.9: barrera y datáfono (opcionales)
    EVENTOS_BARRERA = ("entrada", "abonado", "salida")

    def cfg_barrera(self):
        ev = (self.cfg("barrera_eventos") or "abonado,salida").split(",")
        return {"activa": self.activo("barrera_activa", "perifericos"), "conexion": self.cfg("barrera_conexion") or "http",
                "destino": self.cfg("barrera_destino") or "", "abrir": self.cfg("barrera_abrir") or "",
                "cerrar": self.cfg("barrera_cerrar") or "", "pulso_ms": self.cfg("barrera_pulso_ms", int) or 0,
                "baudios": self.cfg("barrera_baudios", int) or 9600,
                "eventos": [e for e in ev if e in self.EVENTOS_BARRERA]}

    def abrir_barrera(self, evento, usuario=None, motivo="", esperar=False):
        """Abre la barrera si está activada y el evento lo pide ('manual' siempre). Sin esperar: en segundo plano,
        para no retrasar el cobro; devuelve True si se ha mandado abrir."""
        cfg = self.cfg_barrera()
        if not cfg["activa"] or (evento != "manual" and evento not in cfg["eventos"]):
            return None
        from . import perifericos

        def hacer():
            try:
                r = perifericos.abrir_barrera(cfg)
                self.db.set_cfg("barrera_ultimo", f"{iso(self.ahora())} {evento}: {r}")
                self.db.set_cfg("barrera_ultimo_error", "")
                return r
            except Exception as e:  # noqa: BLE001
                self.db.set_cfg("barrera_ultimo_error", f"{iso(self.ahora())} {evento}: {e}")
                if esperar:
                    raise ErrorNegocio(f"No se pudo abrir la barrera: {e}")
                return None
        if evento == "manual":
            with self.db.transaccion() as c:
                self.auditar(c, usuario["id"] if usuario else None, "barrera_abrir", motivo or "manual")
        if esperar:
            return hacer()
        import threading
        threading.Thread(target=hacer, daemon=True, name="barrera").start()
        return True

    def cfg_datafono(self):
        return {"activo": self.activo("datafono_activo", "perifericos"), "modo": self.cfg("datafono_modo") or "simulado",
                "destino": self.cfg("datafono_destino") or "", "timeout": self.cfg("datafono_timeout", int) or 90}

    def cobrar_datafono(self, usuario, importe_cent, referencia=None):
        cfg = self.cfg_datafono()
        if not cfg["activo"]:
            raise ErrorNegocio("El datáfono integrado está desactivado (Ajustes → Equipos → Datáfono)")
        importe = int(importe_cent)
        if importe <= 0:
            raise ErrorNegocio("Importe no válido")
        from . import perifericos
        r = perifericos.cobrar_datafono(cfg, importe, referencia)
        with self.db.transaccion() as c:
            self.auditar(c, usuario["id"], "datafono", f"{importe} {'aprobada ' + (r.get('autorizacion') or '') if r['ok'] else 'NO: ' + r['mensaje']}")
        return r

    def anotar_referencia_pago(self, pago_id, referencia):
        """Nº de autorización del datáfono en el cobro (si el cobro no tenía referencia)."""
        if pago_id and referencia:
            with self.db.transaccion() as c:
                c.execute("UPDATE pagos SET referencia=? WHERE id=? AND referencia IS NULL",
                          ("Datáfono " + str(referencia)[:40], pago_id))
