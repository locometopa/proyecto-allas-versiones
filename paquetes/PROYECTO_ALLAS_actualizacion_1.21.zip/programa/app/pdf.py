"""Facturas en PDF (A4) sin dependencias, con la tipografía Poppins incrustada.

- Lee las fuentes TrueType de app/fuentes (Poppins, licencia SIL OFL 1.1) y las incrusta
  completas en el PDF como fuentes TrueType simples con codificación WinAnsi: se ven igual
  en cualquier ordenador o móvil, con tildes, ñ y el símbolo €.
- Calcula el ancho real de cada texto para alinear importes a la derecha y partir líneas.
"""
import os
import struct
import zlib

A4 = (595.28, 841.89)
FUENTES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fuentes")
_cache = {}

# Colores (RGB 0-1)
TINTA = (0.08, 0.106, 0.149)
SUAVE = (0.357, 0.4, 0.463)
LINEA = (0.843, 0.867, 0.902)
FONDO = (0.957, 0.965, 0.98)
ACENTO = (0.09, 0.278, 0.788)


# ------------------------------------------------------------------ fuentes TrueType
class FuenteTTF:
    def __init__(self, ruta, nombre_pdf):
        self.nombre_pdf = nombre_pdf
        with open(ruta, "rb") as f:
            self.datos = f.read()
        d = self.datos
        n = struct.unpack(">H", d[4:6])[0]
        tablas = {}
        for i in range(n):
            tag, _, off, ln = struct.unpack(">4sLLL", d[12 + 16 * i: 28 + 16 * i])
            tablas[tag.decode("latin-1")] = (off, ln)
        o = tablas["head"][0]
        self.upm = struct.unpack(">H", d[o + 18:o + 20])[0]
        self.bbox = struct.unpack(">hhhh", d[o + 36:o + 44])
        o = tablas["hhea"][0]
        self.ascent, self.descent = struct.unpack(">hh", d[o + 4:o + 8])
        n_metricas = struct.unpack(">H", d[o + 34:o + 36])[0]
        o = tablas["hmtx"][0]
        self.avances = [struct.unpack(">H", d[o + 4 * i:o + 4 * i + 2])[0] for i in range(n_metricas)]
        self.cap = self.ascent * 0.7
        if "OS/2" in tablas:
            o, ln = tablas["OS/2"]
            if ln >= 90:
                self.cap = struct.unpack(">h", d[o + 88:o + 90])[0] or self.cap
        self.cmap = self._leer_cmap(tablas["cmap"][0])
        # anchos (1/1000 em) de los códigos WinAnsi 32..255
        self.anchos = []
        for codigo in range(32, 256):
            ch = bytes([codigo]).decode("cp1252", errors="replace")
            gid = self.cmap.get(ord(ch), 0)
            av = self.avances[min(gid, len(self.avances) - 1)]
            self.anchos.append(round(av * 1000 / self.upm))

    def _leer_cmap(self, o):
        d = self.datos
        n = struct.unpack(">H", d[o + 2:o + 4])[0]
        sub = None
        for i in range(n):
            pid, eid, off = struct.unpack(">HHL", d[o + 4 + 8 * i: o + 12 + 8 * i])
            if pid == 3 and eid in (1, 10) or pid == 0:
                if struct.unpack(">H", d[o + off:o + off + 2])[0] == 4:
                    sub = o + off
                    break
        mapa = {}
        if sub is None:
            return mapa
        segx2 = struct.unpack(">H", d[sub + 6:sub + 8])[0]
        seg = segx2 // 2
        fin = sub + 14
        ini = fin + segx2 + 2
        delta = ini + segx2
        rango = delta + segx2
        for i in range(seg):
            c_fin = struct.unpack(">H", d[fin + 2 * i:fin + 2 * i + 2])[0]
            c_ini = struct.unpack(">H", d[ini + 2 * i:ini + 2 * i + 2])[0]
            dl = struct.unpack(">h", d[delta + 2 * i:delta + 2 * i + 2])[0]
            ro = struct.unpack(">H", d[rango + 2 * i:rango + 2 * i + 2])[0]
            if c_ini > 0xFFFF or c_ini == 0xFFFF:
                continue
            for c in range(c_ini, c_fin + 1):
                if ro == 0:
                    g = (c + dl) & 0xFFFF
                else:
                    p = rango + 2 * i + ro + 2 * (c - c_ini)
                    g = struct.unpack(">H", d[p:p + 2])[0]
                    if g:
                        g = (g + dl) & 0xFFFF
                mapa[c] = g
        return mapa

    def ancho(self, texto, tam):
        total = 0
        for b in texto.encode("cp1252", errors="replace"):
            total += self.anchos[b - 32] if b >= 32 else 0
        return total * tam / 1000


def _fuentes():
    if not _cache:
        _cache["R"] = FuenteTTF(os.path.join(FUENTES, "Poppins-Regular.ttf"), "Poppins-Regular")
        _cache["M"] = FuenteTTF(os.path.join(FUENTES, "Poppins-Medium.ttf"), "Poppins-Medium")
        _cache["B"] = FuenteTTF(os.path.join(FUENTES, "Poppins-Bold.ttf"), "Poppins-Bold")
    return _cache


def _txt(s):
    b = s.encode("cp1252", errors="replace")
    return b.replace(b"\\", b"\\\\").replace(b"(", b"\\(").replace(b")", b"\\)")


# ------------------------------------------------------------------ lienzo de dibujo
class Lienzo:
    def __init__(self):
        self.f = _fuentes()
        self.ops = []
        self.imagenes = []   # [(jpeg, ancho_px, alto_px, componentes)]

    def color(self, rgb, relleno=True):
        self.ops.append(("%.3f %.3f %.3f " % rgb + ("rg" if relleno else "RG")).encode() + b"\n")

    def rect(self, x, y, w, h, rgb):
        self.color(rgb)
        self.ops.append(b"%.2f %.2f %.2f %.2f re f\n" % (x, y, w, h))

    def linea(self, x1, y1, x2, y2, rgb=LINEA, grosor=0.8):
        self.color(rgb, relleno=False)
        self.ops.append(b"%.2f w %.2f %.2f m %.2f %.2f l S\n" % (grosor, x1, y1, x2, y2))

    def texto(self, x, y, s, tam=9.5, peso="R", rgb=TINTA, alin="izq"):
        if not s:
            return
        if alin == "der":
            x -= self.f[peso].ancho(s, tam)
        elif alin == "centro":
            x -= self.f[peso].ancho(s, tam) / 2
        self.color(rgb)
        self.ops.append(b"BT /F%s %.2f Tf %.2f %.2f Td (" % (peso.encode(), tam, x, y) + _txt(s) + b") Tj ET\n")

    def ancho(self, s, tam=9.5, peso="R"):
        return self.f[peso].ancho(s, tam)

    def partir(self, s, ancho_max, tam=9.5, peso="R"):
        """Corta un texto en líneas que quepan en 'ancho_max' puntos."""
        lineas = []
        for parrafo in (s or "").splitlines() or [""]:
            actual = ""
            for palabra in parrafo.split():
                prueba = (actual + " " + palabra).strip()
                if self.ancho(prueba, tam, peso) <= ancho_max or not actual:
                    actual = prueba
                else:
                    lineas.append(actual)
                    actual = palabra
            lineas.append(actual)
        return lineas

    def imagen(self, x, y, w, h, img):
        """Dibuja un JPEG ('img' = {'jpeg','ancho','alto'}) en el rectángulo dado (y = borde inferior)."""
        self.imagenes.append(img)
        self.ops.append(b"q %.2f 0 0 %.2f %.2f %.2f cm /Im%d Do Q\n" % (w, h, x, y, len(self.imagenes)))

    def contenido(self):
        return b"".join(self.ops)


def _ensamblar(paginas, titulo, imagenes=(), tam=A4):
    f = _fuentes()
    objetos = []

    def obj(b):
        objetos.append(b)
        return len(objetos)

    cat = obj(b"")
    pags = obj(b"")
    recursos = []
    for clave, fuente in (("R", f["R"]), ("M", f["M"]), ("B", f["B"])):
        datos = zlib.compress(fuente.datos, 9)
        ff = obj(b"<< /Length %d /Length1 %d /Filter /FlateDecode >>\nstream\n" % (len(datos), len(fuente.datos))
                 + datos + b"\nendstream")
        escala = 1000 / fuente.upm
        desc = obj(b"<< /Type /FontDescriptor /FontName /%s /Flags 32 /FontBBox [%d %d %d %d] /ItalicAngle 0 "
                   b"/Ascent %d /Descent %d /CapHeight %d /StemV 80 /FontFile2 %d 0 R >>" % (
                       fuente.nombre_pdf.encode(), *[round(v * escala) for v in fuente.bbox],
                       round(fuente.ascent * escala), round(fuente.descent * escala), round(fuente.cap * escala), ff))
        fo = obj(b"<< /Type /Font /Subtype /TrueType /BaseFont /%s /FirstChar 32 /LastChar 255 /Widths [%s] "
                 b"/FontDescriptor %d 0 R /Encoding /WinAnsiEncoding >>" % (
                     fuente.nombre_pdf.encode(), b" ".join(str(a).encode() for a in fuente.anchos), desc))
        recursos.append(b"/F%s %d 0 R" % (clave.encode(), fo))
    xobjs = []
    for n, img in enumerate(imagenes, 1):
        espacio = b"/DeviceGray" if img.get("componentes") == 1 else (
            b"/DeviceCMYK" if img.get("componentes") == 4 else b"/DeviceRGB")
        io_ = obj(b"<< /Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace %s /BitsPerComponent 8 "
                  b"/Filter /DCTDecode /Length %d >>\nstream\n" % (img["ancho"], img["alto"], espacio, len(img["jpeg"]))
                  + img["jpeg"] + b"\nendstream")
        xobjs.append(b"/Im%d %d 0 R" % (n, io_))
    extra = (b" /XObject << " + b" ".join(xobjs) + b" >>") if xobjs else b""
    kids = []
    for contenido in paginas:
        datos = zlib.compress(contenido)
        c = obj(b"<< /Length %d /Filter /FlateDecode >>\nstream\n" % len(datos) + datos + b"\nendstream")
        p = obj(b"<< /Type /Page /Parent %d 0 R /MediaBox [0 0 %.2f %.2f] /Contents %d 0 R "
                b"/Resources << /Font << %s >>%s >> >>" % (pags, tam[0], tam[1], c, b" ".join(recursos), extra))
        kids.append(p)
    objetos[cat - 1] = b"<< /Type /Catalog /Pages %d 0 R >>" % pags
    objetos[pags - 1] = b"<< /Type /Pages /Kids [%s] /Count %d >>" % (b" ".join(b"%d 0 R" % k for k in kids), len(kids))
    info = obj(b"<< /Title (" + _txt(titulo) + b") /Producer (PROYECTO ALLAS) >>")
    salida = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = []
    for i, o in enumerate(objetos, 1):
        offsets.append(len(salida))
        salida += b"%d 0 obj\n" % i + o + b"\nendobj\n"
    xref = len(salida)
    salida += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objetos) + 1)
    for off in offsets:
        salida += b"%010d 00000 n \n" % off
    salida += b"trailer\n<< /Size %d /Root %d 0 R /Info %d 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (
        len(objetos) + 1, cat, info, xref)
    return bytes(salida)


# ------------------------------------------------------------------ factura A4
def eur(c):
    s = "-" if c < 0 else ""
    c = abs(int(c))
    return f"{s}{c // 100:,}".replace(",", ".") + f",{c % 100:02d} €"


def color_hex(texto, defecto=ACENTO):
    """'#1747c9' -> (r, g, b) 0-1. Si no es válido, el color por defecto."""
    t = (texto or "").strip().lstrip("#")
    if len(t) == 3:
        t = "".join(c * 2 for c in t)
    try:
        if len(t) != 6:
            raise ValueError
        return tuple(int(t[i:i + 2], 16) / 255 for i in (0, 2, 4))
    except ValueError:
        return defecto


def factura_a_pdf(d):
    """d: datos de la factura (ver Parking.pdf_factura). d["estilo"] (4.2): acento, cabecera_tabla, logo_alto."""
    L = Lienzo()
    W, H = A4
    M = 48                     # margen
    x2 = W - M
    y = H - M
    est = d.get("estilo") or {}
    ACENTO = est.get("acento") or globals()["ACENTO"]
    CAB_TABLA = est.get("cabecera_tabla") or TINTA
    pl = d.get("plantilla") or {}          # 4.9: plantilla del Editor de plantillas
    SEC, COL, TX = pl.get("secciones") or {}, pl.get("columnas") or {}, pl.get("textos") or {}
    mostrar = lambda k: SEC.get(k, True)   # noqa: E731
    col_ok = lambda k: COL.get(k, True)    # noqa: E731

    # --- cabecera: (logo) y empresa a la izquierda, título y número a la derecha
    emp = d["empresa"]
    if d.get("logo") and mostrar("logo"):
        lg = d["logo"]
        escala = min(170 / lg["ancho"], (est.get("logo_alto") or 62) / lg["alto"])
        w, h = lg["ancho"] * escala, lg["alto"] * escala
        L.imagen(M, y - h, w, h, lg)
        y -= h + 8
        y_titulo = y + h + 8
    else:
        y_titulo = y
    L.texto(M, y - 16, emp["nombre"], 18, "B")
    yy = y - 34
    for t in [emp.get("razon_social"), "NIF " + emp["nif"] if emp.get("nif") else None,
              emp.get("direccion"), "Tel. " + emp["telefono"] if emp.get("telefono") else None,
              " · ".join(x for x in (emp.get("email"), emp.get("web")) if x) or None]:
        if t:
            for l in L.partir(t, 260, 9):
                L.texto(M, yy, l, 9, "R", SUAVE)
                yy -= 13
    L.texto(x2, y_titulo - 16, d["titulo"], 17, "B", ACENTO, "der")
    L.texto(x2, y_titulo - 34, "Nº " + d["numero"], 11, "M", TINTA, "der")
    L.texto(x2, y_titulo - 49, d["fecha"], 9, "R", SUAVE, "der")
    if d.get("copia"):
        L.texto(x2, y_titulo - 63, "COPIA", 9, "B", SUAVE, "der")
    y = min(yy, y - 70) - 12
    L.linea(M, y, x2, y, ACENTO, 1.6)
    y -= 22

    # --- cliente (si hay) y datos de la estancia
    col = (x2 - M) / 2
    alto_bloque = 0
    if d.get("cliente"):
        cl = d["cliente"]
        lineas = [(cl["nombre"], "M")] + ([("NIF/CIF: " + cl["nif"], "R")] if cl.get("nif") else []) + \
            [(l, "R") for l in L.partir(cl.get("direccion") or "", col - 30, 9)]
        alto_bloque = 30 + 13 * len([l for l in lineas if l[0]])
        L.rect(M, y - alto_bloque + 10, col - 12, alto_bloque, FONDO)
        L.texto(M + 12, y - 6, TX.get("cliente", "CLIENTE"), 7.5, "B", SUAVE)
        yy = y - 22
        for t, peso in lineas:
            if t:
                L.texto(M + 12, yy, t, 9.5 if peso == "M" else 9, peso)
                yy -= 13
    xd = M + (col + 6 if d.get("cliente") else 0)
    detalles = d["detalles"] if mostrar("detalle") else [x for x in d["detalles"] if x[0] in ("Sustituye a", "Rectifica a", "Importe original", "Tipo", "Motivo")]
    if detalles:
        L.texto(xd + (0 if not d.get("cliente") else 6), y - 6, TX.get("detalle", "DETALLE"), 7.5, "B", SUAVE)
    yy = y - 22
    for etiqueta, valor in detalles:
        bx = xd + (0 if not d.get("cliente") else 6)
        L.texto(bx, yy, etiqueta, 9, "R", SUAVE)
        L.texto(bx + 92, yy, valor, 9, "M")
        yy -= 13
    y = min(y - alto_bloque, yy) - 14
    # observaciones del cliente (3.5)
    obs = (d.get("cliente") or {}).get("observaciones")
    if obs and mostrar("observaciones"):
        partes = L.partir("Observaciones: " + obs, x2 - M - 24, 9)
        L.rect(M, y - 13 * len(partes) + 4, x2 - M, 13 * len(partes) + 10, FONDO)
        for t in partes:
            L.texto(M + 12, y - 4, t, 9, "R")
            y -= 13
        y -= 16

    # --- 4.9: texto libre de la plantilla antes de la tabla
    if d.get("antes_tabla"):
        partes = [l for t in d["antes_tabla"].splitlines() for l in (L.partir(t, x2 - M, 9.5) if t.strip() else [""])]
        for t in partes:
            L.texto(M, y, t, 9.5, "R")
            y -= 13
        y -= 8

    # --- tabla de conceptos
    cols = [(TX.get("concepto", "Concepto"), M + 10, "izq")] + \
        ([(TX.get("cantidad", "Cant."), x2 - 200, "der")] if col_ok("cantidad") else []) + \
        ([(TX.get("precio", "Precio"), x2 - 138, "der")] if col_ok("precio") else []) + \
        ([(TX.get("iva", "IVA"), x2 - 86, "der")] if col_ok("iva") else []) + [(TX.get("importe", "Importe"), x2 - 10, "der")]
    L.rect(M, y - 8, x2 - M, 24, CAB_TABLA)
    for t, x, a in cols:
        L.texto(x, y, t, 8.5, "M", (1, 1, 1), a)
    y -= 26
    for ln in d["lineas"]:
        conc = L.partir(ln["concepto"], x2 - 220 - M, 9.5, "M")
        L.texto(M + 10, y, conc[0], 9.5, "M")
        if col_ok("cantidad"):
            L.texto(x2 - 200, y, str(ln.get("cantidad", 1)), 9.5, "R", TINTA, "der")
        if col_ok("precio"):
            L.texto(x2 - 138, y, eur(ln["precio"]), 9.5, "R", TINTA, "der")
        if col_ok("iva"):
            L.texto(x2 - 86, y, f"{ln['iva']:g} %", 9.5, "R", SUAVE, "der")
        L.texto(x2 - 10, y, eur(ln["importe"]), 9.5, "M", TINTA, "der")
        for extra in conc[1:]:
            y -= 13
            L.texto(M + 10, y, extra, 9.5, "M")
        if ln.get("detalle"):
            for l in L.partir(ln["detalle"], x2 - 220 - M, 8.5):
                y -= 12
                L.texto(M + 10, y, l, 8.5, "R", SUAVE)
        y -= 12
        L.linea(M, y, x2, y)
        y -= 18

    # --- totales
    y -= 4
    bx = x2 - 230
    for dg in d["desglose"]:
        L.texto(bx, y, f"{TX.get('base', 'Base imponible')} {dg['pct']:g} %", 9, "R", SUAVE)
        L.texto(x2 - 10, y, eur(dg["base"]), 9, "R", TINTA, "der")
        y -= 14
        L.texto(bx, y, f"{TX.get('cuota', 'IVA')} {dg['pct']:g} %", 9, "R", SUAVE)
        L.texto(x2 - 10, y, eur(dg["cuota"]), 9, "R", TINTA, "der")
        y -= 14
    y -= 16
    L.rect(bx - 10, y - 12, x2 - bx + 10, 32, ACENTO)
    L.texto(bx, y, TX.get("total", "TOTAL"), 12, "B", (1, 1, 1))
    L.texto(x2 - 10, y, eur(d["total"]), 15, "B", (1, 1, 1), "der")
    y -= 36
    pago = d["pago"]
    L.texto(bx, y, TX.get("forma_pago", "Forma de pago"), 9, "R", SUAVE)
    L.texto(x2 - 10, y, pago["metodo"], 9, "M", TINTA, "der")
    if pago.get("entregado") is not None:
        y -= 14
        L.texto(bx, y, TX.get("entregado", "Entregado"), 9, "R", SUAVE)
        L.texto(x2 - 10, y, eur(pago["entregado"]), 9, "R", TINTA, "der")
        y -= 14
        L.texto(bx, y, TX.get("cambio", "Cambio"), 9, "R", SUAVE)
        L.texto(x2 - 10, y, eur(pago["cambio"]), 9, "R", TINTA, "der")

    # --- 4.2: notas (condiciones, forma de pago, IBAN…) bajo los totales, a la izquierda
    if d.get("notas") and mostrar("notas"):
        yn = y - 26
        partes = [l for t in d["notas"].splitlines() for l in (L.partir(t, x2 - M - 24, 9) if t.strip() else [""])]
        L.rect(M, yn - 13 * len(partes) + 4, x2 - M, 13 * len(partes) + 12, FONDO)
        L.rect(M, yn - 13 * len(partes) + 4, 3, 13 * len(partes) + 12, ACENTO)
        for t in partes:
            L.texto(M + 14, yn - 2, t, 9, "R")
            yn -= 13

    # --- VERI*FACTU: código QR para cotejar la factura en la AEAT
    if d.get("verifactu"):
        from .codigos import qr_matriz
        mat = qr_matriz(d["verifactu"]["url"])
        n = len(mat)
        lado = 82
        mod = lado / n
        x0, y0 = M, M + 70
        L.rect(x0 - 4, y0 - 4, lado + 8, lado + 8, (1, 1, 1))
        for fy, fila in enumerate(mat):
            for fx, v in enumerate(fila):
                if v:
                    L.rect(x0 + fx * mod, y0 + lado - (fy + 1) * mod, mod + 0.05, mod + 0.05, (0, 0, 0))
        L.texto(x0 + lado + 12, y0 + lado - 14, "VERI*FACTU", 11, "B")
        L.texto(x0 + lado + 12, y0 + lado - 30, "Factura verificable en la sede electrónica de la AEAT", 8.5, "R", SUAVE)
        L.texto(x0 + lado + 12, y0 + lado - 44, "Huella: " + d["verifactu"]["huella"][:32] + "…", 7, "R", SUAVE)

    # --- pie
    yp = M + 40
    for l in reversed([l for t in ((d.get("pie") or "") if mostrar("pie") else "").splitlines() for l in L.partir(t, x2 - M, 9)]):
        L.texto(W / 2, yp, l, 9, "R", SUAVE, "centro")
        yp += 13

    # --- 4.58: sello del garaje, abajo a la derecha (se reduce si no cabe; si apenas hay hueco, no se pone)
    if d.get("sello"):
        sl = d["sello"]
        libre = (min(y, yn - 14) if d.get("notas") and mostrar("notas") else y) - 14   # parte baja de lo ya escrito
        alto_max = min(95, libre - (yp + 6))
        if alto_max >= 30:
            esc_ = min(150 / sl["ancho"], alto_max / sl["alto"])
            w_, h_ = sl["ancho"] * esc_, sl["alto"] * esc_
            L.imagen(x2 - w_, yp + 6, w_, h_, sl)
    L.linea(M, M + 18, x2, M + 18)
    L.texto(M, M + 4, d.get("marca", ""), 7.5, "R", SUAVE)
    L.texto(x2, M + 4, f"Factura {d['numero']}", 7.5, "R", SUAVE, "der")
    return _ensamblar([L.contenido()], f"Factura {d['numero']}", L.imagenes)


# ------------------------------------------------------------------ listados (vehículos, abonados)
def listado_a_pdf(d):
    """Listado en tabla con varias páginas.
    d: titulo, subtitulo, empresa, columnas [(título, ancho relativo, 'izq'|'der')], filas [[texto]],
       resumen (texto), marca, horizontal (bool), logo (opcional)."""
    tam = (A4[1], A4[0]) if d.get("horizontal", True) else A4
    W, H = tam
    M = 36
    cols = d["columnas"]
    total_rel = sum(c[1] for c in cols)
    anchos = [(W - 2 * M) * c[1] / total_rel for c in cols]
    xs = [M + sum(anchos[:i]) for i in range(len(cols))]
    paginas, imagenes = [], []
    filas = d["filas"]
    alto_fila, tam_letra = 15, 8
    i, n_pag = 0, 0
    while True:
        L = Lienzo()
        n_pag += 1
        y = H - M
        if d.get("logo") and n_pag == 1:
            lg = d["logo"]
            esc = min(110 / lg["ancho"], 34 / lg["alto"])
            L.imagen(W - M - lg["ancho"] * esc, y - lg["alto"] * esc, lg["ancho"] * esc, lg["alto"] * esc, lg)
        L.texto(M, y - 14, d["titulo"], 15, "B")
        L.texto(M, y - 29, d.get("subtitulo", ""), 9, "R", SUAVE)
        if d.get("empresa"):
            L.texto(M, y - 42, d["empresa"], 8.5, "R", SUAVE)
        y -= 58
        # cabecera de la tabla
        L.rect(M, y - 5, W - 2 * M, 17, TINTA)
        for (titulo, _, alin), x, w in zip(cols, xs, anchos):
            L.texto(x + (w - 5 if alin == "der" else 5), y, titulo.upper(), 7, "B", (1, 1, 1), alin)
        y -= 18
        while i < len(filas) and y > M + 30:
            if i % 2:
                L.rect(M, y - 4, W - 2 * M, alto_fila, FONDO)
            for (_, _, alin), x, w, valor in zip(cols, xs, anchos, filas[i]):
                txt = str(valor if valor is not None else "")
                while txt and L.ancho(txt, tam_letra) > w - 8:
                    txt = txt[:-2] + "…" if len(txt) > 2 else ""
                L.texto(x + (w - 5 if alin == "der" else 5), y, txt, tam_letra, "R", TINTA, alin)
            y -= alto_fila
            i += 1
        if i >= len(filas) and d.get("resumen"):
            L.linea(M, y + 8, W - M, y + 8, LINEA)
            L.texto(M + 5, y - 6, d["resumen"], 8.5, "M")
        L.linea(M, M - 4, W - M, M - 4, LINEA, 0.6)
        L.texto(M, M - 16, d.get("marca", ""), 7, "R", SUAVE)
        L.texto(W - M, M - 16, f"Página {n_pag}", 7, "R", SUAVE, "der")
        paginas.append(L.contenido())
        imagenes += L.imagenes
        if i >= len(filas):
            break
    return _ensamblar(paginas, d["titulo"], imagenes, tam)


# ------------------------------------------------------------------ tarjeta del QR de fichaje (4.51; textos opcionales en 4.53)
def qr_ficha_a_pdf(matriz, parking, nombre, o=None):
    """Una hoja A5 con el QR personal de fichaje. o: opciones (parking, nombre, sup, inf, pie) para mostrar u ocultar los textos."""
    o = o or {"parking": True, "nombre": True, "sup": "", "inf": "Pase este código por el lector para fichar entrada o salida", "pie": ""}
    tam = (A4[0], A4[1] / 2.0)
    W, H = tam
    L = Lienzo()
    n = len(matriz)
    mod = min(7.5, 270.0 / (n + 8))
    lado = (n + 8) * mod
    y = H - 40
    if o.get("sup"):
        for ln in L.partir(o["sup"], W - 80, 11, "R"):
            L.texto(W / 2, y, ln, 11, "R", SUAVE, "centro")
            y -= 15
        y -= 6
    if o.get("parking"):
        L.texto(W / 2, y - 4, parking, 17, "B", TINTA, "centro")
        y -= 28
    x0, y0 = (W - lado) / 2, y - lado
    L.rect(x0, y0, lado, lado, (1, 1, 1))
    for fila in range(n):
        for col in range(n):
            if matriz[fila][col]:
                L.rect(x0 + (col + 4) * mod, y0 + (n - 1 - fila + 4) * mod, mod + 0.15, mod + 0.15, (0, 0, 0))
    y = y0 - 14
    if o.get("nombre"):
        L.texto(W / 2, y - 12, nombre, 20, "B", TINTA, "centro")
        y -= 32
    for txt, tam_l in ((o.get("inf"), 10), (o.get("pie"), 9)):
        if txt:
            for ln in L.partir(txt, W - 80, tam_l, "R"):
                L.texto(W / 2, y, ln, tam_l, "R", SUAVE, "centro")
                y -= tam_l + 5
            y -= 4
    return _ensamblar([L.contenido()], "QR de fichaje", L.imagenes, tam)
