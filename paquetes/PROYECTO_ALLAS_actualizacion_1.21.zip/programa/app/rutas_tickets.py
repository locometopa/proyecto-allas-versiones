"""PROYECTO ALLAS · rutas de la API: tickets, tarifas, reservas, plazas, descuentos, productos, barrera, datáfono y lista negra (se registran desde server.App._registrar)."""
import secrets
import time
from .servicios import ErrorNegocio
from .servicios import ROLES_SUPERVISION


def registrar(app, r, p):
    from .server import Respuesta


    # --- tickets
    @r("POST", "/api/tickets")
    def emitir(req):
        aut, autorizado = req.body.get("autorizacion"), None
        if aut and req.usuario["rol"] not in ROLES_SUPERVISION:   # 4.1: lista negra en modo «bloquear»
            autorizado = p.autenticar(aut.get("usuario", ""), aut.get("pin", ""), req.ip)
        return p.emitir_ticket(req.usuario, req.body.get("matricula"), req.body.get("tarifa_id"),
                               bool(req.body.get("forzar_ticket")), req.body.get("ajuste_min") or 0,
                               bool(req.body.get("lista_negra_ok")), autorizado, req.body.get("reserva"),
                               req.body.get("tipo_vehiculo"), req.body.get("zona_id"), req.body.get("digital"),
                               bool(req.body.get("llaves")))

    @r("POST", r"/api/tickets/(\d+)/reserva")
    def ticket_reserva(req, tid):   # 4.2: reserva / hotel en un ticket que ya está dentro
        return p.aplicar_reserva(req.usuario, int(tid), req.body)

    # ================================================================ 4.3
    # --- reservas de plataformas
    @r("GET", "/api/reservas-previstas")
    def reservas_previstas(req):
        q = req.query
        return p.reservas_previstas(q.get("desde"), q.get("hasta"), q.get("estado", ""), q.get("buscar", ""))

    @r("POST", "/api/reservas-previstas")
    def reserva_prevista_nueva(req):
        return p.guardar_reserva_prevista(req.usuario, req.body)

    @r("PUT", r"/api/reservas-previstas/(\d+)")
    def reserva_prevista_editar(req, rid):
        return p.guardar_reserva_prevista(req.usuario, req.body, int(rid))

    @r("DELETE", r"/api/reservas-previstas/(\d+)")
    def reserva_prevista_cancelar(req, rid):
        return p.cancelar_reserva_prevista(req.usuario, int(rid))

    @r("POST", "/api/reservas-previstas/leer", crudo=True)
    def reservas_leer(req):
        p._exigir_permiso(req.usuario, "reservas")
        nombre = req.query.get("nombre", "")
        r = p.leer_listado_reservas(req.raw, nombre)
        token = secrets.token_hex(8)
        with app._lock:
            app.listados = {k: x for k, x in getattr(app, "listados", {}).items() if time.time() - x[2] < 3600}
            app.listados[token] = (req.raw, nombre, time.time())
        return {**r, "token": token}

    @r("POST", "/api/reservas-previstas/importar")
    def reservas_importar(req):
        b = req.body
        datos = getattr(app, "listados", {}).get(b.get("token") or "")
        if not datos:
            raise ErrorNegocio("Vuelva a elegir el archivo (la lectura ha caducado)")
        return p.importar_reservas(req.usuario, datos[0], datos[1], b.get("mapeo") or {}, b.get("plataforma") or "",
                                   b.get("tarifa_id"), bool(b.get("aplicar")))

    # --- zonas
    @r("GET", "/api/zonas")
    def zonas(req):
        return {"zonas": p.zonas(todas=True), "ocupacion": p.ocupacion_zonas(),
                "plazas_abonados": int(p.cfg("plazas_abonados") or 0), "capacidad": int(p.cfg("capacidad") or 0)}

    @r("POST", "/api/zonas", rol=("admin",))
    def zona_nueva(req):
        return p.guardar_zona(req.usuario["id"], req.body)

    @r("PUT", r"/api/zonas/(\d+)", rol=("admin",))
    def zona_editar(req, zid):
        return p.guardar_zona(req.usuario["id"], req.body, int(zid))

    @r("DELETE", r"/api/zonas/(\d+)", rol=("admin",))
    def zona_borrar(req, zid):
        return p.borrar_zona(req.usuario["id"], int(zid))

    # --- estado del vehículo al entrar (notas y fotos) y ticket digital
    @r("GET", r"/api/tickets/(\d+)/estado")
    def estado_veh(req, tid):
        return p.estado_vehiculo(int(tid))

    @r("PUT", r"/api/tickets/(\d+)/estado")
    def estado_veh_nota(req, tid):
        return p.guardar_estado_vehiculo(req.usuario, int(tid), req.body.get("nota"))

    @r("POST", r"/api/tickets/(\d+)/fotos", crudo=True)
    def estado_veh_foto(req, tid):
        return p.anadir_foto_ticket(req.usuario, int(tid), req.raw)

    @r("GET", r"/api/tickets/(\d+)/fotos/(\d+)")
    def estado_veh_foto_ver(req, tid, fid):
        return Respuesta(p.foto_ticket(int(tid), int(fid)), "image/jpeg", {"Cache-Control": "private, max-age=86400"})

    @r("POST", r"/api/tickets/(\d+)/digital")
    def ticket_digital(req, tid):
        return p.enviar_ticket_digital(req.usuario, p.ticket(int(tid)), req.body.get("telefono"), req.body.get("canal") or "sms")

    # --- 4.1: lista negra de matrículas
    @r("GET", "/api/lista-negra")
    def lista_negra(req):
        return {"modo": p.lista_negra_modo(),
                "filas": p.lista_negra(req.query.get("buscar", ""), req.query.get("todas") == "1")}

    @r("GET", "/api/lista-negra/comprobar")
    def lista_negra_comprobar(req):
        return {"lista_negra": p.en_lista_negra(req.query.get("matricula"))}

    @r("POST", "/api/lista-negra", rol=("admin", "supervisor"))
    def lista_negra_alta(req):
        return p.agregar_lista_negra(req.usuario, req.body.get("matricula"), req.body.get("motivo"), req.body.get("nota"))

    @r("PUT", r"/api/lista-negra/(\d+)", rol=("admin", "supervisor"))
    def lista_negra_editar(req, lid):
        return p.editar_lista_negra(req.usuario, int(lid), req.body.get("motivo"), req.body.get("nota"))

    @r("DELETE", r"/api/lista-negra/(\d+)", rol=("admin", "supervisor"))
    def lista_negra_baja(req, lid):
        return p.quitar_lista_negra(req.usuario, int(lid))

    @r("GET", "/api/tickets/consultar")
    def consultar(req):
        perdido = req.query.get("perdido") == "1"
        if req.query.get("id"):
            return p.consultar(ticket_id=int(req.query["id"]), perdido=perdido)
        return p.consultar(codigo=req.query.get("codigo", ""), perdido=perdido)

    @r("POST", r"/api/tickets/(\d+)/cobrar")
    def cobrar(req, tid):
        b = req.body
        res = p.cobrar(req.usuario, int(tid), b.get("metodo"), b.get("entregado_cent"),
                       bool(b.get("perdido")), b.get("calculo_en"), b.get("descuento_id"), b.get("imprimir"))
        p.anotar_referencia_pago((res.get("pago") or {}).get("id"), b.get("datafono_ref"))
        return res

    # --- 3.9: barrera y datáfono (opcionales)
    @r("POST", "/api/barrera/abrir")
    def barrera_abrir(req):
        r = p.abrir_barrera("manual", req.usuario, (req.body.get("motivo") or "").strip()[:120], esperar=True)
        if r is None:
            raise ErrorNegocio("La barrera no está activada (Ajustes → Equipos → Barrera)")
        return {"ok": True, "resultado": r}

    @r("POST", "/api/datafono/cobrar")
    def datafono_cobrar(req):
        return p.cobrar_datafono(req.usuario, req.body.get("importe_cent"), req.body.get("referencia"))

    @r("GET", "/api/productos")
    def productos(req):
        return p.productos(req.query.get("activos") == "1")

    @r("POST", "/api/productos", rol=("admin",))
    def producto_nuevo(req):
        return {"id": p.guardar_producto(req.body, req.usuario["id"])}

    @r("PUT", r"/api/productos/(\d+)", rol=("admin",))
    def producto_editar(req, pid):
        return {"id": p.guardar_producto(req.body, req.usuario["id"], int(pid))}

    @r("DELETE", r"/api/productos/(\d+)", rol=("admin",))
    def producto_eliminar(req, pid):
        return p.eliminar_producto(int(pid), req.usuario["id"])

    # --- 3.1: fotos de productos
    @r("GET", r"/api/productos/(\d+)/foto")
    def producto_foto(req, pid):
        datos, tipo = p.foto_producto(int(pid))
        return Respuesta(datos, tipo, {"Cache-Control": "private, max-age=86400"})

    @r("POST", r"/api/productos/(\d+)/foto", rol=("admin",), crudo=True)
    def producto_foto_subir(req, pid):
        return p.guardar_foto_producto(int(pid), req.raw, req.usuario["id"])

    @r("DELETE", r"/api/productos/(\d+)/foto", rol=("admin",))
    def producto_foto_quitar(req, pid):
        return p.quitar_foto_producto(int(pid), req.usuario["id"])

    # --- 3.1: descuentos
    @r("GET", "/api/descuentos")
    def descuentos(req):
        return {"activo": p.descuentos_activos(),
                "descuentos": p.descuentos(req.query.get("activos") == "1", req.query.get("ambito") or None)}

    @r("POST", "/api/descuentos", rol=("admin",))
    def descuento_nuevo(req):
        return {"id": p.guardar_descuento(req.body, req.usuario["id"])}

    @r("PUT", r"/api/descuentos/(\d+)", rol=("admin",))
    def descuento_editar(req, did):
        return {"id": p.guardar_descuento(req.body, req.usuario["id"], int(did))}

    # --- 3.2: códigos de descuento y vales
    @r("GET", "/api/descuentos/codigo")
    def descuento_codigo(req):
        return p.descuento_por_codigo(req.query.get("codigo", ""), req.query.get("ambito") or "tienda")[0]

    @r("POST", r"/api/tickets/(\d+)/descuento")
    def ticket_descuento(req, tid):
        b = req.body
        return p.descuento_ticket(int(tid), b.get("codigo", ""), b.get("calculo_en"), bool(b.get("perdido")))

    @r("GET", "/api/vales", rol=ROLES_SUPERVISION)
    def vales(req):
        return p.vales(req.query.get("buscar", ""), req.query.get("estado", ""))

    @r("POST", "/api/vales", rol=ROLES_SUPERVISION)
    def vales_generar(req):
        b = req.body
        return p.generar_vales(req.usuario, b.get("descuento_id"), b.get("cantidad", 1), b.get("usos_max", 1),
                               b.get("caduca"), b.get("nota"), b.get("imprimir", True) is not False)

    @r("POST", "/api/vales/imprimir", rol=ROLES_SUPERVISION)
    def vales_imprimir(req):
        ids = [int(i) for i in (req.body.get("ids") or [])][:200]
        if not ids:
            raise ErrorNegocio("Elija los vales que quiere imprimir")
        return p.imprimir_vales(ids)

    @r("POST", r"/api/vales/(\d+)/anular", rol=ROLES_SUPERVISION)
    def vale_anular(req, vid):
        return p.anular_vale(req.usuario, int(vid), req.body.get("motivo", ""))

    @r("DELETE", r"/api/descuentos/(\d+)", rol=("admin",))
    def descuento_eliminar(req, did):
        return p.eliminar_descuento(int(did), req.usuario["id"])

    @r("POST", r"/api/tickets/(\d+)/matricula")
    def ticket_matricula(req, tid):
        return p.cambiar_matricula(req.usuario, int(tid), req.body.get("matricula"))

    @r("POST", r"/api/tickets/(\d+)/tarifa")
    def ticket_tarifa(req, tid):
        return p.cambiar_tarifa(req.usuario, int(tid), req.body.get("tarifa_id"))

    @r("POST", r"/api/tickets/(\d+)/extras")
    def extra_anadir(req, tid):
        if req.body.get("personalizado"):   # 4.31: servicio libre solo para esta venta
            return p.anadir_extra_personalizado(req.usuario, int(tid), req.body["personalizado"], req.body.get("cantidad", 1))
        return p.anadir_extra(req.usuario, int(tid), int(req.body.get("producto_id") or 0), req.body.get("cantidad", 1),
                             req.body.get("precio_cent"))

    @r("POST", r"/api/extras/(\d+)/cantidad")
    def extra_cantidad(req, eid):
        return p.cambiar_extra(req.usuario, int(eid), req.body.get("cantidad", 0))

    @r("POST", "/api/tickets/manual/calcular")
    def manual_calcular(req):
        b = req.body
        return p.calcular_manual(b.get("entrada"), b.get("salida"), b.get("tarifa_id"), b.get("extras"))

    @r("POST", "/api/tickets/manual")
    def manual(req):
        return p.ticket_manual(req.usuario, req.body)

    @r("POST", r"/api/tickets/(\d+)/salida")
    def salida(req, tid):
        return p.registrar_salida(req.usuario, int(tid))

    @r("POST", r"/api/tickets/(\d+)/anular")
    def anular(req, tid):
        # Un cajero puede anular si un supervisor introduce su PIN en ese momento.
        actor = req.usuario
        aut = req.body.get("autorizacion")
        if actor["rol"] not in ROLES_SUPERVISION and aut:
            actor = p.autenticar(aut.get("usuario", ""), aut.get("pin", ""), req.ip)
        return p.anular_ticket(actor, int(tid), req.body.get("motivo", ""))

    @r("POST", r"/api/tickets/(\d+)/reimprimir")
    def reimprimir(req, tid):
        return p.reimprimir(req.usuario, int(tid))

    @r("GET", "/api/dentro")
    def dentro(req):
        return p.vehiculos_dentro(req.query.get("buscar", ""))

    # --- tarifas
    @r("GET", "/api/tarifas/actual")
    def tarifa_actual(req):   # 3.9: la que se aplicaría ahora a una entrada (por horario o la de por defecto)
        t = p.tarifa_para(None, req.query.get("tipo") or None)   # 4.3: según el tipo de vehículo
        return {"id": t["id"], "nombre": t["nombre"], "por_horario": bool(t.get("horario_dias") or t.get("horario_desde"))} if t else {}

    @r("GET", "/api/tarifas")
    def tarifas(req):
        return p.tarifas()

    @r("POST", "/api/tarifas", rol=("admin",))
    def tarifa_nueva(req):
        return {"id": p.guardar_tarifa(req.body, req.usuario["id"])}

    @r("POST", "/api/tarifas/orden", rol=("admin",))
    def tarifas_orden(req):
        return p.ordenar_tarifas(req.body.get("ids") or [], req.usuario["id"])

    @r("PUT", r"/api/tarifas/(\d+)", rol=("admin",))
    def tarifa_editar(req, tid):
        return {"id": p.guardar_tarifa(req.body, req.usuario["id"], int(tid))}

    # --- tienda
    @r("POST", "/api/tienda/venta")
    def tienda_venta(req):
        b = req.body
        res = p.vender_tienda(req.usuario, b.get("lineas") or [], b.get("metodo"), b.get("entregado_cent"),
                              b.get("descuento_id"))
        p.anotar_referencia_pago((res.get("pago") or {}).get("id"), b.get("datafono_ref"))
        return res

    @r("GET", "/api/tienda/ventas")
    def tienda_ventas(req):
        hoy = p.ahora().date().isoformat()
        return p.ventas_tienda(req.query.get("desde") or hoy, req.query.get("hasta") or hoy,
                               req.query.get("buscar", ""))

    # --- lector de matrículas por cámara (preparado). Las cámaras se autentican con su propio token.
    @r("POST", "/api/lpr/lectura", publica=True)
    def lpr_lectura(req):
        tok = req.headers_camara
        if not tok or not secrets.compare_digest(tok, p.cfg("lpr_token") or "-"):
            if not req.usuario:
                raise ErrorNegocio("Token de cámara no válido", 401)
        b = req.body
        return p.lpr_lectura(b.get("camara"), b.get("matricula") or b.get("plate"), b.get("confianza"),
                             b.get("origen") or ("prueba" if req.usuario else "camara"))

    @r("GET", "/api/lpr/ultimas")
    def lpr_ultimas(req):
        return p.lpr_ultimas(req.query.get("desde", 0), req.query.get("camara"))

    @r("GET", "/api/lpr/config", rol=("admin",))
    def lpr_config(req):
        return {"token": p.cfg("lpr_token"), "activo": p.cfg("lpr_activo") == "1"}

    @r("DELETE", r"/api/tarifas/(\d+)", rol=("admin",))
    def tarifa_eliminar(req, tid):
        return p.eliminar_tarifa(int(tid), req.usuario["id"])

    @r("GET", r"/api/tarifas/(\d+)/simular")
    def simular(req, tid):
        return {"importe_cent": p.simular(int(tid), int(req.query.get("minutos", 0)))}
