"""PROYECTO ALLAS · lógica de negocio: licencia, módulos contratados y comprobación en línea (1.4: sale de servicios.py; se mezcla en la clase Parking)."""
import json
import re
from datetime import date, timedelta

from . import errores
from .utiles import ErrorNegocio, iso, parse


class SvcLicencia:
    # ============================================================ licencia
    def estado_licencia(self):
        from . import FECHA_VERSION
        from .licencia import IDS_MODULOS, estado
        from .licencia_clave import CLAVE_PUBLICA
        if self.demo:
            base = {"estado": "demo", "puede_operar": True, "dias_restantes": None, "plan": "completo",
                    "plan_nombre": "Demostración (todos los módulos)", "modulos": list(IDS_MODULOS), "serial": None,
                    "id_equipo": "", "mensaje": "Modo demostración: datos de ejemplo, sin validez. Sus datos reales no se tocan."}
            if self.licencia_real is not None:
                # la demo dura lo mismo que la licencia o la prueba del programa
                serial, instalado = self.licencia_real[:2]
                comprobante = self.licencia_real[2] if len(self.licencia_real) > 2 else None
                real = estado(serial, bytes.fromhex(CLAVE_PUBLICA), instalado, self.ahora().date(), date.fromisoformat(FECHA_VERSION),
                              comprobante=comprobante)
                base.update({"puede_operar": real["puede_operar"], "dias_restantes": real.get("dias_restantes"),
                             "caduca": real.get("caduca"), "licencia_real": real.get("estado")})
                if not real["puede_operar"]:
                    base["mensaje"] = "Demostración caducada: " + real["mensaje"]
                elif real.get("estado") == "prueba":
                    base["mensaje"] = f"Modo demostración · versión de prueba: quedan {real.get('dias_restantes')} días."
                elif real.get("caduca"):
                    base["mensaje"] = f"Modo demostración · disponible mientras su licencia esté vigente (hasta el {real['caduca']})."
            return base
        args = (self.cfg("licencia_serial"), bytes.fromhex(CLAVE_PUBLICA), self.cfg("fecha_instalacion"))
        e = estado(*args, self.ahora().date(), date.fromisoformat(FECHA_VERSION), comprobante=self.cfg("licencia_comprobante"))
        if e.get("comprobacion"):
            hoy = self._hoy_licencia()
            if hoy != self.ahora().date():
                e = estado(*args, hoy, date.fromisoformat(FECHA_VERSION), comprobante=self.cfg("licencia_comprobante"))
        if e.get("comprobacion"):
            c = e["comprobacion"]
            c["servidor"] = self.cfg("licencia_servidor") or c.get("url") or ""
            c["servidor_propio"] = bool(self.cfg("licencia_servidor"))
            c["ultimo_intento"] = self.cfg("licencia_ultimo_intento")
            c["ultimo_error"] = self.cfg("licencia_ultimo_error") or None
            c["comprobado_el"] = self.cfg("licencia_comprobado_el")
        return e

    def _hoy_licencia(self):
        """Fecha para las licencias con comprobación: nunca anterior a la mayor ya vista, así atrasar el reloj del PC
        no alarga los plazos. Cada comprobante nuevo la vuelve a fijar en la fecha del servidor (corrige un reloj adelantado)."""
        hoy = self.ahora().date()
        try:
            maxima = date.fromisoformat(self.cfg("licencia_fecha_maxima") or "2000-01-01")
        except ValueError:
            maxima = date(2000, 1, 1)
        if hoy > maxima:
            self.db.set_cfg("licencia_fecha_maxima", hoy.isoformat())
            return hoy
        return maxima if (maxima - hoy).days > 1 else hoy   # un día de margen por zonas horarias

    # ------------------------------------------------------------ comprobación periódica de la licencia (3.8)
    def comprobar_licencia_online(self, actor_id=None):
        """Pregunta al servidor de licencias del distribuidor y guarda el comprobante firmado que devuelve."""
        import urllib.error
        import urllib.request
        from . import __version__
        from .licencia import ErrorLicencia, id_equipo, id_equipo_bytes, leer, leer_comprobante
        from .licencia_clave import CLAVE_PUBLICA
        if self.demo:
            raise ErrorNegocio("En la demostración no se comprueba la licencia: salga de ella (Volver a mis datos).", 409)
        serial = self.cfg("licencia_serial")
        if not serial:
            raise ErrorNegocio("No hay ninguna licencia activada")
        try:
            lic = leer(serial, bytes.fromhex(CLAVE_PUBLICA))
        except ErrorLicencia as e:
            raise ErrorNegocio(str(e))
        url = (self.cfg("licencia_servidor") or lic.get("url") or "").strip().rstrip("/")
        if not url:
            raise ErrorNegocio("No hay servidor de comprobación: pida a su distribuidor la dirección o un código de validación.")
        if not url.startswith(("http://", "https://")):
            url = "http://" + url
        self.db.set_cfg("licencia_ultimo_intento", iso(self.ahora()))
        cuerpo = json.dumps({"numero": lic["numero"], "serial": " ".join(serial.split()), "equipo": id_equipo(),
                             "version": __version__, "parking": self.cfg("nombre_parking") or "",
                             "fabricante_fecha": self.datos_fabricante().get("fecha") or ""}).encode()
        req = urllib.request.Request(url + "/comprobar", data=cuerpo, method="POST",
                                     headers={"Content-Type": "application/json", "User-Agent": f"PROYECTO-ALLAS/{__version__}"})
        try:
            try:
                with urllib.request.urlopen(req, timeout=12) as r:
                    resp = json.loads(r.read() or b"{}")
            except urllib.error.HTTPError as e:
                try:
                    resp = json.loads(e.read() or b"{}")
                except ValueError:
                    resp = {}
                if not resp.get("comprobante"):
                    raise ErrorNegocio("El servidor de licencias responde: " + (resp.get("error") or f"error {e.code}"))
            except (urllib.error.URLError, OSError, ValueError) as e:
                motivo = getattr(e, "reason", None) or e
                raise ErrorNegocio(f"No se puede conectar con el servidor de licencias ({url}): {motivo}")
            try:
                comp = leer_comprobante(resp.get("comprobante"), bytes.fromhex(CLAVE_PUBLICA), id_equipo_bytes())
            except ErrorLicencia as e:
                raise ErrorNegocio("Respuesta del servidor de licencias no válida: " + str(e))
            if comp["numero"] != lic["numero"]:
                raise ErrorNegocio("El servidor de licencias ha respondido por otra licencia")
        except ErrorNegocio as e:
            self.db.set_cfg("licencia_ultimo_error", str(e))
            raise
        self._guardar_comprobante(resp["comprobante"], actor_id, "online")
        if resp.get("fabricante"):   # 4.1: el servidor también manda los datos del fabricante (firmados)
            try:
                self.guardar_fabricante(None, resp["fabricante"] if isinstance(resp["fabricante"], str)
                                        else json.dumps(resp["fabricante"]), "servidor")
            except ErrorNegocio:
                pass
        return self.estado_licencia()

    def validar_codigo_licencia(self, actor_id, codigo):
        """Código de validación que da el distribuidor cuando el PC no tiene Internet."""
        from .licencia import ErrorLicencia, leer, leer_comprobante
        from .licencia_clave import CLAVE_PUBLICA
        if self.demo:
            raise ErrorNegocio("Está en la demostración: salga de ella (Volver a mis datos) para validar la licencia.", 409)
        serial = self.cfg("licencia_serial")
        if not serial:
            raise ErrorNegocio("Active primero la licencia")
        try:
            comp = leer_comprobante(codigo, bytes.fromhex(CLAVE_PUBLICA))
            lic = leer(serial, bytes.fromhex(CLAVE_PUBLICA))
        except ErrorLicencia as e:
            raise ErrorNegocio(str(e))
        if comp["numero"] != lic["numero"]:
            raise ErrorNegocio(f"Ese código es de la licencia nº {comp['numero']} y aquí está activada la nº {lic['numero']}")
        if comp["fecha"] > self.ahora().date() + timedelta(days=1):
            raise ErrorNegocio("El código de validación tiene una fecha posterior a la de este PC. Revise la fecha y hora de Windows.")
        self._guardar_comprobante(" ".join(codigo.split()), actor_id, "codigo")
        return self.estado_licencia()

    def _guardar_comprobante(self, texto, actor_id, via):
        from .licencia import leer_comprobante
        from .licencia_clave import CLAVE_PUBLICA
        nuevo = leer_comprobante(texto, bytes.fromhex(CLAVE_PUBLICA))
        actual = self.cfg("licencia_comprobante")
        if actual:
            try:
                previo = leer_comprobante(actual, bytes.fromhex(CLAVE_PUBLICA))
                if previo["numero"] == nuevo["numero"] and previo["fecha"] > nuevo["fecha"]:
                    return   # ya hay uno más reciente
            except Exception as e_:  # noqa: BLE001
                errores.fallo("servicios._guardar_comprobante", e_, grave=True)
        with self.db.transaccion() as c:
            for k, v in (("licencia_comprobante", texto), ("licencia_comprobado_el", iso(self.ahora())),
                         ("licencia_ultimo_error", ""), ("licencia_fecha_maxima", nuevo["fecha"].isoformat())):
                c.execute("INSERT INTO config(clave, valor) VALUES(?,?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor", (k, v))
            self.auditar(c, actor_id, "licencia_comprobada",
                         f"{via} nº {nuevo['numero']} {nuevo['fecha'].isoformat()} {nuevo['estado']}")

    def comprobacion_automatica(self):
        """Desde la tarea periódica: pregunta al servidor cada 12 h (cada hora si ya toca o está bloqueada)."""
        if self.demo or not self.cfg("licencia_serial"):
            return None
        e = self.estado_licencia()
        c = e.get("comprobacion")
        if not c or not c.get("servidor"):
            return None
        urgente = c.get("pendiente") or not e.get("puede_operar")
        try:
            ultimo = parse(self.cfg("licencia_ultimo_intento")) if self.cfg("licencia_ultimo_intento") else None
        except ValueError:
            ultimo = None
        if ultimo and self.ahora() - ultimo < timedelta(hours=1 if urgente else 12):
            return None
        try:
            self.comprobar_licencia_online()
            return "ok"
        except ErrorNegocio as err:
            return str(err)

    # ------------------------------------------------------------ módulos (3.0)
    def modulos_activos(self):
        """Módulos que incluye la licencia (prueba y licencias anteriores a la 3.0: todos), recortados al tipo
        de licencia elegido en Supervisión (4.8). Se guarda en memoria por serial y día, porque comprobar la firma cuesta."""
        plan = None if self.demo else self.plan_supervision()
        clave = (self.cfg("licencia_serial"), self.cfg("fecha_instalacion"), self.ahora().date(), plan)
        cache = getattr(self, "_cache_modulos", None)
        if not cache or cache[0] != clave:
            mods = list(self.estado_licencia().get("modulos") or [])
            if plan:
                from .licencia import PLANES
                mods = [m for m in mods if m in PLANES[plan]["modulos"]]
            cache = (clave, mods)
            self._cache_modulos = cache
        return cache[1]

    def tipo_licencia_info(self):
        """Tipo de licencia junto a la versión: nombre corto (Lite, Básico, Abonados…, Prueba, Demostración) y su color (#rrggbb)."""
        from .licencia import COLOR_TIPO, PLANES
        e = self.estado_licencia()
        if e.get("estado") == "demo":
            return "Demostración", COLOR_TIPO["demo"]
        limitada = self.plan_supervision()   # 4.8: tipo elegido en Supervisión
        if e.get("estado") in ("prueba", "prueba_caducada"):
            return (f"{PLANES[limitada]['nombre']} (prueba)", PLANES[limitada]["color"]) if limitada else ("Prueba", COLOR_TIPO["prueba"])
        if limitada and e.get("serial"):
            return PLANES[limitada]["nombre"], PLANES[limitada]["color"]
        if not e.get("serial"):
            return "Sin licencia", COLOR_TIPO["sin_licencia"]
        plan = e.get("plan")
        if plan in PLANES:
            return PLANES[plan]["nombre"], PLANES[plan]["color"]
        return ("Personalizada", COLOR_TIPO["personalizada"]) if plan else ("Sin licencia", COLOR_TIPO["sin_licencia"])

    def tipo_licencia(self):
        """Nombre corto del tipo de licencia (junto a la versión)."""
        return self.tipo_licencia_info()[0]

    def tiene_modulo(self, modulo):
        return modulo in self.modulos_activos()

    def exigir_modulo(self, modulo):
        if not self.tiene_modulo(modulo):
            from .licencia import NOMBRE_MODULO
            raise ErrorNegocio(f"El módulo «{NOMBRE_MODULO.get(modulo, modulo)}» no está incluido en su licencia "
                               "(Ajustes → Sistema → Licencia).", 403)

    def activo(self, clave_cfg, modulo):
        """Una función opcional está en marcha si está activada en Ajustes Y su módulo está en la licencia."""
        return self.cfg(clave_cfg) == "1" and self.tiene_modulo(modulo)

    def _exigir_licencia(self):
        e = self.estado_licencia()
        if not e["puede_operar"]:
            raise ErrorNegocio(e["mensaje"] + " (Ajustes → Licencia)", 402)

    def activar_licencia(self, actor_id, serial):
        if self.demo:
            raise ErrorNegocio("Está en la demostración: salga de ella (Volver a mis datos) para activar la licencia.", 409)
        from . import FECHA_VERSION
        from .licencia import estado
        from .licencia_clave import CLAVE_PUBLICA
        texto = serial or ""
        fab = re.search(r"-----DATOS DEL FABRICANTE-----\s*(\{.*\})\s*-----FIN DATOS DEL FABRICANTE-----", texto, re.S)
        if fab or "\n" in texto.strip():   # 4.2: se ha pegado o cargado el archivo .lic completo
            m = re.search(r"ALLAS(?:-[A-Z2-7]{1,5})+", texto.replace("\r", ""))
            serial = m.group(0) if m else texto
        serial = " ".join((serial or "").split())
        if not serial:
            raise ErrorNegocio("Pegue el serial de la licencia")
        e = estado(serial, bytes.fromhex(CLAVE_PUBLICA), self.cfg("fecha_instalacion"), self.ahora().date(),
                   date.fromisoformat(FECHA_VERSION))
        if e["estado"] in ("invalida", "otro_equipo", "caducada"):
            raise ErrorNegocio(e["mensaje"])
        with self.db.transaccion() as c:
            c.execute("INSERT INTO config(clave, valor) VALUES('licencia_serial', ?) "
                      "ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor", (serial,))
            self.auditar(c, actor_id, "licencia_activar", f"nº {e.get('numero')} {e.get('titular')} ({e['estado']})")
        if fab:
            try:
                self.guardar_fabricante(actor_id, fab.group(1), "licencia")
            except ErrorNegocio:
                pass
        if e.get("comprobacion"):   # 3.8: licencia con comprobación periódica → se intenta ya (si no hay Internet, sigue el plazo)
            try:
                self.comprobar_licencia_online(actor_id)
            except ErrorNegocio:
                pass
        return self.estado_licencia()

    def quitar_licencia(self, actor_id):
        with self.db.transaccion() as c:
            c.execute("DELETE FROM config WHERE clave IN ('licencia_serial', 'licencia_comprobante', 'licencia_ultimo_error')")
            self.auditar(c, actor_id, "licencia_quitar", "")
        return self.estado_licencia()
