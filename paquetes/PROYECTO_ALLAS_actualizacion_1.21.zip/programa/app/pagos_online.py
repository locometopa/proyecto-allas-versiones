"""Cobro online de suscripciones de abonados con Stripe (cargo automático con tarjeta).

Cómo funciona, sin necesidad de abrir puertos ni tener una web propia:
  1. Por cada tipo de bono se crea en Stripe un producto, un precio recurrente (cada N meses)
     y un «enlace de pago» (Payment Link) que muestra una confirmación al terminar.
  2. Al abonado se le envía su enlace personal: el mismo enlace del plan con su referencia
     (client_reference_id = CL<id>) y su email ya escrito.
  3. El programa consulta Stripe cada pocos minutos (no hace falta que Stripe le avise):
     nuevas suscripciones, facturas pagadas (=> se renueva el bono y se emite la factura
     simplificada) y facturas impagadas (=> se avisa al abonado con el enlace para pagarla).

Solo usa la biblioteca estándar (urllib). La clave secreta de Stripe se guarda en la base de datos.
"""
import base64
import json
import re
import urllib.error
import urllib.parse
import urllib.request

API = "https://api.stripe.com"


class ErrorPago(Exception):
    pass


def _aplanar(datos, prefijo=""):
    """{'a': {'b': 1}, 'c': [{'d': 2}]} -> [('a[b]', '1'), ('c[0][d]', '2')] (formato de Stripe)."""
    salida = []
    if isinstance(datos, dict):
        for k, v in datos.items():
            salida += _aplanar(v, f"{prefijo}[{k}]" if prefijo else k)
    elif isinstance(datos, (list, tuple)):
        for i, v in enumerate(datos):
            salida += _aplanar(v, f"{prefijo}[{i}]")
    elif datos is not None:
        salida.append((prefijo, "true" if datos is True else "false" if datos is False else str(datos)))
    return salida


class Stripe:
    def __init__(self, clave, base=None, timeout=20):
        clave = (clave or "").strip()
        if not re.match(r"^(sk|rk)_(test|live)_[A-Za-z0-9]+$", clave):
            raise ErrorPago("La clave de Stripe no es válida: debe empezar por sk_live_, sk_test_, rk_live_ o rk_test_")
        self.clave = clave
        self.base = (base or API).rstrip("/")
        self.timeout = timeout
        self.prueba = "_test_" in clave

    def _req(self, metodo, ruta, datos=None):
        url = self.base + ruta
        cuerpo = None
        if datos:
            q = urllib.parse.urlencode(_aplanar(datos))
            if metodo == "GET":
                url += ("&" if "?" in url else "?") + q
            else:
                cuerpo = q.encode()
        req = urllib.request.Request(url, data=cuerpo, method=metodo, headers={
            "Authorization": "Basic " + base64.b64encode((self.clave + ":").encode()).decode(),
            "Content-Type": "application/x-www-form-urlencoded",
        })
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                return json.loads(r.read() or b"{}")
        except urllib.error.HTTPError as e:
            try:
                msg = json.loads(e.read())["error"].get("message")
            except Exception:  # noqa: BLE001
                msg = None
            if e.code == 401:
                raise ErrorPago("Stripe rechaza la clave secreta (revise que esté bien copiada y activa)")
            raise ErrorPago(f"Stripe: {msg or e.reason} ({e.code})")
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            raise ErrorPago(f"No hay conexión con Stripe ({getattr(e, 'reason', e)}). Se reintentará más tarde.")

    def _todos(self, ruta, params, maximo=1000):
        """Recorre las páginas de un listado de Stripe."""
        salida, params = [], dict(params, limit=100)
        while len(salida) < maximo:
            r = self._req("GET", ruta, params)
            salida += r.get("data", [])
            if not r.get("has_more") or not r.get("data"):
                break
            params["starting_after"] = r["data"][-1]["id"]
        return salida

    # --- cuenta
    def cuenta(self):
        a = self._req("GET", "/v1/account")
        nombre = (a.get("settings", {}).get("dashboard", {}).get("display_name")
                  or a.get("business_profile", {}).get("name") or a.get("email") or a.get("id"))
        return {"id": a.get("id"), "nombre": nombre, "prueba": self.prueba,
                "cobros_activos": a.get("charges_enabled", True)}

    # --- planes
    def crear_enlace_plan(self, plan, ref_producto=None, mensaje=""):
        """Crea (o rehace si cambió el precio) producto, precio recurrente y enlace de pago de un tipo de bono."""
        if not ref_producto:
            ref_producto = self._req("POST", "/v1/products", {
                "name": f"Bono {plan['nombre']}", "metadata": {"plan_id": plan["id"], "origen": "PROYECTO ALLAS"}})["id"]
        precio = self._req("POST", "/v1/prices", {
            "product": ref_producto, "currency": "eur", "unit_amount": plan["precio_cent"],
            "recurring": {"interval": "month", "interval_count": plan["meses"]},
            "metadata": {"plan_id": plan["id"]}})
        enlace = self._req("POST", "/v1/payment_links", {
            "line_items": [{"price": precio["id"], "quantity": 1}],
            "after_completion": {"type": "hosted_confirmation", "hosted_confirmation": {
                "custom_message": mensaje or "Suscripción realizada. Su bono se renovará automáticamente en cada periodo."}},
            "metadata": {"plan_id": plan["id"], "origen": "PROYECTO ALLAS"},
            "subscription_data": {"metadata": {"plan_id": plan["id"]}}})
        # enlace de pago único (sin suscripción) para pagar renovaciones pendientes
        unico = self._req("POST", "/v1/prices", {"product": ref_producto, "currency": "eur",
                                                 "unit_amount": plan["precio_cent"], "metadata": {"plan_id": plan["id"]}})
        enlace_u = self._req("POST", "/v1/payment_links", {
            "line_items": [{"price": unico["id"], "quantity": 1}],
            "after_completion": {"type": "hosted_confirmation", "hosted_confirmation": {
                "custom_message": "Pago recibido. Su bono queda pagado; recibirá la factura por email."}},
            "metadata": {"plan_id": plan["id"], "origen": "PROYECTO ALLAS", "tipo": "renovacion"}})
        return {"ref_producto": ref_producto, "ref_precio": precio["id"], "ref_enlace": enlace["id"], "url_enlace": enlace["url"],
                "ref_precio_unico": unico["id"], "ref_enlace_unico": enlace_u["id"], "url_enlace_unico": enlace_u["url"]}

    def desactivar_enlace(self, ref_enlace):
        try:
            self._req("POST", f"/v1/payment_links/{ref_enlace}", {"active": False})
        except ErrorPago:
            pass

    # --- 4.3: pago de un ticket desde el móvil del cliente (sesión de Checkout con el importe exacto)
    def crear_sesion_pago(self, importe_cent, concepto, url_ok, url_cancelar, metadatos=None, email=None, minutos=30):
        datos = {
            "mode": "payment", "success_url": url_ok, "cancel_url": url_cancelar, "locale": "es",
            "line_items": [{"quantity": 1, "price_data": {"currency": "eur", "unit_amount": int(importe_cent),
                                                           "product_data": {"name": concepto}}}],
            "metadata": metadatos or {}, "payment_intent_data": {"metadata": metadatos or {}},
            "expires_at": int(__import__("time").time()) + max(30, int(minutos)) * 60}
        if email:
            datos["customer_email"] = email
        s = self._req("POST", "/v1/checkout/sessions", datos)
        return {"id": s["id"], "url": s["url"]}

    def sesion(self, ref):
        return self._req("GET", f"/v1/checkout/sessions/{ref}")

    def expirar_sesion(self, ref):
        """1.18: cierra una sesión de pago abierta (reserva cancelada o cambiada) para que no se pueda pagar después."""
        try:
            return self._req("POST", f"/v1/checkout/sessions/{ref}/expire")
        except ErrorPago:
            return None

    def reembolsar(self, payment_intent, importe_cent=None, metadatos=None):
        """1.18: devuelve un pago (entero, o «importe_cent» si se indica) a la tarjeta del cliente."""
        datos = {"payment_intent": payment_intent, "metadata": metadatos or {}}
        if importe_cent:
            datos["amount"] = int(importe_cent)
        return self._req("POST", "/v1/refunds", datos)

    # --- consultas
    def sesiones_completadas(self, ref_enlace):
        return self._todos("/v1/checkout/sessions", {"payment_link": ref_enlace, "status": "complete"})

    def suscripcion(self, ref):
        return self._req("GET", f"/v1/subscriptions/{ref}")

    def facturas(self, ref_suscripcion):
        return self._todos("/v1/invoices", {"subscription": ref_suscripcion}, maximo=100)

    def cancelar(self, ref, inmediato=False):
        if inmediato:
            return self._req("DELETE", f"/v1/subscriptions/{ref}")
        return self._req("POST", f"/v1/subscriptions/{ref}", {"cancel_at_period_end": True})

    def reactivar(self, ref):
        return self._req("POST", f"/v1/subscriptions/{ref}", {"cancel_at_period_end": False})


def estado_suscripcion(s):
    """Estado de Stripe -> estado propio."""
    return {"active": "activa", "trialing": "activa", "past_due": "impagada", "unpaid": "impagada",
            "canceled": "cancelada", "incomplete_expired": "cancelada", "incomplete": "incompleta",
            "paused": "impagada"}.get(s.get("status"), "incompleta")


def fin_periodo(s):
    """current_period_end (en versiones nuevas de la API está en el elemento de la suscripción)."""
    fin = s.get("current_period_end")
    if not fin:
        items = (s.get("items") or {}).get("data") or []
        fin = items[0].get("current_period_end") if items else None
    return fin


def referencia_cliente(cliente_id):
    return f"CL{int(cliente_id)}"


def cliente_de_referencia(ref):
    m = re.fullmatch(r"CL(\d+)", ref or "")
    return int(m.group(1)) if m else None


def enlace_personal(url_enlace, cliente):
    params = {"client_reference_id": referencia_cliente(cliente["id"])}
    if cliente.get("email"):
        params["prefilled_email"] = cliente["email"]
    return url_enlace + ("&" if "?" in url_enlace else "?") + urllib.parse.urlencode(params)
