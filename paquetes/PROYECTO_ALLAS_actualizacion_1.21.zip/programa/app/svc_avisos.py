"""PROYECTO ALLAS · lógica de negocio: recordatorios, avisos del sistema, mensajes, comunicados y avisos de caducidad (1.4: sale de servicios.py; se mezcla en la clase Parking)."""
import json
import os
import secrets
from datetime import datetime, timedelta

from . import errores
from .utiles import ErrorNegocio, ROLES_SUPERVISION, _plantilla, email_valido, eur, fecha_es, iso, parse


class SvcAvisos:
    # ------------------------------------------------------------ 3.5: recordatorios y avisos
    def recordatorios_activos(self):
        return self.cfg("recordatorios_activo") != "0"

    @staticmethod
    def _para_valido(para):
        para = (para or "todos").strip()
        if para == "todos" or para in ("rol:admin", "rol:supervisor", "rol:cajero"):
            return para
        if para.startswith("usuario:") and para[8:].isdigit():
            return para
        raise ErrorNegocio("Destinatario del recordatorio no válido")

    def _es_para(self, r, usuario):
        para = r["para"] or "todos"
        return (para == "todos" or para == "rol:" + usuario["rol"] or para == f"usuario:{usuario['id']}"
                or r["creado_por"] == usuario["id"])

    def recordatorios_pendientes(self, usuario):
        """Los que ya tocan (fecha <= ahora), sin hacer y que este usuario no ha leído."""
        ahora = iso(self.ahora())
        filas = self.db.q("SELECT r.*, u.nombre creado_por_nombre FROM recordatorios r LEFT JOIN usuarios u ON u.id=r.creado_por "
                          "WHERE r.hecho IS NULL AND r.fecha<=? AND NOT EXISTS (SELECT 1 FROM recordatorio_leidos l "
                          "WHERE l.recordatorio_id=r.id AND l.usuario_id=?) ORDER BY r.fecha DESC", (ahora, usuario["id"]))
        return [r for r in filas if self._es_para(r, usuario)]

    def recordatorios_lista(self, usuario):
        """Todos los que ve este usuario (próximos, pendientes, leídos y hechos de los últimos 60 días)."""
        desde = iso(self.ahora() - timedelta(days=60))
        filas = self.db.q("SELECT r.*, u.nombre creado_por_nombre, h.nombre hecho_por_nombre, "
                          "(SELECT 1 FROM recordatorio_leidos l WHERE l.recordatorio_id=r.id AND l.usuario_id=?) leido "
                          "FROM recordatorios r LEFT JOIN usuarios u ON u.id=r.creado_por LEFT JOIN usuarios h ON h.id=r.hecho_por "
                          "WHERE r.hecho IS NULL OR r.hecho>=? ORDER BY r.hecho IS NOT NULL, r.fecha", (usuario["id"], desde))
        ver_todo = usuario["rol"] in ROLES_SUPERVISION
        return [r for r in filas if ver_todo or self._es_para(r, usuario)]

    def guardar_recordatorio(self, usuario, datos, rid=None):
        titulo = (datos.get("titulo") or "").strip()[:120]
        if not titulo:
            raise ErrorNegocio("Escriba el título del recordatorio")
        texto = (datos.get("texto") or "").strip()[:2000] or None
        try:
            fecha = parse(datos.get("fecha")) if datos.get("fecha") else self.ahora()
        except (ValueError, TypeError):
            raise ErrorNegocio("Fecha no válida")
        if fecha.tzinfo is None and self.ahora().tzinfo is not None:
            fecha = fecha.replace(tzinfo=self.ahora().tzinfo)
        fecha = fecha.replace(microsecond=0)
        para = self._para_valido(datos.get("para"))
        if para != f"usuario:{usuario['id']}" and usuario["rol"] not in ROLES_SUPERVISION:
            raise ErrorNegocio("Solo un supervisor o administrador puede dejar recordatorios a otros", 403)
        with self.db.transaccion() as c:
            if rid:
                r = c.execute("SELECT creado_por FROM recordatorios WHERE id=?", (rid,)).fetchone()
                if not r:
                    raise ErrorNegocio("Recordatorio no encontrado", 404)
                if r[0] != usuario["id"] and usuario["rol"] not in ROLES_SUPERVISION:
                    raise ErrorNegocio("Solo puede cambiar sus propios recordatorios", 403)
                c.execute("UPDATE recordatorios SET titulo=?, texto=?, fecha=?, para=? WHERE id=?",
                          (titulo, texto, iso(fecha), para, rid))
                c.execute("DELETE FROM recordatorio_leidos WHERE recordatorio_id=?", (rid,))
            else:
                rid = c.execute("INSERT INTO recordatorios(titulo, texto, fecha, para, creado, creado_por) VALUES(?,?,?,?,?,?)",
                                (titulo, texto, iso(fecha), para, iso(self.ahora()), usuario["id"])).lastrowid
            self.auditar(c, usuario["id"], "recordatorio_guardar", f"id={rid} {titulo}")
        return {"id": rid}

    def _recordatorio_visible(self, usuario, rid):
        r = self.db.q1("SELECT * FROM recordatorios WHERE id=?", (rid,))
        if not r or not (self._es_para(r, usuario) or usuario["rol"] in ROLES_SUPERVISION):
            raise ErrorNegocio("Recordatorio no encontrado", 404)
        return r

    def leer_recordatorio(self, usuario, rid):
        self._recordatorio_visible(usuario, rid)
        with self.db.transaccion() as c:
            c.execute("INSERT OR IGNORE INTO recordatorio_leidos(recordatorio_id, usuario_id, fecha) VALUES(?,?,?)",
                      (rid, usuario["id"], iso(self.ahora())))
        return {"ok": True}

    def hecho_recordatorio(self, usuario, rid, hecho=True):
        self._recordatorio_visible(usuario, rid)
        with self.db.transaccion() as c:
            c.execute("UPDATE recordatorios SET hecho=?, hecho_por=? WHERE id=?",
                      (iso(self.ahora()) if hecho else None, usuario["id"] if hecho else None, rid))
            if not hecho:
                c.execute("DELETE FROM recordatorio_leidos WHERE recordatorio_id=?", (rid,))
            self.auditar(c, usuario["id"], "recordatorio_hecho" if hecho else "recordatorio_reabrir", f"id={rid}")
        return {"ok": True}

    def borrar_recordatorio(self, usuario, rid):
        r = self._recordatorio_visible(usuario, rid)
        if r["creado_por"] != usuario["id"] and usuario["rol"] not in ROLES_SUPERVISION:
            raise ErrorNegocio("Solo puede borrar sus propios recordatorios", 403)
        with self.db.transaccion() as c:
            c.execute("DELETE FROM recordatorio_leidos WHERE recordatorio_id=?", (rid,))
            c.execute("DELETE FROM recordatorios WHERE id=?", (rid,))
            self.auditar(c, usuario["id"], "recordatorio_borrar", f"id={rid} {r['titulo']}")
        return {"ok": True}

    def avisos_sistema(self, usuario, carpeta_backups=None):
        """Avisos que genera el propio programa (no se guardan): licencia, copias, pagos pendientes, emails."""
        if usuario["rol"] not in ROLES_SUPERVISION:
            return []
        avisos = []
        try:
            lic = self.estado_licencia()
            d = lic.get("dias_restantes")
            if not lic.get("puede_operar"):
                avisos.append({"id": "licencia", "nivel": "rojo", "titulo": "Licencia caducada", "texto": lic.get("mensaje"), "ir": "licencia"})
            elif d is not None and d <= 15:
                avisos.append({"id": "licencia", "nivel": "aviso", "titulo": f"La licencia caduca en {d} día(s)",
                               "texto": lic.get("mensaje"), "ir": "licencia"})
        except Exception as e_:  # noqa: BLE001
            errores.fallo("servicios.avisos_sistema", e_)
        if usuario["rol"] == "admin":   # 4.24: la búsqueda automática de actualizaciones deja aquí su aviso
            try:
                from . import __version__ as _v
                from .actualizacion import version_tupla as _vt
                nuevo = json.loads(self.cfg("actualizacion_aviso") or "null")
                if nuevo and _vt(str(nuevo["version"])) > _vt(_v):
                    avisos.append({"id": "actualizacion", "nivel": "aviso", "titulo": f"Hay una nueva versión: {nuevo['version']}",
                                   "texto": "Pulse para ver las novedades y actualizar (Ajustes → Sistema → Actualizaciones).", "ir": "actualizaciones"})
            except Exception as e_:  # noqa: BLE001
                errores.fallo("servicios.avisos_sistema", e_)
        if carpeta_backups and usuario["rol"] == "admin":
            import glob as _glob
            copias = _glob.glob(os.path.join(carpeta_backups, "parking-*.db"))
            ultima = max((os.path.getmtime(x) for x in copias), default=None)
            if ultima is None or (datetime.now().timestamp() - ultima) > 3 * 86400:
                avisos.append({"id": "copias", "nivel": "aviso", "titulo": "Sin copias de seguridad recientes",
                               "texto": "No hay ninguna copia de los últimos 3 días. Haga una en Ajustes → Sistema → Copias de seguridad.",
                               "ir": "copias"})
        if self.tiene_modulo("abonados"):
            n = self.db.q1("SELECT COUNT(DISTINCT b.cliente_id) n FROM bonos b JOIN clientes c ON c.id=b.cliente_id "
                           "WHERE b.estado='activo' AND b.pagado=0 AND c.activo=1 AND b.desde<=?",
                           (self.ahora().date().isoformat(),))["n"]
            if n:
                avisos.append({"id": "deudas", "nivel": "aviso", "titulo": f"{n} abonado(s) con pago pendiente",
                               "texto": "Bonos renovados que aún no se han cobrado.", "ir": "abonados"})
        if carpeta_backups and usuario["rol"] == "admin" and self.cfg("backup_destino_extra"):
            from .backup import registro as registro_copias
            ult = next((r for r in registro_copias(carpeta_backups, 10) if r.get("ok") and "extra" in r), None)
            if ult and ult["extra"] != "ok":
                avisos.append({"id": "copia_nas", "nivel": "rojo", "titulo": "La última copia no llegó a la carpeta adicional (NAS)",
                               "texto": ult["extra"].replace("error: ", "") + ". Compruebe que el NAS está encendido y conectado.",
                               "ir": "copias"})
        if self.cfg("barrera_activa") == "1" and self.cfg("barrera_ultimo_error"):
            avisos.append({"id": "barrera", "nivel": "aviso", "titulo": "La barrera no respondió la última vez",
                           "texto": self.cfg("barrera_ultimo_error"), "ir": "perifericos"})
        bl = self.bloqueos_activos()
        if bl:
            quien = ", ".join(b["clave"].split(":", 1)[1] for b in bl[:4])
            avisos.append({"id": "bloqueos", "nivel": "rojo", "titulo": f"Acceso bloqueado por PIN fallidos: {quien}",
                           "texto": "Varios intentos de PIN incorrectos seguidos. Si no ha sido un despiste, revise Informes → Auditoría. "
                                    "Se puede desbloquear en Ajustes → Empresa → Usuarios.", "ir": "usuarios"})
        n = self.db.q1("SELECT COUNT(*) n FROM emails WHERE estado='error'")["n"]
        if n:
            avisos.append({"id": "emails", "nivel": "aviso", "titulo": f"{n} email(s) de factura con error",
                           "texto": "Revise la configuración del correo en Ajustes → Conexiones → Email.", "ir": "email"})
        if self.cfg("alertas_activas") != "0":   # 4.3: alertas operativas
            try:
                avisos += self.alertas_operativas()
            except Exception as e_:  # noqa: BLE001
                errores.fallo("servicios.avisos_sistema", e_, grave=True)
        pm = self.db.q("SELECT p.detalle, t.codigo FROM pagos_movil p JOIN tickets t ON t.id=p.ticket_id WHERE p.estado='error' "
                       "ORDER BY p.id DESC LIMIT 5")
        if pm:
            avisos.append({"id": "pago_movil", "nivel": "rojo", "titulo": f"{len(pm)} pago(s) con el móvil a revisar",
                           "texto": "; ".join(f"{x['codigo']}: {x['detalle']}" for x in pm), "ir": "pagos"})
        if self.cfg("nube_ultimo_error"):
            avisos.append({"id": "nube", "nivel": "aviso", "titulo": "La copia en la nube falló",
                           "texto": self.cfg("nube_ultimo_error"), "ir": "copias"})
        try:
            avisos += self.avisos44()   # 4.4: integridad de la base de datos, semáforo / cartel
        except Exception as e_:  # noqa: BLE001
            errores.fallo("servicios.avisos_sistema", e_, grave=True)
        if usuario["rol"] == "admin":   # 1.2: fallos internos que el programa absorbió sin interrumpir a nadie
            graves = errores.recientes(solo_graves=True)
            if graves:
                u = graves[-1]
                avisos.append({"id": "errores_internos", "nivel": "aviso",
                               "titulo": f"Se han producido {len(graves)} fallo(s) interno(s) en las últimas 24 h",
                               "texto": f"Último: {u['donde']} → {u['error']}. Quedan anotados en el registro del servidor.",
                               "ir": "copias"})
        return avisos

    TEXTOS_AVISO = {
        "caducidad": ("Su bono de {parking} caduca el {hasta}",
                      "Hola {nombre}:\n\nLe recordamos que su bono {plan} de {parking} caduca el {hasta}.\n"
                      "Puede renovarlo en la caja del aparcamiento.{texto_enlace}\n\nUn saludo,\n{parking}"),
        "renovacion": ("Su bono de {parking} se ha renovado: pago pendiente",
                       "Hola {nombre}:\n\nSu bono {plan} de {parking} se ha renovado automáticamente del {desde} al {hasta} "
                       "(bono nº {numero}).\nImporte pendiente: {importe}. Puede pagarlo en la caja del aparcamiento "
                       "antes del {pagar_antes}.{texto_enlace}\n\nSi no desea renovarlo, avísenos.\n\nUn saludo,\n{parking}"),
        "pago_pendiente": ("Tiene una factura pendiente de pago en {parking}",
                           "Hola {nombre}:\n\nNo hemos podido cobrar la renovación de su bono {plan} "
                           "({importe}). Puede pagar la factura pendiente aquí:\n{enlace}\n\n"
                           "Si ya la ha pagado, ignore este mensaje.\n\nUn saludo,\n{parking}"),
        "deuda": ("Recordatorio: tiene {importe} pendiente de pago en {parking}",
                  "Hola {nombre}:\n\nLe recordamos que tiene pendiente de pago {importe} de su bono en {parking}:\n"
                  "{detalle}\n\nPuede pagarlo en la caja del aparcamiento en efectivo o con tarjeta.{texto_enlace}\n\n"
                  "Si ya lo ha pagado, ignore este mensaje.\n\nUn saludo,\n{parking}"),
    }

    # ---------------------------------------------------- WhatsApp / SMS
    def msg_modo(self):
        m = self.cfg("msg_modo") or "no"
        if not self.tiene_modulo("mensajeria"):
            return "no"
        return m if m in ("no", "manual", "twilio") else "no"

    def msg_canal(self, canal=None):
        if self.msg_modo() == "manual":
            return "whatsapp"
        c = canal or self.cfg("msg_canal") or "whatsapp"
        return c if c in ("whatsapp", "sms") else "whatsapp"

    def movil(self, telefono):
        from .mensajeria import normalizar_movil
        return normalizar_movil(telefono, self.cfg("msg_prefijo") or "34")

    def _twilio(self):
        from .mensajeria import Twilio
        return Twilio(self.cfg("twilio_sid"), self.cfg("twilio_token"), self.cfg("msg_api_base") or None)

    def _enviar_mensaje(self, cliente_id, movil, texto, canal, tipo, referencia):
        """Envío automático (Twilio) y anotación en avisos. Devuelve (estado, detalle)."""
        from .mensajeria import ErrorMensaje
        desde = self.cfg("twilio_desde_whatsapp" if canal == "whatsapp" else "twilio_desde_sms")
        try:
            sid = self._twilio().enviar(desde, movil, texto, canal)
            estado, det = "enviado", f"{canal} {sid or ''}".strip()
        except ErrorMensaje as e:
            estado, det = "error", f"{canal}: {e}"[:300]
        self._anotar_mensaje(cliente_id, tipo, referencia, movil, estado, det)
        return estado, det

    def _anotar_mensaje(self, cliente_id, tipo, referencia, movil, estado, det):
        self.db.ex("INSERT INTO avisos(cliente_id, tipo, referencia, destino, fecha, estado, detalle) VALUES(?,?,?,?,?,?,?) "
                   "ON CONFLICT(tipo, referencia) DO UPDATE SET fecha=excluded.fecha, estado=excluded.estado, "
                   "detalle=excluded.detalle", (cliente_id, tipo, referencia, movil, iso(self.ahora()), estado, det))

    def _aviso_por_mensaje(self, tipo, referencia, cliente, datos):
        """Los avisos automáticos (renovación, caducidad, pago pendiente) también por WhatsApp/SMS, una sola vez."""
        if self.msg_modo() != "twilio" or self.cfg("msg_avisos_auto") != "1":
            return None
        movil = self.movil(cliente.get("telefono"))
        if not movil or self.db.q1("SELECT 1 FROM avisos WHERE tipo=? AND referencia=? AND estado='enviado'",
                                   (f"{tipo}_msg", referencia)):
            return None
        _, texto = self._texto_aviso(tipo, dict(datos, nombre=cliente["nombre"]))
        return self._enviar_mensaje(cliente["id"], movil, texto, self.msg_canal(), f"{tipo}_msg", referencia)[0]

    def prueba_mensaje(self, usuario, telefono, canal=None):
        movil = self.movil(telefono)
        if not movil:
            raise ErrorNegocio("Número de móvil no válido (p. ej. 612 345 678 o +34612345678)")
        if self.msg_modo() != "twilio":
            raise ErrorNegocio("La prueba de envío es para el modo automático (Twilio)")
        canal = self.msg_canal(canal)
        estado, det = self._enviar_mensaje(None, movil, f"Mensaje de prueba de {self.cfg('nombre_parking') or 'PROYECTO ALLAS'}: "
                                           "los avisos por WhatsApp/SMS funcionan.", canal, "prueba_msg",
                                           f"prueba:{iso(self.ahora())}")
        with self.db.transaccion() as c:
            self.auditar(c, usuario["id"], "mensaje_prueba", f"{canal} a {movil}: {estado}")
        if estado != "enviado":
            raise ErrorNegocio(det)
        return {"estado": estado, "destino": movil, "canal": canal}

    def recordatorio_deuda_mensaje(self, cliente_id):
        """Versión corta del recordatorio de deuda para WhatsApp/SMS."""
        r = self.recordatorio_deuda(cliente_id)
        cli = self.db.q1("SELECT * FROM clientes WHERE id=?", (cliente_id,))
        deudas = self.deudas_cliente(cliente_id)
        iban = (self.cfg("transferencia_iban") or "").strip()
        extra = (f" Por transferencia: IBAN {iban}, concepto «Bono {deudas[0]['numero_txt']}»."
                 if iban and self.cfg("transferencia_activa") != "0" else "")
        texto = _plantilla(self.cfg("msg_deuda_texto") or self.TEXTO_DEUDA_CORTO,
                           {"nombre": cli["nombre"], "importe": eur(r["total_cent"]), "parking": self.cfg("nombre_parking") or "",
                            "texto_transferencia": extra})
        ult = self.db.q1("SELECT fecha, estado, destino, detalle FROM avisos WHERE cliente_id=? AND tipo='deuda_msg' "
                         "ORDER BY fecha DESC LIMIT 1", (cliente_id,))
        from .mensajeria import partes_sms
        return {"movil": self.movil(cli["telefono"]), "telefono": cli["telefono"] or "", "texto": texto,
                "modo": self.msg_modo(), "canal": self.msg_canal(), "sms": partes_sms(texto), "ultimo": ult,
                "total_cent": r["total_cent"]}

    TEXTO_DEUDA_CORTO = ("{parking}: Hola {nombre}, le recordamos que tiene {importe} pendiente de pago de su bono. "
                         "Puede pagarlo en caja.{texto_transferencia} Si ya lo ha pagado, ignore este mensaje.")

    def enviar_recordatorio_mensaje(self, usuario, cliente_id, texto=None, canal=None, telefono=None):
        if self.msg_modo() == "no":
            raise ErrorNegocio("Los avisos por WhatsApp/SMS están desactivados (Ajustes → Conexiones → WhatsApp / SMS)")
        r = self.recordatorio_deuda_mensaje(cliente_id)
        movil = self.movil(telefono) if telefono else r["movil"]
        if not movil:
            raise ErrorNegocio("El cliente no tiene un móvil válido: añádalo en su ficha (Teléfono)")
        texto = (texto or "").strip() or r["texto"]
        canal = self.msg_canal(canal)
        ref = f"{cliente_id}:{iso(self.ahora())}:{secrets.token_hex(3)}"
        if self.msg_modo() == "manual":
            from .mensajeria import enlace_whatsapp
            self._anotar_mensaje(cliente_id, "deuda_msg", ref, movil, "enviado", "a mano (WhatsApp)")
            res = {"estado": "enviado", "destino": movil, "canal": "whatsapp", "enlace": enlace_whatsapp(movil, texto)}
        else:
            estado, det = self._enviar_mensaje(cliente_id, movil, texto, canal, "deuda_msg", ref)
            if estado != "enviado":
                raise ErrorNegocio(f"No se pudo enviar: {det}")
            res = {"estado": estado, "destino": movil, "canal": canal}
        with self.db.transaccion() as c:
            self.auditar(c, usuario["id"], "recordatorio_deuda", f"cliente={cliente_id} {eur(r['total_cent'])} por "
                         f"{res['canal']} a {movil}{' (a mano)' if self.msg_modo() == 'manual' else ''}")
        return res

    # ---------------------------------------------------- comunicados generales a los abonados
    FILTROS_COMUNICADO = {"todos": "Todos los abonados activos", "vigentes": "Con bono vigente",
                          "deuda": "Con pago pendiente", "caducados": "Con bono caducado"}

    def destinatarios_comunicado(self, filtro="todos"):
        if filtro not in self.FILTROS_COMUNICADO:
            raise ErrorNegocio("Filtro de destinatarios no válido")
        salida = []
        for c in self.db.q("SELECT id, nombre, email, telefono FROM clientes WHERE activo=1 AND tipo='abonado' ORDER BY nombre"):
            if filtro == "vigentes" and not self.bono_vigente(c["id"]):
                continue
            if filtro == "deuda" and not self.bono_pendiente(c["id"]):
                continue
            if filtro == "caducados" and self._estado_bono(c["id"])["estado"] != "caducado":
                continue
            c["valido"] = bool(c["email"] and email_valido(c["email"]))
            c["movil"] = self.movil(c.get("telefono"))
            salida.append(c)
        return salida

    def resumen_comunicado(self, filtro="todos"):
        d = self.destinatarios_comunicado(filtro)
        return {"total": len(d), "con_email": sum(1 for x in d if x["valido"]),
                "sin_email": [x["nombre"] for x in d if not x["valido"]],
                "emails": [x["email"] for x in d if x["valido"]], "smtp": self.smtp_listo(),
                "con_movil": sum(1 for x in d if x["movil"]), "sin_movil": [x["nombre"] for x in d if not x["movil"]],
                "msg_modo": self.msg_modo(), "msg_canal": self.msg_canal()}

    def crear_comunicado(self, usuario, asunto, texto, filtro="todos", medio="smtp", en_segundo_plano=True):
        """Envía un comunicado a los abonados. Por SMTP se manda uno a uno (personalizado con {nombre}) en
        segundo plano; con Gmail solo se anota (las direcciones van en copia oculta)."""
        asunto, texto = (asunto or "").strip(), (texto or "").strip()
        if not asunto or not texto:
            raise ErrorNegocio("Escriba el asunto y el mensaje")
        if medio not in ("smtp", "gmail", "mensaje"):
            raise ErrorNegocio("Forma de envío no válida")
        if medio == "smtp" and not self.smtp_listo():
            raise ErrorNegocio("El envío automático (SMTP) no está configurado: use Gmail o configúrelo en Ajustes → Conexiones → Email")
        if medio == "mensaje" and self.msg_modo() == "no":
            raise ErrorNegocio("Los avisos por WhatsApp/SMS están desactivados (Ajustes → Conexiones → WhatsApp / SMS)")
        dest = self.destinatarios_comunicado(filtro)
        if medio == "mensaje":
            validos = [x for x in dest if x["movil"]]
            if not validos:
                raise ErrorNegocio("Ningún abonado de ese grupo tiene móvil")
            medio = "whatsapp_manual" if self.msg_modo() == "manual" else self.msg_canal()
        else:
            validos = [x for x in dest if x["valido"]]
            if not validos:
                raise ErrorNegocio("Ningún abonado de ese grupo tiene email")
        cid = self.db.ex("INSERT INTO comunicados(fecha, usuario_id, asunto, texto, filtro, medio, total, sin_email, estado) "
                         "VALUES(?,?,?,?,?,?,?,?,?)", (iso(self.ahora()), usuario["id"], asunto, texto, filtro, medio,
                                                     len(validos), len(dest) - len(validos),
                                                     "enviando" if medio in ("smtp", "whatsapp", "sms", "whatsapp_manual")
                                                     else "terminado")).lastrowid
        with self.db.transaccion() as c:
            self.auditar(c, usuario["id"], "comunicado", f"id={cid} «{asunto}» a {len(validos)} abonado(s) ({medio}, {filtro})")
        if medio == "gmail":
            self.db.ex("UPDATE comunicados SET enviados=? WHERE id=?", (len(validos), cid))
            return self.comunicado(cid)
        if medio == "whatsapp_manual":   # se abre un WhatsApp por abonado desde la lista
            from .mensajeria import enlace_whatsapp
            parking = self.cfg("nombre_parking") or ""
            res = self.comunicado(cid)
            res["enlaces"] = [{"cliente_id": x["id"], "nombre": x["nombre"], "movil": x["movil"],
                               "enlace": enlace_whatsapp(x["movil"], _plantilla(texto, {"nombre": x["nombre"], "parking": parking}))}
                              for x in validos]
            return res
        if en_segundo_plano:
            import threading
            threading.Thread(target=self._enviar_comunicado, args=(cid, validos), daemon=True, name=f"comunicado{cid}").start()
        else:
            self._enviar_comunicado(cid, validos)
        return self.comunicado(cid)

    def _enviar_comunicado(self, cid, destinatarios):
        from .correo import enviar
        com = self.db.q1("SELECT * FROM comunicados WHERE id=?", (cid,))
        cfg = self.db.config()
        parking = self.cfg("nombre_parking") or ""
        for d in destinatarios:
            datos = {"nombre": d["nombre"], "parking": parking}
            if com["medio"] in ("whatsapp", "sms"):
                estado, _ = self._enviar_mensaje(d["id"], d["movil"], _plantilla(com["texto"], datos), com["medio"],
                                                 "comunicado_msg", f"{cid}:{d['id']}")
                campo = "enviados" if estado == "enviado" else "errores"
                self.db.ex(f"UPDATE comunicados SET {campo}={campo}+1 WHERE id=?", (cid,))
                continue
            try:
                enviar(cfg, d["email"], _plantilla(com["asunto"], datos), _plantilla(com["texto"], datos), [])
                estado, det, campo = "enviado", None, "enviados"
            except Exception as e:  # noqa: BLE001
                estado, det, campo = "error", str(e)[:300], "errores"
            self.db.ex("INSERT OR REPLACE INTO avisos(cliente_id, tipo, referencia, destino, fecha, estado, detalle) "
                       "VALUES(?,?,?,?,?,?,?)", (d["id"], "comunicado", f"{cid}:{d['id']}", d["email"], iso(self.ahora()),
                                                 estado, det))
            self.db.ex(f"UPDATE comunicados SET {campo}={campo}+1 WHERE id=?", (cid,))
        self.db.ex("UPDATE comunicados SET estado='terminado' WHERE id=?", (cid,))

    def comunicado(self, cid):
        c = self.db.q1("SELECT c.*, u.nombre usuario FROM comunicados c LEFT JOIN usuarios u ON u.id=c.usuario_id "
                       "WHERE c.id=?", (cid,))
        if not c:
            raise ErrorNegocio("Comunicado no encontrado", 404)
        c["fallidos"] = self.db.q("SELECT a.destino, a.detalle, cl.nombre FROM avisos a LEFT JOIN clientes cl ON cl.id=a.cliente_id "
                                  "WHERE a.tipo IN ('comunicado','comunicado_msg') AND a.referencia LIKE ? AND a.estado='error'",
                                  (f"{cid}:%",))
        return c

    def marcar_comunicado_whatsapp(self, cid, cliente_id):
        """Modo manual: anota que se ha abierto el WhatsApp de un abonado."""
        com = self.comunicado(cid)
        movil = self.movil((self.db.q1("SELECT telefono FROM clientes WHERE id=?", (cliente_id,)) or {}).get("telefono"))
        nuevo = not self.db.q1("SELECT 1 FROM avisos WHERE tipo='comunicado_msg' AND referencia=?", (f"{cid}:{cliente_id}",))
        self._anotar_mensaje(cliente_id, "comunicado_msg", f"{cid}:{cliente_id}", movil, "enviado", "a mano (WhatsApp)")
        if nuevo:
            self.db.ex("UPDATE comunicados SET enviados=enviados+1, estado=CASE WHEN enviados+1>=total THEN 'terminado' "
                       "ELSE estado END WHERE id=?", (cid,))
        del com
        return self.comunicado(cid)

    def comunicados(self, limite=20):
        return self.db.q("SELECT c.id, c.fecha, c.asunto, c.filtro, c.medio, c.total, c.enviados, c.errores, c.sin_email, "
                         "c.estado, u.nombre usuario FROM comunicados c LEFT JOIN usuarios u ON u.id=c.usuario_id "
                         "ORDER BY c.id DESC LIMIT ?", (limite,))

    # ---------------------------------------------------- recordatorio de deuda (a mano, desde la ficha)
    def recordatorio_deuda(self, cliente_id):
        """Email para recordar a un abonado lo que debe (se puede editar antes de enviarlo)."""
        cli = self.db.q1("SELECT * FROM clientes WHERE id=?", (cliente_id,))
        if not cli:
            raise ErrorNegocio("Cliente no encontrado", 404)
        deudas = self.deudas_cliente(cliente_id)
        if not deudas:
            raise ErrorNegocio("Este cliente no tiene nada pendiente de pago", 409)
        total = sum(d["pendiente_cent"] for d in deudas)
        detalle = "\n".join(
            f"- Bono {d['numero_txt']} ({d['plan_nombre']}) del {fecha_es(d['desde'])} al {fecha_es(d['hasta'])}: "
            f"pendiente {eur(d['pendiente_cent'])}" + (f" (pagado {eur(d['pagado_cent'])} de {eur(d['total_cent'])})"
                                                      if d["pagado_cent"] else "")
            for d in deudas)
        extra = ""
        if len(deudas) == 1 and self.activo("pagos_online_activo", "pagos_online"):
            b = self.db.q1("SELECT * FROM bonos WHERE id=?", (deudas[0]["id"],))
            enlace = self.enlace_pago_bono(b, cli)
            if enlace:
                extra += f"\n\nTambién puede pagarlo ahora con tarjeta en este enlace:\n{enlace}"
        iban = (self.cfg("transferencia_iban") or "").strip()
        if iban and self.cfg("transferencia_activa") != "0":
            titular = (self.cfg("transferencia_titular") or self.cfg("razon_social") or "").strip()
            extra += (f"\n\nO por transferencia bancaria a {titular + ', ' if titular else ''}IBAN {iban}, indicando en el "
                      f"concepto «Bono {deudas[0]['numero_txt']}».")
        asunto, texto = self._texto_aviso("deuda", {"nombre": cli["nombre"], "importe": eur(total), "detalle": detalle,
                                                   "texto_enlace": extra, "iban": iban, "enlace": ""})
        ult = self.db.q1("SELECT fecha, estado, detalle, destino FROM avisos WHERE cliente_id=? AND tipo='deuda' "
                         "ORDER BY fecha DESC LIMIT 1", (cliente_id,))
        return {"email": cli["email"] or "", "asunto": asunto, "texto": texto, "total_cent": total,
                "smtp": self.smtp_listo(), "ultimo": ult}

    def enviar_recordatorio_deuda(self, usuario, cliente_id, asunto=None, texto=None, medio="smtp", email=None):
        """Envía el recordatorio por SMTP o anota que se ha enviado a mano (Gmail / programa de correo)."""
        r = self.recordatorio_deuda(cliente_id)
        destino = (email or r["email"] or "").strip()
        if not destino or not email_valido(destino):
            raise ErrorNegocio("El cliente no tiene un email válido: añádalo en su ficha")
        asunto, texto = (asunto or "").strip() or r["asunto"], (texto or "").strip() or r["texto"]
        if medio == "smtp":
            if not self.smtp_listo():
                raise ErrorNegocio("El envío automático (SMTP) no está configurado: use Gmail o configúrelo en Ajustes → Conexiones → Email")
            from .correo import enviar
            try:
                enviar(self.db.config(), destino, asunto, texto, [])
                estado, det = "enviado", None
            except Exception as e:  # noqa: BLE001
                estado, det = "error", str(e)[:300]
        else:
            estado, det = "enviado", f"a mano ({medio})"
        self.db.ex("INSERT INTO avisos(cliente_id, tipo, referencia, destino, fecha, estado, detalle) VALUES(?,?,?,?,?,?,?)",
                   (cliente_id, "deuda", f"{cliente_id}:{iso(self.ahora())}:{secrets.token_hex(3)}", destino,
                    iso(self.ahora()), estado, det))
        with self.db.transaccion() as c:
            self.auditar(c, usuario["id"], "recordatorio_deuda",
                         f"cliente={cliente_id} {eur(r['total_cent'])} a {destino} ({medio}): {estado}")
        if estado == "error":
            raise ErrorNegocio(f"No se pudo enviar: {det}")
        return {"estado": estado, "destino": destino}

    def _texto_aviso(self, tipo, datos):
        asunto_d, texto_d = self.TEXTOS_AVISO[tipo]
        datos = dict(datos, parking=self.cfg("nombre_parking") or "")
        asunto = _plantilla(self.cfg(f"aviso_{tipo}_asunto") or asunto_d, datos)
        texto = _plantilla(self.cfg(f"aviso_{tipo}_texto") or texto_d, datos)
        return asunto, texto

    def _enviar_aviso(self, tipo, referencia, cliente, datos):
        """Envía un aviso una sola vez (tipo + referencia). Devuelve 'enviado', 'ya_enviado', 'sin_email' o 'error'.
        Si está activado, lo manda también por WhatsApp/SMS (automático con Twilio)."""
        self._aviso_por_mensaje(tipo, referencia, cliente, datos)
        if self.db.q1("SELECT 1 FROM avisos WHERE tipo=? AND referencia=? AND estado='enviado'", (tipo, referencia)):
            return "ya_enviado"
        if not cliente.get("email") or not email_valido(cliente["email"]):
            return "sin_email"
        asunto, texto = self._texto_aviso(tipo, dict(datos, nombre=cliente["nombre"]))
        from .correo import enviar
        try:
            enviar(self.db.config(), cliente["email"], asunto, texto, [])
            estado, det = "enviado", None
        except Exception as e:  # noqa: BLE001
            estado, det = "error", str(e)[:300]
        self.db.ex("INSERT INTO avisos(cliente_id, tipo, referencia, destino, fecha, estado, detalle) VALUES(?,?,?,?,?,?,?) "
                   "ON CONFLICT(tipo, referencia) DO UPDATE SET fecha=excluded.fecha, estado=excluded.estado, "
                   "detalle=excluded.detalle", (cliente["id"], tipo, referencia, cliente["email"], iso(self.ahora()),
                                                estado, det))
        return estado

    def avisos_caducidad(self):
        """Abonados cuyo bono caduca pronto, sin renovación ni suscripción activa."""
        dias = int(self.cfg("avisos_caducidad_dias") or 5)
        hoy = self.ahora().date()
        salida = []
        for c in self.db.q("SELECT * FROM clientes WHERE activo=1 AND tipo='abonado' AND renovacion_auto=0"):
            b = self._estado_bono(c["id"])
            if b["estado"] not in ("vigente", "caduca") or b.get("dias") is None or b["dias"] > dias:
                continue
            if self.db.q1("SELECT 1 FROM suscripciones WHERE cliente_id=? AND estado='activa' AND cancelar_al_final=0",
                          (c["id"],)):
                continue
            ref = f"{c['id']}:{b['hasta']}"
            av = self.db.q1("SELECT fecha, estado, detalle FROM avisos WHERE tipo='caducidad' AND referencia=?", (ref,))
            salida.append({"cliente_id": c["id"], "nombre": c["nombre"], "email": c["email"], "plan": b.get("plan"),
                           "hasta": b["hasta"], "dias": b["dias"], "referencia": ref, "aviso": av,
                           "enlace": self._enlace_cliente(c) if self.activo("pagos_online_activo", "pagos_online") else None})
        del hoy
        return salida

    def _enlace_cliente(self, cliente, plan_id=None):
        """Enlace personal de suscripción (del plan de su último bono) si los pagos online están activos."""
        if not plan_id:
            ult = self.db.q1("SELECT plan_id FROM bonos WHERE cliente_id=? AND estado='activo' ORDER BY hasta DESC LIMIT 1",
                             (cliente["id"],))
            plan_id = ult and ult["plan_id"]
        plan = plan_id and self.db.q1("SELECT * FROM planes_bono WHERE id=? AND activo=1", (plan_id,))
        if not plan or not plan["url_enlace"] or plan["precio_enlace_cent"] != plan["precio_cent"]:
            return None
        from .pagos_online import enlace_personal
        return enlace_personal(plan["url_enlace"], cliente)

    def enviar_avisos(self, solo=None):
        """Envía los avisos de caducidad pendientes (todos o los de 'solo' = lista de referencias)."""
        if not self.smtp_listo():
            raise ErrorNegocio("Para enviar avisos automáticamente configure el «Envío automático (SMTP)» en Ajustes → Email", 409)
        res = {"enviado": 0, "sin_email": 0, "error": 0, "ya_enviado": 0}
        for a in self.avisos_caducidad():
            if solo is not None and a["referencia"] not in solo:
                continue
            cli = self.db.q1("SELECT * FROM clientes WHERE id=?", (a["cliente_id"],))
            enlace = a["enlace"]
            r = self._enviar_aviso("caducidad", a["referencia"], cli, {
                "plan": a["plan"] or "", "hasta": fecha_es(a["hasta"]), "enlace": enlace or "",
                "texto_enlace": f"\n\nTambién puede suscribirse con pago automático con tarjeta y su bono se renovará solo:\n{enlace}" if enlace else ""})
            res[r] += 1
        return res

    def mensaje_aviso(self, referencia):
        """Texto del aviso para enviarlo a mano (Gmail en el navegador / programa de correo)."""
        a = next((x for x in self.avisos_caducidad() if x["referencia"] == referencia), None)
        if not a:
            raise ErrorNegocio("Ese aviso ya no está pendiente", 404)
        enlace = a["enlace"]
        asunto, texto = self._texto_aviso("caducidad", {
            "nombre": a["nombre"], "plan": a["plan"] or "", "hasta": fecha_es(a["hasta"]), "enlace": enlace or "",
            "texto_enlace": f"\n\nTambién puede suscribirse con pago automático con tarjeta y su bono se renovará solo:\n{enlace}" if enlace else ""})
        return {"email": a["email"], "asunto": asunto, "texto": texto}

    def marcar_aviso(self, usuario, referencia, medio):
        a = next((x for x in self.avisos_caducidad() if x["referencia"] == referencia), None)
        if a:
            self.db.ex("INSERT INTO avisos(cliente_id, tipo, referencia, destino, fecha, estado, detalle) "
                       "VALUES(?, 'caducidad', ?, ?, ?, 'enviado', ?) ON CONFLICT(tipo, referencia) DO UPDATE SET "
                       "fecha=excluded.fecha, estado='enviado', detalle=excluded.detalle",
                       (a["cliente_id"], referencia, a["email"], iso(self.ahora()), f"a mano ({medio})"))
        return {"ok": True}
