"""Impresora térmica ESC/POS y cajón portamonedas.

El cajón se conecta por RJ11 a la impresora y se abre con un pulso ESC/POS,
así que no necesita driver propio. El QR se imprime con el comando nativo
GS ( k (soportado por Epson TM-T20/T88, Bixolon, Star en modo ESC/POS, y la
mayoría de clónicas de 80 mm).

Modos de salida (config 'impresora_modo'):
  pantalla    -> no se envía nada: el ticket se muestra en pantalla (sin gastar papel)
  archivo     -> escribe .bin + .txt en una carpeta (pruebas sin hardware)
  dispositivo -> Linux: /dev/usb/lp0 (o puerto serie /dev/ttyUSB0)
  red         -> impresora Ethernet, '192.168.1.50:9100'
  windows     -> nombre de impresora instalada en Windows (envío RAW por winspool)
"""
import os
import re
import socket
import sys
import threading
from datetime import datetime

from .codigos import code128_svg, qr_svg

ESC = b"\x1b"
GS = b"\x1d"

_lock = threading.Lock()


class Ticket:
    """Constructor de documentos ESC/POS.

    Además de los bytes para la impresora, guarda:
      - preview: vista previa en texto plano (se guarda como .txt en modo archivo)
      - elementos: lista estructurada (texto con estilo, QR, código de barras...) que la
        interfaz dibuja como un ticket real en pantalla.
    """

    def __init__(self, ancho=42):
        self.ancho = ancho
        self.buf = bytearray(ESC + b"@" + ESC + b"t\x13")  # init + página de códigos PC858 (con €)
        self.preview = []
        self.elementos = []
        self._alin, self._neg, self._grande, self._alto, self._inv = "izq", False, False, False, False
        self.sep = "-"            # 4.2: carácter de los separadores (configurable)
        self.lineas_corte = 2     # 4.2: líneas en blanco antes del corte (4.43: 2; el propio comando de corte ya avanza el papel)
        self.compacto = True      # 4.43: sin líneas en blanco de adorno (ahorra papel); espacio(forzar=True) las respeta

    def _enc(self, s):
        return s.encode("cp858", errors="replace")

    # ----- estilos (se mantienen hasta que se cambian)
    def alinear(self, modo):
        self.buf += ESC + b"a" + {"izq": b"\x00", "centro": b"\x01", "der": b"\x02"}[modo]
        self._alin = modo
        return self

    def negrita(self, on=True):
        self.buf += ESC + b"E" + (b"\x01" if on else b"\x00")
        self._neg = on
        return self

    def _tam(self):
        v = (0x10 if self._grande else 0) | (0x01 if (self._grande or self._alto) else 0)
        self.buf += GS + b"!" + bytes([v])

    def grande(self, on=True):
        """Doble alto y doble ancho."""
        self._grande = on
        self._tam()
        return self

    def alto(self, on=True):
        """Solo doble alto (cabe la línea entera)."""
        self._alto = on
        self._tam()
        return self

    def inverso(self, on=True):
        """Blanco sobre negro."""
        self.buf += GS + b"B" + (b"\x01" if on else b"\x00")
        self._inv = on
        return self

    def ancho_actual(self):
        return self.ancho // 2 if self._grande else self.ancho

    # ----- contenido
    def linea(self, s=""):
        s = s[: self.ancho_actual()] if self._inv else s
        if self._inv and self._alin == "centro":
            s = s.center(self.ancho_actual())  # la banda negra ocupa todo el ancho
        self.buf += self._enc(s) + b"\n"
        vis = " ".join(s) if self._grande else s
        self.preview.append(vis.center(self.ancho) if self._alin == "centro"
                            else vis.rjust(self.ancho) if self._alin == "der" else vis)
        self.elementos.append({"t": "txt", "s": s, "a": self._alin, "b": self._neg,
                               "g": self._grande, "h": self._alto, "i": self._inv})
        return self

    def lineas(self, texto):
        """Varias líneas (texto con saltos), cortando las largas por palabras."""
        for parrafo in (texto or "").splitlines():
            for l in _partir(parrafo, self.ancho_actual()):
                self.linea(l)
        return self

    def espacio(self, n=1, forzar=False):
        if self.compacto and not forzar:
            return self
        for _ in range(n):
            self.buf += b"\n"
            self.preview.append("")
            self.elementos.append({"t": "esp"})
        return self

    def separador(self, c=None):
        c = c or self.sep
        self.buf += self._enc(c * self.ancho) + b"\n"
        self.preview.append(c * self.ancho)
        self.elementos.append({"t": "sep", "c": c})
        return self

    def par(self, izq, der):
        """Línea con texto a la izquierda y valor alineado a la derecha."""
        ancho = self.ancho_actual()
        izq = izq[: max(1, ancho - len(der) - 1)]
        hueco = max(1, ancho - len(izq) - len(der))
        return self.linea(izq + " " * hueco + der)

    def qr(self, datos, tam=6):
        d = datos.encode("ascii")
        n = len(d) + 3
        tam = max(3, min(15, int(tam)))
        self.buf += ESC + b"a\x01"
        self.buf += GS + b"(k\x04\x00\x31\x41\x32\x00"            # modelo 2
        self.buf += GS + b"(k\x03\x00\x31\x43" + bytes([tam])     # tamaño de módulo
        self.buf += GS + b"(k\x03\x00\x31\x45\x31"                # corrección de errores M
        self.buf += GS + b"(k" + bytes([n % 256, n // 256]) + b"\x31\x50\x30" + d
        self.buf += GS + b"(k\x03\x00\x31\x51\x30"                # imprimir
        self.buf += b"\n" + ESC + b"a" + {"izq": b"\x00", "centro": b"\x01", "der": b"\x02"}[self._alin]
        self.preview.append(f"[QR: {datos}]".center(self.ancho))
        self.elementos.append({"t": "qr", "d": datos, "tam": tam, "svg": qr_svg(datos, modulo=tam, borde=2)})
        return self

    def barras(self, datos, alto=80, modulo=2, texto=True):
        """Code128 (juego B): legible por lectores láser, CCD e infrarrojos 1D."""
        d = b"{B" + datos.encode("ascii")
        self.buf += ESC + b"a\x01"
        self.buf += GS + b"h" + bytes([max(30, min(255, alto))])     # alto en puntos
        self.buf += GS + b"w" + bytes([max(2, min(6, modulo))])      # ancho de módulo
        self.buf += GS + b"H" + (b"\x02" if texto else b"\x00")     # texto legible debajo
        self.buf += GS + b"f\x00"
        self.buf += GS + b"k\x49" + bytes([len(d)]) + d              # m=73: CODE128
        self.buf += b"\n" + ESC + b"a" + {"izq": b"\x00", "centro": b"\x01", "der": b"\x02"}[self._alin]
        self.preview.append(f"[CÓDIGO DE BARRAS: {datos}]".center(self.ancho))
        self.elementos.append({"t": "barras", "d": datos, "texto": texto,
                               "svg": code128_svg(datos, modulo=modulo, alto=alto // 2 * 2, margen=8)})
        return self

    def logo(self, ancho, alto, bits, version=0, img="logo"):
        """Imagen en blanco y negro (GS v 0, modo ráster), centrada. 'bits': 1 = punto negro."""
        fila = ancho // 8
        self.buf += ESC + b"a\x01"
        # en bloques de 128 líneas: algunas impresoras no aceptan imágenes más altas de una vez
        for y0 in range(0, alto, 128):
            h = min(128, alto - y0)
            self.buf += GS + b"v0\x00" + bytes([fila % 256, fila // 256, h % 256, h // 256])
            self.buf += bits[y0 * fila:(y0 + h) * fila]
        self.buf += b"\n" + ESC + b"a" + {"izq": b"\x00", "centro": b"\x01", "der": b"\x02"}[self._alin]
        self.preview.append(("[SELLO]" if img == "sello" else "[LOGO]").center(self.ancho))
        self.elementos.append({"t": "logo", "w": ancho, "h": alto, "v": version, **({"img": img} if img != "logo" else {})})
        return self

    def codigo(self, datos, tipo="ambos", tam_qr=6):
        """Imprime el código según configuración: qr | barras | ambos."""
        if tipo in ("qr", "ambos"):
            self.qr(datos, tam_qr)
        if tipo in ("barras", "ambos"):
            self.barras(datos, texto=True)
        return self

    def abrir_cajon(self, pin=0):
        self.buf += ESC + b"p" + bytes([pin]) + b"\x19\xfa"
        self.preview.append("[ABRIR CAJÓN]")
        self.elementos.append({"t": "cajon"})
        return self

    def cortar(self):
        self.buf += b"\n" * self.lineas_corte + GS + b"V\x42\x00"
        self.preview.append("[CORTE]")
        self.elementos.append({"t": "corte"})
        return self

    def bytes(self):
        return bytes(self.buf)

    def texto(self):
        return "\n".join(self.preview)


def _partir(texto, ancho):
    """Corta un párrafo en líneas de como mucho 'ancho' caracteres, por palabras."""
    if not texto.strip():
        return [""]
    lineas, actual = [], ""
    for palabra in texto.split():
        while len(palabra) > ancho:
            if actual:
                lineas.append(actual)
                actual = ""
            lineas.append(palabra[:ancho])
            palabra = palabra[ancho:]
        if not actual:
            actual = palabra
        elif len(actual) + 1 + len(palabra) <= ancho:
            actual += " " + palabra
        else:
            lineas.append(actual)
            actual = palabra
    if actual:
        lineas.append(actual)
    return lineas


# --- envío al hardware ----------------------------------------------------

def enviar(datos: bytes, modo: str, destino: str, nombre="doc", preview=""):
    """Envía bytes ESC/POS al destino configurado. Lanza excepción si falla."""
    with _lock:
        if modo == "archivo":
            os.makedirs(destino, exist_ok=True)
            base = os.path.join(destino, datetime.now().strftime("%Y%m%d-%H%M%S-%f") + "-" + nombre)
            with open(base + ".bin", "wb") as f:
                f.write(datos)
            with open(base + ".txt", "w", encoding="utf-8") as f:
                f.write(preview)
            return base + ".txt"
        if modo == "dispositivo":
            with open(destino, "wb") as f:
                f.write(datos)
            return destino
        if modo == "red":
            host, _, port = destino.partition(":")
            with socket.create_connection((host, int(port or 9100)), timeout=5) as s:
                s.sendall(datos)
            return destino
        if modo == "windows":
            _enviar_windows(destino, datos)
            return destino
        raise ValueError(f"Modo de impresora desconocido: {modo}")


def _enviar_windows(impresora: str, datos: bytes):
    """Envío RAW a una impresora de Windows usando winspool vía ctypes (sin pywin32)."""
    if sys.platform != "win32":
        raise RuntimeError("El modo 'windows' solo funciona en Windows")
    import ctypes
    from ctypes import wintypes

    winspool = ctypes.WinDLL("winspool.drv")

    class DOC_INFO_1(ctypes.Structure):
        _fields_ = [("pDocName", wintypes.LPWSTR),
                    ("pOutputFile", wintypes.LPWSTR),
                    ("pDatatype", wintypes.LPWSTR)]

    h = wintypes.HANDLE()
    if not winspool.OpenPrinterW(impresora, ctypes.byref(h), None):
        raise RuntimeError(f"No se encuentra la impresora '{impresora}'")
    try:
        di = DOC_INFO_1("Parking", None, "RAW")
        if not winspool.StartDocPrinterW(h, 1, ctypes.byref(di)):
            raise RuntimeError("StartDocPrinter falló")
        try:
            winspool.StartPagePrinter(h)
            escritos = wintypes.DWORD()
            buf = ctypes.create_string_buffer(datos, len(datos))
            if not winspool.WritePrinter(h, buf, len(datos), ctypes.byref(escritos)):
                raise RuntimeError("WritePrinter falló")
            winspool.EndPagePrinter(h)
        finally:
            winspool.EndDocPrinter(h)
    finally:
        winspool.ClosePrinter(h)


# ------------------------------------------------------------------ 4.26 · impresoras instaladas en el equipo
PATRON_TERMICA = re.compile(r"\b(pos|tm-?[a-z]?\d|tsp|thermal|t[eé]rmica|receipt|ticket|xp-?\d|rongta|bixolon|star|citizen|epson tm|58|80 ?mm|gp-?\d|zj-?\d|hprt|sam4s|nextep|3nstar)\b", re.I)
PATRON_NO_TICKET = re.compile(r"(pdf|onenote|xps|fax|anydesk|microsoft print|send to|enviar a|snagit|cutepdf|primopdf)", re.I)


def impresoras_sistema():
    """Impresoras que el sistema operativo tiene instaladas: [{nombre, predeterminada, ticket}].
    'ticket' = el nombre parece de una impresora térmica de tickets. Sin dependencias: winspool (Windows) o lpstat (CUPS)."""
    falsas = os.environ.get("ALLAS_IMPRESORAS_PRUEBA")    # solo para pruebas: "Nombre|1;Otra|0"
    if falsas is not None:
        crudas = []
        for x in filter(None, falsas.split(";")):
            n, d = (x.split("|") + ["0"])[:2]
            crudas.append((n, d == "1"))
    elif os.name == "nt":
        crudas = _impresoras_windows()
    else:
        crudas = _impresoras_cups()
    salida, vistos = [], set()
    for nombre, predet in crudas:
        if not nombre or nombre in vistos:
            continue
        vistos.add(nombre)
        salida.append({"nombre": nombre, "predeterminada": bool(predet),
                       "ticket": bool(PATRON_TERMICA.search(nombre)) and not PATRON_NO_TICKET.search(nombre),
                       "virtual": bool(PATRON_NO_TICKET.search(nombre))})
    # primero las que parecen de tickets, luego las normales y al final las virtuales (PDF, OneNote…)
    salida.sort(key=lambda i: (i["virtual"], not i["ticket"], not i["predeterminada"], i["nombre"].lower()))
    return salida


def _impresoras_windows():
    import ctypes
    from ctypes import wintypes
    winspool = ctypes.WinDLL("winspool.drv", use_last_error=True)

    class INFO4(ctypes.Structure):
        _fields_ = [("pPrinterName", wintypes.LPWSTR), ("pServerName", wintypes.LPWSTR), ("Attributes", wintypes.DWORD)]
    PRINTER_ENUM_LOCAL, PRINTER_ENUM_CONNECTIONS = 0x2, 0x4
    necesario, cuantas = wintypes.DWORD(0), wintypes.DWORD(0)
    flags = PRINTER_ENUM_LOCAL | PRINTER_ENUM_CONNECTIONS
    winspool.EnumPrintersW(flags, None, 4, None, 0, ctypes.byref(necesario), ctypes.byref(cuantas))
    nombres = []
    if necesario.value:
        buf = ctypes.create_string_buffer(necesario.value)
        if winspool.EnumPrintersW(flags, None, 4, buf, necesario, ctypes.byref(necesario), ctypes.byref(cuantas)):
            arr = (INFO4 * cuantas.value).from_buffer(buf)
            nombres = [arr[i].pPrinterName for i in range(cuantas.value)]
    n = wintypes.DWORD(0)
    winspool.GetDefaultPrinterW(None, ctypes.byref(n))
    predeterminada = ""
    if n.value:
        b = ctypes.create_unicode_buffer(n.value)
        if winspool.GetDefaultPrinterW(b, ctypes.byref(n)):
            predeterminada = b.value
    return [(x, x == predeterminada) for x in nombres]


def _impresoras_cups():
    import shutil
    import subprocess
    if not shutil.which("lpstat"):
        return []
    try:
        todas = subprocess.run(["lpstat", "-e"], capture_output=True, text=True, timeout=5).stdout.split()
        d = subprocess.run(["lpstat", "-d"], capture_output=True, text=True, timeout=5).stdout
    except (OSError, subprocess.SubprocessError):
        return []
    pred = d.split(":")[-1].strip() if ":" in d else ""
    return [(x, x == pred) for x in todas]
