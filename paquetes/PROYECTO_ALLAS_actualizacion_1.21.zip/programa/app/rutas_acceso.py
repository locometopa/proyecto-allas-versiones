"""PROYECTO ALLAS · rutas de la API: inicio y cierre de sesión, usuarios y bloqueos (se registran desde server.App._registrar)."""


def registrar(app, r, p):

    @r("POST", "/api/login", publica=True)
    def login(req):
        u = p.autenticar(req.body.get("usuario", ""), req.body.get("pin", ""), req.ip)
        return {"token": app.crear_sesion(u, req.ip), "usuario": u}

    @r("POST", "/api/logout")
    def logout(req):
        app.cerrar_sesion(req.token)
        return {"ok": True}

    # --- 3.9: bloqueos por PIN fallidos
    @r("GET", "/api/usuarios/bloqueos", rol=("admin",))
    def bloqueos(req):
        intentos, minutos = p._cfg_acceso()
        return {"bloqueos": p.bloqueos_activos(), "intentos": intentos, "minutos": minutos}

    @r("POST", "/api/usuarios/desbloquear", rol=("admin",))
    def desbloquear(req):
        return p.desbloquear_acceso(req.usuario["id"], req.body.get("clave"))

    @r("GET", "/api/usuarios/login", publica=True)
    def usuarios_login(req):  # lista para la pantalla de acceso (sin datos sensibles)
        return [{"usuario": u["usuario"], "nombre": u["nombre"]} for u in p.usuarios() if u["activo"]]

    # --- permisos por usuario
    @r("GET", r"/api/usuarios/(\d+)/permisos", rol=("admin",))
    def permisos_ver(req, uid):
        return p.catalogo_permisos(int(uid))

    @r("PUT", r"/api/usuarios/(\d+)/permisos", rol=("admin",))
    def permisos_guardar(req, uid):
        return p.guardar_permisos(req.usuario["id"], int(uid), req.body.get("permisos") or [])

    # --- usuarios
    @r("GET", "/api/usuarios", rol=("admin",))
    def usuarios(req):
        return p.usuarios()

    @r("POST", "/api/usuarios", rol=("admin",))
    def usuario_nuevo(req):
        b = req.body
        return {"id": p.crear_usuario(b.get("nombre"), b.get("usuario"), b.get("pin"), b.get("rol"),
                                      req.usuario["id"])}

    @r("PUT", r"/api/usuarios/(\d+)", rol=("admin",))
    def usuario_editar(req, uid):
        b = req.body
        p.actualizar_usuario(int(uid), req.usuario["id"], b.get("nombre"), b.get("rol"),
                             b.get("activo"), b.get("pin"))
        return {"ok": True}
