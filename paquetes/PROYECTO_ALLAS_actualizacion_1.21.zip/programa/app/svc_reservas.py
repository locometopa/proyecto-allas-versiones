"""PROYECTO ALLAS 1.8 · reservas online: motor de reservas dentro del programa (con interruptor en Ajustes).

Una reserva online reserva «una plaza en la zona X» entre dos fechas. Las reservas se guardan en la misma tabla que las de
plataformas (reservas_previstas, origen 'mostrador' o 'web'), así que al entrar la matrícula se enlazan solas con el ticket.
Con el interruptor apagado (por defecto) nada de esto se ve ni se puede usar y el programa funciona como antes.
"""
import re
import secrets
from datetime import timedelta

from .tarifas import calcular_importe
from .utiles import ErrorNegocio

ALFABETO_CODIGO = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"   # sin 0/O ni 1/I para poder dictarlo
ORIGENES = ("mostrador", "web")
MODOS_PAGO = ("parking", "senal", "total")
DEFECTOS = {"reservas_cupo": 0, "reservas_max_plazas": 1, "reservas_antelacion_min_min": 60, "reservas_antelacion_max_dias": 90,
            "reservas_max_dias": 30, "reservas_cancel_horas": 24, "reservas_pago_horas": 24, "reservas_min_minutos": 0,
            "reservas_noshow_min": 0, "reservas_recordatorio_horas": 0}


class SvcReservas:
    # ============================================================ ajustes
    def reservas_online_activas(self):
        return self.cfg("reservas_online_activas") == "1"

    def _exigir_reservas_online(self):
        if not self.reservas_online_activas():
            raise ErrorNegocio("Las reservas online están desactivadas (Ajustes → Reservas online)", 409)

    def _ajuste_res(self, clave):
        v = self.cfg(clave)
        try:
            return int(v) if v not in (None, "") else DEFECTOS[clave]
        except (TypeError, ValueError):
            return DEFECTOS[clave]

    def config_reservas_online(self):
        zonas = [{"id": z["id"], "nombre": z["nombre"], "capacidad": z["capacidad"], "cupo_online": z.get("cupo_online") or 0}
                 for z in self.zonas()]
        return {"activas": self.reservas_online_activas(), "zonas": zonas, **self._config_pago(),
                "publicas": self.cfg("reservas_publicas_activas") == "1", "condiciones": self.cfg("reservas_condiciones") or "",
                "api_url": self.cfg("reservas_url_publica") or "", "web_url": self.cfg("reservas_web_url") or "",
                "origenes": self.cfg("reservas_origenes") or "", "internet": self.cfg("reservas_internet") == "1",
                "proxies": self.cfg("reservas_proxies") or "",
                "relay_activo": self.cfg("reservas_relay_activo") == "1", "relay_url": self.cfg("reservas_relay_url") or "",
                "relay_token_puesto": bool(self.cfg("reservas_relay_token")),
                "pago_online": self.cfg("reservas_pago_online") == "1", "stripe_listo": bool((self.cfg("stripe_clave") or "").strip()) and self.activo("pagos_online_activo", "pagos_online"),
                **{k: self._ajuste_res(k) for k in DEFECTOS}}

    # ------------------------------------------------------------ 1.12: cobro de la reserva (en el parking, señal o pago anticipado)
    def _config_pago(self):
        modo = self.cfg("reservas_pago_modo")
        tipo = self.cfg("reservas_senal_tipo")
        try:
            valor = int(self.cfg("reservas_senal_valor") or 0)
        except (TypeError, ValueError):
            valor = 0
        return {"pago_modo": modo if modo in MODOS_PAGO else "parking", "senal_tipo": tipo if tipo in ("fijo", "porcentaje") else "fijo",
                "senal_valor": valor, "pago_horas": self._ajuste_res("reservas_pago_horas"),
                "pago_instrucciones": self.cfg("reservas_pago_instrucciones") or ""}

    def senal_para(self, importe_cent):
        """Lo que hay que pagar por adelantado de una reserva de «importe_cent» (0 = todo se paga en el parking)."""
        c = self._config_pago()
        importe_cent = int(importe_cent or 0)
        if c["pago_modo"] == "total":
            return importe_cent
        if c["pago_modo"] != "senal" or importe_cent <= 0:
            return 0
        if c["senal_tipo"] == "porcentaje":
            return min(importe_cent, round(importe_cent * max(0, min(100, c["senal_valor"])) / 100))
        return min(importe_cent, max(0, c["senal_valor"]))

    def caducar_reservas_sin_pago(self):
        """Las reservas con señal pendiente que pasan de su plazo se cancelan solas (la plaza vuelve a estar libre)."""
        self.liberar_no_presentadas()   # 1.18: de paso, las que no han llegado a tiempo
        ahora = self.ahora().isoformat(timespec="seconds")
        filas = self.db.q("SELECT id, codigo, matricula, pago_sesion FROM reservas_previstas WHERE estado='pendiente' AND pago='pendiente_pago' "
                          "AND pago_limite IS NOT NULL AND pago_limite < ?", (ahora,))
        if filas and self.pago_online_reservas_activo():   # 1.18: quien acaba de pagar con tarjeta no pierde la reserva por ir justo de tiempo
            ok = []
            for f in filas:
                try:
                    if f["pago_sesion"] and self.confirmar_senal_stripe(f["id"]) == "pagada":
                        continue
                except Exception as e:  # noqa: BLE001  sin conexión con Stripe: la reserva caduca igualmente (si pagó, se le devolverá)
                    from . import errores
                    errores.fallo("reservas.stripe", e)
                ok.append(f)
            filas = ok
        if filas:
            with self.db.transaccion() as c:
                for f in filas:
                    c.execute("UPDATE reservas_previstas SET estado='cancelada', cancelada=? WHERE id=? AND estado='pendiente'", (ahora, f["id"]))
                    self.auditar(c, None, "reserva_online_caducada", f"{f['codigo']} {f['matricula']}: señal sin pagar")
            for f in filas:
                if f["pago_sesion"]:
                    self.cerrar_sesion_pago(f["pago_sesion"])
        return len(filas)

    def marcar_senal_cobrada(self, usuario, rid, metodo=""):
        self._exigir_permiso(usuario, "reservas")
        metodo = str(metodo or "").strip()[:30] or "mostrador"
        r = self.db.q1("SELECT * FROM reservas_previstas WHERE id=? AND origen IN ('mostrador','web')", (int(rid),))
        if not r:
            raise ErrorNegocio("Reserva no encontrada", 404)
        if r["pago"] != "pendiente_pago":
            raise ErrorNegocio("Esta reserva no tiene una señal pendiente de cobro", 409)
        if r["estado"] not in ("pendiente", "usada"):
            raise ErrorNegocio("La reserva ya no está pendiente" + (" (caducó por no pagar a tiempo)" if r["estado"] == "cancelada" else ""), 409)
        with self.db.transaccion() as c:
            c.execute("UPDATE reservas_previstas SET pago='pagada', pago_fecha=?, pago_metodo=?, pago_limite=NULL WHERE id=?",
                      (self.ahora().isoformat(timespec="seconds"), metodo, int(rid)))
            self.aplicar_senal_a_ticket(c, int(rid))   # 1.18: si el vehículo ya está dentro, se descuenta de lo que debe
            self.auditar(c, usuario["id"], "reserva_senal_cobrada", f"{r['codigo']} {r['senal_cent'] / 100:.2f} € ({metodo})")
        if r["pago_sesion"]:   # ya la pagó a mano: la sesión de tarjeta no debe poder pagarse después
            self.cerrar_sesion_pago(r["pago_sesion"])
        return {"ok": True}

    def marcar_senal_devuelta(self, usuario, rid):
        self._exigir_permiso(usuario, "reservas")
        r = self.db.q1("SELECT * FROM reservas_previstas WHERE id=? AND origen IN ('mostrador','web')", (int(rid),))
        if not r or r["pago"] != "a_devolver":
            raise ErrorNegocio("Esta reserva no tiene una señal por devolver", 409)
        with self.db.transaccion() as c:
            c.execute("UPDATE reservas_previstas SET pago='devuelta' WHERE id=?", (int(rid),))
            self.auditar(c, usuario["id"], "reserva_senal_devuelta", f"{r['codigo']} {r['senal_cent'] / 100:.2f} €")
        return {"ok": True}

    def guardar_config_reservas_online(self, usuario, datos):
        def entero(clave, minimo, maximo, etiqueta):
            try:
                n = int(datos.get(clave, self._ajuste_res(clave)) if datos.get(clave) not in ("", None) else self._ajuste_res(clave))
            except (TypeError, ValueError):
                raise ErrorNegocio(f"{etiqueta}: número no válido")
            if not minimo <= n <= maximo:
                raise ErrorNegocio(f"{etiqueta}: debe estar entre {minimo} y {maximo}")
            return n
        vals = {"reservas_cupo": entero("reservas_cupo", 0, 100000, "Plazas para reservas"),
                "reservas_antelacion_min_min": entero("reservas_antelacion_min_min", 0, 10080, "Antelación mínima"),
                "reservas_antelacion_max_dias": entero("reservas_antelacion_max_dias", 1, 730, "Reservar con hasta"),
                "reservas_max_dias": entero("reservas_max_dias", 1, 90, "Duración máxima"),
                "reservas_min_minutos": entero("reservas_min_minutos", 0, 1440, "Duración mínima"),
                "reservas_cancel_horas": entero("reservas_cancel_horas", 0, 720, "Cancelación gratuita hasta"),
                "reservas_max_plazas": entero("reservas_max_plazas", 1, 50, "Plazas por reserva"),
                "reservas_pago_horas": entero("reservas_pago_horas", 1, 720, "Plazo para pagar la señal"),
                "reservas_noshow_min": entero("reservas_noshow_min", 0, 10080, "Liberar si no llega"),
                "reservas_recordatorio_horas": entero("reservas_recordatorio_horas", 0, 168, "Recordatorio por email")}
        modo = str(datos.get("pago_modo") or self._config_pago()["pago_modo"])
        if modo not in MODOS_PAGO:
            raise ErrorNegocio("Forma de cobro no válida")
        tipo = str(datos.get("senal_tipo") or "fijo")
        if tipo not in ("fijo", "porcentaje"):
            raise ErrorNegocio("Tipo de señal no válido")
        try:
            valor = int(datos.get("senal_valor") if datos.get("senal_valor") not in ("", None) else self._config_pago()["senal_valor"])
        except (TypeError, ValueError):
            raise ErrorNegocio("Importe de la señal no válido")
        if tipo == "porcentaje" and not 0 <= valor <= 100:
            raise ErrorNegocio("La señal en porcentaje debe estar entre 1 y 100")
        if tipo == "fijo" and not 0 <= valor <= 1000000:
            raise ErrorNegocio("Importe de la señal no válido")
        if modo == "senal" and valor <= 0:
            raise ErrorNegocio("Indique cuánto es la señal")
        vals.update({"reservas_pago_modo": modo, "reservas_senal_tipo": tipo, "reservas_senal_valor": valor,
                     "reservas_pago_instrucciones": str(datos.get("pago_instrucciones") or "").strip()[:500]})
        activas = "1" if datos.get("activas") in (True, 1, "1", "true") else "0"
        publicas = "1" if datos.get("publicas") in (True, 1, "1", "true") else "0"
        condiciones = str(datos.get("condiciones") or "").strip()[:2000]
        url = str(datos.get("api_url") or "").strip().rstrip("/")[:200]
        if url and not re.fullmatch(r"https?://[A-Za-z0-9.\-\[\]:]+(/[A-Za-z0-9._~/%-]*)?", url):
            raise ErrorNegocio("La dirección del programa debe ser como https://reservas.mi-parking.es o http://192.168.1.20:8080")
        web = str(datos.get("web_url") or "").strip()[:200]
        if web and not re.fullmatch(r"https?://[A-Za-z0-9.\-\[\]:]+(/[A-Za-z0-9._~/%?=&-]*)?", web):
            raise ErrorNegocio("La página de reservas de su web debe ser como https://www.mi-parking.es/reservas")
        origenes = ",".join(x.strip().rstrip("/") for x in str(datos.get("origenes") or "").replace("\n", ",").replace(" ", ",").split(",") if x.strip())[:500]
        for o in origenes.split(","):
            if o and o != "*" and not re.fullmatch(r"https?://[A-Za-z0-9.\-\[\]:]+", o):
                raise ErrorNegocio(f"«{o}» no es una web válida: escriba solo el dominio, como https://www.mi-parking.es")
        proxies = ",".join(x.strip() for x in str(datos.get("proxies") or "").replace("\n", ",").replace(" ", ",").split(",") if x.strip())[:200]
        for x in proxies.split(","):
            if x:
                import ipaddress
                try:
                    ipaddress.ip_address(x)
                except ValueError:
                    raise ErrorNegocio(f"«{x}» no es una dirección IP válida (proxy de confianza)")
        internet = "1" if datos.get("internet") in (True, 1, "1", "true") else "0"
        relay_activo = "1" if datos.get("relay_activo") in (True, 1, "1", "true") else "0"
        relay_url = str(datos.get("relay_url") or "").strip().rstrip("/")[:200]
        if relay_url and not re.fullmatch(r"https?://[A-Za-z0-9.\-\[\]:]+(/[A-Za-z0-9._~/%-]*)?", relay_url):
            raise ErrorNegocio("La dirección del servidor debe ser como https://reservas.mi-parking.es")
        relay_token = str(datos.get("relay_token") or "").strip()
        if relay_token and not re.fullmatch(r"[A-Za-z0-9_\-]{24,100}", relay_token):
            raise ErrorNegocio("La clave del servidor debe tener entre 24 y 100 letras, números, guiones o guiones bajos")
        if relay_activo == "1" and (not relay_url or not (relay_token or self.cfg("reservas_relay_token"))):
            raise ErrorNegocio("Para usar el servidor en la nube indique su dirección y la clave")
        if relay_activo == "1" and relay_url.startswith("http://") and not re.match(r"http://(localhost|127\.0\.0\.1|\[::1\])(:|/|$)", relay_url):
            raise ErrorNegocio("El servidor en la nube debe usar https:// (la clave viaja en cada llamada)")
        pago_online = "1" if datos.get("pago_online") in (True, 1, "1", "true") else "0"
        if pago_online == "1":
            if modo == "parking":
                raise ErrorNegocio("El pago con tarjeta necesita una señal o el pago anticipado (pestaña Cobro)")
            if not (self.cfg("stripe_clave") or "").strip() or not self.activo("pagos_online_activo", "pagos_online"):
                raise ErrorNegocio("Para cobrar con tarjeta active primero los pagos online con Stripe (Ajustes → Pagos online)")
            if not web:
                raise ErrorNegocio("Para cobrar con tarjeta indique la página de reservas de su web (pestaña Web de clientes): allí vuelve el cliente tras pagar")
        cupos = {}
        for z in datos.get("zonas") or []:
            try:
                zid, cupo = int(z["id"]), int(z.get("cupo_online") or 0)
            except (KeyError, TypeError, ValueError):
                raise ErrorNegocio("Cupo de zona no válido")
            if cupo < 0:
                raise ErrorNegocio("El cupo de una zona no puede ser negativo")
            cupos[zid] = cupo
        with self.db.transaccion() as c:
            for k, v in {**vals, "reservas_online_activas": activas, "reservas_publicas_activas": publicas,
                         "reservas_condiciones": condiciones, "reservas_url_publica": url, "reservas_web_url": web,
                         "reservas_origenes": origenes, "reservas_internet": internet, "reservas_proxies": proxies, "reservas_pago_online": pago_online,
                         "reservas_relay_activo": relay_activo, "reservas_relay_url": relay_url,
                         **({"reservas_relay_token": relay_token} if relay_token else {})}.items():
                c.execute("INSERT INTO config(clave, valor) VALUES(?,?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor",
                          (k, str(v)))
            for zid, cupo in cupos.items():
                c.execute("UPDATE zonas SET cupo_online=? WHERE id=?", (cupo, zid))
            self.auditar(c, usuario["id"], "reservas_online_config",
                         f"activas={activas} publicas={publicas} relay={relay_activo} " + " ".join(f"{k}={v}" for k, v in vals.items() if k != "reservas_pago_instrucciones"))
        return self.config_reservas_online()

    # ============================================================ fechas y cupo
    def _fechas_reserva(self, datos, origen):
        from .funciones43 import leer_fecha
        tz = self.ahora().tzinfo
        try:
            d = leer_fecha(datos.get("desde"), datos.get("hora_desde"), tz)
            h = leer_fecha(datos.get("hasta"), datos.get("hora_hasta"), tz, hora_defecto="23:59")
        except ValueError as e:
            raise ErrorNegocio(f"Fecha no válida ({e})")
        if h <= d:
            raise ErrorNegocio("La salida debe ser posterior a la entrada")
        minutos_min = self._ajuste_res("reservas_min_minutos")
        if origen == "web" and minutos_min and h - d < timedelta(minutes=minutos_min):   # 1.17: duración mínima (solo reservas de clientes)
            txt = f"{minutos_min // 60} h" + (f" {minutos_min % 60} min" if minutos_min % 60 else "") if minutos_min >= 60 else f"{minutos_min} minutos"
            raise ErrorNegocio(f"La reserva debe durar al menos {txt}")
        if h - d > timedelta(days=self._ajuste_res("reservas_max_dias")):
            raise ErrorNegocio(f"Una reserva no puede durar más de {self._ajuste_res('reservas_max_dias')} días")
        if not self.abierto_en_momentos(d, h - timedelta(minutes=1)):   # 1.9: ni la entrada ni la salida pueden caer con el parking cerrado
            raise ErrorNegocio("El parking está cerrado a la hora de entrada o de salida elegida (Ajustes → Empresa → Horario)")
        ahora = self.ahora()
        minimo = timedelta(minutes=self._ajuste_res("reservas_antelacion_min_min")) if origen == "web" else timedelta(minutes=-10)
        if d < ahora + minimo:
            raise ErrorNegocio("La entrada ya ha pasado" if origen != "web"
                               else f"Se reserva con al menos {self._ajuste_res('reservas_antelacion_min_min')} minutos de antelación")
        if d > ahora + timedelta(days=self._ajuste_res("reservas_antelacion_max_dias")):
            raise ErrorNegocio(f"Solo se puede reservar con hasta {self._ajuste_res('reservas_antelacion_max_dias')} días de antelación")
        return d, h

    def _cupo_zona(self, c, zona_id):
        """Plazas que se pueden reservar online en esa zona (0 = ninguna)."""
        if zona_id:
            z = c.execute("SELECT cupo_online FROM zonas WHERE id=? AND activa=1", (int(zona_id),)).fetchone()
            if not z:
                raise ErrorNegocio("Zona no encontrada")
            return int(z[0] or 0)
        return self._ajuste_res("reservas_cupo")

    def _ocupacion_maxima(self, c, zona_id, d, h, excluir=None):
        """Máximo de coches con reserva a la vez en esa zona dentro de [d, h) (sin contar la reserva que se está creando).
        Cuentan las reservas pendientes y también las de coches que ya han entrado y siguen dentro: ocupan su plaza reservada
        hasta que salen (si se pasan de la hora de salida se cuentan hasta que salgan)."""
        base = ("SELECT desde, hasta, plazas, estado FROM reservas_previstas WHERE origen IN ('mostrador','web') "
                "AND COALESCE(zona_id,0)=? AND desde < ? AND (estado='pendiente' AND hasta > ? OR estado='usada' AND ticket_id IN "
                "(SELECT id FROM tickets WHERE estado IN ('dentro','pagado')))")
        args = [int(zona_id or 0), h.isoformat(timespec="seconds"), d.isoformat(timespec="seconds")]
        if excluir:
            base += " AND id<>?"
            args.append(int(excluir))
        from .utiles import parse
        ahora = self.ahora()
        eventos = []
        for desde, hasta, plazas, estado in c.execute(base, args).fetchall():
            fin = parse(hasta)
            if estado == "usada" and fin <= ahora:
                fin = h   # se ha pasado de su hora de salida y sigue dentro: se cuenta hasta que salga
            ini, fin = max(parse(desde), d), min(fin, h)
            if fin <= ini:
                continue
            eventos.append((ini, plazas or 1))
            eventos.append((fin, -(plazas or 1)))
        eventos.sort(key=lambda e: (e[0], e[1]))   # al empatar, primero salen (los negativos)
        actual = maximo = 0
        for _, delta in eventos:
            actual += delta
            maximo = max(maximo, actual)
        return maximo

    def _plazas_pedidas(self, datos):
        try:
            v = datos.get("plazas")
            n = 1 if v in (None, "") else int(v)
        except (TypeError, ValueError):
            raise ErrorNegocio("Número de plazas no válido")
        mx = self._ajuste_res("reservas_max_plazas")
        if not 1 <= n <= mx:
            raise ErrorNegocio("Cada reserva es de 1 plaza" if mx == 1 else f"Cada reserva puede ser de 1 a {mx} plazas")
        return n

    def disponibilidad_reservas(self, zona_id, desde, hasta, origen="mostrador", plazas=1):
        self.caducar_reservas_sin_pago()
        self._exigir_reservas_online()
        plazas = self._plazas_pedidas({"plazas": plazas})
        d, h = self._fechas_reserva({"desde": desde, "hasta": hasta}, origen)
        with self.db.transaccion() as c:
            cupo = self._cupo_zona(c, zona_id)
            usadas = self._ocupacion_maxima(c, zona_id, d, h)
        return {"cupo": cupo, "reservadas": usadas, "libres": max(0, cupo - usadas), "disponible": usadas + plazas <= cupo}

    def calendario_reservas(self, zona_id, desde_dia, dias=31):
        """Plazas libres por día (para pintar el calendario de la pantalla de reservas)."""
        self._exigir_reservas_online()
        from datetime import date, datetime
        try:
            ini = date.fromisoformat(str(desde_dia)[:10])
        except ValueError:
            raise ErrorNegocio("Fecha no válida")
        dias = max(1, min(62, int(dias or 31)))
        tz = self.ahora().tzinfo
        salida = []
        with self.db.transaccion() as c:
            cupo = self._cupo_zona(c, zona_id)
            for i in range(dias):
                dia = ini + timedelta(days=i)
                d = datetime(dia.year, dia.month, dia.day, tzinfo=tz)
                usadas = self._ocupacion_maxima(c, zona_id, d, d + timedelta(days=1))
                salida.append({"dia": dia.isoformat(), "libres": max(0, cupo - usadas), "cupo": cupo})
        return salida

    # ============================================================ precio
    def presupuesto_reserva(self, datos, origen="mostrador"):
        """Precio de la estancia con la tarifa normal que le tocaría a esa entrada (sin descuentos ni servicios)."""
        self._exigir_reservas_online()
        d, h = self._fechas_reserva(datos, origen)
        tipo = (str(datos.get("tipo_vehiculo") or "").strip()[:30] or None)
        t = self.tarifa_para(d, tipo)
        if not t:
            raise ErrorNegocio("No hay tarifa activa disponible")
        t = self.tarifa(t["id"])
        minutos = int((h - d).total_seconds() // 60)
        plazas = self._plazas_pedidas(datos)
        return {"minutos": minutos, "tarifa": t["nombre"], "plazas": plazas,
                "importe_cent": calcular_importe(minutos, t, t["tramos"]) * plazas,
                "senal_cent": self.senal_para(calcular_importe(minutos, t, t["tramos"]) * plazas)}

    # ============================================================ crear y cancelar
    def _codigo_reserva(self, c):
        for _ in range(20):
            cod = "R-" + "".join(secrets.choice(ALFABETO_CODIGO) for _ in range(6))
            if not c.execute("SELECT 1 FROM reservas_previstas WHERE codigo=?", (cod,)).fetchone():
                return cod
        raise ErrorNegocio("No se pudo generar el código de la reserva, inténtelo de nuevo", 500)

    def crear_reserva_online(self, usuario, datos, origen="mostrador"):
        self._exigir_reservas_online()
        self.caducar_reservas_sin_pago()
        if origen not in ORIGENES:
            raise ErrorNegocio("Origen de reserva no válido")
        if usuario:
            self._exigir_permiso(usuario, "reservas")
        mat = self._norm_mat_reserva(datos.get("matricula"))
        plazas = self._plazas_pedidas(datos)
        d, h = self._fechas_reserva(datos, origen)
        zonas = self.zonas()
        zona_id = int(datos["zona_id"]) if datos.get("zona_id") not in (None, "") else (zonas[0]["id"] if zonas else None)
        if zonas and not zona_id:
            raise ErrorNegocio("Elija la zona")
        tipo = (str(datos.get("tipo_vehiculo") or "").strip()[:30] or None)
        limpio = lambda k, n: (str(datos.get(k) or "").strip()[:n] or None)   # noqa: E731
        email, tel, nombre = limpio("email", 120), limpio("telefono", 30), limpio("cliente", 80)
        if email and ("@" not in email or " " in email):
            raise ErrorNegocio("Email no válido")
        precio = self.presupuesto_reserva(datos, origen)["importe_cent"]
        with self.db.transaccion() as c:   # la comprobación del cupo y la inserción van juntas: dos reservas a la vez no pasan del cupo
            cupo = self._cupo_zona(c, zona_id)
            if self._ocupacion_maxima(c, zona_id, d, h) + plazas > cupo:
                raise ErrorNegocio("No quedan plazas libres en esas fechas" if cupo else
                                   "Esta zona no admite reservas online (cupo 0 en Ajustes → Reservas online)", 409)
            if c.execute("SELECT 1 FROM reservas_previstas WHERE matricula=? AND estado='pendiente' AND desde < ? AND hasta > ?",
                         (mat, h.isoformat(timespec="seconds"), d.isoformat(timespec="seconds"))).fetchone():
                raise ErrorNegocio(f"La matrícula {mat} ya tiene una reserva en esas fechas", 409)
            codigo = self._codigo_reserva(c)
            rid = c.execute("INSERT INTO reservas_previstas(matricula, desde, hasta, ref, plataforma, cliente, nota, tarifa_id, estado, "
                            "creada, usuario_id, origen, zona_id, tipo_vehiculo, email, telefono, codigo, importe_cent, pago, plazas, revisada) "
                            "VALUES(?,?,?,?,?,?,?,NULL,'pendiente',?,?,?,?,?,?,?,?,?,'en_parking',?,?)",
                            (mat, d.isoformat(timespec="seconds"), h.isoformat(timespec="seconds"), codigo, "Online" if origen == "web" else "Mostrador",
                             nombre, limpio("nota", 200), self.ahora().isoformat(timespec="seconds"),
                             usuario["id"] if usuario else None, origen, zona_id, tipo, email, tel, codigo, precio, plazas,
                             0 if origen == "web" else 1)).lastrowid
            senal = self.senal_para(precio)
            if senal and usuario and datos.get("senal_cobrada") in (True, 1, "1", "true"):   # el personal la cobra al reservar
                pago, limite, fecha = "pagada", None, self.ahora().isoformat(timespec="seconds")
            elif senal:
                pago, fecha = "pendiente_pago", None
                limite = min(self.ahora() + timedelta(hours=self._ajuste_res("reservas_pago_horas")), d).isoformat(timespec="seconds")   # nunca después de la entrada
            else:
                pago, limite, fecha = "en_parking", None, None
            c.execute("UPDATE reservas_previstas SET pago=?, senal_cent=?, pago_limite=?, pago_fecha=?, pago_metodo=? WHERE id=?",
                      (pago, senal, limite, fecha, (str(datos.get("senal_metodo") or "mostrador")[:30] if pago == "pagada" else None), rid))
            self.auditar(c, usuario["id"] if usuario else None, "reserva_online",
                         f"{codigo} {mat} {d:%Y-%m-%d %H:%M}→{h:%Y-%m-%d %H:%M} zona={zona_id} {origen}" + (f" señal={senal / 100:.2f} € {pago}" if senal else ""))
        return self.db.q1("SELECT * FROM reservas_previstas WHERE id=?", (rid,))

    @staticmethod
    def _norm_mat_reserva(m):
        from .utiles import norm_matricula
        mat = norm_matricula(m)
        if not mat or not 3 <= len(mat) <= 12:
            raise ErrorNegocio("Matrícula no válida")
        return mat

    def cancelar_reserva_online(self, usuario, rid, como_cliente=False):
        """El personal cancela cuando quiera; el cliente solo dentro del plazo de cancelación gratuita."""
        self._exigir_reservas_online()
        if usuario:
            self._exigir_permiso(usuario, "reservas")
        r = self.db.q1("SELECT * FROM reservas_previstas WHERE id=? AND origen IN ('mostrador','web')", (int(rid),))
        if not r:
            raise ErrorNegocio("Reserva no encontrada", 404)
        if r["estado"] != "pendiente":
            raise ErrorNegocio("Solo se pueden cancelar las reservas pendientes", 409)
        if como_cliente:
            from .utiles import parse
            limite = parse(r["desde"]) - timedelta(hours=self._ajuste_res("reservas_cancel_horas"))
            if self.ahora() > limite:
                raise ErrorNegocio(f"La cancelación gratuita terminó {self._ajuste_res('reservas_cancel_horas')} horas antes de la entrada", 409)
        with self.db.transaccion() as c:
            devolver = r["pago"] == "pagada"
            c.execute("UPDATE reservas_previstas SET estado='cancelada', cancelada=?, pago=CASE WHEN pago='pagada' THEN 'a_devolver' ELSE pago END "
                      "WHERE id=? AND estado='pendiente'", (self.ahora().isoformat(timespec="seconds"), int(rid)))
            self.auditar(c, usuario["id"] if usuario else None, "reserva_online_cancelar",
                         f"{r['codigo']} {r['matricula']}" + (f" (señal {r['senal_cent'] / 100:.2f} € a devolver)" if devolver else ""))
        reembolsada = False
        if devolver and r.get("pago_ref"):   # 1.18: pagada con tarjeta online → se devuelve sola por Stripe
            reembolsada = self.reembolsar_senal_auto(r["id"])
        elif r.get("pago_sesion") and not r.get("pago_ref"):
            self.cerrar_sesion_pago(r["pago_sesion"])
        return {"ok": True, "devolver_senal": devolver and not reembolsada, "reembolsada": reembolsada}

    def resumen_reservas_online(self):
        hoy = self.ahora().date().isoformat()
        q = lambda w: self.db.q1("SELECT COUNT(*) n FROM reservas_previstas WHERE origen IN ('mostrador','web') AND " + w, (hoy,))["n"]   # noqa: E731
        return {"a_devolver": self.db.q1("SELECT COUNT(*) n FROM reservas_previstas WHERE pago='a_devolver'")["n"],
                "senal_pendiente": self.db.q1("SELECT COUNT(*) n FROM reservas_previstas WHERE estado='pendiente' AND pago='pendiente_pago'")["n"],
                "llegan_hoy": q("estado='pendiente' AND substr(desde,1,10)=?"),
                "salen_hoy": q("estado IN ('pendiente','usada') AND substr(hasta,1,10)=?"),
                "futuras": q("estado='pendiente' AND substr(hasta,1,10)>=?")}

    # ============================================================ 1.11: avisos al personal
    def reservas_por_revisar(self):
        """Reservas hechas por clientes en la página pública que el personal aún no ha confirmado ni cancelado."""
        return self.db.q("SELECT r.*, z.nombre zona_nombre FROM reservas_previstas r LEFT JOIN zonas z ON z.id=r.zona_id "
                         "WHERE r.origen='web' AND r.estado='pendiente' AND r.revisada=0 ORDER BY r.id LIMIT 50")

    def n_reservas_por_revisar(self):
        return self.db.q1("SELECT COUNT(*) n FROM reservas_previstas WHERE origen='web' AND estado='pendiente' AND revisada=0")["n"]

    def confirmar_reserva_online(self, usuario, rid):
        """El personal da por vista la reserva de un cliente (la plaza ya estaba garantizada; esto solo quita el aviso)."""
        self._exigir_permiso(usuario, "reservas")
        with self.db.transaccion() as c:
            r = c.execute("SELECT codigo, matricula, estado FROM reservas_previstas WHERE id=? AND origen IN ('mostrador','web')",
                          (int(rid),)).fetchone()
            if not r:
                raise ErrorNegocio("Reserva no encontrada", 404)
            c.execute("UPDATE reservas_previstas SET revisada=1 WHERE id=?", (int(rid),))
            self.auditar(c, usuario["id"], "reserva_online_confirmar", f"{r[0]} {r[1]}")
        return {"ok": True}

    def aviso_reserva(self, texto):
        """Busca la reserva de un vehículo (por matrícula) o de un código R-XXXXXX (el QR que recibe el cliente) y dice
        si se aplicaría si entra ahora. Sirve para todas las reservas: online, de mostrador y de plataformas."""
        from .utiles import norm_matricula, parse
        self.caducar_reservas_sin_pago()
        t = str(texto or "").strip().upper()
        if not t:
            return {"reserva": None}
        ahora = self.ahora()
        margen = timedelta(minutes=int(self.cfg("reservas_margen_min") or 120))
        if re.fullmatch(r"R-[A-Z0-9]{6}", t):
            r = self.db.q1("SELECT r.*, z.nombre zona_nombre, tk.codigo ticket_codigo FROM reservas_previstas r "
                           "LEFT JOIN zonas z ON z.id=r.zona_id LEFT JOIN tickets tk ON tk.id=r.ticket_id WHERE r.codigo=?", (t,))
        else:
            mat = norm_matricula(t)
            if not mat:
                return {"reserva": None}
            r = None
            for x in self.db.q("SELECT r.*, z.nombre zona_nombre, tk.codigo ticket_codigo FROM reservas_previstas r "
                               "LEFT JOIN zonas z ON z.id=r.zona_id LEFT JOIN tickets tk ON tk.id=r.ticket_id "
                               "WHERE r.matricula=? AND r.estado='pendiente' ORDER BY r.desde", (mat,)):
                if parse(x["hasta"]) > ahora:
                    r = x
                    break
        if not r:
            return {"reserva": None}
        if r["estado"] == "pendiente":
            if ahora >= parse(r["hasta"]):
                motivo, aplica = "caducada", False
            elif ahora < parse(r["desde"]) - margen:
                motivo, aplica = "antes", False
            else:
                motivo, aplica = "ok", True
        else:
            motivo, aplica = ("no_presentada" if r.get("noshow") else r["estado"]), False   # usada / cancelada
        for k in ("email", "telefono", "condiciones", "email_estado", "email_intentos"):
            r.pop(k, None)   # el aviso no necesita datos personales del cliente
        return {"reserva": r, "aplica": aplica, "motivo": motivo,
                "ventana_desde": (parse(r["desde"]) - margen).isoformat(timespec="seconds")}

    def reservas_llegadas(self):
        """Reservas pendientes que llegan hoy (o que ya se admiten por la ventana de llegada): para el panel de Entrada."""
        from .utiles import parse
        self.caducar_reservas_sin_pago()
        ahora = self.ahora()
        margen = timedelta(minutes=int(self.cfg("reservas_margen_min") or 120))
        fin_dia = ahora.replace(hour=23, minute=59, second=59, microsecond=0)
        filas = self.db.q("SELECT r.id, r.matricula, r.codigo, r.ref, r.plataforma, r.origen, r.cliente, r.desde, r.hasta, r.plazas, r.pago, r.senal_cent, "
                          "z.nombre zona_nombre FROM reservas_previstas r LEFT JOIN zonas z ON z.id=r.zona_id "
                          "WHERE r.estado='pendiente' AND r.hasta > ? ORDER BY r.desde LIMIT 200", (ahora.isoformat(timespec="seconds"),))
        res = []
        for f in filas:
            d = parse(f["desde"])
            if d - margen <= ahora or d <= fin_dia:
                f["aplica"] = d - margen <= ahora
                res.append(f)
        return res[:40]
