"""PROYECTO ALLAS 4.53 · eliminar usuarios y control de turnos (fichaje) por QR.

Eliminar un usuario lo ARCHIVA: desaparece de las listas, no puede entrar y su nombre de usuario queda libre, pero sus
tickets, turnos y cobros conservan su nombre (el historial contable no se toca).
El control de turnos por QR es opcional (Ajustes → Empresa → Usuarios): cada usuario tiene un QR personal; al escanearlo
se registra el comienzo o el fin de su jornada. Es independiente del turno de caja.
"""
import re
import secrets
from datetime import timedelta
from . import errores


def _sv():
    from . import servicios
    return servicios


ANTIREBOTE_SEG = 20   # un mismo QR leído dos veces seguidas (rebote del lector o doble clic) cuenta una sola vez


class Funciones50:
    # ============================================================== eliminar usuarios
    def eliminar_usuario(self, uid, actor_id):
        sv = _sv()
        with self.db.transaccion() as c:
            u = c.execute("SELECT * FROM usuarios WHERE id=?", (uid,)).fetchone()
            if not u or u["eliminado"]:
                raise sv.ErrorNegocio("Usuario no encontrado", 404)
            if uid == actor_id:
                raise sv.ErrorNegocio("No puede eliminarse a sí mismo")
            if c.execute("SELECT 1 FROM turnos WHERE usuario_id=? AND estado='abierto'", (uid,)).fetchone():
                raise sv.ErrorNegocio("Tiene un turno de caja abierto: ciérrelo antes de eliminarlo")
            if u["rol"] == "admin" and u["activo"] and not c.execute(
                    "SELECT 1 FROM usuarios WHERE rol='admin' AND activo=1 AND eliminado=0 AND id<>?", (uid,)).fetchone():
                raise sv.ErrorNegocio("Debe quedar al menos un administrador activo")
            c.execute("UPDATE usuarios SET eliminado=1, activo=0, usuario=?, qr_token=NULL WHERE id=?",
                      (f"{u['usuario']}~eliminado{uid}", uid))
            c.execute("DELETE FROM sesiones WHERE usuario_id=?", (uid,))
            c.execute("UPDATE fichajes SET salida=? WHERE usuario_id=? AND salida IS NULL", (sv.iso(self.ahora()), uid))
            self.auditar(c, actor_id, "usuario_eliminar", f"{u['usuario']} (id={uid})")
        return {"ok": True}

    # ============================================================== control de turnos por QR (rehecho en 4.53)
    # El QR lleva «FICHA» + 12 dígitos. Sin signos ni mayúsculas/minúsculas mezcladas: así el lector del equipo, que «teclea» el código,
    # lo escribe igual con cualquier distribución de teclado, con Bloq Mayús o con prefijos/sufijos del lector.
    def fichaje_activo(self):
        return self.cfg("fichaje_qr_activo") == "1"

    def fichaje_modo_turno(self):
        """no | abrir (ficha la entrada al abrir el turno de caja) | ambos (también la salida al cerrarlo)."""
        m = self.cfg("fichaje_auto_turno")
        return m if m in ("abrir", "ambos") else "no"

    def qr_usuario(self, uid, regenerar=False):
        """Código personal del QR (se crea la primera vez que se pide)."""
        sv = _sv()
        with self.db.transaccion() as c:
            u = c.execute("SELECT id, nombre, usuario, qr_token FROM usuarios WHERE id=? AND eliminado=0", (uid,)).fetchone()
            if not u:
                raise sv.ErrorNegocio("Usuario no encontrado", 404)
            tok = u["qr_token"]
            if not tok or regenerar or not re.fullmatch(r"\d{12}", tok):
                while True:
                    tok = "".join(secrets.choice("0123456789") for _ in range(12))
                    if not c.execute("SELECT 1 FROM usuarios WHERE qr_token=?", (tok,)).fetchone():
                        break
                c.execute("UPDATE usuarios SET qr_token=? WHERE id=?", (tok, uid))
                if regenerar:
                    self.auditar(c, None, "fichaje_qr_regenerar", f"usuario id={uid}")
        return {"id": u["id"], "nombre": u["nombre"], "usuario": u["usuario"], "token": tok}

    @staticmethod
    def _token_de_lectura(texto):
        """Saca los 12 dígitos de lo que haya leído el lector (admite minúsculas, signos y caracteres extra del lector)."""
        limpio = re.sub(r"[^A-Za-z0-9]", "", texto or "").upper()
        m = re.search(r"FICHA(\d{12})", limpio)
        return m.group(1) if m else ""

    @staticmethod
    def es_lectura_fichaje(texto):
        return bool(re.search(r"FICHA\d{12}", re.sub(r"[^A-Za-z0-9]", "", texto or "").upper()))

    def _turno_abierto_de(self, c, uid):
        t = c.execute("SELECT id FROM turnos WHERE usuario_id=? AND estado='abierto' ORDER BY id DESC LIMIT 1", (uid,)).fetchone()
        return t["id"] if t else None

    def _usuario_de_lectura(self, texto, origen=None):
        sv = _sv()
        if not self.fichaje_activo():
            raise sv.ErrorNegocio("El control de turnos por QR no está activado", 403)
        tok = self._token_de_lectura(texto)
        clave = [(f"ip:{origen}", 40)] if origen else []
        for k, _ in clave:
            if self._bloqueo(k):
                raise sv.ErrorNegocio("Demasiados códigos no válidos seguidos. Espere unos minutos.", 429)
        u = self.db.q1("SELECT id, nombre FROM usuarios WHERE qr_token=? AND activo=1 AND eliminado=0", (tok,)) if tok else None
        if not u:
            if clave:
                self._fallo_acceso(clave)
            raise sv.ErrorNegocio("Código de fichaje no válido. Si el QR es antiguo, imprima uno nuevo en Ajustes → Empresa → Usuarios.", 404)
        return u

    def fichaje_confirmar_salida(self):
        """Opcional (Ajustes → Empresa → Usuarios): pedir confirmación, con el resumen del turno, antes de fichar una salida."""
        return self.cfg("fichaje_confirmar_salida") != "0"

    def fichaje_previa(self, texto, origen=None):
        """Qué pasaría al fichar con este código (sin registrar nada): entrada o salida y, si es salida, el resumen de la jornada y del turno de caja."""
        sv = _sv()
        u = self._usuario_de_lectura(texto, origen)
        ult = self.db.q1("SELECT * FROM fichajes WHERE usuario_id=? ORDER BY id DESC LIMIT 1", (u["id"],))
        dentro = bool(ult and not ult["salida"])
        ahora = self.ahora()
        reciente = bool(ult and ahora - sv.parse(ult["salida"] or ult["entrada"]) < timedelta(seconds=ANTIREBOTE_SEG))
        out = {"usuario": u["nombre"], "accion": "salida" if dentro else "entrada", "confirmar": bool(dentro and self.fichaje_confirmar_salida() and not reciente),
               "desde": ult["entrada"] if dentro else None, "minutos": int((ahora - sv.parse(ult["entrada"])).total_seconds() // 60) if dentro else None, "turno": None}
        t = self.db.q1("SELECT id FROM turnos WHERE usuario_id=? AND estado='abierto' ORDER BY id DESC LIMIT 1", (u["id"],))
        if dentro and t:
            r = self.resumen_turno(t["id"])
            out["turno"] = {"id": r["id"], "apertura": r["apertura"], "entradas": r.get("num_entradas", 0), "cobros": r.get("num_cobros", 0),
                            "efectivo_cent": r.get("cobrado_efectivo_cent", 0), "tarjeta_cent": r.get("cobrado_tarjeta_cent", 0),
                            "auto_cierre": self.fichaje_modo_turno() == "ambos"}
        return out

    def fichar(self, texto, origen=None):
        return self._registrar_fichaje(self._usuario_de_lectura(texto, origen), origen)

    def _registrar_fichaje(self, u, origen=None, forzar=None):
        """Alterna entrada/salida. forzar='entrada'|'salida' (fichaje automático con el turno): no hace nada si ya está en ese estado."""
        sv = _sv()
        ahora = self.ahora()
        with self.db.transaccion() as c:
            ult = c.execute("SELECT * FROM fichajes WHERE usuario_id=? ORDER BY id DESC LIMIT 1", (u["id"],)).fetchone()
            ult = dict(ult) if ult else None
            dentro = bool(ult and not ult["salida"])
            if forzar and (forzar == "entrada") == dentro:
                return None
            turno = self._turno_abierto_de(c, u["id"])
            if not forzar and ult:
                ultimo_mov = sv.parse(ult["salida"] or ult["entrada"])
                if ahora - ultimo_mov < timedelta(seconds=ANTIREBOTE_SEG):
                    return self._resp_fichaje(u, "salida" if ult["salida"] else "entrada", ult, repetido=True, turno=turno)
            if dentro:
                c.execute("UPDATE fichajes SET salida=?, turno_id=COALESCE(turno_id, ?) WHERE id=?", (sv.iso(ahora), turno, ult["id"]))
                accion = "salida"
                fila = dict(ult, salida=sv.iso(ahora))
            else:
                cur = c.execute("INSERT INTO fichajes(usuario_id, entrada, origen, turno_id) VALUES(?,?,?,?)", (u["id"], sv.iso(ahora), origen, turno))
                accion = "entrada"
                fila = {"id": cur.lastrowid, "entrada": sv.iso(ahora), "salida": None}
            self.auditar(c, u["id"], "fichaje_" + accion, origen or "")
        return self._resp_fichaje(u, accion, fila, turno=turno)

    def fichaje_auto(self, uid, momento):
        """Fichaje automático ligado al turno de caja. momento: 'abrir' | 'cerrar'. Nunca hace fallar la operación de caja."""
        try:
            if not self.fichaje_activo():
                return None
            modo = self.fichaje_modo_turno()
            if modo == "no" or (momento == "cerrar" and modo != "ambos"):
                return None
            u = self.db.q1("SELECT id, nombre FROM usuarios WHERE id=? AND activo=1 AND eliminado=0", (uid,))
            return self._registrar_fichaje(u, "turno de caja", "entrada" if momento == "abrir" else "salida") if u else None
        except Exception as e_:
            errores.fallo("funciones50.fichaje_auto", e_)
            return None

    def _resp_fichaje(self, u, accion, fila, repetido=False, turno=None):
        sv = _sv()
        ent = sv.parse(fila["entrada"])
        sal = sv.parse(fila["salida"]) if fila.get("salida") else None
        hora = (sal or ent).strftime("%H:%M")
        minutos = int((sal - ent).total_seconds() // 60) if sal else None
        return {"usuario": u["nombre"], "accion": accion, "hora": hora, "minutos": minutos, "repetido": repetido, "turno_id": turno}

    def cerrar_fichaje(self, fid, actor_id):
        """Cierra una jornada que se quedó abierta (el empleado olvidó fichar la salida)."""
        sv = _sv()
        with self.db.transaccion() as c:
            f = c.execute("SELECT * FROM fichajes WHERE id=?", (fid,)).fetchone()
            if not f:
                raise sv.ErrorNegocio("Fichaje no encontrado", 404)
            if f["salida"]:
                raise sv.ErrorNegocio("Ese fichaje ya tiene salida")
            c.execute("UPDATE fichajes SET salida=?, cerrado_por=? WHERE id=?", (sv.iso(self.ahora()), actor_id, fid))
            self.auditar(c, actor_id, "fichaje_cerrar", f"id={fid}")
        return {"ok": True}

    def fichajes(self, desde=None, hasta=None, usuario_id=None):
        """Jornadas registradas: filas y total de minutos por usuario. desde/hasta: AAAA-MM-DD (por defecto, los últimos 14 días)."""
        sv = _sv()
        hoy = self.ahora().date()
        d = (desde or (hoy - timedelta(days=13)).isoformat())[:10]
        h = (hasta or hoy.isoformat())[:10]
        sql = ("SELECT f.id, f.usuario_id, u.nombre usuario_nombre, f.entrada, f.salida, f.origen, f.turno_id FROM fichajes f "
               "JOIN usuarios u ON u.id=f.usuario_id WHERE substr(f.entrada,1,10)>=? AND substr(f.entrada,1,10)<=?")
        par = [d, h]
        if usuario_id:
            sql += " AND f.usuario_id=?"
            par.append(int(usuario_id))
        filas = self.db.q(sql + " ORDER BY f.entrada DESC LIMIT 2000", tuple(par))
        ahora = self.ahora()
        res = {}
        out = []
        for f in filas:
            ent = sv.parse(f["entrada"])
            sal = sv.parse(f["salida"]) if f["salida"] else None
            mins = int(((sal or ahora) - ent).total_seconds() // 60)
            out.append({**dict(f), "minutos": mins, "abierto": sal is None})
            r = res.setdefault(f["usuario_id"], {"usuario_id": f["usuario_id"], "usuario_nombre": f["usuario_nombre"], "minutos": 0, "jornadas": 0, "dentro": False})
            r["minutos"] += mins
            r["jornadas"] += 1
            r["dentro"] = r["dentro"] or sal is None
        return {"activo": self.fichaje_activo(), "desde": d, "hasta": h, "filas": out,
                "resumen": sorted(res.values(), key=lambda x: x["usuario_nombre"])}

    def fichajes_csv(self, desde=None, hasta=None, usuario_id=None):
        sv = _sv()
        datos = self.fichajes(desde, hasta, usuario_id)
        lin = ["Fecha;Usuario;Entrada;Salida;Minutos;Horas;Turno de caja"]
        for f in reversed(datos["filas"]):
            ent = sv.parse(f["entrada"])
            sal = sv.parse(f["salida"]) if f["salida"] else None
            lin.append(";".join([ent.strftime("%d/%m/%Y"), f["usuario_nombre"].replace(";", ","), ent.strftime("%H:%M"),
                                 sal.strftime("%H:%M") if sal else "(abierta)", str(f["minutos"]), f"{f['minutos'] / 60:.2f}".replace(".", ","), str(f.get("turno_id") or "")]))
        return "﻿" + "\r\n".join(lin) + "\r\n"

    # ============================================================== 4.50: comentarios internos e historial del vehículo
    def nota_vehiculo(self, matricula):
        m = _sv().norm_matricula(matricula)
        if not m:
            return None
        return self.db.q1("SELECT n.matricula, n.nota, n.actualizada, u.nombre usuario FROM notas_vehiculo n "
                          "LEFT JOIN usuarios u ON u.id=n.usuario_id WHERE n.matricula=?", (m,))

    def guardar_nota_vehiculo(self, usuario, matricula, nota):
        """Comentario interno de un vehículo (no sale en tickets ni facturas). Vacío = quitarlo."""
        sv = _sv()
        m = sv.norm_matricula(matricula)
        if not m:
            raise sv.ErrorNegocio("El comentario se guarda por matrícula: este vehículo no tiene")
        nota = (nota or "").strip()[:500]
        with self.db.transaccion() as c:
            if not nota:
                c.execute("DELETE FROM notas_vehiculo WHERE matricula=?", (m,))
                self.auditar(c, usuario["id"], "vehiculo_nota_quitar", m)
            else:
                c.execute("INSERT INTO notas_vehiculo(matricula, nota, usuario_id, actualizada) VALUES(?,?,?,?) "
                          "ON CONFLICT(matricula) DO UPDATE SET nota=excluded.nota, usuario_id=excluded.usuario_id, actualizada=excluded.actualizada",
                          (m, nota, usuario["id"], sv.iso(self.ahora())))
                self.auditar(c, usuario["id"], "vehiculo_nota", f"{m}: {nota[:80]}")
        return {"matricula": m, "nota": nota}

    def historial_vehiculo(self, matricula, limite=200):
        """Visitas anteriores de una matrícula: entradas, salidas, tiempo y lo pagado, con totales."""
        sv = _sv()
        m = sv.norm_matricula(matricula)
        if not m:
            raise sv.ErrorNegocio("Matrícula no válida")
        ahora = self.ahora()
        filas = self.db.q(
            "SELECT t.id, t.codigo, t.entrada, t.salida, t.estado, t.manual, "
            "(SELECT nombre FROM tarifas WHERE id=t.tarifa_id) tarifa_nombre, "
            "COALESCE((SELECT SUM(importe_cent) FROM pagos WHERE ticket_id=t.id), 0) pagado_cent "
            "FROM tickets t WHERE t.matricula=? ORDER BY t.entrada DESC LIMIT ?", (m, int(limite)))
        visitas, total, mins = 0, 0, 0
        for f in filas:
            fin = sv.parse(f["salida"]) if f["salida"] else ahora
            f["minutos"] = max(0, int((fin - sv.parse(f["entrada"])).total_seconds() // 60))
            if f["estado"] != "anulado":
                visitas += 1
                total += f["pagado_cent"]
                mins += f["minutos"]
        cli = self.db.q1("SELECT c.nombre FROM cliente_matriculas cm JOIN clientes c ON c.id=cm.cliente_id WHERE cm.matricula=?", (m,))
        return {"matricula": m, "cliente": cli["nombre"] if cli else None, "nota": self.nota_vehiculo(m),
                "visitas": visitas, "total_cent": total, "media_min": (mins // visitas) if visitas else 0,
                "primera": filas[-1]["entrada"] if filas else None, "filas": filas}

    # ============================================================== QR del personal: datos, impresión, PDF y correo
    OPCIONES_QR = {"fichaje_qr_mostrar_parking": "1", "fichaje_qr_mostrar_nombre": "1", "fichaje_qr_texto_sup": "",
                   "fichaje_qr_texto_inf": "Pase este código por el lector para fichar entrada o salida", "fichaje_qr_texto_pie": "", "fichaje_qr_tam": "10"}

    def opciones_qr(self):
        """Textos y tamaño opcionales del QR impreso (los mismos para ticket, PDF y vista previa)."""
        o = {k: (self.cfg(k) if self.cfg(k) is not None else v) for k, v in self.OPCIONES_QR.items()}
        try:
            tam = max(4, min(15, int(o["fichaje_qr_tam"])))
        except (TypeError, ValueError):
            tam = 10
        return {"parking": o["fichaje_qr_mostrar_parking"] == "1", "nombre": o["fichaje_qr_mostrar_nombre"] == "1",
                "sup": o["fichaje_qr_texto_sup"].strip(), "inf": o["fichaje_qr_texto_inf"].strip(), "pie": o["fichaje_qr_texto_pie"].strip(), "tam": tam}

    def qr_datos(self, uid, regenerar=False):
        from .codigos import qr_svg
        u = self.qr_usuario(uid, regenerar)
        texto = "FICHA" + u["token"]
        return {**u, "texto": texto, "svg": qr_svg(texto, modulo=6), "nombre_parking": self.cfg("nombre_parking") or "", "opciones": self.opciones_qr()}

    def doc_qr_usuario(self, uid, lineas_corte=None):
        """Tarjeta del QR personal para la impresora de tickets. lineas_corte: papel antes del corte (si no, el de Ajustes)."""
        sv = _sv()
        q = self.qr_usuario(uid)
        o = self.opciones_qr()
        cfg = self._cfg_ticket()
        doc = self._nuevo_doc(cfg)
        if lineas_corte not in (None, ""):
            try:
                doc.lineas_corte = max(0, min(15, int(lineas_corte)))
            except (TypeError, ValueError):
                raise sv.ErrorNegocio("Líneas de corte no válidas")
        doc.alinear("centro")
        if o["sup"]:
            doc.lineas(o["sup"])
        if o["parking"]:
            doc.negrita().alto().linea(cfg.get("nombre_parking") or "PROYECTO ALLAS").alto(False).negrita(False)
        if o["sup"] or o["parking"]:
            doc.espacio()
        doc.qr("FICHA" + q["token"], o["tam"])
        if o["nombre"]:
            doc.espacio().negrita().alto().linea(q["nombre"]).alto(False).negrita(False)
        if o["inf"]:
            doc.lineas(o["inf"])
        if o["pie"]:
            doc.espacio().lineas(o["pie"])
        doc.alinear("izq")
        return doc.cortar()

    def imprimir_qr_usuario(self, actor, uid, lineas_corte=None):
        doc = self.doc_qr_usuario(uid, lineas_corte)
        with self.db.transaccion() as c:
            self.auditar(c, actor["id"], "fichaje_qr_imprimir", f"usuario id={uid}")
        return self._imprimir(doc, "qr_fichaje")

    def pdf_qr_usuario(self, uid):
        from . import pdf
        from .codigos import qr_matriz
        q = self.qr_usuario(uid)
        return pdf.qr_ficha_a_pdf(qr_matriz("FICHA" + q["token"]), self.cfg("nombre_parking") or "PROYECTO ALLAS", q["nombre"], self.opciones_qr())

    def enviar_qr_usuario(self, actor, uid, destino):
        sv = _sv()
        destino = (destino or "").strip()
        if not sv.email_valido(destino):
            raise sv.ErrorNegocio("Indique un email válido")
        if not self.smtp_listo():
            raise sv.ErrorNegocio("Configure antes el correo (Ajustes → Conexiones → Email)", 409)
        from .correo import ErrorCorreo, enviar
        q = self.qr_usuario(uid)
        try:
            enviar(self.db.config(), destino, f"Su QR de fichaje - {self.cfg('nombre_parking') or ''}",
                   f"Hola {q['nombre']}:\n\nAdjuntamos su código QR personal para fichar la entrada y la salida. "
                   "Es personal: no lo comparta.\n", [(f"qr_fichaje_{q['usuario']}.pdf", self.pdf_qr_usuario(uid), "application/pdf")])
        except ErrorCorreo as e:
            raise sv.ErrorNegocio(f"No se pudo enviar: {e}")
        with self.db.transaccion() as c:
            self.auditar(c, actor["id"], "fichaje_qr_email", f"usuario id={uid} → {destino}")
        return {"ok": True, "destino": destino}

    def fichaje_panel(self, usuario=None):
        """Jornada y turno juntos (pantalla Caja y turno): quién está dentro, últimos fichajes y la situación del usuario actual."""
        if not self.fichaje_activo():
            return {"activo": False, "dentro": [], "recientes": [], "modo": "no", "yo": None}
        hoy = self.ahora().date().isoformat()
        filas = self.db.q("SELECT f.id, f.usuario_id, u.nombre usuario_nombre, f.entrada, f.salida, f.turno_id FROM fichajes f JOIN usuarios u ON u.id=f.usuario_id "
                          "WHERE f.salida IS NULL OR substr(f.entrada,1,10)>=? OR substr(f.salida,1,10)>=? ORDER BY COALESCE(f.salida, f.entrada) DESC LIMIT 40",
                          (hoy, hoy))
        dentro = [{"nombre": f["usuario_nombre"], "entrada": f["entrada"], "turno_id": f["turno_id"]} for f in filas if not f["salida"]]
        rec = [{"nombre": f["usuario_nombre"], "accion": "entrada" if not f["salida"] else "salida", "hora": f["salida"] or f["entrada"]} for f in filas[:12]]
        yo = None
        if usuario:
            mio = next((f for f in filas if f["usuario_id"] == usuario["id"] and not f["salida"]), None)
            t = self.db.q1("SELECT id FROM turnos WHERE usuario_id=? AND estado='abierto' ORDER BY id DESC LIMIT 1", (usuario["id"],))
            yo = {"dentro": bool(mio), "desde": mio["entrada"] if mio else None, "turno_id": t["id"] if t else None}
        return {"activo": True, "dentro": dentro, "recientes": rec, "modo": self.fichaje_modo_turno(), "yo": yo}
