"""Avisos por WhatsApp y SMS (se activan en Ajustes → Conexiones → WhatsApp / SMS).

Modos:
  - "no"      desactivado (por defecto).
  - "manual"  WhatsApp sin coste: el programa prepara el mensaje y abre WhatsApp (Web o la aplicación del PC)
              con el número y el texto ya escritos; el empleado solo pulsa Enviar. No necesita ninguna cuenta.
  - "twilio"  envío automático por SMS o WhatsApp a través de Twilio (cuenta de pago, https://www.twilio.com).
              Por WhatsApp, Meta solo permite iniciar conversación con plantillas aprobadas: si el cliente no
              ha escrito en las últimas 24 h, el mensaje libre puede no entregarse. El SMS no tiene esa limitación.

Solo usa la biblioteca estándar (urllib).
"""
import base64
import json
import re
import urllib.error
import urllib.parse
import urllib.request

API_TWILIO = "https://api.twilio.com"


class ErrorMensaje(Exception):
    pass


def normalizar_movil(tel, prefijo_pais="34"):
    """'612 34 56 78' -> '+34612345678'. Devuelve None si no parece un móvil."""
    if not tel:
        return None
    t = re.sub(r"[^\d+]", "", str(tel))
    if t.startswith("00"):
        t = "+" + t[2:]
    if not t.startswith("+"):
        if len(t) == 9 and t[0] in "67":
            t = f"+{prefijo_pais}{t}"
        else:
            return None
    digitos = t[1:]
    if not digitos.isdigit() or not 8 <= len(digitos) <= 15:
        return None
    if digitos.startswith("34") and (len(digitos) != 11 or digitos[2] not in "67"):
        return None   # en España solo los móviles (6xx / 7xx) reciben SMS y WhatsApp
    return t


def enlace_whatsapp(movil, texto):
    """Enlace «click to chat» de WhatsApp con el número y el mensaje ya escritos."""
    return f"https://wa.me/{movil.lstrip('+')}?text={urllib.parse.quote(texto)}"


def partes_sms(texto):
    """Cuántos SMS ocupa un texto (aprox.: 160 caracteres, o 70 si lleva caracteres fuera del alfabeto GSM)."""
    gsm = set("@£$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ !\"#¤%&'()*+,-./0123456789:;<=>?¡ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ§"
              "¿abcdefghijklmnopqrstuvwxyzäöñüà")
    unicode_ = any(ch not in gsm for ch in texto)
    n = len(texto)
    if unicode_:
        return 1 if n <= 70 else -(-n // 67)
    return 1 if n <= 160 else -(-n // 153)


class Twilio:
    def __init__(self, sid, token, base=None, timeout=20):
        if not sid or not token:
            raise ErrorMensaje("Falta el Account SID o el Auth Token de Twilio")
        self.sid, self.token = sid.strip(), token.strip()
        self.base = (base or API_TWILIO).rstrip("/")
        self.timeout = timeout

    def _llamar(self, metodo, ruta, datos=None):
        cuerpo = urllib.parse.urlencode(datos).encode() if datos else None
        req = urllib.request.Request(self.base + ruta, data=cuerpo, method=metodo)
        req.add_header("Authorization", "Basic " + base64.b64encode(f"{self.sid}:{self.token}".encode()).decode())
        if cuerpo:
            req.add_header("Content-Type", "application/x-www-form-urlencoded")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                return json.loads(r.read() or b"{}")
        except urllib.error.HTTPError as e:
            try:
                msg = json.loads(e.read()).get("message") or str(e)
            except Exception:  # noqa: BLE001
                msg = str(e)
            raise ErrorMensaje(f"Twilio: {msg}")
        except (urllib.error.URLError, OSError) as e:
            raise ErrorMensaje(f"Sin conexión con Twilio: {getattr(e, 'reason', e)}")

    def cuenta(self):
        return self._llamar("GET", f"/2010-04-01/Accounts/{self.sid}.json")

    def enviar(self, desde, para, texto, canal="sms"):
        """Envía un SMS o un WhatsApp. Devuelve el identificador del mensaje en Twilio."""
        if not desde:
            raise ErrorMensaje(f"Falta el número remitente de {'WhatsApp' if canal == 'whatsapp' else 'SMS'} en Ajustes")
        if canal == "whatsapp":
            desde = desde if desde.startswith("whatsapp:") else "whatsapp:" + desde
            para = "whatsapp:" + para
        r = self._llamar("POST", f"/2010-04-01/Accounts/{self.sid}/Messages.json",
                         {"From": desde, "To": para, "Body": texto})
        return r.get("sid")
