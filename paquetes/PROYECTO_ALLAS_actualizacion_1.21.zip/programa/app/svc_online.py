"""PROYECTO ALLAS · lógica de negocio: cobro online de bonos y pago con el móvil (Stripe) (1.4: sale de servicios.py; se mezcla en la clase Parking)."""
import json
import re
from datetime import datetime, timedelta

from .utiles import ErrorNegocio, email_valido, eur, iso


class SvcOnline:
    # ======================================================= pagos online (Stripe)
    def _stripe(self):
        from .pagos_online import Stripe
        if not self.activo("pagos_online_activo", "pagos_online"):
            raise ErrorNegocio("Los pagos online no están activados (Ajustes → Pagos online)", 409)
        return Stripe(self.cfg("stripe_clave"), self.cfg("stripe_api_base") or None)

    def configurar_pagos_online(self, actor_id, clave):
        from .pagos_online import ErrorPago, Stripe
        clave = (clave or "").strip()
        if not clave and self.cfg("stripe_clave"):
            clave = self.cfg("stripe_clave")
        try:
            cuenta = Stripe(clave, self.cfg("stripe_api_base") or None).cuenta()
        except ErrorPago as e:
            raise ErrorNegocio(str(e))
        with self.db.transaccion() as c:
            for k, v in (("stripe_clave", clave), ("pagos_online_activo", "1"),
                         ("stripe_cuenta", json.dumps(cuenta, ensure_ascii=False))):
                c.execute("INSERT INTO config(clave, valor) VALUES(?,?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor",
                          (k, v))
            self.auditar(c, actor_id, "pagos_online_activar", f"{cuenta['nombre']} ({'prueba' if cuenta['prueba'] else 'real'})")
        self.preparar_planes_online()
        return self.estado_pagos_online()

    def desactivar_pagos_online(self, actor_id):
        with self.db.transaccion() as c:
            c.execute("UPDATE config SET valor='0' WHERE clave='pagos_online_activo'")
            self.auditar(c, actor_id, "pagos_online_desactivar", "")
        return self.estado_pagos_online()

    def estado_pagos_online(self):
        try:
            cuenta = json.loads(self.cfg("stripe_cuenta") or "null")
        except ValueError:
            cuenta = None
        clave = self.cfg("stripe_clave") or ""
        planes = self.db.q("SELECT id, nombre, precio_cent, meses, activo, url_enlace, precio_enlace_cent FROM planes_bono "
                           "ORDER BY activo DESC, meses, precio_cent")
        for p in planes:
            p["al_dia"] = bool(p["url_enlace"]) and p["precio_enlace_cent"] == p["precio_cent"]
        subs = self.db.q("SELECT s.*, c.nombre cliente_nombre, c.email, p.nombre plan_nombre FROM suscripciones s "
                         "JOIN clientes c ON c.id=s.cliente_id JOIN planes_bono p ON p.id=s.plan_id ORDER BY s.id DESC")
        return {"activo": self.cfg("pagos_online_activo") == "1", "cuenta": cuenta,
                "clave": (clave[:8] + "…" + clave[-4:]) if clave else "", "prueba": "_test_" in clave,
                "ultimo_sync": self.cfg("stripe_ultimo_sync"), "ultimo_error": self.cfg("stripe_ultimo_error"),
                "planes": planes, "suscripciones": subs, "smtp": self.smtp_listo()}

    def preparar_planes_online(self):
        """Crea o rehace en Stripe el enlace de pago de cada tipo de bono a la venta."""
        from .pagos_online import ErrorPago
        st = self._stripe()
        hechos = []
        for p in self.db.q("SELECT * FROM planes_bono"):
            try:
                if p["activo"] and p["precio_cent"] > 0 and (not p["url_enlace"] or p["precio_enlace_cent"] != p["precio_cent"]):
                    if p["ref_enlace"]:
                        self.sincronizar_pagos_online()      # no perder altas hechas con el enlace anterior
                        st.desactivar_enlace(p["ref_enlace"])
                        if p["ref_enlace_unico"]:
                            st.desactivar_enlace(p["ref_enlace_unico"])
                    r = st.crear_enlace_plan(p, p["ref_producto"])
                    self.db.ex("UPDATE planes_bono SET ref_producto=?, ref_precio=?, ref_enlace=?, url_enlace=?, "
                               "precio_enlace_cent=?, ref_precio_unico=?, ref_enlace_unico=?, url_enlace_unico=? WHERE id=?",
                               (r["ref_producto"], r["ref_precio"], r["ref_enlace"], r["url_enlace"], p["precio_cent"],
                                r["ref_precio_unico"], r["ref_enlace_unico"], r["url_enlace_unico"], p["id"]))
                    hechos.append(p["nombre"])
                elif not p["activo"] and p["url_enlace"]:
                    st.desactivar_enlace(p["ref_enlace"])
                    if p["ref_enlace_unico"]:
                        st.desactivar_enlace(p["ref_enlace_unico"])
                    self.db.ex("UPDATE planes_bono SET url_enlace=NULL, url_enlace_unico=NULL, precio_enlace_cent=NULL "
                               "WHERE id=?", (p["id"],))
            except ErrorPago as e:
                raise ErrorNegocio(f"Bono {p['nombre']}: {e}")
        return hechos

    def enlace_suscripcion(self, cliente_id, plan_id):
        cli = self.db.q1("SELECT * FROM clientes WHERE id=?", (cliente_id,))
        if not cli:
            raise ErrorNegocio("Cliente no encontrado", 404)
        plan = self.db.q1("SELECT * FROM planes_bono WHERE id=? AND activo=1", (plan_id,))
        if not plan:
            raise ErrorNegocio("Ese tipo de bono no está a la venta")
        if not plan["url_enlace"] or plan["precio_enlace_cent"] != plan["precio_cent"]:
            self.preparar_planes_online()
        url = self._enlace_cliente(cli, plan_id)
        if not url:
            raise ErrorNegocio("No se pudo preparar el enlace de pago de ese bono")
        from .codigos import qr_svg
        asunto = f"Suscripción a su bono {plan['nombre']} en {self.cfg('nombre_parking') or ''}"
        cada = f"{plan['meses']} meses" if plan["meses"] > 1 else "mes"
        texto = (f"Hola {cli['nombre']}:\n\nPara pagar su bono {plan['nombre']} ({eur(plan['precio_cent'])} cada {cada}) "
                 f"con cargo automático en su tarjeta, entre en este enlace:\n{url}\n\nEl bono se renovará solo en cada "
                 f"periodo; puede darse de baja cuando quiera avisándonos.\n\nUn saludo,\n{self.cfg('nombre_parking') or ''}")
        return {"url": url, "qr": qr_svg(url, modulo=4, borde=2), "email": cli["email"], "asunto": asunto,
                "texto": texto, "plan": plan["nombre"], "precio_cent": plan["precio_cent"], "meses": plan["meses"]}

    def enviar_enlace_suscripcion(self, usuario, cliente_id, plan_id):
        d = self.enlace_suscripcion(cliente_id, plan_id)
        if not d["email"] or not email_valido(d["email"]):
            raise ErrorNegocio("El cliente no tiene un email válido")
        if not self.smtp_listo():
            raise ErrorNegocio("Configure el «Envío automático (SMTP)» en Ajustes → Email, o use «Gmail» para enviarlo a mano", 409)
        from .correo import enviar
        try:
            enviar(self.db.config(), d["email"], d["asunto"], d["texto"], [])
        except Exception as e:  # noqa: BLE001
            raise ErrorNegocio(f"No se pudo enviar: {e}")
        with self.db.transaccion() as c:
            self.auditar(c, usuario["id"], "suscripcion_enlace", f"cliente={cliente_id} plan={plan_id} -> {d['email']}")
        return {"ok": True, "email": d["email"]}

    def sincronizar_pagos_online(self, solo_cliente=None):
        """Consulta Stripe: altas de suscripción, cobros (renuevan el bono) e impagos (aviso al abonado)."""
        from .pagos_online import ErrorPago, cliente_de_referencia, estado_suscripcion, fin_periodo
        st = self._stripe()
        res = {"nuevas": 0, "cobros": 0, "avisos": 0}
        try:
            # pagos únicos de renovaciones pendientes (client_reference_id = BN<id del bono>)
            for p in self.db.q("SELECT id, ref_enlace_unico FROM planes_bono WHERE ref_enlace_unico IS NOT NULL"):
                for ses in st.sesiones_completadas(p["ref_enlace_unico"]):
                    m = re.fullmatch(r"BN(\d+)", ses.get("client_reference_id") or "")
                    if not m or ses.get("payment_status") != "paid":
                        continue
                    if self.db.q1("SELECT 1 FROM pagos WHERE online_ref=?", (ses["id"],)):
                        continue
                    b = self.db.q1("SELECT * FROM bonos WHERE id=?", (int(m.group(1)),))
                    if not b or (solo_cliente and b["cliente_id"] != solo_cliente):
                        continue
                    if b["pagado"] or b["estado"] != "activo":
                        if not self.db.q1("SELECT 1 FROM auditoria WHERE accion='pago_online_duplicado' AND detalle LIKE ?",
                                          (f"%{ses['id']}%",)):
                            with self.db.transaccion() as c:
                                self.auditar(c, None, "pago_online_duplicado",
                                             f"bono={b['id'] if b else '?'} ya pagado o anulado; pago Stripe {ses['id']} "
                                             f"({eur(ses.get('amount_total') or 0)}): devuélvalo desde el panel de Stripe")
                        continue
                    importe = int(ses.get("amount_total") or b["importe_cent"])
                    with self.db.transaccion() as c:
                        pago = self._insertar_pago(c, None, None, importe, "online", None, None, bono_id=b["id"],
                                                   online_ref=ses["id"])
                        c.execute("UPDATE bonos SET pagado=1 WHERE id=?", (b["id"],))
                        self.auditar(c, None, "bono_pago_online", f"bono={b['id']} {importe} sesión {ses['id']}")
                    self._factura_a_abonado(b["cliente_id"], pago["id"])
                    res["cobros"] += 1
            if not solo_cliente:
                for p in self.db.q("SELECT id, ref_enlace FROM planes_bono WHERE ref_enlace IS NOT NULL"):
                    for ses in st.sesiones_completadas(p["ref_enlace"]):
                        cid = cliente_de_referencia(ses.get("client_reference_id"))
                        sub = ses.get("subscription")
                        sub = sub["id"] if isinstance(sub, dict) else sub
                        if not cid or not sub or not self.db.q1("SELECT 1 FROM clientes WHERE id=?", (cid,)):
                            continue
                        if self.db.q1("SELECT 1 FROM suscripciones WHERE ref_suscripcion=?", (sub,)):
                            continue
                        cus = ses.get("customer")
                        with self.db.transaccion() as c:
                            c.execute("INSERT INTO suscripciones(cliente_id, plan_id, ref_suscripcion, ref_cliente, estado, creada) "
                                      "VALUES(?,?,?,?, 'activa', ?)", (cid, p["id"], sub, cus["id"] if isinstance(cus, dict) else cus,
                                                                     iso(self.ahora())))
                            c.execute("UPDATE clientes SET tipo='abonado' WHERE id=?", (cid,))
                            self.auditar(c, None, "suscripcion_alta", f"cliente={cid} plan={p['id']} {sub}")
                        res["nuevas"] += 1
            sql = "SELECT * FROM suscripciones WHERE (estado<>'cancelada' OR actualizada>=?)"
            params = [iso(self.ahora() - timedelta(days=40))]
            if solo_cliente:
                sql += " AND cliente_id=?"
                params.append(solo_cliente)
            for sus in self.db.q(sql, params):
                s = st.suscripcion(sus["ref_suscripcion"])
                fin = fin_periodo(s)
                self.db.ex("UPDATE suscripciones SET estado=?, periodo_fin=?, cancelar_al_final=?, actualizada=? WHERE id=?",
                           (estado_suscripcion(s), datetime.fromtimestamp(fin).astimezone().isoformat(timespec="seconds")
                            if fin else None, 1 if s.get("cancel_at_period_end") else 0, iso(self.ahora()), sus["id"]))
                for inv in sorted(st.facturas(sus["ref_suscripcion"]), key=lambda x: x.get("created") or 0):
                    if inv.get("status") == "paid" and (inv.get("amount_paid") or 0) > 0:
                        if not self.db.q1("SELECT 1 FROM pagos WHERE online_ref=?", (inv["id"],)):
                            self._registrar_cobro_online(sus, inv)
                            res["cobros"] += 1
                    elif inv.get("status") == "open" and inv.get("hosted_invoice_url") and (
                            inv.get("attempt_count") or 0) > 0:
                        cli = self.db.q1("SELECT * FROM clientes WHERE id=?", (sus["cliente_id"],))
                        plan = self.db.q1("SELECT nombre FROM planes_bono WHERE id=?", (sus["plan_id"],))
                        if self.smtp_listo() and self.cfg("avisos_activos") == "1":
                            if self._enviar_aviso("pago_pendiente", inv["id"], cli, {
                                    "plan": plan["nombre"], "importe": eur(inv.get("amount_due") or 0),
                                    "enlace": inv["hosted_invoice_url"]}) == "enviado":
                                res["avisos"] += 1
            self.db.set_cfg("stripe_ultimo_sync", iso(self.ahora()))
            self.db.set_cfg("stripe_ultimo_error", "")
        except ErrorPago as e:
            self.db.set_cfg("stripe_ultimo_error", f"{iso(self.ahora())} {e}")
            raise ErrorNegocio(str(e), 502)
        return res

    def _registrar_cobro_online(self, sus, inv):
        """Factura pagada en Stripe -> nuevo periodo de bono + factura simplificada (+ email al abonado)."""
        importe = int(inv["amount_paid"])
        desde = self.proximo_desde(sus["cliente_id"])
        plan, d, h = self.periodo_bono(sus["plan_id"], desde)
        with self.db.transaccion() as c:
            if c.execute("SELECT 1 FROM pagos WHERE online_ref=?", (inv["id"],)).fetchone():
                return None
            bid = self._insertar_bono(c, sus["cliente_id"], plan["id"], d, h, importe, None)
            pago = self._insertar_pago(c, None, None, importe, "online", None, None, bono_id=bid, online_ref=inv["id"])
            self.auditar(c, None, "bono_cobro_online",
                         f"cliente={sus['cliente_id']} {plan['nombre']} {d}..{h} {importe} factura Stripe {inv['id']}")
        self._factura_a_abonado(sus["cliente_id"], pago["id"])
        return pago

    def cancelar_suscripcion(self, usuario, sus_id, inmediato=False):
        from .pagos_online import ErrorPago
        sus = self.db.q1("SELECT * FROM suscripciones WHERE id=?", (sus_id,))
        if not sus:
            raise ErrorNegocio("Suscripción no encontrada", 404)
        try:
            self._stripe().cancelar(sus["ref_suscripcion"], inmediato)
        except ErrorPago as e:
            raise ErrorNegocio(str(e))
        with self.db.transaccion() as c:
            if inmediato:
                c.execute("UPDATE suscripciones SET estado='cancelada', actualizada=? WHERE id=?", (iso(self.ahora()), sus_id))
            else:
                c.execute("UPDATE suscripciones SET cancelar_al_final=1, actualizada=? WHERE id=?", (iso(self.ahora()), sus_id))
            self.auditar(c, usuario["id"], "suscripcion_cancelar",
                         f"cliente={sus['cliente_id']} {sus['ref_suscripcion']} {'inmediata' if inmediato else 'al final del periodo'}")
        return self.db.q1("SELECT * FROM suscripciones WHERE id=?", (sus_id,))
