"""PROYECTO ALLAS 4.3 · funciones nuevas de la clase Parking (se mezclan con ella en servicios.py):

- reservas de plataformas (Parclick, ElParking, hoteles…) importadas de CSV/Excel y aplicadas solas al entrar
- zonas con su capacidad y plazas reservadas para abonados
- alertas operativas, estadísticas, cierre diario por email y libro de facturas para la gestoría
- ticket digital (SMS / WhatsApp), estado del vehículo al entrar (notas y fotos)
- permisos por usuario, auditoría con filtros
- pago desde el móvil del cliente con el QR del ticket (Stripe)
"""
import csv
import io
import json
import os
import re
from datetime import date, datetime, timedelta


def _sv():
    from . import servicios
    return servicios


def _iso(dt):
    return dt.isoformat(timespec="seconds")


# ------------------------------------------------------------------ fechas de los listados de reservas
FORMATOS_FECHA = ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M", "%Y-%m-%d",
                  "%d/%m/%Y %H:%M:%S", "%d/%m/%Y %H:%M", "%d/%m/%Y", "%d-%m-%Y %H:%M:%S", "%d-%m-%Y %H:%M", "%d-%m-%Y",
                  "%d/%m/%y %H:%M", "%d/%m/%y", "%d.%m.%Y %H:%M", "%d.%m.%Y")


def leer_fecha(texto, hora=None, tz=None, hora_defecto="00:00"):
    """'12/10/2026 14:30', '2026-10-12T14:30', número de Excel (46307.6)… → datetime con la zona del PC."""
    t = str(texto or "").strip()
    if not t:
        raise ValueError("fecha vacía")
    dt = None
    if re.fullmatch(r"\d{5}(\.\d+)?", t):   # fecha de Excel
        dt = datetime(1899, 12, 30) + timedelta(days=float(t))
        dt = dt.replace(second=0, microsecond=0)
    else:
        t2 = t.replace("h", "").strip()
        for f in FORMATOS_FECHA:
            try:
                dt = datetime.strptime(t2[:19], f)
                if "%H" not in f:
                    hh, mm = (hora_defecto or "00:00").split(":")
                    dt = dt.replace(hour=int(hh), minute=int(mm))
                break
            except ValueError:
                continue
        if dt is None:
            try:
                dt = datetime.fromisoformat(t)
            except ValueError:
                raise ValueError(f"fecha no reconocida: {t}")
    if hora:
        h = str(hora).strip()
        if re.fullmatch(r"0?\.\d+", h):   # hora de Excel (fracción del día)
            minutos = round(float(h) * 1440)
            dt = dt.replace(hour=minutos // 60 % 24, minute=minutos % 60)
        else:
            m = re.match(r"(\d{1,2})[:.h](\d{2})", h)
            if m:
                dt = dt.replace(hour=int(m.group(1)), minute=int(m.group(2)))
    if dt.tzinfo is None and tz is not None:
        dt = dt.replace(tzinfo=tz)
    return dt


CAMPOS_RESERVA = [("matricula", "Matrícula"), ("desde", "Entrada (fecha y hora)"), ("hora_desde", "Hora de entrada (si va aparte)"),
                  ("hasta", "Salida (fecha y hora)"), ("hora_hasta", "Hora de salida (si va aparte)"), ("ref", "Nº de reserva"),
                  ("cliente", "Cliente"), ("plataforma", "Plataforma / canal"), ("nota", "Notas")]
SINONIMOS_RESERVA = {
    "matricula": ("matricula", "placa", "plate", "license plate", "vehiculo", "coche"),
    "desde": ("entrada", "fecha entrada", "llegada", "fecha llegada", "check in", "checkin", "inicio", "desde", "arrival",
              "fecha inicio", "entry", "start", "fecha de entrada"),
    "hora_desde": ("hora entrada", "hora llegada", "hora inicio", "hora de entrada"),
    "hasta": ("salida", "fecha salida", "check out", "checkout", "fin", "hasta", "departure", "fecha fin", "exit", "end",
              "fecha de salida"),
    "hora_hasta": ("hora salida", "hora fin", "hora de salida"),
    "ref": ("referencia", "reserva", "localizador", "codigo", "codigo reserva", "booking", "booking id", "id reserva",
            "n reserva", "no reserva", "numero reserva", "ref", "id", "confirmacion"),
    "cliente": ("cliente", "nombre", "titular", "huesped", "name", "customer"),
    "plataforma": ("plataforma", "canal", "origen", "web", "proveedor", "source"),
    "nota": ("notas", "observaciones", "comentarios", "nota", "habitacion"),
}

# ------------------------------------------------------------------ permisos por usuario
# (permiso, nombre, roles que lo tienen de serie)
PERMISOS = [
    ("anular_tickets", "Anular tickets", ("admin", "supervisor")),
    ("ticket_manual", "Tickets manuales y perdidos", ("admin", "supervisor", "cajero")),
    ("cambiar_tarifa", "Cambiar la tarifa o la matrícula de un ticket", ("admin", "supervisor", "cajero")),
    ("descuentos", "Aplicar descuentos y vales", ("admin", "supervisor", "cajero")),
    ("abrir_cajon", "Abrir el cajón sin venta", ("admin", "supervisor", "cajero")),
    ("movimientos_caja", "Ingresos y retiradas de caja", ("admin", "supervisor", "cajero")),
    ("ver_informes", "Ver informes, estadísticas y auditoría", ("admin", "supervisor")),
    ("turnos_ajenos", "Ver y cerrar turnos de otros cajeros", ("admin", "supervisor")),
    ("lista_negra", "Cambiar la lista negra", ("admin", "supervisor")),
    ("reservas", "Importar y cambiar reservas de plataformas", ("admin", "supervisor")),
    ("abonados", "Vender bonos y cambiar abonados", ("admin", "supervisor", "cajero")),
    ("exportar", "Exportar datos (CSV, Excel)", ("admin", "supervisor")),
]
NOMBRES_PERMISO = {p: n for p, n, _ in PERMISOS}


class Funciones43:
    # ============================================================ reservas de plataformas
    def _ahora_tz(self):
        return self.ahora().tzinfo

    def reservas_previstas(self, desde=None, hasta=None, estado="", buscar=""):
        sql = ("SELECT r.*, t.nombre tarifa_nombre, tk.codigo ticket_codigo, z.nombre zona_nombre FROM reservas_previstas r "
               "LEFT JOIN tarifas t ON t.id=r.tarifa_id LEFT JOIN tickets tk ON tk.id=r.ticket_id "
               "LEFT JOIN zonas z ON z.id=r.zona_id WHERE 1=1")
        args = []
        if desde:
            sql += " AND substr(r.hasta,1,10)>=?"
            args.append(desde)
        if hasta:
            sql += " AND substr(r.desde,1,10)<=?"
            args.append(hasta)
        if estado == "a_devolver":   # 1.12: señales cobradas de reservas canceladas
            sql += " AND r.pago='a_devolver'"
        elif estado:
            sql += " AND r.estado=?"
            args.append(estado)
        b = (buscar or "").strip()
        if b:
            m = _sv().norm_matricula(b) or b
            sql += " AND (r.matricula LIKE ? OR r.ref LIKE ? OR r.cliente LIKE ? OR r.plataforma LIKE ?)"
            args += [f"%{m}%", f"%{b}%", f"%{b}%", f"%{b}%"]
        return self.db.q(sql + " ORDER BY r.desde, r.id LIMIT 2000", args)

    def _tarifa_reserva_defecto(self):
        t = self.db.q1("SELECT id FROM tarifas WHERE activa=1 AND eliminada=0 AND modo='reserva' ORDER BY id")
        return t and t["id"]

    def _validar_reserva_prevista(self, datos, tz):
        sv = _sv()
        mat = sv.norm_matricula(datos.get("matricula"))
        if not mat or not 3 <= len(mat) <= 12:
            raise sv.ErrorNegocio("Matrícula no válida")
        try:
            d = leer_fecha(datos.get("desde"), datos.get("hora_desde"), tz)
            h = leer_fecha(datos.get("hasta"), datos.get("hora_hasta"), tz, hora_defecto="23:59")
        except ValueError as e:
            raise sv.ErrorNegocio(f"Fecha no válida ({e})")
        if h <= d:
            raise sv.ErrorNegocio("La salida de la reserva debe ser posterior a la entrada")
        if h - d > timedelta(days=90):
            raise sv.ErrorNegocio("Una reserva no puede durar más de 90 días")
        limpio = lambda k, n: (str(datos.get(k) or "").strip()[:n] or None)  # noqa: E731
        return {"matricula": mat, "desde": _iso(d), "hasta": _iso(h), "ref": limpio("ref", 60),
                "plataforma": limpio("plataforma", 40), "cliente": limpio("cliente", 80), "nota": limpio("nota", 200)}

    def guardar_reserva_prevista(self, usuario, datos, rid=None):
        sv = _sv()
        self._exigir_permiso(usuario, "reservas")
        v = self._validar_reserva_prevista(datos, self._ahora_tz())
        tarifa = int(datos.get("tarifa_id") or 0) or self._tarifa_reserva_defecto()
        if not tarifa or (self.tarifa(tarifa).get("modo") != "reserva"):
            raise sv.ErrorNegocio("Cree antes una tarifa de tipo «Reserva / hotel» (Ajustes → Precios → Tarifas)")
        with self.db.transaccion() as c:
            if rid:
                if c.execute("SELECT 1 FROM reservas_previstas WHERE id=? AND origen IN ('mostrador','web')", (int(rid),)).fetchone():
                    raise sv.ErrorNegocio("Las reservas online no se editan: cancélela y cree otra", 409)
                if not c.execute("UPDATE reservas_previstas SET matricula=?, desde=?, hasta=?, ref=?, plataforma=?, cliente=?, "
                                 "nota=?, tarifa_id=? WHERE id=? AND estado='pendiente'",
                                 (v["matricula"], v["desde"], v["hasta"], v["ref"], v["plataforma"], v["cliente"], v["nota"],
                                  tarifa, int(rid))).rowcount:
                    raise sv.ErrorNegocio("Solo se pueden cambiar las reservas pendientes", 409)
            else:
                rid = c.execute("INSERT INTO reservas_previstas(matricula, desde, hasta, ref, plataforma, cliente, nota, tarifa_id, "
                                "creada, usuario_id) VALUES(?,?,?,?,?,?,?,?,?,?)",
                                (v["matricula"], v["desde"], v["hasta"], v["ref"], v["plataforma"], v["cliente"], v["nota"],
                                 tarifa, sv.iso(self.ahora()), usuario["id"])).lastrowid
            self.auditar(c, usuario["id"], "reserva_prevista", f"{v['matricula']} {v['desde'][:16]}→{v['hasta'][:16]} {v['ref'] or ''}")
        return self.db.q1("SELECT * FROM reservas_previstas WHERE id=?", (int(rid),))

    def cancelar_reserva_prevista(self, usuario, rid):
        self._exigir_permiso(usuario, "reservas")
        with self.db.transaccion() as c:
            if not c.execute("UPDATE reservas_previstas SET estado='cancelada' WHERE id=? AND estado='pendiente'", (int(rid),)).rowcount:
                raise _sv().ErrorNegocio("Solo se pueden cancelar las reservas pendientes", 409)
            self.auditar(c, usuario["id"], "reserva_prevista_cancelar", f"id={rid}")
        return {"ok": True}

    def leer_listado_reservas(self, datos, nombre=""):
        from . import importar
        try:
            filas = importar.leer(datos, nombre)
        except ValueError as e:
            raise _sv().ErrorNegocio(str(e))
        cab = filas[0]
        sug = {}
        for i, c in enumerate(cab):
            n = importar._norm(c)
            for campo, sins in SINONIMOS_RESERVA.items():
                if campo not in sug and (n in sins or any(n.startswith(s + " ") for s in sins if len(s) > 3)):
                    sug[campo] = i
                    break
        return {"cabeceras": cab, "muestra": filas[1:11], "total": len(filas) - 1, "sugerencia": sug, "campos": CAMPOS_RESERVA}

    def importar_reservas(self, usuario, datos, nombre, mapeo, plataforma="", tarifa_id=None, aplicar=False):
        """mapeo: {campo: índice de columna}. Repetidas (misma plataforma y nº, o misma matrícula y entrada): se actualizan."""
        from . import importar
        sv = _sv()
        self._exigir_permiso(usuario, "reservas")
        tarifa = int(tarifa_id or 0) or self._tarifa_reserva_defecto()
        if not tarifa or self.tarifa(tarifa).get("modo") != "reserva":
            raise sv.ErrorNegocio("Cree antes una tarifa de tipo «Reserva / hotel» (Ajustes → Precios → Tarifas)")
        for campo in ("matricula", "desde", "hasta"):
            if mapeo.get(campo) in (None, ""):
                raise sv.ErrorNegocio(f"Indique la columna de «{dict(CAMPOS_RESERVA)[campo]}»")
        filas = importar.leer(datos, nombre)[1:]
        tz = self._ahora_tz()
        lote = sv.iso(self.ahora())
        res = {"nuevas": 0, "actualizadas": 0, "iguales": 0, "errores": []}
        with self.db.transaccion() as c:
            for n, fila in enumerate(filas, start=2):
                d = {k: (fila[int(i)] if i not in (None, "") and int(i) < len(fila) else "") for k, i in mapeo.items()}
                if plataforma and not d.get("plataforma"):
                    d["plataforma"] = plataforma
                try:
                    v = self._validar_reserva_prevista(d, tz)
                except sv.ErrorNegocio as e:
                    res["errores"].append(f"Fila {n}: {e}")
                    continue
                previa = None
                if v["ref"]:
                    previa = c.execute("SELECT id, estado, matricula, desde, hasta FROM reservas_previstas WHERE ref=? "
                                       "AND COALESCE(plataforma,'')=COALESCE(?,'')", (v["ref"], v["plataforma"])).fetchone()
                if not previa:
                    previa = c.execute("SELECT id, estado, matricula, desde, hasta FROM reservas_previstas WHERE matricula=? AND desde=?",
                                       (v["matricula"], v["desde"])).fetchone()
                if previa:
                    if (previa[2], previa[3], previa[4]) == (v["matricula"], v["desde"], v["hasta"]) or previa[1] != "pendiente":
                        res["iguales"] += 1
                        continue
                    c.execute("UPDATE reservas_previstas SET matricula=?, desde=?, hasta=?, cliente=?, nota=?, lote=? WHERE id=?",
                              (v["matricula"], v["desde"], v["hasta"], v["cliente"], v["nota"], lote, previa[0]))
                    res["actualizadas"] += 1
                else:
                    c.execute("INSERT INTO reservas_previstas(matricula, desde, hasta, ref, plataforma, cliente, nota, tarifa_id, "
                              "creada, usuario_id, lote) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                              (v["matricula"], v["desde"], v["hasta"], v["ref"], v["plataforma"], v["cliente"], v["nota"],
                               tarifa, lote, usuario["id"], lote))
                    res["nuevas"] += 1
            if aplicar:
                self.auditar(c, usuario["id"], "reservas_importar",
                             f"{nombre}: {res['nuevas']} nuevas, {res['actualizadas']} actualizadas, {len(res['errores'])} errores")
            else:
                c.execute("ROLLBACK")
                c.execute("BEGIN IMMEDIATE")
        res["aplicado"] = bool(aplicar)
        res["errores"] = res["errores"][:50]
        return res

    def reserva_para(self, matricula, momento=None):
        """Reserva pendiente de esa matrícula para ahora (se admite llegar antes según 'reservas_margen_min')."""
        sv = _sv()
        m = sv.norm_matricula(matricula)
        if not m:
            return None
        self.caducar_reservas_sin_pago()   # 1.12: una señal sin pagar a tiempo ya no vale
        momento = momento or self.ahora()
        margen = timedelta(minutes=int(self.cfg("reservas_margen_min") or 120))
        for r in self.db.q("SELECT * FROM reservas_previstas WHERE matricula=? AND estado='pendiente' ORDER BY desde", (m,)):
            if sv.parse(r["desde"]) - margen <= momento < sv.parse(r["hasta"]):
                return r
        return None

    # ============================================================ zonas y plazas
    def zonas(self, todas=False):
        if not self.tiene_modulo("gestion"):   # 4.7: licencia Lite sin zonas (todo el parking cuenta como una)
            return []
        return self.db.q("SELECT * FROM zonas" + ("" if todas else " WHERE activa=1") + " ORDER BY orden, id")

    def guardar_zona(self, actor_id, datos, zid=None):
        sv = _sv()
        nombre = (datos.get("nombre") or "").strip()[:40]
        if not nombre:
            raise sv.ErrorNegocio("Indique el nombre de la zona")
        try:
            cap = int(datos.get("capacidad") or 0)
            orden = int(datos.get("orden") or 0)
        except (TypeError, ValueError):
            raise sv.ErrorNegocio("Capacidad no válida")
        if cap < 0:
            raise sv.ErrorNegocio("Capacidad no válida")
        color = (datos.get("color") or "").strip().lower()   # 4.5
        if color and not re.fullmatch(r"#[0-9a-f]{6}", color):
            raise sv.ErrorNegocio("Color no válido")
        with self.db.transaccion() as c:
            if zid:
                c.execute("UPDATE zonas SET nombre=?, capacidad=?, orden=?, activa=?, color=? WHERE id=?",
                          (nombre, cap, orden, 0 if datos.get("activa") is False else 1, color or None, int(zid)))
            else:
                zid = c.execute("INSERT INTO zonas(nombre, capacidad, orden, color) VALUES(?,?,?,?)", (nombre, cap, orden, color or None)).lastrowid
            self.auditar(c, actor_id, "zona_guardar", f"{nombre} ({cap})")
        return self.db.q1("SELECT * FROM zonas WHERE id=?", (int(zid),))

    def borrar_zona(self, actor_id, zid):
        with self.db.transaccion() as c:
            if c.execute("SELECT 1 FROM tickets WHERE zona_id=? LIMIT 1", (int(zid),)).fetchone():
                c.execute("UPDATE zonas SET activa=0 WHERE id=?", (int(zid),))
            else:
                c.execute("DELETE FROM zonas WHERE id=?", (int(zid),))
            self.auditar(c, actor_id, "zona_borrar", f"id={zid}")
        return {"ok": True}

    def ocupacion_zonas(self):
        zs = self.zonas()
        if not zs:
            return []
        n = {r["zona_id"]: r["n"] for r in self.db.q("SELECT zona_id, COUNT(*) n FROM tickets WHERE estado IN ('dentro','pagado') "
                                                      "GROUP BY zona_id")}
        return [{"id": z["id"], "nombre": z["nombre"], "capacidad": z["capacidad"], "ocupadas": n.get(z["id"], 0), "color": z.get("color")} for z in zs]

    def cambiar_zona(self, usuario, ticket_id, zona_id):
        """4.5: mover un vehículo que está dentro a otra zona (comprueba que la nueva tenga sitio)."""
        sv = _sv()
        with self.db.transaccion() as c:
            t = c.execute("SELECT id, codigo, matricula, estado, zona_id, cliente_id FROM tickets WHERE id=?", (int(ticket_id),)).fetchone()
            if not t:
                raise sv.ErrorNegocio("Ticket no encontrado", 404)
            if t["estado"] not in ("dentro", "pagado"):
                raise sv.ErrorNegocio("El vehículo ya no está dentro")
            nueva = int(zona_id) if zona_id else None
            if nueva == t["zona_id"]:
                return {"ok": True, "zona_id": nueva}
            if nueva:
                z = c.execute("SELECT nombre, capacidad FROM zonas WHERE id=? AND activa=1", (nueva,)).fetchone()
                if not z:
                    raise sv.ErrorNegocio("Zona no encontrada")
                if z[1] and c.execute("SELECT COUNT(*) FROM tickets WHERE zona_id=? AND estado IN ('dentro','pagado')", (nueva,)).fetchone()[0] >= z[1]:
                    raise sv.ErrorNegocio(f"Zona «{z[0]}» COMPLETA", 409)
            antes = c.execute("SELECT nombre FROM zonas WHERE id=?", (t["zona_id"],)).fetchone() if t["zona_id"] else None
            c.execute("UPDATE tickets SET zona_id=? WHERE id=?", (nueva, t["id"]))
            despues = c.execute("SELECT nombre FROM zonas WHERE id=?", (nueva,)).fetchone() if nueva else None
            self.auditar(c, usuario["id"], "ticket_zona", f"{t['matricula'] or t['codigo']}: {antes[0] if antes else '—'} → {despues[0] if despues else '—'}")
        return {"ok": True, "zona_id": nueva}

    def _comprobar_plazas(self, c, zona_id, es_abonado=False):
        """Zona completa y plazas reservadas para abonados (la rotación no puede ocuparlas)."""
        sv = _sv()
        if zona_id:
            z = c.execute("SELECT nombre, capacidad FROM zonas WHERE id=? AND activa=1", (int(zona_id),)).fetchone()
            if not z:
                raise sv.ErrorNegocio("Zona no encontrada")
            if z[1] and c.execute("SELECT COUNT(*) FROM tickets WHERE zona_id=? AND estado IN ('dentro','pagado')",
                                  (int(zona_id),)).fetchone()[0] >= z[1]:
                raise sv.ErrorNegocio(f"Zona «{z[0]}» COMPLETA", 409)
        reservadas = int(self.cfg("plazas_abonados") or 0)
        capacidad = int(self.cfg("capacidad") or 0)
        if reservadas and capacidad and not es_abonado:
            rot = c.execute("SELECT COUNT(*) FROM tickets WHERE estado IN ('dentro','pagado') AND cliente_id IS NULL").fetchone()[0]
            if rot >= capacidad - reservadas:
                raise sv.ErrorNegocio(f"COMPLETO para rotación: quedan solo las {reservadas} plazas reservadas para abonados", 409)

    # ============================================================ alertas operativas (en la campana)
    def alertas_operativas(self):
        sv = _sv()
        avisos = []
        ahora = self.ahora()
        cap = int(self.cfg("capacidad") or 0)
        oc = self.ocupacion()
        pct = int(self.cfg("alerta_ocupacion_pct") or 90)
        if cap and pct and oc["ocupadas"] >= cap * pct / 100:
            completo = oc["ocupadas"] >= cap
            avisos.append({"id": "ocupacion", "nivel": "rojo" if completo else "aviso",
                           "titulo": "Parking COMPLETO" if completo else f"Parking casi lleno: {oc['ocupadas']} de {cap} plazas",
                           "texto": f"Ocupación del {round(oc['ocupadas'] * 100 / cap)} %. Aviso a partir del {pct} % (Ajustes → Opciones → Alertas).",
                           "ir": "vehiculos"})
        for z in self.ocupacion_zonas():
            if z["capacidad"] and z["ocupadas"] >= z["capacidad"]:
                avisos.append({"id": f"zona{z['id']}", "nivel": "aviso", "titulo": f"Zona «{z['nombre']}» completa",
                               "texto": f"{z['ocupadas']} de {z['capacidad']} plazas.", "ir": "vehiculos"})
        dias = int(self.cfg("alerta_dias_dentro") or 7)
        if dias:
            limite = sv.iso(ahora - timedelta(days=dias))
            viejos = self.db.q("SELECT matricula, codigo, entrada FROM tickets WHERE estado IN ('dentro','pagado') AND cliente_id IS NULL "
                               "AND entrada<? AND reserva_hasta IS NULL ORDER BY entrada LIMIT 50", (limite,))
            viejos += self.db.q("SELECT matricula, codigo, entrada FROM tickets WHERE estado IN ('dentro','pagado') AND cliente_id IS NULL "
                                "AND reserva_hasta IS NOT NULL AND reserva_hasta<? ORDER BY entrada LIMIT 50", (limite,))
            if viejos:
                lista = ", ".join((v["matricula"] or v["codigo"]) for v in viejos[:6])
                avisos.append({"id": "dias_dentro", "nivel": "aviso", "titulo": f"{len(viejos)} vehículo(s) más de {dias} días dentro",
                               "texto": f"{lista}{'…' if len(viejos) > 6 else ''}. ¿Abandonados o ticket perdido?", "ir": "vehiculos"})
        tope = int(self.cfg("alerta_efectivo_cent") or 50000)
        if tope:
            for t in self.turnos_abiertos() or []:
                try:
                    tt = self._totales_turno(t["id"])
                except Exception:  # noqa: BLE001
                    continue
                if tt["efectivo_esperado_actual_cent"] > tope:
                    avisos.append({"id": f"efectivo{t['id']}", "nivel": "aviso",
                                   "titulo": f"Mucho efectivo en la caja de {t.get('usuario_nombre') or 'un cajero'}",
                                   "texto": f"Hay unos {sv.eur(tt['efectivo_esperado_actual_cent'])} en el cajón (aviso a partir de {sv.eur(tope)}). "
                                            "Conviene hacer una retirada (Caja y turno → Retirada).", "ir": "caja"})
        if self.tiene_modulo("abonados"):
            desde = sv.iso(ahora - timedelta(hours=24))
            filas = self.db.q("SELECT DISTINCT c.id, c.nombre, t.matricula FROM tickets t JOIN cliente_matriculas m ON m.matricula=t.matricula "
                              "JOIN clientes c ON c.id=m.cliente_id WHERE t.entrada>=? AND t.cliente_id IS NULL AND c.activo=1 "
                              "AND EXISTS (SELECT 1 FROM bonos b WHERE b.cliente_id=c.id)", (desde,))
            caducados = [f for f in filas if not self.bono_vigente(f["id"], ahora.date())]
            if caducados:
                avisos.append({"id": "abonado_caducado", "nivel": "aviso",
                               "titulo": f"{len(caducados)} abonado(s) con el bono caducado han entrado hoy",
                               "texto": ", ".join(f"{f['nombre']} ({f['matricula']})" for f in caducados[:5]) + ". Han entrado como rotación: ofrézcales renovar.",
                               "ir": "abonados"})
        desde = sv.iso(ahora - timedelta(hours=24))
        ln = self.db.q("SELECT DISTINCT l.matricula, n.motivo FROM lpr_lecturas l JOIN lista_negra n ON n.matricula=l.matricula AND n.activa=1 "
                       "WHERE l.fecha>=? LIMIT 20", (desde,))
        if ln:
            avisos.append({"id": "lpr_lista_negra", "nivel": "rojo", "titulo": f"La cámara ha leído {len(ln)} matrícula(s) de la lista negra",
                           "texto": "; ".join(f"{x['matricula']}: {x['motivo']}" for x in ln[:5]), "ir": "vehiculos"})
        return avisos

    # ============================================================ estadísticas
    def estadisticas(self, desde, hasta):
        sv = _sv()
        try:
            d0, d1 = date.fromisoformat(desde), date.fromisoformat(hasta)
        except (TypeError, ValueError):
            raise sv.ErrorNegocio("Fechas no válidas")
        if d1 < d0 or (d1 - d0).days > 366:
            raise sv.ErrorNegocio("Elija un periodo de como mucho un año")
        dias = (d1 - d0).days + 1
        tz = self._ahora_tz()
        ini = datetime.combine(d0, datetime.min.time()).replace(tzinfo=tz)
        fin = datetime.combine(d1, datetime.max.time()).replace(tzinfo=tz)
        tks = self.db.q("SELECT t.entrada, t.salida, t.estado, t.cliente_id, t.tarifa_id, t.tipo_vehiculo, tr.nombre tarifa FROM tickets t "
                        "JOIN tarifas tr ON tr.id=t.tarifa_id WHERE t.estado<>'anulado' AND t.entrada<=? "
                        "AND (t.salida IS NULL OR t.salida>=?)", (sv.iso(fin), sv.iso(ini)))
        # entradas por día de la semana y hora, y ocupación media por hora del día
        entradas = [[0] * 24 for _ in range(7)]
        ocup = [0] * 24
        ahora = self.ahora()
        tramos = []
        for t in tks:
            e = sv.parse(t["entrada"])
            s = sv.parse(t["salida"]) if t["salida"] else ahora
            tramos.append((e, s))
            if ini <= e <= fin:
                entradas[e.weekday()][e.hour] += 1
        for h in range(24):
            total = 0
            for i in range(dias):
                momento = datetime.combine(d0 + timedelta(days=i), datetime.min.time()).replace(tzinfo=tz) + timedelta(hours=h, minutes=30)
                if momento > ahora:
                    continue
                total += sum(1 for e, s in tramos if e <= momento < s)
            ocup[h] = round(total / dias, 1)
        n_entradas = sum(sum(f) for f in entradas)
        # ingresos por día y comparación con el periodo anterior (misma duración)
        def ingresos(a, b):
            filas = self.db.q("SELECT substr(fecha,1,10) dia, SUM(importe_cent) total, SUM(concepto='estancia') n, "
                              "SUM(CASE WHEN concepto='estancia' THEN importe_cent ELSE 0 END) estancias FROM pagos "
                              "WHERE substr(fecha,1,10) BETWEEN ? AND ? AND concepto<>'sustitutiva' GROUP BY dia", (a.isoformat(), b.isoformat()))
            return {f["dia"]: f for f in filas}
        act = ingresos(d0, d1)
        p0, p1 = d0 - timedelta(days=dias), d0 - timedelta(days=1)
        ant = ingresos(p0, p1)
        serie = []
        for i in range(dias):
            dd = d0 + timedelta(days=i)
            da = p0 + timedelta(days=i)
            serie.append({"dia": dd.isoformat(), "total": (act.get(dd.isoformat()) or {}).get("total") or 0,
                          "anterior": (ant.get(da.isoformat()) or {}).get("total") or 0})
        tot = sum(x["total"] for x in serie)
        tot_ant = sum(x["anterior"] for x in serie)
        cobros = self.db.q1("SELECT COUNT(*) n, AVG(importe_cent) medio, AVG(minutos) min_medio FROM pagos WHERE concepto='estancia' "
                            "AND importe_cent>0 AND substr(fecha,1,10) BETWEEN ? AND ?", (d0.isoformat(), d1.isoformat()))
        tarifas = self.db.q("SELECT tr.nombre, COUNT(DISTINCT t.id) entradas, COALESCE(SUM(p.importe_cent - p.extras_cent),0) importe FROM tickets t "
                            "JOIN tarifas tr ON tr.id=t.tarifa_id LEFT JOIN pagos p ON p.ticket_id=t.id AND p.concepto='estancia' "
                            "WHERE substr(t.entrada,1,10) BETWEEN ? AND ? AND t.estado<>'anulado' GROUP BY tr.nombre ORDER BY entradas DESC LIMIT 12",
                            (d0.isoformat(), d1.isoformat()))
        servicios = self.db.q("SELECT nombre, SUM(cantidad) unidades, SUM(precio_cent*cantidad) importe FROM ticket_extras "
                              "WHERE substr(fecha,1,10) BETWEEN ? AND ? GROUP BY nombre ORDER BY importe DESC LIMIT 12",
                              (d0.isoformat(), d1.isoformat()))
        tipos = self.db.q("SELECT COALESCE(tipo_vehiculo,'Sin indicar') tipo, COUNT(*) n FROM tickets WHERE substr(entrada,1,10) BETWEEN ? AND ? "
                          "AND estado<>'anulado' GROUP BY tipo ORDER BY n DESC", (d0.isoformat(), d1.isoformat()))
        cap = int(self.cfg("capacidad") or 0)
        return {"desde": d0.isoformat(), "hasta": d1.isoformat(), "dias": dias, "entradas_hora": entradas, "ocupacion_hora": ocup,
                "capacidad": cap, "entradas": n_entradas, "ingresos": serie, "total_cent": tot, "total_anterior_cent": tot_ant,
                "variacion_pct": round((tot - tot_ant) * 100 / tot_ant, 1) if tot_ant else None,
                "ticket_medio_cent": round(cobros["medio"] or 0), "estancia_media_min": round(cobros["min_medio"] or 0),
                "num_cobros": cobros["n"], "rotacion": round(n_entradas / cap / dias, 2) if cap else None,
                "tarifas": tarifas, "servicios": servicios, "tipos_vehiculo": tipos}

    # ============================================================ cierre diario y libro de facturas
    def libro_facturas(self, desde, hasta):
        sv = _sv()
        pagos = self.db.q("SELECT p.*, d.nombre cli_nombre, d.nif cli_nif, o.serie o_serie, o.numero o_numero FROM pagos p "
                          "LEFT JOIN facturas_destinatario d ON d.pago_id=p.id LEFT JOIN pagos o ON o.id=COALESCE(p.rectifica_id, p.sustituye_id) "
                          "WHERE substr(p.fecha,1,10) BETWEEN ? AND ? ORDER BY p.fecha, p.serie, p.numero", (desde, hasta))
        tipos = set()
        filas = []
        for p in pagos:
            completo = self._pago_completo(p["id"])
            lineas = [{"iva_pct": d["pct"], "base_cent": d["base"], "cuota_cent": d["cuota"], "total_cent": d["total"]}
                      for d in completo["desglose_iva"]]
            iva = {}
            for l in lineas:
                k = float(l["iva_pct"])
                tipos.add(k)
                b, q = iva.get(k, (0, 0))
                iva[k] = (b + l["base_cent"], q + l["cuota_cent"])
            tipo = {"rectificativa": "Rectificativa", "sustitutiva": "Sustitutiva"}.get(p["concepto"]) or \
                ("Completa" if p["cli_nombre"] else "Simplificada")
            filas.append({"fecha": p["fecha"], "serie": p["serie"], "numero": p["numero"], "tipo": tipo, "concepto": p["concepto"],
                          "nif": p["cli_nif"] or "", "cliente": p["cli_nombre"] or "", "iva": iva, "total": p["importe_cent"],
                          "metodo": sv.texto_metodo(p["metodo"]), "rectifica": f"{p['o_serie']}-{p['o_numero']:06d}" if p["o_serie"] else ""})
        return filas, sorted(tipos, reverse=True)

    def libro_facturas_csv(self, desde, hasta):
        filas, tipos = self.libro_facturas(desde, hasta)
        e = lambda c: f"{c / 100:.2f}".replace(".", ",")  # noqa: E731
        out = io.StringIO()
        w = csv.writer(out, delimiter=";")
        w.writerow(["Fecha", "Hora", "Serie", "Número", "Factura", "Tipo", "NIF cliente", "Cliente"]
                   + [x for t in tipos for x in (f"Base {t:g} %", f"Cuota {t:g} %")] + ["Total", "Forma de pago", "Rectifica / sustituye a"])
        for f in filas:
            w.writerow([f["fecha"][:10], f["fecha"][11:16], f["serie"], f["numero"], f"{f['serie']}-{f['numero']:06d}", f["tipo"], f["nif"], f["cliente"]]
                       + [x for t in tipos for x in (e(f["iva"].get(t, (0, 0))[0]), e(f["iva"].get(t, (0, 0))[1]))]
                       + [e(f["total"]), f["metodo"], f["rectifica"]])
        tot = {t: (sum(f["iva"].get(t, (0, 0))[0] for f in filas), sum(f["iva"].get(t, (0, 0))[1] for f in filas)) for t in tipos}
        w.writerow(["TOTAL", "", "", "", f"{len(filas)} facturas", "", "", ""] + [x for t in tipos for x in (e(tot[t][0]), e(tot[t][1]))]
                   + [e(sum(f["total"] for f in filas)), "", ""])
        return "﻿" + out.getvalue()

    def resumen_cierre(self, dia=None):
        sv = _sv()
        dia = dia or self.ahora().date().isoformat()
        inf = self.informe(dia, dia)
        t = inf["totales"]
        turnos = self.db.q("SELECT t.*, u.nombre usuario_nombre FROM turnos t JOIN usuarios u ON u.id=t.usuario_id "
                           "WHERE substr(COALESCE(t.cierre, t.apertura),1,10)=? ORDER BY t.id", (dia,))
        n_ent = self.db.q1("SELECT COUNT(*) n FROM tickets WHERE substr(entrada,1,10)=? AND estado<>'anulado'", (dia,))["n"]
        oc = self.ocupacion()
        lineas = [f"Resumen del día {datetime.fromisoformat(dia).strftime('%d/%m/%Y')} · {self.cfg('nombre_parking') or 'PROYECTO ALLAS'}", "",
                  f"Total cobrado:      {sv.eur(t.get('total') or 0)}",
                  f"  Efectivo:         {sv.eur(t.get('efectivo') or 0)}",
                  f"  Tarjeta:          {sv.eur(t.get('tarjeta') or 0)}",
                  f"  Online:           {sv.eur(t.get('online') or 0)}",
                  f"  Bonos:            {sv.eur(t.get('bonos') or 0)}",
                  f"  Tienda:           {sv.eur(t.get('tienda') or 0)}",
                  f"Cobros de estancia: {t.get('cobros') or 0}",
                  f"Entradas:           {n_ent}",
                  f"Descuentos:         {sv.eur(t.get('descuentos') or 0)} ({t.get('num_descuentos') or 0})",
                  f"Devoluciones:       {sv.eur(t.get('devoluciones') or 0)} ({t.get('num_devoluciones') or 0})",
                  f"Vehículos dentro ahora: {oc['ocupadas']}" + (f" de {oc['capacidad']}" if oc["capacidad"] else ""), "", "Turnos:"]
        for tu in turnos:
            if tu["estado"] == "cerrado":
                desc = tu.get("diferencia_cent") or 0
                lineas.append(f"  {tu['usuario_nombre']}: cerrado · descuadre {sv.eur(desc)}" + ("  ← REVISAR" if desc else ""))
            else:
                lineas.append(f"  {tu['usuario_nombre']}: abierto")
        lineas += ["", "Se adjunta el libro de facturas del día (CSV, se abre con Excel).", "", "— PROYECTO ALLAS"]
        return "\n".join(lineas)

    def enviar_cierre(self, dia=None, actor_id=None, automatico=False):
        sv = _sv()
        destino = (self.cfg("cierre_email") or "").strip()
        if not destino:
            raise sv.ErrorNegocio("Indique el email que recibe el resumen (Informes → Cierre diario)")
        if not self.smtp_listo():
            raise sv.ErrorNegocio("Configure antes el correo (Ajustes → Conexiones → Email)", 409)
        dia = dia or self.ahora().date().isoformat()
        from .correo import ErrorCorreo, enviar
        csv_txt = self.libro_facturas_csv(dia, dia)
        try:
            for d in [x.strip() for x in re.split(r"[;,\s]+", destino) if x.strip()]:
                enviar(self.db.config(), d, f"Cierre del día {datetime.fromisoformat(dia).strftime('%d/%m/%Y')} - {self.cfg('nombre_parking') or ''}",
                       self.resumen_cierre(dia), [(f"facturas_{dia}.csv", csv_txt.encode("utf-8"), "text/csv")])
        except ErrorCorreo as e:
            self.db.set_cfg("cierre_ultimo_error", f"{sv.iso(self.ahora())} {e}")
            raise sv.ErrorNegocio(f"No se pudo enviar el resumen: {e}")
        self.db.set_cfg("cierre_ultimo_envio", f"{dia} {sv.iso(self.ahora())}")
        self.db.set_cfg("cierre_ultimo_error", "")
        with self.db.transaccion() as c:
            self.auditar(c, actor_id, "cierre_email", f"{dia} → {destino}" + (" (automático)" if automatico else ""))
        return {"ok": True, "destino": destino, "dia": dia}

    def _cierre_tras_turno(self):
        """Al cerrar el último turno abierto del día: resumen por email (si está activado)."""
        if self.cfg("cierre_email_activo") != "1" or self.turnos_abiertos():
            return None
        try:
            return self.enviar_cierre(automatico=True)
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "error": str(e)}

    # ============================================================ ticket digital (SMS / WhatsApp)
    def texto_ticket_digital(self, tk):
        sv = _sv()
        ent = sv.parse(tk["entrada"])
        url = self.url_pago_ticket(tk["codigo"]) if self.pago_movil_activo() else None
        partes = [f"{self.cfg('nombre_parking') or 'Parking'}: ticket {tk['codigo']}",
                  f"Entrada {ent.strftime('%d/%m %H:%M')}" + (f" · {tk['matricula']}" if tk.get("matricula") else "")]
        if tk.get("reserva_hasta"):
            partes.append(f"Reserva hasta {sv.parse(tk['reserva_hasta']).strftime('%d/%m %H:%M')}")
        partes.append(f"Pague y vea su ticket: {url}" if url else "Muestre este mensaje en caja al salir.")
        return "\n".join(partes)

    def enviar_ticket_digital(self, usuario, tk, telefono, canal="sms"):
        """Envía el ticket por SMS o WhatsApp. Con Twilio sale solo; si no, devuelve el enlace de WhatsApp para abrirlo."""
        from . import mensajeria
        sv = _sv()
        movil = self.movil(telefono)
        canal = canal if canal in ("sms", "whatsapp") else "sms"
        if not movil:
            raise sv.ErrorNegocio("Teléfono no válido")
        texto = self.texto_ticket_digital(tk)
        with self.db.transaccion() as c:
            c.execute("UPDATE tickets SET telefono_digital=? WHERE id=?", (movil, tk["id"]))
            self.auditar(c, usuario["id"], "ticket_digital", f"{tk['codigo']} → {movil} ({canal})")
        if self.msg_modo() == "twilio":
            try:
                desde = self.cfg("twilio_desde_whatsapp" if canal == "whatsapp" else "twilio_desde_sms")
                self._twilio().enviar(desde, movil, texto, canal)
                return {"enviado": True, "telefono": movil, "canal": canal}
            except Exception as e:  # noqa: BLE001
                return {"enviado": False, "error": str(e), "enlace": mensajeria.enlace_whatsapp(movil, texto), "telefono": movil}
        return {"enviado": False, "enlace": mensajeria.enlace_whatsapp(movil, texto), "telefono": movil, "texto": texto}

    # ============================================================ estado del vehículo al entrar
    @property
    def carpeta_fotos_tickets(self):
        return os.path.join(self.carpeta_datos, "fotos_tickets")

    def guardar_estado_vehiculo(self, usuario, tid, nota):
        with self.db.transaccion() as c:
            if not c.execute("UPDATE tickets SET estado_nota=? WHERE id=?", ((nota or "").strip()[:500] or None, int(tid))).rowcount:
                raise _sv().ErrorNegocio("Ticket no encontrado", 404)
            self.auditar(c, usuario["id"], "ticket_estado", f"id={tid} {(nota or '')[:80]}")
        return self.estado_vehiculo(tid)

    def anadir_foto_ticket(self, usuario, tid, jpeg):
        sv = _sv()
        if not jpeg or jpeg[:3] != b"\xff\xd8\xff":
            raise sv.ErrorNegocio("La foto debe ser JPEG")
        if len(jpeg) > 3_000_000:
            raise sv.ErrorNegocio("La foto es demasiado grande (máx. 3 MB)")
        if self.db.q1("SELECT COUNT(*) n FROM ticket_fotos WHERE ticket_id=?", (int(tid),))["n"] >= 6:
            raise sv.ErrorNegocio("Como mucho 6 fotos por ticket")
        self.ticket(int(tid))
        os.makedirs(self.carpeta_fotos_tickets, exist_ok=True)
        nombre = f"{int(tid)}_{datetime.now().strftime('%Y%m%d%H%M%S%f')}.jpg"
        with open(os.path.join(self.carpeta_fotos_tickets, nombre), "wb") as f:
            f.write(jpeg)
        with self.db.transaccion() as c:
            c.execute("INSERT INTO ticket_fotos(ticket_id, archivo, fecha, usuario_id) VALUES(?,?,?,?)",
                      (int(tid), nombre, sv.iso(self.ahora()), usuario["id"]))
            self.auditar(c, usuario["id"], "ticket_foto", f"id={tid}")
        return self.estado_vehiculo(tid)

    def estado_vehiculo(self, tid):
        t = self.db.q1("SELECT id, estado_nota FROM tickets WHERE id=?", (int(tid),))
        if not t:
            raise _sv().ErrorNegocio("Ticket no encontrado", 404)
        fotos = self.db.q("SELECT id, fecha FROM ticket_fotos WHERE ticket_id=? ORDER BY id", (int(tid),))
        return {"ticket_id": t["id"], "nota": t["estado_nota"], "fotos": fotos}

    def foto_ticket(self, tid, fid):
        f = self.db.q1("SELECT archivo FROM ticket_fotos WHERE id=? AND ticket_id=?", (int(fid), int(tid)))
        if not f:
            raise _sv().ErrorNegocio("Foto no encontrada", 404)
        with open(os.path.join(self.carpeta_fotos_tickets, os.path.basename(f["archivo"])), "rb") as fh:
            return fh.read()

    # ============================================================ permisos por usuario
    def permisos_de(self, usuario):
        """Permisos efectivos: los de su rol, más o menos los que el administrador haya cambiado."""
        if not usuario:
            return set()
        if usuario.get("rol") == "admin":
            return {p for p, _, _ in PERMISOS}
        base = {p for p, _, roles in PERMISOS if usuario.get("rol") in roles}
        fila = self.db.q1("SELECT permisos FROM usuarios WHERE id=?", (usuario["id"],)) if usuario.get("id") else None
        try:
            extra = json.loads((fila or {}).get("permisos") or "{}")
        except ValueError:
            extra = {}
        for p, v in extra.items():
            if p in NOMBRES_PERMISO:
                (base.add if v else base.discard)(p)
        return base

    def puede(self, usuario, permiso):
        return permiso in self.permisos_de(usuario)

    def _exigir_permiso(self, usuario, permiso):
        if not self.puede(usuario, permiso):
            raise _sv().ErrorNegocio(f"No tiene permiso: {NOMBRES_PERMISO.get(permiso, permiso)}", 403)

    def catalogo_permisos(self, uid):
        u = self.db.q1("SELECT id, nombre, rol, permisos FROM usuarios WHERE id=?", (int(uid),))
        if not u:
            raise _sv().ErrorNegocio("Usuario no encontrado", 404)
        efectivos = self.permisos_de(u)
        return {"usuario": {k: u[k] for k in ("id", "nombre", "rol")},
                "permisos": [{"id": p, "nombre": n, "de_serie": u["rol"] in roles or u["rol"] == "admin", "activo": p in efectivos}
                             for p, n, roles in PERMISOS]}

    def guardar_permisos(self, actor_id, uid, activos):
        sv = _sv()
        u = self.db.q1("SELECT id, rol, nombre FROM usuarios WHERE id=?", (int(uid),))
        if not u:
            raise sv.ErrorNegocio("Usuario no encontrado", 404)
        if u["rol"] == "admin":
            raise sv.ErrorNegocio("El administrador tiene siempre todos los permisos")
        activos = set(activos or [])
        cambios = {}
        for p, _, roles in PERMISOS:
            serie = u["rol"] in roles
            if (p in activos) != serie:
                cambios[p] = p in activos
        with self.db.transaccion() as c:
            c.execute("UPDATE usuarios SET permisos=? WHERE id=?", (json.dumps(cambios) if cambios else None, u["id"]))
            self.auditar(c, actor_id, "permisos", f"{u['nombre']}: " + (", ".join(f"{'+' if v else '-'}{k}" for k, v in cambios.items()) or "los de su rol"))
        return self.catalogo_permisos(uid)

    # ============================================================ auditoría con filtros
    def auditoria_buscar(self, desde=None, hasta=None, usuario_id=None, accion="", texto="", limite=500):
        sql = "SELECT a.*, u.nombre usuario_nombre FROM auditoria a LEFT JOIN usuarios u ON u.id=a.usuario_id WHERE 1=1"
        args = []
        if desde:
            sql += " AND substr(a.fecha,1,10)>=?"
            args.append(desde)
        if hasta:
            sql += " AND substr(a.fecha,1,10)<=?"
            args.append(hasta)
        if usuario_id:
            sql += " AND a.usuario_id=?"
            args.append(int(usuario_id))
        if accion:
            sql += " AND a.accion LIKE ?"
            args.append(accion + "%")
        if texto:
            sql += " AND (a.detalle LIKE ? OR a.accion LIKE ?)"
            args += [f"%{texto}%", f"%{texto}%"]
        filas = self.db.q(sql + " ORDER BY a.id DESC LIMIT ?", args + [max(1, min(5000, int(limite or 500)))])
        acciones = [r["accion"] for r in self.db.q("SELECT DISTINCT accion FROM auditoria ORDER BY accion")]
        return {"filas": filas, "acciones": acciones}

    def auditoria_csv(self, **filtros):
        r = self.auditoria_buscar(**filtros, limite=5000)
        out = io.StringIO()
        w = csv.writer(out, delimiter=";")
        w.writerow(["Fecha", "Hora", "Usuario", "Acción", "Detalle"])
        for f in r["filas"]:
            w.writerow([f["fecha"][:10], f["fecha"][11:19], f["usuario_nombre"] or "(sistema)", f["accion"], f["detalle"] or ""])
        return "﻿" + out.getvalue()

    # ============================================================ pago desde el móvil (QR del ticket)
    def pago_movil_activo(self):
        return self.cfg("pago_movil_activo") == "1" and self.activo("pagos_online_activo", "pagos_online") \
            and bool(self.cfg("stripe_clave")) and bool(self.url_publica())

    def url_publica(self):
        u = (self.cfg("pago_movil_url") or "").strip().rstrip("/")
        if u and not u.startswith(("http://", "https://")):
            u = "https://" + u
        return u

    def url_pago_ticket(self, codigo):
        return f"{self.url_publica()}/pagar?c={codigo}"

    def info_publica_ticket(self, codigo):
        """Lo que ve el cliente en su móvil: importe, entrada y su QR. Sin datos personales."""
        sv = _sv()
        tid = self._id_desde_codigo(codigo)
        tk = self.ticket(tid)
        res = {"codigo": tk["codigo"], "parking": self.cfg("nombre_parking") or "", "entrada": tk["entrada"],
               "estado": tk["estado"], "puede_pagar": False, "pendiente_cent": 0,
               "matricula": (tk["matricula"][:2] + "•" * max(0, len(tk["matricula"]) - 5) + tk["matricula"][-3:]) if tk.get("matricula") else None}
        from .codigos import qr_svg
        res["qr"] = qr_svg(tk["codigo"], modulo=6)
        if tk["estado"] in ("salido", "anulado"):
            res["mensaje"] = "Este ticket ya no está activo." if tk["estado"] == "anulado" else "Este vehículo ya ha salido."
            return res
        liq = self._liquidar(tk, self.ahora())
        res["minutos"] = liq["minutos"]
        res["pendiente_cent"] = liq["pendiente_cent"]
        if liq.get("reserva"):
            res["reserva_hasta"] = liq["reserva"]["hasta"]
        if liq["dentro_de_plazo"]:
            res["pagado"] = True
            res["salida_limite"] = tk["salida_limite"]
            res["mensaje"] = f"Pagado. Puede salir hasta las {sv.parse(tk['salida_limite']).strftime('%H:%M')}."
        elif liq.get("abonado") and liq["abonado"].get("vigente"):
            res["mensaje"] = "Abonado con bono en vigor: no tiene que pagar."
        elif liq["pendiente_cent"] <= 0:
            res["mensaje"] = "No tiene nada que pagar: puede salir."
        else:
            res["puede_pagar"] = self.pago_movil_activo()
        res["minutos_salida"] = int(self.cfg("pago_movil_minutos") or self.cfg("minutos_salida") or 15)
        return res

    def crear_pago_movil(self, codigo):
        sv = _sv()
        if not self.pago_movil_activo():
            raise sv.ErrorNegocio("El pago con el móvil no está disponible en este parking", 409)
        tid = self._id_desde_codigo(codigo)
        tk = self.ticket(tid)
        if tk["estado"] not in ("dentro", "pagado"):
            raise sv.ErrorNegocio("Este ticket ya no está activo", 409)
        momento = self.ahora()
        liq = self._liquidar(tk, momento)
        if liq["dentro_de_plazo"] or liq["pendiente_cent"] <= 0:
            raise sv.ErrorNegocio("No hay nada que pagar", 409)
        base = self.url_publica()
        ses = self._stripe().crear_sesion_pago(
            liq["pendiente_cent"], f"Estacionamiento · ticket {tk['codigo']}",
            f"{base}/pagar?c={tk['codigo']}&s={{CHECKOUT_SESSION_ID}}", f"{base}/pagar?c={tk['codigo']}",
            {"ticket_id": tk["id"], "codigo": tk["codigo"], "origen": "PROYECTO ALLAS"})
        with self.db.transaccion() as c:
            c.execute("INSERT INTO pagos_movil(ticket_id, sesion, importe_cent, calculo_en, creada) VALUES(?,?,?,?,?)",
                      (tk["id"], ses["id"], liq["pendiente_cent"], sv.iso(momento), sv.iso(momento)))
        return {"url": ses["url"], "importe_cent": liq["pendiente_cent"]}

    def confirmar_pago_movil(self, sesion):
        """Comprueba en Stripe que el pago está hecho y lo registra (factura simplificada, método «online»)."""
        sv = _sv()
        pm = self.db.q1("SELECT * FROM pagos_movil WHERE sesion=?", (sesion,))
        if not pm:
            raise sv.ErrorNegocio("Pago no encontrado", 404)
        if pm["estado"] == "pagado":
            return {"estado": "pagado", "pago_id": pm["pago_id"]}
        s = self._stripe().sesion(sesion)
        if s.get("payment_status") != "paid":
            if s.get("status") == "expired":
                self.db.ex("UPDATE pagos_movil SET estado='caducado' WHERE id=?", (pm["id"],))
                return {"estado": "caducado"}
            return {"estado": "pendiente"}
        meta = s.get("metadata") or {}
        if str(meta.get("ticket_id")) != str(pm["ticket_id"]) or int(s.get("amount_total") or 0) != pm["importe_cent"]:
            self.db.ex("UPDATE pagos_movil SET estado='error', detalle=? WHERE id=?", ("importe o ticket no coinciden", pm["id"]))
            raise sv.ErrorNegocio("El pago no coincide con el ticket", 409)
        momento = sv.parse(pm["calculo_en"])
        with self.db.transaccion() as c:
            if c.execute("SELECT pago_id FROM pagos_movil WHERE id=? AND estado='pagado'", (pm["id"],)).fetchone():
                return {"estado": "pagado"}
            tk = self.ticket(pm["ticket_id"])
            if tk["estado"] in ("salido", "anulado"):
                c.execute("UPDATE pagos_movil SET estado='error', detalle=? WHERE id=?",
                          (f"ticket {tk['estado']}: devuelva {sv.eur(pm['importe_cent'])} desde Stripe", pm["id"]))
                self.auditar(c, None, "pago_movil_error", f"{tk['codigo']} ya {tk['estado']}; sesión {sesion}")
                return {"estado": "error"}
            liq = self._liquidar(tk, momento)
            pendientes = [e for e in tk["extras"] if not e["pago_id"]]
            iva_gen = float(self.cfg("iva_pct") or 21)
            lineas = [(pm["importe_cent"] - liq["extras_pendientes_cent"], iva_gen)] + \
                [(e["precio_cent"] * e["cantidad"], e["iva_pct"]) for e in pendientes]
            pago = self._insertar_pago(c, None, None, pm["importe_cent"], "online", None, None, ticket_id=tk["id"],
                                       minutos=liq["minutos"], extras=liq["extras_pendientes_cent"], lineas=lineas,
                                       online_ref=sesion, referencia=(s.get("payment_intent") or "")[:60] or None)
            if pendientes:
                c.execute("UPDATE ticket_extras SET pago_id=? WHERE ticket_id=? AND pago_id IS NULL", (pago["id"], tk["id"]))
            minutos = int(self.cfg("pago_movil_minutos") or self.cfg("minutos_salida") or 15)
            limite = sv.iso(self.ahora() + timedelta(minutes=minutos))
            c.execute("UPDATE tickets SET estado='pagado', salida_limite=? WHERE id=?", (limite, tk["id"]))
            c.execute("UPDATE pagos_movil SET estado='pagado', pago_id=? WHERE id=?", (pago["id"], pm["id"]))
            self.auditar(c, None, "pago_movil", f"{tk['codigo']} {pm['importe_cent']} sesión {sesion}")
        return {"estado": "pagado", "pago_id": pago["id"], "salida_limite": limite}

    def sincronizar_pagos_movil(self):
        """Por si el cliente cerró el navegador antes de volver: revisa las sesiones pendientes de las últimas 24 h."""
        sv = _sv()
        hechos = 0
        desde = sv.iso(self.ahora() - timedelta(hours=24))
        for pm in self.db.q("SELECT sesion FROM pagos_movil WHERE estado='pendiente' AND creada>=?", (desde,)):
            try:
                if self.confirmar_pago_movil(pm["sesion"]).get("estado") == "pagado":
                    hechos += 1
            except Exception:  # noqa: BLE001
                continue
        return hechos
