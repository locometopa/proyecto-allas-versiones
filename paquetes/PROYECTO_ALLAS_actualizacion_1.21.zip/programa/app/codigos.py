"""Generadores de QR y Code128 en Python puro (sin dependencias).

La impresora térmica genera sus propios códigos con comandos ESC/POS; estos
generadores sirven para la VISTA PREVIA en pantalla (SVG), de modo que lo que
se ve sea lo que se imprime. También permitirían imprimir como imagen en
impresoras sin QR nativo.

QR: modo byte, corrección M, versiones 1-10, elección de máscara por penalización
(algoritmo de la norma ISO/IEC 18004, estructura inspirada en el generador de
Project Nayuki, MIT).
"""

# =============================================================== Code 128
_C128 = [
    "212222", "222122", "222221", "121223", "121322", "131222", "122213", "122312", "132212", "221213",
    "221312", "231212", "112232", "122132", "122231", "113222", "123122", "123221", "223211", "221132",
    "221231", "213212", "223112", "312131", "311222", "321122", "321221", "312212", "322112", "322211",
    "212123", "212321", "232121", "111323", "131123", "131321", "112313", "132113", "132311", "211313",
    "231113", "231311", "112133", "112331", "132131", "113123", "113321", "133121", "313121", "211331",
    "231131", "213113", "213311", "213131", "311123", "311321", "331121", "312113", "312311", "332111",
    "314111", "221411", "431111", "111224", "111422", "121124", "121421", "141122", "141221", "112214",
    "112412", "122114", "122411", "142112", "142211", "241211", "221114", "413111", "241112", "134111",
    "111242", "121142", "121241", "114212", "124112", "124211", "411212", "421112", "421211", "212141",
    "214121", "412121", "111143", "111341", "131141", "114113", "114311", "411113", "411311", "113141",
    "114131", "311141", "411131", "211412", "211214", "211232", "2331112",
]
_START_B, _STOP = 104, 106


def code128_valores(texto):
    """Valores de símbolo Code128 (juego B) con inicio, control y parada."""
    for ch in texto:
        if not 32 <= ord(ch) <= 126:
            raise ValueError("Code128-B solo admite ASCII imprimible")
    vals = [_START_B] + [ord(ch) - 32 for ch in texto]
    control = (vals[0] + sum(i * v for i, v in enumerate(vals[1:], 1))) % 103
    return vals + [control, _STOP]


def code128_modulos(texto):
    """Lista de anchos alternos barra/espacio (empieza en barra)."""
    anchos = []
    for v in code128_valores(texto):
        anchos += [int(c) for c in _C128[v]]
    return anchos


def code128_svg(texto, modulo=2, alto=60, margen=10):
    anchos = code128_modulos(texto)
    total = sum(anchos) * modulo + 2 * margen
    x, rects = margen, []
    for i, w in enumerate(anchos):
        if i % 2 == 0:
            rects.append(f'<rect x="{x}" y="0" width="{w * modulo}" height="{alto}"/>')
        x += w * modulo
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {total} {alto}" '
            f'width="{total}" height="{alto}" shape-rendering="crispEdges">'
            f'<rect width="100%" height="100%" fill="#fff"/><g fill="#000">{"".join(rects)}</g></svg>')


# ===================================================================== QR
_ECC_M_POR_BLOQUE = [None, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26]
_BLOQUES_M = [None, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5]


def _modulos_datos_brutos(ver):
    r = (16 * ver + 128) * ver + 64
    if ver >= 2:
        n = ver // 7 + 2
        r -= (25 * n - 10) * n - 55
        if ver >= 7:
            r -= 36
    return r


def _codewords_datos(ver):
    return _modulos_datos_brutos(ver) // 8 - _ECC_M_POR_BLOQUE[ver] * _BLOQUES_M[ver]


def _gf_mul(x, y):
    z = 0
    for i in reversed(range(8)):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z


def _rs_divisor(grado):
    r = [0] * (grado - 1) + [1]
    raiz = 1
    for _ in range(grado):
        for j in range(grado):
            r[j] = _gf_mul(r[j], raiz)
            if j + 1 < grado:
                r[j] ^= r[j + 1]
        raiz = _gf_mul(raiz, 0x02)
    return r


def _rs_resto(datos, divisor):
    r = [0] * len(divisor)
    for b in datos:
        f = b ^ r.pop(0)
        r.append(0)
        for i, c in enumerate(divisor):
            r[i] ^= _gf_mul(c, f)
    return r


def _posiciones_alineacion(ver):
    if ver == 1:
        return []
    n = ver // 7 + 2
    paso = (ver * 8 + n * 3 + 5) // (n * 4 - 4) * 2
    r = [ver * 4 + 10 - i * paso for i in range(n - 1)] + [6]
    return list(reversed(r))


class _Matriz:
    def __init__(self, ver):
        self.ver = ver
        self.n = ver * 4 + 17
        self.m = [[False] * self.n for _ in range(self.n)]
        self.func = [[False] * self.n for _ in range(self.n)]

    def poner(self, x, y, v):
        self.m[y][x] = v
        self.func[y][x] = True

    def patrones(self):
        n = self.n
        for i in range(n):  # temporización
            self.poner(6, i, i % 2 == 0)
            self.poner(i, 6, i % 2 == 0)
        for cx, cy in ((3, 3), (n - 4, 3), (3, n - 4)):  # buscadores + separadores
            for dy in range(-4, 5):
                for dx in range(-4, 5):
                    x, y = cx + dx, cy + dy
                    if 0 <= x < n and 0 <= y < n:
                        d = max(abs(dx), abs(dy))
                        self.poner(x, y, d not in (2, 4))
        pos = _posiciones_alineacion(self.ver)
        k = len(pos)
        for i in range(k):
            for j in range(k):
                if (i == 0 and j == 0) or (i == 0 and j == k - 1) or (i == k - 1 and j == 0):
                    continue
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        self.poner(pos[i] + dx, pos[j] + dy, max(abs(dx), abs(dy)) != 1)
        self.formato(0)
        self.version()

    def formato(self, mascara):
        datos = (0 << 3) | mascara  # nivel M = 00
        r = datos
        for _ in range(10):
            r = (r << 1) ^ ((r >> 9) * 0x537)
        bits = (datos << 10 | r) ^ 0x5412
        b = lambda i: (bits >> i) & 1 != 0
        for i in range(6):
            self.poner(8, i, b(i))
        self.poner(8, 7, b(6))
        self.poner(8, 8, b(7))
        self.poner(7, 8, b(8))
        for i in range(9, 15):
            self.poner(14 - i, 8, b(i))
        n = self.n
        for i in range(8):
            self.poner(n - 1 - i, 8, b(i))
        for i in range(8, 15):
            self.poner(8, n - 15 + i, b(i))
        self.poner(8, n - 8, True)  # módulo oscuro

    def version(self):
        if self.ver < 7:
            return
        r = self.ver
        for _ in range(12):
            r = (r << 1) ^ ((r >> 11) * 0x1F25)
        bits = self.ver << 12 | r
        for i in range(18):
            bit = (bits >> i) & 1 != 0
            a, b = self.n - 11 + i % 3, i // 3
            self.poner(a, b, bit)
            self.poner(b, a, bit)

    def codewords(self, datos):
        n, i = self.n, 0
        for der in range(n - 1, 0, -2):
            if der <= 6:  # saltar la columna de temporización
                der -= 1
            for vert in range(n):
                for j in range(2):
                    x = der - j
                    subiendo = ((der + 1) & 2) == 0
                    y = n - 1 - vert if subiendo else vert
                    if not self.func[y][x] and i < len(datos) * 8:
                        self.m[y][x] = (datos[i >> 3] >> (7 - (i & 7))) & 1 != 0
                        i += 1

    def aplicar_mascara(self, k):
        f = [lambda x, y: (x + y) % 2 == 0, lambda x, y: y % 2 == 0, lambda x, y: x % 3 == 0,
             lambda x, y: (x + y) % 3 == 0, lambda x, y: (x // 3 + y // 2) % 2 == 0,
             lambda x, y: x * y % 2 + x * y % 3 == 0, lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0,
             lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0][k]
        for y in range(self.n):
            for x in range(self.n):
                if not self.func[y][x] and f(x, y):
                    self.m[y][x] = not self.m[y][x]

    def penalizacion(self):
        n, m, p = self.n, self.m, 0
        for filas in (m, [list(c) for c in zip(*m)]):
            for fila in filas:
                racha, color = 0, None
                for v in fila:
                    if v == color:
                        racha += 1
                    else:
                        if racha >= 5:
                            p += racha - 2
                        racha, color = 1, v
                if racha >= 5:
                    p += racha - 2
                s = "".join("1" if v else "0" for v in fila)
                for pat in ("10111010000", "00001011101"):
                    p += 40 * s.count(pat)
        for y in range(n - 1):
            for x in range(n - 1):
                c = m[y][x]
                if c == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                    p += 3
        oscuros = sum(sum(f) for f in m)
        total = n * n
        k = (abs(oscuros * 20 - total * 10) + total - 1) // total - 1
        return p + k * 10


def qr_matriz(texto):
    datos = texto.encode("utf-8")
    for ver in range(1, 11):
        cap = _codewords_datos(ver) * 8
        bits_cc = 8 if ver < 10 else 16
        if 4 + bits_cc + len(datos) * 8 <= cap:
            break
    else:
        raise ValueError("Texto demasiado largo para QR v10-M")
    bits = [0, 1, 0, 0] + [(len(datos) >> i) & 1 for i in reversed(range(bits_cc))]
    for b in datos:
        bits += [(b >> i) & 1 for i in reversed(range(8))]
    bits += [0] * min(4, cap - len(bits))
    bits += [0] * (-len(bits) % 8)
    cw = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    pad = 0xEC
    while len(cw) < cap // 8:
        cw.append(pad)
        pad ^= 0xEC ^ 0x11

    # bloques + corrección + entrelazado
    nb, ecl = _BLOQUES_M[ver], _ECC_M_POR_BLOQUE[ver]
    brutos = _modulos_datos_brutos(ver) // 8
    cortos = nb - brutos % nb
    largo_corto = brutos // nb
    div = _rs_divisor(ecl)
    bloques, k = [], 0
    for i in range(nb):
        d = cw[k:k + largo_corto - ecl + (0 if i < cortos else 1)]
        k += len(d)
        e = _rs_resto(d, div)
        if i < cortos:
            d = d + [0]
        bloques.append(d + e)
    final = []
    for i in range(len(bloques[0])):
        for j, b in enumerate(bloques):
            if i != largo_corto - ecl or j >= cortos:
                final.append(b[i])

    mejor, mejor_p = None, None
    for mascara in range(8):
        q = _Matriz(ver)
        q.patrones()
        q.codewords(final)
        q.aplicar_mascara(mascara)
        q.formato(mascara)
        p = q.penalizacion()
        if mejor_p is None or p < mejor_p:
            mejor, mejor_p = q, p
    return mejor.m


def qr_svg(texto, modulo=4, borde=4):
    m = qr_matriz(texto)
    n = len(m)
    tam = (n + 2 * borde) * modulo
    rects = [f'<rect x="{(x + borde) * modulo}" y="{(y + borde) * modulo}" width="{modulo}" height="{modulo}"/>'
             for y in range(n) for x in range(n) if m[y][x]]
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {tam} {tam}" width="{tam}" height="{tam}" '
            f'shape-rendering="crispEdges"><rect width="100%" height="100%" fill="#fff"/>'
            f'<g fill="#000">{"".join(rects)}</g></svg>')


def qr_png(texto, modulo=6, borde=4):
    """1.18: el mismo QR como imagen PNG (para adjuntarlo a un email; los correos no muestran SVG)."""
    import struct
    import zlib
    m = qr_matriz(texto)
    n = len(m)
    lado = (n + 2 * borde) * modulo
    blanco = b"\xff" * (lado)
    filas = []
    for y in range(-borde, n + borde):
        if 0 <= y < n:
            fila = bytearray()
            for x in range(-borde, n + borde):
                fila += (b"\x00" if 0 <= x < n and m[y][x] else b"\xff") * modulo
        else:
            fila = bytearray(blanco)
        filas += [b"\x00" + bytes(fila)] * modulo

    def trozo(tipo, datos):
        c = tipo + datos
        return struct.pack(">I", len(datos)) + c + struct.pack(">I", zlib.crc32(c) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + trozo(b"IHDR", struct.pack(">IIBBBBB", lado, lado, 8, 0, 0, 0, 0))
            + trozo(b"IDAT", zlib.compress(b"".join(filas), 9)) + trozo(b"IEND", b""))
