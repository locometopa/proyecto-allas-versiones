"""PROYECTO ALLAS · lógica de negocio: usuarios, acceso y bloqueos (1.4: sale de servicios.py; se mezcla en la clase Parking)."""
import hmac
import secrets
from datetime import timedelta

from .utiles import ErrorNegocio, hash_pin, iso, parse


class SvcUsuarios:
    # ============================================================ usuarios
    def crear_usuario(self, nombre, usuario, pin, rol, actor_id=None):
        if not pin or len(pin) < 4 or not pin.isdigit():
            raise ErrorNegocio("El PIN debe tener al menos 4 dígitos")
        if rol not in ("admin", "supervisor", "cajero"):
            raise ErrorNegocio("Rol no válido")
        salt = secrets.token_hex(16)
        with self.db.transaccion() as c:
            if c.execute("SELECT 1 FROM usuarios WHERE usuario=?", (usuario,)).fetchone():
                raise ErrorNegocio("Ese nombre de usuario ya existe")
            cur = c.execute("INSERT INTO usuarios(nombre, usuario, pin_hash, pin_salt, rol, creado) "
                            "VALUES(?,?,?,?,?,?)",
                            (nombre, usuario, hash_pin(pin, salt), salt, rol, iso(self.ahora())))
            self.auditar(c, actor_id, "usuario_crear", f"{usuario} ({rol})")
            return cur.lastrowid

    def actualizar_usuario(self, uid, actor_id, nombre=None, rol=None, activo=None, pin=None):
        with self.db.transaccion() as c:
            u = c.execute("SELECT * FROM usuarios WHERE id=?", (uid,)).fetchone()
            if not u:
                raise ErrorNegocio("Usuario no encontrado", 404)
            if nombre:
                c.execute("UPDATE usuarios SET nombre=? WHERE id=?", (nombre, uid))
            if rol:
                c.execute("UPDATE usuarios SET rol=? WHERE id=?", (rol, uid))
            if activo is not None:
                if not activo and uid == actor_id:
                    raise ErrorNegocio("No puede desactivarse a sí mismo")
                c.execute("UPDATE usuarios SET activo=? WHERE id=?", (1 if activo else 0, uid))
            if pin:
                if len(pin) < 4 or not pin.isdigit():
                    raise ErrorNegocio("El PIN debe tener al menos 4 dígitos")
                salt = secrets.token_hex(16)
                c.execute("UPDATE usuarios SET pin_hash=?, pin_salt=? WHERE id=?",
                          (hash_pin(pin, salt), salt, uid))
            # Debe quedar al menos un admin activo
            n = c.execute("SELECT COUNT(*) FROM usuarios WHERE rol='admin' AND activo=1 AND eliminado=0").fetchone()[0]
            if n == 0:
                raise ErrorNegocio("Debe quedar al menos un administrador activo")
            self.auditar(c, actor_id, "usuario_editar", f"id={uid}")

    # ------------------------------------------------------------ 3.9: bloqueo tras PIN fallidos
    def _cfg_acceso(self):
        return (max(3, self.cfg("acceso_intentos", int) or 5), max(1, self.cfg("acceso_bloqueo_min", int) or 5))

    def _bloqueo(self, clave):
        r = self.db.q1("SELECT * FROM bloqueos_acceso WHERE clave=?", (clave,))
        if r and r["hasta"] and parse(r["hasta"]) > self.ahora():
            return r
        return None

    def _fallo_acceso(self, claves):
        intentos, minutos = self._cfg_acceso()
        ahora = self.ahora()
        bloqueado = False
        with self.db.transaccion() as c:
            for clave, maximo in claves:
                r = c.execute("SELECT fallos, ultimo FROM bloqueos_acceso WHERE clave=?", (clave,)).fetchone()
                fallos = (r[0] if r and r[1] and ahora - parse(r[1]) < timedelta(hours=1) else 0) + 1
                hasta = None
                if fallos >= maximo:
                    hasta, bloqueado = iso(ahora + timedelta(minutes=minutos)), True
                    fallos = 0
                    self.auditar(c, None, "acceso_bloqueado", f"{clave} {minutos} min")
                c.execute("INSERT INTO bloqueos_acceso(clave, fallos, ultimo, hasta) VALUES(?,?,?,?) "
                          "ON CONFLICT(clave) DO UPDATE SET fallos=excluded.fallos, ultimo=excluded.ultimo, "
                          "hasta=COALESCE(excluded.hasta, bloqueos_acceso.hasta)", (clave, fallos, iso(ahora), hasta))
        return bloqueado

    def bloqueos_activos(self):
        return [r for r in self.db.q("SELECT * FROM bloqueos_acceso WHERE hasta IS NOT NULL ORDER BY hasta DESC")
                if parse(r["hasta"]) > self.ahora()]

    def desbloquear_acceso(self, actor_id, clave=None):
        with self.db.transaccion() as c:
            if clave:
                c.execute("DELETE FROM bloqueos_acceso WHERE clave=?", (clave,))
            else:
                c.execute("DELETE FROM bloqueos_acceso")
            self.auditar(c, actor_id, "acceso_desbloquear", clave or "todos")
        return {"ok": True}

    def autenticar(self, usuario, pin, origen=None):
        """Comprueba usuario y PIN. Tras varios fallos seguidos (5 por defecto) el usuario queda bloqueado unos
        minutos; y una misma dirección de red que falla muchas veces (con cualquier usuario), también."""
        intentos, minutos = self._cfg_acceso()
        claves = [(f"usuario:{(usuario or '').strip().lower()}", intentos)]
        if origen:
            claves.append((f"ip:{origen}", intentos * 4))
        for clave, _ in claves:
            b = self._bloqueo(clave)
            if b:
                quedan = max(1, -(-int((parse(b["hasta"]) - self.ahora()).total_seconds()) // 60))
                raise ErrorNegocio(f"Demasiados intentos fallidos. Espere {quedan} minuto{'s' if quedan != 1 else ''} "
                                   "o pida a un administrador que lo desbloquee.", 429)
        u = self.db.q1("SELECT * FROM usuarios WHERE usuario=? AND activo=1", (usuario,))
        if not u or not hmac.compare_digest(u["pin_hash"], hash_pin(pin or "", u["pin_salt"])):
            with self.db.transaccion() as c:
                self.auditar(c, None, "login_fallido", f"{usuario}" + (f" desde {origen}" if origen else ""))
            if self._fallo_acceso(claves):
                raise ErrorNegocio(f"Demasiados intentos fallidos: bloqueado durante {minutos} minutos.", 429)
            raise ErrorNegocio("Usuario o PIN incorrectos", 401)
        with self.db.transaccion() as c:
            c.execute("DELETE FROM bloqueos_acceso WHERE clave=?", (claves[0][0],))
            self.auditar(c, u["id"], "login", f"desde {origen}" if origen else "")
        return {k: u[k] for k in ("id", "nombre", "usuario", "rol")}

    def usuarios(self):
        return self.db.q("SELECT id, nombre, usuario, rol, activo, creado FROM usuarios WHERE eliminado=0 ORDER BY nombre")

    def hay_usuarios(self):
        return self.db.q1("SELECT COUNT(*) n FROM usuarios")["n"] > 0
