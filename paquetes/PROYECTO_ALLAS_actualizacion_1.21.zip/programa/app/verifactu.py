"""VERI*FACTU (Real Decreto 1007/2023 y Orden HAC/1177/2024) · PREPARACIÓN, desactivado por defecto.

Qué hay hecho:
  - Registro de facturación de alta por cada factura, con su huella SHA-256 encadenada a la anterior
    con el formato de la AEAT («Detalle de las especificaciones técnicas para la generación de la huella»).
  - URL del código QR para cotejar la factura en la sede de la AEAT (se imprime en el ticket y en el PDF).
  - XML del registro (RegistroAlta) listo para incluirlo en el envío.

Qué falta para usarlo en producción (por eso está desactivado):
  - El envío a la AEAT (servicio web SOAP con certificado electrónico de la empresa), probarlo en el entorno
    de pruebas de la AEAT y la declaración responsable del sistema informático.
  - Registros de anulación y subsanación.
Fechas de obligación (RDL 15/2025): sociedades 1-1-2027; resto de obligados 1-7-2027.
"""
import hashlib
from urllib.parse import urlencode
from xml.sax.saxutils import escape

URL_QR = {"pruebas": "https://prewww2.aeat.es/wlpl/TIKE-CONT/ValidarQR",
          "produccion": "https://www2.agenciatributaria.gob.es/wlpl/TIKE-CONT/ValidarQR"}

SISTEMA = {"nombre": "PROYECTO ALLAS", "id": "PA"}


def importe(cent):
    """Importe con punto decimal y dos decimales (12.35)."""
    signo = "-" if cent < 0 else ""
    cent = abs(int(cent))
    return f"{signo}{cent // 100}.{cent % 100:02d}"


def huella_alta(nif, num_serie, fecha_expedicion, tipo_factura, cuota_cent, importe_cent, huella_anterior,
                fecha_generacion):
    """Huella del registro de alta: SHA-256 (hex en mayúsculas) de los campos en este orden y formato."""
    cadena = (f"IDEmisorFactura={nif.strip()}&NumSerieFactura={num_serie.strip()}"
              f"&FechaExpedicionFactura={fecha_expedicion}&TipoFactura={tipo_factura}"
              f"&CuotaTotal={importe(cuota_cent)}&ImporteTotal={importe(importe_cent)}"
              f"&Huella={huella_anterior or ''}&FechaHoraHusoGenRegistro={fecha_generacion}")
    return hashlib.sha256(cadena.encode("utf-8")).hexdigest().upper()


def url_qr(nif, num_serie, fecha_expedicion, importe_cent, entorno="pruebas"):
    return URL_QR.get(entorno, URL_QR["pruebas"]) + "?" + urlencode(
        {"nif": nif, "numserie": num_serie, "fecha": fecha_expedicion, "importe": importe(importe_cent)})


def xml_registro_alta(r, emisor_nombre, desglose, version_programa, nif_productor="", destinatario=None):
    """RegistroAlta según el esquema SuministroInformacion de la AEAT (para revisar con el entorno de pruebas)."""
    lineas_desglose = "".join(
        "<sum1:DetalleDesglose><sum1:Impuesto>01</sum1:Impuesto><sum1:ClaveRegimen>01</sum1:ClaveRegimen>"
        "<sum1:CalificacionOperacion>S1</sum1:CalificacionOperacion>"
        f"<sum1:TipoImpositivo>{d['pct']:.2f}</sum1:TipoImpositivo>"
        f"<sum1:BaseImponibleOimporteNoSujeto>{importe(d['base'])}</sum1:BaseImponibleOimporteNoSujeto>"
        f"<sum1:CuotaRepercutida>{importe(d['cuota'])}</sum1:CuotaRepercutida></sum1:DetalleDesglose>"
        for d in desglose)
    dest = ""
    if destinatario and destinatario.get("nif"):
        dest = ("<sum1:Destinatarios><sum1:IDDestinatario>"
                f"<sum1:NombreRazon>{escape(destinatario['nombre'][:120])}</sum1:NombreRazon>"
                f"<sum1:NIF>{escape(destinatario['nif'])}</sum1:NIF></sum1:IDDestinatario></sum1:Destinatarios>")
    encadenamiento = ("<sum1:Encadenamiento><sum1:PrimerRegistro>S</sum1:PrimerRegistro></sum1:Encadenamiento>"
                      if not r["huella_anterior"] else
                      "<sum1:Encadenamiento><sum1:RegistroAnterior>"
                      f"<sum1:IDEmisorFactura>{escape(r['nif'])}</sum1:IDEmisorFactura>"
                      f"<sum1:NumSerieFactura>{escape(r['ant_num_serie'])}</sum1:NumSerieFactura>"
                      f"<sum1:FechaExpedicionFactura>{r['ant_fecha']}</sum1:FechaExpedicionFactura>"
                      f"<sum1:Huella>{r['huella_anterior']}</sum1:Huella></sum1:RegistroAnterior></sum1:Encadenamiento>")
    return (
        "<sum1:RegistroAlta><sum1:IDVersion>1.0</sum1:IDVersion>"
        f"<sum1:IDFactura><sum1:IDEmisorFactura>{escape(r['nif'])}</sum1:IDEmisorFactura>"
        f"<sum1:NumSerieFactura>{escape(r['num_serie'])}</sum1:NumSerieFactura>"
        f"<sum1:FechaExpedicionFactura>{r['fecha_expedicion']}</sum1:FechaExpedicionFactura></sum1:IDFactura>"
        f"<sum1:NombreRazonEmisor>{escape(emisor_nombre[:120])}</sum1:NombreRazonEmisor>"
        f"<sum1:TipoFactura>{r['tipo_factura']}</sum1:TipoFactura>"
        f"<sum1:DescripcionOperacion>Servicio de aparcamiento y ventas</sum1:DescripcionOperacion>"
        f"{dest}<sum1:Desglose>{lineas_desglose}</sum1:Desglose>"
        f"<sum1:CuotaTotal>{importe(r['cuota_cent'])}</sum1:CuotaTotal>"
        f"<sum1:ImporteTotal>{importe(r['importe_cent'])}</sum1:ImporteTotal>{encadenamiento}"
        "<sum1:SistemaInformatico>"
        f"<sum1:NombreRazon>{escape(emisor_nombre[:120])}</sum1:NombreRazon><sum1:NIF>{escape(nif_productor or r['nif'])}</sum1:NIF>"
        f"<sum1:NombreSistemaInformatico>{SISTEMA['nombre']}</sum1:NombreSistemaInformatico>"
        f"<sum1:IdSistemaInformatico>{SISTEMA['id']}</sum1:IdSistemaInformatico>"
        f"<sum1:Version>{escape(version_programa)}</sum1:Version><sum1:NumeroInstalacion>1</sum1:NumeroInstalacion>"
        "<sum1:TipoUsoPosibleSoloVerifactu>S</sum1:TipoUsoPosibleSoloVerifactu>"
        "<sum1:TipoUsoPosibleMultiOT>N</sum1:TipoUsoPosibleMultiOT><sum1:IndicadorMultiplesOT>N</sum1:IndicadorMultiplesOT>"
        "</sum1:SistemaInformatico>"
        f"<sum1:FechaHoraHusoGenRegistro>{r['fecha_generacion']}</sum1:FechaHoraHusoGenRegistro>"
        "<sum1:TipoHuella>01</sum1:TipoHuella>"
        f"<sum1:Huella>{r['huella']}</sum1:Huella></sum1:RegistroAlta>")
