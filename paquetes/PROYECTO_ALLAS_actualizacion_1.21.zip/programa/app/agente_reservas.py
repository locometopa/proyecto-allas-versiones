"""PROYECTO ALLAS 1.18 · agente de reservas: conecta el programa con el servidor intermedio (scripts/servidor_reservas/relay.py).

El PC del parking no recibe llamadas desde Internet: es este agente quien PREGUNTA al servidor (conexión saliente, cada pocos
segundos) si hay peticiones de clientes. Cada una se atiende en el propio programa por la dirección local, con las mismas
comprobaciones y límites que si viniera de la red, y la respuesta se devuelve al servidor.

Solo reenvía rutas /api/publico/reservas* (nunca el resto del programa).
"""
import base64
import http.client
import json
import re
import secrets
import threading
import time
import urllib.error
import urllib.request

from . import errores

PREFIJO = "/api/publico/reservas"
MAX_CUERPO = 20000
RUTA_VALIDA = re.compile(r"/api/publico/reservas[A-Za-z0-9/_\-.?=&%:+@]*")


class AgenteReservas:
    def __init__(self, app):
        self.app = app
        self.token_local = secrets.token_urlsafe(24)   # solo lo conoce este proceso: identifica las peticiones que llegan por el agente
        self._parar = threading.Event()
        self._hilo = None
        self.conectado = False
        self.ultimo_error = ""
        self.ultimo_contacto = None
        self.atendidas = 0

    # --- ajustes
    def _cfg(self):
        p = self.app.p
        return {"activo": p.cfg("reservas_relay_activo") == "1", "url": (p.cfg("reservas_relay_url") or "").rstrip("/"),
                "token": p.cfg("reservas_relay_token") or ""}

    def configurado(self):
        c = self._cfg()
        return bool(c["activo"] and c["url"] and len(c["token"]) >= 24)

    def activo(self):
        return bool(self._hilo and self._hilo.is_alive() and not self._parar.is_set())

    def estado(self):
        c = self._cfg()
        return {"activo": c["activo"], "url": c["url"], "token_puesto": bool(c["token"]), "ejecutando": self.activo(),
                "conectado": self.conectado and self.activo(), "error": self.ultimo_error, "atendidas": self.atendidas,
                "ultimo_contacto": self.ultimo_contacto}

    # --- ciclo de vida
    def reiniciar(self):
        """Aplica los ajustes: arranca el agente si está configurado y activado; si no, lo para."""
        self.parar()
        if self.configurado() and self.app.puerto:
            self._parar = threading.Event()
            self._hilo = threading.Thread(target=self._bucle, args=(self._parar,), daemon=True, name="agente-reservas")
            self._hilo.start()

    def parar(self):
        self._parar.set()
        self.conectado = False

    # --- llamadas al servidor
    def _llamar(self, metodo, ruta, cuerpo=None, timeout=35):
        c = self._cfg()
        req = urllib.request.Request(c["url"] + ruta, data=json.dumps(cuerpo).encode() if cuerpo is not None else None, method=metodo,
                                     headers={"Authorization": "Bearer " + c["token"], "Content-Type": "application/json", "User-Agent": "AllasAgente/1.18"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            datos = r.read()
            return r.status, (json.loads(datos) if datos else None)

    def probar(self):
        """Comprueba la dirección y la clave sin esperar peticiones. Devuelve {ok, mensaje}."""
        c = self._cfg()
        if not c["url"]:
            return {"ok": False, "mensaje": "Falta la dirección del servidor"}
        if len(c["token"]) < 24:
            return {"ok": False, "mensaje": "Falta la clave (mínimo 24 caracteres)"}
        try:
            self._llamar("GET", "/agente/ping", timeout=10)
            return {"ok": True, "mensaje": "Conexión correcta: el servidor responde y acepta la clave."}
        except urllib.error.HTTPError as e:
            return {"ok": False, "mensaje": "El servidor rechaza la clave (debe ser la misma que usó al arrancarlo)." if e.code == 401
                    else f"El servidor respondió con un error ({e.code}). ¿Es la dirección del servidor de reservas?"}
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "mensaje": f"No se puede conectar con el servidor: {getattr(e, 'reason', e)}"}

    def _bucle(self, parar):
        espera = 2
        while not parar.is_set():
            try:
                estado, trabajo = self._llamar("GET", "/agente/esperar?max=25")
                self.conectado, self.ultimo_error = True, ""
                self.ultimo_contacto = time.strftime("%Y-%m-%dT%H:%M:%S")
                espera = 2
                if estado == 200 and trabajo:
                    threading.Thread(target=self._atender, args=(trabajo,), daemon=True).start()
            except urllib.error.HTTPError as e:
                self.conectado = False
                self.ultimo_error = "El servidor rechaza la clave" if e.code == 401 else f"El servidor respondió con un error ({e.code})"
                parar.wait(min(60, espera))
                espera = min(60, espera * 2)
            except Exception as e:  # noqa: BLE001  sin Internet, servidor caído…
                self.conectado = False
                self.ultimo_error = f"Sin conexión con el servidor ({getattr(e, 'reason', e)})"
                parar.wait(min(60, espera))
                espera = min(60, espera * 2)

    # --- atender una petición de un cliente con el propio programa
    def _atender(self, t):
        try:
            resp = self._local(t)
        except Exception as e:  # noqa: BLE001
            errores.fallo("reservas.agente", e)
            resp = {"estado": 502, "tipo": "application/json; charset=utf-8",
                    "cuerpo_b64": base64.b64encode(json.dumps({"error": "El parking no ha podido atender la petición"}).encode()).decode()}
        try:
            self._llamar("POST", f"/agente/responder/{t.get('id', '')}", resp, timeout=15)
            self.atendidas += 1
        except Exception as e:  # noqa: BLE001
            errores.fallo("reservas.agente", e)

    def _local(self, t):
        metodo, ruta = str(t.get("metodo") or ""), str(t.get("ruta") or "")
        if metodo not in ("GET", "POST") or not RUTA_VALIDA.fullmatch(ruta) or ".." in ruta or not ruta.startswith(PREFIJO):
            return {"estado": 400, "tipo": "application/json", "cuerpo_b64": base64.b64encode(b'{"error":"Solicitud no v\\u00e1lida"}').decode()}
        cuerpo = base64.b64decode(t.get("cuerpo_b64") or "")[:MAX_CUERPO]
        ip = re.sub(r"[^0-9a-fA-F:.]", "", str(t.get("ip") or ""))[:45] or "desconocida"
        cx = http.client.HTTPConnection("127.0.0.1", self.app.puerto, timeout=25)
        try:
            cab = {"X-Allas-Relay": self.token_local, "X-Allas-IP": ip, "Content-Type": "application/json", "Host": "agente.local"}
            cx.request(metodo, ruta, body=cuerpo if metodo == "POST" else None, headers=cab)
            r = cx.getresponse()
            datos = r.read()
            return {"estado": r.status, "tipo": r.getheader("Content-Type") or "application/json", "cuerpo_b64": base64.b64encode(datos).decode()}
        finally:
            cx.close()
