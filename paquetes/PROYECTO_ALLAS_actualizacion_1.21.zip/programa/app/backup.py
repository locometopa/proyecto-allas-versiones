"""Copias de seguridad de SQLite: hacer, registrar, listar, validar y restaurar.

- Las copias se hacen con la API de backup de SQLite: son consistentes aunque haya
  cobros en curso.
- Cada intento (correcto o fallido) se anota en 'registro.jsonl', FUERA de la base de
  datos, para que el historial no se pierda al restaurar una copia antigua.
- Restaurar copia la base elegida SOBRE la base en uso (también con la API de backup),
  tras validarla y tras guardar una copia de seguridad del estado actual. No hace falta
  reiniciar el programa.
"""
import glob
import json
import os
import re
import shutil
import sqlite3
import threading
import time
from datetime import datetime

from .db import SCHEMA_VERSION
from . import errores

NOMBRE_OK = re.compile(r"^parking-[\w.-]+\.db$")
TABLAS_NECESARIAS = {"config", "usuarios", "tarifas", "tickets", "pagos", "turnos"}
REGISTRO = "registro.jsonl"
ARCHIVOS_LOGO = ("logo.jpg", "logo.bin", "logo_ticket.png", "logo.json", "logo_factura.jpg", "logo_factura.json",
                 "sello.jpg", "sello.bin", "sello_ticket.png", "sello.json")

# Qué se puede elegir al hacer una copia manual. 'deps': tablas que se guardan también porque los datos
# del grupo las necesitan; al restaurar solo se añaden si faltan (no sustituyen a las actuales).
GRUPOS = [
    {"id": "configuracion", "nombre": "Configuración y ajustes",
     "detalle": "Empresa, ticket, impresora, tarifas, servicios y productos (con fotos), descuentos, tipos de bono, usuarios y logo",
     "tablas": ["config", "usuarios", "tarifas", "tarifa_tramos", "productos", "producto_fotos", "descuentos", "planes_bono",
                "publicidad", "recordatorios", "recordatorio_leidos"],
     "deps": []},
    {"id": "clientes", "nombre": "Clientes, abonados y bonos",
     "detalle": "Fichas de clientes, matrículas, bonos, suscripciones y avisos",
     "tablas": ["clientes", "cliente_matriculas", "vehiculo_fotos", "bonos", "suscripciones", "avisos"],
     "deps": ["planes_bono", "usuarios"]},
    {"id": "movimientos", "nombre": "Tickets, cobros, caja y facturas",
     "detalle": "Entradas y salidas, cobros, ventas de tienda, turnos y caja, facturas y envíos por email",
     "tablas": ["turnos", "tickets", "pagos", "ticket_extras", "ventas_lineas", "movimientos_caja", "vales",
                "registros_facturacion", "facturas_destinatario", "emails", "verifactu_registros", "m360_envios",
                "lpr_lecturas"],
     "deps": ["usuarios", "tarifas", "tarifa_tramos", "clientes", "cliente_matriculas", "bonos", "planes_bono",
              "productos", "descuentos"]},
    {"id": "auditoria", "nombre": "Registro de auditoría", "detalle": "Quién hizo qué y cuándo",
     "tablas": ["auditoria"], "deps": ["usuarios"]},
]
TODOS = [g["id"] for g in GRUPOS]
CONSERVAR_CONFIG = ("fecha_instalacion", "licencia_serial")


def _contenido(c):
    """Grupos guardados en una copia (None = copia completa sin información, p. ej. automática)."""
    try:
        fila = c.execute("SELECT valor FROM copia_info WHERE clave='contenido'").fetchone()
    except sqlite3.Error:
        return None
    return json.loads(fila[0]) if fila else None


def _preparar_copia(ruta, contenido, carpeta_logo):
    """Deja en la copia solo los grupos elegidos y le añade el logo y la descripción de su contenido."""
    c = sqlite3.connect(ruta)
    try:
        c.execute("PRAGMA foreign_keys = OFF")
        tablas = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        conservar = set()
        for g in GRUPOS:
            if g["id"] in contenido:
                conservar |= set(g["tablas"]) | set(g["deps"])
        if set(contenido) != set(TODOS):
            for t in sorted(tablas - conservar):
                if not t.startswith("sqlite_"):
                    c.execute(f'DELETE FROM "{t}"')
        c.execute("CREATE TABLE IF NOT EXISTS copia_info (clave TEXT PRIMARY KEY, valor TEXT)")
        c.execute("INSERT OR REPLACE INTO copia_info VALUES('contenido', ?)", (json.dumps(sorted(contenido)),))
        if "configuracion" in contenido and carpeta_logo and os.path.isdir(carpeta_logo):
            c.execute("CREATE TABLE IF NOT EXISTS copia_archivos (nombre TEXT PRIMARY KEY, datos BLOB)")
            for n in ARCHIVOS_LOGO:
                r = os.path.join(carpeta_logo, n)
                if os.path.isfile(r):
                    with open(r, "rb") as f:
                        c.execute("INSERT OR REPLACE INTO copia_archivos VALUES(?,?)", ("logo/" + n, f.read()))
        c.commit()
        c.execute("VACUUM")
    finally:
        c.close()


def _restaurar_logo(conn, carpeta_logo):
    """Escribe el logo guardado en la copia (si lo hay) y quita las tablas propias de la copia."""
    tablas = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if "copia_archivos" in tablas and carpeta_logo:
        filas = conn.execute("SELECT nombre, datos FROM copia_archivos WHERE nombre LIKE 'logo/%'").fetchall()
        if filas:
            os.makedirs(carpeta_logo, exist_ok=True)
            for n in ARCHIVOS_LOGO:
                try:
                    os.remove(os.path.join(carpeta_logo, n))
                except OSError:
                    pass
            for nombre, datos in filas:
                base = os.path.basename(nombre)
                if base in ARCHIVOS_LOGO:
                    with open(os.path.join(carpeta_logo, base), "wb") as f:
                        f.write(datos)
_lock_registro = threading.Lock()


def _anotar(carpeta, entrada):
    os.makedirs(carpeta, exist_ok=True)
    with _lock_registro, open(os.path.join(carpeta, REGISTRO), "a", encoding="utf-8") as f:
        f.write(json.dumps(entrada, ensure_ascii=False) + "\n")


def registro(carpeta, limite=50):
    """Últimas entradas del registro de copias, la más reciente primero."""
    ruta = os.path.join(carpeta, REGISTRO)
    if not os.path.exists(ruta):
        return []
    with _lock_registro, open(ruta, encoding="utf-8") as f:
        lineas = f.readlines()
    salida = []
    for l in reversed(lineas[-limite * 2:]):
        try:
            salida.append(json.loads(l))
        except ValueError:
            continue
        if len(salida) >= limite:
            break
    return salida


def _rotar(carpeta, mantener):
    if mantener <= 0:
        return
    copias = sorted(glob.glob(os.path.join(carpeta, "parking-*.db")), key=os.path.getmtime)
    for viejo in copias[:-mantener]:
        try:
            os.remove(viejo)
        except OSError:
            pass


def hacer_backup(db, carpeta, mantener=30, extra=None, tipo="manual", usuario=None, contenido=None,
                 carpeta_logo=None):
    """Copia la base de datos. 'tipo': arranque | automatica | cierre_turno | manual | antes_de_restaurar.
    'contenido': lista de grupos (GRUPOS) a guardar; si no son todos, la copia es parcial."""
    os.makedirs(carpeta, exist_ok=True)
    if contenido is not None:
        contenido = [g for g in TODOS if g in contenido]
        if not contenido:
            raise ValueError("Elija al menos qué quiere guardar")
        if set(contenido) != set(TODOS) and tipo == "manual":
            tipo = "parcial"
    marca = datetime.now().strftime("%Y%m%d-%H%M%S")
    nombre = f"parking-{marca}-{tipo}.db"
    ruta = os.path.join(carpeta, nombre)
    n = 1
    while os.path.exists(ruta):  # dos copias en el mismo segundo
        n += 1
        ruta = os.path.join(carpeta, f"parking-{marca}-{tipo}-{n}.db")
        nombre = os.path.basename(ruta)
    entrada = {"fecha": datetime.now().astimezone().isoformat(timespec="seconds"), "tipo": tipo,
               "archivo": nombre, "usuario": usuario, "ok": False}
    if contenido is not None:
        entrada["contenido"] = contenido
    t0 = time.time()
    try:
        with db._lock:
            dst = sqlite3.connect(ruta)
            try:
                db.conn.backup(dst)
            finally:
                dst.close()
        if contenido is not None:
            _preparar_copia(ruta, contenido, carpeta_logo)
        entrada["tamano"] = os.path.getsize(ruta)
        entrada["ok"] = True
        if extra:
            if os.path.isdir(extra):
                try:
                    shutil.copy2(ruta, os.path.join(extra, nombre))
                    entrada["extra"] = "ok"
                    _rotar(extra, mantener)
                except OSError as e:
                    entrada["extra"] = f"error: {e}"
            else:
                entrada["extra"] = "error: la carpeta adicional no existe o no está conectada"
        _rotar(carpeta, mantener)
        try:   # 4.3: copia cifrada en la nube (en segundo plano)
            from . import nube
            nube.tras_copia(db, ruta, tipo)
        except Exception as e_:  # noqa: BLE001
            errores.fallo("backup.hacer_backup: copia en la nube", e_, grave=True)
        return ruta
    except Exception as e:
        entrada["error"] = str(e)
        raise
    finally:
        entrada["segundos"] = round(time.time() - t0, 2)
        try:
            _anotar(carpeta, entrada)
        except OSError:
            pass


def listar(carpeta):
    """Copias disponibles, la más reciente primero, con un resumen de su contenido."""
    salida = []
    for ruta in glob.glob(os.path.join(carpeta, "parking-*.db")):
        nombre = os.path.basename(ruta)
        m = re.match(r"parking-(\d{8})-(\d{6})(?:-([a-z_]+))?", nombre)
        info = {"archivo": nombre, "tamano": os.path.getsize(ruta),
                "fecha": datetime.fromtimestamp(os.path.getmtime(ruta)).astimezone().isoformat(timespec="seconds"),
                "tipo": (m.group(3) if m and m.group(3) else "manual")}
        try:
            c = sqlite3.connect(f"file:{ruta}?mode=ro", uri=True)
            try:
                info["contenido"] = _contenido(c)
            finally:
                c.close()
        except sqlite3.Error:
            info["contenido"] = None
        salida.append(info)
    salida.sort(key=lambda x: x["fecha"], reverse=True)
    return salida


def ruta_segura(carpeta, nombre):
    """Evita que se pida un archivo fuera de la carpeta de copias."""
    if not NOMBRE_OK.match(nombre or ""):
        raise ValueError("Nombre de copia no válido")
    ruta = os.path.join(carpeta, nombre)
    if not os.path.isfile(ruta):
        raise FileNotFoundError("La copia no existe")
    return ruta


def validar(ruta):
    """Comprueba que el archivo es una base de datos del parking sana. Devuelve un resumen."""
    try:
        c = sqlite3.connect(f"file:{ruta}?mode=ro", uri=True)
    except sqlite3.Error as e:
        raise ValueError(f"No se puede abrir: {e}")
    try:
        try:
            ok = c.execute("PRAGMA integrity_check").fetchone()[0]
        except sqlite3.DatabaseError:
            raise ValueError("El archivo no es una base de datos válida")
        if ok != "ok":
            raise ValueError(f"La copia está dañada: {ok}")
        tablas = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not TABLAS_NECESARIAS <= tablas:
            raise ValueError("El archivo no es una copia de este programa de parking")
        version = c.execute("PRAGMA user_version").fetchone()[0]
        if version > SCHEMA_VERSION:
            raise ValueError("La copia es de una versión más nueva del programa. Actualice el programa primero.")
        cuenta = lambda t: c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] if t in tablas else 0
        ultimo = c.execute("SELECT MAX(fecha) FROM pagos").fetchone()[0]
        contenido = _contenido(c)
        return {"version": version, "tickets": cuenta("tickets"), "pagos": cuenta("pagos"),
                "clientes": cuenta("clientes"), "usuarios": cuenta("usuarios"), "ultimo_cobro": ultimo,
                "contenido": contenido or TODOS, "parcial": bool(contenido) and set(contenido) != set(TODOS),
                "logo": "copia_archivos" in tablas,
                "grupos": [{"id": g["id"], "nombre": g["nombre"]} for g in GRUPOS if g["id"] in (contenido or TODOS)]}
    finally:
        c.close()


def _fusionar(db, ruta, contenido):
    """Restauración de una copia parcial: añade o actualiza los datos de los grupos guardados, sin borrar
    el resto. Las tablas de dependencia solo se añaden si faltan."""
    conn = db.conn
    principales, deps = [], []
    for g in GRUPOS:
        if g["id"] in contenido:
            principales += [t for t in g["tablas"] if t not in principales]
    for g in GRUPOS:
        if g["id"] in contenido:
            deps += [t for t in g["deps"] if t not in principales and t not in deps]
    conn.execute("PRAGMA foreign_keys = OFF")
    conn.execute("ATTACH DATABASE ? AS copia", (f"file:{ruta}?mode=ro",))
    try:
        en_copia = {r[0] for r in conn.execute("SELECT name FROM copia.sqlite_master WHERE type='table'")}
        conn.execute("BEGIN IMMEDIATE")
        try:
            filas = 0
            for t, modo in [(t, "OR IGNORE") for t in deps] + [(t, "OR REPLACE") for t in principales]:
                if t not in en_copia:
                    continue
                cols_main = [r[1] for r in conn.execute(f'PRAGMA main.table_info("{t}")')]
                cols_copia = {r[1] for r in conn.execute(f'PRAGMA copia.table_info("{t}")')}
                cols = [c for c in cols_main if c in cols_copia]
                if not cols:
                    continue
                lista = ", ".join(f'"{c}"' for c in cols)
                where = ""
                if t == "config":
                    where = " WHERE clave NOT IN (%s)" % ",".join("'%s'" % k for k in CONSERVAR_CONFIG)
                filas += conn.execute(f'INSERT {modo} INTO main."{t}" ({lista}) SELECT {lista} FROM copia."{t}"{where}').rowcount
            malas = conn.execute("PRAGMA main.foreign_key_check").fetchall()
            if malas:
                tablas = sorted({m[2] for m in malas})
                raise ValueError("Faltan datos relacionados en " + ", ".join(tablas)
                                 + ". Restaure una copia que los incluya (o una copia completa).")
            conn.execute("COMMIT")
            return filas
        except Exception:
            conn.execute("ROLLBACK")
            raise
    finally:
        conn.execute("DETACH DATABASE copia")
        conn.execute("PRAGMA foreign_keys = ON")


def restaurar(db, carpeta, nombre, usuario=None, mantener=30, carpeta_logo=None):
    """Sustituye la base en uso por la copia 'nombre' (o, si es parcial, añade/actualiza sus datos).
    Antes guarda el estado actual."""
    ruta = ruta_segura(carpeta, nombre)
    resumen = validar(ruta)
    previa = hacer_backup(db, carpeta, mantener + 1, tipo="antes_de_restaurar", usuario=usuario)
    entrada = {"fecha": datetime.now().astimezone().isoformat(timespec="seconds"), "tipo": "restauracion",
               "archivo": nombre, "usuario": usuario, "copia_previa": os.path.basename(previa), "ok": False}
    try:
        with db._lock:
            if resumen["parcial"]:
                entrada["contenido"] = resumen["contenido"]
                resumen["filas"] = _fusionar(db, ruta, resumen["contenido"])
                src = sqlite3.connect(f"file:{ruta}?mode=ro", uri=True)
                try:
                    if "configuracion" in resumen["contenido"]:
                        _restaurar_logo(src, carpeta_logo)
                finally:
                    src.close()
            else:
                guardado = {k: db.get_cfg(k) for k in CONSERVAR_CONFIG}
                src = sqlite3.connect(f"file:{ruta}?mode=ro", uri=True)
                try:
                    src.backup(db.conn)
                finally:
                    src.close()
                _restaurar_logo(db.conn, carpeta_logo)
                db.conn.execute("DROP TABLE IF EXISTS copia_archivos")
                db.conn.execute("DROP TABLE IF EXISTS copia_info")
                db._migrar()  # una copia antigua se pone al día con el esquema actual
                for k, v in guardado.items():   # la licencia y la fecha de instalación son las del equipo
                    if v and not db.get_cfg(k):
                        db.set_cfg(k, v)
        entrada["ok"] = True
        return {"restaurada": nombre, "copia_previa": os.path.basename(previa), **resumen}
    except Exception as e:
        entrada["error"] = str(e)
        raise
    finally:
        _anotar(carpeta, entrada)


def restablecer(db, carpeta, usuario=None, mantener=30, conservar=("fecha_instalacion", "licencia_serial")):
    """Deja la base de datos como recién instalada. Antes guarda una copia del estado actual (se puede
    restaurar desde Copias de seguridad). Se conservan la fecha de instalación y la licencia."""
    import tempfile
    from .db import Database
    previa = hacer_backup(db, carpeta, mantener + 1, tipo="antes_de_restablecer", usuario=usuario)
    guardado = {k: db.get_cfg(k) for k in conservar}
    entrada = {"fecha": datetime.now().astimezone().isoformat(timespec="seconds"), "tipo": "restablecimiento",
               "usuario": usuario, "copia_previa": os.path.basename(previa), "ok": False}
    tmp = tempfile.mkdtemp()
    try:
        nueva = Database(os.path.join(tmp, "vacia.db"))
        nueva.conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        with db._lock:
            nueva.conn.backup(db.conn)
            nueva.conn.close()
            for k, v in guardado.items():
                if v:
                    db.set_cfg(k, v)
        entrada["ok"] = True
        return {"copia_previa": os.path.basename(previa)}
    except Exception as e:
        entrada["error"] = str(e)
        raise
    finally:
        _anotar(carpeta, entrada)
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)


def eliminar(carpeta, nombre, usuario=None):
    """Borra una copia. Devuelve un aviso si era la última copia correcta disponible."""
    ruta = ruta_segura(carpeta, nombre)
    quedan = [c for c in listar(carpeta) if c["archivo"] != nombre]
    os.remove(ruta)
    _anotar(carpeta, {"fecha": datetime.now().astimezone().isoformat(timespec="seconds"), "tipo": "eliminacion",
                      "archivo": nombre, "usuario": usuario, "ok": True})
    return {"eliminada": nombre, "quedan": len(quedan)}


def guardar_subida(carpeta, datos):
    """Guarda un .db subido desde el navegador (p. ej. traído en un pendrive) tras validarlo."""
    if len(datos) < 512 or not datos.startswith(b"SQLite format 3\x00"):
        raise ValueError("El archivo no es una base de datos SQLite")
    os.makedirs(carpeta, exist_ok=True)
    nombre = f"parking-{datetime.now().strftime('%Y%m%d-%H%M%S')}-subida.db"
    ruta = os.path.join(carpeta, nombre)
    with open(ruta, "wb") as f:
        f.write(datos)
    try:
        resumen = validar(ruta)
    except ValueError:
        os.remove(ruta)
        raise
    _anotar(carpeta, {"fecha": datetime.now().astimezone().isoformat(timespec="seconds"), "tipo": "subida",
                      "archivo": nombre, "tamano": len(datos), "ok": True})
    return {"archivo": nombre, **resumen}


# ------------------------------------------------------------------ copias programadas
# Ajustes (tabla config):
#   backup_auto_modo      intervalo | horas | no
#   backup_auto_cada_h    cada cuántas horas (modo intervalo)
#   backup_auto_horas     horas fijas "14:00,23:30" (modo horas)
#   backup_auto_dias      días de la semana ISO "1234567" (1 = lunes)
#   backup_auto_contenido grupos a guardar separados por comas (vacío = todo)
#   backup_auto_ultima    fecha y hora de la última copia programada (interno)
PROGRAMA_DEFECTO = {"backup_auto_modo": "intervalo", "backup_auto_cada_h": "6", "backup_auto_horas": "23:30",
                    "backup_auto_dias": "1234567", "backup_auto_contenido": ""}
HORA_OK = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")


def leer_horas(texto):
    """'9:00, 23:30' -> ['09:00', '23:30'] (ordenadas, sin repetir). ValueError si alguna no es válida."""
    horas = set()
    for trozo in re.split(r"[,;\s]+", (texto or "").strip()):
        if not trozo:
            continue
        m = HORA_OK.match(trozo)
        if not m:
            raise ValueError(f"Hora no válida: {trozo} (use HH:MM, p. ej. 23:30)")
        horas.add(f"{int(m.group(1)):02d}:{m.group(2)}")
    return sorted(horas)


def programa(cfg):
    """Ajustes de la programación con sus valores por defecto."""
    p = {k: (cfg.get(k) if cfg.get(k) not in (None, "") else v) for k, v in PROGRAMA_DEFECTO.items()}
    p["backup_auto_contenido"] = cfg.get("backup_auto_contenido") or ""
    return p


def _momentos(p, ahora):
    """Horas programadas (modo «horas») desde ayer hasta dentro de 8 días."""
    from datetime import timedelta
    try:
        horas = leer_horas(p["backup_auto_horas"])
    except ValueError:
        horas = []
    dias = {int(d) for d in p["backup_auto_dias"] if d.isdigit() and 1 <= int(d) <= 7}
    salida = []
    for n in range(-1, 9):
        dia = (ahora + timedelta(days=n)).date()
        if dia.isoweekday() not in dias:
            continue
        for h in horas:
            hh, mm = map(int, h.split(":"))
            salida.append(datetime(dia.year, dia.month, dia.day, hh, mm, tzinfo=ahora.tzinfo))
    return sorted(salida)


def proxima_copia(cfg, ahora, ultima=None):
    """Cuándo toca la siguiente copia programada (None si están desactivadas)."""
    from datetime import timedelta
    p = programa(cfg)
    if p["backup_auto_modo"] == "intervalo":
        cada = max(1, min(168, int(p["backup_auto_cada_h"] or 6)))
        return (ultima or ahora) + timedelta(hours=cada)
    if p["backup_auto_modo"] == "horas":
        return next((m for m in _momentos(p, ahora) if m > ahora), None)
    return None


def copia_toca(cfg, ahora, ultima):
    """¿Hay que hacer ya una copia programada? En modo «horas», si el equipo estaba apagado a la hora
    prevista se hace al encenderlo (si no han pasado más de 24 h)."""
    from datetime import timedelta
    p = programa(cfg)
    if p["backup_auto_modo"] == "intervalo":
        return ultima is not None and ahora >= proxima_copia(cfg, ahora, ultima)
    if p["backup_auto_modo"] == "horas":
        return any((ultima is None or m > ultima) and m <= ahora and ahora - m < timedelta(hours=24)
                   for m in _momentos(p, ahora))
    return False


def contenido_programado(cfg):
    grupos = [g for g in (cfg.get("backup_auto_contenido") or "").split(",") if g in TODOS]
    return grupos if grupos and set(grupos) != set(TODOS) else None


def hacer_copia_programada(db, carpeta, carpeta_logo=None, ahora=None):
    ahora = ahora or datetime.now().astimezone()
    cfg = db.config()
    contenido = contenido_programado(cfg)
    ruta = hacer_backup(db, carpeta, int(cfg.get("backups_mantener") or 30), cfg.get("backup_destino_extra"),
                        tipo="automatica", usuario="programada", contenido=contenido,
                        carpeta_logo=carpeta_logo)
    db.set_cfg("backup_auto_ultima", ahora.isoformat(timespec="seconds"))
    return ruta


def ultima_programada(db):
    v = db.get_cfg("backup_auto_ultima")
    try:
        return datetime.fromisoformat(v) if v else None
    except ValueError:
        return None


def programar_copias(db, carpeta, carpeta_logo=None, cada_seg=30):
    """Hilo en segundo plano: comprueba cada medio minuto si toca una copia según lo programado
    en Ajustes → Copias de seguridad."""
    if programa(db.config())["backup_auto_modo"] == "intervalo" or not ultima_programada(db):
        # al arrancar ya se ha hecho la copia de arranque: el intervalo empieza a contar ahora
        db.set_cfg("backup_auto_ultima", datetime.now().astimezone().isoformat(timespec="seconds"))

    def bucle():
        while True:
            time.sleep(cada_seg)
            try:
                ahora = datetime.now().astimezone()
                if copia_toca(db.config(), ahora, ultima_programada(db)):
                    hacer_copia_programada(db, carpeta, carpeta_logo, ahora)
            except Exception as e:
                print("Copia programada fallida:", e)
                time.sleep(300)   # no reintentar en bucle
    threading.Thread(target=bucle, daemon=True, name="backup").start()

