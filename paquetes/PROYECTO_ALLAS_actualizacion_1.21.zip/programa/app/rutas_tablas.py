"""PROYECTO ALLAS 1.6 · rutas de exportar e importar en CSV, Excel (.xlsx, .xls) y PDF, y borrado de clientes."""
from . import errores
from . import tablas
from . import importar
from .backup import hacer_backup
from .servicios import ErrorNegocio
from .svc_tablas import CONJUNTOS


def registrar(app, r, p):
    from .server import Respuesta

    @r("GET", r"/api/exportar/tabla/([a-z-]+)\.(csv|xlsx|xls|pdf)", rol=("admin",))
    def exportar_tabla(req, conjunto, fmt):
        if conjunto not in CONJUNTOS:
            raise ErrorNegocio("Listado no válido")
        t = p.tabla_exportable(conjunto)
        extra = {}
        if fmt == "pdf":
            from . import VERSION_COMPLETA
            extra = {"marca": VERSION_COMPLETA}
        try:
            cuerpo = tablas.FORMATOS[fmt][1](t, **extra)
        except ValueError as e:
            raise ErrorNegocio(str(e))
        nombre = f"{conjunto.replace('-', '_')}_{p.ahora():%Y%m%d}.{fmt}"
        return Respuesta(cuerpo, tablas.FORMATOS[fmt][0], {"Content-Disposition": f'attachment; filename="{nombre}"'})

    @r("GET", r"/api/plantilla/(clientes|servicios|productos)\.(csv|xlsx|xls)", rol=("admin",))
    def plantilla_tabla(req, que, fmt):
        t = p.tabla_plantilla(que)
        return Respuesta(tablas.FORMATOS[fmt][1](t), tablas.FORMATOS[fmt][0],
                         {"Content-Disposition": f'attachment; filename="plantilla_{que}.{fmt}"'})

    @r("POST", "/api/config/importar/leer", rol=("admin",), crudo=True)
    def config_importar_leer(req):
        """Servicios o productos en una tabla (.xlsx, .xls o .csv) → el mismo formato que el .json de exportar, para la vista previa."""
        try:
            filas = importar.leer(req.raw, req.query.get("nombre", ""))
        except ValueError as e:
            raise ErrorNegocio(str(e))
        if len(filas) > 5001:
            raise ErrorNegocio("El archivo tiene demasiadas filas (máximo 5.000)")
        tipo = "producto" if req.query.get("tipo") == "productos" else "servicio"
        datos, avisos = p.config_desde_tabla(filas, tipo)
        return {"datos": datos, "avisos": avisos}

    @r("GET", "/api/clientes/borrar-todos", rol=("admin",))
    def clientes_borrar_resumen(req):
        return p.resumen_borrar_clientes(req.query.get("ambito", "todos"))

    @r("POST", "/api/clientes/borrar-todos", rol=("admin",))
    def clientes_borrar(req):
        app._comprobar_pin(req)
        if (req.body.get("confirmacion") or "").strip().upper() != "BORRAR":
            raise ErrorNegocio("Escriba BORRAR para confirmar")
        ambito = req.body.get("ambito")
        p.resumen_borrar_clientes(ambito)   # valida el ámbito antes de copiar nada
        try:
            hacer_backup(p.db, app.backups, int(p.cfg("backups_mantener") or 30), p.cfg("backup_destino_extra"),
                         tipo="antes_de_borrar", usuario=req.usuario["usuario"])
        except Exception as e_:
            errores.fallo("rutas_tablas.clientes_borrar: copia previa", e_, grave=True)
            raise ErrorNegocio("No se pudo hacer la copia de seguridad previa; no se ha borrado nada")
        return p.borrar_clientes(req.usuario["id"], ambito, req.body.get("confirmacion"))
