"""Actualizaciones de PROYECTO ALLAS mediante paquetes firmados (funciona sin Internet).

Un paquete es un .zip creado con el Gestor de licencias que contiene:
  manifiesto.json   versión, fecha de publicación, notas y la huella SHA-256 de cada archivo
  manifiesto.firma  firma Ed25519 del manifiesto (solo el Gestor tiene la clave privada)
  programa/...      los archivos nuevos del programa

Al instalar: se comprueba la firma y cada archivo, que la versión sea más nueva y que la licencia
incluya actualizaciones de esa fecha; se guarda una copia de la versión actual (para poder volver
atrás) y se sustituyen los archivos. La base de datos no se toca: se adapta sola al arrancar.
"""
import hashlib
import io
import json
import os
import shutil
import zipfile
from datetime import date, datetime

from . import ed25519

FORMATO = "proyecto-allas/actualizacion"
CONTEXTO = b"PROYECTO-ALLAS-ACTUALIZACION"
# Solo se instalan / guardan estas rutas del programa (nunca datos/, copias ni configuración local)
CARPETAS = ("app", "web", "scripts", "docs")
ARCHIVOS = ("run.py", "ARRANCAR.bat", "README.md", "CHANGELOG.md")
MAX_PAQUETE = 200 * 1024 * 1024


class ErrorActualizacion(ValueError):
    pass


def version_tupla(v):
    try:
        return tuple(int(x) for x in str(v).split("."))
    except ValueError:
        raise ErrorActualizacion(f"Versión no válida: {v}")


def _ruta_permitida(rel):
    rel = rel.replace("\\", "/")
    if rel.startswith("/") or ".." in rel.split("/") or "__pycache__" in rel or rel.endswith(".pyc"):
        return False
    return rel in ARCHIVOS or rel.split("/")[0] in CARPETAS


def archivos_programa(raiz):
    """Rutas relativas de los archivos del programa instalado."""
    salida = []
    for f in ARCHIVOS:
        if os.path.isfile(os.path.join(raiz, f)):
            salida.append(f)
    for c in CARPETAS:
        for base, dirs, nombres in os.walk(os.path.join(raiz, c)):
            dirs[:] = [d for d in dirs if d != "__pycache__"]
            for n in nombres:
                rel = os.path.relpath(os.path.join(base, n), raiz).replace(os.sep, "/")
                if _ruta_permitida(rel):
                    salida.append(rel)
    return sorted(salida)


# ------------------------------------------------------------------ crear (Gestor)
def crear_paquete(raiz, clave_privada, version, fecha, notas="", version_minima="1.0", extra=None):
    """Empaqueta el programa que hay en 'raiz'. Devuelve los bytes del .zip.
    extra (4.1): {ruta: bytes|str} que se añaden o sustituyen (p. ej. app/fabricante.json del Gestor)."""
    archivos = {}
    extra = {k: (v.encode("utf-8") if isinstance(v, str) else v) for k, v in (extra or {}).items() if _ruta_permitida(k)}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for rel in sorted(set(archivos_programa(raiz)) | set(extra)):
            if rel in extra:
                datos = extra[rel]
            else:
                with open(os.path.join(raiz, rel), "rb") as f:
                    datos = f.read()
            archivos[rel] = hashlib.sha256(datos).hexdigest()
            z.writestr("programa/" + rel, datos)
        manifiesto = json.dumps({"formato": FORMATO, "version": version, "fecha": fecha, "notas": notas,
                                 "version_minima": version_minima, "archivos": archivos,
                                 "creado": datetime.now().astimezone().isoformat(timespec="seconds")},
                                ensure_ascii=False, indent=1, sort_keys=True).encode("utf-8")
        z.writestr("manifiesto.json", manifiesto)
        z.writestr("manifiesto.firma", ed25519.firmar(clave_privada, CONTEXTO + manifiesto).hex())
    return buf.getvalue()


# ------------------------------------------------------------------ comprobar (programa)
def leer_paquete(datos, clave_publica):
    """Comprueba firma e integridad. Devuelve (manifiesto, zipfile abierto)."""
    if len(datos) > MAX_PAQUETE:
        raise ErrorActualizacion("El paquete es demasiado grande")
    try:
        z = zipfile.ZipFile(io.BytesIO(datos))
        manifiesto = z.read("manifiesto.json")
        firma = bytes.fromhex(z.read("manifiesto.firma").decode().strip())
    except (zipfile.BadZipFile, KeyError, ValueError):
        raise ErrorActualizacion("El archivo no es un paquete de actualización de PROYECTO ALLAS")
    if not ed25519.verificar(clave_publica, CONTEXTO + manifiesto, firma):
        raise ErrorActualizacion("La firma del paquete no es válida: no procede del fabricante o está dañado")
    m = json.loads(manifiesto)
    if m.get("formato") != FORMATO:
        raise ErrorActualizacion("Formato de paquete no reconocido")
    for rel, huella in m["archivos"].items():
        if not _ruta_permitida(rel):
            raise ErrorActualizacion(f"El paquete contiene una ruta no permitida: {rel}")
        try:
            contenido = z.read("programa/" + rel)
        except KeyError:
            raise ErrorActualizacion(f"Falta el archivo {rel} en el paquete")
        if hashlib.sha256(contenido).hexdigest() != huella:
            raise ErrorActualizacion(f"El archivo {rel} está dañado")
    if "app/__init__.py" not in m["archivos"]:
        raise ErrorActualizacion("Paquete incompleto")
    return m, z


def comprobar(m, version_actual, licencia_estado, permitir_anterior=False):
    """Lanza ErrorActualizacion si el paquete no se puede instalar con esta versión y licencia.
    4.21: con permitir_anterior se admite un paquete de una versión anterior (volver atrás)."""
    v, hoy = version_tupla(m["version"]), version_tupla(version_actual)
    if v == hoy:
        raise ErrorActualizacion(f"El paquete es la versión {m['version']}, que es justo la que ya tiene instalada")
    if v < hoy and not permitir_anterior:
        if hoy[0] >= 4 and v[0] < 4:   # 1.2: un paquete de la numeración nueva (1.x) sobre una instalación 4.x
            raise ErrorActualizacion(
                f"El paquete es de la numeración nueva ({m['version']}) y su instalación es la {version_actual}. "
                "Instale primero el paquete «PROYECTO_ALLAS_actualizacion_desde_4.x.zip»; después ya podrá subir los 1.x")
        raise ErrorActualizacion(
            f"El paquete es la versión {m['version']}, anterior a la {version_actual} que tiene instalada. "
            "Suba un paquete de versión posterior (para volver atrás use «Versiones guardadas»)")
    if v[0] == 4 and hoy[0] < 4:   # 1.2: el paquete puente 4.x → 1.x no sirve en una instalación que ya es 1.x
        raise ErrorActualizacion(f"El paquete {m['version']} es solo para instalaciones con la numeración antigua (4.x); "
                                 f"la suya ya es la {version_actual}")
    if v > hoy and version_tupla(version_actual) < version_tupla(m.get("version_minima") or "0"):
        raise ErrorActualizacion(f"Para instalar la {m['version']} necesita al menos la versión {m['version_minima']}")
    lic = licencia_estado
    if lic["estado"] in ("activa", "version_no_cubierta") and lic.get("actualizaciones_hasta"):
        if date.fromisoformat(m["fecha"]) > date.fromisoformat(lic["actualizaciones_hasta"]):
            raise ErrorActualizacion(
                f"Su licencia incluye actualizaciones publicadas hasta el "
                f"{date.fromisoformat(lic['actualizaciones_hasta']).strftime('%d/%m/%Y')} y esta versión es del "
                f"{date.fromisoformat(m['fecha']).strftime('%d/%m/%Y')}. Renueve la licencia para instalarla.")
    elif lic["estado"] in ("caducada", "invalida", "otro_equipo"):
        raise ErrorActualizacion("Necesita una licencia válida para instalar actualizaciones")


def _copiar_programa(raiz, destino):
    os.makedirs(destino, exist_ok=True)
    for rel in archivos_programa(raiz):
        d = os.path.join(destino, rel)
        os.makedirs(os.path.dirname(d), exist_ok=True)
        shutil.copy2(os.path.join(raiz, rel), d)


def _restaurar_desde(raiz, origen):
    """Deja el programa exactamente como está en 'origen' (copia guardada)."""
    nuevos = set()
    for base, _, nombres in os.walk(origen):
        for n in nombres:
            rel = os.path.relpath(os.path.join(base, n), origen).replace(os.sep, "/")
            if rel == "version.json":
                continue
            nuevos.add(rel)
            d = os.path.join(raiz, rel)
            os.makedirs(os.path.dirname(d), exist_ok=True)
            shutil.copy2(os.path.join(base, n), d)
    for rel in archivos_programa(raiz):
        if rel not in nuevos and rel.split("/")[0] in ("app", "web"):
            os.remove(os.path.join(raiz, rel))


def instalar(raiz, datos, clave_publica, version_actual, licencia_estado, carpeta_versiones, permitir_anterior=False):
    """Instala el paquete. Devuelve el manifiesto. Si algo falla a mitad, deja la versión anterior."""
    m, z = leer_paquete(datos, clave_publica)
    comprobar(m, version_actual, licencia_estado, permitir_anterior)
    copia = os.path.join(carpeta_versiones, version_actual)
    if os.path.isdir(copia):
        shutil.rmtree(copia)
    _copiar_programa(raiz, copia)
    with open(os.path.join(copia, "version.json"), "w") as f:
        json.dump({"version": version_actual, "guardada": datetime.now().astimezone().isoformat(timespec="seconds"),
                   "sustituida_por": m["version"]}, f)
    try:
        for rel in m["archivos"]:
            d = os.path.join(raiz, rel)
            os.makedirs(os.path.dirname(d), exist_ok=True)
            tmp = d + ".nuevo"
            with open(tmp, "wb") as f:
                f.write(z.read("programa/" + rel))
            os.replace(tmp, d)
        # archivos del programa que ya no existen en la versión nueva
        for rel in archivos_programa(raiz):
            if rel not in m["archivos"] and rel.split("/")[0] in ("app", "web"):
                os.remove(os.path.join(raiz, rel))
    except Exception:
        _restaurar_desde(raiz, copia)
        raise
    return m


def versiones_guardadas(carpeta_versiones):
    salida = []
    if os.path.isdir(carpeta_versiones):
        for v in os.listdir(carpeta_versiones):
            try:
                with open(os.path.join(carpeta_versiones, v, "version.json")) as f:
                    info = json.load(f)
                version_tupla(info["version"])
                salida.append(info)
            except (OSError, ValueError, KeyError, ErrorActualizacion):
                continue
    return sorted(salida, key=lambda i: version_tupla(i["version"]), reverse=True)


def volver_a(raiz, carpeta_versiones, version, version_actual):
    origen = os.path.join(carpeta_versiones, version)
    if not os.path.isfile(os.path.join(origen, "version.json")):
        raise ErrorActualizacion(f"No hay copia guardada de la versión {version}")
    # se guarda también la actual, por si se quiere volver a ella
    copia = os.path.join(carpeta_versiones, version_actual)
    if not os.path.isdir(copia):
        _copiar_programa(raiz, copia)
        with open(os.path.join(copia, "version.json"), "w") as f:
            json.dump({"version": version_actual, "guardada": datetime.now().astimezone().isoformat(timespec="seconds"),
                       "sustituida_por": version}, f)
    _restaurar_desde(raiz, origen)


def cambios_desde(z, version_actual, version_paquete):
    """4.22: texto del CHANGELOG.md que viaja dentro del paquete, solo de las versiones posteriores a la instalada
    y hasta la del paquete (así, al saltar varias versiones se ve todo lo que cambia). '' si no se puede leer."""
    try:
        texto = z.read("programa/CHANGELOG.md").decode("utf-8")
        hoy, tope = version_tupla(version_actual), version_tupla(version_paquete)
    except (KeyError, UnicodeDecodeError, ErrorActualizacion):
        return ""
    import re
    trozos, vigente = [], None
    for linea in texto.splitlines():
        m = re.match(r"^## (\d+(?:\.\d+)*)\b", linea)
        if m:
            v = version_tupla(m.group(1))
            vigente = hoy < v <= tope
        if vigente:
            trozos.append(linea)
    return "\n".join(trozos).strip()


def historial_versiones(raiz, version_actual, desde=None):
    """4.23: novedades de cada versión ya instalada o anterior, leídas del CHANGELOG.md del programa
    (más reciente primero). Sirve para consultar qué trajo cada versión; no permite restaurarla."""
    import re
    try:
        with open(os.path.join(raiz, "CHANGELOG.md"), encoding="utf-8") as f:
            texto = f.read()
        hoy = version_tupla(version_actual)
        inicio = version_tupla(desde) if desde else (0,)   # 1.0: no se ve nada anterior a la versión de la primera instalación
    except (OSError, UnicodeDecodeError, ErrorActualizacion):
        return []
    salida, vigente = [], None
    for linea in texto.splitlines():
        m = re.match(r"^## (\d+(?:\.\d+)*)\b\s*[—-]?\s*(.*)$", linea)
        if m:
            try:
                v = version_tupla(m.group(1))
            except ErrorActualizacion:
                vigente = None
                continue
            vigente = {"version": m.group(1), "fecha": m.group(2).strip(), "notas": ""} if inicio <= v <= hoy else None
            if vigente:
                salida.append(vigente)
        elif vigente is not None:
            vigente["notas"] += linea + "\n"
    for x in salida:
        x["notas"] = "\n".join(mayuscula_tras_dos_puntos(l) for l in x["notas"].strip().splitlines())
    return sorted(salida, key=lambda x: version_tupla(x["version"]), reverse=True)


def mayuscula_tras_dos_puntos(linea):
    """4.62: en cada novedad, la primera letra que sigue a los «:» de la etiqueta va en mayúscula
    («- **Etiqueta: detalle:** texto» → «Detalle» y «Texto»). Solo toca el encabezado de la novedad, no el resto de la frase."""
    import re
    m = re.match(r"^(\s*[-*•]\s+)(\*\*.+?\*\*)(.*)$", linea)
    if m:
        cab = re.sub(r"(:[ \t]+)([a-záéíóúüñ])", lambda x: x.group(1) + x.group(2).upper(), m.group(2))
        resto = re.sub(r"^([\s.,:;—–-]*)([a-záéíóúüñ])", lambda x: x.group(1) + x.group(2).upper(), m.group(3))
        return m.group(1) + cab + resto
    m = re.match(r"^(\s*[-*•]\s+[^:`]{1,80}:[ \t]+)([a-záéíóúüñ])(.*)$", linea)
    return m.group(1) + m.group(2).upper() + m.group(3) if m else linea


def texto_historial(raiz, version_actual, desde=None):
    """4.62: historial completo de versiones en texto plano, para descargar (más reciente primero)."""
    import re
    salida = ["PROYECTO ALLAS · historial de actualizaciones", ""]
    for h in historial_versiones(raiz, version_actual, desde):
        salida.append(f"Versión {h['version']}" + (f" — {h['fecha']}" if h["fecha"] else ""))
        for linea in h["notas"].splitlines():
            linea = linea.strip()
            if not linea:
                continue
            linea = mayuscula_tras_dos_puntos(linea)
            linea = re.sub(r"\*\*|`", "", linea)
            salida.append("  " + linea if linea[:1] in "-*•" else "    " + linea)
        salida.append("")
    return "\n".join(salida).rstrip() + "\n"


def motivo_limpieza(pq):
    """1.13: por qué un paquete de la carpeta ya no sirve (None si todavía se puede instalar):
    no_valido, instalada, anterior o incompatible."""
    if "error" in pq:
        return "no_valido"
    if pq.get("estado") in ("instalada", "anterior"):
        return pq["estado"]
    return None if pq.get("instalable") else "incompatible"


def tamano_carpeta(ruta):
    total = 0
    for base, _, nombres in os.walk(ruta):
        for n in nombres:
            try:
                total += os.path.getsize(os.path.join(base, n))
            except OSError:
                pass
    return total


def paquetes_en_carpeta(carpeta, clave_publica, version_actual=None):
    """Paquetes .zip dejados en la carpeta 'actualizaciones' (p. ej. desde un pendrive)."""
    salida = []
    if not os.path.isdir(carpeta):
        return salida
    for n in sorted(os.listdir(carpeta)):
        if not n.lower().endswith(".zip"):
            continue
        ruta = os.path.join(carpeta, n)
        try:
            with open(ruta, "rb") as f:
                m, z = leer_paquete(f.read(), clave_publica)
            pq = {"archivo": n, "version": m["version"], "fecha": m["fecha"], "notas": m.get("notas", "")}
            if version_actual:
                pq["cambios"] = cambios_desde(z, version_actual, m["version"])
            salida.append(pq)
        except (OSError, ErrorActualizacion) as e:
            salida.append({"archivo": n, "error": str(e)})
    return salida
