"""PROYECTO ALLAS · lógica de negocio: turnos, caja, cierre, informes y auditoría (1.4: sale de servicios.py; se mezcla en la clase Parking)."""
import csv
import io
import json

from . import impresion
from .utiles import ErrorNegocio, iso


class SvcCaja:
    # ============================================================== turnos
    # 3.9: cada cajero tiene su propio turno (varios abiertos a la vez, uno por persona)
    def turno_abierto(self, usuario=None):
        """El turno abierto de ese usuario; sin usuario, el más antiguo de los abiertos (compatibilidad)."""
        if usuario is not None:
            t = self.db.q1("SELECT t.*, u.nombre AS usuario_nombre FROM turnos t JOIN usuarios u ON u.id=t.usuario_id "
                           "WHERE t.estado='abierto' AND t.usuario_id=?", (usuario["id"],))
        else:
            t = self.db.q1("SELECT t.*, u.nombre AS usuario_nombre FROM turnos t JOIN usuarios u ON u.id=t.usuario_id "
                           "WHERE t.estado='abierto' ORDER BY t.id LIMIT 1")
        if t:
            t.update(self._totales_turno(t["id"]))
        return t

    def turnos_abiertos(self):
        return self.db.q("SELECT t.id, t.usuario_id, t.apertura, u.nombre usuario_nombre FROM turnos t "
                         "JOIN usuarios u ON u.id=t.usuario_id WHERE t.estado='abierto' ORDER BY t.id")

    def turno_de(self, usuario):
        """El turno en el que trabaja el usuario: el suyo o, desde la caja móvil (si se permite), el único abierto."""
        t = self.turno_abierto(usuario)
        if t or not usuario.get("_movil"):
            return t
        if self.cfg("movil_turno_compartido") != "0" and self.tiene_modulo("movil"):
            abiertos = self.turnos_abiertos()
            if len(abiertos) == 1:
                return self.resumen_turno(abiertos[0]["id"])
        return None

    def _exigir_turno(self, usuario):
        t = self.turno_de(usuario)
        if not t:
            otros = self.turnos_abiertos()
            if usuario.get("_movil") and len(otros) > 1:
                raise ErrorNegocio("Hay varios turnos abiertos: abra su propio turno en el móvil.", 409)
            if otros and not self.tiene_modulo("multicaja"):
                raise ErrorNegocio(f"La caja está abierta por {otros[0]['usuario_nombre']}. Debe cerrar su turno antes.", 409)
            raise ErrorNegocio("No tiene un turno de caja abierto. Abra su turno primero (Caja y turno).", 409)
        return t

    # ---------------------------------------------------------- arqueo por billetes y monedas (3.5)
    DENOMINACIONES = (50000, 20000, 10000, 5000, 2000, 1000, 500, 200, 100, 50, 20, 10, 5, 2, 1)

    @classmethod
    def _desglose(cls, d):
        """{'2000': 3, '500': 4} → (total en céntimos, JSON normalizado) o (None, None) si no hay desglose."""
        if not d:
            return None, None
        if not isinstance(d, dict):
            raise ErrorNegocio("Desglose de efectivo no válido")
        limpio = {}
        for k, v in d.items():
            try:
                den, n = int(k), int(v or 0)
            except (TypeError, ValueError):
                raise ErrorNegocio("Desglose de efectivo no válido")
            if den not in cls.DENOMINACIONES or n < 0 or n > 100000:
                raise ErrorNegocio("Desglose de efectivo no válido")
            if n:
                limpio[str(den)] = n
        return sum(int(k) * n for k, n in limpio.items()), json.dumps(limpio, sort_keys=True)

    def config_arqueo(self):
        dens = [int(x) for x in (self.cfg("arqueo_denominaciones") or "").split(",") if x.strip().isdigit()]
        dens = [d for d in self.DENOMINACIONES if d in dens] or list(self.DENOMINACIONES)
        try:
            fondo = {str(int(k)): int(v) for k, v in json.loads(self.cfg("arqueo_fondo_predefinido") or "{}").items() if int(v) > 0}
        except (ValueError, TypeError, AttributeError):
            fondo = {}
        return {"desglose_cierre": self.cfg("arqueo_desglose_cierre") != "0",
                "desglose_apertura": self.cfg("arqueo_desglose_apertura") == "1",
                "denominaciones": dens, "fondo_predefinido": fondo,
                "fondo_predefinido_cent": sum(int(k) * v for k, v in fondo.items())}

    def abrir_turno(self, usuario, fondo_cent, arqueo=True, fondo_desglose=None):
        """arqueo=False: al cerrar no se cuenta el efectivo (sin comprobación de descuadre).
        fondo_desglose (3.5): billetes y monedas del fondo; si se da, el fondo es su suma."""
        total_d, desglose = self._desglose(fondo_desglose)
        if desglose:
            fondo_cent = total_d
        fondo_cent = int(fondo_cent or 0)
        if fondo_cent < 0:
            raise ErrorNegocio("El fondo no puede ser negativo")
        arqueo = 0 if arqueo in (False, 0, "0") else 1
        with self.db.transaccion() as c:
            if c.execute("SELECT 1 FROM turnos WHERE estado='abierto' AND usuario_id=?", (usuario["id"],)).fetchone():
                raise ErrorNegocio("Ya tiene un turno abierto", 409)
            otro = c.execute("SELECT u.nombre FROM turnos t JOIN usuarios u ON u.id=t.usuario_id WHERE t.estado='abierto'").fetchone()
            if otro and not self.tiene_modulo("multicaja"):   # 4.0: sin el módulo, una sola caja abierta
                raise ErrorNegocio(f"La caja está abierta por {otro[0]}: debe cerrar su turno antes "
                                   "(varios turnos a la vez necesitan el módulo «Varios cajeros»).", 409)
            tid = c.execute("INSERT INTO turnos(usuario_id, apertura, fondo_inicial_cent, arqueo, fondo_desglose) VALUES(?,?,?,?,?)",
                            (usuario["id"], iso(self.ahora()), fondo_cent, arqueo, desglose)).lastrowid
            # se recuerda la elección para proponerla en el siguiente turno
            c.execute("INSERT INTO config(clave, valor) VALUES('arqueo_defecto', ?) "
                      "ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor", (str(arqueo),))
            self.auditar(c, usuario["id"], "turno_abrir",
                         f"turno={tid} fondo={fondo_cent}" + ("" if arqueo else " SIN ARQUEO"))
        return tid

    def _totales_turno(self, turno_id):
        t = self.db.q1("SELECT fondo_inicial_cent FROM turnos WHERE id=?", (turno_id,))
        p = self.db.q1("SELECT "
                       "COALESCE(SUM(CASE WHEN metodo='efectivo' THEN importe_cent END),0) efectivo, "
                       "COALESCE(SUM(CASE WHEN metodo='tarjeta' THEN importe_cent END),0) tarjeta, "
                       "COALESCE(SUM(CASE WHEN metodo='transferencia' THEN importe_cent END),0) transferencia, "
                       "COALESCE(SUM(CASE WHEN concepto='bono' THEN importe_cent END),0) bonos, "
                       "COALESCE(SUM(concepto='bono'),0) nbonos, "
                       "COALESCE(SUM(extras_cent),0) extras, "
                       "COALESCE(SUM(concepto<>'rectificativa'),0) n, "
                       "-COALESCE(SUM(CASE WHEN concepto='rectificativa' THEN importe_cent END),0) devuelto, "
                       "COALESCE(SUM(concepto='rectificativa'),0) ndev FROM pagos WHERE turno_id=?", (turno_id,))
        m = self.db.q1("SELECT "
                       "COALESCE(SUM(CASE WHEN tipo='ingreso' THEN importe_cent END),0) ingresos, "
                       "COALESCE(SUM(CASE WHEN tipo='retirada' THEN importe_cent END),0) retiradas "
                       "FROM movimientos_caja WHERE turno_id=?", (turno_id,))
        n_ent = self.db.q1("SELECT COUNT(*) n FROM tickets WHERE turno_entrada_id=?", (turno_id,))["n"]
        esperado = t["fondo_inicial_cent"] + p["efectivo"] + m["ingresos"] - m["retiradas"]
        return {"cobrado_efectivo_cent": p["efectivo"], "cobrado_tarjeta_cent": p["tarjeta"],
                "cobrado_transferencia_cent": p["transferencia"],
                "cobrado_bonos_cent": p["bonos"], "num_bonos": p["nbonos"], "cobrado_extras_cent": p["extras"],
                "num_cobros": p["n"], "ingresos_cent": m["ingresos"], "retiradas_cent": m["retiradas"],
                "devuelto_cent": p["devuelto"], "num_devoluciones": p["ndev"],
                "num_entradas": n_ent, "efectivo_esperado_actual_cent": esperado}

    def movimiento_caja(self, usuario, tipo, importe_cent, motivo):
        if tipo not in ("retirada", "ingreso"):
            raise ErrorNegocio("Tipo de movimiento no válido")
        importe_cent = int(importe_cent)
        if importe_cent <= 0:
            raise ErrorNegocio("El importe debe ser mayor que cero")
        t = self._exigir_turno(usuario)
        if tipo == "retirada" and importe_cent > t["efectivo_esperado_actual_cent"]:
            raise ErrorNegocio("No hay tanto efectivo en caja")
        with self.db.transaccion() as c:
            c.execute("INSERT INTO movimientos_caja(turno_id, usuario_id, fecha, tipo, importe_cent, motivo) "
                      "VALUES(?,?,?,?,?,?)", (t["id"], usuario["id"], iso(self.ahora()), tipo, importe_cent, motivo))
            self.auditar(c, usuario["id"], f"caja_{tipo}", f"{importe_cent} {motivo or ''}")
        return self._imprimir(self._doc_movimiento(tipo, importe_cent, motivo, usuario), "movimiento", cajon=True)

    def abrir_cajon(self, usuario, motivo):
        """Apertura sin venta: queda registrada en auditoría y en el turno."""
        t = self.turno_de(usuario)
        with self.db.transaccion() as c:
            if t:
                c.execute("INSERT INTO movimientos_caja(turno_id, usuario_id, fecha, tipo, motivo) "
                          "VALUES(?,?,?,'apertura_cajon',?)", (t["id"], usuario["id"], iso(self.ahora()), motivo))
            self.auditar(c, usuario["id"], "cajon_abrir", motivo or "")
        doc = impresion.Ticket(self.cfg("impresora_ancho", int)).abrir_cajon(self.cfg("cajon_pin", int))
        return self._enviar(doc, "cajon")

    def cerrar_turno(self, usuario, contado_cent, observaciones="", contado_desglose=None, turno_id=None):
        """Cierra el turno propio o, si se indica turno_id (supervisor), el de otro cajero."""
        total_d, desglose = self._desglose(contado_desglose)
        if desglose:
            contado_cent = total_d
        if turno_id:
            t = self.db.q1("SELECT id FROM turnos WHERE id=? AND estado='abierto'", (int(turno_id),))
            t = self.resumen_turno(t["id"]) if t else None
        else:
            t = self.turno_abierto(usuario)
        if not t:
            raise ErrorNegocio("No hay turno abierto", 409)
        if t["usuario_id"] != usuario["id"] and not self.puede(usuario, "turnos_ajenos"):
            raise ErrorNegocio("Solo el titular del turno o un supervisor puede cerrarlo", 403)
        esperado = t["efectivo_esperado_actual_cent"]
        if t.get("arqueo", 1):
            contado_cent = int(contado_cent)
            diferencia = contado_cent - esperado
        else:  # turno sin arqueo: no se cuenta el efectivo
            contado_cent = diferencia = None
        with self.db.transaccion() as c:
            c.execute("UPDATE turnos SET cierre=?, efectivo_esperado_cent=?, efectivo_contado_cent=?, "
                      "diferencia_cent=?, observaciones=?, estado='cerrado', contado_desglose=? WHERE id=?",
                      (iso(self.ahora()), esperado, contado_cent, diferencia, observaciones,
                       desglose if t.get("arqueo", 1) else None, t["id"]))
            self.auditar(c, usuario["id"], "turno_cerrar",
                         f"turno={t['id']} esperado={esperado} "
                         + (f"contado={contado_cent}" if contado_cent is not None else "sin arqueo"))
        res = self.resumen_turno(t["id"])
        res["impresion"] = self._imprimir(self._doc_cierre(res), "cierre", cajon=True)
        if self.cfg("cierre_email_activo") == "1" and not self.turnos_abiertos():   # 4.3: resumen del día por email
            import threading
            threading.Thread(target=self._cierre_tras_turno, daemon=True).start()
            res["cierre_email"] = True
        return res

    def resumen_turno(self, turno_id):
        t = self.db.q1("SELECT t.*, u.nombre AS usuario_nombre FROM turnos t "
                       "JOIN usuarios u ON u.id=t.usuario_id WHERE t.id=?", (turno_id,))
        if not t:
            raise ErrorNegocio("Turno no encontrado", 404)
        t.update(self._totales_turno(turno_id))
        t["movimientos"] = self.db.q("SELECT m.*, u.nombre usuario_nombre FROM movimientos_caja m "
                                     "JOIN usuarios u ON u.id=m.usuario_id WHERE turno_id=? ORDER BY m.id", (turno_id,))
        return t

    def turnos(self, limite=50):
        return self.db.q("SELECT t.*, u.nombre usuario_nombre FROM turnos t JOIN usuarios u ON u.id=t.usuario_id "
                         "ORDER BY t.id DESC LIMIT ?", (limite,))

    # ============================================================ informes
    def informe(self, desde, hasta):
        """desde/hasta: 'YYYY-MM-DD' (ambos inclusive)."""
        d0, d1 = desde + "T00:00:00", hasta + "T23:59:59"
        # Las fechas incluyen offset; comparamos por los primeros 19 caracteres (hora local)
        dias = self.db.q("SELECT substr(fecha,1,10) dia, SUM(concepto='estancia') cobros, SUM(importe_cent) total, "
                         "SUM(CASE WHEN metodo='efectivo' THEN importe_cent ELSE 0 END) efectivo, "
                         "SUM(CASE WHEN metodo='tarjeta' THEN importe_cent ELSE 0 END) tarjeta, "
                         "SUM(CASE WHEN metodo='online' THEN importe_cent ELSE 0 END) online, "
                         "SUM(CASE WHEN metodo='transferencia' THEN importe_cent ELSE 0 END) transferencia, "
                         "SUM(CASE WHEN concepto='venta' THEN importe_cent ELSE 0 END) tienda, "
                         "SUM(CASE WHEN concepto='bono' THEN importe_cent ELSE 0 END) bonos, "
                         "SUM(concepto='bono') num_bonos, "
                         "SUM(CASE WHEN concepto='estancia' THEN importe_cent - extras_cent ELSE 0 END) estancias, "
                         "SUM(extras_cent) servicios, SUM(descuento_cent) descuentos, SUM(descuento_cent > 0) num_descuentos, "
                         "-SUM(CASE WHEN concepto='rectificativa' AND COALESCE(rectificacion,'diferencias')='diferencias' THEN importe_cent ELSE 0 END) devoluciones, "
                         "SUM(concepto='rectificativa' AND COALESCE(rectificacion,'diferencias')='diferencias') num_devoluciones, "
                         "SUM(concepto='sustitutiva') num_sustituciones, "
                         "SUM(minutos) minutos FROM pagos WHERE substr(fecha,1,19) BETWEEN ? AND ? "
                         "GROUP BY dia ORDER BY dia", (d0, d1))
        entradas = {r["dia"]: r["n"] for r in self.db.q(
            "SELECT substr(entrada,1,10) dia, COUNT(*) n FROM tickets WHERE substr(entrada,1,19) BETWEEN ? AND ? "
            "AND estado<>'anulado' GROUP BY dia", (d0, d1))}
        for d in dias:
            d["entradas"] = entradas.pop(d["dia"], 0)
        for dia, n in entradas.items():
            dias.append({"dia": dia, "cobros": 0, "total": 0, "efectivo": 0, "tarjeta": 0, "online": 0, "transferencia": 0, "tienda": 0, "minutos": 0, "entradas": n,
                         "bonos": 0, "num_bonos": 0, "estancias": 0, "servicios": 0, "descuentos": 0, "num_descuentos": 0,
                         "devoluciones": 0, "num_devoluciones": 0, "num_sustituciones": 0})
        dias.sort(key=lambda x: x["dia"])
        tot = {k: sum(d[k] or 0 for d in dias) for k in ("cobros", "total", "efectivo", "tarjeta", "online", "transferencia", "tienda", "minutos",
                                                         "entradas", "bonos", "num_bonos", "estancias", "servicios",
                                                         "descuentos", "num_descuentos", "devoluciones", "num_devoluciones", "num_sustituciones")}
        tot["ticket_medio"] = round(tot["estancias"] / tot["cobros"]) if tot["cobros"] else 0
        tot["estancia_media_min"] = round(tot["minutos"] / tot["cobros"]) if tot["cobros"] else 0
        anulados = self.db.q1("SELECT COUNT(*) n FROM tickets WHERE estado='anulado' AND substr(entrada,1,19) "
                              "BETWEEN ? AND ?", (d0, d1))["n"]
        productos_vendidos = self.db.q(
            "SELECT nombre, tipo, SUM(cantidad) unidades, SUM(cantidad * precio_cent) importe FROM ("
            "SELECT e.nombre, e.tipo, e.cantidad, e.precio_cent FROM ticket_extras e JOIN pagos p ON p.id=e.pago_id "
            "WHERE substr(p.fecha,1,19) BETWEEN ? AND ? UNION ALL "
            "SELECT v.nombre, v.tipo, v.cantidad, v.precio_cent FROM ventas_lineas v JOIN pagos p ON p.id=v.pago_id "
            "WHERE substr(p.fecha,1,19) BETWEEN ? AND ?) GROUP BY nombre, tipo ORDER BY importe DESC", (d0, d1, d0, d1))
        manuales = self.db.q1("SELECT COUNT(*) n FROM tickets WHERE manual=1 AND substr(entrada,1,19) "
                              "BETWEEN ? AND ?", (d0, d1))["n"]
        perdidos = self.db.q1("SELECT COUNT(*) n FROM pagos WHERE recargo_cent>0 AND substr(fecha,1,19) "
                              "BETWEEN ? AND ?", (d0, d1))["n"]
        horas = self.db.q("SELECT CAST(substr(entrada,12,2) AS INTEGER) hora, COUNT(*) n FROM tickets "
                          "WHERE substr(entrada,1,19) BETWEEN ? AND ? AND estado<>'anulado' GROUP BY hora", (d0, d1))
        abonados = self.db.q1("SELECT COUNT(DISTINCT cliente_id) n FROM bonos WHERE estado='activo' "
                              "AND desde<=? AND hasta>=?", (self.ahora().date().isoformat(),) * 2)["n"]
        entradas_abonados = self.db.q1("SELECT COUNT(*) n FROM tickets WHERE cliente_id IS NOT NULL AND "
                                       "substr(entrada,1,19) BETWEEN ? AND ?", (d0, d1))["n"]
        comercios = self.db.q(   # 3.9: validaciones de comercios (descuentos marcados con un comercio)
            "SELECT d.comercio, COUNT(*) usos, SUM(p.descuento_cent) importe FROM pagos p JOIN descuentos d ON d.id=p.descuento_id "
            "WHERE d.comercio IS NOT NULL AND d.comercio<>'' AND substr(p.fecha,1,19) BETWEEN ? AND ? "
            "GROUP BY d.comercio ORDER BY importe DESC", (d0, d1))
        return {"desde": desde, "hasta": hasta, "dias": dias, "totales": tot, "anulados": anulados, "comercios": comercios,
                "abonados_vigentes": abonados, "entradas_abonados": entradas_abonados, "manuales": manuales, "productos_vendidos": productos_vendidos,
                "perdidos": perdidos, "entradas_por_hora": horas}

    def csv_pagos(self, desde, hasta):
        filas = self.db.q("SELECT p.serie, p.numero, p.fecha, p.concepto, t.codigo, "
                          "COALESCE(t.matricula, '') matricula, t.entrada, p.minutos, cl.nombre cliente, cl.nif, "
                          "b.desde bono_desde, b.hasta bono_hasta, "
                          "p.importe_cent, p.recargo_cent, p.extras_cent, p.metodo, COALESCE(u.nombre, 'Pago online') empleado, r.base_cent, "
                          "r.cuota_iva_cent, r.hash "
                          "FROM pagos p LEFT JOIN tickets t ON t.id=p.ticket_id LEFT JOIN bonos b ON b.id=p.bono_id "
                          "LEFT JOIN clientes cl ON cl.id=b.cliente_id LEFT JOIN usuarios u ON u.id=p.usuario_id "
                          "LEFT JOIN registros_facturacion r ON r.pago_id=p.id "
                          "WHERE substr(p.fecha,1,10) BETWEEN ? AND ? ORDER BY p.serie, p.numero", (desde, hasta))
        out = io.StringIO()
        w = csv.writer(out, delimiter=";")
        w.writerow(["Serie", "Número", "Fecha", "Concepto", "Ticket", "Matrícula", "Entrada", "Minutos",
                    "Cliente", "NIF cliente", "Bono desde", "Bono hasta", "Importe",
                    "Recargo", "Servicios/productos", "Método", "Empleado", "Base", "IVA", "Hash"])
        dec = lambda c: f"{(c or 0) / 100:.2f}".replace(".", ",")
        for f in filas:
            w.writerow([f["serie"], f["numero"], f["fecha"], f["concepto"], f["codigo"] or "", f["matricula"] or "",
                        f["entrada"] or "", f["minutos"], f["cliente"] or "", f["nif"] or "", f["bono_desde"] or "",
                        f["bono_hasta"] or "", dec(f["importe_cent"]), dec(f["recargo_cent"]), dec(f["extras_cent"]),
                        f["metodo"], f["empleado"],
                        dec(f["base_cent"]), dec(f["cuota_iva_cent"]), f["hash"]])
        return "﻿" + out.getvalue()  # BOM para que Excel abra bien las tildes

    def auditoria(self, limite=200):
        return self.db.q("SELECT a.*, u.nombre usuario_nombre FROM auditoria a LEFT JOIN usuarios u "
                         "ON u.id=a.usuario_id ORDER BY a.id DESC LIMIT ?", (limite,))
