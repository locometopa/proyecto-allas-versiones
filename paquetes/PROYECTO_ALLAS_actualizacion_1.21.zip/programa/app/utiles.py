"""PROYECTO ALLAS · utilidades y errores comunes de la lógica de negocio (1.4: salen de servicios.py).

servicios.py las vuelve a exportar, así que `from .servicios import eur, ErrorNegocio…` sigue funcionando."""
from datetime import datetime
import hashlib


def texto_metodo(m):
    return {"online": "Tarjeta (pago online)", "transferencia": "Transferencia bancaria"}.get(m, (m or "").capitalize())


class ErrorNegocio(Exception):
    """Error esperado que se muestra tal cual al empleado."""

    def __init__(self, msg, codigo=400, datos=None):
        super().__init__(msg)
        self.codigo = codigo
        self.datos = datos or {}   # 4.1: datos extra para la interfaz (p. ej. la lista negra)


ROLES_SUPERVISION = ("admin", "supervisor")


def _norm_txt(t):
    import unicodedata
    return unicodedata.normalize("NFKD", str(t or "")).encode("ascii", "ignore").decode().lower().strip()


def eur(cent):
    if cent is None:
        return "-"
    s = "-" if cent < 0 else ""
    cent = abs(cent)
    return f"{s}{cent // 100:,}".replace(",", ".") + f",{cent % 100:02d} €"


def hash_pin(pin, salt):
    return hashlib.pbkdf2_hmac("sha256", pin.encode(), bytes.fromhex(salt), 120_000).hex()


def iso(dt):
    return dt.isoformat(timespec="seconds")


def parse(s):
    return datetime.fromisoformat(s)


def norm_matricula(m):
    return "".join(ch for ch in (m or "").upper() if ch.isalnum()) or None


def desglose_iva(lineas):
    """lineas: [(importe_cent IVA incluido, iva_pct)] -> [{'pct','base','cuota','total'}] agrupado por tipo."""
    por_tipo = {}
    for importe, pct in lineas:
        if importe:
            por_tipo[float(pct)] = por_tipo.get(float(pct), 0) + importe
    salida = []
    for pct, total in sorted(por_tipo.items(), reverse=True):
        base = round(total / (1 + pct / 100))
        salida.append({"pct": pct, "base": base, "cuota": total - base, "total": total})
    return salida


def _plantilla(texto, datos):
    for k, v in datos.items():
        texto = texto.replace("{" + k + "}", str(v))
    return texto


def email_valido(e):
    import re
    return bool(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", e or ""))


def nif_valido(nif):
    """Valida NIF (DNI), NIE y CIF españoles. Otros formatos (extranjeros) devuelven False."""
    import re
    letras = "TRWAGMYFPDXBNJZSQVHLCKE"
    nif = (nif or "").upper()
    if re.fullmatch(r"\d{8}[A-Z]", nif):
        return letras[int(nif[:8]) % 23] == nif[8]
    if re.fullmatch(r"[XYZ]\d{7}[A-Z]", nif):
        return letras[int(str("XYZ".index(nif[0])) + nif[1:8]) % 23] == nif[8]
    if re.fullmatch(r"[ABCDEFGHJNPQRSUVW]\d{7}[0-9A-J]", nif):
        dig = nif[1:8]
        pares = sum(int(dig[i]) for i in (1, 3, 5))
        impares = sum(sum(divmod(int(dig[i]) * 2, 10)) for i in (0, 2, 4, 6))
        control = (10 - (pares + impares) % 10) % 10
        return nif[8] in (str(control), "JABCDEFGHI"[control])
    return False


def _partir_txt(texto, ancho):
    """Corta un texto en líneas de 'ancho' caracteres por palabras."""
    salida = []
    for parrafo in (texto or "").splitlines():
        actual = ""
        for p in parrafo.split():
            if actual and len(actual) + 1 + len(p) > ancho:
                salida.append(actual)
                actual = p
            else:
                actual = (actual + " " + p).strip()
        if actual:
            salida.append(actual[:ancho])
    return salida


def texto_duracion(minutos):
    h, m = divmod(int(minutos), 60)
    return (f"{h // 24} d " if h >= 24 else "") + f"{h % 24} h {m:02d} min"


def duracion_corta(minutos):
    """90 -> '1 h 30 min' · 120 -> '2 h' · 45 -> '45 min'"""
    h, m = divmod(int(minutos), 60)
    return " ".join(x for x in (f"{h} h" if h else "", f"{m} min" if m or not h else "") if x)


def desc_vehiculo(v):
    """'1234ABC · Seat Ibiza'"""
    extra = " ".join(x for x in (v.get("marca"), v.get("modelo")) if x)
    return v["matricula"] + (f" · {extra}" if extra else "")


def fecha_es(d):
    """'2026-10-09' -> '09/10/2026'"""
    if not d:
        return "-"
    return f"{d[8:10]}/{d[5:7]}/{d[0:4]}"


DIAS = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]


MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre",
         "octubre", "noviembre", "diciembre"]


def fecha_larga(dt):
    return f"{DIAS[dt.weekday()]}, {dt.day} de {MESES[dt.month - 1]} de {dt.year}"


def sumar_meses(d, meses):
    """Suma meses a una fecha ajustando al último día del mes si hace falta (31 ene + 1 = 28/29 feb)."""
    import calendar
    m = d.month - 1 + meses
    a, m = d.year + m // 12, m % 12 + 1
    return d.replace(year=a, month=m, day=min(d.day, calendar.monthrange(a, m)[1]))
