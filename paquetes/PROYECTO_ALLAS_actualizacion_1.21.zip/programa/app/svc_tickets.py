"""PROYECTO ALLAS · lógica de negocio: entrada y salida de vehículos, cobro, reservas, extras, ticket manual, historial y lista negra (1.4: sale de servicios.py; se mezcla en la clase Parking)."""
import csv
import hashlib
import hmac
import io
import secrets
from datetime import date, datetime, timedelta

from . import errores
from . import impresion
from . import logo as logos
from .tarifas import calcular_importe
from .tarifas import minutos_estancia
from .utiles import ErrorNegocio, ROLES_SUPERVISION, desglose_iva, eur, fecha_es, iso, norm_matricula, parse, texto_duracion


class SvcTickets:
    # ------------------------------------------------------------------ 4.1 · lista negra de matrículas
    def lista_negra_modo(self):
        return "bloquear" if self.cfg("lista_negra_modo") == "bloquear" else "avisar"

    def en_lista_negra(self, matricula):
        m = norm_matricula(matricula)
        if not m:
            return None
        return self.db.q1("SELECT l.id, l.matricula, l.motivo, l.nota, l.creada, u.nombre AS creada_por FROM lista_negra l "
                          "LEFT JOIN usuarios u ON u.id=l.usuario_id WHERE l.matricula=? AND l.activa=1", (m,))

    def _comprobar_lista_negra(self, usuario, ln, confirmado, autorizado_por=None):
        modo = self.lista_negra_modo()
        datos = {"lista_negra": {**ln, "modo": modo}}
        if not confirmado:
            raise ErrorNegocio(f"La matrícula {ln['matricula']} está en la LISTA NEGRA: {ln['motivo']}", 423, datos)
        actor = autorizado_por or usuario
        if modo == "bloquear" and actor["rol"] not in ROLES_SUPERVISION:
            raise ErrorNegocio("Matrícula en lista negra: para dejarla entrar hace falta la autorización de un supervisor", 403, datos)
        with self.db.transaccion() as c:
            self.auditar(c, actor["id"], "lista_negra_permitir", f"{ln['matricula']} ({ln['motivo']})"
                         + (f" en el puesto de {usuario['usuario']}" if autorizado_por else ""))

    def lista_negra(self, buscar="", todas=False):
        sql = ("SELECT l.*, u.nombre AS creada_por, r.nombre AS retirada_por_nombre FROM lista_negra l "
               "LEFT JOIN usuarios u ON u.id=l.usuario_id LEFT JOIN usuarios r ON r.id=l.retirada_por WHERE 1=1")
        args = []
        if not todas:
            sql += " AND l.activa=1"
        b = (buscar or "").strip()
        if b:
            sql += " AND (l.matricula LIKE ? OR l.motivo LIKE ? OR l.nota LIKE ?)"
            args += [f"%{norm_matricula(b) or b}%", f"%{b}%", f"%{b}%"]
        filas = self.db.q(sql + " ORDER BY l.activa DESC, l.creada DESC LIMIT 1000", args)
        for f in filas:   # ¿está dentro ahora?
            f["dentro"] = bool(self.db.q1("SELECT 1 FROM tickets WHERE matricula=? AND estado IN ('dentro','pagado')", (f["matricula"],)))
        return filas

    def agregar_lista_negra(self, usuario, matricula, motivo, nota=""):
        if not self.puede(usuario, "lista_negra"):
            raise ErrorNegocio("Solo un supervisor o el administrador puede cambiar la lista negra", 403)
        m = norm_matricula(matricula)
        if not m or len(m) < 3 or len(m) > 12:
            raise ErrorNegocio("Indique una matrícula válida")
        motivo = (motivo or "").strip()[:200]
        if len(motivo) < 3:
            raise ErrorNegocio("Indique el motivo")
        if self.en_lista_negra(m):
            raise ErrorNegocio(f"La matrícula {m} ya está en la lista negra", 409)
        with self.db.transaccion() as c:
            lid = c.execute("INSERT INTO lista_negra(matricula, motivo, nota, creada, usuario_id) VALUES(?,?,?,?,?)",
                            (m, motivo, (nota or "").strip()[:500] or None, iso(self.ahora()), usuario["id"])).lastrowid
            self.auditar(c, usuario["id"], "lista_negra_alta", f"{m}: {motivo}")
        return self.db.q1("SELECT * FROM lista_negra WHERE id=?", (lid,))

    def editar_lista_negra(self, usuario, lid, motivo, nota=""):
        if not self.puede(usuario, "lista_negra"):
            raise ErrorNegocio("Solo un supervisor o el administrador puede cambiar la lista negra", 403)
        motivo = (motivo or "").strip()[:200]
        if len(motivo) < 3:
            raise ErrorNegocio("Indique el motivo")
        with self.db.transaccion() as c:
            if not c.execute("UPDATE lista_negra SET motivo=?, nota=? WHERE id=? AND activa=1",
                             (motivo, (nota or "").strip()[:500] or None, int(lid))).rowcount:
                raise ErrorNegocio("No encontrada", 404)
            self.auditar(c, usuario["id"], "lista_negra_editar", f"id={lid}: {motivo}")
        return self.db.q1("SELECT * FROM lista_negra WHERE id=?", (int(lid),))

    def quitar_lista_negra(self, usuario, lid):
        if not self.puede(usuario, "lista_negra"):
            raise ErrorNegocio("Solo un supervisor o el administrador puede cambiar la lista negra", 403)
        with self.db.transaccion() as c:
            fila = c.execute("SELECT matricula FROM lista_negra WHERE id=? AND activa=1", (int(lid),)).fetchone()
            if not fila:
                raise ErrorNegocio("No encontrada", 404)
            c.execute("UPDATE lista_negra SET activa=0, retirada=?, retirada_por=? WHERE id=?", (iso(self.ahora()), usuario["id"], int(lid)))
            self.auditar(c, usuario["id"], "lista_negra_baja", fila[0])
        return {"ok": True}

    # ============================================================= tickets
    def _firma(self, tid, prefijo="PK"):
        secreto = self.db.get_cfg("secreto_qr").encode()
        msg = str(tid) if prefijo == "PK" else f"{prefijo}{tid}"
        return hmac.new(secreto, msg.encode(), hashlib.sha256).hexdigest()[:5].upper()

    def _codigo(self, tid, prefijo="PK"):
        return f"{prefijo}{tid:07d}{self._firma(tid, prefijo)}"

    @staticmethod
    def _limpiar_codigo(codigo):
        # Algunos lectores con la distribución de teclado mal configurada meten símbolos: solo [A-Z0-9]
        return "".join(ch for ch in (codigo or "").strip().upper() if ch.isalnum())

    def _leer_codigo(self, codigo):
        """Devuelve (prefijo, número) de un código escaneado: CL = tarjeta de cliente; otro prefijo = ticket."""
        import re
        url = re.search(r"[?&]c=([A-Za-z0-9-]+)", codigo or "")   # 4.3: QR de pago con el móvil (https://…/pagar?c=CÓDIGO)
        if url:
            codigo = url.group(1)
        codigo = self._limpiar_codigo(codigo)
        m = re.fullmatch(r"([A-Z]{1,3})(\d{7})([0-9A-F]{5})", codigo)
        if not m and len(codigo) > 15:   # URL leída con el teclado mal configurado: el código va al final
            for n in (1, 2, 3):
                x = re.fullmatch(r"([A-Z]{%d})(\d{7})([0-9A-F]{5})" % n, codigo[-(12 + n):])
                if x and hmac.compare_digest(x.group(3), self._firma(int(x.group(2)), x.group(1))):
                    m = x
                    break
        if not m:
            raise ErrorNegocio("Código no reconocido. ¿Es un ticket o tarjeta de este parking?", 404)
        pre, num = m.group(1), int(m.group(2))
        if not hmac.compare_digest(m.group(3), self._firma(num, pre)):
            raise ErrorNegocio("Código no válido (firma incorrecta)", 404)
        return pre, num

    def _id_desde_codigo(self, codigo):
        pre, num = self._leer_codigo(codigo)
        if pre == "CL":
            raise ErrorNegocio("Eso es una tarjeta de abonado, no un ticket", 400)
        canon = f"{pre}{num:07d}{self._firma(num, pre)}"   # 4.3: también si venía dentro de la URL de pago
        t = self.db.q1("SELECT id FROM tickets WHERE codigo IN (?, ?)", (self._limpiar_codigo(codigo), canon))
        if not t:
            raise ErrorNegocio("Ticket no encontrado", 404)
        return t["id"]

    def _asignar_codigo_ticket(self, c, tid):
        """Número correlativo (desde el inicial configurado) y código con el prefijo configurado."""
        pre = (self.cfg("ticket_prefijo") or "PK").upper()
        ultimo = c.execute("SELECT MAX(numero) FROM tickets").fetchone()[0] or 0
        numero = max(ultimo + 1, int(self.cfg("ticket_numero_inicial") or 1))
        codigo = self._codigo(numero, pre)
        c.execute("UPDATE tickets SET numero=?, codigo=? WHERE id=?", (numero, codigo, tid))
        return codigo

    def emitir_ticket(self, usuario, matricula=None, tarifa_id=None, forzar_ticket=False, ajuste_min=0,
                      lista_negra_ok=False, autorizado_por=None, reserva=None, tipo_vehiculo=None, zona_id=None,
                      digital=None, llaves=False):
        t = self._exigir_turno(usuario)
        self._exigir_licencia()
        self._exigir_abierto(usuario)   # 1.9: horario del parking
        matricula = norm_matricula(matricula)
        ln = self.en_lista_negra(matricula)
        if ln:
            self._comprobar_lista_negra(usuario, ln, lista_negra_ok, autorizado_por)
        try:
            ajuste = int(ajuste_min or 0)
        except (TypeError, ValueError):
            raise ErrorNegocio("Ajuste de minutos no válido")
        maximo = max(0, min(1440, self.cfg("entrada_ajuste_max_min", int) or 0))
        if abs(ajuste) > maximo:
            raise ErrorNegocio(f"El ajuste de la hora de entrada no puede pasar de {maximo} minutos"
                               if maximo else "El ajuste de la hora de entrada está desactivado en Ajustes")
        if matricula and not forzar_ticket and self.tiene_modulo("abonados"):
            cli = self.db.q1("SELECT cliente_id FROM cliente_matriculas WHERE matricula=?", (matricula,))
            if cli:
                self.renovar_bonos_automaticos(cli["cliente_id"])
            if cli and self.bono_vigente(cli["cliente_id"]):
                return self.entrada_abonado(usuario, cli["cliente_id"], matricula)
        if not self.tiene_modulo("rotacion"):   # 4.5: licencia «solo abonados»
            raise ErrorNegocio("Licencia «Abonados»: solo pueden entrar abonados con el bono vigente "
                               "(por su matrícula o su tarjeta)." + (f" La matrícula {matricula} no es de ningún abonado al día." if matricula else ""), 402)
        capacidad = self.cfg("capacidad", int) or 0
        tipo_vehiculo = (str(tipo_vehiculo or "").strip()[:30] or None)
        zonas = self.zonas()
        zona_pedida = zona_id
        if zonas and not zona_id:
            zona_id = zonas[0]["id"]
        # 4.3: reserva hecha en una plataforma (Parclick, hotel…) para esta matrícula
        prevista = None
        if matricula and not reserva:
            prevista = self.reserva_para(matricula)
            if prevista and prevista.get("origen") in ("mostrador", "web"):
                # 1.8: reserva online = plaza garantizada; se cobra con la tarifa normal (no es una tarifa de reserva/hotel).
                # 1.11: se enlaza con cualquier tarifa elegida (antes solo si la entrada era «automática»)
                if prevista.get("zona_id"):   # la plaza está garantizada en la zona reservada
                    zona_id = prevista["zona_id"]
                tipo_vehiculo = tipo_vehiculo or prevista.get("tipo_vehiculo")
            elif prevista and (not tarifa_id or self.tarifa(int(tarifa_id)).get("modo") == "reserva"):
                tr = self.db.q1("SELECT id FROM tarifas WHERE id=? AND activa=1 AND modo='reserva'", (prevista["tarifa_id"],)) \
                    if prevista["tarifa_id"] else None
                tarifa_id = (tr and tr["id"]) or self._tarifa_reserva_defecto() or tarifa_id
                if tarifa_id and self.tarifa(int(tarifa_id)).get("modo") == "reserva":
                    reserva = {"hasta": prevista["hasta"],
                               "ref": " ".join(x for x in (prevista["plataforma"], prevista["ref"]) if x) or None}
                else:
                    prevista = None
            else:
                prevista = None
        with self.db.transaccion() as c:
            if capacidad:
                ocupadas = c.execute("SELECT COUNT(*) FROM tickets WHERE estado IN ('dentro','pagado')").fetchone()[0]
                if ocupadas >= capacidad:
                    raise ErrorNegocio("Parking COMPLETO", 409)
            self._comprobar_plazas(c, zona_id)   # 4.3: zonas y plazas reservadas para abonados
            if matricula and c.execute("SELECT 1 FROM tickets WHERE matricula=? AND estado IN ('dentro','pagado')",
                                       (matricula,)).fetchone():
                raise ErrorNegocio(f"La matrícula {matricula} ya figura dentro del parking", 409)
            entrada = iso(self.ahora() + timedelta(minutes=ajuste))
            if tarifa_id:
                tar = c.execute("SELECT id FROM tarifas WHERE id=? AND activa=1", (tarifa_id,)).fetchone()
            else:   # 3.9: la que toca por horario (nocturna, fin de semana…) o la de por defecto (4.3: y tipo de vehículo)
                auto = self.tarifa_para(parse(entrada), tipo_vehiculo)
                tar = (auto["id"],) if auto else None
            if not tar:
                raise ErrorNegocio("No hay tarifa activa disponible")
            res = self._datos_reserva(self.tarifa(tar[0]), parse(entrada), reserva)   # 4.2: reserva / hotel
            tid = c.execute("INSERT INTO tickets(codigo, matricula, entrada, tarifa_id, turno_entrada_id, "
                            "usuario_entrada_id, ajuste_min, reserva_hasta, reserva_ref, reserva_tarifa_id, reserva_desde) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                            ("tmp-" + secrets.token_hex(8), matricula, entrada, tar[0], t["id"], usuario["id"],
                             ajuste, res["hasta"], res["ref"], res["tarifa_id"], res["desde"])).lastrowid
            c.execute("UPDATE tickets SET tipo_vehiculo=?, zona_id=?, reserva_prevista_id=?, llaves=? WHERE id=?",
                      (tipo_vehiculo, zona_id, prevista["id"] if prevista else None, 1 if llaves else 0, tid))
            if prevista:
                c.execute("UPDATE reservas_previstas SET estado='usada', ticket_id=? WHERE id=?", (tid, prevista["id"]))
                self.aplicar_senal_a_ticket(c, prevista["id"])   # 1.18: la señal pagada se descuenta sola al salir
            codigo = self._asignar_codigo_ticket(c, tid)
            self.auditar(c, usuario["id"], "ticket_emitir", f"{codigo} {matricula or ''}"
                         + (f" hora ajustada {ajuste:+d} min" if ajuste else "")
                         + (f" reserva hasta {res['hasta'][:16]} {res['ref'] or ''}" if res["hasta"] else "")
                         + (" (reserva de plataforma)" if prevista else ""))
        tk = self.ticket(tid)
        if prevista:
            tk["reserva_prevista"] = prevista
        if digital and digital.get("telefono"):   # 4.3: ticket por SMS / WhatsApp en lugar de papel
            tk["digital"] = self.enviar_ticket_digital(usuario, tk, digital["telefono"], digital.get("canal") or "sms")
            if digital.get("imprimir"):
                tk["impresion"] = self._imprimir(self._doc_entrada(tk), "entrada", copias=1)
        else:
            tk["impresion"] = self._imprimir(self._doc_entrada(tk), "entrada", copias=self._copias_entrada())
        tk["barrera"] = self.abrir_barrera("entrada", usuario)
        return tk

    def ticket(self, tid):
        tk = self.db.q1("SELECT t.*, tr.nombre tarifa_nombre, c.nombre cliente_nombre, ue.nombre usuario_entrada_nombre "
                        "FROM tickets t JOIN tarifas tr ON tr.id=t.tarifa_id LEFT JOIN clientes c ON c.id=t.cliente_id "
                        "LEFT JOIN usuarios ue ON ue.id=t.usuario_entrada_id WHERE t.id=?", (tid,))
        if not tk:
            raise ErrorNegocio("Ticket no encontrado", 404)
        tk["pagos"] = self.db.q("SELECT id, fecha, importe_cent, extras_cent, metodo, serie, numero FROM pagos "
                                "WHERE ticket_id=? ORDER BY id", (tid,))
        if tk.get("reserva_prevista_id"):   # 1.11: el vehículo entró con una reserva (se avisa en Salida y en Vehículos)
            tk["reserva_info"] = self.db.q1("SELECT r.codigo, r.ref, r.plataforma, r.origen, r.desde, r.hasta, r.plazas, r.pago, r.senal_cent, r.senal_pago_id, z.nombre zona_nombre "
                                            "FROM reservas_previstas r LEFT JOIN zonas z ON z.id=r.zona_id WHERE r.id=?",
                                            (tk["reserva_prevista_id"],))
        elif tk.get("matricula") and tk.get("estado") in ("dentro", "pagado") and not tk.get("cliente_id"):
            av = self.aviso_reserva(tk["matricula"])   # tiene una reserva pendiente que no se enlazó al entrar (p. ej. llegó antes de hora)
            if av.get("reserva"):
                tk["reserva_pendiente"] = {k: av["reserva"].get(k) for k in ("id", "codigo", "ref", "plataforma", "origen", "desde", "hasta", "zona_nombre")}
                tk["reserva_pendiente"]["motivo"] = av["motivo"]
        tk["extras"] = self.db.q("SELECT id, producto_id, nombre, tipo, precio_cent, cantidad, iva_pct, pago_id, fecha, "
                                 "minutos_incluidos, descripcion FROM ticket_extras WHERE ticket_id=? ORDER BY id", (tid,))
        return tk

    # ------------------------------------------------------------------ 4.2 · reservas / hotel
    def _tarifa_tras_reserva(self, t):
        """La tarifa del parking que se cobra al acabar la reserva: la indicada (su versión vigente) o la de por defecto."""
        if t.get("tarifa_despues_id"):
            r = self.db.q1("SELECT * FROM tarifas WHERE id=?", (t["tarifa_despues_id"],))
            if r and not r["activa"]:   # se editó y es una versión antigua: la vigente con el mismo nombre
                r = self.db.q1("SELECT * FROM tarifas WHERE activa=1 AND eliminada=0 AND nombre=? AND COALESCE(modo,'tramos')<>'reserva'",
                               (r["nombre"],)) or None
            if r and (r.get("modo") or "tramos") != "reserva":
                return r["id"]
        d = self.db.q1("SELECT id FROM tarifas WHERE por_defecto=1 AND activa=1")
        return d and d["id"]

    def _datos_reserva(self, t, entrada, datos=None):
        """Fin de la reserva y tarifa de después para un ticket con tarifa de reserva. datos (opcional): noches, horas,
        desde y hasta (fechas reservadas) y ref (nº de reserva, habitación…). 4.43: en la reserva por fecha, el tiempo entre
        «desde» y «hasta» no se cobra; antes y después se cobra con la tarifa de después."""
        if (t.get("modo") or "tramos") != "reserva":
            return {"desde": None, "hasta": None, "ref": None, "tarifa_id": None}
        datos = datos or {}

        def fecha(v):
            f = datetime.fromisoformat(str(v))
            return f.replace(tzinfo=entrada.tzinfo) if f.tzinfo is None else f
        desde = None
        try:
            if t["reserva_modo"] == "fecha" and not datos.get("hasta") and datos.get("horas") in (None, "") and datos.get("noches") in (None, ""):
                raise ErrorNegocio("Indique la fecha de salida de la reserva")
            if datos.get("hasta"):
                fin = fecha(datos["hasta"])
            elif datos.get("horas") not in (None, ""):
                fin = entrada + timedelta(minutes=int(round(float(datos["horas"]) * 60)))
            else:
                noches = int(datos.get("noches") or t["reserva_noches"] or 1)
                h, m = (int(x) for x in (t["reserva_hora"] or "12:00").split(":"))
                fin = (entrada + timedelta(days=noches)).replace(hour=h, minute=m, second=0, microsecond=0)
            if datos.get("desde"):
                desde = fecha(datos["desde"])
                if desde <= entrada:
                    desde = None   # la reserva ya había empezado: cuenta desde la entrada
        except (ValueError, TypeError):
            raise ErrorNegocio("Datos de la reserva no válidos")
        if fin <= entrada or fin > max(entrada, desde or entrada) + timedelta(days=90):
            raise ErrorNegocio("El fin de la reserva debe ser posterior a la entrada (y como mucho 90 días)")
        if desde and fin <= desde:
            raise ErrorNegocio("La fecha de salida de la reserva debe ser posterior a la de entrada")
        despues = self._tarifa_tras_reserva(t)
        if not despues:
            raise ErrorNegocio("No hay tarifa del parking para cobrar después de la reserva")
        return {"desde": iso(desde) if desde else None, "hasta": iso(fin), "ref": (str(datos.get("ref") or "").strip()[:60] or None), "tarifa_id": despues}

    def aplicar_reserva(self, usuario, ticket_id, datos):
        """Pasar a reserva un ticket que ya está dentro (o quitársela). datos: tarifa_id (de reserva), noches/horas/hasta, ref
        o {"quitar": true}."""
        tk = self.ticket(int(ticket_id))
        if tk["estado"] != "dentro" or tk["pagos"]:
            raise ErrorNegocio("Solo se puede cambiar la reserva de un vehículo que está dentro y no ha pagado", 409)
        if tk.get("cliente_id"):
            raise ErrorNegocio("Es un abonado: no necesita reserva", 409)
        with self.db.transaccion() as c:
            if datos.get("quitar"):
                if not tk.get("reserva_hasta"):
                    raise ErrorNegocio("El ticket no tiene reserva")
                c.execute("UPDATE tickets SET tarifa_id=?, reserva_hasta=NULL, reserva_ref=NULL, reserva_tarifa_id=NULL, reserva_desde=NULL WHERE id=?",
                          (tk["reserva_tarifa_id"] or self._tarifa_tras_reserva({}), tk["id"]))
                self.auditar(c, usuario["id"], "ticket_reserva_quitar", tk["codigo"])
            else:
                t = self.tarifa(int(datos.get("tarifa_id") or 0)) if datos.get("tarifa_id") else None
                if not t or t.get("modo") != "reserva" or not t["activa"]:
                    raise ErrorNegocio("Elija una tarifa de reserva")
                res = self._datos_reserva(t, parse(tk["entrada"]), datos)
                c.execute("UPDATE tickets SET tarifa_id=?, reserva_hasta=?, reserva_ref=?, reserva_tarifa_id=?, reserva_desde=? WHERE id=?",
                          (t["id"], res["hasta"], res["ref"], res["tarifa_id"], res["desde"], tk["id"]))
                self.auditar(c, usuario["id"], "ticket_reserva", f"{tk['codigo']} {t['nombre']} hasta {res['hasta'][:16]} {res['ref'] or ''}")
        return self.consultar(ticket_id=tk["id"])

    def _liquidar(self, tk, momento, perdido=False):
        """Calcula lo que debe un ticket en 'momento'. No escribe nada."""
        tarifa = self.tarifa(tk["tarifa_id"])
        entrada = parse(tk["entrada"])
        abonado = None
        reserva = None
        if tk.get("reserva_hasta") and not tk.get("cliente_id"):
            # 4.2: el tiempo reservado (pagado en el hotel o en la web de reservas) no se cobra; después, la tarifa del parking
            fin = parse(tk["reserva_hasta"])
            ini = max(entrada, parse(tk["reserva_desde"])) if tk.get("reserva_desde") else entrada   # 4.43: reserva por fecha
            antes = minutos_estancia(entrada, min(ini, momento)) if ini > entrada and momento > entrada else 0   # llegó antes de la reserva
            despues = self.tarifa(tk.get("reserva_tarifa_id") or self._tarifa_tras_reserva(tarifa))
            reserva = {"desde": tk.get("reserva_desde"), "hasta": tk["reserva_hasta"], "ref": tk.get("reserva_ref"), "tarifa_despues": despues["nombre"],
                       "tarifa_reserva": tarifa["nombre"], "vigente": momento <= fin, "minutos_antes": antes,
                       "minutos_reserva": minutos_estancia(ini, min(fin, momento)) if momento > ini else 0}
            tarifa = despues
            if momento <= fin and not antes:
                ext = self._extras_pendientes(tk)
                pagado = sum(p["importe_cent"] - (p.get("extras_cent") or 0) for p in tk["pagos"])
                return {"minutos": minutos_estancia(entrada, momento), "minutos_incluidos": 0, "minutos_cobrables": 0,
                        "importe_estancia_cent": 0, "recargo_cent": 0, "pagado_cent": pagado, "pendiente_estancia_cent": 0,
                        "extras_pendientes_cent": ext, "pendiente_cent": ext, "perdido": bool(perdido or tk["perdido"]),
                        "dentro_de_plazo": False, "abonado": None, "reserva": reserva}
        if tk.get("cliente_id"):
            # Abonado: no paga mientras tenga bono vigente. Si se le caducó estando dentro,
            # paga solo el tiempo posterior al fin de su último bono.
            vig = self.bono_vigente(tk["cliente_id"], momento.date())
            if vig:
                minutos = minutos_estancia(entrada, momento)
                ext = self._extras_pendientes(tk)
                return {"minutos": minutos, "importe_estancia_cent": 0, "recargo_cent": 0, "pagado_cent": 0,
                        "pendiente_estancia_cent": 0, "extras_pendientes_cent": ext,
                        "pendiente_cent": ext, "perdido": False, "dentro_de_plazo": False,
                        "abonado": {"vigente": True, "hasta": vig["hasta"]}}
            ult = self.db.q1("SELECT hasta FROM bonos WHERE cliente_id=? AND estado='activo' AND pagado=1 "
                             "ORDER BY hasta DESC LIMIT 1", (tk["cliente_id"],))
            if ult:
                fin = datetime.fromisoformat(ult["hasta"] + "T23:59:59").replace(tzinfo=momento.tzinfo) \
                    + timedelta(seconds=1)
                entrada = max(entrada, fin)
            abonado = {"vigente": False, "hasta": ult["hasta"] if ult else None}
        minutos = minutos_estancia(entrada, momento)
        # Servicios que incluyen tiempo de parking (p. ej. "lavado + 60 min"): ese tiempo no se cobra
        incluidos = sum((e.get("minutos_incluidos") or 0) * e["cantidad"] for e in tk.get("extras", []))
        cobrables = max(0, minutos - incluidos)
        estancia = None
        if reserva:   # se cobra desde el fin de la reserva (y, en la reserva por fecha, el tiempo anterior a su inicio)
            fin_r = parse(reserva["hasta"])
            tras = minutos_estancia(fin_r, momento) if momento > fin_r else 0
            tras_c = max(0, tras - incluidos)
            antes_c = max(0, reserva["minutos_antes"] - max(0, incluidos - tras))
            cobrables = antes_c + tras_c
            estancia = (calcular_importe(antes_c, tarifa, tarifa["tramos"]) if antes_c else 0) \
                + (calcular_importe(tras_c, tarifa, tarifa["tramos"]) if tras_c else 0)
        if estancia is None:
            estancia = calcular_importe(cobrables, tarifa, tarifa["tramos"])
        if perdido and not tk["perdido"] and self.cfg("ticket_perdido_activo") == "0":
            raise ErrorNegocio("El cobro como ticket perdido está desactivado (Ajustes → Empresa y cobro)")
        es_perdido = bool(perdido or tk["perdido"])
        recargo = (self.cfg("recargo_perdido_cent", int) or 0) if es_perdido else 0
        # Lo pagado por estancia (sin los servicios/productos, que se liquidan aparte)
        pagado = sum(p["importe_cent"] - (p.get("extras_cent") or 0) for p in tk["pagos"])
        dentro_de_plazo = (tk["estado"] == "pagado" and tk["salida_limite"]
                           and momento <= parse(tk["salida_limite"]))
        pend_estancia = 0 if dentro_de_plazo else max(0, estancia + recargo - pagado)
        ext = self._extras_pendientes(tk)
        a_favor = max(0, pagado - estancia - recargo) if pagado and not dentro_de_plazo else 0   # 1.18: señal mayor que la estancia
        return {"minutos": minutos, "a_favor_cent": a_favor, "minutos_incluidos": min(incluidos, minutos), "minutos_cobrables": cobrables,
                "importe_estancia_cent": estancia, "recargo_cent": recargo,
                "pagado_cent": pagado, "pendiente_estancia_cent": pend_estancia, "extras_pendientes_cent": ext,
                "pendiente_cent": pend_estancia + ext, "perdido": es_perdido,
                "dentro_de_plazo": bool(dentro_de_plazo), "abonado": abonado, "reserva": reserva}

    @staticmethod
    def _extras_pendientes(tk):
        return sum(e["precio_cent"] * e["cantidad"] for e in tk.get("extras", []) if not e["pago_id"])

    def consultar(self, codigo=None, ticket_id=None, perdido=False):
        if not ticket_id:
            pre, num = self._leer_codigo(codigo)
            if pre == "CL":
                self.exigir_modulo("abonados")
                return self.consultar_abonado(num)
        tid = ticket_id or self._id_desde_codigo(codigo)
        tk = self.ticket(int(tid))
        if tk["estado"] == "anulado":
            raise ErrorNegocio(f"Ticket ANULADO: {tk['anulado_motivo'] or ''}", 409)
        momento = self.ahora()
        tk["calculo_en"] = iso(momento)
        if tk["estado"] == "salido":
            tk["liquidacion"] = None
            tk["mensaje"] = "Este vehículo ya salió"
            return tk
        tk["tipo"] = "ticket"
        if tk.get("matricula"):   # 4.1: aviso si la matrícula está en la lista negra
            tk["lista_negra"] = self.en_lista_negra(tk["matricula"])
            tk["nota_vehiculo"] = self.nota_vehiculo(tk["matricula"])   # 4.50: comentario interno
        if tk.get("matricula"):   # 3.5: foto del vehículo si la matrícula es de un cliente
            f = self.db.q1("SELECT f.cliente_id, f.actualizado FROM vehiculo_fotos f JOIN cliente_matriculas m "
                           "ON m.cliente_id=f.cliente_id AND m.matricula=f.matricula WHERE f.matricula=?", (tk["matricula"],))
            if f:
                tk["foto_vehiculo"], tk["foto_cliente_id"] = f["actualizado"], f["cliente_id"]
        tk["liquidacion"] = self._liquidar(tk, momento, perdido)
        liq = tk["liquidacion"]
        liq["descuentos"] = self.opciones_descuento_ticket(tk, liq, momento, perdido)
        if liq.get("abonado"):
            ab = liq["abonado"]
            tk["mensaje"] = (f"Abonado {tk['cliente_nombre']}: bono válido hasta {fecha_es(ab['hasta'])}. "
                             "Puede salir sin pagar." if ab["vigente"] else
                             f"Abonado {tk['cliente_nombre']}: bono CADUCADO"
                             + (f" el {fecha_es(ab['hasta'])}" if ab["hasta"] else "")
                             + ". Paga el tiempo desde entonces o renueve el bono.")
        elif liq["pendiente_cent"] == 0 and tk["estado"] == "pagado":
            tk["mensaje"] = "Pagado. Puede salir hasta las " + parse(tk["salida_limite"]).strftime("%H:%M")
        elif liq["dentro_de_plazo"]:
            tk["mensaje"] = "Estancia pagada. Quedan servicios o productos por cobrar."
        elif tk["estado"] == "pagado":
            tk["mensaje"] = "Superado el tiempo de salida: debe abonar la diferencia"
        return tk

    def cobrar(self, usuario, ticket_id, metodo, entregado_cent=None, perdido=False, calculo_en=None, descuento_id=None, imprimir=None):
        """Cobra lo pendiente. 'calculo_en' es la hora de la consulta que vio el cliente:
        se respeta si tiene menos de 3 min, para que el importe cobrado sea el mostrado."""
        turno = self._exigir_turno(usuario)
        self._exigir_abierto(usuario)   # 1.9: la salida no se da fuera de horario
        if metodo not in ("efectivo", "tarjeta"):
            raise ErrorNegocio("Forma de pago no válida")
        momento = self.ahora()
        if calculo_en:
            c_en = parse(calculo_en)
            if timedelta(0) <= momento - c_en <= timedelta(minutes=3):
                momento = c_en
        with self.db.transaccion() as c:
            tk = self.ticket(int(ticket_id))
            if tk["estado"] in ("anulado", "salido"):
                raise ErrorNegocio(f"No se puede cobrar un ticket en estado '{tk['estado']}'", 409)
            liq = self._liquidar(tk, momento, perdido)
            if liq["dentro_de_plazo"] and not liq["extras_pendientes_cent"]:
                raise ErrorNegocio("Este ticket ya está pagado y dentro del tiempo de salida", 409)
            importe = liq["pendiente_cent"]
            desc = self.descuento_cliente(tk) if descuento_id == "cliente" else self._descuento_para(descuento_id, "estancia")
            if descuento_id == "cliente" and not desc:
                raise ErrorNegocio("El cliente ya no tiene descuento fijo", 409)
            desc_cent = self._importe_descuento_estancia(desc, tk, liq, momento, perdido) if desc else 0
            importe -= desc_cent
            minutos_salida = self.cfg("minutos_salida", int) or 15
            # Pagar solo servicios dentro del plazo no alarga el tiempo para salir
            limite = tk["salida_limite"] if liq["dentro_de_plazo"] else iso(self.ahora() + timedelta(minutes=minutos_salida))
            pago = None
            if importe > 0:
                entregado, cambio = self._entregado_y_cambio(metodo, importe, entregado_cent)
                recargo_nuevo = liq["recargo_cent"] if (liq["perdido"] and not tk["perdido"]) else 0
                pendientes = [e for e in tk["extras"] if not e["pago_id"]]
                iva_gen = float(self.cfg("iva_pct") or 21)
                lineas = [(liq["pendiente_estancia_cent"] - desc_cent, iva_gen)] + \
                    [(e["precio_cent"] * e["cantidad"], e["iva_pct"]) for e in pendientes]
                pago = self._insertar_pago(c, turno, usuario, importe, metodo, entregado, cambio,
                                           ticket_id=tk["id"], minutos=liq["minutos"], recargo=recargo_nuevo,
                                           extras=liq["extras_pendientes_cent"], lineas=lineas,
                                           descuento=(desc, desc_cent) if desc_cent else None)
                if pendientes:
                    c.execute("UPDATE ticket_extras SET pago_id=? WHERE ticket_id=? AND pago_id IS NULL",
                              (pago["id"], tk["id"]))
                pago["lineas_extra"] = pendientes
                pago["minutos_incluidos"] = liq.get("minutos_incluidos", 0)
            # Por defecto, cobrar = dar salida al vehículo (libera la plaza en el momento).
            # Con 'salida_al_cobrar' = 0 se vuelve al modo «paga y tiene X minutos para salir».
            salida = None
            if desc and desc.get("_vale") and desc_cent:
                self._usar_vale(c, desc["_vale"])
                if pago:
                    c.execute("UPDATE pagos SET vale_id=? WHERE id=?", (desc["_vale"]["id"], pago["id"]))
            if self.cfg("salida_al_cobrar") != "0":
                salida, limite = iso(self.ahora()), None
                c.execute("UPDATE tickets SET estado='salido', salida=?, salida_limite=NULL, perdido=? WHERE id=?",
                          (salida, 1 if liq["perdido"] else 0, tk["id"]))
            else:
                c.execute("UPDATE tickets SET estado='pagado', salida_limite=?, perdido=? WHERE id=?",
                          (limite, 1 if liq["perdido"] else 0, tk["id"]))
            self.auditar(c, usuario["id"], "cobro",
                         f"{tk['codigo']} {importe} {metodo}" + (" PERDIDO" if liq["perdido"] else "")
                         + (f" DESCUENTO {desc['nombre']} -{desc_cent}" if desc_cent else "")
                         + (" +SALIDA" if salida else ""))
        res = {"ticket": self.ticket(tk["id"]), "pago": pago, "salida_limite": limite, "salida": salida}
        if salida:
            res["barrera"] = self.abrir_barrera("salida", usuario)
        if pago:
            res["impresion"] = self._imprimir_salida(self._doc_recibo(res["ticket"], pago, limite), "recibo", metodo == "efectivo", imprimir)
        return res

    def imprimir_salida_activo(self):
        """4.28: ¿se imprime el ticket (recibo) de salida al cobrar? (Ajustes → Tickets, o la casilla de la pantalla de cobro)."""
        return self.cfg("ticket_salida_imprimir") == "1"

    def guardar_imprimir_salida(self, usuario, activo):
        with self.db.transaccion() as c:
            c.execute("INSERT OR REPLACE INTO config(clave, valor) VALUES('ticket_salida_imprimir', ?)", ("1" if activo else "0",))
            self.auditar(c, usuario["id"], "ticket_salida_imprimir", "activado" if activo else "desactivado")
        return {"activo": bool(activo)}

    def _imprimir_salida(self, doc, nombre, efectivo, imprimir=None):
        """Imprime el ticket de salida, o no si está desactivado. Aunque no se imprima, en efectivo el cajón se abre
        y el recibo se puede ver en pantalla («Ver recibo»)."""
        activo = self.imprimir_salida_activo() if imprimir is None else bool(imprimir)
        if activo:
            return self._imprimir(doc, nombre, cajon=efectivo)
        res = {"ok": True, "omitida": True, "destino": None, "vista_previa": doc.texto(), "elementos": doc.elementos, "ancho": doc.ancho, "copias": 0}
        if efectivo:
            abrir = self._enviar(impresion.Ticket(self.cfg("impresora_ancho", int)).abrir_cajon(self.cfg("cajon_pin", int)), "cajon")
            res["ok"] = abrir.get("ok", True)
            if abrir.get("error"):
                res["error"] = abrir["error"]
        return res

    def _insertar_pago(self, c, turno, usuario, importe, metodo, entregado, cambio,
                       ticket_id=None, bono_id=None, minutos=0, recargo=0, extras=0, lineas=None, online_ref=None,
                       concepto=None, referencia=None, descuento=None, serie=None):
        """Inserta un cobro (= factura simplificada numerada) y su registro encadenado.
        descuento: (fila del descuento, céntimos descontados) o None; importe ya va descontado."""
        serie = serie or self.cfg("serie_factura") or "A"
        propia = serie == (self.cfg("serie_proveedor") or "P") and serie != (self.cfg("serie_factura") or "A")
        numero = max((c.execute("SELECT MAX(numero) FROM pagos WHERE serie=?", (serie,)).fetchone()[0] or 0) + 1,
                     int(self.cfg("factura_proveedor_numero_inicial" if propia else "factura_numero_inicial") or 1))
        fecha = iso(self.ahora())
        concepto = concepto or ("bono" if bono_id else "estancia")
        pid = c.execute("INSERT INTO pagos(ticket_id, bono_id, concepto, turno_id, usuario_id, fecha, minutos, "
                        "importe_cent, recargo_cent, extras_cent, metodo, entregado_cent, cambio_cent, serie, numero, "
                        "online_ref, referencia) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (ticket_id, bono_id, concepto, turno["id"] if turno else None, usuario["id"] if usuario else None,
                         fecha, minutos, importe, recargo, extras, metodo, entregado, cambio, serie, numero,
                         online_ref, referencia)).lastrowid
        if metodo in ("efectivo", "tarjeta"):   # 4.64: lo cobrado en el momento nace «cobrada»; el resto, «generada»
            c.execute("UPDATE pagos SET estado_factura='cobrada' WHERE id=?", (pid,))
        d_fila, d_cent = descuento if descuento else (None, 0)
        if d_cent:
            c.execute("UPDATE pagos SET descuento_cent=?, descuento_id=?, descuento_nombre=? WHERE id=?",
                      (d_cent, d_fila["id"], d_fila["nombre"], pid))
        iva_gen = float(self.cfg("iva_pct") or 21)
        desglose = desglose_iva(lineas or [(importe, iva_gen)])
        self._registro_factura(c, pid, serie, numero, fecha, importe, desglose)
        if self.activo("verifactu_activo", "verifactu"):
            self._registro_verifactu(c, pid, serie, numero, fecha, importe, desglose)
        return {"id": pid, "importe_cent": importe, "metodo": metodo, "entregado_cent": entregado,
                "cambio_cent": cambio, "serie": serie, "numero": numero, "fecha": fecha,
                "minutos": minutos, "recargo_cent": recargo, "extras_cent": extras, "concepto": concepto,
                "bono_id": bono_id, "ticket_id": ticket_id, "referencia": referencia,
                "desglose_iva": desglose, "lineas_extra": [],
                "descuento_cent": d_cent, "descuento_nombre": d_fila["nombre"] if d_fila else None}

    def _metodo_bono(self, metodo, referencia=None):
        """Formas de pago de un bono en caja: efectivo, tarjeta o transferencia bancaria (registrada a mano)."""
        if metodo == "transferencia":
            if self.cfg("transferencia_activa") == "0":
                raise ErrorNegocio("El pago por transferencia está desactivado (Ajustes → Empresa y cobro)")
            ref = (referencia or "").strip()[:60]
            return ref or None
        if metodo not in ("efectivo", "tarjeta"):
            raise ErrorNegocio("Forma de pago no válida")
        return None

    def _entregado_y_cambio(self, metodo, importe, entregado_cent):
        if metodo != "efectivo":
            return None, None
        if entregado_cent in (None, "") and importe > 0 and self.cfg("efectivo_exigir_entregado") != "0":
            raise ErrorNegocio("Indique la cantidad recibida en efectivo")
        entregado = int(entregado_cent) if entregado_cent not in (None, "") else importe
        if entregado < importe:
            raise ErrorNegocio(f"Entregado insuficiente: faltan {eur(importe - entregado)}")
        return entregado, entregado - importe

    def _registro_factura(self, c, pago_id, serie, numero, fecha, total, desglose=None):
        if self.cfg("registro_integridad") == "0":
            return   # desactivado en Ajustes → General (necesario para VERI*FACTU cuando sea obligatorio)
        if desglose:
            base = sum(d["base"] for d in desglose)
        else:
            iva = float(self.cfg("iva_pct") or 21)
            base = round(total / (1 + iva / 100))
        cuota = total - base
        nif = self.cfg("nif") or ""
        ant = c.execute("SELECT hash FROM registros_facturacion ORDER BY id DESC LIMIT 1").fetchone()
        hash_ant = ant[0] if ant else "0" * 64
        cadena = f"{nif}|{serie}|{numero}|{fecha}|{base}|{cuota}|{total}|{hash_ant}"
        h = hashlib.sha256(cadena.encode()).hexdigest()
        c.execute("INSERT INTO registros_facturacion(pago_id, serie, numero, fecha, nif_emisor, base_cent, "
                  "cuota_iva_cent, total_cent, hash_anterior, hash) VALUES(?,?,?,?,?,?,?,?,?,?)",
                  (pago_id, serie, numero, fecha, nif, base, cuota, total, hash_ant, h))

    def verificar_cadena(self):
        """Recalcula toda la cadena de registros. Devuelve (ok, n, primer_error)."""
        ant = "0" * 64
        regs = self.db.q("SELECT * FROM registros_facturacion ORDER BY id")
        for r in regs:
            cadena = (f"{r['nif_emisor']}|{r['serie']}|{r['numero']}|{r['fecha']}|{r['base_cent']}|"
                      f"{r['cuota_iva_cent']}|{r['total_cent']}|{ant}")
            if r["hash_anterior"] != ant or hashlib.sha256(cadena.encode()).hexdigest() != r["hash"]:
                return {"ok": False, "registros": len(regs), "error_en": f"{r['serie']}-{r['numero']}"}
            ant = r["hash"]
        return {"ok": True, "registros": len(regs), "error_en": None}

    def registrar_salida(self, usuario, ticket_id):
        self._exigir_abierto(usuario)   # 1.9
        tk = self.consultar(ticket_id=ticket_id)
        if tk["estado"] == "salido":
            raise ErrorNegocio("El vehículo ya había salido", 409)
        if tk["liquidacion"]["pendiente_cent"] > 0:
            raise ErrorNegocio(f"Tiene pendiente {eur(tk['liquidacion']['pendiente_cent'])}", 409)
        with self.db.transaccion() as c:
            c.execute("UPDATE tickets SET estado='salido', salida=? WHERE id=?", (iso(self.ahora()), tk["id"]))
            self.auditar(c, usuario["id"], "salida", tk["codigo"])
        res = self.ticket(tk["id"])
        res["barrera"] = self.abrir_barrera("salida", usuario)
        return res

    def anular_ticket(self, usuario, ticket_id, motivo):
        if not self.puede(usuario, "anular_tickets"):
            raise ErrorNegocio("Solo un supervisor puede anular tickets", 403)
        motivo = (motivo or "").strip() or "sin motivo"   # 4.38: el motivo es opcional
        with self.db.transaccion() as c:
            tk = self.ticket(int(ticket_id))
            if tk["pagos"]:
                raise ErrorNegocio("No se puede anular un ticket con cobros registrados", 409)
            if tk["estado"] != "dentro":
                raise ErrorNegocio(f"No se puede anular un ticket en estado '{tk['estado']}'", 409)
            c.execute("UPDATE tickets SET estado='anulado', anulado_motivo=?, salida=? WHERE id=?",
                      (motivo, iso(self.ahora()), tk["id"]))
            self.auditar(c, usuario["id"], "ticket_anular", f"{tk['codigo']} {motivo}")
        return self.ticket(tk["id"])

    def anadir_extra(self, usuario, ticket_id, producto_id, cantidad=1, precio_cent=None):
        cantidad = 1 if cantidad in (None, "") else int(cantidad)
        if not 1 <= cantidad <= 99:
            raise ErrorNegocio("Cantidad no válida")
        prod = self.db.q1("SELECT * FROM productos WHERE id=? AND activo=1 AND eliminado=0", (producto_id,))
        if not prod:
            raise ErrorNegocio("Servicio o producto no disponible", 404)
        iva = prod["iva_pct"] if prod["iva_pct"] is not None else float(self.cfg("iva_pct") or 21)
        precio = self._precio_de_producto(prod, precio_cent)
        with self.db.transaccion() as c:
            tk = c.execute("SELECT estado, codigo FROM tickets WHERE id=?", (ticket_id,)).fetchone()
            if not tk:
                raise ErrorNegocio("Ticket no encontrado", 404)
            if tk[0] not in ("dentro", "pagado"):
                raise ErrorNegocio(f"No se pueden añadir servicios a un ticket {tk[0]}", 409)
            # misma línea pendiente con el mismo precio -> se suma la cantidad
            linea = c.execute("SELECT id, cantidad FROM ticket_extras WHERE ticket_id=? AND producto_id=? "
                              "AND pago_id IS NULL AND precio_cent=? AND iva_pct=? AND minutos_incluidos=? "
                              "AND COALESCE(descripcion,'')=?",
                              (ticket_id, producto_id, precio, iva, prod["minutos_incluidos"] or 0,
                               prod["descripcion"] or "")).fetchone()
            if linea:
                if linea[1] + cantidad > 99:
                    raise ErrorNegocio("Cantidad no válida")
                c.execute("UPDATE ticket_extras SET cantidad=? WHERE id=?", (linea[1] + cantidad, linea[0]))
            else:
                c.execute("INSERT INTO ticket_extras(ticket_id, producto_id, nombre, tipo, precio_cent, cantidad, "
                          "iva_pct, fecha, usuario_id, minutos_incluidos, descripcion) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                          (ticket_id, producto_id, prod["nombre"], prod["tipo"], precio, cantidad, iva,
                           iso(self.ahora()), usuario["id"], prod["minutos_incluidos"] or 0, prod["descripcion"]))
            self.auditar(c, usuario["id"], "extra_anadir", f"{tk[1]} {cantidad} x {prod['nombre']}")
        return self.consultar(ticket_id=ticket_id)

    def anadir_extra_personalizado(self, usuario, ticket_id, datos, cantidad=1):
        """4.31: servicio libre (descripción + precio) solo para la venta en curso: no entra en el catálogo."""
        cantidad = 1 if cantidad in (None, "") else int(cantidad)
        if not 1 <= cantidad <= 99:
            raise ErrorNegocio("Cantidad no válida")
        nombre = (datos.get("nombre") or "").strip()[:80]
        if not nombre:
            raise ErrorNegocio("Escriba la descripción del servicio")
        try:
            precio = int(datos.get("precio_cent"))
        except (TypeError, ValueError):
            raise ErrorNegocio("Precio no válido")
        if not 0 <= precio <= 10_000_000:
            raise ErrorNegocio("Precio no válido")
        iva = datos.get("iva_pct")
        iva = float(self.cfg("iva_pct") or 21) if iva in (None, "") else float(iva)
        if not 0 <= iva <= 30:
            raise ErrorNegocio("IVA no válido")
        with self.db.transaccion() as c:
            tk = c.execute("SELECT estado, codigo FROM tickets WHERE id=?", (ticket_id,)).fetchone()
            if not tk:
                raise ErrorNegocio("Ticket no encontrado", 404)
            if tk[0] not in ("dentro", "pagado"):
                raise ErrorNegocio(f"No se pueden añadir servicios a un ticket {tk[0]}", 409)
            c.execute("INSERT INTO ticket_extras(ticket_id, producto_id, nombre, tipo, precio_cent, cantidad, iva_pct, fecha, "
                      "usuario_id, minutos_incluidos, descripcion) VALUES(?,?,?,?,?,?,?,?,?,0,NULL)",
                      (ticket_id, None, nombre, "servicio", precio, cantidad, iva, iso(self.ahora()), usuario["id"]))
            self.auditar(c, usuario["id"], "extra_anadir", f"{tk[1]} {cantidad} x {nombre} (personalizado)")
        return self.consultar(ticket_id=ticket_id)

    def cambiar_extra(self, usuario, extra_id, cantidad):
        """Cambia la cantidad de una línea aún no cobrada (0 = quitarla)."""
        cantidad = int(cantidad)
        if not 0 <= cantidad <= 99:
            raise ErrorNegocio("Cantidad no válida")
        with self.db.transaccion() as c:
            e = c.execute("SELECT ticket_id, pago_id, nombre FROM ticket_extras WHERE id=?", (extra_id,)).fetchone()
            if not e:
                raise ErrorNegocio("Línea no encontrada", 404)
            if e[1]:
                raise ErrorNegocio("Esa línea ya está cobrada y no se puede cambiar", 409)
            if cantidad == 0:
                c.execute("DELETE FROM ticket_extras WHERE id=?", (extra_id,))
            else:
                c.execute("UPDATE ticket_extras SET cantidad=? WHERE id=?", (cantidad, extra_id))
            self.auditar(c, usuario["id"], "extra_quitar" if cantidad == 0 else "extra_cantidad",
                         f"ticket={e[0]} {e[2]} -> {cantidad}")
        return self.consultar(ticket_id=e[0])

    # ========================================================== ticket manual
    # Para vehículos sin ticket del sistema (corte de luz, impresora averiada, entrada
    # anotada en papel...). Requiere supervisor y motivo; queda marcado y auditado.

    def _hora_local(self, texto, campo):
        try:
            dt = datetime.fromisoformat((texto or "").strip())
        except ValueError:
            raise ErrorNegocio(f"Fecha y hora de {campo} no válida")
        if dt.tzinfo is None:
            dt = dt.astimezone()  # hora local del PC (respeta el horario de verano de esa fecha)
        return dt.replace(microsecond=0)

    def _validar_manual(self, entrada, salida=None):
        ahora = self.ahora()
        e = self._hora_local(entrada, "entrada")
        if e > ahora + timedelta(minutes=1):
            raise ErrorNegocio("La hora de entrada no puede ser futura")
        if ahora - e > timedelta(days=31):
            raise ErrorNegocio("La entrada no puede tener más de 31 días")
        s = None
        if salida:
            s = self._hora_local(salida, "salida")
            if s <= e:
                raise ErrorNegocio("La salida debe ser posterior a la entrada")
            if s - ahora > timedelta(days=31):
                raise ErrorNegocio("La salida no puede ser a más de 31 días vista")
        return e, s

    def _tarifa_para(self, tarifa_id):
        if tarifa_id:
            t = self.db.q1("SELECT id FROM tarifas WHERE id=? AND activa=1", (tarifa_id,))
        else:
            t = self.db.q1("SELECT id FROM tarifas WHERE por_defecto=1 AND activa=1")
        if not t:
            raise ErrorNegocio("No hay tarifa activa disponible")
        return self.tarifa(t["id"])

    def _extras_manual(self, extras, proveedor=False):
        """[{producto_id, cantidad}] -> líneas listas para insertar (con precio e IVA del momento)."""
        iva_gen = float(self.cfg("iva_pct") or 21)
        lineas = []
        for x in extras or []:
            try:
                cantidad = int(x.get("cantidad") or 1)
                pid = int(x.get("producto_id"))
            except (TypeError, ValueError):
                raise ErrorNegocio("Servicio no válido")
            if not 1 <= cantidad <= 99:
                raise ErrorNegocio("Cantidad no válida")
            prod = self.db.q1("SELECT * FROM productos WHERE id=? AND activo=1 AND eliminado=0 AND solo_proveedor=?",
                              (pid, 1 if proveedor else 0))
            if not prod:
                raise ErrorNegocio("Servicio o producto no disponible", 404)
            lineas.append({"producto_id": pid, "nombre": prod["nombre"], "tipo": prod["tipo"],
                           "precio_cent": self._precio_de_producto(prod, x.get("precio_cent")), "cantidad": cantidad,
                           "iva_pct": prod["iva_pct"] if prod["iva_pct"] is not None else iva_gen,
                           "minutos_incluidos": prod["minutos_incluidos"] or 0, "descripcion": prod["descripcion"]})
        return lineas

    @staticmethod
    def _importe_manual(t, minutos, lineas):
        incluidos = min(minutos, sum(l["minutos_incluidos"] * l["cantidad"] for l in lineas))
        estancia = calcular_importe(max(0, minutos - incluidos), t, t["tramos"])
        extras = sum(l["precio_cent"] * l["cantidad"] for l in lineas)
        return estancia, extras, incluidos

    def calcular_manual(self, entrada, salida, tarifa_id=None, extras=None):
        e, s = self._validar_manual(entrada, salida)
        if not s:
            raise ErrorNegocio("Indique la hora de salida")
        t = self._tarifa_para(tarifa_id)
        minutos = minutos_estancia(e, s)
        estancia, ext, incluidos = self._importe_manual(t, minutos, self._extras_manual(extras))
        return {"entrada": iso(e), "salida": iso(s), "minutos": minutos, "tarifa_id": t["id"],
                "tarifa_nombre": t["nombre"], "importe_estancia_cent": estancia, "extras_cent": ext,
                "minutos_incluidos": incluidos, "importe_cent": estancia + ext}

    def ticket_manual(self, usuario, datos):
        turno = self._exigir_turno(usuario)
        self._exigir_licencia()
        if not self.tiene_modulo("rotacion"):
            raise ErrorNegocio("Licencia «Abonados»: no hay tickets de rotación", 402)
        # Desde la 2.4 el ticket manual no pide autorización de supervisor: lo hace el propio
        # usuario del turno y queda a su nombre en el ticket y en la auditoría.
        autoriza = usuario
        motivo = (datos.get("motivo") or "").strip() or None  # opcional
        matricula = norm_matricula(datos.get("matricula"))
        e, s = self._validar_manual(datos.get("entrada"), datos.get("salida"))
        t = self._tarifa_para(datos.get("tarifa_id"))
        metodo = datos.get("metodo") or "efectivo"
        if metodo not in ("efectivo", "tarjeta"):
            raise ErrorNegocio("Forma de pago no válida")
        lineas = self._extras_manual(datos.get("extras"))
        minutos = importe = extras_cent = incluidos = 0
        entregado = cambio = None
        if s:
            minutos = minutos_estancia(e, s)
            estancia, extras_cent, incluidos = self._importe_manual(t, minutos, lineas)
            importe = estancia + extras_cent
            if importe:
                entregado, cambio = self._entregado_y_cambio(metodo, importe, datos.get("entregado_cent"))
        capacidad = self.cfg("capacidad", int) or 0
        pago = None
        # Salida futura = pago por adelantado: el vehículo sigue dentro y puede salir hasta esa
        # hora (más el margen de salida); si se pasa, paga la diferencia como cualquier ticket.
        futura = bool(s and s > self.ahora())
        estado = "pagado" if futura else ("salido" if s else "dentro")
        limite = iso(s + timedelta(minutes=self.cfg("minutos_salida", int) or 15)) if futura else None
        with self.db.transaccion() as c:
            if not s or futura:
                if capacidad and c.execute("SELECT COUNT(*) FROM tickets WHERE estado IN ('dentro','pagado')"
                                           ).fetchone()[0] >= capacidad:
                    raise ErrorNegocio("Parking COMPLETO", 409)
                if matricula and c.execute("SELECT 1 FROM tickets WHERE matricula=? AND estado IN ('dentro','pagado')",
                                           (matricula,)).fetchone():
                    raise ErrorNegocio(f"La matrícula {matricula} ya figura dentro del parking", 409)
            tid = c.execute("INSERT INTO tickets(codigo, matricula, entrada, tarifa_id, estado, salida, salida_limite, "
                            "turno_entrada_id, usuario_entrada_id, manual, manual_motivo, manual_autoriza_id) "
                            "VALUES(?,?,?,?,?,?,?,?,?,1,?,?)",
                            ("tmp-" + secrets.token_hex(8), matricula, iso(e), t["id"], estado,
                             iso(s) if (s and not futura) else None, limite, turno["id"], usuario["id"], motivo,
                             autoriza["id"])).lastrowid
            codigo = self._asignar_codigo_ticket(c, tid)
            if importe:
                iva_gen = float(self.cfg("iva_pct") or 21)
                pago = self._insertar_pago(c, turno, usuario, importe, metodo, entregado, cambio,
                                           ticket_id=tid, minutos=minutos, extras=extras_cent,
                                           lineas=[(importe - extras_cent, iva_gen)] +
                                           [(l["precio_cent"] * l["cantidad"], l["iva_pct"]) for l in lineas])
                pago["lineas_extra"] = lineas
                pago["minutos_incluidos"] = incluidos
            for l in lineas:
                c.execute("INSERT INTO ticket_extras(ticket_id, producto_id, nombre, tipo, precio_cent, cantidad, "
                          "iva_pct, fecha, usuario_id, minutos_incluidos, pago_id, descripcion) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                          (tid, l["producto_id"], l["nombre"], l["tipo"], l["precio_cent"], l["cantidad"], l["iva_pct"],
                           iso(self.ahora()), usuario["id"], l["minutos_incluidos"], pago["id"] if pago else None,
                           l["descripcion"]))
            self.auditar(c, usuario["id"], "ticket_manual",
                         f"{codigo} {matricula or ''} entrada={iso(e)} salida={iso(s) if s else '-'} "
                         f"importe={importe} autoriza={autoriza['usuario']} motivo={motivo or '(sin motivo)'}"
                         + "".join(f" +{l['cantidad']}x{l['nombre']}" for l in lineas))
        tk = self.ticket(tid)
        res = {"ticket": tk, "pago": pago, "minutos": minutos, "importe_cent": importe, "salida_futura": futura,
               "salida_limite": limite}
        if not s:
            res["impresion"] = self._imprimir(self._doc_entrada(tk), "entrada_manual", copias=self._copias_entrada())
        elif pago:
            if futura:
                pago["salida_prevista"] = iso(s)
            res["impresion"] = self._imprimir_salida(self._doc_recibo(tk, pago, limite), "recibo_manual", metodo == "efectivo")
        return res

    def reimprimir(self, usuario, ticket_id):
        tk = self.ticket(int(ticket_id))
        with self.db.transaccion() as c:
            self.auditar(c, usuario["id"], "ticket_reimprimir", tk["codigo"])
        return self._imprimir(self._doc_entrada(tk, duplicado=True), "entrada")

    def vehiculos_dentro(self, buscar=""):
        sql = ("SELECT t.id, t.codigo, t.matricula, t.entrada, t.estado, t.salida_limite, t.tarifa_id, t.perdido, "
               "t.cliente_id, c.nombre cliente_nombre, t.manual, t.zona_id, "
               "(SELECT nombre FROM tarifas WHERE id=t.tarifa_id) tarifa_nombre, "
               "(SELECT COUNT(*) FROM pagos WHERE ticket_id=t.id) n_pagos, "
               "(SELECT TRIM(COALESCE(marca,'') || ' ' || COALESCE(modelo,'')) FROM cliente_matriculas cm "
               "WHERE cm.matricula=t.matricula) vehiculo, "
               "(SELECT nota FROM notas_vehiculo nv WHERE nv.matricula=t.matricula) nota, "
               "(SELECT COALESCE(rp.codigo, rp.ref, 'Reserva') FROM reservas_previstas rp WHERE rp.id=t.reserva_prevista_id) reserva_codigo "
               "FROM tickets t LEFT JOIN clientes c ON c.id=t.cliente_id WHERE estado IN ('dentro','pagado')")
        params = []
        if buscar:
            sql += " AND (t.matricula LIKE ? OR t.codigo LIKE ? OR c.nombre LIKE ?)"
            b = "%" + (norm_matricula(buscar) or "") + "%"
            params += [b, b, "%" + buscar.strip() + "%"]
        filas = self.db.q(sql + " ORDER BY t.entrada DESC, t.id DESC", params)   # 1.19: arriba los que llevan menos tiempo
        momento = self.ahora()
        for f in filas:
            f["minutos"] = minutos_estancia(parse(f["entrada"]), momento)
            try:   # 1.19: lo que pagaría si saliera ahora (tarifa, señal de reserva y pagos ya hechos incluidos)
                f["pago_estimado_cent"] = self._liquidar(self.ticket(f["id"]), momento)["pendiente_cent"]
            except Exception as e:  # noqa: BLE001  una tarifa rota no debe vaciar la lista
                errores.fallo("vehiculos.estimado", e)
                f["pago_estimado_cent"] = None
        return filas

    def cambiar_matricula(self, usuario, ticket_id, matricula):
        """Corrige la matrícula de un vehículo que está dentro (mal escrita o sin matrícula)."""
        nueva = norm_matricula(matricula)
        if nueva and not 4 <= len(nueva) <= 12:
            raise ErrorNegocio("Matrícula no válida")
        with self.db.transaccion() as c:
            tk = c.execute("SELECT codigo, matricula, estado, bono_id FROM tickets WHERE id=?", (ticket_id,)).fetchone()
            if not tk:
                raise ErrorNegocio("Ticket no encontrado", 404)
            if tk[2] not in ("dentro", "pagado"):
                raise ErrorNegocio("Solo se puede cambiar la matrícula de un vehículo que está dentro", 409)
            if (tk[1] or None) == nueva:
                return self.ticket(ticket_id)
            if nueva and c.execute("SELECT 1 FROM tickets WHERE matricula=? AND estado IN ('dentro','pagado') AND id<>?",
                                   (nueva, ticket_id)).fetchone():
                raise ErrorNegocio(f"La matrícula {nueva} ya figura dentro del parking", 409)
            c.execute("UPDATE tickets SET matricula=? WHERE id=?", (nueva, ticket_id))
            self.auditar(c, usuario["id"], "matricula_cambiar", f"{tk[0]} {tk[1] or '(sin matrícula)'} -> {nueva or '(sin matrícula)'}")
        return self.ticket(ticket_id)

    def cambiar_tarifa(self, usuario, ticket_id, tarifa_id):
        """Cambia la tarifa de un vehículo que está dentro y aún no ha pagado la estancia."""
        try:
            tarifa_id = int(tarifa_id)
        except (TypeError, ValueError):
            raise ErrorNegocio("Elija una tarifa")
        with self.db.transaccion() as c:
            tk = c.execute("SELECT t.codigo, t.estado, t.cliente_id, t.tarifa_id, tr.nombre FROM tickets t "
                           "JOIN tarifas tr ON tr.id=t.tarifa_id WHERE t.id=?", (ticket_id,)).fetchone()
            if not tk:
                raise ErrorNegocio("Ticket no encontrado", 404)
            if tk[1] != "dentro":
                raise ErrorNegocio("Solo se puede cambiar la tarifa de un vehículo que está dentro y sin pagar", 409)
            if tk[2]:
                raise ErrorNegocio("Es la entrada de un abonado: la cubre su bono", 409)
            if c.execute("SELECT 1 FROM pagos WHERE ticket_id=?", (ticket_id,)).fetchone():
                raise ErrorNegocio("Este ticket ya tiene cobros: no se puede cambiar la tarifa", 409)
            nueva = c.execute("SELECT nombre, COALESCE(modo,'tramos') FROM tarifas WHERE id=? AND activa=1 AND eliminada=0",
                              (tarifa_id,)).fetchone()
            if not nueva:
                raise ErrorNegocio("Tarifa no encontrada o desactivada", 404)
            es_reserva = nueva[1] == "reserva"
            if tk[3] != tarifa_id and not es_reserva:
                c.execute("UPDATE tickets SET tarifa_id=?, reserva_hasta=NULL, reserva_ref=NULL, reserva_tarifa_id=NULL, reserva_desde=NULL WHERE id=?",
                          (tarifa_id, ticket_id))
                self.auditar(c, usuario["id"], "tarifa_cambiar", f"{tk[0]} {tk[4]} -> {nueva[0]}")
        if es_reserva and tk[3] != tarifa_id:   # 4.2: a una tarifa de reserva, con su tiempo por defecto
            self.aplicar_reserva(usuario, ticket_id, {"tarifa_id": tarifa_id})
        return self.ticket(ticket_id)

    def historial_vehiculos(self, desde, hasta, buscar="", estado="", limite=2000):
        """Vehículos que entraron o salieron entre dos fechas (ambas incluidas)."""
        try:
            d, h = date.fromisoformat(desde), date.fromisoformat(hasta)
        except (TypeError, ValueError):
            raise ErrorNegocio("Fechas no válidas")
        if h < d:
            raise ErrorNegocio("La fecha final es anterior a la inicial")
        sql = ("SELECT t.id, t.codigo, t.matricula, t.entrada, t.salida, t.estado, t.manual, t.perdido, t.ajuste_min, "
               "t.anulado_motivo, tr.nombre tarifa_nombre, c.nombre cliente_nombre, c.tipo cliente_tipo, "
               "(SELECT TRIM(COALESCE(marca,'') || ' ' || COALESCE(modelo,'')) FROM cliente_matriculas cm "
               "WHERE cm.matricula=t.matricula) vehiculo, "
               "(SELECT COALESCE(SUM(importe_cent),0) FROM pagos p WHERE p.ticket_id=t.id) cobrado_cent "
               "FROM tickets t JOIN tarifas tr ON tr.id=t.tarifa_id LEFT JOIN clientes c ON c.id=t.cliente_id "
               "WHERE ((substr(t.entrada,1,10) BETWEEN ? AND ?) OR (substr(t.salida,1,10) BETWEEN ? AND ?))")
        params = [d.isoformat(), h.isoformat()] * 2
        if buscar:
            sql += " AND (t.matricula LIKE ? OR t.codigo LIKE ? OR c.nombre LIKE ?)"
            b = "%" + (norm_matricula(buscar) or "") + "%"
            params += [b, b, "%" + buscar.strip() + "%"]
        if estado == "dentro":
            sql += " AND t.estado IN ('dentro','pagado')"
        elif estado in ("salido", "anulado"):
            sql += " AND t.estado=?"
            params.append(estado)
        filas = self.db.q(sql + " ORDER BY t.entrada DESC LIMIT ?", params + [int(limite)])
        momento = self.ahora()
        for f in filas:
            fin = parse(f["salida"]) if f["salida"] else momento
            f["minutos"] = minutos_estancia(parse(f["entrada"]), fin)
        en_rango = lambda x: x and d.isoformat() <= x[:10] <= h.isoformat()
        return {"filas": filas, "limite_alcanzado": len(filas) >= int(limite),
                "resumen": {"entradas": sum(1 for f in filas if en_rango(f["entrada"])),
                            "salidas": sum(1 for f in filas if f["estado"] == "salido" and en_rango(f["salida"])),
                            "dentro": sum(1 for f in filas if f["estado"] in ("dentro", "pagado")),
                            "cobrado_cent": sum(f["cobrado_cent"] for f in filas)}}

    def csv_historial(self, desde, hasta, buscar="", estado=""):
        r = self.historial_vehiculos(desde, hasta, buscar, estado, limite=100000)
        out = io.StringIO()
        w = csv.writer(out, delimiter=";")
        w.writerow(["Ticket", "Matrícula", "Vehículo", "Cliente", "Entrada", "Salida", "Minutos", "Estado",
                    "Tarifa", "Cobrado (€)", "Manual", "Perdido"])
        for f in r["filas"]:
            w.writerow([f["codigo"], f["matricula"] or "", f["vehiculo"] or "", f["cliente_nombre"] or "",
                        f["entrada"][:16].replace("T", " "), (f["salida"] or "")[:16].replace("T", " "), f["minutos"],
                        f["estado"], f["tarifa_nombre"], f"{f['cobrado_cent'] / 100:.2f}".replace(".", ","),
                        "sí" if f["manual"] else "", "sí" if f["perdido"] else ""])
        return "\ufeff" + out.getvalue()

    # ====================================================== exportaciones (CSV / PDF)
    @staticmethod
    def _linea_matricula(matricula, momento):
        """9999ZZZ;20261009;23:59"""
        return f"{matricula};{momento.strftime('%Y%m%d')};{momento.strftime('%H:%M')}"

    def _momento_fijo(self, dia, hora):
        try:
            d = date.fromisoformat(dia)
            hh, mm = (int(x) for x in (hora or "23:59").split(":"))
            return datetime(d.year, d.month, d.day, hh, mm)
        except (TypeError, ValueError):
            raise ErrorNegocio("Fecha u hora no válidas para la exportación")

    def _vehiculos_para_exportar(self, origen, desde=None, hasta=None, buscar="", estado=""):
        if origen == "dentro":
            return self.vehiculos_dentro(buscar), "Vehículos dentro del parking", f"A {self.ahora().strftime('%d/%m/%Y %H:%M')}"
        r = self.historial_vehiculos(desde, hasta, buscar, estado, limite=100000)
        sub = f"Del {fecha_es(desde)} al {fecha_es(hasta)}" + (f" · búsqueda «{buscar}»" if buscar else "")
        return r["filas"], "Historial de entradas y salidas", sub

    def csv_vehiculos(self, origen="historial", desde=None, hasta=None, buscar="", estado="", fecha="registro",
                      dia=None, hora=None, hora_de="entrada"):
        filas, _, _ = self._vehiculos_para_exportar(origen, desde, hasta, buscar, estado)
        fijo = self._momento_fijo(dia, hora) if fecha == "fija" else None
        lineas = []
        for f in filas:
            if not f.get("matricula"):
                continue
            if fijo:
                m = fijo
            elif hora_de == "salida" and f.get("salida"):
                m = parse(f["salida"])
            else:
                m = parse(f["entrada"])
            lineas.append(self._linea_matricula(f["matricula"], m))
        return "\r\n".join(lineas) + ("\r\n" if lineas else "")

    def pdf_vehiculos(self, origen="historial", desde=None, hasta=None, buscar="", estado=""):
        from . import VERSION_COMPLETA
        from .pdf import listado_a_pdf
        filas, titulo, sub = self._vehiculos_para_exportar(origen, desde, hasta, buscar, estado)
        cfg = self.db.config()
        nombres = {"dentro": "Dentro", "pagado": "Pagado", "salido": "Salido", "anulado": "Anulado"}
        tabla = [[f.get("matricula") or "—", f.get("vehiculo") or "", f.get("cliente_nombre") or "", f["codigo"],
                  parse(f["entrada"]).strftime("%d/%m/%Y %H:%M"),
                  parse(f["salida"]).strftime("%d/%m/%Y %H:%M") if f.get("salida") else "—",
                  texto_duracion(f["minutos"]), nombres.get(f["estado"], f["estado"]),
                  eur(f["cobrado_cent"]) if f.get("cobrado_cent") else ""] for f in filas]
        total = sum(f.get("cobrado_cent") or 0 for f in filas)
        return listado_a_pdf({
            "titulo": titulo, "subtitulo": sub, "empresa": f"{cfg.get('nombre_parking', '')} · {cfg.get('razon_social', '')}",
            "columnas": [("Matrícula", 9, "izq"), ("Vehículo", 12, "izq"), ("Cliente", 14, "izq"), ("Ticket", 12, "izq"),
                         ("Entrada", 11, "izq"), ("Salida", 11, "izq"), ("Tiempo", 8, "izq"), ("Estado", 7, "izq"),
                         ("Cobrado", 7, "der")],
            "filas": tabla, "resumen": f"{len(filas)} vehículo(s)" + (f" · cobrado {eur(total)}" if origen != "dentro" else ""),
            "marca": VERSION_COMPLETA,
            "logo": logos.jpeg(self.carpeta_logo) if cfg.get("logo_factura") == "1" else None,
            "sello": logos.jpeg_sello(self.carpeta_logo) if cfg.get("sello_factura", "1") != "0" else None})

    def ocupacion(self):
        n = self.db.q1("SELECT COUNT(*) n FROM tickets WHERE estado IN ('dentro','pagado')")["n"]
        r = {"ocupadas": n, "capacidad": self.cfg("capacidad", int) or 0}
        zs = self.ocupacion_zonas()   # 4.3
        if zs:
            r["zonas"] = zs
        reservadas = self.cfg("plazas_abonados", int) or 0
        if reservadas:
            r["plazas_abonados"] = reservadas
            r["rotacion"] = self.db.q1("SELECT COUNT(*) n FROM tickets WHERE estado IN ('dentro','pagado') AND cliente_id IS NULL")["n"]
        return r
