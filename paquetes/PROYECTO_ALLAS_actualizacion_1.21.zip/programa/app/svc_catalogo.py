"""PROYECTO ALLAS · lógica de negocio: productos y servicios, tienda, descuentos y vales (1.4: sale de servicios.py; se mezcla en la clase Parking)."""
import secrets
from datetime import date, timedelta

from .utiles import ErrorNegocio, eur, fecha_es, iso, parse, texto_duracion


class SvcCatalogo:
    # ================================================= servicios y productos
    def productos(self, solo_activos=False):
        filas = self.db.q("SELECT p.*, f.actualizado foto FROM productos p LEFT JOIN producto_fotos f ON f.producto_id=p.id "
                          "WHERE p.eliminado=0" + (" AND p.activo=1 AND p.solo_proveedor=0" if solo_activos else "")
                          + " ORDER BY p.activo DESC, p.orden, p.nombre COLLATE NOCASE")
        iva_gen = float(self.cfg("iva_pct") or 21)
        for f in filas:
            f["iva_efectivo"] = f["iva_pct"] if f["iva_pct"] is not None else iva_gen
        return filas

    @staticmethod
    def _validar_producto(datos):
        nombre = (datos.get("nombre") or "").strip()[:80]
        if not nombre:
            raise ErrorNegocio("El servicio o producto necesita un nombre")
        # 4.62: sin precio fijo → «precio variable»: se pide al seleccionar el servicio
        solo_prov = datos.get("solo_proveedor") in (True, 1, "1")
        # los servicios de proveedor llevan el precio de cada proveedor: el del catálogo no cuenta
        variable = 0 if solo_prov else 1 if datos.get("precio_variable") in (True, 1, "1") or datos.get("precio_cent") in (None, "") else 0
        try:
            precio = 0 if variable or solo_prov else int(datos.get("precio_cent"))
            iva = datos.get("iva_pct")
            iva = None if iva in (None, "") else float(iva)
            orden = int(datos.get("orden") or 0)
            minutos = int(datos.get("minutos_incluidos") or 0)
        except (ValueError, TypeError):
            raise ErrorNegocio(f"Datos no válidos en «{nombre}»")
        if precio < 0:
            raise ErrorNegocio(f"Precio no válido en «{nombre}»")
        if iva is not None and not 0 <= iva <= 30:
            raise ErrorNegocio(f"IVA no válido en «{nombre}»")
        if not 0 <= minutos <= 31 * 1440:
            raise ErrorNegocio("El parking incluido no es válido (máximo 31 días)")
        return {"nombre": nombre, "tipo": datos.get("tipo") if datos.get("tipo") in ("servicio", "producto") else "servicio",
                "precio_cent": precio, "precio_variable": variable, "iva_pct": iva, "activo": 0 if datos.get("activo") in (False, 0, "0") else 1,
                "orden": orden, "minutos_incluidos": minutos,
                "descripcion": (datos.get("descripcion") or "").strip()[:300] or None,
                "solo_proveedor": 1 if datos.get("solo_proveedor") in (True, 1, "1") else 0}

    @staticmethod
    def _escribir_producto(c, v, pid=None):
        campos = ("nombre", "tipo", "precio_cent", "iva_pct", "activo", "orden", "minutos_incluidos", "descripcion", "solo_proveedor", "precio_variable")
        if pid:
            c.execute("UPDATE productos SET " + ", ".join(f"{k}=?" for k in campos) + " WHERE id=?",
                      tuple(v[k] for k in campos) + (pid,))
            return pid
        return c.execute(f"INSERT INTO productos({', '.join(campos)}) VALUES({', '.join('?' * len(campos))})",
                         tuple(v[k] for k in campos)).lastrowid

    def guardar_producto(self, datos, actor_id, pid=None):
        v = self._validar_producto(datos)
        with self.db.transaccion() as c:
            if pid and not c.execute("SELECT 1 FROM productos WHERE id=? AND eliminado=0", (pid,)).fetchone():
                raise ErrorNegocio("Servicio o producto no encontrado", 404)
            pid = self._escribir_producto(c, v, pid)
            self.auditar(c, actor_id, "producto_guardar", f"id={pid} {v['nombre']} {v['precio_cent']}")
        return pid

    @staticmethod
    def _quitar_producto(c, pid):
        """Borra el producto. Si ya se ha vendido alguna vez, se oculta en lugar de borrarlo
        (las facturas y estancias guardan su propia copia del nombre y el precio)."""
        if c.execute("SELECT 1 FROM ticket_extras WHERE producto_id=? LIMIT 1", (pid,)).fetchone():
            c.execute("UPDATE productos SET eliminado=1, activo=0 WHERE id=?", (pid,))
            return "oculto"
        c.execute("DELETE FROM productos WHERE id=?", (pid,))
        return "borrado"

    def eliminar_producto(self, pid, actor_id):
        with self.db.transaccion() as c:
            p = c.execute("SELECT nombre FROM productos WHERE id=? AND eliminado=0", (pid,)).fetchone()
            if not p:
                raise ErrorNegocio("Servicio o producto no encontrado", 404)
            modo = self._quitar_producto(c, pid)
            self.auditar(c, actor_id, "producto_eliminar", f"id={pid} {p[0]} ({modo})")
        return {"ok": True, "modo": modo}

    # ============================ fotos de productos (3.1)
    FOTO_MAX = 600 * 1024

    def guardar_foto_producto(self, pid, datos, actor_id):
        if not self.db.q1("SELECT 1 FROM productos WHERE id=? AND eliminado=0", (pid,)):
            raise ErrorNegocio("Servicio o producto no encontrado", 404)
        if datos[:3] == b"\xff\xd8\xff":
            tipo = "image/jpeg"
        elif datos[:8] == b"\x89PNG\r\n\x1a\n":
            tipo = "image/png"
        elif datos[:4] == b"RIFF" and datos[8:12] == b"WEBP":
            tipo = "image/webp"
        else:
            raise ErrorNegocio("La foto debe ser JPG, PNG o WEBP")
        if len(datos) > self.FOTO_MAX:
            raise ErrorNegocio("La foto es demasiado grande (máximo 600 KB)")
        with self.db.transaccion() as c:
            c.execute("INSERT INTO producto_fotos(producto_id, tipo, datos, actualizado) VALUES(?,?,?,?) "
                      "ON CONFLICT(producto_id) DO UPDATE SET tipo=excluded.tipo, datos=excluded.datos, "
                      "actualizado=excluded.actualizado", (pid, tipo, datos, iso(self.ahora())))
            self.auditar(c, actor_id, "producto_foto", f"id={pid} {len(datos)} bytes")
        return {"ok": True}

    def foto_producto(self, pid):
        r = self.db.q1("SELECT tipo, datos FROM producto_fotos WHERE producto_id=?", (pid,))
        if not r:
            raise ErrorNegocio("Este producto no tiene foto", 404)
        return r["datos"], r["tipo"]

    def quitar_foto_producto(self, pid, actor_id):
        with self.db.transaccion() as c:
            c.execute("DELETE FROM producto_fotos WHERE producto_id=?", (pid,))
            self.auditar(c, actor_id, "producto_foto_quitar", f"id={pid}")
        return {"ok": True}

    # ============================ descuentos (3.1)
    TIPOS_DESCUENTO = ("porcentaje", "importe", "minutos")
    AMBITOS_DESCUENTO = ("estancia", "tienda", "todo")

    def descuentos_activos(self):
        return self.activo("descuentos_activo", "descuentos")

    def descuentos(self, solo_activos=False, ambito=None):
        filas = self.db.q("SELECT * FROM descuentos WHERE eliminado=0" + (" AND activo=1" if solo_activos else "")
                          + " ORDER BY activo DESC, orden, nombre COLLATE NOCASE")
        if ambito:
            filas = [d for d in filas if d["ambito"] in (ambito, "todo") and not (ambito == "tienda" and d["tipo"] == "minutos")]
        for d in filas:
            d["texto"] = self._texto_descuento(d)
        return filas

    @staticmethod
    def _texto_descuento(d):
        return {"porcentaje": f"{d['valor']} %", "importe": f"{eur(d['valor'])}",
                "minutos": f"{texto_duracion(d['valor'])} gratis"}[d["tipo"]]

    def guardar_descuento(self, datos, actor_id, did=None):
        nombre = (datos.get("nombre") or "").strip()[:60]
        if not nombre:
            raise ErrorNegocio("El descuento necesita un nombre")
        tipo, ambito = datos.get("tipo"), datos.get("ambito") or "estancia"
        if tipo not in self.TIPOS_DESCUENTO:
            raise ErrorNegocio("Tipo de descuento no válido")
        if ambito not in self.AMBITOS_DESCUENTO:
            raise ErrorNegocio("Indique dónde se aplica el descuento")
        if tipo == "minutos" and ambito != "estancia":
            raise ErrorNegocio("Los minutos gratis solo se pueden aplicar a la estancia")
        try:
            valor = int(datos.get("valor"))
        except (TypeError, ValueError):
            raise ErrorNegocio("Indique el valor del descuento")
        if valor <= 0 or (tipo == "porcentaje" and valor > 100):
            raise ErrorNegocio("El porcentaje debe estar entre 1 y 100" if tipo == "porcentaje" else "El valor debe ser mayor que 0")
        codigo = (datos.get("codigo") or "").strip().upper()[:30] or None
        activo = 0 if datos.get("activo") in (False, 0, "0") else 1
        comercio = (datos.get("comercio") or "").strip()[:60] or None   # 3.9: validación de un comercio
        with self.db.transaccion() as c:
            if codigo and c.execute("SELECT 1 FROM descuentos WHERE codigo=? AND eliminado=0 AND id<>?",
                                    (codigo, did or 0)).fetchone():
                raise ErrorNegocio(f"Ya hay otro descuento con el código {codigo}")
            if did:
                if not c.execute("SELECT 1 FROM descuentos WHERE id=? AND eliminado=0", (did,)).fetchone():
                    raise ErrorNegocio("Descuento no encontrado", 404)
                c.execute("UPDATE descuentos SET nombre=?, tipo=?, valor=?, ambito=?, codigo=?, activo=?, comercio=? WHERE id=?",
                          (nombre, tipo, valor, ambito, codigo, activo, comercio, did))
            else:
                did = c.execute("INSERT INTO descuentos(nombre, tipo, valor, ambito, codigo, activo, comercio) VALUES(?,?,?,?,?,?,?)",
                                (nombre, tipo, valor, ambito, codigo, activo, comercio)).lastrowid
            self.auditar(c, actor_id, "descuento_guardar", f"id={did} {nombre} {tipo}={valor} {ambito}")
        return did

    def eliminar_descuento(self, did, actor_id):
        with self.db.transaccion() as c:
            if not c.execute("SELECT 1 FROM descuentos WHERE id=? AND eliminado=0", (did,)).fetchone():
                raise ErrorNegocio("Descuento no encontrado", 404)
            # se marca como eliminado: las facturas guardan su nombre e importe
            c.execute("UPDATE descuentos SET eliminado=1, activo=0 WHERE id=?", (did,))
            self.auditar(c, actor_id, "descuento_eliminar", f"id={did}")
        return {"ok": True}

    # ---------------------------------------------------------- vales de descuento (3.2)
    ALFABETO_VALE = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"   # sin 0/O ni 1/I para que se tecleen sin errores

    def _nuevo_codigo_vale(self, c):
        while True:
            cod = "V" + "".join(secrets.choice(self.ALFABETO_VALE) for _ in range(8))
            if not c.execute("SELECT 1 FROM vales WHERE codigo=?", (cod,)).fetchone():
                return cod

    @staticmethod
    def _limpiar_vale(codigo):
        return "".join(ch for ch in (codigo or "").upper() if ch.isalnum())

    def generar_vales(self, usuario, descuento_id, cantidad=1, usos_max=1, caduca=None, nota=None, imprimir=True):
        """Crea 'cantidad' vales del descuento indicado. usos_max: 1 = un uso, N = varios, None/0 = ilimitado."""
        if not self.descuentos_activos():
            raise ErrorNegocio("Active primero los descuentos (Ajustes → Precios → Descuentos)")
        d = self.db.q1("SELECT * FROM descuentos WHERE id=? AND eliminado=0", (descuento_id,))
        if not d:
            raise ErrorNegocio("Elija el descuento que dan los vales")
        try:
            cantidad = int(cantidad)
        except (TypeError, ValueError):
            raise ErrorNegocio("Cantidad no válida")
        if not 1 <= cantidad <= 200:
            raise ErrorNegocio("Se pueden generar entre 1 y 200 vales de una vez")
        usos_max = int(usos_max) if usos_max not in (None, "", 0, "0") else None
        if usos_max is not None and not 1 <= usos_max <= 9999:
            raise ErrorNegocio("Número de usos no válido")
        if caduca:
            try:
                cad = date.fromisoformat(str(caduca)[:10])
            except ValueError:
                raise ErrorNegocio("Fecha de caducidad no válida")
            if cad < self.ahora().date():
                raise ErrorNegocio("La fecha de caducidad ya ha pasado")
            caduca = cad.isoformat()
        else:
            caduca = None
        nota = (nota or "").strip()[:80] or None
        lote = self.ahora().strftime("%Y%m%d-%H%M%S")
        ids = []
        with self.db.transaccion() as c:
            for _ in range(cantidad):
                ids.append(c.execute("INSERT INTO vales(codigo, descuento_id, usos_max, caduca, nota, lote, creado, usuario_id) "
                                     "VALUES(?,?,?,?,?,?,?,?)", (self._nuevo_codigo_vale(c), d["id"], usos_max, caduca, nota,
                                                                 lote, iso(self.ahora()), usuario["id"])).lastrowid)
            self.auditar(c, usuario["id"], "vales_generar", f"{cantidad} x {d['nombre']} usos={usos_max or 'ilimitado'} "
                         f"caduca={caduca or '-'} lote={lote}")
        vales = [self.vale(i) for i in ids]
        res = {"vales": vales, "lote": lote}
        if imprimir:
            res["impresion"] = self.imprimir_vales(ids)
        return res

    def vale(self, vid):
        v = self.db.q1("SELECT v.*, d.nombre descuento_nombre, d.tipo, d.valor, d.ambito FROM vales v "
                       "JOIN descuentos d ON d.id=v.descuento_id WHERE v.id=?", (vid,))
        if not v:
            raise ErrorNegocio("Vale no encontrado", 404)
        return self._estado_vale(v)

    def _estado_vale(self, v):
        v["texto"] = self._texto_descuento(v)
        hoy = self.ahora().date().isoformat()
        v["estado"] = ("anulado" if v["anulado"] else "caducado" if v["caduca"] and v["caduca"] < hoy else
                       "agotado" if v["usos_max"] is not None and v["usos"] >= v["usos_max"] else "valido")
        return v

    def vales(self, buscar="", estado="", limite=300):
        sql = ("SELECT v.*, d.nombre descuento_nombre, d.tipo, d.valor, d.ambito FROM vales v "
               "JOIN descuentos d ON d.id=v.descuento_id")
        params = []
        if buscar:
            b = "%" + buscar.strip() + "%"
            sql += " WHERE v.codigo LIKE ? OR d.nombre LIKE ? OR COALESCE(v.nota,'') LIKE ? OR v.lote LIKE ?"
            params = [self._limpiar_vale(buscar) + "%", b, b, b]
        filas = [self._estado_vale(v) for v in self.db.q(sql + " ORDER BY v.id DESC LIMIT ?", params + [int(limite)])]
        return [v for v in filas if not estado or v["estado"] == estado]

    def anular_vale(self, usuario, vid, motivo=""):
        v = self.vale(vid)
        if v["anulado"]:
            raise ErrorNegocio("El vale ya estaba anulado")
        with self.db.transaccion() as c:
            c.execute("UPDATE vales SET anulado=? WHERE id=?", (f"{iso(self.ahora())} {(motivo or '').strip()}".strip(), vid))
            self.auditar(c, usuario["id"], "vale_anular", f"{v['codigo']} {motivo or ''}")
        return self.vale(vid)

    def imprimir_vales(self, ids):
        cfg = self._cfg_ticket()
        docs = [self._doc_vale(self.vale(i), cfg) for i in ids]
        doc = docs[0]
        for otro in docs[1:]:   # todos los vales en un solo envío, cada uno con su corte
            doc.buf += otro.buf
            doc.preview += [""] + otro.preview
            doc.elementos += otro.elementos
        return self._enviar(doc, "vales")

    def _doc_vale(self, v, cfg=None):
        cfg = cfg or self._cfg_ticket()
        doc = self._cabecera(self._nuevo_doc(cfg), cfg)
        self._titulo(doc, cfg.get("vale_titulo") or "VALE DE DESCUENTO")
        doc.alinear("centro").espacio().grande().negrita().linea(v["texto"]).negrita(False).grande(False)
        doc.linea(v["descuento_nombre"])
        doc.lineas({"estancia": "Válido en el aparcamiento", "tienda": "Válido en la tienda",
                    "todo": "Válido en aparcamiento y tienda"}[v["ambito"]])
        doc.alinear("izq").separador()
        doc.par("Usos", "1 (un solo uso)" if v["usos_max"] == 1 else "Ilimitados" if v["usos_max"] is None
                else f"{v['usos_max']} usos")
        doc.par("Válido hasta", date.fromisoformat(v["caduca"]).strftime("%d/%m/%Y") if v["caduca"] else "Sin caducidad")
        if v.get("nota"):
            doc.par("Nota", v["nota"])
        doc.separador()
        self._codigo_doc(doc, v["codigo"], {**cfg, "ticket_codigo": cfg.get("ticket_codigo") or "ambos"})
        doc.alinear("centro").linea(f"Código: {v['codigo']}").alinear("izq")
        doc.separador().alinear("centro").lineas(cfg.get("vale_pie") or "Presente este vale al pagar.").alinear("izq")
        return doc.cortar()

    def _vale_por_codigo(self, codigo):
        cod = self._limpiar_vale(codigo)
        if not cod.startswith("V") or len(cod) != 9:
            return None
        v = self.db.q1("SELECT v.*, d.nombre descuento_nombre, d.tipo, d.valor, d.ambito FROM vales v "
                       "JOIN descuentos d ON d.id=v.descuento_id WHERE v.codigo=?", (cod,))
        return self._estado_vale(v) if v else None

    def _usar_vale(self, c, vale):
        """Gasta un uso del vale dentro de la transacción del cobro (falla si otro puesto acaba de gastarlo)."""
        n = c.execute("UPDATE vales SET usos=usos+1 WHERE id=? AND anulado IS NULL AND "
                      "(usos_max IS NULL OR usos < usos_max)", (vale["id"],)).rowcount
        if n != 1:
            raise ErrorNegocio(f"El vale {vale['codigo']} ya no tiene usos disponibles", 409)

    def descuento_por_codigo(self, codigo, ambito):
        """Busca un vale o un descuento por su código (para la pantalla de Salida y la Tienda)."""
        d = self._descuento_para(codigo, ambito)
        out = {"id": d.get("_vale", {}).get("codigo") or d["codigo"], "nombre": d["nombre"], "texto": self._texto_descuento(d),
               "tipo": d["tipo"], "valor": d["valor"], "codigo": d.get("_vale", {}).get("codigo") or d["codigo"]}
        if d.get("_vale"):
            v = d["_vale"]
            out["vale"] = {"codigo": v["codigo"], "usos": v["usos"], "usos_max": v["usos_max"], "caduca": v["caduca"]}
        return out, d

    def descuento_ticket(self, ticket_id, codigo, calculo_en=None, perdido=False):
        """Cuánto descuenta un código (vale o descuento) a lo que debe ahora un ticket."""
        momento = self.ahora()
        if calculo_en:
            c_en = parse(calculo_en)
            if timedelta(0) <= momento - c_en <= timedelta(minutes=3):
                momento = c_en
        tk = self.ticket(int(ticket_id))
        liq = self._liquidar(tk, momento, perdido)
        out, d = self.descuento_por_codigo(codigo, "estancia")
        out["descuento_cent"] = self._importe_descuento_estancia(d, tk, liq, momento, perdido)
        if not out["descuento_cent"]:
            raise ErrorNegocio("No hay nada que descontar en este ticket")
        return out

    def _descuento_para(self, descuento_id, ambito):
        """Descuento elegido (por id o por código) si el servicio está activado y vale para 'ambito'."""
        if descuento_id in (None, "", 0):
            return None
        if not self.descuentos_activos():
            raise ErrorNegocio("Los descuentos están desactivados (Ajustes → Precios → Descuentos)")
        if isinstance(descuento_id, str) and not descuento_id.isdigit():
            vale = self._vale_por_codigo(descuento_id)
            if vale:
                if vale["estado"] != "valido":
                    raise ErrorNegocio({"anulado": f"El vale {vale['codigo']} está anulado",
                                        "caducado": f"El vale {vale['codigo']} caducó el {fecha_es(vale['caduca'])}",
                                        "agotado": f"El vale {vale['codigo']} ya se ha usado"
                                        + ("" if vale["usos_max"] == 1 else f" {vale['usos']} veces (todos sus usos)")}[vale["estado"]], 409)
                d = self.db.q1("SELECT * FROM descuentos WHERE id=?", (vale["descuento_id"],))
                d["_vale"] = vale
                d["nombre"] = f"{d['nombre']} (vale {vale['codigo']})"
                d["activo"] = 1   # un vale emitido vale aunque el tipo de descuento se haya desactivado después
                if d["ambito"] not in (ambito, "todo") or (ambito == "tienda" and d["tipo"] == "minutos"):
                    raise ErrorNegocio(f"El vale {vale['codigo']} no se puede usar en {'la tienda' if ambito == 'tienda' else 'el estacionamiento'}")
                return d
            d = self.db.q1("SELECT * FROM descuentos WHERE codigo=? AND eliminado=0", (descuento_id.strip().upper(),))
        else:
            d = self.db.q1("SELECT * FROM descuentos WHERE id=? AND eliminado=0", (int(descuento_id),))
        if not d or not d["activo"]:
            raise ErrorNegocio("Descuento no encontrado o inactivo", 404)
        if d["ambito"] not in (ambito, "todo") or (ambito == "tienda" and d["tipo"] == "minutos"):
            raise ErrorNegocio(f"El descuento «{d['nombre']}» no se aplica a {'la tienda' if ambito == 'tienda' else 'la estancia'}")
        return d

    def _importe_descuento_estancia(self, d, tk, liq, momento, perdido=False):
        """Lo que se descuenta de la estancia pendiente (nunca más de lo que se debe por ella)."""
        base = liq["pendiente_estancia_cent"]
        if base <= 0:
            return 0
        if d["tipo"] == "porcentaje":
            return min(base, round(base * d["valor"] / 100))
        if d["tipo"] == "importe":
            return min(base, d["valor"])
        # minutos gratis: se calcula como si hubiera entrado N minutos más tarde
        tk2 = dict(tk)
        nueva = parse(tk["entrada"]) + timedelta(minutes=d["valor"])
        if nueva >= momento:
            return base
        tk2["entrada"] = iso(nueva)
        liq2 = self._liquidar(tk2, momento, perdido)
        return max(0, min(base, base - liq2["pendiente_estancia_cent"]))

    @staticmethod
    def _importe_descuento_total(d, total):
        if d["tipo"] == "porcentaje":
            return min(total, round(total * d["valor"] / 100))
        return min(total, d["valor"])

    def opciones_descuento_ticket(self, tk, liq, momento, perdido=False):
        """Para la pantalla de Salida: cuánto descontaría cada descuento de estancia activo."""
        if not liq or liq.get("abonado") or liq["pendiente_estancia_cent"] <= 0:
            return []
        out = []
        dc = self.descuento_cliente(tk)   # 4.54: descuento fijo del cliente (va primero y no depende del módulo de descuentos)
        if dc:
            out.append({"id": "cliente", "nombre": dc["nombre"], "texto": dc["texto"], "codigo": None, "cliente": True,
                        "descuento_cent": self._importe_descuento_estancia(dc, tk, liq, momento, perdido)})
        if self.descuentos_activos():
            out += [{"id": d["id"], "nombre": d["nombre"], "texto": d["texto"], "codigo": d["codigo"],
                     "descuento_cent": self._importe_descuento_estancia(d, tk, liq, momento, perdido)}
                    for d in self.descuentos(solo_activos=True, ambito="estancia")]
        return out

    def descuento_cliente(self, tk):
        """Descuento fijo en % del cliente dueño del ticket (por el propio ticket o por la matrícula), o None."""
        cid = tk.get("cliente_id")
        if not cid and tk.get("matricula"):
            r = self.db.q1("SELECT cliente_id FROM cliente_matriculas WHERE matricula=?", (tk["matricula"],))
            cid = r["cliente_id"] if r else None
        if not cid:
            return None
        c = self.db.q1("SELECT nombre, descuento_pct FROM clientes WHERE id=? AND activo=1", (cid,))
        if not c or not c["descuento_pct"] or c["descuento_pct"] <= 0:
            return None
        pct = c["descuento_pct"]
        txt = f"{pct:g} %".replace(".", ",")
        return {"id": None, "nombre": f"Cliente {c['nombre']}", "tipo": "porcentaje", "valor": pct, "texto": txt, "codigo": None, "ambito": "estancia", "activo": 1}

    def ventas_tienda(self, desde, hasta, buscar=""):
        """Historial de ventas de la tienda (para consultar o reimprimir un ticket)."""
        try:
            d, h = date.fromisoformat(desde), date.fromisoformat(hasta)
        except (TypeError, ValueError):
            raise ErrorNegocio("Fechas no válidas")
        sql = ("SELECT p.id, p.serie, p.numero, p.fecha, p.importe_cent, p.metodo, u.nombre usuario, "
               "d.nombre cliente FROM pagos p LEFT JOIN usuarios u ON u.id=p.usuario_id "
               "LEFT JOIN facturas_destinatario d ON d.pago_id=p.id "
               "WHERE p.concepto='venta' AND substr(p.fecha,1,10) BETWEEN ? AND ?")
        params = [d.isoformat(), h.isoformat()]
        q = (buscar or "").strip()
        if q:
            sql += (" AND (p.serie || '-' || printf('%06d', p.numero) LIKE ? OR CAST(p.numero AS TEXT)=? OR "
                    "EXISTS (SELECT 1 FROM ventas_lineas v WHERE v.pago_id=p.id AND v.nombre LIKE ?) OR d.nombre LIKE ?)")
            params += [f"%{q.upper()}%", q.lstrip("0") or "0", f"%{q}%", f"%{q}%"]
        filas = self.db.q(sql + " ORDER BY p.id DESC LIMIT 500", params)
        for f in filas:
            f["lineas"] = self.db.q("SELECT nombre, cantidad, precio_cent FROM ventas_lineas WHERE pago_id=? ORDER BY id",
                                    (f["id"],))
        return {"ventas": filas, "total_cent": sum(f["importe_cent"] for f in filas),
                "unidades": sum(l["cantidad"] for f in filas for l in f["lineas"])}

    # ================================================================ tienda
    def vender_tienda(self, usuario, lineas, metodo, entregado_cent=None, descuento_id=None):
        """Venta de productos y servicios sin estancia (sin matrícula ni tiempo)."""
        turno = self._exigir_turno(usuario)
        self._exigir_licencia()
        if metodo not in ("efectivo", "tarjeta"):
            raise ErrorNegocio("Forma de pago no válida")
        ls = self._extras_manual(lineas)
        if not ls:
            raise ErrorNegocio("Añada al menos un producto o servicio")
        bruto = sum(l["precio_cent"] * l["cantidad"] for l in ls)
        if bruto <= 0:
            raise ErrorNegocio("El total de la venta es 0")
        desc = self._descuento_para(descuento_id, "tienda")
        desc_cent = self._importe_descuento_total(desc, bruto) if desc else 0
        importe = bruto - desc_cent
        lineas_iva = self._lineas_iva_con_descuento(ls, desc_cent)
        entregado, cambio = self._entregado_y_cambio(metodo, importe, entregado_cent) if importe else (None, None)
        with self.db.transaccion() as c:
            pago = self._insertar_pago(c, turno, usuario, importe, metodo, entregado, cambio, extras=bruto,
                                       lineas=lineas_iva, concepto="venta",
                                       descuento=(desc, desc_cent) if desc_cent else None)
            if desc and desc.get("_vale") and desc_cent:
                self._usar_vale(c, desc["_vale"])
                c.execute("UPDATE pagos SET vale_id=? WHERE id=?", (desc["_vale"]["id"], pago["id"]))
            for l in ls:
                c.execute("INSERT INTO ventas_lineas(pago_id, producto_id, nombre, tipo, descripcion, precio_cent, cantidad, "
                          "iva_pct) VALUES(?,?,?,?,?,?,?,?)", (pago["id"], l["producto_id"], l["nombre"], l["tipo"],
                                                               l["descripcion"], l["precio_cent"], l["cantidad"], l["iva_pct"]))
            self.auditar(c, usuario["id"], "tienda_venta", f"{pago['serie']}-{pago['numero']} {importe} {metodo} · "
                         + (f"DESCUENTO {desc['nombre']} -{desc_cent} · " if desc_cent else "")
                         + ", ".join(f"{l['cantidad']}x{l['nombre']}" for l in ls))
        pago["lineas_extra"] = ls
        return {"pago": pago, "impresion": self._imprimir(self._doc_recibo_venta(pago), "recibo_tienda",
                                                          cajon=(metodo == "efectivo"))}
