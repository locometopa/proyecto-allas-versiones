"""Visor TPV de cliente (pole display): 2 líneas de texto, normalmente 20 columnas.

Se conecta por puerto serie (COM3, /dev/ttyUSB0), por red (IP:puerto) o como impresora de Windows
(muchos visores USB se instalan así). Protocolos habituales:
  - epson   : ESC/POS de visores (Epson DM-D y compatibles; el más común)
  - cd5220  : visores con juego de órdenes CD5220 (ESC Q A / ESC Q B)
  - texto   : texto plano, una línea tras otra
El envío se hace en un hilo aparte y solo se manda el último mensaje (si el visor tarda o no está
conectado, la caja no se bloquea).
"""
import os
import re
import queue
import socket
import subprocess
import sys
import threading
import time
import unicodedata

from . import impresion
from . import errores

PROTOCOLOS = ("epson", "cd5220", "aedex", "texto")
CONEXIONES = ("serie", "red", "windows", "archivo")

# 4.11: efectos. Se hacen reenviando el texto cuadro a cuadro (valen para cualquier visor de texto), solo en los mensajes de
# texto (reposo, bienvenida, despedida), nunca en los importes. Con «programa del fabricante» no hay efectos (cada cuadro
# abriría el programa).
EFECTOS = {"ninguno": "Sin efecto", "desplazar": "Desplazar el texto", "parpadear": "Parpadear",
           "escribir": "Escribir letra a letra", "entrar": "Entrar por la derecha"}
VELOCIDADES = {"lenta": 0.45, "normal": 0.28, "rapida": 0.16}   # segundos por cuadro


def efectos_permitidos(conexion):
    return conexion != "programa"


# ------------------------------------------------------------------ texto
def plano(texto):
    """Sin acentos ni símbolos que muchos visores no tienen (€ → EUR)."""
    t = (texto or "")
    for a, b in (("·", "-"), ("•", "-"), ("—", "-"), ("–", "-"), ("…", "..."), ("“", '"'), ("”", '"'), ("‘", "'"), ("’", "'"), ("«", '"'), ("»", '"'), ("×", "x")):
        t = t.replace(a, b)
    t = t.replace("€", "EUR").replace("º", "o").replace("ª", "a").replace("¡", "").replace("¿", "")
    t = unicodedata.normalize("NFKD", t)
    t = "".join(c for c in t if not unicodedata.combining(c))
    return "".join(c if 32 <= ord(c) < 127 else "?" for c in t)


def eur(cent):
    s = "-" if cent < 0 else ""
    cent = abs(int(cent))
    return f"{s}{cent // 100:,}".replace(",", ".") + f",{cent % 100:02d}"


def par(izq, der, cols):
    """'TOTAL          4,12' en exactamente 'cols' caracteres (recorta la parte izquierda si no cabe)."""
    izq, der = plano(izq), plano(der)
    hueco = cols - len(der) - 1
    if hueco < 1:
        return der[-cols:].rjust(cols)
    return izq[:hueco].ljust(hueco) + " " + der


def centro(texto, cols):
    return plano(texto)[:cols].center(cols)


def lineas(d, cfg):
    """Las dos líneas del visor para un mensaje de la caja (el mismo que recibe la pantalla de cliente)."""
    cols = max(8, min(40, int(cfg.get("columnas") or 20)))
    sufijo = " EUR" if cols >= 20 else ""
    tipo = (d or {}).get("tipo") or "libre"
    if tipo == "cobro" or tipo == "tienda":
        total = int(d.get("total_cent") or 0)
        ent = d.get("entregado_cent")
        if d.get("metodo") == "efectivo" and ent is not None:
            dif = int(ent) - total
            return (par("ENTREGADO", eur(ent) + sufijo, cols),
                    par("CAMBIO" if dif >= 0 else "FALTAN", eur(abs(dif)) + sufijo, cols))
        if tipo == "cobro":
            arriba = par(d.get("matricula") or "TICKET", d.get("tiempo") or "", cols)
        else:
            ls = d.get("lineas") or []
            ult = ls[-1] if ls else {}
            arriba = par((f"{ult.get('cantidad')}x " if (ult.get("cantidad") or 1) > 1 else "") + (ult.get("concepto") or ""),
                         eur(ult.get("importe_cent") or 0), cols) if ult else centro("", cols)
        return arriba, par("TOTAL", eur(total) + sufijo, cols)
    if tipo == "gracias":
        cambio = int(d.get("cambio_cent") or 0)
        abajo = par("CAMBIO", eur(cambio) + sufijo, cols) if cambio else (
            par("PAGADO", eur(d.get("total_cent") or 0) + sufijo, cols) if d.get("total_cent") else centro("Buen viaje", cols))
        return centro(cfg.get("gracias") or "GRACIAS", cols), abajo
    if tipo == "entrada":
        return centro(cfg.get("bienvenida") or "BIENVENIDO", cols), par(d.get("matricula") or "", d.get("hora") or "", cols)
    return centro(cfg.get("reposo1") or cfg.get("nombre") or "", cols), centro(cfg.get("reposo2") or "", cols)


def bytes_visor(l1, l2, protocolo="epson"):
    a, b = l1.encode("ascii", "replace"), l2.encode("ascii", "replace")
    if protocolo == "cd5220":
        return b"\x1b@\x0c\x1bQA" + a + b"\r\x1bQB" + b + b"\r"
    if protocolo == "aedex":   # AEDEX (Posiflex, Aures… en ese modo): !#1 línea de arriba, !#2 línea de abajo
        return b"!#1" + a + b"\r" + b"!#2" + b + b"\r"
    if protocolo == "texto":
        return b"\x0c" + a + b"\r\n" + b + b"\r\n"
    # Epson / ESC-POS de visor: inicializar, borrar, cursor arriba a la izquierda, línea 1, ir a (1,2), línea 2
    return b"\x1b@\x0c\x0b" + a + b"\x1f$\x01\x02" + b


# ------------------------------------------------------------------ efectos
def textos_libres(d, cfg):
    """Texto completo (sin recortar) de las líneas que admiten efecto; None en las que no. Así un texto largo puede desplazarse."""
    tipo = (d or {}).get("tipo") or "libre"
    if tipo == "libre":
        return (cfg.get("reposo1") or cfg.get("nombre") or "", cfg.get("reposo2") or "")
    if tipo == "entrada":
        return (cfg.get("bienvenida") or "BIENVENIDO", None)
    if tipo == "gracias":
        return (cfg.get("gracias") or "GRACIAS", None)
    return (None, None)


def _cuadros_linea(texto, cols, efecto):
    """Cuadros de una línea (cada uno de 'cols' caracteres) y si el efecto se repite sin fin."""
    t = plano(texto).strip()[:200]
    if not t:
        return [" " * cols], False
    fin = t.center(cols) if len(t) <= cols else t[:cols]
    off = max(0, (cols - len(t)) // 2) if len(t) <= cols else 0
    if efecto == "parpadear":
        return [fin] * 3 + [" " * cols], True
    if efecto == "escribir":
        return [(" " * off + t[:i]).ljust(cols)[:cols] for i in range(1, min(len(t), cols - off) + 1)], False
    if efecto == "entrar":
        paso = max(1, (cols - off) // 12)
        return [(" " * x + t)[:cols].ljust(cols) for x in range(cols, off, -paso)] + [fin], False
    if efecto == "desplazar":
        if len(t) <= cols:   # entra por la derecha, se queda un momento centrado y sale por la izquierda
            base = " " * off + t
            entra = [(" " * x + t)[:cols].ljust(cols) for x in range(cols, off, -1)]
            sale = [base[k:].ljust(cols)[:cols] for k in range(1, len(base) + 1)]
            return entra + [fin] * 8 + sale, True
        largo = t + " " * 4
        giro = largo + largo
        return [giro[:cols]] * 6 + [giro[k:k + cols] for k in range(1, len(largo) + 1)], True
    return [fin if len(t) > cols else t.center(cols)], False


def fotogramas(l1, l2, cols, efecto, crudos=(None, None)):
    """Lista de cuadros [(línea1, línea2)…] del efecto y si se repite sin fin. Un solo cuadro = sin animación.
    'crudos' = texto completo de cada línea que admite efecto (None = la línea no se anima)."""
    if efecto not in EFECTOS or efecto == "ninguno" or crudos[0] is None and crudos[1] is None:
        return [(l1, l2)], False
    cols = max(8, min(40, int(cols or 20)))
    a, ra = _cuadros_linea(crudos[0], cols, efecto) if crudos[0] is not None else ([l1], False)
    b, rb = _cuadros_linea(crudos[1], cols, efecto) if crudos[1] is not None else ([l2], False)
    n = max(len(a), len(b))
    cuadros = [(a[i % len(a)] if (i < len(a) or ra) else a[-1], b[i % len(b)] if (i < len(b) or rb) else b[-1]) for i in range(n)]
    if n > 1 and cuadros[-1] != (l1, l2) and not (ra or rb):
        cuadros.append((l1, l2))   # los efectos de una sola vez terminan en el texto de siempre
    return cuadros, bool(ra or rb)


# ------------------------------------------------------------------ puertos serie del equipo
def _libre(ruta):
    try:
        fd = os.open(ruta, os.O_RDWR | getattr(os, "O_NOCTTY", 0) | getattr(os, "O_NONBLOCK", 0) | getattr(os, "O_BINARY", 0))
        os.close(fd)
        return True
    except OSError:
        return False


def puertos_serie():
    """Puertos COM del equipo: [{puerto, nombre, libre}]. Sin dependencias (registro de Windows / /dev en Linux)."""
    falsos = os.environ.get("ALLAS_PUERTOS_PRUEBA")   # solo para pruebas: "COM3|USB Serial Port|1;COM4||0"
    if falsos is not None:
        sal = []
        for x in filter(None, falsos.split(";")):
            p, n, f = (x.split("|") + ["", "1"])[:3]
            sal.append({"puerto": p, "nombre": n, "libre": f != "0"})
        return sal
    sal = []
    if os.name == "nt":
        nombres = {}
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DEVICEMAP\SERIALCOMM") as k:
                i = 0
                while True:
                    try:
                        _, v, _ = winreg.EnumValue(k, i)
                    except OSError:
                        break
                    nombres[str(v)] = ""
                    i += 1
        except Exception as e_:
            errores.fallo("visor.puertos_serie", e_)
        if nombres:
            try:   # nombre «amistoso» (p. ej. «USB Serial Port (COM3)») si PowerShell lo da
                r = subprocess.run(["powershell", "-NoProfile", "-Command", "Get-CimInstance Win32_PnPEntity | Where-Object { $_.Name -match '\\(COM\\d+\\)' } | ForEach-Object { $_.Name }"],
                                   capture_output=True, timeout=8, creationflags=0x08000000)
                for linea in r.stdout.decode("utf-8", "replace").splitlines():
                    import re
                    m = re.search(r"\((COM\d+)\)", linea)
                    if m and m.group(1) in nombres:
                        nombres[m.group(1)] = re.sub(r"\s*\(COM\d+\)", "", linea).strip()
            except Exception as e_:
                errores.fallo("visor.puertos_serie", e_)
        for p in sorted(nombres, key=lambda x: (len(x), x)):
            sal.append({"puerto": p, "nombre": nombres[p], "libre": _libre("\\\\.\\" + p)})
        return sal
    import glob
    vistos = set()
    for patron in ("/dev/ttyUSB*", "/dev/ttyACM*", "/dev/ttyAMA*", "/dev/rfcomm*", "/dev/ttyS*"):
        for ruta in sorted(glob.glob(patron)):
            base = os.path.basename(ruta)
            if ruta in vistos or (base.startswith("ttyS") and not os.path.exists(f"/sys/class/tty/{base}/device/driver")):
                continue
            vistos.add(ruta)
            nombre = ""
            d = os.path.realpath(f"/sys/class/tty/{base}/device")
            for _ in range(4):
                pr = os.path.join(d, "product")
                if os.path.exists(pr):
                    try:
                        nombre = open(pr, encoding="utf-8", errors="replace").read().strip()
                    except OSError:
                        pass
                    break
                d = os.path.dirname(d)
            sal.append({"puerto": ruta, "nombre": nombre, "libre": _libre(ruta)})
    return sal


# ------------------------------------------------------------------ envío
_puertos_configurados = set()
FORMATOS_SERIE = ("8N1", "7E1", "7O1", "8E1", "8O1", "7N1", "8N2")


def _formato(f):
    m = re.fullmatch(r"([78])([NEO])([12])", (f or "8N1").upper())
    return (int(m.group(1)), m.group(2), int(m.group(3))) if m else (8, "N", 1)


def _configurar_serie(puerto, baudios, formato="8N1"):
    """Linux/otros: stty (se recuerda para no repetirlo en cada mensaje)."""
    clave = (puerto, baudios, formato)
    if clave in _puertos_configurados:
        return
    bits, par_, stop = _formato(formato)
    try:
        if os.name == "nt":
            subprocess.run(["mode", f"{puerto}:", f"BAUD={baudios}", f"PARITY={par_}", f"DATA={bits}", f"STOP={stop}"],
                           shell=True, capture_output=True, timeout=5)
        else:
            flags = [f"cs{bits}", "cstopb" if stop == 2 else "-cstopb"] + (["-parenb"] if par_ == "N" else ["parenb", "parodd" if par_ == "O" else "-parodd"])
            subprocess.run(["stty", "-F", puerto, str(baudios), "raw", "-echo"] + flags, capture_output=True, timeout=5)
    except Exception:
        pass   # si no se puede configurar, se intenta escribir igualmente
    _puertos_configurados.add(clave)


def _escribir_serie_windows(puerto, datos, baudios, formato):
    """Windows: abre el puerto, fija velocidad/bits/paridad con la API del sistema (sin depender de «mode»), escribe y lo suelta."""
    import ctypes
    from ctypes import wintypes
    k = ctypes.WinDLL("kernel32", use_last_error=True)
    k.CreateFileW.restype = ctypes.c_void_p
    k.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p]
    for fn in (k.GetCommState, k.SetCommState, k.WriteFile, k.FlushFileBuffers, k.CloseHandle, k.PurgeComm):
        fn.argtypes = None

    class DCB(ctypes.Structure):
        _fields_ = [("DCBlength", wintypes.DWORD), ("BaudRate", wintypes.DWORD), ("flags", wintypes.DWORD), ("wReserved", wintypes.WORD),
                    ("XonLim", wintypes.WORD), ("XoffLim", wintypes.WORD), ("ByteSize", ctypes.c_ubyte), ("Parity", ctypes.c_ubyte),
                    ("StopBits", ctypes.c_ubyte), ("XonChar", ctypes.c_char), ("XoffChar", ctypes.c_char), ("ErrorChar", ctypes.c_char),
                    ("EofChar", ctypes.c_char), ("EvtChar", ctypes.c_char), ("wReserved1", wintypes.WORD)]
    bits, par_, stop = _formato(formato)
    h = k.CreateFileW("\\\\.\\" + puerto.lstrip("\\.").strip(), 0xC0000000, 0, None, 3, 0, None)
    if h is None or h == ctypes.c_void_p(-1).value:
        raise OSError(f"No se puede abrir {puerto}: {ctypes.FormatError(ctypes.get_last_error())} (¿lo usa otro programa?)")
    try:
        dcb = DCB(); dcb.DCBlength = ctypes.sizeof(DCB)
        if not k.GetCommState(ctypes.c_void_p(h), ctypes.byref(dcb)):
            raise OSError(f"{puerto} no es un puerto serie")
        dcb.BaudRate = int(baudios); dcb.ByteSize = bits
        dcb.Parity = {"N": 0, "O": 1, "E": 2}[par_]; dcb.StopBits = 2 if stop == 2 else 0
        dcb.flags = 1 | ((1 if par_ != "N" else 0) << 1) | (1 << 4) | (1 << 12)   # binario, paridad, DTR y RTS activos, sin control de flujo
        if not k.SetCommState(ctypes.c_void_p(h), ctypes.byref(dcb)):
            raise OSError(f"{puerto} no admite {baudios} baudios {formato}")
        escritos = wintypes.DWORD(0)
        if not k.WriteFile(ctypes.c_void_p(h), datos, len(datos), ctypes.byref(escritos), None):
            raise OSError(f"No se pudo escribir en {puerto}: {ctypes.FormatError(ctypes.get_last_error())}")
        k.FlushFileBuffers(ctypes.c_void_p(h))
    finally:
        k.CloseHandle(ctypes.c_void_p(h))


def enviar(datos, conexion, destino, baudios=9600, preview="", formato="8N1"):
    if conexion == "serie":
        puerto = (destino or "").strip()
        if not puerto:
            raise ValueError("Indique el puerto del visor (p. ej. COM3)")
        if os.name == "nt":
            try:
                _escribir_serie_windows(puerto, datos, int(baudios or 9600), formato)
                return puerto
            except (AttributeError, ImportError):
                pass   # sin API de Windows: por el camino de siempre
        _configurar_serie(puerto, int(baudios or 9600), formato)
        ruta = ("\\\\.\\" + puerto) if os.name == "nt" and not puerto.startswith("\\\\") else puerto
        with open(ruta, "wb", buffering=0) as f:
            f.write(datos)
        return puerto
    if conexion == "red":
        host, _, port = (destino or "").partition(":")
        with socket.create_connection((host, int(port or 9100)), timeout=3) as s:
            s.sendall(datos)
        return destino
    if conexion == "windows":
        impresion._enviar_windows(destino, datos)
        return destino
    if conexion == "programa":   # 3.5: utilidad del fabricante (p. ej. customerdisplay.exe de Posiflex)
        return ejecutar_programa(destino, preview, datos)
    if conexion == "archivo":
        carpeta = destino or "salida_visor"
        if re.fullmatch(r"(?i)(com|lpt)\d+|/dev/.*|[\w.\-]+:\d+", carpeta.strip()):
            carpeta = "salida_visor"   # un puerto o una IP no es una carpeta (en Windows «COM3» ni siquiera se puede crear)
        os.makedirs(carpeta, exist_ok=True)
        with open(os.path.join(carpeta, "visor.txt"), "w", encoding="utf-8") as f:
            f.write(preview)
        with open(os.path.join(carpeta, "visor.bin"), "wb") as f:
            f.write(datos)
        return os.path.join(carpeta, "visor.txt")
    raise ValueError(f"Conexión de visor desconocida: {conexion}")


def comando_programa(plantilla, l1, l2, archivo="", binario=""):
    """Convierte la línea de órdenes configurada en una lista de argumentos.
    Marcadores: {l1} {l2} (las dos líneas), {archivo} (txt con las dos líneas), {bin} (los bytes del protocolo).
    Sin marcadores, se añaden las dos líneas al final."""
    import shlex
    plantilla = (plantilla or "").strip()
    if not plantilla:
        raise ValueError("Indique el programa del visor (p. ej. C:\\Posiflex\\customerdisplay.exe)")
    partes = shlex.split(plantilla, posix=(os.name != "nt"))
    partes = [x[1:-1] if len(x) >= 2 and x[0] == x[-1] == '"' else x for x in partes]
    marcas = ("{l1}", "{l2}", "{archivo}", "{bin}")
    if not any(m in plantilla for m in marcas):
        partes += ["{l1}", "{l2}"]
    valores = {"{l1}": l1, "{l2}": l2, "{archivo}": archivo, "{bin}": binario}
    salida = []
    for x in partes:
        for m, v in valores.items():
            x = x.replace(m, v)
        salida.append(x)
    return salida


def ejecutar_programa(plantilla, texto, datos):
    import tempfile
    l1, _, l2 = (texto or "").partition("\n")
    carpeta = os.path.join(tempfile.gettempdir(), "proyecto_allas_visor")
    os.makedirs(carpeta, exist_ok=True)
    archivo, binario = os.path.join(carpeta, "visor.txt"), os.path.join(carpeta, "visor.bin")
    with open(archivo, "w", encoding="cp1252", errors="replace") as f:
        f.write(l1 + "\r\n" + l2 + "\r\n")
    with open(binario, "wb") as f:
        f.write(datos)
    args = comando_programa(plantilla, l1, l2, archivo, binario)
    extra = {"creationflags": 0x08000000} if os.name == "nt" else {}   # sin ventana negra
    r = subprocess.run(args, capture_output=True, timeout=10, **extra)
    if r.returncode != 0:
        raise ValueError(f"El programa del visor terminó con error {r.returncode}: "
                         + (r.stderr or r.stdout or b"").decode("utf-8", "replace").strip()[:200])
    return args[0]


class Visor:
    """Cola de un solo elemento: siempre se envía el último mensaje pendiente. Con efecto, un hilo aparte reenvía los
    cuadros; cualquier mensaje nuevo (o el de reposo de nuevo) lo corta."""

    def __init__(self):
        self.ultimo = ("", "")
        self.error = None
        self._cola = queue.Queue(maxsize=1)
        self._hilo = None
        self._cerrojo = threading.RLock()
        self._gen = 0            # número del mensaje en curso: una animación se para si ya no es el suyo
        self._firma = None
        self._anim = None

    def mostrar(self, l1, l2, cfg, esperar=False, crudos=(None, None)):
        cuadros, repetir = [(l1, l2)], False
        efecto = cfg.get("efecto") or "ninguno"
        if efecto != "ninguno" and efectos_permitidos(cfg.get("conexion") or "archivo"):
            cuadros, repetir = fotogramas(l1, l2, cfg.get("columnas") or 20, efecto, crudos)
        firma = (l1, l2, efecto, tuple(crudos), cfg.get("conexion"), cfg.get("destino"))
        if len(cuadros) > 1 and not esperar and firma == self._firma and self._anim is not None and self.error is None:
            return None   # el mismo mensaje con efecto ya está en marcha (o terminó): no se reinicia
        self._gen += 1
        gen = self._gen
        self._firma = firma
        self.ultimo = (l1, l2)
        proto = cfg.get("protocolo") or "epson"
        if len(cuadros) > 1:
            primero = (bytes_visor(*cuadros[0], proto), cfg, "\n".join(cuadros[0]))
            if esperar:   # prueba desde Ajustes: el primer cuadro se envía ya (y se informa del error)
                destino = self._enviar(primero)
            else:
                destino = None
            ritmo = VELOCIDADES.get(cfg.get("velocidad") or "normal", VELOCIDADES["normal"])
            self._anim = threading.Thread(target=self._animar, args=(gen, cuadros[0 if not esperar else 1:], repetir, ritmo, cfg, proto, cuadros), daemon=True, name="visor-efecto")
            self._anim.start()
            return destino
        tarea = (bytes_visor(l1, l2, proto), cfg, l1 + "\n" + l2)
        if esperar:
            return self._enviar(tarea)
        try:
            self._cola.get_nowait()
        except queue.Empty:
            pass
        try:
            self._cola.put_nowait(tarea)
        except queue.Full:
            pass
        if not self._hilo or not self._hilo.is_alive():
            self._hilo = threading.Thread(target=self._bucle, daemon=True, name="visor")
            self._hilo.start()
        return None

    def _animar(self, gen, cuadros, repetir, ritmo, cfg, proto, todos):
        primera = True
        while True:
            for c in (cuadros if primera else todos):
                if gen != self._gen:
                    return
                try:
                    with self._cerrojo:
                        if gen != self._gen:
                            return
                        self._enviar((bytes_visor(c[0], c[1], proto), cfg, c[0] + "\n" + c[1]))
                except Exception as e:
                    print("Visor TPV:", e, file=sys.stderr)
                    return
                fin = time.monotonic() + ritmo
                while time.monotonic() < fin:
                    if gen != self._gen:
                        return
                    time.sleep(0.03)
            primera = False
            if not repetir:
                return

    def _enviar(self, tarea):
        datos, cfg, texto = tarea
        try:
            with self._cerrojo:
                r = enviar(datos, cfg.get("conexion") or "archivo", cfg.get("destino"), cfg.get("baudios") or 9600, texto, cfg.get("formato") or "8N1")
            self.error = None
            return r
        except Exception as e:
            self.error = str(e)
            raise

    def _bucle(self):
        while True:
            try:
                tarea = self._cola.get(timeout=30)
            except queue.Empty:
                return
            try:
                self._enviar(tarea)
            except Exception as e:
                print("Visor TPV:", e, file=sys.stderr)


VISOR = Visor()   # uno por programa (lo comparten todos los puestos que cobran en este servidor)
