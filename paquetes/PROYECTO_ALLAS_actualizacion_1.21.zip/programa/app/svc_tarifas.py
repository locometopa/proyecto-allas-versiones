"""PROYECTO ALLAS · lógica de negocio: tarifas y su cálculo (1.4: sale de servicios.py; se mezcla en la clase Parking)."""
import re
from datetime import timedelta

from .tarifas import REDONDEOS
from .tarifas import calcular_importe
from .tarifas import validar_tramos
from .utiles import ErrorNegocio


class SvcTarifas:
    # ============================================================= tarifas
    def tarifas(self):
        ts = self.db.q("SELECT * FROM tarifas WHERE eliminada=0 ORDER BY orden, por_defecto DESC, activa DESC, nombre")
        for t in ts:
            t["tramos"] = self.db.q("SELECT desde_min, hasta_min, fraccion_min, precio_mil "
                                    "FROM tarifa_tramos WHERE tarifa_id=? ORDER BY desde_min", (t["id"],))
        return ts

    def ordenar_tarifas(self, ids, actor_id):
        """4.43: orden de las tarifas en el selector de Entrada (la lista completa, de arriba abajo)."""
        try:
            ids = [int(x) for x in ids]
        except (TypeError, ValueError):
            raise ErrorNegocio("Orden de tarifas no válido")
        with self.db.transaccion() as c:
            for i, tid in enumerate(ids, 1):
                c.execute("UPDATE tarifas SET orden=? WHERE id=?", (i, tid))
            self.auditar(c, actor_id, "tarifas_orden", ",".join(map(str, ids)))
        return self.tarifas()

    def tarifa(self, tid):
        t = self.db.q1("SELECT * FROM tarifas WHERE id=?", (tid,))
        if not t:
            raise ErrorNegocio("Tarifa no encontrada", 404)
        t["tramos"] = self.db.q("SELECT desde_min, hasta_min, fraccion_min, precio_mil "
                                "FROM tarifa_tramos WHERE tarifa_id=? ORDER BY desde_min", (tid,))
        return t

    @staticmethod
    def _validar_tarifa(datos):
        modo = datos.get("modo") or "tramos"
        if modo not in ("tramos", "hibrida", "reserva"):
            raise ErrorNegocio("Tipo de tarifa no válido")
        try:
            tramos = [{"desde_min": int(t["desde_min"]),
                       "hasta_min": None if t.get("hasta_min") in (None, "") else int(t["hasta_min"]),
                       "fraccion_min": int(t["fraccion_min"]),
                       "precio_mil": int(t["precio_mil"])} for t in datos.get("tramos", [])] if modo != "reserva" else []
            if modo != "reserva":
                validar_tramos(tramos)
        except (ValueError, KeyError, TypeError) as e:
            raise ErrorNegocio(f"Tramos no válidos: {e}")
        nombre = (datos.get("nombre") or "").strip()
        if not nombre:
            raise ErrorNegocio("La tarifa necesita un nombre")
        reserva = {"reserva_modo": None, "reserva_min": None, "reserva_noches": None, "reserva_hora": None,
                   "tarifa_despues_id": None, "tarifa_despues": None}
        if modo == "reserva":   # 4.2: reservas / hotel
            rm = datos.get("reserva_modo") or "noches"
            if rm == "horas":   # 4.43: la reserva por horas pasó a ser por fecha
                rm = "fecha"
            if rm not in ("fecha", "noches"):
                raise ErrorNegocio("Indique si la reserva es por fecha o por noches")
            try:
                reserva["reserva_modo"] = rm
                if rm == "fecha":
                    hora = (datos.get("reserva_hora") or "12:00").strip()   # hora de salida que se propone al escribir la fecha de salida
                    if not re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", hora):
                        raise ValueError
                    reserva["reserva_hora"] = hora
                else:
                    reserva["reserva_noches"] = int(datos.get("reserva_noches") or 1)
                    hora = (datos.get("reserva_hora") or "12:00").strip()
                    if not 1 <= reserva["reserva_noches"] <= 60 or not re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", hora):
                        raise ValueError
                    reserva["reserva_hora"] = hora
            except (ValueError, TypeError):
                raise ErrorNegocio("Tiempo de la reserva no válido (noches de 1 a 60 y hora de salida HH:MM)")
            reserva["tarifa_despues_id"] = int(datos["tarifa_despues_id"]) if str(datos.get("tarifa_despues_id") or "").isdigit() else None
            reserva["tarifa_despues"] = (datos.get("tarifa_despues") or "").strip() or None
            if datos.get("por_defecto"):
                raise ErrorNegocio("Una tarifa de reserva no puede ser la tarifa por defecto")
        if modo == "hibrida":   # 4.2: precio fijo durante un tiempo y, pasado ese tiempo, otro precio
            t0 = tramos[0]
            if len(tramos) != 2 or t0["hasta_min"] is None or t0["fraccion_min"] != t0["hasta_min"]:
                raise ErrorNegocio("Tarifa híbrida no válida: indique el tiempo del precio fijo y el precio de después")
        maximo = datos.get("maximo_diario_cent")
        redondeo = datos.get("redondeo") or "ninguno"
        if redondeo not in REDONDEOS:
            raise ErrorNegocio("Modo de redondeo no válido")
        # 3.9: horario de aplicación (tarifa automática por días y/o franja horaria)
        dias = "".join(sorted({d for d in str(datos.get("horario_dias") or "") if d in "1234567"}))
        desde, hasta = (datos.get("horario_desde") or "").strip(), (datos.get("horario_hasta") or "").strip()
        for h in (desde, hasta):
            if h and not re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", h):
                raise ErrorNegocio("Hora del horario no válida (use HH:MM)")
        if bool(desde) != bool(hasta) or (desde and desde == hasta):
            raise ErrorNegocio("Indique la hora de inicio y la de fin del horario (distintas)")
        if dias == "1234567" and not desde:
            dias = ""
        if modo == "reserva":
            dias, desde, hasta = "", "", ""
        # 4.3: tipo de vehículo (moto, furgoneta…) y fechas de evento (partido, concierto…)
        tipo_veh = (str(datos.get("tipo_vehiculo") or "").strip()[:30] or None) if modo != "reserva" else None
        ev_d, ev_h = (str(datos.get("evento_desde") or "").strip() or None), (str(datos.get("evento_hasta") or "").strip() or None)
        if modo == "reserva":
            ev_d = ev_h = None
        for x in (ev_d, ev_h):
            if x and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", x):
                raise ErrorNegocio("Fechas del evento no válidas")
        if ev_h and not ev_d:
            ev_d = ev_h
        if ev_d and ev_h and ev_h < ev_d:
            raise ErrorNegocio("La fecha de fin del evento es anterior a la de inicio")
        if (tipo_veh or ev_d) and datos.get("por_defecto"):
            raise ErrorNegocio("La tarifa por defecto no puede ser de un evento ni de un tipo de vehículo")
        try:
            return {"nombre": nombre[:80], "tramos": tramos,
                    "horario_dias": dias or None, "horario_desde": desde or None, "horario_hasta": hasta or None,
                    "maximo_diario_cent": None if maximo in (None, "") else int(maximo),
                    "gracia_min": int(datos.get("gracia_min") or 0),
                    "por_defecto": 1 if datos.get("por_defecto") else 0,
                    "activa": 0 if datos.get("activa") in (False, 0) else 1,
                    "redondeo": redondeo, "modo": modo, **reserva,
                    "tipo_vehiculo": tipo_veh, "evento_desde": ev_d, "evento_hasta": ev_h or ev_d,
                    "texto_ticket": (datos.get("texto_ticket") or "").strip()[:300] or None}
        except (ValueError, TypeError):
            raise ErrorNegocio(f"Datos no válidos en la tarifa {nombre}")

    def _escribir_tarifa(self, c, v, tid=None):
        if v.get("modo") == "reserva" and not v.get("tarifa_despues_id"):
            ref = None
            if v.get("tarifa_despues"):   # por nombre (importar)
                ref = c.execute("SELECT id FROM tarifas WHERE activa=1 AND eliminada=0 AND lower(nombre)=lower(?) "
                                "AND COALESCE(modo,'tramos')<>'reserva'", (v["tarifa_despues"],)).fetchone()
            v = {**v, "tarifa_despues_id": ref[0] if ref else None}
        orden = (c.execute("SELECT orden FROM tarifas WHERE id=?", (tid,)).fetchone() or [None])[0] if tid else None
        if orden is None:
            orden = (c.execute("SELECT COALESCE(MAX(orden),0)+1 FROM tarifas").fetchone() or [1])[0]
        if tid:
            # Las tarifas usadas por tickets no se reescriben: se crea una nueva versión
            # y la antigua se desactiva, para que los tickets ya emitidos cobren
            # exactamente lo anunciado al entrar.
            usada = c.execute("SELECT 1 FROM tickets WHERE tarifa_id=? OR reserva_tarifa_id=? LIMIT 1", (tid, tid)).fetchone()
            if usada:
                c.execute("UPDATE tarifas SET activa=0, por_defecto=0 WHERE id=?", (tid,))
                tid = None
            else:
                c.execute("UPDATE tarifas SET nombre=?, gracia_min=?, maximo_diario_cent=?, activa=?, "
                          "por_defecto=?, redondeo=?, texto_ticket=?, horario_dias=?, horario_desde=?, horario_hasta=?, modo=? WHERE id=?",
                          (v["nombre"], v["gracia_min"], v["maximo_diario_cent"], v["activa"], v["por_defecto"],
                           v["redondeo"], v["texto_ticket"], v.get("horario_dias"), v.get("horario_desde"),
                           v.get("horario_hasta"), v.get("modo") or "tramos", tid))
                c.execute("DELETE FROM tarifa_tramos WHERE tarifa_id=?", (tid,))
        if not tid:
            tid = c.execute("INSERT INTO tarifas(nombre, gracia_min, maximo_diario_cent, activa, por_defecto, "
                            "redondeo, texto_ticket, horario_dias, horario_desde, horario_hasta, modo) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                            (v["nombre"], v["gracia_min"], v["maximo_diario_cent"], v["activa"], v["por_defecto"],
                             v["redondeo"], v["texto_ticket"], v.get("horario_dias"), v.get("horario_desde"),
                             v.get("horario_hasta"), v.get("modo") or "tramos")).lastrowid
        c.execute("UPDATE tarifas SET orden=? WHERE id=?", (orden, tid))
        c.execute("UPDATE tarifas SET reserva_modo=?, reserva_min=?, reserva_noches=?, reserva_hora=?, tarifa_despues_id=?, "
                  "tipo_vehiculo=?, evento_desde=?, evento_hasta=? WHERE id=?",
                  (v.get("reserva_modo"), v.get("reserva_min"), v.get("reserva_noches"), v.get("reserva_hora"),
                   v.get("tarifa_despues_id"), v.get("tipo_vehiculo"), v.get("evento_desde"), v.get("evento_hasta"), tid))
        for t in v["tramos"]:
            c.execute("INSERT INTO tarifa_tramos(tarifa_id, desde_min, hasta_min, fraccion_min, precio_mil) "
                      "VALUES(?,?,?,?,?)", (tid, t["desde_min"], t["hasta_min"], t["fraccion_min"], t["precio_mil"]))
        if v["por_defecto"]:
            c.execute("UPDATE tarifas SET por_defecto=0 WHERE id<>?", (tid,))
        return tid

    def guardar_tarifa(self, datos, actor_id, tid=None):
        v = self._validar_tarifa(datos)
        with self.db.transaccion() as c:
            tid = self._escribir_tarifa(c, v, tid)
            if not c.execute("SELECT 1 FROM tarifas WHERE por_defecto=1 AND activa=1").fetchone():
                raise ErrorNegocio("Debe haber una tarifa activa marcada por defecto")
            self.auditar(c, actor_id, "tarifa_guardar", f"id={tid} {v['nombre']}")
        return tid

    def eliminar_tarifa(self, tid, actor_id):
        """Borra una tarifa. Si ya la usó algún ticket se oculta (los tickets la siguen necesitando
        para calcular su importe); si no, se borra del todo."""
        with self.db.transaccion() as c:
            t = c.execute("SELECT nombre, activa, por_defecto FROM tarifas WHERE id=? AND eliminada=0", (tid,)).fetchone()
            if not t:
                raise ErrorNegocio("Tarifa no encontrada", 404)
            if t[1] and t[2]:
                raise ErrorNegocio("Es la tarifa por defecto: marque otra como «por defecto» antes de eliminarla")
            if c.execute("SELECT 1 FROM tickets WHERE tarifa_id=? AND estado IN ('dentro','pagado') LIMIT 1",
                         (tid,)).fetchone():
                aviso = " Los vehículos que están dentro con ella la seguirán pagando."
            else:
                aviso = ""
            if c.execute("SELECT 1 FROM tickets WHERE tarifa_id=? OR reserva_tarifa_id=? LIMIT 1", (tid, tid)).fetchone():
                c.execute("UPDATE tarifas SET eliminada=1, activa=0, por_defecto=0 WHERE id=?", (tid,))
                modo = "oculta"
            else:
                c.execute("DELETE FROM tarifa_tramos WHERE tarifa_id=?", (tid,))
                c.execute("DELETE FROM tarifas WHERE id=?", (tid,))
                modo = "borrada"
            if not c.execute("SELECT 1 FROM tarifas WHERE por_defecto=1 AND activa=1").fetchone():
                raise ErrorNegocio("Debe quedar una tarifa activa por defecto")
            self.auditar(c, actor_id, "tarifa_eliminar", f"id={tid} {t[0]} ({modo})")
        return {"ok": True, "modo": modo, "aviso": aviso}

    @staticmethod
    def _en_horario(t, momento):
        """¿Aplica la tarifa (con horario) en ese momento? Franjas que cruzan la medianoche (22:00-08:00) cuentan
        para el día en que empiezan: el sábado de 00:00 a 08:00 es la noche del viernes."""
        dias, desde, hasta = t.get("horario_dias"), t.get("horario_desde"), t.get("horario_hasta")
        if not dias and not desde:
            return False
        hm = momento.strftime("%H:%M")
        dia = momento.isoweekday()
        if desde:
            if desde < hasta:
                if not desde <= hm < hasta:
                    return False
            else:   # cruza la medianoche
                if hm >= desde:
                    pass
                elif hm < hasta:
                    dia = (momento - timedelta(days=1)).isoweekday()
                else:
                    return False
        return not dias or str(dia) in dias

    def tarifa_para(self, momento=None, tipo_vehiculo=None):
        """Tarifa que corresponde a una entrada. Por orden: la de un evento en esas fechas, la de horario más concreta,
        la del tipo de vehículo y, si no, la de por defecto (4.3: eventos y tipos de vehículo)."""
        momento = momento or self.ahora()
        if not self.tiene_modulo("tarifas_avanzadas"):
            return self.db.q1("SELECT * FROM tarifas WHERE por_defecto=1 AND activa=1")
        dia = momento.date().isoformat()
        puntos = []
        for t in self.db.q("SELECT * FROM tarifas WHERE activa=1 AND eliminada=0 AND COALESCE(modo,'tramos')<>'reserva' ORDER BY id"):
            if t.get("tipo_vehiculo") and t["tipo_vehiculo"] != tipo_vehiculo:
                continue
            p = 0
            if t.get("evento_desde"):
                if not t["evento_desde"] <= dia <= (t.get("evento_hasta") or t["evento_desde"]):
                    continue
                p += 100
            if t["horario_dias"] or t["horario_desde"]:
                if not self._en_horario(t, momento):
                    continue
                p += 10 + bool(t["horario_dias"]) + bool(t["horario_desde"])
            if t.get("tipo_vehiculo"):
                p += 5
            if p:
                puntos.append((p, -t["id"], t))
        if puntos:
            return max(puntos, key=lambda x: (x[0], x[1]))[2]
        return self.db.q1("SELECT * FROM tarifas WHERE por_defecto=1 AND activa=1")

    def simular(self, tid, minutos):
        t = self.tarifa(tid)
        return calcular_importe(int(minutos), t, t["tramos"])
