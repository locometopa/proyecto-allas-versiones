"""PROYECTO ALLAS 1.16 · web local de pruebas de las reservas de clientes.

Simula la web del aparcamiento en este mismo equipo: sirve la carpeta scripts/integracion_web y reenvía las llamadas
/api/publico/reservas/* al programa, como haría un servidor web con proxy (mismo origen: no necesita CORS).
Se activa y desactiva desde Ajustes → Reservas online → Probar en local (o por línea de comandos con scripts/web_pruebas.py).
Solo vive mientras el programa está abierto: al reiniciar queda desactivada.
"""
import json
import mimetypes
import os
import secrets
import threading
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PREFIJO = "/api/publico/reservas"
PUERTO_BASE = 8090


def carpeta_kit(raiz):
    return os.path.join(raiz, "scripts", "integracion_web")


def crear_handler(programa, web, token=None):
    """programa: dirección del programa (http://127.0.0.1:8080). web: carpeta con reservas.html y reservas.js."""
    web = os.path.abspath(web)

    class Handler(BaseHTTPRequestHandler):
        server_version = "WebPruebasAllas"

        def log_message(self, fmt, *args):
            pass

        def _enviar(self, codigo, cuerpo, tipo):
            self.send_response(codigo)
            self.send_header("Content-Type", tipo)
            self.send_header("Content-Length", str(len(cuerpo)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(cuerpo)

        def _proxy(self):
            n = int(self.headers.get("Content-Length") or 0)
            cuerpo = self.rfile.read(n) if n else None
            req = urllib.request.Request(programa + self.path, data=cuerpo, method=self.command,
                                         headers={"Content-Type": self.headers.get("Content-Type", "application/json"),
                                                  **({"X-Allas-Prueba": token} if token else {})})
            try:
                with urllib.request.urlopen(req, timeout=30) as r:
                    return self._enviar(r.status, r.read(), r.headers.get("Content-Type", "application/json"))
            except urllib.error.HTTPError as e:
                return self._enviar(e.code, e.read(), e.headers.get("Content-Type", "application/json"))
            except OSError:
                return self._enviar(502, json.dumps({"error": "No se puede conectar con el programa: ¿está en marcha?"}).encode(), "application/json")

        def do_GET(self):
            ruta = self.path.split("?")[0]
            if ruta.startswith(PREFIJO):
                return self._proxy()
            if ruta in ("/", "/reservas", "/reservas.html"):
                ruta = "/reservas.html"
            archivo = os.path.normpath(os.path.join(web, ruta.lstrip("/")))
            if os.path.commonpath([archivo, web]) != web or not os.path.isfile(archivo) or archivo.endswith(".md"):
                return self._enviar(404, b"No encontrado", "text/plain")
            with open(archivo, "rb") as f:
                tipo = mimetypes.guess_type(archivo)[0] or "application/octet-stream"
                self._enviar(200, f.read(), tipo + ("; charset=utf-8" if tipo.startswith("text/") or "javascript" in tipo else ""))

        def do_POST(self):
            if self.path.split("?")[0].startswith(PREFIJO):
                return self._proxy()
            self._enviar(404, b"No encontrado", "text/plain")

    return Handler


def buscar_programa(raiz):
    """Dirección del programa en marcha (datos/puerto.txt y luego 8080-8099). Solo para la línea de comandos."""
    puertos = []
    for nombre in ("puerto.txt", "puerto_preferido.txt"):
        for carpeta in (os.path.join(raiz, "datos"), raiz):
            try:
                with open(os.path.join(carpeta, nombre)) as f:
                    puertos.append(int(f.read().strip()))
            except (OSError, ValueError):
                pass
    puertos += range(8080, 8100)
    for p in dict.fromkeys(puertos):
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{p}/api/ping", timeout=0.5) as r:
                if json.loads(r.read()).get("software"):
                    return f"http://127.0.0.1:{p}"
        except Exception:
            continue
    return None


class WebPruebas:
    """Gestor de la web de pruebas dentro del programa (un solo servidor, activable y desactivable)."""

    def __init__(self, app):
        self.app = app
        self.srv = None
        self.red = False
        self.token = secrets.token_hex(16)   # solo lo conoce este proceso: el servidor lo exige para quitar el límite de peticiones
        self._lock = threading.Lock()

    @property
    def activa(self):
        return self.srv is not None

    def activar(self, red=False):
        with self._lock:
            self.parar()
            puerto_programa = getattr(self.app, "puerto", None)
            if not puerto_programa:
                raise OSError("No se conoce el puerto del programa")
            host = "0.0.0.0" if red else "127.0.0.1"
            handler = crear_handler(f"http://127.0.0.1:{puerto_programa}", carpeta_kit(self.app.raiz), self.token)
            ultimo = None
            for puerto in range(PUERTO_BASE, PUERTO_BASE + 10):
                if puerto == puerto_programa:
                    continue
                try:
                    srv = ThreadingHTTPServer((host, puerto), handler)
                except OSError as e:
                    ultimo = e
                    continue
                srv.daemon_threads = True
                threading.Thread(target=srv.serve_forever, daemon=True).start()
                self.srv, self.red = srv, bool(red)
                return
            raise OSError(f"No hay ningún puerto libre entre el {PUERTO_BASE} y el {PUERTO_BASE + 9}: {ultimo}")

    def parar(self):
        srv, self.srv = self.srv, None
        if srv:
            srv.shutdown()
            srv.server_close()

    def estado(self):
        from .codigos import qr_svg
        from .server import ips_locales
        res = {"activa": self.activa, "red": self.red, "url": None, "urls": [], "qr": None, "puerto": None,
               "reservas_listas": bool(self.app.p.reservas_publicas_activas())}
        if self.activa:
            puerto = self.srv.server_address[1]
            ips = ips_locales() if self.red else []
            res["puerto"] = puerto
            res["urls"] = [f"http://{ip}:{puerto}/" for ip in ips] or [f"http://127.0.0.1:{puerto}/"]
            res["url"] = res["urls"][0]
            res["qr"] = qr_svg(res["url"], modulo=6)
        return res
