"""Lectura de listados de clientes en CSV o Excel (.xlsx) sin librerías externas.

- CSV: detecta el separador (; , tabulador |) y la codificación (UTF-8, con o sin BOM, o Windows-1252).
- XLSX: lee la primera hoja (zip + XML). 1.6: también lee el .xls antiguo (tablas.leer_xls). Un PDF no se puede importar.
"""
import csv
import io
import re
import unicodedata
import zipfile
from xml.etree import ElementTree as ET

CAMPOS = [
    ("nombre", "Nombre o razón social"), ("nif", "NIF / CIF"), ("telefono", "Teléfono"), ("email", "Email"),
    ("direccion", "Dirección"), ("matricula", "Matrícula(s)"), ("marca", "Marca"), ("modelo", "Modelo"),
    ("tipo", "Tipo (abonado / facturación)"), ("notas", "Notas"),
]
SINONIMOS = {
    "nombre": ("nombre", "cliente", "razon social", "nombre y apellidos", "nombre completo", "titular", "empresa", "name"),
    "nif": ("nif", "cif", "dni", "nie", "nif cif", "cif nif", "dni nie", "documento", "vat"),
    "telefono": ("telefono", "tel", "movil", "telefono movil", "celular", "phone", "tlf"),
    "email": ("email", "e mail", "correo", "correo electronico", "mail"),
    "direccion": ("direccion", "domicilio", "direccion postal", "address", "calle"),
    "matricula": ("matricula", "matriculas", "placa", "vehiculo", "coche", "plate"),
    "marca": ("marca",),
    "modelo": ("modelo",),
    "tipo": ("tipo", "tipo de cliente", "categoria"),
    "notas": ("notas", "observaciones", "comentarios", "nota"),
}
NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


def _norm(t):
    t = unicodedata.normalize("NFKD", str(t or "")).encode("ascii", "ignore").decode().lower().strip()
    t = t.replace(".", "")
    return re.sub(r"[\s_:/\-]+", " ", t).strip()


def sugerir(cabeceras):
    """{campo: índice de columna} según los nombres de las cabeceras."""
    sug = {}
    for i, c in enumerate(cabeceras):
        n = _norm(c)
        for campo, sins in SINONIMOS.items():
            if campo not in sug and (n in sins or any(n.startswith(s + " ") for s in sins if len(s) > 3)):
                sug[campo] = i
                break
    return sug


def leer_csv(datos):
    for cod in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            texto = datos.decode(cod)
            break
        except UnicodeDecodeError:
            continue
    muestra = texto[:5000]
    try:
        dialecto = csv.Sniffer().sniff(muestra, delimiters=";,\t|")
        sep = dialecto.delimiter
    except csv.Error:
        sep = max(";,\t|", key=muestra.count)
    return [fila for fila in csv.reader(io.StringIO(texto), delimiter=sep)]


def _col(ref):
    letras = re.match(r"[A-Z]+", ref).group(0)
    n = 0
    for ch in letras:
        n = n * 26 + ord(ch) - 64
    return n - 1


def leer_xlsx(datos):
    try:
        z = zipfile.ZipFile(io.BytesIO(datos))
    except zipfile.BadZipFile:
        raise ValueError("El archivo no es un Excel .xlsx válido. Si es un .xls antiguo, ábralo en Excel y guárdelo como .xlsx o .csv.")
    compartidas = []
    if "xl/sharedStrings.xml" in z.namelist():
        for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall("m:si", NS):
            compartidas.append("".join(t.text or "" for t in si.iter("{%s}t" % NS["m"])))
    # primera hoja según el libro (no siempre se llama sheet1.xml)
    hoja = "xl/worksheets/sheet1.xml"
    try:
        libro = ET.fromstring(z.read("xl/workbook.xml"))
        rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        primera = libro.find("m:sheets/m:sheet", NS)
        rid = primera.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
        for r in rels:
            if r.get("Id") == rid:
                destino = r.get("Target").lstrip("/")
                hoja = destino if destino.startswith("xl/") else "xl/" + destino
    except (KeyError, AttributeError, ET.ParseError):
        pass
    filas = []
    for fila in ET.fromstring(z.read(hoja)).iter("{%s}row" % NS["m"]):
        valores = {}
        for c in fila.findall("m:c", NS):
            t, ref = c.get("t"), c.get("r") or ""
            v = c.find("m:v", NS)
            if t == "s" and v is not None:
                val = compartidas[int(v.text)]
            elif t == "inlineStr":
                val = "".join(x.text or "" for x in c.iter("{%s}t" % NS["m"]))
            elif v is not None and v.text is not None:
                val = v.text
                if re.fullmatch(r"-?\d+\.0", val):
                    val = val[:-2]
                elif re.fullmatch(r"-?\d+(\.\d+)?E\+?\d+", val, re.I):   # teléfonos guardados como número
                    val = str(int(float(val)))
            else:
                val = ""
            if ref:
                valores[_col(ref)] = val
        if valores:
            ancho = max(valores) + 1
            filas.append([valores.get(i, "") for i in range(ancho)])
    return filas


def leer(datos, nombre=""):
    nombre = (nombre or "").lower()
    if datos[:4] == bytes.fromhex("D0CF11E0"):   # 1.6: Excel antiguo (.xls)
        from . import tablas
        try:
            filas = tablas.leer_xls(datos)
        except ValueError:
            raise
        except Exception:
            raise ValueError("No se pudo leer el archivo .xls. Ábralo en Excel y guárdelo como .xlsx o .csv.")
    elif datos[:2] == b"PK":
        filas = leer_xlsx(datos)
    elif nombre.endswith(".pdf") or datos[:4] == b"%PDF":
        raise ValueError("Los PDF no se pueden importar (no tienen columnas fiables). Use Excel (.xlsx, .xls) o CSV.")
    else:
        filas = leer_csv(datos)
    filas = [[(c or "").strip() for c in f] for f in filas if any((c or "").strip() for c in f)]
    if not filas:
        raise ValueError("El archivo está vacío")
    ancho = max(len(f) for f in filas)
    return [f + [""] * (ancho - len(f)) for f in filas]
