"""Registro de los fallos que el programa absorbe para no interrumpir al usuario (1.2).

Antes, varios bloques `except Exception: pass` tragaban el error sin dejar rastro. Ahora cada uno llama a
`fallo()`: el error queda en el log del servidor (consola / `allas.log`) y, si es de los que dejan una
función sin hacer su trabajo (`grave=True`), también aparece como aviso en la campana de notificaciones
del administrador. La lista vive en memoria (se vacía al reiniciar) y guarda como mucho los últimos 50.
"""
import logging
import threading
import time
from collections import deque

_log = logging.getLogger("allas")
if not _log.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s", "%Y-%m-%d %H:%M:%S"))
    _log.addHandler(_h)
    _log.setLevel(logging.INFO)
    _log.propagate = False

_lock = threading.Lock()
_recientes = deque(maxlen=50)
VENTANA_AVISO = 24 * 3600


def fallo(donde, exc, grave=False):
    """Anota un error absorbido. `donde` identifica el sitio (p. ej. 'avisos: alertas operativas')."""
    _log.log(logging.ERROR if grave else logging.WARNING, "%s: %s: %s", donde, type(exc).__name__, exc)
    with _lock:
        _recientes.append({"ts": time.time(), "donde": donde, "error": f"{type(exc).__name__}: {exc}"[:300], "grave": bool(grave)})


def recientes(solo_graves=False, desde=None):
    corte = time.time() - (desde if desde is not None else VENTANA_AVISO)
    with _lock:
        return [e for e in _recientes if e["ts"] >= corte and (e["grave"] or not solo_graves)]


def vaciar():
    with _lock:
        _recientes.clear()
