"""PROYECTO ALLAS · lógica de negocio: clientes, abonados, bonos, deudas, vehículos de cliente y proveedores (1.4: sale de servicios.py; se mezcla en la clase Parking)."""
import re
import secrets
from datetime import date, datetime, timedelta

from . import errores
from . import logo as logos
from .utiles import ErrorNegocio, ROLES_SUPERVISION, _norm_txt, email_valido, eur, fecha_es, iso, norm_matricula, sumar_meses


class SvcClientes:
    def abonados_listado(self, estado="todos", buscar=""):
        """Todos los abonados con sus datos, vehículos y situación del bono."""
        salida = []
        for c in self.clientes(buscar, "abonado"):
            cli = self.db.q1("SELECT * FROM clientes WHERE id=?", (c["id"],))
            b = c["bono"]
            est = b["estado"]
            if estado == "vigentes" and est not in ("vigente", "caduca"):
                continue
            if estado == "caducados" and est != "caducado":
                continue
            if estado == "pendientes" and not b.get("pendiente"):
                continue
            sus = self.db.q1("SELECT estado FROM suscripciones WHERE cliente_id=? AND estado<>'cancelada' ORDER BY id DESC "
                             "LIMIT 1", (c["id"],))
            salida.append({"id": c["id"], "codigo": cli["codigo"], "nombre": cli["nombre"], "nif": cli["nif"],
                           "telefono": cli["telefono"], "email": cli["email"], "direccion": cli["direccion"],
                           "activo": cli["activo"], "renovacion_auto": cli["renovacion_auto"],
                           "vehiculos": self.vehiculos_cliente(c["id"]), "bono": b,
                           "suscripcion": sus["estado"] if sus else None})
        return salida

    def csv_abonados(self, estado="todos", buscar="", fecha="bono", dia=None, hora=None):
        """Una línea por matrícula: fin del bono a las 23:59 (o la fecha y hora indicadas)."""
        fijo = self._momento_fijo(dia, hora) if fecha == "fija" else None
        lineas = []
        for a in self.abonados_listado(estado, buscar):
            if fijo:
                m = fijo
            elif a["bono"].get("hasta"):
                d = date.fromisoformat(a["bono"]["hasta"])
                hh, mm = (int(x) for x in (hora or "23:59").split(":")) if hora else (23, 59)
                m = datetime(d.year, d.month, d.day, hh, mm)
            else:
                continue
            for v in a["vehiculos"]:
                lineas.append(self._linea_matricula(v["matricula"], m))
        return "\r\n".join(lineas) + ("\r\n" if lineas else "")

    def pdf_abonados(self, estado="todos", buscar=""):
        from . import VERSION_COMPLETA
        from .pdf import listado_a_pdf
        cfg = self.db.config()
        nombres = {"vigente": "Vigente", "caduca": "Caduca pronto", "caducado": "Caducado", "futuro": "Futuro",
                   "sin_bono": "Sin bono"}
        filas = []
        for a in self.abonados_listado(estado, buscar):
            b = a["bono"]
            est = nombres.get(b["estado"], b["estado"]) + (" · pago pendiente" if b.get("pendiente") else "")
            filas.append([a["nombre"], a["nif"] or "", a["telefono"] or "", a["email"] or "",
                          ", ".join(v["matricula"] + (f" ({' '.join(x for x in (v['marca'], v['modelo']) if x)})"
                                                      if v["marca"] or v["modelo"] else "") for v in a["vehiculos"]),
                          b.get("plan") or "", fecha_es(b["hasta"]) if b.get("hasta") else "—", est,
                          "Sí" if a["renovacion_auto"] else "No"])
        titulos = {"todos": "Todos", "vigentes": "Con bono vigente", "caducados": "Con bono caducado",
                   "pendientes": "Con pago pendiente"}
        return listado_a_pdf({
            "titulo": "Listado de abonados", "subtitulo": f"{titulos.get(estado, estado)} · {self.ahora().strftime('%d/%m/%Y %H:%M')}",
            "empresa": f"{cfg.get('nombre_parking', '')} · {cfg.get('razon_social', '')}",
            "columnas": [("Abonado", 15, "izq"), ("NIF/CIF", 8, "izq"), ("Teléfono", 8, "izq"), ("Email", 15, "izq"),
                         ("Vehículos", 18, "izq"), ("Bono", 11, "izq"), ("Válido hasta", 8, "izq"), ("Estado", 11, "izq"),
                         ("Renov.", 5, "izq")],
            "filas": filas, "resumen": f"{len(filas)} abonado(s)", "marca": VERSION_COMPLETA,
            "logo": logos.jpeg(self.carpeta_logo) if cfg.get("logo_factura") == "1" else None,
            "sello": logos.jpeg_sello(self.carpeta_logo) if cfg.get("sello_factura", "1") != "0" else None})

    # ==================================================== clientes y bonos
    def bono_vigente(self, cliente_id, dia=None):
        """Bono que cubre el día. Una renovación automática sin pagar vale durante los días de gracia."""
        dia = (dia or self.ahora().date()).isoformat()
        gracia = int(self.cfg("renovacion_dias_gracia") or 0)
        return self.db.q1("SELECT b.*, p.nombre plan_nombre FROM bonos b JOIN planes_bono p ON p.id=b.plan_id "
                          "WHERE b.cliente_id=? AND b.estado='activo' AND b.desde<=? AND b.hasta>=? "
                          "AND (b.pagado=1 OR date(b.desde, '+' || ? || ' days') > ?) "
                          "ORDER BY b.hasta DESC LIMIT 1", (cliente_id, dia, dia, gracia, dia))

    def bono_pendiente(self, cliente_id):
        b = self.db.q1("SELECT b.*, p.nombre plan_nombre FROM bonos b JOIN planes_bono p ON p.id=b.plan_id "
                       "WHERE b.cliente_id=? AND b.estado='activo' AND b.pagado=0 ORDER BY b.desde LIMIT 1", (cliente_id,))
        if b:
            gracia = int(self.cfg("renovacion_dias_gracia") or 0)
            b["numero_txt"] = self.numero_bono(b["numero"])
            b["pagar_antes"] = (date.fromisoformat(b["desde"]) + timedelta(days=gracia)).isoformat()
            b.update(self.saldo_bono(b["id"]))
        return b

    def saldo_bono(self, bono_id, c=None):
        """Lo cobrado de un bono, lo cancelado a mano y lo que queda por pagar."""
        if c is not None:
            imp, canc = c.execute("SELECT importe_cent, cancelado_cent FROM bonos WHERE id=?", (bono_id,)).fetchone()
            pagado = c.execute("SELECT COALESCE(SUM(importe_cent),0) FROM pagos WHERE bono_id=?", (bono_id,)).fetchone()[0]
        else:
            r = self.db.q1("SELECT importe_cent, cancelado_cent, (SELECT COALESCE(SUM(importe_cent),0) FROM pagos "
                           "WHERE bono_id=b.id) pagado FROM bonos b WHERE id=?", (bono_id,))
            imp, canc, pagado = r["importe_cent"], r["cancelado_cent"], r["pagado"]
        return {"total_cent": imp, "pagado_cent": pagado, "cancelado_cent": canc or 0,
                "pendiente_cent": max(0, imp - pagado - (canc or 0))}

    def deudas_cliente(self, cliente_id):
        """Bonos activos sin pagar del todo, del más antiguo al más reciente."""
        filas = self.db.q("SELECT b.id, b.numero, b.desde, b.hasta, b.importe_cent, p.nombre plan_nombre FROM bonos b "
                          "JOIN planes_bono p ON p.id=b.plan_id WHERE b.cliente_id=? AND b.estado='activo' AND b.pagado=0 "
                          "ORDER BY b.desde", (cliente_id,))
        for f in filas:
            f["numero_txt"] = self.numero_bono(f["numero"])
            f.update(self.saldo_bono(f["id"]))
        return filas

    def _estado_bono(self, cliente_id, dias_aviso=7):
        hoy = self.ahora().date()
        vig = self.bono_vigente(cliente_id, hoy)
        if vig:
            # si ya tiene renovación pagada que empieza justo después, cuenta la última fecha
            fin = self.db.q1("SELECT MAX(hasta) h FROM bonos WHERE cliente_id=? AND estado='activo'",
                             (cliente_id,))["h"]
            quedan = (date.fromisoformat(fin) - hoy).days
            return {"estado": "caduca" if quedan < dias_aviso else "vigente", "hasta": fin, "dias": quedan,
                    "plan": vig["plan_nombre"]}
        ult = self.db.q1("SELECT b.hasta, b.desde, p.nombre plan_nombre FROM bonos b JOIN planes_bono p "
                         "ON p.id=b.plan_id WHERE cliente_id=? AND estado='activo' ORDER BY hasta DESC LIMIT 1",
                         (cliente_id,))
        if ult and ult["desde"] > hoy.isoformat():
            return {"estado": "futuro", "hasta": ult["hasta"], "desde": ult["desde"], "plan": ult["plan_nombre"]}
        if ult:
            return {"estado": "caducado", "hasta": ult["hasta"], "dias": (date.fromisoformat(ult["hasta"]) - hoy).days,
                    "plan": ult["plan_nombre"]}
        return {"estado": "sin_bono", "hasta": None}

    def _estado_bono_completo(self, cliente_id):
        e = self._estado_bono(cliente_id)
        p = self.bono_pendiente(cliente_id)
        if p:
            e["pendiente"] = {"bono_id": p["id"], "importe_cent": p["pendiente_cent"], "total_cent": p["total_cent"],
                              "pagado_cent": p["pagado_cent"], "desde": p["desde"], "hasta": p["hasta"],
                              "numero": p["numero_txt"], "pagar_antes": p["pagar_antes"], "plan": p["plan_nombre"]}
            deudas = self.deudas_cliente(cliente_id)
            e["deuda_total_cent"] = sum(d["pendiente_cent"] for d in deudas)
            e["deudas"] = len(deudas)
        return e

    # ================================================ renovación automática de bonos
    def renovar_bonos_automaticos(self, solo_cliente=None):
        """El último día de cada bono se crea el siguiente periodo (pendiente de pago) para los abonados
        con «renovación automática», salvo los que pagan con suscripción online (ya se renuevan solos)."""
        hoy = self.ahora().date()
        sql = "SELECT * FROM clientes WHERE activo=1 AND tipo='abonado' AND renovacion_auto=1"
        params = []
        if solo_cliente:
            sql += " AND id=?"
            params.append(solo_cliente)
        creados = []
        for cli in self.db.q(sql, params):
            if self.db.q1("SELECT 1 FROM suscripciones WHERE cliente_id=? AND estado IN ('activa','impagada') "
                          "AND cancelar_al_final=0", (cli["id"],)):
                continue
            ult = self.db.q1("SELECT * FROM bonos WHERE cliente_id=? AND estado='activo' ORDER BY hasta DESC LIMIT 1",
                             (cli["id"],))
            if not ult or not ult["pagado"]:
                continue        # sin bonos, o ya tiene una renovación sin pagar (no se acumulan deudas)
            hasta = date.fromisoformat(ult["hasta"])
            if hasta > hoy or (hoy - hasta).days > 31:
                continue        # aún no toca, o hace más de un mes que caducó (ya no se considera abonado activo)
            plan = self.db.q1("SELECT * FROM planes_bono WHERE id=? AND activo=1", (ult["plan_id"],))
            if not plan:
                continue
            _, d, h = self.periodo_bono(plan["id"], (hasta + timedelta(days=1)).isoformat())
            with self.db.transaccion() as c:
                if c.execute("SELECT 1 FROM bonos WHERE cliente_id=? AND estado='activo' AND hasta>=?",
                             (cli["id"], d.isoformat())).fetchone():
                    continue
                bid = self._insertar_bono(c, cli["id"], plan["id"], d, h, plan["precio_cent"], None,
                                          pagado=plan["precio_cent"] == 0)
                self.auditar(c, None, "bono_renovacion_auto",
                             f"cliente={cli['id']} {plan['nombre']} {d}..{h} {plan['precio_cent']} (pendiente de pago)")
            creados.append(bid)
            if plan["precio_cent"] and self.smtp_listo() and self.cfg("avisos_activos") == "1":
                self._aviso_renovacion(bid)
        return creados

    def _datos_aviso_renovacion(self, bono_id):
        b = self.db.q1("SELECT b.*, p.nombre plan_nombre FROM bonos b JOIN planes_bono p ON p.id=b.plan_id WHERE b.id=?",
                       (bono_id,))
        cli = self.db.q1("SELECT * FROM clientes WHERE id=?", (b["cliente_id"],))
        enlace = self.enlace_pago_bono(b, cli) if self.activo("pagos_online_activo", "pagos_online") else None
        gracia = int(self.cfg("renovacion_dias_gracia") or 0)
        datos = {"plan": b["plan_nombre"], "desde": fecha_es(b["desde"]), "hasta": fecha_es(b["hasta"]),
                 "importe": eur(b["importe_cent"]), "numero": self.numero_bono(b["numero"]),
                 "pagar_antes": fecha_es((date.fromisoformat(b["desde"]) + timedelta(days=gracia)).isoformat()),
                 "enlace": enlace or "",
                 "texto_enlace": (f"\n\nTambién puede pagarlo ahora con tarjeta en este enlace:\n{enlace}" if enlace else "")
                 + self._texto_transferencia(b), "iban": self.cfg("transferencia_iban") or ""}
        return b, cli, datos

    def _texto_transferencia(self, bono):
        iban = (self.cfg("transferencia_iban") or "").strip()
        if self.cfg("transferencia_activa") == "0" or not iban:
            return ""
        titular = (self.cfg("transferencia_titular") or self.cfg("razon_social") or "").strip()
        return (f"\n\nTambién puede pagarlo por transferencia bancaria a {titular + ', ' if titular else ''}IBAN {iban}, "
                f"indicando en el concepto «Bono {self.numero_bono(bono['numero'])}».")

    def _aviso_renovacion(self, bono_id):
        _, cli, datos = self._datos_aviso_renovacion(bono_id)
        return self._enviar_aviso("renovacion", f"bono:{bono_id}", cli, datos)

    def enlace_pago_bono(self, bono, cliente):
        """Enlace de pago único (Stripe) para una renovación pendiente."""
        plan = self.db.q1("SELECT * FROM planes_bono WHERE id=?", (bono["plan_id"],))
        if not plan or not plan["url_enlace_unico"] or plan["precio_enlace_cent"] != bono["importe_cent"]:
            return None
        if self.saldo_bono(bono["id"])["pendiente_cent"] != bono["importe_cent"]:
            return None     # ya tiene pagos parciales o parte cancelada: el enlace cobraría de más
        import urllib.parse
        params = {"client_reference_id": f"BN{bono['id']}"}
        if cliente.get("email"):
            params["prefilled_email"] = cliente["email"]
        return plan["url_enlace_unico"] + ("&" if "?" in plan["url_enlace_unico"] else "?") + urllib.parse.urlencode(params)

    def _importe_parcial(self, importe_cent, pendiente):
        """Importe a cobrar ahora: todo lo pendiente o solo una parte (el resto queda pendiente)."""
        if importe_cent in (None, ""):
            return pendiente
        try:
            importe = int(importe_cent)
        except (TypeError, ValueError):
            raise ErrorNegocio("Importe a cobrar no válido")
        if importe <= 0:
            raise ErrorNegocio("El importe a cobrar debe ser mayor que 0")
        if importe > pendiente:
            raise ErrorNegocio(f"No puede cobrar más de lo pendiente ({eur(pendiente)})")
        return importe

    def cobrar_bono_pendiente(self, usuario, bono_id, metodo, entregado_cent=None, importe_cent=None, referencia=None):
        """Cobra en caja lo pendiente de un bono, entero o solo una parte (el resto sigue pendiente)."""
        turno = self._exigir_turno(usuario)
        referencia = self._metodo_bono(metodo, referencia)
        b = self.db.q1("SELECT * FROM bonos WHERE id=?", (bono_id,))
        if not b or b["estado"] != "activo":
            raise ErrorNegocio("Bono no encontrado o anulado", 404)
        if b["pagado"]:
            raise ErrorNegocio("Ese bono ya está pagado", 409)
        pendiente = self.saldo_bono(bono_id)["pendiente_cent"]
        importe = self._importe_parcial(importe_cent, pendiente)
        entregado, cambio = self._entregado_y_cambio(metodo, importe, entregado_cent)
        with self.db.transaccion() as c:
            pago = self._insertar_pago(c, turno, usuario, importe, metodo, entregado, cambio, bono_id=bono_id,
                                       referencia=referencia)
            queda = self.saldo_bono(bono_id, c)["pendiente_cent"]
            if queda <= 0:
                c.execute("UPDATE bonos SET pagado=1 WHERE id=?", (bono_id,))
            self.auditar(c, usuario["id"], "bono_cobrar_renovacion" if queda <= 0 else "bono_cobro_parcial",
                         f"bono={bono_id} {importe} {metodo}" + (f" · queda pendiente {queda}" if queda > 0 else ""))
        bono = self.db.q1("SELECT b.*, p.nombre plan_nombre FROM bonos b JOIN planes_bono p ON p.id=b.plan_id WHERE b.id=?",
                          (bono_id,))
        res = {"bono": bono, "pago": pago, "cliente": self.cliente(b["cliente_id"]), "saldo": self.saldo_bono(bono_id)}
        res["impresion"] = self._imprimir(self._doc_recibo_bono(res["cliente"], bono, pago), "recibo_bono",
                                          cajon=(metodo == "efectivo"))
        res["email"] = self._factura_a_abonado(b["cliente_id"], pago["id"], usuario)
        return res

    def cancelar_deuda(self, usuario, bono_id, motivo):
        """Cancela a mano lo que queda por pagar de un bono. Si no se pagó nada, el bono se anula (deja de
        valer); si se pagó una parte, se da por cerrado con lo cobrado."""
        if usuario["rol"] not in ROLES_SUPERVISION:
            raise ErrorNegocio("Solo un supervisor puede cancelar deudas", 403)
        motivo = (motivo or "").strip()
        if not motivo:
            raise ErrorNegocio("Indique el motivo")
        with self.db.transaccion() as c:
            b = c.execute("SELECT estado, pagado FROM bonos WHERE id=?", (bono_id,)).fetchone()
            if not b or b[0] != "activo":
                raise ErrorNegocio("Bono no encontrado o anulado", 404)
            if b[1]:
                raise ErrorNegocio("Ese bono no tiene nada pendiente", 409)
            sal = self.saldo_bono(bono_id, c)
            if sal["pagado_cent"] == 0:
                c.execute("UPDATE bonos SET estado='anulado', anulado_motivo=?, cancelado_cent=?, cancelado_motivo=? "
                          "WHERE id=?", ("Deuda cancelada: " + motivo, sal["pendiente_cent"], motivo, bono_id))
                accion = "anulado"
            else:
                c.execute("UPDATE bonos SET pagado=1, cancelado_cent=cancelado_cent+?, cancelado_motivo=? WHERE id=?",
                          (sal["pendiente_cent"], motivo, bono_id))
                accion = "cerrado con lo cobrado"
            self.auditar(c, usuario["id"], "bono_cancelar_deuda",
                         f"bono={bono_id} cancelado {sal['pendiente_cent']} ({accion}) · {motivo}")
        return {"bono_id": bono_id, "cancelado_cent": sal["pendiente_cent"], "anulado": accion == "anulado"}

    def cancelar_deudas_cliente(self, usuario, cliente_id, motivo, quitar_renovacion=False):
        deudas = self.deudas_cliente(cliente_id)
        if not deudas:
            raise ErrorNegocio("Este cliente no tiene deudas", 409)
        res = [self.cancelar_deuda(usuario, d["id"], motivo) for d in deudas]
        if quitar_renovacion:
            with self.db.transaccion() as c:
                c.execute("UPDATE clientes SET renovacion_auto=0 WHERE id=?", (cliente_id,))
                self.auditar(c, usuario["id"], "cliente_sin_renovacion", f"cliente={cliente_id} al cancelar deudas")
        return {"bonos": len(res), "cancelado_cent": sum(r["cancelado_cent"] for r in res)}

    def clientes(self, buscar="", filtro="todos"):
        sql = ("SELECT c.id, c.codigo, c.nombre, c.nif, c.telefono, c.email, c.direccion, c.activo, c.tipo, c.proveedor, "
               "(SELECT group_concat(matricula, ', ') FROM cliente_matriculas m WHERE m.cliente_id=c.id) matriculas, "
               "(SELECT group_concat(matricula || CASE WHEN COALESCE(marca,'')||COALESCE(modelo,'')<>'' "
               "THEN ' (' || TRIM(COALESCE(marca,'') || ' ' || COALESCE(modelo,'')) || ')' ELSE '' END, ', ') "
               "FROM cliente_matriculas m WHERE m.cliente_id=c.id) vehiculos_txt, "
               "(SELECT group_concat(p.nombre || ' · ' || replace(printf('%.2f', s.precio_cent / 100.0), '.', ',') || ' €', ', ') "
               "FROM proveedor_servicios s JOIN productos p ON p.id=s.producto_id WHERE s.cliente_id=c.id) servicios_txt, "
               "(SELECT COUNT(*) FROM tickets t WHERE t.cliente_id=c.id AND t.estado IN ('dentro','pagado')) dentro "
               "FROM clientes c")
        params = []
        if filtro in ("abonado", "facturacion"):
            sql += " WHERE c.tipo=?"
            params.append(filtro)
        elif filtro == "proveedor":
            sql += " WHERE c.proveedor=1"
        if buscar:
            b = "%" + buscar.strip() + "%"
            bm = "%" + (norm_matricula(buscar) or "") + "%"
            sql += (" AND (" if params else " WHERE (") + ("c.nombre LIKE ? OR c.nif LIKE ? OR c.telefono LIKE ? OR c.codigo LIKE ? OR EXISTS "
                    "(SELECT 1 FROM cliente_matriculas m WHERE m.cliente_id=c.id AND "
                    "(m.matricula LIKE ? OR m.marca LIKE ? OR m.modelo LIKE ?)))")
            params += [b, b, b, b, bm, b, b]
        filas = self.db.q(sql + " ORDER BY c.activo DESC, c.nombre COLLATE NOCASE", params)
        for f in filas:
            f["bono"] = self._estado_bono_completo(f["id"])
        if filtro == "pendiente":
            return [f for f in filas if f["bono"].get("pendiente")]
        if filtro not in ("todos", "abonado", "facturacion", "proveedor", "", None):
            filas = [f for f in filas if f["bono"]["estado"] == filtro
                     or (filtro == "vigente" and f["bono"]["estado"] == "caduca")]
        return filas

    def cliente(self, cid):
        c = self.db.q1("SELECT * FROM clientes WHERE id=?", (cid,))
        if not c:
            raise ErrorNegocio("Cliente no encontrado", 404)
        c["vehiculos"] = self.vehiculos_cliente(cid)
        c["matriculas"] = [v["matricula"] for v in c["vehiculos"]]
        c["servicios"] = self.servicios_de_proveedor(cid) if c.get("proveedor") else []
        c["bonos"] = self.db.q("SELECT b.*, p.nombre plan_nombre FROM bonos b "
                               "JOIN planes_bono p ON p.id=b.plan_id WHERE b.cliente_id=? ORDER BY b.desde DESC", (cid,))
        for b in c["bonos"]:
            b["numero_txt"] = self.numero_bono(b["numero"])
            b["pagos"] = self.db.q("SELECT id, serie, numero, fecha, importe_cent, metodo FROM pagos WHERE bono_id=? "
                                   "ORDER BY id", (b["id"],))
            pg = b["pagos"][0] if b["pagos"] else None      # compatibilidad: primera factura del bono
            b.update({"pago_id": pg and pg["id"], "serie": pg and pg["serie"], "factura_numero": pg and pg["numero"],
                      "metodo": pg and pg["metodo"]})
            b.update(self.saldo_bono(b["id"]))
        c["deudas"] = self.deudas_cliente(cid)
        c["estancias"] = self.db.q("SELECT id, codigo, matricula, entrada, salida, estado FROM tickets "
                                   "WHERE cliente_id=? ORDER BY id DESC LIMIT 20", (cid,))
        c["bono"] = self._estado_bono_completo(cid)
        c["dentro"] = self.db.q1("SELECT id, matricula, entrada FROM tickets WHERE cliente_id=? "
                                 "AND estado IN ('dentro','pagado')", (cid,))
        c["proximo_desde"] = self.proximo_desde(cid)
        c["suscripciones"] = self.db.q("SELECT s.*, p.nombre plan_nombre, p.precio_cent FROM suscripciones s "
                                       "JOIN planes_bono p ON p.id=s.plan_id WHERE s.cliente_id=? ORDER BY s.id DESC", (cid,))
        c["facturas"] = self.db.q("SELECT p.id, p.serie, p.numero, p.fecha, p.importe_cent, p.concepto, t.matricula, p.estado_factura, "
                                  "(SELECT group_concat(v.cantidad || ' × ' || v.nombre, ', ') FROM ventas_lineas v WHERE v.pago_id=p.id) servicio "
                                  "FROM facturas_destinatario d JOIN pagos p ON p.id=d.pago_id "
                                  "LEFT JOIN tickets t ON t.id=p.ticket_id WHERE d.cliente_id=? "
                                  "ORDER BY p.id DESC LIMIT 20", (cid,))
        return c

    # ---------------------------------------------------------- importar clientes (3.5)
    def importar_clientes(self, usuario, filas, mapeo, cabecera=True, tipo_defecto="abonado", duplicados="actualizar",
                          simular=False):
        """filas: lista de listas (de importar.leer). mapeo: {campo: índice de columna}.
        duplicados: 'actualizar' (completa y actualiza la ficha) o 'saltar'. Devuelve el resumen y los errores por fila."""
        from .importar import CAMPOS
        validos = {c for c, _ in CAMPOS}
        mapeo = {k: int(v) for k, v in (mapeo or {}).items() if k in validos and str(v).lstrip("-").isdigit() and int(v) >= 0}
        if "nombre" not in mapeo:
            raise ErrorNegocio("Indique qué columna tiene el nombre del cliente")
        abonados = self.tiene_modulo("abonados")
        datos_filas = filas[1:] if cabecera else filas
        res = {"crear": 0, "actualizar": 0, "saltar": 0, "errores": [], "total": len(datos_filas)}
        vistos_nif, vistas_mats = set(), set()
        for n, fila in enumerate(datos_filas, start=2 if cabecera else 1):
            v = {k: (fila[i].strip() if i < len(fila) else "") for k, i in mapeo.items()}
            if not v.get("nombre"):
                res["errores"].append({"fila": n, "motivo": "Sin nombre"})
                continue
            mats = [norm_matricula(m) for m in re.split(r"[,;/|]+", v.get("matricula") or "") if norm_matricula(m)]
            tipo_txt = _norm_txt(v.get("tipo"))
            tipo = ("facturacion" if tipo_txt.startswith("fact") or tipo_txt in ("f", "cliente") else
                    "abonado" if tipo_txt.startswith("abon") or tipo_txt == "a" else tipo_defecto)
            if not abonados:
                tipo = "facturacion"
            nif = (v.get("nif") or "").upper().replace(" ", "").replace("-", "").replace(".", "") or None
            # ¿ya existe? por NIF, por matrícula o por email
            existente = None
            if nif:
                existente = self.db.q1("SELECT id FROM clientes WHERE nif=? ORDER BY tipo='abonado' DESC, id LIMIT 1", (nif,))
            for m in mats:
                if not existente:
                    existente = self.db.q1("SELECT cliente_id id FROM cliente_matriculas WHERE matricula=?", (m,))
            if not existente and v.get("email"):
                existente = self.db.q1("SELECT id FROM clientes WHERE lower(email)=lower(?) LIMIT 1", (v["email"],))
            clave = nif or (mats[0] if mats else None)
            if clave and (clave in vistos_nif or any(m in vistas_mats for m in mats)):
                res["errores"].append({"fila": n, "motivo": "Repetido en el archivo (mismo NIF o matrícula que una fila anterior)"})
                continue
            if nif:
                vistos_nif.add(nif)
            vistas_mats.update(mats)
            if existente and duplicados == "saltar":
                res["saltar"] += 1
                continue
            res["actualizar" if existente else "crear"] += 1
            if simular:
                continue
            try:
                if existente:
                    c = self.cliente(existente["id"])
                    vehs = {x["matricula"]: dict(x) for x in c["vehiculos"]}
                    for i, m in enumerate(mats):
                        vehs.setdefault(m, {"matricula": m})
                        if i == 0 and (v.get("marca") or v.get("modelo")):
                            vehs[m].update({k: v[k] for k in ("marca", "modelo") if v.get(k)})
                    datos = {"nombre": v["nombre"], "tipo": tipo if v.get("tipo") else c["tipo"],
                             "vehiculos": list(vehs.values()), "activo": c["activo"],
                             "enviar_facturas": c.get("enviar_facturas", 1), "renovacion_auto": c.get("renovacion_auto", 1),
                             **{k: v.get(k) or c.get(k) or "" for k in ("telefono", "email", "direccion", "notas")},
                             "nif": nif or c.get("nif") or ""}
                    self.guardar_cliente(datos, usuario["id"], existente["id"])
                else:
                    vehs = [{"matricula": m} for m in mats]
                    if vehs and (v.get("marca") or v.get("modelo")):
                        vehs[0].update({"marca": v.get("marca"), "modelo": v.get("modelo")})
                    self.guardar_cliente({"nombre": v["nombre"], "tipo": tipo, "nif": nif or "", "vehiculos": vehs,
                                          **{k: v.get(k) or "" for k in ("telefono", "email", "direccion", "notas")}},
                                         usuario["id"])
            except ErrorNegocio as e:
                res["actualizar" if existente else "crear"] -= 1
                res["errores"].append({"fila": n, "motivo": str(e)})
        if not simular:
            with self.db.transaccion() as c:
                self.auditar(c, usuario["id"], "clientes_importar",
                             f"creados={res['crear']} actualizados={res['actualizar']} saltados={res['saltar']} errores={len(res['errores'])}")
        return res

    def exportar_clientes_csv(self):
        """Todos los clientes con las mismas columnas que la plantilla de importación (se puede volver a importar)."""
        import csv as _csv
        import io as _io
        buf = _io.StringIO()
        w = _csv.writer(buf, delimiter=";", lineterminator="\r\n")
        w.writerow(["nombre", "nif", "telefono", "email", "direccion", "matricula", "marca", "modelo", "tipo", "notas"])
        vehs = {}
        for v in self.db.q("SELECT cliente_id, matricula, marca, modelo FROM cliente_matriculas ORDER BY id"):
            vehs.setdefault(v["cliente_id"], []).append(v)
        for c in self.db.q("SELECT * FROM clientes WHERE activo=1 ORDER BY nombre COLLATE NOCASE"):
            vs = vehs.get(c["id"], [])
            w.writerow([c["nombre"], c["nif"] or "", c["telefono"] or "", c["email"] or "", c["direccion"] or "",
                        ", ".join(v["matricula"] for v in vs), (vs[0]["marca"] or "") if vs else "",
                        (vs[0]["modelo"] or "") if vs else "", c["tipo"], (c["notas"] or "").replace("\n", " ")])
        return "\ufeff" + buf.getvalue()

    def guardar_cliente(self, datos, actor_id, cid=None):
        nombre = (datos.get("nombre") or "").strip()
        if not nombre:
            raise ErrorNegocio("El nombre del cliente es obligatorio")
        entrada = datos.get("vehiculos")
        if entrada is None:  # compatibilidad: lista simple de matrículas
            entrada = [{"matricula": m} for m in (datos.get("matriculas") or [])]
        vehs, mats = [], []
        for v in entrada:
            m = norm_matricula(v.get("matricula"))
            if not m:
                if (v.get("marca") or v.get("modelo") or "").strip():
                    raise ErrorNegocio("Falta la matrícula de un vehículo")
                continue
            if m in mats:
                raise ErrorNegocio(f"La matrícula {m} está repetida")
            mats.append(m)
            vehs.append({"matricula": m,
                         "marca": (v.get("marca") or "").strip()[:40] or None,
                         "modelo": (v.get("modelo") or "").strip()[:40] or None})
        campos = {k: (datos.get(k) or "").strip() or None for k in ("nif", "telefono", "email", "direccion", "notas")}
        if campos["nif"]:
            campos["nif"] = campos["nif"].upper().replace(" ", "").replace("-", "")
        activo = 0 if datos.get("activo") in (False, 0, "0") else 1
        tipo = datos.get("tipo") if datos.get("tipo") in ("abonado", "facturacion") else None
        es_prov = 1 if (datos.get("proveedor") in (True, 1, "1") or datos.get("tipo") == "proveedor") else 0
        if es_prov:
            tipo = "facturacion"   # un proveedor no tiene bonos: es un cliente de facturación
            vehs, mats = [], []     # ni vehículos ni ticket: solo se le factura
        servicios = self._validar_servicios_proveedor(datos.get("servicios")) if es_prov and "servicios" in datos else None   # 4.63: sin la clave no se tocan
        enviar_fact = 0 if datos.get("enviar_facturas") in (False, 0, "0") else 1
        renov = 0 if datos.get("renovacion_auto") in (False, 0, "0") else 1
        try:   # 4.54: descuento fijo en % (0 = sin descuento)
            dto_pct = round(float(str(datos.get("descuento_pct") or 0).replace(",", ".")), 2)
        except ValueError:
            raise ErrorNegocio("El descuento del cliente no es válido")
        if not 0 <= dto_pct <= 100:
            raise ErrorNegocio("El descuento del cliente debe estar entre 0 y 100 %")
        with self.db.transaccion() as c:
            if cid and es_prov and c.execute(
                    "SELECT 1 FROM bonos WHERE cliente_id=? AND estado='activo' LIMIT 1", (cid,)).fetchone():
                raise ErrorNegocio("Este cliente tiene bonos: no puede ser proveedor")
            if cid and tipo == "facturacion" and c.execute(
                    "SELECT 1 FROM bonos WHERE cliente_id=? AND estado='activo' LIMIT 1", (cid,)).fetchone():
                raise ErrorNegocio("Este cliente tiene bonos: no puede pasar a cliente de facturación")
            for m in mats:
                otro = c.execute("SELECT c.nombre FROM cliente_matriculas m JOIN clientes c ON c.id=m.cliente_id "
                                 "WHERE m.matricula=? AND m.cliente_id<>?", (m, cid or 0)).fetchone()
                if otro:
                    raise ErrorNegocio(f"La matrícula {m} ya está asignada a {otro[0]}")
            if cid:
                if not c.execute("SELECT 1 FROM clientes WHERE id=?", (cid,)).fetchone():
                    raise ErrorNegocio("Cliente no encontrado", 404)
                c.execute("UPDATE clientes SET nombre=?, nif=?, telefono=?, email=?, direccion=?, notas=?, activo=? "
                          "WHERE id=?", (nombre, *campos.values(), activo, cid))
                if tipo:
                    c.execute("UPDATE clientes SET tipo=? WHERE id=?", (tipo, cid))
                c.execute("UPDATE clientes SET enviar_facturas=?, renovacion_auto=?, descuento_pct=?, proveedor=? WHERE id=?", (enviar_fact, renov, dto_pct, es_prov, cid))
                c.execute("DELETE FROM cliente_matriculas WHERE cliente_id=?", (cid,))
            else:
                cid = c.execute("INSERT INTO clientes(nombre, nif, telefono, email, direccion, notas, activo, creado, tipo) "
                                "VALUES(?,?,?,?,?,?,?,?,?)", (nombre, *campos.values(), activo, iso(self.ahora()),
                                                             tipo or "abonado")).lastrowid
                c.execute("UPDATE clientes SET codigo=?, enviar_facturas=?, renovacion_auto=?, descuento_pct=?, proveedor=? WHERE id=?",
                          (self._codigo(cid, "CL"), enviar_fact, renov, dto_pct, es_prov, cid))
            for v in vehs:
                c.execute("INSERT INTO cliente_matriculas(cliente_id, matricula, marca, modelo) VALUES(?,?,?,?)",
                          (cid, v["matricula"], v["marca"], v["modelo"]))
            if es_prov and servicios is not None:
                c.execute("DELETE FROM proveedor_servicios WHERE cliente_id=?", (cid,))
                for sv_ in servicios:
                    pid = self._servicio_de_proveedor(c, sv_["nombre"], sv_["precio_cent"])
                    c.execute("INSERT OR REPLACE INTO proveedor_servicios(cliente_id, producto_id, precio_cent) VALUES(?,?,?)",
                              (cid, pid, sv_["precio_cent"]))
            elif not es_prov:
                c.execute("DELETE FROM proveedor_servicios WHERE cliente_id=?", (cid,))
            self.auditar(c, actor_id, "cliente_guardar", f"id={cid} {nombre} [{', '.join(mats)}]" + (f" dto={dto_pct}%" if dto_pct else ""))
        return cid

    @staticmethod
    def _validar_servicios_proveedor(lista):
        """[{nombre, precio_cent}] del formulario del proveedor; las filas vacías se ignoran."""
        res, vistos = [], set()
        for x in lista or []:
            nombre = (x.get("nombre") or "").strip()[:80]
            if not nombre and x.get("precio_cent") in (None, ""):
                continue
            if not nombre:
                raise ErrorNegocio("Falta el nombre de un servicio del proveedor")
            try:
                precio = int(x.get("precio_cent"))
            except (TypeError, ValueError):
                raise ErrorNegocio(f"Precio no válido en «{nombre}»")
            if precio < 0:
                raise ErrorNegocio(f"Precio no válido en «{nombre}»")
            if nombre.lower() in vistos:
                raise ErrorNegocio(f"El servicio «{nombre}» está repetido")
            vistos.add(nombre.lower())
            res.append({"nombre": nombre, "precio_cent": precio})
        return res

    def _servicio_de_proveedor(self, c, nombre, precio_cent):
        """Id del servicio «solo proveedores» con ese nombre; si no existe en el catálogo, se crea."""
        r = c.execute("SELECT id FROM productos WHERE solo_proveedor=1 AND eliminado=0 AND lower(nombre)=lower(?)", (nombre,)).fetchone()
        if r:
            c.execute("UPDATE productos SET activo=1 WHERE id=?", (r[0],))
            return r[0]
        v = self._validar_producto({"nombre": nombre, "tipo": "servicio", "precio_cent": precio_cent, "solo_proveedor": True})
        return self._escribir_producto(c, v)

    def guardar_servicio_proveedor(self, actor_id, cid, nombre, precio_cent, anterior_id=None):
        """4.63: añade (o cambia) un servicio con su precio en la ficha del proveedor, igual que se venden bonos a un abonado."""
        v = self._validar_servicios_proveedor([{"nombre": nombre, "precio_cent": precio_cent}])
        if not v:
            raise ErrorNegocio("Escriba el servicio y su precio")
        v = v[0]
        with self.db.transaccion() as c:
            if not c.execute("SELECT 1 FROM clientes WHERE id=? AND proveedor=1", (cid,)).fetchone():
                raise ErrorNegocio("Proveedor no encontrado", 404)
            pid = self._servicio_de_proveedor(c, v["nombre"], v["precio_cent"])
            if anterior_id and int(anterior_id) != pid:
                c.execute("DELETE FROM proveedor_servicios WHERE cliente_id=? AND producto_id=?", (cid, int(anterior_id)))
            elif not anterior_id and c.execute("SELECT 1 FROM proveedor_servicios WHERE cliente_id=? AND producto_id=?", (cid, pid)).fetchone():
                raise ErrorNegocio(f"El servicio «{v['nombre']}» ya está en este proveedor: edítelo desde la lista")
            c.execute("INSERT OR REPLACE INTO proveedor_servicios(cliente_id, producto_id, precio_cent) VALUES(?,?,?)",
                      (cid, pid, v["precio_cent"]))
            self.auditar(c, actor_id, "proveedor_servicio", f"cliente={cid} {v['nombre']} {v['precio_cent']}")
        return self.servicios_de_proveedor(cid)

    def quitar_servicio_proveedor(self, actor_id, cid, producto_id):
        with self.db.transaccion() as c:
            c.execute("DELETE FROM proveedor_servicios WHERE cliente_id=? AND producto_id=?", (cid, producto_id))
            self.auditar(c, actor_id, "proveedor_servicio_quitar", f"cliente={cid} producto={producto_id}")
        return self.servicios_de_proveedor(cid)

    def servicios_de_proveedor(self, cid):
        iva_gen = float(self.cfg("iva_pct") or 21)
        filas = self.db.q("SELECT s.producto_id, p.nombre, s.precio_cent, p.iva_pct FROM proveedor_servicios s "
                          "JOIN productos p ON p.id=s.producto_id WHERE s.cliente_id=? AND p.eliminado=0 "
                          "ORDER BY p.nombre COLLATE NOCASE", (cid,))
        for f in filas:
            f["iva_efectivo"] = f["iva_pct"] if f["iva_pct"] is not None else iva_gen
        return filas

    def vehiculos_cliente(self, cid):
        return self.db.q("SELECT m.matricula, m.marca, m.modelo, (SELECT f.actualizado FROM vehiculo_fotos f "
                         "WHERE f.cliente_id=m.cliente_id AND f.matricula=m.matricula) foto "
                         "FROM cliente_matriculas m WHERE m.cliente_id=? ORDER BY m.id", (cid,))

    # ------------------------------------------------------------ 3.5: fotos de vehículos de abonados
    def _tipo_imagen(self, datos):
        if datos[:3] == b"\xff\xd8\xff":
            return "image/jpeg"
        if datos[:8] == b"\x89PNG\r\n\x1a\n":
            return "image/png"
        if datos[:4] == b"RIFF" and datos[8:12] == b"WEBP":
            return "image/webp"
        raise ErrorNegocio("La foto debe ser JPG, PNG o WEBP")

    def guardar_foto_vehiculo(self, cid, matricula, datos, actor_id):
        m = norm_matricula(matricula)
        if not self.db.q1("SELECT 1 FROM cliente_matriculas WHERE cliente_id=? AND matricula=?", (cid, m)):
            raise ErrorNegocio("Guarde primero el vehículo en la ficha del cliente", 404)
        tipo = self._tipo_imagen(datos)
        if len(datos) > self.FOTO_MAX:
            raise ErrorNegocio("La foto es demasiado grande (máximo 600 KB)")
        with self.db.transaccion() as c:
            c.execute("INSERT INTO vehiculo_fotos(cliente_id, matricula, tipo, datos, actualizado) VALUES(?,?,?,?,?) "
                      "ON CONFLICT(cliente_id, matricula) DO UPDATE SET tipo=excluded.tipo, datos=excluded.datos, "
                      "actualizado=excluded.actualizado", (cid, m, tipo, datos, iso(self.ahora())))
            self.auditar(c, actor_id, "vehiculo_foto", f"cliente={cid} {m} {len(datos)} bytes")
        return {"ok": True}

    def foto_vehiculo(self, cid, matricula):
        r = self.db.q1("SELECT tipo, datos FROM vehiculo_fotos WHERE cliente_id=? AND matricula=?",
                       (cid, norm_matricula(matricula)))
        if not r:
            raise ErrorNegocio("Este vehículo no tiene foto", 404)
        return r["datos"], r["tipo"]

    def quitar_foto_vehiculo(self, cid, matricula, actor_id):
        m = norm_matricula(matricula)
        with self.db.transaccion() as c:
            c.execute("DELETE FROM vehiculo_fotos WHERE cliente_id=? AND matricula=?", (cid, m))
            self.auditar(c, actor_id, "vehiculo_foto_quitar", f"cliente={cid} {m}")
        return {"ok": True}

    def planes(self, solo_activos=False):
        return self.db.q("SELECT * FROM planes_bono" + (" WHERE activo=1" if solo_activos else "")
                         + " ORDER BY activo DESC, meses, precio_cent")

    def guardar_plan(self, datos, actor_id, pid=None):
        nombre = (datos.get("nombre") or "").strip()
        if not nombre:
            raise ErrorNegocio("El bono necesita un nombre")
        precio = int(datos.get("precio_cent") or 0)
        meses = int(datos.get("meses") or 1)
        if precio < 0 or not 1 <= meses <= 12:
            raise ErrorNegocio("Precio >= 0 y duración entre 1 y 12 meses")
        activo = 0 if datos.get("activo") in (False, 0, "0") else 1
        with self.db.transaccion() as c:
            if pid:
                antes = c.execute("SELECT precio_cent, meses FROM planes_bono WHERE id=?", (pid,)).fetchone()
                c.execute("UPDATE planes_bono SET nombre=?, descripcion=?, precio_cent=?, meses=?, activo=? WHERE id=?",
                          (nombre, datos.get("descripcion"), precio, meses, activo, pid))
                if antes and (antes[0], antes[1]) != (precio, meses):
                    c.execute("UPDATE planes_bono SET precio_enlace_cent=NULL WHERE id=?", (pid,))
            else:
                pid = c.execute("INSERT INTO planes_bono(nombre, descripcion, precio_cent, meses, activo) "
                                "VALUES(?,?,?,?,?)", (nombre, datos.get("descripcion"), precio, meses, activo)).lastrowid
            self.auditar(c, actor_id, "bono_plan_guardar", f"id={pid} {nombre} {precio}")
        return pid

    def _insertar_bono(self, c, cliente_id, plan_id, desde, hasta, importe, usuario_id, pagado=True):
        ultimo = c.execute("SELECT MAX(numero) FROM bonos").fetchone()[0] or 0
        numero = max(ultimo + 1, int(self.cfg("bono_numero_inicial") or 1))
        return c.execute("INSERT INTO bonos(cliente_id, plan_id, desde, hasta, importe_cent, creado, usuario_id, numero, pagado) "
                         "VALUES(?,?,?,?,?,?,?,?,?)", (cliente_id, plan_id, desde.isoformat(), hasta.isoformat(), importe,
                                                       iso(self.ahora()), usuario_id, numero, 1 if pagado else 0)).lastrowid

    def numero_bono(self, numero):
        return f"{(self.cfg('bono_prefijo') or 'B')}{int(numero or 0):06d}"

    def proximo_desde(self, cliente_id):
        """Fecha de inicio por defecto al vender: el día siguiente al último bono si no ha caducado, o hoy."""
        hoy = self.ahora().date()
        ult = self.db.q1("SELECT MAX(hasta) h FROM bonos WHERE cliente_id=? AND estado='activo'", (cliente_id,))["h"]
        if ult and date.fromisoformat(ult) >= hoy:
            return (date.fromisoformat(ult) + timedelta(days=1)).isoformat()
        return hoy.isoformat()

    def periodo_bono(self, plan_id, desde):
        plan = self.db.q1("SELECT * FROM planes_bono WHERE id=?", (plan_id,))
        if not plan:
            raise ErrorNegocio("Tipo de bono no encontrado", 404)
        d = date.fromisoformat(desde)
        return plan, d, sumar_meses(d, plan["meses"]) - timedelta(days=1)

    def vender_bono(self, usuario, cliente_id, plan_id, desde=None, metodo="efectivo", entregado_cent=None,
                    renovacion_auto=None, importe_cent=None, referencia=None):
        turno = self._exigir_turno(usuario)
        self._exigir_licencia()
        pend = self.bono_pendiente(cliente_id)
        if pend:
            raise ErrorNegocio(f"Tiene la renovación del {fecha_es(pend['desde'])} al {fecha_es(pend['hasta'])} pendiente de "
                               f"pago ({eur(pend['importe_cent'])}): cóbrela desde su ficha o anúlela antes de vender otro bono.", 409)
        if renovacion_auto is not None:
            self.db.ex("UPDATE clientes SET renovacion_auto=? WHERE id=?", (1 if renovacion_auto else 0, cliente_id))
        referencia = self._metodo_bono(metodo, referencia)
        cli = self.db.q1("SELECT * FROM clientes WHERE id=?", (cliente_id,))
        if cli and cli.get("proveedor"):
            raise ErrorNegocio("Un proveedor no puede tener bonos: se le factura con «Factura a proveedor»")
        if not cli or not cli["activo"]:
            raise ErrorNegocio("Cliente no encontrado o dado de baja", 404)
        desde = desde or self.proximo_desde(cliente_id)
        plan, d, h = self.periodo_bono(plan_id, desde)
        if not plan["activo"]:
            raise ErrorNegocio("Ese tipo de bono no está a la venta")
        if d < self.ahora().date() - timedelta(days=31):
            raise ErrorNegocio("La fecha de inicio es demasiado antigua")
        importe = plan["precio_cent"]
        cobrar = self._importe_parcial(importe_cent, importe) if importe > 0 else 0
        entregado, cambio = self._entregado_y_cambio(metodo, cobrar, entregado_cent)
        with self.db.transaccion() as c:
            solape = c.execute("SELECT desde, hasta FROM bonos WHERE cliente_id=? AND estado='activo' "
                               "AND desde<=? AND hasta>=?", (cliente_id, h.isoformat(), d.isoformat())).fetchone()
            if solape:
                raise ErrorNegocio(f"Se solapa con el bono del {fecha_es(solape[0])} al {fecha_es(solape[1])}. "
                                   "Elija otra fecha de inicio.")
            bid = self._insertar_bono(c, cliente_id, plan_id, d, h, importe, usuario["id"], pagado=cobrar >= importe)
            c.execute("UPDATE clientes SET tipo='abonado' WHERE id=?", (cliente_id,))
            pago = None
            if cobrar > 0:
                pago = self._insertar_pago(c, turno, usuario, cobrar, metodo, entregado, cambio, bono_id=bid,
                                           referencia=referencia)
            self.auditar(c, usuario["id"], "bono_vender",
                         f"cliente={cliente_id} {plan['nombre']} {d}..{h} {importe} {metodo}"
                         + (f" · cobrado {cobrar}, pendiente {importe - cobrar}" if cobrar < importe else ""))
        bono = self.db.q1("SELECT b.*, p.nombre plan_nombre FROM bonos b JOIN planes_bono p ON p.id=b.plan_id "
                          "WHERE b.id=?", (bid,))
        res = {"bono": bono, "pago": pago, "cliente": self.cliente(cliente_id), "saldo": self.saldo_bono(bid)}
        if pago:
            res["impresion"] = self._imprimir(self._doc_recibo_bono(res["cliente"], bono, pago), "recibo_bono",
                                              cajon=(metodo == "efectivo"))
            res["email"] = self._factura_a_abonado(cliente_id, pago["id"], usuario)
        return res

    # ======================================== facturas y avisos por email a abonados
    def smtp_listo(self):
        return bool(self.cfg("smtp_servidor"))

    def _factura_a_abonado(self, cliente_id, pago_id, usuario=None):
        """Envía la factura del bono al email del abonado si así está configurado. Devuelve el estado o None."""
        cli = self.db.q1("SELECT * FROM clientes WHERE id=?", (cliente_id,))
        if not (cli and cli["email"] and cli["enviar_facturas"] and self.cfg("facturas_bono_email") == "1"
                and self.smtp_listo() and email_valido(cli["email"])):
            return None
        if not self.db.q1("SELECT 1 FROM facturas_destinatario WHERE pago_id=?", (pago_id,)):
            self.db.ex("INSERT INTO facturas_destinatario(pago_id, nombre, nif, direccion, email, cliente_id, fecha, usuario_id) "
                       "VALUES(?,?,?,?,?,?,?,?)", (pago_id, cli["nombre"], cli["nif"], cli["direccion"], cli["email"],
                                                   cliente_id, iso(self.ahora()), usuario["id"] if usuario else None))
        try:
            e = self.enviar_factura(usuario or {"id": None}, pago_id, cli["email"])
            return {"estado": e["estado"], "destino": e["destino"], "error": e.get("ultimo_error")}
        except ErrorNegocio as ex:
            return {"estado": "error", "destino": cli["email"], "error": str(ex)}

    def anular_bono(self, usuario, bono_id, motivo):
        if usuario["rol"] not in ROLES_SUPERVISION:
            raise ErrorNegocio("Solo un supervisor puede anular bonos", 403)
        if not (motivo or "").strip():
            raise ErrorNegocio("Indique el motivo")
        with self.db.transaccion() as c:
            b = c.execute("SELECT estado FROM bonos WHERE id=?", (bono_id,)).fetchone()
            if not b or b[0] != "activo":
                raise ErrorNegocio("Bono no encontrado o ya anulado", 404)
            c.execute("UPDATE bonos SET estado='anulado', anulado_motivo=? WHERE id=?", (motivo, bono_id))
            self.auditar(c, usuario["id"], "bono_anular", f"id={bono_id} {motivo}")

    def consultar_abonado(self, cliente_id):
        self.renovar_bonos_automaticos(cliente_id)
        cli = self.db.q1("SELECT id, codigo, nombre, nif, telefono, activo FROM clientes WHERE id=?", (cliente_id,))
        if not cli:
            raise ErrorNegocio("Tarjeta de un cliente que ya no existe", 404)
        cli["vehiculos"] = self.vehiculos_cliente(cliente_id)
        cli["matriculas"] = [v["matricula"] for v in cli["vehiculos"]]
        if (not self.bono_vigente(cliente_id) and self.db.q1(
                "SELECT 1 FROM suscripciones WHERE cliente_id=? AND estado<>'cancelada'", (cliente_id,))) or (
                self.activo("pagos_online_activo", "pagos_online") and self.bono_pendiente(cliente_id)):
            try:   # quizá ya se cobró la renovación y aún no se había sincronizado
                self.sincronizar_pagos_online(solo_cliente=cliente_id)
            except Exception as e_:  # noqa: BLE001  (sin Internet: se decide con lo que hay)
                errores.fallo("servicios.consultar_abonado", e_)
        res = {"tipo": "abonado", "cliente": cli, "bono": self._estado_bono(cliente_id),
               "vigente": bool(self.bono_vigente(cliente_id)) and bool(cli["activo"]), "dentro": None}
        t = self.db.q1("SELECT id FROM tickets WHERE cliente_id=? AND estado IN ('dentro','pagado')", (cliente_id,))
        if t:
            res["dentro"] = self.consultar(ticket_id=t["id"])
        return res

    def entrada_abonado(self, usuario, cliente_id, matricula=None):
        t = self._exigir_turno(usuario)
        self._exigir_licencia()
        self._exigir_abierto(usuario)   # 1.9
        info = self.consultar_abonado(cliente_id)
        cli = info["cliente"]
        if not cli["activo"]:
            raise ErrorNegocio(f"{cli['nombre']} está dado de baja", 409)
        vig = self.bono_vigente(cliente_id)
        if not vig:
            raise ErrorNegocio(f"{cli['nombre']} no tiene bono vigente. Renueve el bono o emita un ticket normal.", 409)
        if info["dentro"]:
            raise ErrorNegocio(f"{cli['nombre']} ya tiene un vehículo dentro "
                               f"({info['dentro'].get('matricula') or 'sin matrícula'})", 409)
        matricula = norm_matricula(matricula) or (cli["matriculas"][0] if cli["matriculas"] else None)
        capacidad = self.cfg("capacidad", int) or 0
        with self.db.transaccion() as c:
            if capacidad and c.execute("SELECT COUNT(*) FROM tickets WHERE estado IN ('dentro','pagado')"
                                       ).fetchone()[0] >= capacidad:
                raise ErrorNegocio("Parking COMPLETO", 409)
            tar = c.execute("SELECT id FROM tarifas WHERE por_defecto=1 AND activa=1").fetchone()
            if not tar:
                raise ErrorNegocio("No hay tarifa activa disponible")
            tid = c.execute("INSERT INTO tickets(codigo, matricula, entrada, tarifa_id, turno_entrada_id, "
                            "usuario_entrada_id, cliente_id, bono_id) VALUES(?,?,?,?,?,?,?,?)",
                            ("tmp-" + secrets.token_hex(8), matricula, iso(self.ahora()), tar[0], t["id"],
                             usuario["id"], cliente_id, vig["id"])).lastrowid
            self._asignar_codigo_ticket(c, tid)
            self.auditar(c, usuario["id"], "abonado_entrada", f"{cli['nombre']} {matricula or ''}")
        tk = self.ticket(tid)
        tk["abonado"] = True
        tk["impresion"] = None
        tk["mensaje"] = f"Abonado {cli['nombre']}: entrada registrada (bono hasta {fecha_es(vig['hasta'])})"
        tk["barrera"] = self.abrir_barrera("abonado", usuario)
        return tk

    def imprimir_tarjeta(self, usuario, cliente_id):
        cli = self.cliente(cliente_id)
        with self.db.transaccion() as c:
            self.auditar(c, usuario["id"], "tarjeta_imprimir", cli["nombre"])
        return self._imprimir(self._doc_tarjeta(cli), "tarjeta")
