"""PROYECTO ALLAS · rutas de la API: turnos, caja, informes, estadísticas y auditoría (se registran desde server.App._registrar)."""
from .backup import hacer_backup
from .servicios import ROLES_SUPERVISION


def registrar(app, r, p):
    from .server import Respuesta


    # --- turno y caja
    @r("POST", "/api/turno/abrir")
    def turno_abrir(req):
        p.abrir_turno(req.usuario, req.body.get("fondo_cent", 0), req.body.get("arqueo", True), req.body.get("fondo_desglose"))
        fich = p.fichaje_auto(req.usuario["id"], "abrir")   # 4.53: si está activado, abrir el turno ficha la entrada
        res = p.turno_abierto(req.usuario)
        if fich and isinstance(res, dict):
            res["fichaje"] = fich
        return res

    @r("POST", "/api/turno/cerrar")
    def turno_cerrar(req):
        dueno = req.usuario["id"]
        if req.body.get("turno_id"):
            t0 = p.db.q1("SELECT usuario_id FROM turnos WHERE id=?", (int(req.body.get("turno_id")),))
            dueno = t0["usuario_id"] if t0 else dueno
        res = p.cerrar_turno(req.usuario, req.body.get("contado_cent", 0), req.body.get("observaciones", ""),
                             req.body.get("contado_desglose"), req.body.get("turno_id"))
        fich = p.fichaje_auto(dueno, "cerrar")   # 4.53: con «turno y jornada», cerrar el turno ficha la salida
        if fich:
            res["fichaje"] = fich
        try:
            hacer_backup(p.db, app.backups, int(p.cfg("backups_mantener") or 30), p.cfg("backup_destino_extra"),
                         tipo="cierre_turno", usuario=req.usuario["usuario"])
        except Exception as e:
            res["aviso_backup"] = str(e)
        return res

    @r("GET", "/api/turnos", rol=ROLES_SUPERVISION)
    def turnos(req):
        return p.turnos()

    @r("GET", r"/api/turnos/(\d+)", rol=ROLES_SUPERVISION)
    def turno(req, tid):
        return p.resumen_turno(int(tid))

    @r("POST", "/api/caja/movimiento")
    def movimiento(req):
        b = req.body
        return p.movimiento_caja(req.usuario, b.get("tipo"), b.get("importe_cent", 0), b.get("motivo", ""))

    @r("POST", "/api/caja/abrir")
    def cajon(req):
        return p.abrir_cajon(req.usuario, req.body.get("motivo", ""))

    # --- estadísticas, cierre diario y libro de facturas
    @r("GET", "/api/estadisticas", rol=ROLES_SUPERVISION)
    def estadisticas(req):
        return p.estadisticas(req.query.get("desde"), req.query.get("hasta"))

    @r("GET", "/api/informes/libro-facturas.csv", rol=ROLES_SUPERVISION)
    def libro_facturas(req):
        d, h = req.query.get("desde") or p.ahora().date().isoformat(), req.query.get("hasta") or p.ahora().date().isoformat()
        return Respuesta(p.libro_facturas_csv(d, h).encode("utf-8"), "text/csv; charset=utf-8",
                         {"Content-Disposition": f'attachment; filename="libro_facturas_{d}_{h}.csv"'})

    @r("GET", "/api/informes/cierre", rol=ROLES_SUPERVISION)
    def cierre_ver(req):
        dia = req.query.get("dia") or p.ahora().date().isoformat()
        return {"dia": dia, "texto": p.resumen_cierre(dia), "email": p.cfg("cierre_email") or "",
                "activo": p.cfg("cierre_email_activo") == "1", "ultimo": p.cfg("cierre_ultimo_envio"),
                "error": p.cfg("cierre_ultimo_error") or None, "smtp": p.smtp_listo()}

    @r("POST", "/api/informes/cierre/enviar", rol=ROLES_SUPERVISION)
    def cierre_enviar(req):
        return p.enviar_cierre(req.body.get("dia"), req.usuario["id"])

    # --- auditoría con filtros
    @r("GET", "/api/auditoria/buscar", rol=ROLES_SUPERVISION)
    def auditoria_buscar(req):
        q = req.query
        return p.auditoria_buscar(q.get("desde"), q.get("hasta"), q.get("usuario_id"), q.get("accion", ""), q.get("texto", ""),
                                  q.get("limite", 500))

    @r("GET", "/api/auditoria.csv", rol=ROLES_SUPERVISION)
    def auditoria_csv(req):
        q = req.query
        return Respuesta(p.auditoria_csv(desde=q.get("desde"), hasta=q.get("hasta"), usuario_id=q.get("usuario_id"),
                                         accion=q.get("accion", ""), texto=q.get("texto", "")).encode("utf-8"),
                         "text/csv; charset=utf-8", {"Content-Disposition": 'attachment; filename="auditoria.csv"'})

    @r("GET", "/api/historial")
    def historial(req):
        q = req.query
        return p.historial_vehiculos(q.get("desde"), q.get("hasta"), q.get("buscar", ""), q.get("estado", ""))

    @r("GET", "/api/historial.csv")
    def historial_csv(req):
        q = req.query
        datos = p.csv_historial(q.get("desde"), q.get("hasta"), q.get("buscar", ""), q.get("estado", ""))
        return Respuesta(datos.encode("utf-8"), "text/csv; charset=utf-8",
                         {"Content-Disposition": f'attachment; filename="vehiculos_{q.get("desde")}_{q.get("hasta")}.csv"'})

    @r("GET", "/api/informe", rol=ROLES_SUPERVISION)
    def informe(req):
        return p.informe(req.query["desde"], req.query["hasta"])

    @r("GET", "/api/informe.csv", rol=ROLES_SUPERVISION)
    def informe_csv(req):
        d, h = req.query["desde"], req.query["hasta"]
        return Respuesta(p.csv_pagos(d, h).encode("utf-8"), "text/csv; charset=utf-8",
                         {"Content-Disposition": f'attachment; filename="cobros_{d}_{h}.csv"'})

    @r("GET", "/api/auditoria", rol=ROLES_SUPERVISION)
    def auditoria(req):
        return p.auditoria(int(req.query.get("limite", 200)))
