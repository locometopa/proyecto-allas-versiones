"""4.3 · Copia de seguridad cifrada en la nube.

La copia (.db) se cifra con una contraseña antes de salir del PC, así el proveedor de la nube no puede leerla:
- clave: PBKDF2-HMAC-SHA256 (300 000 vueltas, sal aleatoria) → 64 bytes (32 para cifrar, 32 para autenticar)
- cifrado: BLAKE2b con clave en modo contador (flujo de 64 bytes por bloque, nonce aleatorio de 16 bytes)
- integridad: HMAC-SHA256 de todo el archivo (cualquier cambio o contraseña errónea se detecta)
Formato: b"ALLASNUBE1" + sal(16) + nonce(16) + datos cifrados + hmac(32). Solo biblioteca estándar de Python.

Destinos: una carpeta sincronizada (OneDrive, Google Drive, Dropbox… instalados en el PC) o un servidor WebDAV
(Nextcloud, muchos NAS, pCloud, Koofr…).
"""
import base64
import hashlib
import hmac
import os
import secrets
import threading
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime

MAGIA = b"ALLASNUBE1"
VUELTAS = 300_000
EXT = ".allas-cifrada"


class ErrorNube(Exception):
    pass


def _claves(clave, sal):
    k = hashlib.pbkdf2_hmac("sha256", clave.encode("utf-8"), sal, VUELTAS, dklen=64)
    return k[:32], k[32:]


def _flujo(datos, clave_cif, nonce):
    """XOR con el flujo BLAKE2b(nonce || contador) — cifrar y descifrar es la misma operación."""
    n = len(datos)
    b2 = hashlib.blake2b
    bloques = (n + 63) // 64
    flujo = b"".join(b2(nonce + i.to_bytes(8, "little"), key=clave_cif, digest_size=64).digest() for i in range(bloques))[:n]
    return (int.from_bytes(datos, "little") ^ int.from_bytes(flujo, "little")).to_bytes(n, "little") if n else b""


def cifrar(datos, clave):
    if not clave or len(clave) < 8:
        raise ErrorNube("La contraseña de cifrado debe tener al menos 8 caracteres")
    sal, nonce = secrets.token_bytes(16), secrets.token_bytes(16)
    kc, km = _claves(clave, sal)
    cuerpo = MAGIA + sal + nonce + _flujo(datos, kc, nonce)
    return cuerpo + hmac.new(km, cuerpo, hashlib.sha256).digest()


def descifrar(datos, clave):
    if len(datos) < len(MAGIA) + 64 or not datos.startswith(MAGIA):
        raise ErrorNube("No es una copia cifrada de PROYECTO ALLAS")
    sal, nonce = datos[10:26], datos[26:42]
    kc, km = _claves(clave or "", sal)
    if not hmac.compare_digest(hmac.new(km, datos[:-32], hashlib.sha256).digest(), datos[-32:]):
        raise ErrorNube("Contraseña incorrecta o archivo dañado")
    return _flujo(datos[42:-32], kc, nonce)


# ------------------------------------------------------------------ destinos
def _rotar_carpeta(carpeta, mantener):
    copias = sorted(f for f in os.listdir(carpeta) if f.startswith("parking-") and f.endswith(EXT))
    for f in copias[:-max(1, mantener)]:
        try:
            os.remove(os.path.join(carpeta, f))
        except OSError:
            pass


def _webdav(url, usuario, clave, nombre, datos, timeout=120):
    base = url.rstrip("/") + "/"
    destino = base + urllib.parse.quote(nombre)
    cab = {"Content-Type": "application/octet-stream"}
    if usuario:
        cab["Authorization"] = "Basic " + base64.b64encode(f"{usuario}:{clave}".encode()).decode()
    req = urllib.request.Request(destino, data=datos, method="PUT", headers=cab)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            if r.status not in (200, 201, 204):
                raise ErrorNube(f"El servidor WebDAV respondió {r.status}")
    except urllib.error.HTTPError as e:
        raise ErrorNube({401: "usuario o contraseña del WebDAV incorrectos", 404: "la carpeta del WebDAV no existe",
                         409: "la carpeta del WebDAV no existe", 507: "no queda espacio en la nube"}.get(e.code, f"error {e.code} del WebDAV"))
    except (urllib.error.URLError, OSError) as e:
        raise ErrorNube(f"No se puede conectar con el WebDAV: {getattr(e, 'reason', e)}")


def subir(cfg, ruta):
    """Cifra la copia 'ruta' y la deja en el destino configurado. Devuelve un texto con lo hecho."""
    with open(ruta, "rb") as f:
        datos = cifrar(f.read(), cfg.get("nube_clave") or "")
    nombre = os.path.basename(ruta) + EXT
    destino = cfg.get("nube_destino") or "carpeta"
    if destino == "carpeta":
        carpeta = (cfg.get("nube_carpeta") or "").strip()
        if not carpeta or not os.path.isdir(carpeta):
            raise ErrorNube("La carpeta de la nube no existe (¿está instalado y abierto OneDrive / Google Drive / Dropbox?)")
        with open(os.path.join(carpeta, nombre + ".tmp"), "wb") as f:
            f.write(datos)
        os.replace(os.path.join(carpeta, nombre + ".tmp"), os.path.join(carpeta, nombre))
        _rotar_carpeta(carpeta, int(cfg.get("nube_mantener") or 10))
        return f"{nombre} en {carpeta}"
    if destino == "webdav":
        url = (cfg.get("nube_webdav_url") or "").strip()
        if not url.startswith(("http://", "https://")):
            raise ErrorNube("Indique la dirección WebDAV (https://…)")
        _webdav(url, (cfg.get("nube_webdav_usuario") or "").strip(), cfg.get("nube_webdav_clave") or "", nombre, datos)
        return f"{nombre} en {url}"
    raise ErrorNube("Destino de la nube no válido")


def tras_copia(db, ruta, tipo):
    """Se llama después de cada copia local: si la copia en la nube está activada, se sube en segundo plano."""
    cfg = db.config()
    if cfg.get("nube_activo") != "1" or tipo in ("antes_de_restaurar", "antes_de_restablecer"):
        return None

    def trabajo():
        ahora = datetime.now().astimezone().isoformat(timespec="seconds")
        try:
            hecho = subir(cfg, ruta)
            db.set_cfg("nube_ultimo", f"{ahora} {hecho}")
            db.set_cfg("nube_ultimo_error", "")
        except Exception as e:  # noqa: BLE001
            db.set_cfg("nube_ultimo_error", f"{ahora[:16].replace('T', ' ')}: {e}")
    hilo = threading.Thread(target=trabajo, daemon=True)
    hilo.start()
    return hilo
