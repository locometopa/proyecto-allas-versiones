"""PROYECTO ALLAS · rutas de la API: clientes, bonos, abonados, renovaciones, comunicados, avisos y cobro online (se registran desde server.App._registrar)."""
import secrets
import time
from . import errores
from .backup import hacer_backup
from .servicios import ErrorNegocio
from .servicios import ROLES_SUPERVISION


def registrar(app, r, p):
    from .server import Respuesta


    # --- 3.5: importar clientes desde CSV / Excel
    @r("POST", "/api/clientes/importar/leer", rol=("admin",), crudo=True)
    def clientes_importar_leer(req):
        from . import importar
        try:
            filas = importar.leer(req.raw, req.query.get("nombre", ""))
        except ValueError as e:
            raise ErrorNegocio(str(e))
        if len(filas) > 20001:
            raise ErrorNegocio("El archivo tiene demasiadas filas (máximo 20.000 clientes)")
        token = secrets.token_hex(8)
        with app._lock:
            app.importaciones = {k: x for k, x in getattr(app, "importaciones", {}).items() if time.time() - x[1] < 3600}
            app.importaciones[token] = (filas, time.time())
        return {"token": token, "cabeceras": filas[0], "muestra": filas[1:11], "filas": len(filas),
                "sugerencia": importar.sugerir(filas[0]), "campos": importar.CAMPOS}

    @r("POST", "/api/clientes/importar", rol=("admin",))
    def clientes_importar(req):
        b = req.body
        filas = getattr(app, "importaciones", {}).get(b.get("token") or "", (None,))[0]
        if filas is None:
            raise ErrorNegocio("Vuelva a elegir el archivo (la lectura ha caducado)")
        if not b.get("simular"):
            try:
                hacer_backup(p.db, app.backups, int(p.cfg("backups_mantener") or 30), p.cfg("backup_destino_extra"),
                             tipo="antes_de_importar", usuario=req.usuario["usuario"])
            except Exception as e_:
                errores.fallo("server.clientes_importar: copia previa", e_, grave=True)
        return p.importar_clientes(req.usuario, filas, b.get("mapeo") or {}, b.get("cabecera", True) is not False,
                                   b.get("tipo_defecto") or "abonado", b.get("duplicados") or "actualizar",
                                   bool(b.get("simular")))

    @r("GET", "/api/clientes/importar/plantilla.csv", rol=("admin",))
    def clientes_plantilla(req):
        txt = ("nombre;nif;telefono;email;direccion;matricula;marca;modelo;tipo;notas\r\n"
               "Lucía Fernández Ruiz;12345678Z;600111222;lucia@ejemplo.com;Calle Mayor 1, Madrid;1234BCD;Seat;Ibiza;abonado;\r\n"
               "Talleres Ruiz S.L.;B87654321;910000000;admin@ejemplo.com;Calle del Taller 12;;;;facturacion;Factura mensual\r\n")
        return Respuesta(("\ufeff" + txt).encode("utf-8"), "text/csv; charset=utf-8",
                         {"Content-Disposition": 'attachment; filename="plantilla_clientes.csv"'})

    # --- 3.5: fotos de los vehículos de los abonados
    @r("GET", r"/api/clientes/(\d+)/vehiculos/([A-Za-z0-9]+)/foto")
    def vehiculo_foto(req, cid, mat):
        datos, tipo = p.foto_vehiculo(int(cid), mat)
        return Respuesta(datos, tipo, {"Cache-Control": "private, max-age=86400"})

    @r("POST", r"/api/clientes/(\d+)/vehiculos/([A-Za-z0-9]+)/foto", crudo=True)
    def vehiculo_foto_subir(req, cid, mat):
        return p.guardar_foto_vehiculo(int(cid), mat, req.raw, req.usuario["id"])

    @r("DELETE", r"/api/clientes/(\d+)/vehiculos/([A-Za-z0-9]+)/foto")
    def vehiculo_foto_quitar(req, cid, mat):
        return p.quitar_foto_vehiculo(int(cid), mat, req.usuario["id"])

    @r("GET", "/api/clientes/exportar.csv", rol=("admin",))
    def clientes_exportar(req):
        return Respuesta(p.exportar_clientes_csv().encode("utf-8"), "text/csv; charset=utf-8",
                         {"Content-Disposition": f'attachment; filename="clientes_{p.ahora():%Y%m%d}.csv"'})

    # --- pagos online (Stripe), suscripciones y avisos a abonados
    @r("GET", "/api/pagos-online", rol=("admin",))
    def pagos_online(req):
        return p.estado_pagos_online()

    @r("POST", "/api/pagos-online/activar", rol=("admin",))
    def pagos_online_activar(req):
        return p.configurar_pagos_online(req.usuario["id"], req.body.get("clave"))

    @r("POST", "/api/pagos-online/desactivar", rol=("admin",))
    def pagos_online_desactivar(req):
        return p.desactivar_pagos_online(req.usuario["id"])

    @r("POST", "/api/pagos-online/planes", rol=("admin",))
    def pagos_online_planes(req):
        return {"rehechos": p.preparar_planes_online(), **p.estado_pagos_online()}

    @r("POST", "/api/pagos-online/sincronizar")
    def pagos_online_sincronizar(req):
        return p.sincronizar_pagos_online()

    @r("GET", r"/api/clientes/(\d+)/suscripcion")
    def suscripcion_enlace(req, cid):
        return p.enlace_suscripcion(int(cid), int(req.query.get("plan_id") or 0))

    @r("POST", r"/api/clientes/(\d+)/suscripcion/enviar")
    def suscripcion_enviar(req, cid):
        return p.enviar_enlace_suscripcion(req.usuario, int(cid), int(req.body.get("plan_id") or 0))

    @r("POST", r"/api/suscripciones/(\d+)/cancelar", rol=ROLES_SUPERVISION)
    def suscripcion_cancelar(req, sid):
        return p.cancelar_suscripcion(req.usuario, int(sid), bool(req.body.get("inmediato")))

    @r("GET", "/api/avisos")
    def avisos(req):
        return {"pendientes": p.avisos_caducidad(), "smtp": p.smtp_listo(),
                "activos": p.cfg("avisos_activos") == "1", "dias": int(p.cfg("avisos_caducidad_dias") or 5),
                "enviados": p.db.q("SELECT a.*, c.nombre FROM avisos a LEFT JOIN clientes c ON c.id=a.cliente_id "
                                   "ORDER BY a.id DESC LIMIT 30")}

    @r("POST", "/api/avisos/enviar")
    def avisos_enviar(req):
        return p.enviar_avisos(req.body.get("referencias"))

    @r("GET", "/api/avisos/mensaje")
    def aviso_mensaje(req):
        return p.mensaje_aviso(req.query.get("ref", ""))

    @r("POST", "/api/avisos/marcar")
    def aviso_marcar(req):
        return p.marcar_aviso(req.usuario, req.body.get("referencia", ""), req.body.get("medio", "gmail"))

    # --- exportaciones y listados
    def _desc(nombre, tipo):
        return {"Content-Disposition": f'attachment; filename="{nombre}"'}

    @r("GET", r"/api/export/vehiculos\.(csv|pdf)")
    def export_vehiculos(req, fmt):
        q = req.query
        args = (q.get("origen", "historial"), q.get("desde"), q.get("hasta"), q.get("buscar", ""), q.get("estado", ""))
        sufijo = "dentro" if args[0] == "dentro" else f"{q.get('desde')}_{q.get('hasta')}"
        if fmt == "csv":
            datos = p.csv_vehiculos(*args, q.get("fecha", "registro"), q.get("dia"), q.get("hora"), q.get("hora_de", "entrada"))
            return Respuesta(datos.encode("utf-8"), "text/csv; charset=utf-8", _desc(f"vehiculos_{sufijo}.csv", fmt))
        return Respuesta(p.pdf_vehiculos(*args), "application/pdf", _desc(f"vehiculos_{sufijo}.pdf", fmt))

    @r("GET", "/api/abonados")
    def abonados(req):
        return p.abonados_listado(req.query.get("estado", "todos"), req.query.get("buscar", ""))

    @r("GET", r"/api/export/abonados\.(csv|pdf)")
    def export_abonados(req, fmt):
        q = req.query
        hoy = p.ahora().strftime("%Y%m%d")
        if fmt == "csv":
            datos = p.csv_abonados(q.get("estado", "todos"), q.get("buscar", ""), q.get("fecha", "bono"), q.get("dia"),
                                   q.get("hora"))
            return Respuesta(datos.encode("utf-8"), "text/csv; charset=utf-8", _desc(f"abonados_{hoy}.csv", fmt))
        return Respuesta(p.pdf_abonados(q.get("estado", "todos"), q.get("buscar", "")), "application/pdf",
                         _desc(f"abonados_{hoy}.pdf", fmt))

    @r("GET", "/api/numeracion", rol=("admin",))
    def numeracion(req):
        return p.numeracion()

    @r("PUT", "/api/numeracion", rol=("admin",))
    def numeracion_guardar(req):
        return p.guardar_numeracion(req.usuario["id"], req.body)

    # --- renovaciones de bonos pendientes de pago
    @r("POST", r"/api/bonos/(\d+)/cobrar")
    def bono_cobrar(req, bid):
        b = req.body
        res = p.cobrar_bono_pendiente(req.usuario, int(bid), b.get("metodo"), b.get("entregado_cent"),
                                      b.get("importe_cent"), b.get("referencia"))
        p.anotar_referencia_pago((res.get("pago") or {}).get("id"), b.get("datafono_ref"))
        return res

    def _supervisor(req):
        actor = req.usuario
        aut = req.body.get("autorizacion")
        if actor["rol"] not in ROLES_SUPERVISION and aut:
            try:
                actor = p.autenticar(aut.get("usuario", ""), aut.get("pin", ""), req.ip)
            except ErrorNegocio:   # sin cerrar la sesión del cajero
                raise ErrorNegocio("Usuario o PIN del supervisor incorrectos", 403)
        return actor

    @r("GET", "/api/comunicados")
    def comunicados(req):
        return {"historial": p.comunicados(), "filtros": p.FILTROS_COMUNICADO,
                "resumen": p.resumen_comunicado(req.query.get("filtro", "todos"))}

    @r("POST", "/api/comunicados", rol=ROLES_SUPERVISION)
    def comunicado_nuevo(req):
        b = req.body
        return p.crear_comunicado(req.usuario, b.get("asunto"), b.get("texto"), b.get("filtro", "todos"),
                                  b.get("medio", "smtp"))

    @r("GET", r"/api/comunicados/(\d+)")
    def comunicado_ver(req, cid):
        return p.comunicado(int(cid))

    @r("GET", r"/api/clientes/(\d+)/recordatorio-mensaje")
    def recordatorio_msg(req, cid):
        return p.recordatorio_deuda_mensaje(int(cid))

    @r("POST", r"/api/clientes/(\d+)/recordatorio-mensaje")
    def recordatorio_msg_enviar(req, cid):
        b = req.body
        return p.enviar_recordatorio_mensaje(req.usuario, int(cid), b.get("texto"), b.get("canal"), b.get("telefono"))

    @r("POST", "/api/mensajes/prueba", rol=("admin",))
    def mensaje_prueba(req):
        return p.prueba_mensaje(req.usuario, req.body.get("telefono"), req.body.get("canal"))

    @r("POST", r"/api/comunicados/(\d+)/whatsapp/(\d+)")
    def comunicado_whatsapp(req, cid, cliente):
        return p.marcar_comunicado_whatsapp(int(cid), int(cliente))

    @r("GET", r"/api/clientes/(\d+)/recordatorio")
    def recordatorio(req, cid):
        return p.recordatorio_deuda(int(cid))

    @r("POST", r"/api/clientes/(\d+)/recordatorio")
    def recordatorio_enviar(req, cid):
        b = req.body
        return p.enviar_recordatorio_deuda(req.usuario, int(cid), b.get("asunto"), b.get("texto"),
                                           b.get("medio", "smtp"), b.get("email"))

    @r("POST", r"/api/bonos/(\d+)/cancelar-deuda")
    def bono_cancelar_deuda(req, bid):
        return p.cancelar_deuda(_supervisor(req), int(bid), req.body.get("motivo", ""))

    @r("POST", r"/api/clientes/(\d+)/cancelar-deudas")
    def cliente_cancelar_deudas(req, cid):
        return p.cancelar_deudas_cliente(_supervisor(req), int(cid), req.body.get("motivo", ""),
                                         bool(req.body.get("quitar_renovacion")))

    @r("GET", "/api/renovaciones")
    def renovaciones(req):
        filas = p.db.q("SELECT b.id, b.numero, b.desde, b.hasta, b.importe_cent, c.id cliente_id, c.nombre, c.email, "
                       "pl.nombre plan FROM bonos b JOIN clientes c ON c.id=b.cliente_id JOIN planes_bono pl ON pl.id=b.plan_id "
                       "WHERE b.estado='activo' AND b.pagado=0 ORDER BY b.desde")
        for f in filas:
            f["numero_txt"] = p.numero_bono(f["numero"])
            f["aviso"] = p.db.q1("SELECT fecha, estado FROM avisos WHERE tipo='renovacion' AND referencia=?",
                                 (f"bono:{f['id']}",))
        return filas

    @r("GET", r"/api/renovaciones/(\d+)/mensaje")
    def renovacion_mensaje(req, bid):
        _, cli, datos = p._datos_aviso_renovacion(int(bid))
        asunto, texto = p._texto_aviso("renovacion", dict(datos, nombre=cli["nombre"]))
        p.db.ex("INSERT INTO avisos(cliente_id, tipo, referencia, destino, fecha, estado, detalle) "
                "VALUES(?, 'renovacion', ?, ?, ?, 'enviado', 'a mano') ON CONFLICT(tipo, referencia) DO UPDATE SET "
                "fecha=excluded.fecha, estado='enviado', detalle='a mano'",
                (cli["id"], f"bono:{bid}", cli["email"], p.ahora().isoformat(timespec="seconds")))
        return {"email": cli["email"], "asunto": asunto, "texto": texto}

    @r("POST", r"/api/renovaciones/(\d+)/enviar")
    def renovacion_enviar(req, bid):
        if not p.smtp_listo():
            raise ErrorNegocio("Configure el envío automático (SMTP) en Ajustes → Email", 409)
        p.db.ex("DELETE FROM avisos WHERE tipo='renovacion' AND referencia=?", (f"bono:{bid}",))
        return {"estado": p._aviso_renovacion(int(bid))}

    # --- clientes y bonos
    @r("GET", "/api/clientes")
    def clientes(req):
        return p.clientes(req.query.get("buscar", ""), req.query.get("filtro", "todos"))

    def _con_aviso_nif(c):
        from .servicios import nif_valido
        if c.get("nif") and not nif_valido(c["nif"]):
            c["aviso"] = f"El NIF/CIF {c['nif']} no parece válido. Se ha guardado igualmente: revíselo si es un error."
        return c

    @r("POST", "/api/clientes")
    def cliente_nuevo(req):
        return _con_aviso_nif(p.cliente(p.guardar_cliente(req.body, req.usuario["id"])))

    @r("GET", r"/api/clientes/(\d+)")
    def cliente(req, cid):
        p.renovar_bonos_automaticos(int(cid))
        return p.cliente(int(cid))

    @r("PUT", r"/api/clientes/(\d+)")
    def cliente_editar(req, cid):
        return _con_aviso_nif(p.cliente(p.guardar_cliente(req.body, req.usuario["id"], int(cid))))

    @r("GET", r"/api/clientes/(\d+)/periodo")
    def periodo(req, cid):
        desde = req.query.get("desde") or p.proximo_desde(int(cid))
        plan, d, h = p.periodo_bono(int(req.query["plan_id"]), desde)
        return {"desde": d.isoformat(), "hasta": h.isoformat(), "precio_cent": plan["precio_cent"]}

    @r("POST", r"/api/clientes/(\d+)/bono")
    def vender_bono(req, cid):
        b = req.body
        return p.vender_bono(req.usuario, int(cid), int(b["plan_id"]), b.get("desde"),
                             b.get("metodo", "efectivo"), b.get("entregado_cent"), b.get("renovacion_auto"),
                             b.get("importe_cent"), b.get("referencia"))

    @r("POST", r"/api/clientes/(\d+)/entrada")
    def entrada_abonado(req, cid):
        return p.entrada_abonado(req.usuario, int(cid), req.body.get("matricula"))

    @r("POST", r"/api/clientes/(\d+)/tarjeta")
    def tarjeta(req, cid):
        return p.imprimir_tarjeta(req.usuario, int(cid))

    @r("POST", r"/api/bonos/(\d+)/anular")
    def anular_bono(req, bid):
        actor = req.usuario
        aut = req.body.get("autorizacion")
        if actor["rol"] not in ROLES_SUPERVISION and aut:
            actor = p.autenticar(aut.get("usuario", ""), aut.get("pin", ""), req.ip)
        p.anular_bono(actor, int(bid), req.body.get("motivo", ""))
        return {"ok": True}

    @r("GET", "/api/planes")
    def planes(req):
        return p.planes(req.query.get("activos") == "1")

    @r("POST", "/api/planes", rol=("admin",))
    def plan_nuevo(req):
        return {"id": p.guardar_plan(req.body, req.usuario["id"])}

    @r("PUT", r"/api/planes/(\d+)", rol=("admin",))
    def plan_editar(req, pid):
        return {"id": p.guardar_plan(req.body, req.usuario["id"], int(pid))}
