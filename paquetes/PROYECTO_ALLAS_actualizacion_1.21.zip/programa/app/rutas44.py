"""PROYECTO ALLAS 4.4 · rutas nuevas del servidor (se registran desde server.App._registrar)."""
import base64
import json
import time

from .servicios import ErrorNegocio
from . import errores

MINUTOS_SUPERVISION = 30


def registrar(app, r, p):
    from .server import Respuesta, hacer_backup
    app.supervision = getattr(app, "supervision", {})   # resumen del token de sesión → caduca (epoch)

    def sup_abierta(req):
        h = app._hash_tok(getattr(req, "token", "") or "")
        t = app.supervision.get(h)
        if t and t > time.time():
            app.supervision[h] = time.time() + MINUTOS_SUPERVISION * 60   # se renueva mientras se usa
            return True
        app.supervision.pop(h, None)
        return False

    try:
        p.asegurar_publicidad_ejemplo()   # fotos de ejemplo para la pantalla de cliente (una sola vez)
    except Exception as e_:  # noqa: BLE001
        errores.fallo("rutas44.sup_abierta", e_)

    @r("POST", "/api/publicidad/ejemplos", rol=("admin",))
    def publicidad_ejemplos(req):
        return p.poner_publicidad_ejemplo(req.usuario["id"])

    @r("DELETE", "/api/publicidad/ejemplos", rol=("admin",))
    def publicidad_quitar_ejemplos(req):
        return p.quitar_publicidad_ejemplo(req.usuario["id"])

    # ------------------------------------------------------------------ supervisión
    @r("GET", "/api/supervision", rol=("admin",))
    def supervision_estado(req):
        abierta = sup_abierta(req)
        r = {"configurada": True, "clave_defecto": not p.supervision_configurada(), "abierta": abierta,
             "ocultos": p.ocultos() if abierta else None, "minutos": MINUTOS_SUPERVISION}
        if abierta:   # 4.8: tipo de licencia
            from .licencia import NOMBRE_MODULO
            r.update(plan=p.plan_supervision(), planes=p.planes_supervision(), tipo=p.tipo_licencia(), demo=bool(p.demo),
                     modulos_licencia=list(p.estado_licencia().get("modulos") or []), nombres_modulos=dict(NOMBRE_MODULO))
        return r

    @r("POST", "/api/supervision/entrar", rol=("admin",))
    def supervision_entrar(req):
        try:
            origen = p.comprobar_clave_supervision(req.body.get("clave") or "", getattr(req, "ip", None))
        except ErrorNegocio as e:
            if e.codigo == 403:
                with p.db.transaccion() as c:
                    p.auditar(c, req.usuario["id"], "supervision_fallo", getattr(req, "ip", "") or "")
            raise
        app.supervision[app._hash_tok(req.token)] = time.time() + MINUTOS_SUPERVISION * 60
        with p.db.transaccion() as c:
            p.auditar(c, req.usuario["id"], "supervision_entrar", origen)
        return {"abierta": True, "origen": origen, "ocultos": p.ocultos(), "minutos": MINUTOS_SUPERVISION}

    @r("PUT", "/api/supervision/plan", rol=("admin",))
    def supervision_plan(req):
        if not sup_abierta(req):
            raise ErrorNegocio("Entre en Supervisión con su contraseña", 403)
        if p.demo:
            raise ErrorNegocio("En la demostración están todos los módulos: el tipo de licencia se cambia con sus datos reales.")
        r = p.guardar_plan_supervision(req.usuario["id"], req.body.get("plan") or "")
        p.db.set_cfg("ui_recargar", str(int(time.time())))   # los demás puestos se recargan solos
        return r

    @r("POST", "/api/supervision/salir", rol=("admin",))
    def supervision_salir(req):
        app.supervision.pop(app._hash_tok(req.token), None)
        return {"abierta": False}

    @r("PUT", "/api/supervision/ocultos", rol=("admin",))
    def supervision_ocultos(req):
        if not sup_abierta(req):
            raise ErrorNegocio("Entre en Supervisión con su contraseña", 403)
        return p.guardar_ocultos(req.usuario["id"], req.body.get("ocultos"))

    # ------------------------------------------------------------------ estabilidad
    @r("GET", "/api/salud", publica=True)
    def salud(req):
        p.db.q1("SELECT 1 x")
        return {"ok": True}

    @r("POST", "/api/registro-error")
    def registro_error(req):
        return p.registrar_error_cliente(req.body or {}, req.usuario, getattr(req, "ip", None))

    @r("GET", "/api/errores-pantalla", rol=("admin",))
    def errores_pantalla(req):
        return {"errores": p.errores_cliente(), "integridad": p.cfg("integridad_resultado"),
                "integridad_fecha": p.cfg("integridad_fecha")}

    @r("POST", "/api/integridad", rol=("admin",))
    def integridad(req):
        return {"resultado": p.comprobar_integridad(), "fecha": p.cfg("integridad_fecha")}

    # ------------------------------------------------------------------ exportar por separado
    @r("GET", r"/api/exportar/(tarifas|servicios|productos)\.json", rol=("admin",))
    def exportar_parte(req, que):
        datos = p.exportar_config_parte(que)
        nombre = f"{que}_" + p.ahora().strftime("%Y%m%d-%H%M") + ".json"
        return Respuesta(json.dumps(datos, ensure_ascii=False, indent=2).encode(), "application/json; charset=utf-8",
                         {"Content-Disposition": f'attachment; filename="{nombre}"'})

    @r("GET", r"/api/clientes/exportar-(abonados|no-abonados)\.csv", rol=("admin",))
    def clientes_exportar_tipo(req, tipo):
        t = "abonado" if tipo == "abonados" else "facturacion"
        nombre = ("abonados" if t == "abonado" else "clientes_no_abonados") + f"_{p.ahora():%Y%m%d}.csv"
        return Respuesta(p.exportar_clientes_tipo_csv(t).encode("utf-8"), "text/csv; charset=utf-8",
                         {"Content-Disposition": f'attachment; filename="{nombre}"'})

    # ------------------------------------------------------------------ clientes que no son abonados
    @r("GET", "/api/clientes/no-abonados", rol=("admin",))
    def no_abonados(req):
        return p.resumen_no_abonados()

    @r("POST", "/api/clientes/no-abonados/borrar", rol=("admin",))
    def no_abonados_borrar(req):
        app._comprobar_pin(req)
        if (req.body.get("confirmacion") or "").strip().upper() != "BORRAR":
            raise ErrorNegocio("Escriba BORRAR para confirmar")
        hacer_backup(p.db, app.backups, int(p.cfg("backups_mantener") or 30), p.cfg("backup_destino_extra"),
                     tipo="antes_de_borrar", usuario=req.usuario["usuario"])
        return p.borrar_clientes_no_abonados(req.usuario["id"], req.body.get("confirmacion"))

    # ------------------------------------------------------------------ logo propio de la factura
    @r("GET", "/api/logo/factura", rol=("admin",))
    def logo_factura_info(req):
        from . import logo as logos
        return logos.info_factura(p.carpeta_logo) or {}

    @r("POST", "/api/logo/factura", rol=("admin",))
    def logo_factura_subir(req):
        from . import logo as logos
        try:
            datos = base64.b64decode(req.body.get("jpeg") or "")
            i = logos.guardar_factura(p.carpeta_logo, datos)
        except (ValueError, TypeError) as e:
            raise ErrorNegocio(str(e) or "Imagen no válida")
        with p.db.transaccion() as c:
            p.auditar(c, req.usuario["id"], "logo_factura_guardar", f"{i['ancho']}x{i['alto']}")
            c.execute("INSERT OR REPLACE INTO config(clave, valor) VALUES('logo_factura', '1')")
        return i

    @r("DELETE", "/api/logo/factura", rol=("admin",))
    def logo_factura_borrar(req):
        from . import logo as logos
        logos.borrar_factura(p.carpeta_logo)
        with p.db.transaccion() as c:
            p.auditar(c, req.usuario["id"], "logo_factura_borrar", "")
        return {"ok": True}

    @r("GET", r"/api/logo/factura\.jpg")
    def logo_factura_archivo(req):
        from . import logo as logos
        d = logos.jpeg(p.carpeta_logo)
        if not d:
            raise ErrorNegocio("No hay logo", 404)
        return Respuesta(d["jpeg"], "image/jpeg")

    # ------------------------------------------------------------------ semáforo y cartel
    @r("GET", "/api/senales", rol=("admin",))
    def senales(req):
        return p.estado_senales()

    @r("POST", r"/api/senales/(semaforo|cartel)/probar", rol=("admin",))
    def senal_probar(req, pref):
        return p.probar_senal(req.usuario["id"], pref, req.body.get("estado"))

    # ------------------------------------------------------------------ caja móvil: matrícula desde una foto
    @r("POST", "/api/ocr/matricula", crudo=True)
    def ocr_matricula(req):
        return p.leer_matricula_foto(req.raw)

    # ------------------------------------------------------------------ impresora A4
    @r("POST", r"/api/facturas/(\d+)/imprimir-a4")
    def factura_a4(req, pid):
        return p.imprimir_factura_a4(req.usuario, int(pid))

    @r("POST", r"/api/facturas/(\d+)/imprimir")
    def factura_imprimir(req, pid):
        if p.a4_para_factura(int(pid)) or p.es_factura_proveedor(int(pid)):
            return p.imprimir_factura_a4(req.usuario, int(pid))
        return p.imprimir_factura(req.usuario, int(pid))

    # ------------------------------------------------------------------ 4.9: plantillas del Editor de plantillas
    @r("GET", "/api/plantillas", rol=("admin",))
    def plantillas_estado(req):
        return p.plantillas_estado()

    @r("GET", r"/api/plantillas/(\w+)", rol=("admin",))
    def plantilla_descargar(req, tipo):
        return Respuesta(json.dumps(p.plantilla_json(tipo), ensure_ascii=False, indent=2).encode("utf-8"), "application/json",
                         {"Content-Disposition": f'attachment; filename="plantilla_{tipo}.json"'})

    @r("PUT", "/api/plantillas", rol=("admin",))
    def plantilla_cargar(req):
        return p.guardar_plantilla(req.usuario["id"], req.body)

    @r("DELETE", r"/api/plantillas/(\w+)", rol=("admin",))
    def plantilla_quitar(req, tipo):
        return p.quitar_plantilla(req.usuario["id"], tipo)

    # ------------------------------------------------------------------ 4.5: cambiar de zona un vehículo que está dentro
    @r("PUT", r"/api/tickets/(\d+)/zona")
    def ticket_zona(req, tid):
        return p.cambiar_zona(req.usuario, int(tid), req.body.get("zona_id"))

    # ------------------------------------------------------------------ 4.5: arranque con Windows y aplicar Supervisión
    @r("GET", "/api/sistema/autoarranque", rol=("admin",))
    def autoarranque(req):
        return p.autoarranque()

    @r("PUT", "/api/sistema/autoarranque", rol=("admin",))
    def autoarranque_guardar(req):
        return p.guardar_autoarranque(req.usuario["id"], bool(req.body.get("activo")), req.body.get("modo") or "normal")

    @r("POST", "/api/supervision/aplicar", rol=("admin",))
    def supervision_aplicar(req):
        if not sup_abierta(req):
            raise ErrorNegocio("Entre en Supervisión con su contraseña", 403)
        p.db.set_cfg("ui_recargar", str(int(time.time())))
        return {"ok": True}
