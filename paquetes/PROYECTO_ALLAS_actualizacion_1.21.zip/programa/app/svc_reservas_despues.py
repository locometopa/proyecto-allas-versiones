"""PROYECTO ALLAS 1.18 · lo que pasa DESPUÉS de reservar: modificar la reserva, liberar las no presentadas,
recordatorio por email con QR e informe de reservas.

Las reglas de cupo, fechas y precios son las de siempre (svc_reservas.py); aquí solo se reutilizan.
"""
import csv
import io
import threading
from datetime import timedelta

from .utiles import ErrorNegocio, parse

ESTADOS_INFORME = ("pendiente", "usada", "cancelada", "no_presentada")


class SvcReservasDespues:
    # ============================================================ modificar
    def modificar_reserva_online(self, usuario, rid, datos, como_cliente=False):
        """Cambia fechas, zona o tipo de vehículo de una reserva pendiente. El cliente puede hasta el mismo límite que para
        cancelar gratis; el personal, siempre. Se vuelve a comprobar el cupo (sin contar la propia reserva) y se recalcula el precio."""
        self._exigir_reservas_online()
        self.caducar_reservas_sin_pago()
        if usuario:
            self._exigir_permiso(usuario, "reservas")
        r = self.db.q1("SELECT * FROM reservas_previstas WHERE id=? AND origen IN ('mostrador','web')", (int(rid),))
        if not r:
            raise ErrorNegocio("Reserva no encontrada", 404)
        if r["estado"] != "pendiente":
            raise ErrorNegocio("Solo se pueden modificar las reservas pendientes", 409)
        if como_cliente:
            limite = parse(r["desde"]) - timedelta(hours=self._ajuste_res("reservas_cancel_horas"))
            if self.ahora() > limite:
                raise ErrorNegocio(f"Ya no se puede modificar: el plazo terminó {self._ajuste_res('reservas_cancel_horas')} horas antes de la entrada. "
                                   "Avise al parking.", 409)
        origen = "web" if como_cliente else r["origen"]
        nuevos = {"desde": datos.get("desde") or r["desde"], "hasta": datos.get("hasta") or r["hasta"],
                  "hora_desde": datos.get("hora_desde"), "hora_hasta": datos.get("hora_hasta"),
                  "zona_id": datos.get("zona_id") if datos.get("zona_id") not in (None, "") else r["zona_id"],
                  "tipo_vehiculo": datos.get("tipo_vehiculo") if "tipo_vehiculo" in datos else r["tipo_vehiculo"], "plazas": r["plazas"]}
        d, h = self._fechas_reserva(nuevos, origen)
        zona_id = int(nuevos["zona_id"]) if nuevos["zona_id"] not in (None, "") else None
        precio = self.presupuesto_reserva(nuevos, origen)["importe_cent"]
        senal = self.senal_para(precio)
        with self.db.transaccion() as c:
            cupo = self._cupo_zona(c, zona_id)
            if self._ocupacion_maxima(c, zona_id, d, h, excluir=r["id"]) + (r["plazas"] or 1) > cupo:
                raise ErrorNegocio("No quedan plazas libres en esas fechas", 409)
            if c.execute("SELECT 1 FROM reservas_previstas WHERE matricula=? AND estado='pendiente' AND id<>? AND desde < ? AND hasta > ?",
                         (r["matricula"], r["id"], h.isoformat(timespec="seconds"), d.isoformat(timespec="seconds"))).fetchone():
                raise ErrorNegocio(f"La matrícula {r['matricula']} ya tiene otra reserva en esas fechas", 409)
            pago, limite, sesion = r["pago"], r["pago_limite"], r["pago_sesion"]
            if r["pago"] == "pagada":
                if senal != r["senal_cent"]:
                    raise ErrorNegocio(f"La señal de esas fechas sería de {senal / 100:.2f} € y ya ha pagado {r['senal_cent'] / 100:.2f} €. "
                                       "Elija fechas con un importe parecido o cancele y vuelva a reservar.", 409)
            elif senal:
                pago, sesion = "pendiente_pago", None   # el importe cambió: la sesión de pago anterior ya no vale
                limite = min(parse(limite) if limite else self.ahora() + timedelta(hours=self._ajuste_res("reservas_pago_horas")), d).isoformat(timespec="seconds")
            else:
                pago, limite, sesion = "en_parking", None, None
            c.execute("UPDATE reservas_previstas SET desde=?, hasta=?, zona_id=?, tipo_vehiculo=?, importe_cent=?, senal_cent=?, pago=?, pago_limite=?, "
                      "pago_sesion=?, modificada=?, recordatorio=NULL, revisada=CASE WHEN origen='web' THEN 0 ELSE revisada END WHERE id=?",
                      (d.isoformat(timespec="seconds"), h.isoformat(timespec="seconds"), zona_id, nuevos["tipo_vehiculo"], precio, senal, pago, limite,
                       sesion, self.ahora().isoformat(timespec="seconds"), r["id"]))
            self.auditar(c, usuario["id"] if usuario else None, "reserva_online_modificar",
                         f"{r['codigo']} {r['matricula']} {r['desde'][:16]}→{r['hasta'][:16]} a {d:%Y-%m-%d %H:%M}→{h:%Y-%m-%d %H:%M}")
        if r["email"]:   # confirmación con los datos nuevos
            self.db.ex("UPDATE reservas_previstas SET email_estado='pendiente', email_intentos=0 WHERE id=?", (r["id"],))
            base = self._base_publica()
            if getattr(self, "email_sincrono", False) or not (self.cfg("smtp_servidor") or "").strip():
                self.enviar_email_reserva(r["id"], base)
            else:
                threading.Thread(target=self.enviar_email_reserva, args=(r["id"], base), daemon=True).start()
        return self.db.q1("SELECT * FROM reservas_previstas WHERE id=?", (r["id"],))

    def pub_modificar(self, datos, ip):
        from .svc_reservas_publicas import limpiar_publico
        rid = self._buscar_publica(datos.get("codigo"), datos.get("matricula"), ip)
        self._limitar(("modificar", ip), 10, 3600)
        d = limpiar_publico(datos)
        nuevos = {"desde": d["desde"], "hasta": d["hasta"]}
        if d["zona_id"]:
            nuevos["zona_id"] = self._zona_publica(d["zona_id"])
        if self.cfg("tipos_vehiculo_activo") == "1" and d["tipo_vehiculo"]:
            nuevos["tipo_vehiculo"] = self._tipo_publico(d["tipo_vehiculo"])
        if not nuevos["desde"] or not nuevos["hasta"]:
            raise ErrorNegocio("Indique la nueva entrada y salida")
        self.modificar_reserva_online(None, rid, nuevos, como_cliente=True)
        return self._vista_publica(rid)

    # ============================================================ no presentados
    def liberar_no_presentadas(self):
        """Si se configura, la reserva que no ha llegado pasados N minutos de su hora de entrada se cancela y la plaza vuelve a quedar libre.
        La señal pagada NO se devuelve (queda retenida: el cliente la perdió por no presentarse)."""
        minutos = self._ajuste_res("reservas_noshow_min")
        if minutos <= 0:
            return 0
        corte = (self.ahora() - timedelta(minutes=minutos)).isoformat(timespec="seconds")
        filas = self.db.q("SELECT id, codigo, matricula, pago FROM reservas_previstas WHERE estado='pendiente' AND origen IN ('mostrador','web') "
                          "AND desde < ?", (corte,))
        if filas:
            ahora = self.ahora().isoformat(timespec="seconds")
            with self.db.transaccion() as c:
                for f in filas:
                    c.execute("UPDATE reservas_previstas SET estado='cancelada', cancelada=?, noshow=1 WHERE id=? AND estado='pendiente'", (ahora, f["id"]))
                    self.auditar(c, None, "reserva_online_no_presentada", f"{f['codigo']} {f['matricula']}" + (" (señal retenida)" if f["pago"] == "pagada" else ""))
        return len(filas)

    # ============================================================ recordatorio
    def enviar_recordatorios_reservas(self):
        """Email con el código y el QR unas horas antes de la entrada (ajuste «Recordatorio»; 0 = no se envía)."""
        horas = self._ajuste_res("reservas_recordatorio_horas")
        if horas <= 0 or not (self.cfg("smtp_servidor") or "").strip():
            return 0
        ahora = self.ahora()
        n = 0
        filas = self.db.q("SELECT * FROM reservas_previstas WHERE estado='pendiente' AND origen='web' AND email IS NOT NULL AND email<>'' "
                          "AND recordatorio IS NULL AND desde > ? AND desde <= ? ORDER BY desde LIMIT 50",
                          (ahora.isoformat(timespec="seconds"), (ahora + timedelta(hours=horas)).isoformat(timespec="seconds")))
        for r in filas:
            if parse(r["creada"]) >= parse(r["desde"]) - timedelta(hours=horas):   # la acaba de hacer: ya tiene la confirmación
                self.db.ex("UPDATE reservas_previstas SET recordatorio='omitido' WHERE id=?", (r["id"],))
                continue
            if self.enviar_recordatorio_reserva(r["id"]) == "enviado":
                n += 1
        return n

    def enviar_recordatorio_reserva(self, rid):
        from .codigos import qr_png
        r = self.db.q1("SELECT r.*, z.nombre zona_nombre FROM reservas_previstas r LEFT JOIN zonas z ON z.id=r.zona_id WHERE r.id=?", (int(rid),))
        cfg = self.db.config()
        fmt = lambda s: parse(s).strftime("%d/%m/%Y %H:%M")   # noqa: E731
        base = self._base_publica()
        enlace = f"\nPara ver, modificar o cancelar su reserva: {base}{'&' if '?' in base else '?'}c={r['codigo']}\n" if base else ""
        aviso_pago = ""
        if r["pago"] == "pendiente_pago":
            aviso_pago = f"\nRecuerde que falta pagar la señal ({r['senal_cent'] / 100:.2f} €) o la reserva se cancelará sola.\n"
        texto = (f"Hola {r['cliente'] or ''},\n\nLe recordamos su reserva en {cfg.get('nombre_parking') or 'el parking'}.\n\n"
                 f"Código: {r['codigo']}\nMatrícula: {r['matricula']}\nEntrada: {fmt(r['desde'])}\nSalida: {fmt(r['hasta'])}\n"
                 + (f"Zona: {r['zona_nombre']}\n" if r["zona_nombre"] else "") + aviso_pago + enlace
                 + "\nAdjuntamos el código QR de su reserva: enséñelo al entrar si se lo piden.\n")
        try:
            from .correo import enviar
            enviar(cfg, r["email"], f"Recordatorio de su reserva {r['codigo']} · {cfg.get('nombre_parking') or 'Parking'}", texto,
                   [(f"reserva-{r['codigo']}.png", qr_png(r["codigo"]), "image/png")])
        except Exception as ex:  # noqa: BLE001  se reintenta en la siguiente pasada
            from . import errores
            errores.fallo("reservas.recordatorio", ex)
            return "error"
        self.db.ex("UPDATE reservas_previstas SET recordatorio=? WHERE id=?", (self.ahora().isoformat(timespec="seconds"), r["id"]))
        return "enviado"

    # ============================================================ informe
    def informe_reservas(self, desde=None, hasta=None):
        """Reservas cuya entrada cae entre dos fechas (por defecto, el mes en curso) con totales, señales y excesos de estancia."""
        from datetime import date
        hoy = self.ahora().date()
        try:
            d = date.fromisoformat(str(desde)[:10]) if desde else hoy.replace(day=1)
            h = date.fromisoformat(str(hasta)[:10]) if hasta else hoy
        except ValueError:
            raise ErrorNegocio("Fecha no válida")
        if h < d:
            raise ErrorNegocio("La fecha final es anterior a la inicial")
        if (h - d).days > 366:
            raise ErrorNegocio("El informe admite como máximo un año")
        filas = self.db.q("SELECT r.id, r.codigo, r.matricula, r.cliente, r.origen, r.desde, r.hasta, r.estado, r.noshow, r.importe_cent, r.senal_cent, r.pago, "
                          "r.pago_metodo, r.plazas, z.nombre zona, tk.salida, tk.estado tk_estado FROM reservas_previstas r "
                          "LEFT JOIN zonas z ON z.id=r.zona_id LEFT JOIN tickets tk ON tk.id=r.ticket_id "
                          "WHERE r.origen IN ('mostrador','web') AND substr(r.desde,1,10)>=? AND substr(r.desde,1,10)<=? ORDER BY r.desde, r.id LIMIT 5000",
                          (d.isoformat(), h.isoformat()))
        ahora = self.ahora()
        tot = {e: 0 for e in ESTADOS_INFORME}
        senal = {"cobrada": 0, "devuelta": 0, "por_devolver": 0, "retenida": 0, "pendiente": 0}
        excesos = []
        for f in filas:
            f["estado_informe"] = "no_presentada" if f["noshow"] else f["estado"]
            tot[f["estado_informe"]] += 1
            if f["pago"] in ("pagada", "a_devolver", "devuelta"):
                senal["cobrada"] += f["senal_cent"]
            if f["pago"] == "devuelta":
                senal["devuelta"] += f["senal_cent"]
            elif f["pago"] == "a_devolver":
                senal["por_devolver"] += f["senal_cent"]
            elif f["pago"] == "pagada" and f["noshow"]:
                senal["retenida"] += f["senal_cent"]
            elif f["pago"] == "pendiente_pago" and f["estado"] == "pendiente":
                senal["pendiente"] += f["senal_cent"]
            f["exceso_min"] = 0
            if f["estado"] == "usada":
                fin = parse(f["salida"]) if f["salida"] else ahora
                if fin > parse(f["hasta"]) + timedelta(minutes=5):
                    f["exceso_min"] = int((fin - parse(f["hasta"])).total_seconds() // 60)
                    excesos.append(f["exceso_min"])
        validas = [f for f in filas if f["estado_informe"] in ("pendiente", "usada")]
        return {"desde": d.isoformat(), "hasta": h.isoformat(), "total": len(filas), "por_estado": tot,
                "por_origen": {o: sum(1 for f in filas if f["origen"] == o) for o in ("web", "mostrador")},
                "importe_previsto_cent": sum(f["importe_cent"] for f in validas), "senal": senal,
                "no_presentadas_pct": round(100 * tot["no_presentada"] / len(filas)) if filas else 0,
                "excesos": {"n": len(excesos), "minutos_medios": round(sum(excesos) / len(excesos)) if excesos else 0, "max": max(excesos) if excesos else 0},
                "filas": filas[:500], "truncado": len(filas) > 500}

    def informe_reservas_csv(self, desde=None, hasta=None):
        inf = self.informe_reservas(desde, hasta)
        sal = io.StringIO()
        w = csv.writer(sal, delimiter=";")
        w.writerow(["Código", "Matrícula", "Cliente", "Origen", "Zona", "Entrada", "Salida", "Estado", "Plazas", "Importe previsto (€)",
                    "Señal (€)", "Estado del pago", "Método", "Exceso de estancia (min)"])
        for f in inf["filas"]:
            w.writerow([f["codigo"], f["matricula"], f["cliente"] or "", f["origen"], f["zona"] or "", f["desde"][:16].replace("T", " "),
                        f["hasta"][:16].replace("T", " "), f["estado_informe"], f["plazas"], f"{f['importe_cent'] / 100:.2f}".replace(".", ","),
                        f"{f['senal_cent'] / 100:.2f}".replace(".", ","), f["pago"], f["pago_metodo"] or "", f["exceso_min"]])
        return ("﻿" + sal.getvalue()).encode("utf-8")
