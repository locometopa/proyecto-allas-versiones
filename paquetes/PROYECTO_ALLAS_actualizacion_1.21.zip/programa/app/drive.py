"""Actualizaciones desde una carpeta de Google Drive (4.16).

El distribuidor sube los paquetes firmados (PROYECTO_ALLAS_actualizacion_X.Y.zip) a SU carpeta de Drive, compartida con
«Cualquier persona con el enlace». La carpeta va incluida en el programa (CARPETA_DEFECTO) y no se enseña en pantalla.
Sin clave: se lee el listado público de la carpeta (embeddedfolderview) y se descarga el archivo por su enlace público.
Con clave de API de Google (opcional, ajuste oculto actualizaciones_drive_clave): se usa la API oficial de Drive v3.
Solo se guarda un paquete si la firma del fabricante es correcta, igual que con los demás orígenes.
Sin dependencias: urllib. ALLAS_DRIVE_API / ALLAS_DRIVE_WEB cambian las direcciones (las pruebas usan un servidor local)."""
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request

API = "https://www.googleapis.com"
WEB = "https://drive.google.com"
DESCARGA = "https://drive.usercontent.google.com"
CARPETA_DEFECTO = "1vmFZn1KAeyq9zCxkrMtdW4EFyabNATca"   # carpeta del distribuidor (no se muestra en pantalla)
_ID = re.compile(r"^[A-Za-z0-9_\-]{10,120}$")
_NOMBRE = re.compile(r"actualizaci[oó]n[_\- ]v?(\d+(?:\.\d+)+)\.zip$", re.I)


class ErrorDrive(Exception):
    pass


def base():
    return (os.environ.get("ALLAS_DRIVE_API") or API).rstrip("/")


def base_web():
    return (os.environ.get("ALLAS_DRIVE_WEB") or WEB).rstrip("/")


def base_descarga():
    return (os.environ.get("ALLAS_DRIVE_WEB") or DESCARGA).rstrip("/")


def id_carpeta(texto):
    """Acepta el enlace de la carpeta (…/folders/ID?usp=sharing, …/open?id=ID) o el ID suelto."""
    t = (texto or "").strip()
    if not t:
        raise ErrorDrive("Falta la carpeta de actualizaciones (configuración interna)")
    if _ID.match(t):
        return t
    u = urllib.parse.urlparse(t)
    m = re.search(r"/folders/([A-Za-z0-9_\-]{10,120})", u.path)
    if m:
        return m.group(1)
    q = urllib.parse.parse_qs(u.query).get("id")
    if q and _ID.match(q[0]):
        return q[0]
    raise ErrorDrive("La carpeta de actualizaciones configurada no es válida (configuración interna).")


def _error_http(e):
    try:
        msg = (json.loads(e.read() or b"{}").get("error") or {}).get("message") or ""
    except (ValueError, AttributeError):
        msg = ""
    if e.code == 400 and "key" in msg.lower():
        return "El servicio de actualizaciones no acepta la clave configurada (400)."
    if e.code == 404:
        return "El servicio de actualizaciones no está disponible: no se encuentra la carpeta publicada (404)."
    if e.code in (401, 403):
        return f"El servicio de actualizaciones rechaza la petición ({e.code}). Avise a su distribuidor."
    return f"El servicio de actualizaciones responde con error {e.code}."


def _pedir(url, timeout):
    req = urllib.request.Request(url, headers={"User-Agent": "PROYECTO-ALLAS"})
    try:
        return urllib.request.urlopen(req, timeout=timeout)
    except urllib.error.HTTPError as e:
        raise ErrorDrive(_error_http(e))
    except (urllib.error.URLError, OSError) as e:
        raise ErrorDrive(f"No se puede conectar con el servicio de actualizaciones: {getattr(e, 'reason', e)}")


def listar(carpeta, clave):
    """Paquetes de actualización de la carpeta: [{id, archivo, version, tamano, fecha}], el más reciente de cada versión."""
    cid = id_carpeta(carpeta or CARPETA_DEFECTO)
    if not (clave or "").strip():
        return _listar_publica(cid)
    vistos, token = {}, None
    for _ in range(10):   # hasta 2000 archivos
        params = {"q": f"'{cid}' in parents and trashed=false", "fields": "nextPageToken,files(id,name,size,modifiedTime)", "pageSize": "200",
                  "supportsAllDrives": "true", "includeItemsFromAllDrives": "true", "key": clave.strip()}
        if token:
            params["pageToken"] = token
        with _pedir(f"{base()}/drive/v3/files?" + urllib.parse.urlencode(params), 20) as r:
            try:
                datos = json.loads(r.read() or b"{}")
            except ValueError:
                raise ErrorDrive("Respuesta no válida del servicio de actualizaciones")
        for f in datos.get("files") or []:
            m = _NOMBRE.search(f.get("name") or "")
            if not m:
                continue
            x = {"id": f["id"], "archivo": f["name"], "version": m.group(1), "fecha": (f.get("modifiedTime") or "")[:10],
                 "tamano": int(f["size"]) if str(f.get("size") or "").isdigit() else None, "_mod": f.get("modifiedTime") or ""}
            if m.group(1) not in vistos or x["_mod"] > vistos[m.group(1)]["_mod"]:
                vistos[m.group(1)] = x
        token = datos.get("nextPageToken")
        if not token:
            break
    for x in vistos.values():
        x.pop("_mod", None)
    return list(vistos.values())


def _listar_publica(cid):
    """Sin clave: el listado público de la carpeta (la misma vista que se incrusta en una web)."""
    with _pedir(f"{base_web()}/embeddedfolderview?id={cid}", 20) as r:
        html = r.read(5_000_000).decode("utf-8", "replace")
    vistos = {}
    for bloque in re.split(r'(?=id="entry-)', html)[1:]:
        mid = re.match(r'id="entry-([A-Za-z0-9_\-]{10,120})"', bloque)
        mt = re.search(r'flip-entry-title"[^>]*>([^<]+)<', bloque)
        if not (mid and mt):
            continue
        nombre = (mt.group(1) or "").strip().replace("&amp;", "&")
        m = _NOMBRE.search(nombre)
        if m and m.group(1) not in vistos:
            vistos[m.group(1)] = {"id": mid.group(1), "archivo": nombre, "version": m.group(1), "fecha": "", "tamano": None}
    if not vistos and "entry-" not in html and ("accounts.google" in html or "ServiceLogin" in html):
        raise ErrorDrive("El servicio de actualizaciones no está disponible (la carpeta publicada no es accesible). Avise a su distribuidor.")
    return list(vistos.values())


def descargar(archivo_id, clave, maximo):
    if not _ID.match(archivo_id or ""):
        raise ErrorDrive("Paquete no válido")
    if (clave or "").strip():
        url = f"{base()}/drive/v3/files/{archivo_id}?" + urllib.parse.urlencode({"alt": "media", "supportsAllDrives": "true", "key": clave.strip()})
    else:
        url = f"{base_descarga()}/download?" + urllib.parse.urlencode({"id": archivo_id, "export": "download", "confirm": "t"})
    with _pedir(url, 180) as r:
        datos = r.read(maximo + 1)
    if datos[:2] != b"PK":   # un zip empieza por PK; si llega una página web, Drive pide confirmación o no es público
        raise ErrorDrive("El servicio de actualizaciones no entregó el paquete. Inténtelo más tarde o avise a su distribuidor.")
    if len(datos) > maximo:
        raise ErrorDrive("El paquete es demasiado grande")
    return datos
