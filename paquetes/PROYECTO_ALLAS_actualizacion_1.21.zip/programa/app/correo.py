"""Envío de emails por SMTP (biblioteca estándar). Requiere conexión a Internet en el
momento del envío; si no la hay, el llamador deja el email pendiente y se reintenta.

Los errores se traducen a mensajes comprensibles (con instrucciones para Gmail), y se
corrigen solas las combinaciones típicas mal configuradas (puerto 465 con STARTTLS, etc.).
"""
import smtplib
import socket
import ssl
from email.message import EmailMessage
from email.utils import formatdate, make_msgid
from . import errores


class ErrorCorreo(Exception):
    pass


def _es_gmail(servidor, usuario):
    return "gmail" in (servidor or "").lower() or "googlemail" in (servidor or "").lower() \
        or (usuario or "").lower().endswith(("@gmail.com", "@googlemail.com"))


def _traducir(e, servidor, puerto, gmail):
    texto = str(e)
    if isinstance(e, smtplib.SMTPAuthenticationError):
        if gmail:
            return ("Gmail ha rechazado el usuario o la contraseña. Gmail NO acepta la contraseña normal de la cuenta: "
                    "active la verificación en 2 pasos en su cuenta de Google y cree una «contraseña de aplicación» "
                    "(myaccount.google.com → Seguridad → Contraseñas de aplicación). Póngala en «Contraseña» y su "
                    "dirección de Gmail completa en «Usuario». O use el método «Gmail en el navegador», que no "
                    "necesita configuración.")
        return f"El servidor ha rechazado el usuario o la contraseña ({texto})."
    if isinstance(e, smtplib.SMTPNotSupportedError) or "AUTH extension not supported" in texto:
        return "El servidor no admite autenticación con esa seguridad. Pruebe STARTTLS con el puerto 587."
    if isinstance(e, smtplib.SMTPSenderRefused):
        return ("El servidor no deja enviar con ese remitente. En Gmail, el «Email del remitente» debe ser "
                "la misma dirección que el usuario.")
    if isinstance(e, smtplib.SMTPRecipientsRefused):
        return "El servidor ha rechazado la dirección del destinatario. Revise el email del cliente."
    if isinstance(e, socket.gaierror):
        return f"No se encuentra el servidor «{servidor}». ¿Hay conexión a Internet? ¿Está bien escrito?"
    if isinstance(e, (socket.timeout, TimeoutError)):
        return (f"El servidor {servidor}:{puerto} no responde. Compruebe la conexión a Internet y que el antivirus "
                "o el cortafuegos no bloquean Python.")
    if isinstance(e, ConnectionRefusedError):
        return f"El servidor {servidor} rechaza la conexión en el puerto {puerto}. Compruebe el puerto (587 o 465)."
    if isinstance(e, ssl.SSLError):
        return "Error de seguridad (SSL). Use STARTTLS con el puerto 587, o SSL/TLS con el 465."
    if isinstance(e, OSError):
        return f"Sin conexión con el servidor de correo ({texto}). ¿Hay Internet?"
    return texto


def enviar(cfg, destino, asunto, texto, adjuntos, timeout=20):
    servidor = (cfg.get("smtp_servidor") or "").strip()
    if not servidor:
        raise ErrorCorreo("Servidor de correo no configurado")
    puerto = int(cfg.get("smtp_puerto") or 587)
    seguridad = cfg.get("smtp_seguridad") or "starttls"
    # Correcciones automáticas de configuraciones habituales mal combinadas
    if puerto == 465:
        seguridad = "ssl"
    elif puerto == 587 and seguridad == "ssl":
        seguridad = "starttls"
    usuario = (cfg.get("smtp_usuario") or "").strip()
    clave = cfg.get("smtp_clave") or ""
    gmail = _es_gmail(servidor, usuario)
    if gmail:
        clave = clave.replace(" ", "")  # Google muestra la contraseña de aplicación en grupos de 4
        if not usuario:
            usuario = (cfg.get("smtp_remitente") or "").strip()
    remitente = (cfg.get("smtp_remitente") or usuario).strip()
    if not remitente:
        raise ErrorCorreo("Falta la dirección del remitente")
    if gmail and usuario and remitente.lower() != usuario.lower():
        remitente = usuario  # Gmail solo deja enviar como la propia cuenta

    msg = EmailMessage()
    nombre = cfg.get("nombre_parking") or ""
    msg["From"] = f"{nombre} <{remitente}>" if nombre else remitente
    msg["To"] = destino
    msg["Subject"] = asunto
    msg["Date"] = formatdate(localtime=True)
    msg["Message-ID"] = make_msgid(domain=remitente.split("@")[-1] if "@" in remitente else None)
    msg.set_content(texto)
    for nombre_archivo, datos, tipo in adjuntos:
        principal, sub = tipo.split("/")
        msg.add_attachment(datos, maintype=principal, subtype=sub, filename=nombre_archivo)

    conexion = None
    try:
        contexto = ssl.create_default_context()
        if seguridad == "ssl":
            conexion = smtplib.SMTP_SSL(servidor, puerto, timeout=timeout, context=contexto)
        else:
            conexion = smtplib.SMTP(servidor, puerto, timeout=timeout)
        conexion.ehlo()
        if seguridad == "starttls":
            conexion.starttls(context=contexto)
            conexion.ehlo()
        if usuario:
            conexion.login(usuario, clave)
        conexion.send_message(msg)
    except ErrorCorreo:
        raise
    except Exception as e:
        raise ErrorCorreo(_traducir(e, servidor, puerto, gmail)) from e
    finally:
        if conexion is not None:
            try:
                conexion.quit()
            except Exception as e_:
                errores.fallo("correo.enviar", e_)
