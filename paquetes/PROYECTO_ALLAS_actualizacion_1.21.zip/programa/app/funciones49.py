"""PROYECTO ALLAS 4.9 · plantillas de tickets y facturas hechas con el Editor de plantillas (archivos JSON).

Sin plantilla cargada, el programa imprime con su diseño de serie (nada cambia). Con una plantilla cargada
(Ajustes → Documentos), ese documento se dibuja con ella: los bloques los pone el editor y los datos
(matrícula, total, líneas…) los pone el programa. Ver docs/PLANTILLAS.md.
"""
import json

from . import plantillas


def _sv():
    from . import servicios
    return servicios


def _txt(v):
    return "" if v is None else str(v)


class Funciones49:
    # ============================================================== almacén
    @staticmethod
    def _clave_plantilla(tipo):
        if tipo not in plantillas.TIPOS:
            raise _sv().ErrorNegocio("Tipo de plantilla desconocido", 404)
        return "plantilla_" + tipo

    def plantilla(self, tipo):
        """Plantilla cargada para ese documento (ya validada) o None si se usa el diseño de serie."""
        try:
            texto = self.cfg("plantilla_" + tipo)
            return plantillas.validar(texto) if texto else None
        except (plantillas.ErrorPlantilla, TypeError):
            return None   # una plantilla dañada nunca debe impedir imprimir

    def plantillas_estado(self):
        r = {}
        for t, nombre in plantillas.TIPOS.items():
            p = self.plantilla(t)
            r[t] = {"nombre_tipo": nombre, "activa": bool(p), "nombre": p["nombre"] if p else None}
        return r

    def plantilla_json(self, tipo):
        """La plantilla cargada o, si no hay, la de serie (para abrirla en el editor)."""
        self._clave_plantilla(tipo)
        return self.plantilla(tipo) or plantillas.fabrica(tipo)

    def guardar_plantilla(self, actor_id, contenido):
        sv = _sv()
        try:
            p = plantillas.validar(contenido)
        except plantillas.ErrorPlantilla as e:
            raise sv.ErrorNegocio(f"Plantilla no válida: {e}")
        faltan = plantillas.campos_usados(p)
        with self.db.transaccion() as c:
            c.execute("INSERT OR REPLACE INTO config(clave, valor) VALUES(?, ?)",
                      ("plantilla_" + p["tipo"], json.dumps(p, ensure_ascii=False)))
            self.auditar(c, actor_id, "plantilla_cargar", f"{p['tipo']}: {p['nombre']}")
        return {"tipo": p["tipo"], "nombre": p["nombre"], "campos_desconocidos": faltan}

    def quitar_plantilla(self, actor_id, tipo):
        self._clave_plantilla(tipo)
        with self.db.transaccion() as c:
            c.execute("DELETE FROM config WHERE clave=?", ("plantilla_" + tipo,))
            self.auditar(c, actor_id, "plantilla_quitar", tipo)
        return {"tipo": tipo, "activa": False}

    # ============================================================== dibujo
    def _doc_plantilla(self, plt, datos, cfg):
        sv = _sv()
        doc = sv.impresion.Ticket(int(cfg.get("impresora_ancho") or 42))
        datos["_cfg"] = self._cfg_plantilla(cfg)

        def logo():
            return sv.logos.raster(self.carpeta_logo)
        return plantillas.dibujar_ticket(doc, plt, datos, logo)

    @staticmethod
    def _cfg_plantilla(cfg):
        return {"nombre_tam": cfg.get("ticket_nombre_tam") or "grande", "cabecera_invertida": cfg.get("ticket_cabecera_invertida", "1"),
                "mostrar_razon": cfg.get("ticket_mostrar_razon", "1"), "mostrar_nif": cfg.get("ticket_mostrar_nif", "1"),
                "mostrar_direccion": cfg.get("ticket_mostrar_direccion", "1"), "mostrar_telefono": cfg.get("ticket_mostrar_telefono", "1"),
                "mostrar_web": cfg.get("ticket_mostrar_web", "0"), "cabecera_extra": cfg.get("ticket_cabecera_extra") or "",
                "logo_ticket": cfg.get("logo_ticket") or "0", "codigo": cfg.get("ticket_codigo", "ambos"),
                "qr_tam": cfg.get("ticket_qr_tam") or "6", "separador": (cfg.get("ticket_separador") or "-")[:1] or "-",
                "lineas_corte": cfg.get("ticket_lineas_corte") or "4"}

    def _datos_empresa(self, cfg):
        return {"nombre_parking": cfg.get("nombre_parking", ""), "razon_social": cfg.get("razon_social", ""), "nif": cfg.get("nif", ""),
                "direccion": cfg.get("direccion", ""), "telefono": cfg.get("telefono", ""),
                "web": cfg.get("empresa_web", ""), "email": cfg.get("empresa_email", ""), "demo": "1" if self.demo else ""}

    # ============================================================== datos de cada documento
    def _datos_entrada(self, tk, duplicado, cfg):
        sv = _sv()
        d = self._datos_empresa(cfg)
        ent = sv.parse(tk["entrada"])
        t = self.tarifa(tk["tarifa_id"])
        d.update(titulo=cfg.get("ticket_entrada_titulo") or "TICKET DE ENTRADA", hora=ent.strftime("%H:%M"), fecha_larga=sv.fecha_larga(ent),
                 ajuste_hora=f"(hora ajustada en caja: {tk['ajuste_min']:+d} min)" if tk.get("ajuste_min") and not tk.get("matricula") else "",
                 entrada_completa=ent.strftime("%d/%m/%Y %H:%M") if tk.get("matricula") else "",
                 ajuste_linea=f"(hora ajustada en caja: {tk['ajuste_min']:+d} min)" if tk.get("ajuste_min") and tk.get("matricula") else "",
                 duplicado="1" if duplicado else "", manual="1" if tk.get("manual") else "", matricula=tk.get("matricula") or "",
                 matricula_grande="1" if cfg.get("ticket_matricula_grande") == "1" else "", tarifa=t["nombre"],
                 codigo=tk["codigo"], llaves=self._texto_llaves(cfg) if tk.get("llaves") else "", pie=cfg.get("ticket_entrada_pie", ""), reserva_desde="", reserva_hasta="", reserva_ref="", tarifa_despues="")
        if tk.get("reserva_hasta"):
            d["reserva_hasta"] = sv.parse(tk["reserva_hasta"]).strftime("%d/%m/%Y %H:%M")
            if tk.get("reserva_desde"):
                d["reserva_desde"] = sv.parse(tk["reserva_desde"]).strftime("%d/%m/%Y %H:%M")
            d["reserva_ref"] = tk.get("reserva_ref") or ""
            texto_res = t.get("texto_ticket")
            t = self.tarifa(tk.get("reserva_tarifa_id") or self._tarifa_tras_reserva(t))
            t = {**t, "texto_ticket": texto_res or t.get("texto_ticket")}
            d["tarifa_despues"] = t["nombre"]
        precios = []
        if cfg.get("ticket_mostrar_precio", "0") == "1":
            precios = [{"etiqueta": e, "valor": v} for e, v in self._precios_entrada(t)]
        d["precios"] = precios
        d["url_tarifas"] = self._url_tarifas(cfg)
        d["texto_tarifa"] = t.get("texto_ticket") or ""
        d["cajero"] = tk.get("usuario_entrada_nombre") or "" if cfg.get("ticket_mostrar_cajero") == "1" else ""
        d["qr_pago"] = ""
        if cfg.get("ticket_qr_pago", "1") == "1" and tk.get("codigo") and self.pago_movil_activo():
            d["qr_pago"] = self.url_pago_ticket(tk["codigo"])
        return d

    def _datos_pago(self, pago, cfg, total=None):
        """Lo común de las facturas en ticket: título, número, cliente, IVA, total y forma de pago."""
        sv = _sv()
        dest = pago.get("destinatario")
        f = sv.parse(pago["fecha"])
        d = self._datos_empresa(cfg)
        d.update(titulo=(cfg.get("factura_titulo_completa") or "FACTURA") if dest else (cfg.get("recibo_titulo") or "FACTURA SIMPLIFICADA"),
                 numero=f"{pago['serie']}-{pago['numero']:06d}", fecha_hora=f.strftime("%d/%m/%Y %H:%M"),
                 copia="1" if pago.get("copia") else "", sustituye="", pie=cfg.get("recibo_pie", ""),
                 cliente_nombre=(dest or {}).get("nombre") or "", cliente_nif=(dest or {}).get("nif") or "",
                 cliente_direccion=(dest or {}).get("direccion") or "", cliente_observaciones=(dest or {}).get("observaciones") or "")
        if pago.get("sustituye"):
            o = pago["sustituye"]
            d["sustituye"] = f"Sustituye a la {o['serie']}-{o['numero']:06d} del {sv.parse(o['fecha']).strftime('%d/%m/%Y')}"
        total = pago["importe_cent"] if total is None else total
        desglose = pago.get("desglose_iva") or sv.desglose_iva([(total, float(cfg.get("iva_pct") or 21))])
        if len(desglose) == 1:
            x = desglose[0]
            lista = [{"izq": f"Base {sv.eur(x['base'])}", "der": f"IVA {x['pct']:g}% {sv.eur(x['cuota'])}"}]
        else:
            lista = [{"izq": f"Base {x['pct']:g}%  {sv.eur(x['base'])}", "der": f"IVA {sv.eur(x['cuota'])}"} for x in desglose]
        d["desglose"] = lista
        d["total"] = sv.eur(total)
        d["forma_pago"] = sv.texto_metodo(pago["metodo"])
        d["referencia"] = pago.get("referencia") or ""
        mostrar = pago["metodo"] == "efectivo" and cfg.get("recibo_mostrar_cambio", "1") == "1" and pago.get("entregado_cent") is not None
        d["entregado"] = sv.eur(pago["entregado_cent"]) if mostrar else ""
        d["cambio"] = sv.eur(pago["cambio_cent"]) if mostrar else ""
        d["cajero"] = pago.get("usuario_nombre") or "" if cfg.get("ticket_mostrar_cajero") == "1" else ""
        q = self._qr_verifactu(pago["id"]) if pago.get("id") else None
        d["qr_verifactu"] = q["url"] if q else ""
        return d

    def _lineas_pago(self, pago, ancho):
        sv = _sv()
        r = []
        for e in pago.get("lineas_extra") or []:
            desc = "\n".join("   " + l for l in sv._partir_txt(e["descripcion"], ancho - 3)) if e.get("descripcion") else ""
            r.append({"nombre": (f"{e['cantidad']} x " if e["cantidad"] > 1 else "") + e["nombre"],
                      "importe": sv.eur(e["precio_cent"] * e["cantidad"]),
                      "precio_unidad": f"   ({sv.eur(e['precio_cent'])} / ud.)" if e["cantidad"] > 1 else "", "descripcion": desc,
                      "incluye": f"   (incluye {sv.texto_duracion(e['minutos_incluidos'] * e['cantidad'])} de parking)"
                      if e.get("minutos_incluidos") else ""})
        return r

    def _datos_recibo(self, tk, pago, limite, cfg, venta=False):
        sv = _sv()
        d = self._datos_pago(pago, cfg)
        ancho = int(cfg.get("impresora_ancho") or 42)
        d["lineas"] = self._lineas_pago(pago, ancho)
        d.update(matricula="", ticket="", manual="", entrada="", salida="", pagado_hasta="", pago_fecha="", tiempo="", incluido_servicios="",
                 estacionamiento="", recargo="", descuento_nombre="", descuento="", aviso_salida="")
        total = pago["importe_cent"]
        extras = pago.get("extras_cent") or 0
        descuento = pago.get("descuento_cent") or 0
        if descuento:
            d["descuento_nombre"] = f"Descuento {pago.get('descuento_nombre') or ''}".strip()
            d["descuento"] = "-" + sv.eur(descuento)
        if venta:
            return d
        estancia = total - extras - pago["recargo_cent"] + descuento
        d.update(matricula=tk.get("matricula") or "", ticket=tk["codigo"], manual="1" if tk.get("manual") else "",
                 entrada=sv.parse(tk["entrada"]).strftime("%d/%m/%Y %H:%M"),
                 salida=sv.parse(tk["salida"]).strftime("%d/%m/%Y %H:%M") if tk.get("salida") and tk.get("estado") == "salido" else "",
                 pagado_hasta=sv.parse(pago["salida_prevista"]).strftime("%d/%m/%Y %H:%M") if pago.get("salida_prevista") else "",
                 pago_fecha=d["fecha_hora"], tiempo=sv.texto_duracion(pago["minutos"]),
                 incluido_servicios="-" + sv.texto_duracion(pago["minutos_incluidos"]) if pago.get("minutos_incluidos") else "",
                 estacionamiento=sv.eur(estancia) if (estancia or not extras) else "",
                 recargo=sv.eur(pago["recargo_cent"]) if pago["recargo_cent"] else "")
        if limite:
            lim = sv.parse(limite)
            hora_txt = lim.strftime("%H:%M") if lim.date() == self.ahora().date() else lim.strftime("%H:%M del %d/%m/%Y")
            d["aviso_salida"] = (cfg.get("recibo_salida_texto") or "").replace("{hora}", hora_txt)
        return d

    def _datos_bono(self, cli, bono, pago, cfg):
        sv = _sv()
        d = self._datos_pago(pago, cfg)
        d.update(abonado_nombre=cli["nombre"], abonado_nif=cli.get("nif") or "", plan=bono["plan_nombre"],
                 numero_bono=self.numero_bono(bono["numero"]) if bono.get("numero") else "",
                 periodo=f"Del {sv.fecha_es(bono['desde'])} al {sv.fecha_es(bono['hasta'])}", importe_bono=sv.eur(pago["importe_cent"]),
                 bono_total="", bono_pagado="", bono_pendiente="", valido_hasta=sv.fecha_es(bono["hasta"]))
        d["vehiculos"] = [{"texto": sv.desc_vehiculo(v)} for v in (cli.get("vehiculos") or [{"matricula": m} for m in cli.get("matriculas", [])])]
        parcial = self._parcial_bono(bono, pago)
        if parcial:
            d.update(bono_total=sv.eur(parcial["total_cent"]), bono_pagado=sv.eur(parcial["pagado_cent"]),
                     bono_pendiente=sv.eur(parcial["pendiente_cent"]))
        return d

    def _datos_tarjeta(self, cli, cfg):
        sv = _sv()
        d = self._datos_empresa(cfg)
        b = cli.get("bono") or {}
        vigente = bool(b.get("hasta") and b.get("estado") in ("vigente", "caduca", "futuro"))
        d.update(titulo=cfg.get("tarjeta_titulo") or "TARJETA DE ABONADO", nombre=cli["nombre"], codigo=cli["codigo"],
                 pie=cfg.get("tarjeta_pie", ""), plan=(b.get("plan") or "") if vigente else "",
                 valido_hasta=sv.fecha_es(b["hasta"]) if vigente else "")
        d["vehiculos"] = [{"texto": sv.desc_vehiculo(v)} for v in (cli.get("vehiculos") or [{"matricula": m} for m in cli.get("matriculas", [])])]
        return d

    # ============================================================== factura A4
    def _aplicar_plantilla_a4(self, datos, plt):
        """Aplica la plantilla de factura A4 a los datos ya preparados (colores, títulos, secciones, columnas y textos)."""
        return plantillas.aplicar_factura(datos, plt, self.demo)
