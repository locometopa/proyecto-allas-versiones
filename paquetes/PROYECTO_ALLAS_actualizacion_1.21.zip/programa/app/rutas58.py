"""PROYECTO ALLAS 4.58 · facturas a proveedores y sello del garaje (se registran desde server.App._registrar)."""
import base64

from .servicios import ErrorNegocio


def registrar(app, r, p):
    from .server import Respuesta
    from . import logo as logos

    # ---------------------------------------------------------------- facturas a proveedores
    @r("GET", "/api/proveedores")
    def proveedores(req):
        return {"proveedores": p.proveedores(), "servicios": p.servicios_proveedor(), "catalogo": p.servicios_proveedor(),
                "serie": p.cfg("serie_proveedor") or "P"}

    @r("POST", "/api/proveedores/factura")
    def proveedor_factura(req):
        b = req.body
        try:
            lineas = [{"producto_id": int(x.get("producto_id")), "cantidad": int(x.get("cantidad") or 1)} for x in (b.get("lineas") or [])]
            cid = int(b.get("cliente_id"))
        except (TypeError, ValueError):
            raise ErrorNegocio("Elija el proveedor y el servicio")
        return p.facturar_proveedor(req.usuario, cid, lineas, "transferencia", None, b.get("referencia"), b.get("observaciones"))

    @r("POST", r"/api/proveedores/(\d+)/servicios")
    def proveedor_servicio_guardar(req, cid):
        b = req.body
        return {"servicios": p.guardar_servicio_proveedor(req.usuario["id"], int(cid), b.get("nombre"), b.get("precio_cent"), b.get("anterior_id"))}

    @r("DELETE", r"/api/proveedores/(\d+)/servicios/(\d+)")
    def proveedor_servicio_quitar(req, cid, pid):
        return {"servicios": p.quitar_servicio_proveedor(req.usuario["id"], int(cid), int(pid))}

    # ---------------------------------------------------------------- sello del garaje
    @r("GET", "/api/sello", rol=("admin",))
    def sello_info(req):
        return logos.info(p.carpeta_logo, "sello") or {}

    @r("POST", "/api/sello", rol=("admin",))
    def sello_subir(req):
        b = req.body
        try:
            jpeg = base64.b64decode(b.get("jpeg") or "")
            bits = base64.b64decode(b.get("bits") or "")
            info = logos.guardar(p.carpeta_logo, jpeg, b.get("ancho"), b.get("alto"), bits, base="sello")
        except (ValueError, TypeError) as e:
            raise ErrorNegocio(str(e) or "Imagen no válida")
        with p.db.transaccion() as c:
            p.auditar(c, req.usuario["id"], "sello_guardar", f"{info['ticket_ancho']}x{info['ticket_alto']}")
        return info

    @r("DELETE", "/api/sello", rol=("admin",))
    def sello_borrar(req):
        logos.borrar(p.carpeta_logo, "sello")
        with p.db.transaccion() as c:
            p.auditar(c, req.usuario["id"], "sello_borrar", "")
        return {"ok": True}

    @r("GET", r"/api/sello/(ticket\.png|sello\.jpg)", publica=True)
    def sello_archivo(req, nombre):
        import os
        ruta = os.path.join(p.carpeta_logo, "sello_ticket.png" if nombre == "ticket.png" else "sello.jpg")
        if not os.path.isfile(ruta):
            raise ErrorNegocio("No hay sello", 404)
        with open(ruta, "rb") as f:
            return Respuesta(f.read(), "image/png" if nombre == "ticket.png" else "image/jpeg")
