"""Licencias de PROYECTO ALLAS mediante serial firmado.

Un serial contiene: número de licencia, tipo, titular, fecha de caducidad (o ninguna), hasta qué
fecha incluye actualizaciones y, opcionalmente, el ID del equipo en el que se puede usar.
Va firmado con Ed25519: el programa solo tiene la clave pública, así que puede comprobar un
serial pero no fabricarlo. Los seriales se emiten con el Gestor de licencias (programa aparte).

Este archivo lo usan los dos programas (PROYECTO ALLAS y el Gestor de licencias).
"""
import base64
import functools
import hashlib
import os
import platform
import struct
import uuid
from datetime import date, timedelta

from . import ed25519

PREFIJO = "ALLAS"
VERSION_FORMATO = 1
EPOCA = date(2020, 1, 1)
DIAS_PRUEBA = 5
TIPOS = {0: "perpetua", 1: "suscripcion", 2: "prueba"}
NOMBRE_TIPO = {"perpetua": "Perpetua", "suscripcion": "Suscripción", "prueba": "Prueba ampliada"}
_CONTEXTO = b"PROYECTO-ALLAS-LICENCIA"

# ------------------------------------------------------------------ módulos y planes (3.0)
# La «Base» (entrada, salida, vehículos, caja, tarifas, facturas, informes, copias) va siempre.
# El orden de MODULOS fija el bit de cada uno en el serial: añadir siempre al final, nunca reordenar.
MODULOS = [
    {"id": "abonados", "nombre": "Abonados", "detalle": "Clientes con bonos mensuales, renovaciones, deudas y avisos por email"},
    {"id": "tienda", "nombre": "Tienda", "detalle": "Venta de productos y servicios sin ticket, con historial de ventas"},
    {"id": "pagos_online", "nombre": "Pagos online", "detalle": "Cobro de bonos con tarjeta por Internet (Stripe)", "requiere": ["abonados"]},
    {"id": "mensajeria", "nombre": "Mensajería", "detalle": "WhatsApp / SMS y comunicados a los abonados", "requiere": ["abonados"]},
    {"id": "madrid360", "nombre": "Madrid 360 y cámaras", "detalle": "Listado diario ZBE Distrito Centro y lectura de matrículas por cámara"},
    {"id": "verifactu", "nombre": "VERI*FACTU", "detalle": "Registros de facturación para la AEAT"},
    # 3.5 (los nuevos SIEMPRE al final: la posición fija el bit del serial)
    {"id": "movil", "nombre": "Caja móvil / tablet", "detalle": "Entradas y cobros desde un móvil o tablet de la red local (código QR)"},
    # 4.0: funciones que antes iban en la base pasan a módulos. «antes_base»: las licencias emitidas antes
    # de existir el módulo lo conservan (así nadie pierde lo que ya tenía).
    {"id": "descuentos", "nombre": "Descuentos y vales", "antes_base": True,
     "detalle": "Descuentos, vales imprimibles y validaciones de comercios"},
    {"id": "pantalla_cliente", "nombre": "Pantalla de cliente", "antes_base": True,
     "detalle": "Segundo monitor con publicidad y visor TPV de texto"},
    {"id": "multicaja", "nombre": "Varios cajeros", "antes_base": True,
     "detalle": "Varios turnos de caja abiertos a la vez, cada uno con su arqueo"},
    {"id": "tarifas_avanzadas", "nombre": "Tarifas por horario", "antes_base": True,
     "detalle": "Tarifas automáticas por franja horaria y día de la semana"},
    {"id": "facturacion", "nombre": "Devoluciones y rectificación", "antes_base": True,
     "detalle": "Devoluciones y rectificación de facturas (facturas rectificativas)"},
    {"id": "perifericos", "nombre": "Barrera y datáfono", "antes_base": True,
     "detalle": "Apertura de barrera por relé y datáfono integrado"},
    # 4.5: sin este módulo, la licencia es «solo abonados» (no se emiten tickets de rotación)
    {"id": "rotacion", "nombre": "Entradas y salidas por horas", "antes_base": True,
     "detalle": "Tickets de rotación, tarifas y cobro por tiempo (sin él, solo entran abonados)"},
    # 4.7: sin este módulo, la licencia es «Lite» (solo lo imprescindible para cobrar)
    {"id": "gestion", "nombre": "Gestión ampliada", "antes_base": True,
     "detalle": "Clientes y factura con datos, ticket manual, servicios, historial, reservas, lista negra, zonas, "
                "informes completos, aplicaciones externas, semáforo, importar y exportar"},
]
IDS_MODULOS = [m["id"] for m in MODULOS]
NOMBRE_MODULO = {m["id"]: m["nombre"] for m in MODULOS}
# 4.10: orden de menor a mayor (Lite · Básico · Abonados · Básico plus · Profesional · Completo) y un color por plan.
# Los identificadores («solo_abonados», «solo_rotacion») y los códigos del serial no cambian: solo el nombre que se ve.
PLANES = {
    # 4.7: lo mínimo para cobrar por horas (Entrada, Salida, vehículos dentro, caja, tarifas, ticket, resumen y copias)
    "lite": {"nombre": "Lite", "color": "#64748b", "modulos": ["rotacion"]},
    "basico": {"nombre": "Básico", "color": "#0369a1", "modulos": ["rotacion", "gestion"]},
    # 4.5: modo cerrado: solo abonados, sin tickets por horas
    "solo_abonados": {"nombre": "Abonados", "color": "#7c3aed",
                      "modulos": ["gestion", "abonados", "pagos_online", "mensajeria", "movil", "multicaja", "facturacion", "perifericos", "madrid360", "verifactu"]},
    # 4.5: modo cerrado: entradas y salidas por horas, sin abonados
    "solo_rotacion": {"nombre": "Básico plus", "color": "#0f766e", "modulos": [m for m in IDS_MODULOS if m not in ("abonados", "pagos_online", "mensajeria")]},
    "profesional": {"nombre": "Profesional", "color": "#c2410c",
                    "modulos": ["rotacion", "gestion", "abonados", "tienda", "descuentos", "pantalla_cliente", "tarifas_avanzadas", "facturacion"]},
    "completo": {"nombre": "Completo", "color": "#15803d", "modulos": list(IDS_MODULOS)},
}
# colores de lo que no es un plan (junto a la versión)
COLOR_TIPO = {"prueba": "#b45309", "demo": "#be123c", "personalizada": "#475569", "sin_licencia": "#b91c1c"}
for _p in PLANES.values():          # siempre en el orden de la máscara (igual que al leer un serial)
    _p["modulos"] = sorted(set(_p["modulos"]), key=IDS_MODULOS.index)
_COD_PLAN = {"personalizado": 0, "basico": 1, "profesional": 2, "completo": 3, "solo_rotacion": 4, "solo_abonados": 5, "lite": 6}
_PLAN_DE_COD = {v: k for k, v in _COD_PLAN.items()}
_MARCA_MODULOS = b"M"
_MARCA_CONOCIDOS = b"N"
_MARCA_COMPROBAR = b"C"   # 3.8: comprobar cada N días (uint16) + días de gracia (uint8) + fecha de emisión (uint16)
_MARCA_URL = b"U"         # 3.8: dirección del servidor de comprobación (1 byte de longitud + texto)
_MARCA_SUPERVISION = b"S"  # 4.4: huella de la contraseña de supervisión de esta licencia (4 bytes de sal + 12 de huella)
_CONTEXTO_COMPROBANTE = b"PROYECTO-ALLAS-COMPROBANTE"
PREFIJO_COMPROBANTE = "VAL"
ESTADOS_COMPROBANTE = {0: "activa", 1: "revocada"}
MODULOS_ANTES_35 = 6   # seriales sin la marca «N»: se emitieron cuando había 6 módulos


def normalizar_modulos(modulos):
    """Quita ids desconocidos, añade las dependencias y devuelve la lista en el orden oficial."""
    sel = set(m for m in (modulos or []) if m in IDS_MODULOS)
    for m in MODULOS:
        if m["id"] in sel:
            sel.update(m.get("requiere", []))
    return [i for i in IDS_MODULOS if i in sel]


def nombre_plan(plan, modulos):
    """'Profesional', 'Básico + Tienda', 'Completo − VERI*FACTU', 'Personalizado'…"""
    if plan not in PLANES:
        return "Personalizado"
    base = set(PLANES[plan]["modulos"])
    extra = [NOMBRE_MODULO[m] for m in modulos if m not in base]
    quita = [NOMBRE_MODULO[m] for m in IDS_MODULOS if m in base and m not in modulos]
    return PLANES[plan]["nombre"] + "".join(" + " + x for x in extra) + "".join(" − " + x for x in quita)


class ErrorLicencia(ValueError):
    pass


# ------------------------------------------------------------------ ID de equipo
def _datos_equipo():
    partes = []
    if os.name == "nt":
        try:
            import winreg
            k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0,
                               winreg.KEY_READ | getattr(winreg, "KEY_WOW64_64KEY", 0))
            partes.append(winreg.QueryValueEx(k, "MachineGuid")[0])
        except OSError:
            pass
    else:
        for ruta in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
            try:
                with open(ruta) as f:
                    partes.append(f.read().strip())
                    break
            except OSError:
                continue
    if not partes:  # último recurso: dirección MAC y nombre del sistema
        partes += [hex(uuid.getnode()), platform.node()]
    return "|".join(partes)


@functools.lru_cache(maxsize=1)
def id_equipo_bytes():
    return hashlib.sha256(("allas|" + _datos_equipo()).encode()).digest()[:8]


def formatear_equipo(b):
    h = b.hex().upper()
    return "-".join(h[i:i + 4] for i in range(0, 16, 4))


def leer_equipo(texto):
    """'A1B2-C3D4-...' -> 8 bytes (o None si está vacío)."""
    limpio = "".join(c for c in (texto or "").upper() if c in "0123456789ABCDEF")
    if not limpio:
        return None
    if len(limpio) != 16:
        raise ErrorLicencia("El ID de equipo debe tener 16 caracteres (4 grupos de 4)")
    return bytes.fromhex(limpio)


def id_equipo():
    return formatear_equipo(id_equipo_bytes())


# ------------------------------------------------------------------ fechas
def _a_dias(d):
    return 0 if d is None else (d - EPOCA).days


def _de_dias(n):
    return None if n == 0 else EPOCA + timedelta(days=n)


# ------------------------------------------------------------------ emitir (Gestor)
def emitir(clave_privada, numero, titular, tipo="perpetua", caduca=None, actualizaciones_hasta=None,
           equipo=None, puestos=1, plan=None, modulos=None, comprobar_dias=0, gracia_dias=7, url=None, emitida=None,
           supervision=None):
    """Crea un serial. 'clave_privada': 32 bytes. Fechas: date o None (= sin límite).
    plan/modulos (3.0): si se indican, el serial lleva los módulos activados. Sin ellos = todos.
    Los módulos van después del titular, así que los programas anteriores a la 3.0 los ignoran."""
    cod_tipo = {v: k for k, v in TIPOS.items()}.get(tipo)
    if cod_tipo is None:
        raise ErrorLicencia("Tipo de licencia no válido")
    nombre = (titular or "").strip().encode("utf-8")[:60]
    if not nombre:
        raise ErrorLicencia("Indique el titular de la licencia")
    datos = struct.pack(">BIBHH8sB", VERSION_FORMATO, int(numero), cod_tipo, _a_dias(caduca),
                        _a_dias(actualizaciones_hasta), equipo or b"\0" * 8, max(1, min(255, int(puestos))))
    datos += bytes([len(nombre)]) + nombre
    if plan is not None or modulos is not None:
        if plan is not None and plan not in _COD_PLAN:
            raise ErrorLicencia("Plan no válido")
        mods = normalizar_modulos(PLANES[plan]["modulos"] if modulos is None and plan in PLANES else modulos)
        mascara = sum(1 << IDS_MODULOS.index(m) for m in mods)
        datos += _MARCA_MODULOS + struct.pack(">BH", _COD_PLAN[plan or "personalizado"], mascara)
        # 3.5: cuántos módulos existían al emitirlo (así los que se añadan después pueden entrar en su plan)
        datos += _MARCA_CONOCIDOS + bytes([len(IDS_MODULOS)])
        # 3.8: comprobación periódica (online o con código) y servidor al que preguntar
        if comprobar_dias:
            if not 1 <= int(comprobar_dias) <= 3650 or not 0 <= int(gracia_dias) <= 255:
                raise ErrorLicencia("Días de comprobación (1-3650) o de gracia (0-255) no válidos")
            datos += _MARCA_COMPROBAR + struct.pack(">HBH", int(comprobar_dias), int(gracia_dias), _a_dias(emitida or date.today()))
            u = (url or "").strip().encode("utf-8")
            if u:
                if len(u) > 120:
                    raise ErrorLicencia("La dirección del servidor de comprobación es demasiado larga")
                datos += _MARCA_URL + bytes([len(u)]) + u
        # 4.4: contraseña del menú de supervisión propia de esta licencia (texto) o la huella ya calculada (16 bytes)
        if supervision:
            datos += _MARCA_SUPERVISION + (supervision if isinstance(supervision, bytes) else huella_supervision_serial(supervision))
    firma = ed25519.firmar(clave_privada, _CONTEXTO + datos)
    b32 = base64.b32encode(datos + firma).decode().rstrip("=")
    return PREFIJO + "-" + "-".join(b32[i:i + 5] for i in range(0, len(b32), 5))


# ------------------------------------------------------------------ leer (programa)
def leer(serial, clave_publica):
    """Comprueba la firma y devuelve los datos del serial. Lanza ErrorLicencia si no vale."""
    texto = "".join(c for c in (serial or "").upper() if c.isalnum())
    if texto.startswith(PREFIJO):
        texto = texto[len(PREFIJO):]
    if len(texto) < 100:
        raise ErrorLicencia("El serial está incompleto. Cópielo entero (incluidos todos los grupos).")
    try:
        crudo = base64.b32decode(texto + "=" * (-len(texto) % 8))
    except (ValueError, base64.binascii.Error):
        raise ErrorLicencia("El serial tiene caracteres no válidos")
    datos, firma = crudo[:-64], crudo[-64:]
    if len(datos) < 20 or not ed25519.verificar(clave_publica, _CONTEXTO + datos, firma):
        raise ErrorLicencia("El serial no es válido (revise que esté copiado sin errores)")
    ver, numero, cod_tipo, cad, act, equipo, puestos = struct.unpack(">BIBHH8sB", datos[:19])
    if ver != VERSION_FORMATO:
        raise ErrorLicencia("Serial de una versión del programa no compatible")
    n = datos[19]
    plan, modulos, resto = "completo", list(IDS_MODULOS), datos[20 + n:]
    extra = {}
    if len(resto) >= 4 and resto[:1] == _MARCA_MODULOS:   # seriales 3.0 con módulos
        cod_plan, mascara = struct.unpack(">BH", resto[1:4])
        plan = _PLAN_DE_COD.get(cod_plan, "personalizado")
        modulos = [m for i, m in enumerate(IDS_MODULOS) if mascara & (1 << i)]
        conocidos = resto[5] if len(resto) >= 6 and resto[4:5] == _MARCA_CONOCIDOS else MODULOS_ANTES_35
        extra = _leer_extras(resto[6:] if resto[4:5] == _MARCA_CONOCIDOS else b"")
        # módulos nuevos (posteriores al serial): activos si su plan los incluye o si antes eran de la base
        antes_base = {m["id"] for m in MODULOS if m.get("antes_base")}
        nuevos = [m for i, m in enumerate(IDS_MODULOS) if i >= conocidos and
                  ((plan in PLANES and m in PLANES[plan]["modulos"]) or m in antes_base)]
        modulos = [m for m in IDS_MODULOS if m in modulos or m in nuevos]
    return {"numero": numero, "tipo": TIPOS.get(cod_tipo, "perpetua"), "caduca": _de_dias(cad),
            "actualizaciones_hasta": _de_dias(act), "equipo": None if equipo == b"\0" * 8 else equipo,
            "puestos": puestos, "titular": datos[20:20 + n].decode("utf-8", "replace"),
            "plan": plan, "modulos": modulos, "con_modulos": resto[:1] == _MARCA_MODULOS,
            "comprobar_dias": extra.get("comprobar_dias", 0), "gracia_dias": extra.get("gracia_dias", 0),
            "url": extra.get("url"), "emitida": extra.get("emitida"), "supervision": extra.get("supervision")}


def _leer_extras(b):
    """Marcas opcionales tras el bloque de módulos (los programas anteriores no las leen)."""
    r, i = {}, 0
    while i < len(b):
        marca = b[i:i + 1]
        if marca == _MARCA_COMPROBAR and i + 6 <= len(b):
            r["comprobar_dias"], r["gracia_dias"], em = struct.unpack(">HBH", b[i + 1:i + 6])
            r["emitida"] = _de_dias(em)
            i += 6
        elif marca == _MARCA_URL and i + 2 <= len(b):
            n = b[i + 1]
            r["url"] = b[i + 2:i + 2 + n].decode("utf-8", "replace")
            i += 2 + n
        elif marca == _MARCA_SUPERVISION and i + 17 <= len(b):
            r["supervision"] = b[i + 1:i + 17]
            i += 17
        else:
            break
    return r


# ------------------------------------------------------------------ comprobantes (3.8)
# Respuesta firmada del Gestor que dice «la licencia nº X estaba activa (o revocada) el día D en el equipo E».
# El equipo no viaja en el texto (va implícito: el del PC que lo usa), así el código es más corto
# y no sirve en otro ordenador.
def emitir_comprobante(clave_privada, numero, equipo, fecha, estado_lic="activa"):
    cod = {v: k for k, v in ESTADOS_COMPROBANTE.items()}[estado_lic]
    datos = struct.pack(">BIHB", 1, int(numero), _a_dias(fecha), cod)
    firma = ed25519.firmar(clave_privada, _CONTEXTO_COMPROBANTE + datos + equipo)
    b32 = base64.b32encode(datos + firma).decode().rstrip("=")
    return PREFIJO_COMPROBANTE + "-" + "-".join(b32[i:i + 5] for i in range(0, len(b32), 5))


def leer_comprobante(texto, clave_publica, equipo=None):
    """-> {numero, fecha, estado}. Lanza ErrorLicencia si no es válido para este equipo."""
    equipo = equipo or id_equipo_bytes()
    t = "".join(c for c in (texto or "").upper() if c.isalnum())
    if t.startswith(PREFIJO_COMPROBANTE):
        t = t[len(PREFIJO_COMPROBANTE):]
    try:
        crudo = base64.b32decode(t + "=" * (-len(t) % 8))
    except (ValueError, base64.binascii.Error):
        raise ErrorLicencia("El código de validación tiene caracteres no válidos")
    if len(crudo) != 8 + 64:
        raise ErrorLicencia("El código de validación está incompleto. Cópielo entero.")
    datos, firma = crudo[:8], crudo[8:]
    if not ed25519.verificar(clave_publica, _CONTEXTO_COMPROBANTE + datos + equipo, firma):
        raise ErrorLicencia("El código de validación no es válido para este equipo (revise que esté completo "
                            "y que sea para el ID de equipo que aparece aquí)")
    ver, numero, dias, cod = struct.unpack(">BIHB", datos)
    return {"numero": numero, "fecha": _de_dias(dias), "estado": ESTADOS_COMPROBANTE.get(cod, "revocada")}


def estado(serial, clave_publica, fecha_instalacion, hoy, fecha_version=None, equipo_local=None, comprobante=None):
    """Situación de la licencia en la fecha 'hoy'. 'puede_operar' = se pueden registrar entradas.
    comprobante (3.8): el último comprobante guardado; sin él, los plazos cuentan desde la emisión del serial."""
    equipo_local = equipo_local or id_equipo_bytes()
    # Prueba, sin licencia o serial ilegible: todos los módulos (así no se ocultan datos del cliente)
    base = {"id_equipo": formatear_equipo(equipo_local), "serial": None, "plan": "completo",
            "plan_nombre": "Todos los módulos", "modulos": list(IDS_MODULOS)}
    if not serial:
        try:
            inst = date.fromisoformat((fecha_instalacion or hoy.isoformat())[:10])
        except ValueError:
            inst = hoy
        quedan = DIAS_PRUEBA - max(0, (hoy - inst).days)
        if quedan > 0:
            return {**base, "estado": "prueba", "puede_operar": True, "dias_restantes": quedan,
                    "mensaje": f"Versión de prueba: quedan {quedan} día{'s' if quedan != 1 else ''}."}
        return {**base, "estado": "prueba_caducada", "puede_operar": False, "dias_restantes": 0,
                "mensaje": "El periodo de prueba ha terminado. Active una licencia para seguir registrando entradas."}
    try:
        lic = leer(serial, clave_publica)
    except ErrorLicencia as e:
        return {**base, "estado": "invalida", "puede_operar": False, "mensaje": str(e)}
    info = {**base, "serial": serial, "numero": lic["numero"], "titular": lic["titular"], "tipo": lic["tipo"],
            "tipo_nombre": NOMBRE_TIPO.get(lic["tipo"], lic["tipo"]),
            "caduca": lic["caduca"].isoformat() if lic["caduca"] else None,
            "actualizaciones_hasta": lic["actualizaciones_hasta"].isoformat() if lic["actualizaciones_hasta"] else None,
            "equipo_licencia": formatear_equipo(lic["equipo"]) if lic["equipo"] else None, "puestos": lic["puestos"],
            "plan": lic["plan"], "modulos": lic["modulos"],
            "plan_nombre": nombre_plan(lic["plan"], lic["modulos"]) if lic["con_modulos"] else "Todos los módulos"}
    if lic["equipo"] and lic["equipo"] != equipo_local:
        return {**info, "estado": "otro_equipo", "puede_operar": False,
                "mensaje": f"Esta licencia es para otro equipo ({formatear_equipo(lic['equipo'])}). "
                           f"El ID de este equipo es {formatear_equipo(equipo_local)}."}
    if lic["caduca"] and hoy > lic["caduca"]:
        return {**info, "estado": "caducada", "puede_operar": False,
                "mensaje": f"La licencia caducó el {lic['caduca'].strftime('%d/%m/%Y')}. Renuévela para seguir registrando entradas."}
    if fecha_version and lic["actualizaciones_hasta"] and fecha_version > lic["actualizaciones_hasta"]:
        return {**info, "estado": "version_no_cubierta", "puede_operar": False,
                "mensaje": f"Esta versión del programa es posterior al {lic['actualizaciones_hasta'].strftime('%d/%m/%Y')}, "
                           "fecha hasta la que su licencia incluye actualizaciones. Vuelva a la versión anterior o renueve."}
    dias = (lic["caduca"] - hoy).days if lic["caduca"] else None
    msg = f"Licencia nº {lic['numero']} a nombre de {lic['titular']}"
    if dias is not None:
        msg += f" · caduca el {lic['caduca'].strftime('%d/%m/%Y')} (quedan {dias} días)"
    res = {**info, "estado": "activa", "puede_operar": True, "dias_restantes": dias, "mensaje": msg}
    if lic.get("comprobar_dias"):
        res = _con_comprobacion(res, lic, clave_publica, equipo_local, hoy, comprobante)
    return res


def _con_comprobacion(res, lic, clave_publica, equipo_local, hoy, comprobante):
    cada, gracia = lic["comprobar_dias"], lic["gracia_dias"]
    comp = None
    if comprobante:
        try:
            comp = leer_comprobante(comprobante, clave_publica, equipo_local)
            if comp["numero"] != lic["numero"] or comp["fecha"] > hoy + timedelta(days=1):
                comp = None
        except ErrorLicencia:
            comp = None
    desde = lic.get("emitida") or hoy   # fecha firmada en el serial: borrar datos no reinicia el plazo
    ultima = comp["fecha"] if comp else None
    base = max(ultima, desde) if ultima else desde
    proxima, limite = base + timedelta(days=cada), base + timedelta(days=cada + gracia)
    info = {"cada": cada, "gracia": gracia, "ultima": ultima and ultima.isoformat(), "proxima": proxima.isoformat(),
            "limite": limite.isoformat(), "url": lic.get("url"), "pendiente": hoy > proxima}
    res["comprobacion"] = info
    if comp and comp["estado"] == "revocada":
        return {**res, "estado": "revocada", "puede_operar": False, "dias_restantes": 0,
                "mensaje": f"La licencia nº {lic['numero']} ha sido anulada por el distribuidor. Póngase en contacto con él."}
    if hoy > limite:
        return {**res, "estado": "sin_comprobar", "puede_operar": False, "dias_restantes": 0,
                "mensaje": f"No se ha podido comprobar la licencia desde el {base.strftime('%d/%m/%Y')}. Conecte el PC a Internet "
                           "y pulse «Comprobar ahora», o pida a su distribuidor un código de validación (Ajustes → Licencia)."}
    if hoy > proxima:
        quedan = (limite - hoy).days
        res["mensaje"] = (f"Comprobación de la licencia pendiente: conecte el PC a Internet o introduzca un código de validación. "
                          f"Si no, dejará de registrar entradas en {quedan} día{'s' if quedan != 1 else ''} ({limite.strftime('%d/%m/%Y')}).")
        res["dias_restantes"] = quedan if res["dias_restantes"] is None else min(quedan, res["dias_restantes"])
        res["estado_comprobacion"] = "pendiente"
    return res


# ------------------------------------------------------------------ datos del fabricante (4.1)
# Copyright, derechos, logo y contacto del creador del software. Los escribe el Gestor de licencias y van
# firmados con la clave privada: el programa solo muestra los que vienen del fabricante.
_CONTEXTO_FABRICANTE = b"PROYECTO-ALLAS-FABRICANTE"
CAMPOS_FABRICANTE = ("nombre", "copyright", "derechos", "web", "email", "telefono", "direccion", "nif", "texto", "logo", "fecha",
                     "supervision")
MAX_LOGO_FABRICANTE = 400_000   # caracteres del data:URL


def _limpiar_fabricante(datos):
    d = {}
    for k in CAMPOS_FABRICANTE:
        v = datos.get(k)
        if v is None:
            continue
        v = str(v).strip()
        if k == "logo":
            if v and (not v.startswith(("data:image/png;base64,", "data:image/jpeg;base64,", "data:image/svg+xml;base64,",
                                        "data:image/webp;base64,")) or len(v) > MAX_LOGO_FABRICANTE):
                raise ErrorLicencia("El logo debe ser una imagen PNG, JPG, SVG o WEBP de menos de 300 KB")
        elif k == "web":
            if v and not v.lower().startswith(("http://", "https://")):
                v = "https://" + v
            v = v[:200]
        elif k == "texto":
            v = v[:1500]
        elif k == "supervision":   # 4.4: huella de la contraseña maestra (nunca la contraseña)
            if v and not _FORMATO_HUELLA(v):
                raise ErrorLicencia("Huella de la contraseña de supervisión no válida")
        else:
            v = v[:200]
        if v:
            d[k] = v
    return d


def firmar_fabricante(clave_privada, datos):
    """→ texto JSON {"datos": {...}, "firma": "hex"} para guardar como app/fabricante.json."""
    import json
    d = _limpiar_fabricante(datos)
    cuerpo = json.dumps(d, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    firma = ed25519.firmar(clave_privada, _CONTEXTO_FABRICANTE + cuerpo.encode("utf-8"))
    return json.dumps({"formato": "proyecto-allas/fabricante", "datos": d, "firma": firma.hex()}, ensure_ascii=False, indent=1)


def leer_fabricante(texto, clave_publica):
    """Comprueba la firma y devuelve los datos. Lanza ErrorLicencia si no vienen del fabricante."""
    import json
    try:
        j = json.loads(texto if isinstance(texto, str) else texto.decode("utf-8"))
        d, firma = j["datos"], bytes.fromhex(j["firma"])
    except (ValueError, KeyError, TypeError, AttributeError):
        raise ErrorLicencia("El archivo de datos del fabricante no es válido")
    cuerpo = json.dumps(d, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    if not isinstance(d, dict) or not ed25519.verificar(clave_publica, _CONTEXTO_FABRICANTE + cuerpo.encode("utf-8"), firma):
        raise ErrorLicencia("Los datos del fabricante no están firmados por su distribuidor")
    return _limpiar_fabricante(d)


# ------------------------------------------------------------------ 4.4 · contraseña de supervisión
# El menú «Supervisión» del programa solo lo abre el fabricante/instalador. Su contraseña no se guarda nunca:
# - maestra: huella PBKDF2 dentro de los datos del fabricante (firmados), vale para todas las licencias;
# - por licencia: huella corta dentro del serial (firmado), solo para ese cliente.
ITER_SUPERVISION = 200_000
ITER_SUPERVISION_SERIAL = 120_000


def _FORMATO_HUELLA(v):
    partes = v.split("$")
    return (len(partes) == 4 and partes[0] == "pbkdf2_sha256" and partes[1].isdigit() and 10_000 <= int(partes[1]) <= 2_000_000
            and len(partes[2]) == 32 and len(partes[3]) == 64 and all(c in "0123456789abcdef" for c in partes[2] + partes[3]))


def huella_supervision(clave, sal=None, iteraciones=ITER_SUPERVISION):
    """→ 'pbkdf2_sha256$iteraciones$sal$huella' (para la contraseña maestra)."""
    if len(clave or "") < 8:
        raise ErrorLicencia("La contraseña de supervisión debe tener al menos 8 caracteres")
    sal = sal or os.urandom(16)
    h = hashlib.pbkdf2_hmac("sha256", clave.encode("utf-8"), sal, iteraciones)
    return f"pbkdf2_sha256${iteraciones}${sal.hex()}${h.hex()}"


def huella_supervision_serial(clave, sal=None):
    """16 bytes (4 de sal + 12 de huella) que van dentro del serial."""
    if len(clave or "") < 8:
        raise ErrorLicencia("La contraseña de supervisión debe tener al menos 8 caracteres")
    sal = sal or os.urandom(4)
    return sal + hashlib.pbkdf2_hmac("sha256", clave.encode("utf-8"), b"ALLAS-SUP" + sal, ITER_SUPERVISION_SERIAL, dklen=12)


def comprobar_supervision(clave, huella):
    """huella: texto (maestra) o 16 bytes (serial). Comparación en tiempo constante."""
    import hmac
    if not clave or not huella:
        return False
    if isinstance(huella, (bytes, bytearray)):
        if len(huella) != 16:
            return False
        return hmac.compare_digest(huella_supervision_serial(clave, bytes(huella[:4])) if len(clave) >= 8 else b"", bytes(huella))
    if not _FORMATO_HUELLA(huella):
        return False
    _, it, sal, h = huella.split("$")
    calc = hashlib.pbkdf2_hmac("sha256", clave.encode("utf-8"), bytes.fromhex(sal), int(it))
    return hmac.compare_digest(calc.hex(), h)
