"""PROYECTO ALLAS 4.9 · plantillas de tickets y facturas (formato abierto).

Una plantilla es un archivo JSON (ver docs/PLANTILLAS.md) que dice QUÉ bloques lleva un ticket y en qué orden,
con textos que pueden incluir campos entre llaves ({matricula}, {total}…). Este módulo no depende del resto del
programa (solo de impresion.Ticket para dibujar), así que lo usan tanto PROYECTO ALLAS como el Editor de plantillas
y cualquier otro programa que quiera leerlas.

Tipos:  entrada · recibo · bono · tarjeta   (ticket térmico, bloques)
        factura                             (PDF A4: estilo, textos y secciones)
"""
import copy
import json
import re

FORMATO = "allas-plantilla"
VERSION = 1
TIPOS = {"entrada": "Ticket de entrada", "recibo": "Factura / recibo (ticket)", "bono": "Recibo de bono",
         "tarjeta": "Tarjeta de abonado", "factura": "Factura A4 (PDF)"}
TIPOS_TICKET = ("entrada", "recibo", "bono", "tarjeta")

MAX_BLOQUES = 150
MAX_TEXTO = 400
MAX_BYTES = 200_000

# ---------------------------------------------------------------- campos disponibles por tipo
# (campo, descripción, ejemplo)
_EMPRESA = [("nombre_parking", "Nombre del parking", "PARKING DEMO CENTRO"), ("razon_social", "Razón social", "Demo Parking S.L."),
            ("nif", "NIF de la empresa", "B12345674"), ("direccion", "Dirección", "C/ Mayor 1, 28013 Madrid"),
            ("telefono", "Teléfono", "912 345 678"), ("web", "Web", "www.demoparking.es"), ("email", "Email", "info@demoparking.es")]
_PAGO = [("total", "Importe total", "19,41 €"), ("forma_pago", "Forma de pago", "Efectivo"), ("referencia", "Referencia del pago", ""),
         ("entregado", "Efectivo entregado (solo efectivo)", "20,00 €"), ("cambio", "Cambio (solo efectivo)", "0,59 €"),
         ("cajero", "Cajero (si está activado en Ajustes)", "Ana García"), ("qr_verifactu", "Enlace del QR VERI*FACTU (si lo hay)", ""),
         ("copia", "«1» si es una copia", ""), ("sustituye", "Texto «Sustituye a la …» (si lo hay)", ""),
         ("numero", "Número de factura", "A-000123"), ("fecha_hora", "Fecha y hora del cobro", "12/10/2026 15:00"),
         ("titulo", "Título configurado en Ajustes", "FACTURA SIMPLIFICADA"), ("pie", "Pie configurado en Ajustes", "Gracias por su visita"),
         ("cliente_nombre", "Cliente (si es factura completa)", ""), ("cliente_nif", "NIF del cliente", ""),
         ("cliente_direccion", "Dirección del cliente", ""), ("cliente_observaciones", "Observaciones del cliente", "")]
CAMPOS = {
    "entrada": {
        "campos": _EMPRESA + [
            ("titulo", "Título configurado en Ajustes", "TICKET DE ENTRADA"), ("hora", "Hora de entrada", "13:23"),
            ("fecha_larga", "Fecha de entrada", "lunes, 12 de octubre de 2026"), ("ajuste_hora", "Aviso de hora ajustada (si la hay y no hay matrícula)", ""),
            ("entrada_completa", "Fecha y hora de entrada (solo si hay matrícula)", "12/10/2026 13:23"), ("ajuste_linea", "Aviso de hora ajustada (con matrícula)", ""),
            ("duplicado", "«1» si es un duplicado", ""), ("manual", "«1» si es entrada manual", ""),
            ("matricula", "Matrícula", "1234ABC"), ("matricula_grande", "«1» si Ajustes pide la matrícula grande", ""),
            ("tarifa", "Nombre de la tarifa", "General"), ("llaves", "«… se queda con las llaves» (si se marcó en Entrada)", ""), ("reserva_desde", "Reserva desde (reserva por fecha, si empieza más tarde)", ""), ("reserva_hasta", "Fecha hasta la que no se cobra, «Sin cargo hasta» (si hay reserva)", ""),
            ("reserva_ref", "Nº de reserva (si lo hay)", ""), ("tarifa_despues", "Tarifa después de la reserva", ""),
            ("texto_tarifa", "Texto del ticket de la tarifa", ""), ("url_tarifas", "Dirección para consultar las tarifas (si se activa en Ajustes)", ""), ("cajero", "Cajero (si está activado en Ajustes)", "Ana García"),
            ("codigo", "Código del ticket (QR / barras)", "PK0000123A3F9C"), ("qr_pago", "Enlace de pago con el móvil (si está activo)", ""),
            ("pie", "Pie configurado en Ajustes", "Conserve este ticket")],
        "listas": {"precios": [("etiqueta", "Concepto", "Precio"), ("valor", "Valor", "0,05 €/min")]}},
    "recibo": {
        "campos": _EMPRESA + _PAGO + [
            ("matricula", "Matrícula", "1234ABC"), ("ticket", "Código del ticket", "PK0000123A3F9C"), ("manual", "«1» si es ticket manual", ""),
            ("entrada", "Fecha y hora de entrada", "12/10/2026 13:23"), ("salida", "Fecha y hora de salida", "12/10/2026 15:00"),
            ("pagado_hasta", "Pagado hasta (si se paga por adelantado)", ""), ("tiempo", "Tiempo de estancia", "1 h 37 min"),
            ("incluido_servicios", "Tiempo incluido en servicios", ""), ("pago_fecha", "Fecha y hora del pago", "12/10/2026 15:00"), ("estacionamiento", "Importe del estacionamiento", "4,41 €"),
            ("recargo", "Recargo por ticket perdido", ""), ("descuento_nombre", "Texto «Descuento X»", ""), ("descuento", "Importe del descuento", ""),
            ("aviso_salida", "Aviso «salga antes de las …»", "")],
        "listas": {"lineas": [("nombre", "Concepto (con «2 x »)", "Lavado exterior"), ("importe", "Importe", "12,00 €"),
                              ("precio_unidad", "«(1,50 € / ud.)» si hay varias unidades", ""), ("descripcion", "Descripción", ""),
                              ("incluye", "«(incluye 1 h de parking)»", "")],
                   "desglose": [("izq", "Texto de la izquierda", "Base imponible"), ("der", "Valor", "16,04 €")]}},
    "bono": {
        "campos": _EMPRESA + _PAGO + [
            ("abonado_nombre", "Nombre del abonado", "Laura Martín Gómez"), ("abonado_nif", "NIF del abonado", "12345678Z"),
            ("plan", "Plan del bono", "Mensual 24 horas"),
            ("numero_bono", "Nº de bono", "B-0007"), ("periodo", "«Del 12/10/2026 al 11/11/2026»", "Del 12/10/2026 al 11/11/2026"),
            ("importe_bono", "Importe de este pago", "90,00 €"), ("bono_total", "Importe total del bono (si se paga a plazos)", ""),
            ("bono_pagado", "Pagado hasta hoy (a plazos)", ""), ("bono_pendiente", "Queda pendiente (a plazos)", ""),
            ("valido_hasta", "Válido hasta", "11/11/2026")],
        "listas": {"vehiculos": [("texto", "Vehículo", "1234ABC · Seat Ibiza")],
                   "desglose": [("izq", "Texto de la izquierda", "Base imponible"), ("der", "Valor", "74,38 €")]}},
    "tarjeta": {
        "campos": _EMPRESA + [
            ("titulo", "Título configurado en Ajustes", "TARJETA DE ABONADO"), ("nombre", "Nombre del abonado", "Laura Martín Gómez"),
            ("plan", "Plan del bono", "Mensual 24 horas"), ("valido_hasta", "Válido hasta", "11/11/2026"),
            ("codigo", "Código de la tarjeta (QR / barras)", "CL0000001A3F9C"), ("pie", "Pie configurado en Ajustes", "Presente esta tarjeta en el lector")],
        "listas": {"vehiculos": [("texto", "Vehículo", "1234ABC · Seat Ibiza")]}},
    "factura": {
        "campos": _EMPRESA + [
            ("numero", "Número de factura", "A-000123"), ("fecha", "Fecha y hora", "12/10/2026  15:00"), ("total", "Total", "16,41 €"),
            ("cliente_nombre", "Cliente", "Transportes Ejemplo S.L."), ("cliente_nif", "NIF del cliente", "B12345674"),
            ("matricula", "Matrícula", "1234ABC")],
        "listas": {}},
}

# la «configuración» que los bloques con valor «auto» leen de Ajustes (en el editor, estos valores de ejemplo)
CFG_DEFECTO = {"nombre_tam": "grande", "cabecera_invertida": "1", "mostrar_razon": "1", "mostrar_nif": "1", "mostrar_direccion": "1",
               "mostrar_telefono": "1", "mostrar_web": "0", "cabecera_extra": "", "logo_ticket": "1", "codigo": "ambos", "qr_tam": "6",
               "separador": "-", "lineas_corte": "4"}


def campos_de(tipo):
    c = CAMPOS[tipo]
    return {"campos": [{"campo": a, "descripcion": b, "ejemplo": e} for a, b, e in c["campos"]],
            "listas": {n: [{"campo": a, "descripcion": b, "ejemplo": e} for a, b, e in f] for n, f in c["listas"].items()}}


def ejemplo(tipo):
    """Datos de ejemplo para la vista previa fuera de PROYECTO ALLAS (el editor)."""
    c = CAMPOS[tipo]
    d = {a: e for a, _, e in c["campos"]}
    d["_cfg"] = dict(CFG_DEFECTO)
    if tipo == "entrada":
        d.update(precios=[{"etiqueta": "Precio", "valor": "0,05 €/min"}, {"etiqueta": "Cortesía", "valor": "5 min gratis"},
                          {"etiqueta": "Máximo por 24 h", "valor": "18,00 €"}], pie="Conserve este ticket", cajero="Ana García")
    elif tipo in ("recibo", "bono"):
        iva = [{"izq": "Base imponible", "der": "16,04 €"}, {"izq": "IVA 21% (incluido)", "der": "3,37 €"}]
        if tipo == "recibo":
            d.update(lineas=[{"nombre": "Lavado exterior", "importe": "12,00 €", "precio_unidad": "", "descripcion": "   Lavado a mano", "incluye": ""},
                             {"nombre": "2 x Botella de agua 50 cl", "importe": "3,00 €", "precio_unidad": "   (1,50 € / ud.)", "descripcion": "", "incluye": ""}],
                     desglose=iva, aviso_salida="Salga antes de las 15:15")
        else:
            d.update(vehiculos=[{"texto": "1234ABC · Seat Ibiza"}], desglose=[{"izq": "Base imponible", "der": "74,38 €"}, {"izq": "IVA 21% (incluido)", "der": "15,62 €"}],
                     total="90,00 €", entregado="100,00 €", cambio="10,00 €")
    elif tipo == "tarjeta":
        d.update(vehiculos=[{"texto": "1234ABC · Seat Ibiza"}, {"texto": "5678DEF · Toyota Corolla"}])
    return d


# ---------------------------------------------------------------- validación
_ALIN = ("izq", "centro", "der")
_TAM = ("normal", "alto", "grande")
_SEPS = "-=·*_. "
_BOOL3 = (True, False, "auto")
_COD = ("auto", "ambos", "qr", "barras")
_NOM = re.compile(r"^[a-z_][a-z0-9_]{0,40}$")
_CAMPO = re.compile(r"\{([a-z_][a-z0-9_]*)\}")
_COLOR = re.compile(r"^#[0-9a-fA-F]{6}$")


class ErrorPlantilla(ValueError):
    pass


def _txt(v, max_=MAX_TEXTO):
    if v is None:
        return ""
    if not isinstance(v, str):
        v = str(v)
    if len(v) > max_:
        raise ErrorPlantilla(f"Un texto supera los {max_} caracteres")
    return v


def _enum(v, validos, defecto, nombre):
    if v is None:
        return defecto
    if v not in validos:
        raise ErrorPlantilla(f"«{nombre}» no admite el valor {v!r} (opciones: {', '.join(map(str, validos))})")
    return v


def _bool3(v, nombre):
    if v is None or v == "auto":
        return "auto"
    if isinstance(v, bool):
        return v
    raise ErrorPlantilla(f"«{nombre}» debe ser true, false o \"auto\"")


def _condicion(v):
    v = _txt(v, 80).strip()
    if v and not re.fullmatch(r"!?[a-z_][a-z0-9_]*(?:(?:=|!=)[^\s]{0,40})?", v):
        raise ErrorPlantilla(f"Condición «si» no válida: {v!r}")
    return v


def _bloque(b, tipo, profundidad, cuenta):
    if not isinstance(b, dict):
        raise ErrorPlantilla("Cada bloque debe ser un objeto")
    cuenta[0] += 1
    if cuenta[0] > MAX_BLOQUES:
        raise ErrorPlantilla(f"Demasiados bloques (máximo {MAX_BLOQUES})")
    t = b.get("t")
    o = {"t": t}
    si = _condicion(b.get("si"))
    if t == "cabecera":
        o.update(nombre_tam=_enum(b.get("nombre_tam"), ("auto",) + _TAM, "auto", "nombre_tam"),
                 invertida=_bool3(b.get("invertida"), "invertida"), logo=_bool3(b.get("logo"), "logo"),
                 razon=_bool3(b.get("razon"), "razon"), nif=_bool3(b.get("nif"), "nif"), direccion=_bool3(b.get("direccion"), "direccion"),
                 telefono=_bool3(b.get("telefono"), "telefono"), web=_bool3(b.get("web"), "web"), extra=_txt(b.get("extra", "auto")) or "auto")
    elif t == "texto":
        o.update(texto=_txt(b.get("texto")), alinear=_enum(b.get("alinear"), _ALIN, "izq", "alinear"),
                 negrita=bool(b.get("negrita", False)), tam=_enum(b.get("tam"), _TAM, "normal", "tam"),
                 inverso=bool(b.get("inverso", False)), ajustar=bool(b.get("ajustar", True)))
    elif t == "par":
        o.update(izq=_txt(b.get("izq")), der=_txt(b.get("der")), negrita=bool(b.get("negrita", False)), inverso=bool(b.get("inverso", False)),
                 tam=_enum(b.get("tam"), _TAM[:2], "normal", "tam"))
    elif t == "sep":
        c = b.get("c", "auto")
        if c != "auto" and (not isinstance(c, str) or len(c) != 1 or c not in _SEPS):
            raise ErrorPlantilla(f"Separador no válido: {c!r} (use uno de «{_SEPS}» o \"auto\")")
        o["c"] = c
    elif t == "espacio":
        n = b.get("n", 1)
        if not isinstance(n, int) or isinstance(n, bool) or not 1 <= n <= 5:
            raise ErrorPlantilla("«n» de un espacio debe ser un número de 1 a 5")
        o["n"] = n
    elif t == "logo":
        pass
    elif t == "codigo":
        tam = b.get("tam", "auto")
        if tam != "auto" and (not isinstance(tam, int) or isinstance(tam, bool) or not 3 <= tam <= 8):
            raise ErrorPlantilla("«tam» del código debe ser \"auto\" o un número de 3 a 8")
        o.update(dato=_txt(b.get("dato", "{codigo}"), 120), tipo=_enum(b.get("tipo"), _COD, "auto", "tipo"), tam=tam,
                 mostrar_texto=bool(b.get("mostrar_texto", False)), espacio=bool(b.get("espacio", True)))
    elif t == "repetir":
        if profundidad:
            raise ErrorPlantilla("Un bloque «repetir» no puede ir dentro de otro")
        lista = b.get("lista")
        if lista not in CAMPOS[tipo]["listas"]:
            raise ErrorPlantilla(f"La lista {lista!r} no existe en este tipo (listas: {', '.join(CAMPOS[tipo]['listas']) or 'ninguna'})")
        interior = b.get("bloques")
        if not isinstance(interior, list):
            raise ErrorPlantilla("«repetir» necesita una lista de «bloques»")
        o.update(lista=lista, bloques=[_bloque(x, tipo, 1, cuenta) for x in interior])
    else:
        raise ErrorPlantilla(f"Tipo de bloque desconocido: {t!r}")
    if si:
        o["si"] = si
    return o


def _validar_factura(p):
    est = p.get("estilo") or {}
    sec = p.get("secciones") or {}
    col = p.get("columnas") or {}
    tx = p.get("textos") or {}
    for k in ("color", "cabecera_tabla"):
        if est.get(k) and not _COLOR.match(str(est[k])):
            raise ErrorPlantilla(f"El color «{k}» debe ser #rrggbb")
    out = {"estilo": {k: est[k] for k in ("color", "cabecera_tabla") if est.get(k)},
           # los datos de la empresa, el cliente, el desglose de IVA y el QR VERI*FACTU son obligatorios: no se pueden quitar
           "secciones": {k: bool(sec.get(k, True)) for k in ("logo", "detalle", "observaciones", "notas", "pie")},
           "columnas": {k: bool(col.get(k, True)) for k in ("cantidad", "precio", "iva")},
           "textos": {k: _txt(tx[k], 80) for k in ("titulo_completa", "titulo_simplificada", "cliente", "detalle", "concepto", "cantidad", "precio", "iva",
                                                   "importe", "base", "cuota", "total", "forma_pago", "entregado", "cambio") if tx.get(k)},
           "antes_tabla": _txt(p.get("antes_tabla"), 1000), "notas": _txt(p.get("notas"), 1000), "pie": _txt(p.get("pie"), 1000)}
    out["estilo"]["tam_logo"] = _enum(est.get("tam_logo"), ("pequeno", "mediano", "grande"), "mediano", "tam_logo")
    return out


def validar(p):
    """Comprueba una plantilla y devuelve una copia limpia (solo claves conocidas). Lanza ErrorPlantilla."""
    if isinstance(p, (str, bytes)):
        if len(p) > MAX_BYTES:
            raise ErrorPlantilla("La plantilla es demasiado grande")
        try:
            p = json.loads(p)
        except ValueError:
            raise ErrorPlantilla("El archivo no es un JSON válido")
    if not isinstance(p, dict) or p.get("formato") != FORMATO:
        raise ErrorPlantilla("No es una plantilla de PROYECTO ALLAS (falta «formato»: \"%s\")" % FORMATO)
    if not isinstance(p.get("version"), int) or p["version"] > VERSION:
        raise ErrorPlantilla("Plantilla de una versión más nueva: actualice el programa")
    tipo = p.get("tipo")
    if tipo not in TIPOS:
        raise ErrorPlantilla(f"Tipo de plantilla desconocido: {tipo!r} (tipos: {', '.join(TIPOS)})")
    out = {"formato": FORMATO, "version": VERSION, "tipo": tipo, "nombre": _txt(p.get("nombre"), 80).strip() or TIPOS[tipo]}
    if tipo == "factura":
        out.update(_validar_factura(p))
    else:
        bl = p.get("bloques")
        if not isinstance(bl, list) or not bl:
            raise ErrorPlantilla("La plantilla no tiene bloques")
        cuenta = [0]
        out["bloques"] = [_bloque(b, tipo, 0, cuenta) for b in bl]
    if len(json.dumps(out)) > MAX_BYTES:
        raise ErrorPlantilla("La plantilla es demasiado grande")
    return out


def campos_usados(p):
    """Campos {x} que usa la plantilla y no existen en su tipo (para avisar en el editor)."""
    tipo = p.get("tipo")
    if tipo not in CAMPOS:
        return []
    ok = {a for a, _, _ in CAMPOS[tipo]["campos"]}
    for lst in CAMPOS[tipo]["listas"].values():
        ok |= {a for a, _, _ in lst}
    usados = set()

    def ver(bs):
        for b in bs:
            for k in ("texto", "izq", "der", "dato", "extra"):
                usados.update(_CAMPO.findall(b.get(k) or "") if isinstance(b.get(k), str) else [])
            s = (b.get("si") or "").lstrip("!").split("=")[0].split("!")[0]
            if s:
                usados.add(s)
            ver(b.get("bloques") or [])
    ver(p.get("bloques") or [])
    return sorted(usados - ok)


# ---------------------------------------------------------------- dibujo de tickets
def _valor(datos, item, nombre):
    if item is not None and nombre in item:
        v = item[nombre]
    else:
        v = datos.get(nombre)
    return "" if v is None or v is False else str(v)


def _expandir(texto, datos, item):
    campos = _CAMPO.findall(texto or "")
    valores = {c: _valor(datos, item, c) for c in campos}
    return _CAMPO.sub(lambda m: valores[m.group(1)], texto or ""), campos, valores


def _cumple(si, datos, item):
    if not si:
        return True
    neg = si.startswith("!")
    cond = si[1:] if neg else si
    if "!=" in cond:
        c, v = cond.split("!=", 1)
        r = _valor(datos, item, c) != v
    elif "=" in cond:
        c, v = cond.split("=", 1)
        r = _valor(datos, item, c) == v
    else:
        r = _valor(datos, item, cond).strip() not in ("", "0")
    return (not r) if neg else r


def _cfg(datos, k):
    return str((datos.get("_cfg") or {}).get(k, CFG_DEFECTO.get(k, "")))


def _estilo(doc, b):
    doc.alinear(b.get("alinear", "izq"))
    if b.get("negrita"):
        doc.negrita()
    if b.get("tam") == "grande":
        doc.grande()
    elif b.get("tam") == "alto":
        doc.alto()
    if b.get("inverso"):
        doc.inverso()


def _reset(doc):
    doc.negrita(False).grande(False).alto(False).inverso(False).alinear("izq")


def _auto(v, cfg_val):
    return (cfg_val == "1") if v == "auto" else bool(v)


def _cabecera(doc, b, datos, logo):
    if _auto(b.get("logo", "auto"), _cfg(datos, "logo_ticket")) and logo:
        r = logo()
        if r:
            doc.logo(*r)
    doc.alinear("centro")
    tam = _cfg(datos, "nombre_tam") if b.get("nombre_tam", "auto") == "auto" else b["nombre_tam"]
    if _auto(b.get("invertida", "auto"), _cfg(datos, "cabecera_invertida")):
        doc.inverso()
    doc.negrita()
    if tam == "grande":
        doc.grande()
    elif tam == "alto":
        doc.alto()
    doc.linea(datos.get("nombre_parking") or "").negrita(False).grande(False).alto(False).inverso(False)
    doc.espacio()
    if datos.get("demo"):
        doc.negrita().lineas("*** DEMOSTRACION - SIN VALIDEZ ***").negrita(False)
    razon = datos.get("razon_social") or ""
    t_razon = razon if _auto(b.get("razon", "auto"), _cfg(datos, "mostrar_razon")) else ""
    t_nif = ("NIF " + (datos.get("nif") or "")) if _auto(b.get("nif", "auto"), _cfg(datos, "mostrar_nif")) or not razon else ""
    if t_razon and t_nif and len(t_razon) + len(t_nif) + 3 <= doc.ancho:   # 4.43: razón social y NIF en la misma línea
        doc.negrita().linea(f"{t_razon} · {t_nif}").negrita(False)
    else:
        if t_razon:
            doc.negrita().lineas(t_razon).negrita(False)
        if t_nif:
            doc.linea(t_nif)
    if _auto(b.get("direccion", "auto"), _cfg(datos, "mostrar_direccion")) and datos.get("direccion"):
        doc.lineas(datos["direccion"])
    if _auto(b.get("telefono", "auto"), _cfg(datos, "mostrar_telefono")) and datos.get("telefono"):
        doc.linea("Tel. " + datos["telefono"])
    if _auto(b.get("web", "auto"), _cfg(datos, "mostrar_web")):
        for k in ("web", "email"):
            if datos.get(k):
                doc.lineas(datos[k].replace("https://", "").replace("http://", ""))
    extra = _cfg(datos, "cabecera_extra") if b.get("extra", "auto") == "auto" else _expandir(b["extra"], datos, None)[0]
    if extra:
        doc.lineas(extra)
    doc.alinear("izq").separador("=")


def _dibujar(doc, bloques, datos, logo, item=None):
    for b in bloques:
        if not _cumple(b.get("si"), datos, item):
            continue
        t = b["t"]
        if t == "cabecera":
            _cabecera(doc, b, datos, logo)
        elif t == "texto":
            txt, campos, vals = _expandir(b["texto"], datos, item)
            if campos and not any(v.strip() for v in vals.values()):
                continue
            _estilo(doc, b)
            if b.get("ajustar", True):
                doc.lineas(txt)
            else:
                for l in txt.split("\n"):
                    doc.linea(l)
            _reset(doc)
        elif t == "par":
            izq, c1, v1 = _expandir(b["izq"], datos, item)
            der, c2, v2 = _expandir(b["der"], datos, item)
            if (c1 or c2) and not any(v.strip() for v in list(v1.values()) + list(v2.values())):
                continue
            _estilo(doc, b)
            doc.par(izq, der)
            _reset(doc)
        elif t == "sep":
            doc.alinear("izq").separador(None if b.get("c", "auto") == "auto" else b["c"])
        elif t == "espacio":
            doc.espacio(b.get("n", 1))
        elif t == "logo":
            r = logo() if logo else None
            if r:
                doc.logo(*r)
        elif t == "codigo":
            dato, campos, vals = _expandir(b.get("dato", "{codigo}"), datos, item)
            dato = "".join(ch if 32 <= ord(ch) < 127 else "?" for ch in dato).strip()
            if not dato:
                continue
            tipo = _cfg(datos, "codigo") if b.get("tipo", "auto") == "auto" else b["tipo"]
            tam = int(_cfg(datos, "qr_tam") or 6) if b.get("tam", "auto") == "auto" else b["tam"]
            doc.alinear("centro")
            if b.get("espacio", True):
                doc.espacio()
            doc.codigo(dato, tipo, tam)
            if tipo == "qr" and b.get("mostrar_texto", False):
                doc.negrita().linea(dato).negrita(False)
            doc.alinear("izq")
        elif t == "repetir":
            for it in datos.get(b["lista"]) or []:
                _dibujar(doc, b["bloques"], datos, logo, it)


def dibujar_ticket(doc, plantilla, datos, logo=None):
    """Dibuja la plantilla (ya validada) en 'doc' (impresion.Ticket) con los 'datos' del documento.
    logo: función sin argumentos que devuelve (ancho, alto, bits, versión) o None. Devuelve doc con el corte puesto."""
    if plantilla.get("tipo") not in TIPOS_TICKET:
        raise ErrorPlantilla("Esta plantilla no es de un ticket")
    sep = _cfg(datos, "separador")[:1]
    doc.sep = sep if sep and sep in _SEPS else "-"
    try:
        doc.lineas_corte = max(1, min(10, int(_cfg(datos, "lineas_corte") or 4)))
    except ValueError:
        pass
    _dibujar(doc, plantilla["bloques"], datos, logo)
    return doc.cortar()


# ---------------------------------------------------------------- plantillas de fábrica (= el diseño de serie)
def _t(texto, **k):
    return {"t": "texto", "texto": texto, **k}


def _p(izq, der, **k):
    return {"t": "par", "izq": izq, "der": der, **k}


_SEP = {"t": "sep"}
_TITULO = dict(alinear="centro", negrita=True, tam="alto")


def _bloque_total():
    return [{"t": "repetir", "lista": "desglose", "bloques": [_p("{izq}", "{der}")]},
            _p(" TOTAL", "{total} ", negrita=True, inverso=True, tam="alto")]


def _bloque_pago():
    return [_p("Forma de pago", "{forma_pago}"), _p("Referencia", "{referencia}"), _p("Entregado", "{entregado}", si="entregado"),
            _p("Cambio", "{cambio}", si="entregado"), _p("Atendido por", "{cajero}"), _SEP,
            {"t": "texto", "texto": "QR tributario:", "alinear": "centro", "si": "qr_verifactu"},
            {"t": "codigo", "dato": "{qr_verifactu}", "tipo": "qr", "tam": 4, "si": "qr_verifactu", "espacio": False},
            _t("VERI*FACTU", alinear="centro", negrita=True, si="qr_verifactu"),
            _t("Factura verificable en la sede electrónica de la AEAT", alinear="centro", si="qr_verifactu"),
            {"t": "sep", "si": "qr_verifactu"}]


def _cab_factura():
    return [_t("{titulo}", **_TITULO), _t("Nº {numero}  ·  {fecha_hora}", alinear="centro", ajustar=False),
            _t(" COPIA ", alinear="centro", inverso=True, si="copia"),
            _t("{sustituye}", alinear="centro", si="sustituye"), _SEP,
            _t("Cliente:", negrita=True, si="cliente_nombre"), _t("{cliente_nombre}"), _t("NIF/CIF: {cliente_nif}"),
            _t("{cliente_direccion}"), _t("Observaciones: {cliente_observaciones}"), {"t": "sep", "si": "cliente_nombre"}]


def fabrica(tipo):
    """Plantilla que reproduce el diseño de serie (punto de partida para el editor)."""
    cab = {"t": "cabecera"}
    if tipo == "entrada":
        b = [cab, _t("{titulo}", **_TITULO),
             _t(" DUPLICADO ", alinear="centro", inverso=True, si="duplicado"), _t(" ENTRADA MANUAL ", alinear="centro", inverso=True, si="manual"),
             _t("{matricula}", alinear="centro", negrita=True, tam="grande", si="matricula", ajustar=False),
             _t("{hora}", alinear="centro", negrita=True, tam="grande", si="!matricula"), _t("{fecha_larga}", alinear="centro", si="!matricula"),
             _t("{ajuste_hora}", alinear="centro", si="ajuste_hora"), _SEP,
             _p("Entrada", "{entrada_completa}", negrita=True), _t("{ajuste_linea}", si="ajuste_linea"),
             _p("Tarifa", "{tarifa}"), _p("Reserva desde", "{reserva_desde}", negrita=True), _p("Sin cargo hasta", "{reserva_hasta}", negrita=True), _p("Nº reserva", "{reserva_ref}"),
             _p("Después", "{tarifa_despues}"),
             {"t": "repetir", "lista": "precios", "bloques": [_p("{etiqueta}", "{valor}")]},
             _t("Consulte las tarifas en:", alinear="centro", si="url_tarifas"), _t("{url_tarifas}", alinear="centro", negrita=True, si="url_tarifas"),
             {"t": "sep", "si": "texto_tarifa"}, _t("{texto_tarifa}", alinear="centro", negrita=True),
             _p("Atendido por", "{cajero}"), {"t": "sep", "si": "llaves"}, _t("{llaves}", alinear="centro", negrita=True, si="llaves"),
             _SEP, {"t": "codigo", "dato": "{codigo}", "mostrar_texto": True, "espacio": False},
             {"t": "sep", "si": "qr_pago"}, _t("PAGUE CON SU MÓVIL", alinear="centro", negrita=True, si="qr_pago"),
             _t("Escanee este código con la cámara del móvil", alinear="centro", si="qr_pago"),
             {"t": "codigo", "dato": "{qr_pago}", "tipo": "qr", "tam": 5, "si": "qr_pago", "espacio": False},
             _SEP, _t("{pie}", alinear="centro")]
    elif tipo == "recibo":
        b = [cab] + _cab_factura() + [
            _p("Matrícula", "{matricula}", negrita=True), _p("Ticket", "{ticket}"),
            _t(" TICKET MANUAL ", alinear="centro", inverso=True, si="manual"),
            _p("Entrada", "{entrada}"), _p("Salida", "{salida}"), _p("Pagado hasta", "{pagado_hasta}"), _p("Pago", "{pago_fecha}"),
            _p("Tiempo", "{tiempo}"), _p("Incluido en servicios", "{incluido_servicios}"), {"t": "sep", "si": "ticket"},
            _p("Estacionamiento", "{estacionamiento}"), _p("Recargo ticket perdido", "{recargo}"),
            {"t": "repetir", "lista": "lineas", "bloques": [_p("{nombre}", "{importe}"), _t("{precio_unidad}", ajustar=False),
                                                            _t("{descripcion}", ajustar=False), _t("{incluye}", ajustar=False)]},
            _p("{descuento_nombre}", "{descuento}"), _SEP] + _bloque_total() + _bloque_pago() + [
            _t("{aviso_salida}", alinear="centro", negrita=True, tam="alto"), {"t": "espacio"}, _t("{pie}", alinear="centro")]
    elif tipo == "bono":
        b = [cab] + _cab_factura() + [
            _p("Cliente", "{abonado_nombre}", negrita=True), _p("NIF", "{abonado_nif}"),
            {"t": "repetir", "lista": "vehiculos", "bloques": [_p("Vehículo", "{texto}")]}, _SEP,
            _t("Bono {plan}", negrita=True), _p("Nº de bono", "{numero_bono}"), _p("{periodo}", "{importe_bono}"),
            _p("Importe del bono", "{bono_total}"), _p("Pagado hasta hoy", "{bono_pagado}"), _p("Queda pendiente", "{bono_pendiente}", negrita=True),
            _SEP] + _bloque_total() + _bloque_pago() + [
            _t("Válido hasta {valido_hasta}", alinear="centro", negrita=True, tam="alto"), {"t": "espacio"}, _t("{pie}", alinear="centro")]
    elif tipo == "tarjeta":
        b = [cab, _t("{titulo}", alinear="centro", negrita=True, tam="alto", inverso=True), {"t": "espacio"},
             _t("{nombre}", alinear="centro", negrita=True, tam="alto"),
             {"t": "repetir", "lista": "vehiculos", "bloques": [_t("{texto}", alinear="centro")]},
             _t("Bono {plan}", alinear="centro", ajustar=False), _t("Válido hasta {valido_hasta}", alinear="centro", ajustar=False),
             _SEP, {"t": "codigo", "dato": "{codigo}", "mostrar_texto": True}, _SEP, _t("{pie}", alinear="centro")]
    elif tipo == "factura":
        return {"formato": FORMATO, "version": VERSION, "tipo": "factura", "nombre": "Factura A4 de serie",
                "estilo": {"color": "#1747c9", "cabecera_tabla": "#141b26", "tam_logo": "mediano"},
                "secciones": {k: True for k in ("logo", "detalle", "observaciones", "notas", "pie")},
                "columnas": {"cantidad": True, "precio": True, "iva": True},
                "textos": {"titulo_completa": "FACTURA", "titulo_simplificada": "FACTURA SIMPLIFICADA", "cliente": "CLIENTE", "detalle": "DETALLE",
                           "concepto": "Concepto", "cantidad": "Cant.", "precio": "Precio", "iva": "IVA", "importe": "Importe",
                           "base": "Base imponible", "cuota": "IVA", "total": "TOTAL", "forma_pago": "Forma de pago",
                           "entregado": "Entregado", "cambio": "Cambio"},
                "antes_tabla": "", "notas": "", "pie": ""}
    else:
        raise ErrorPlantilla("Tipo desconocido")
    return {"formato": FORMATO, "version": VERSION, "tipo": tipo, "nombre": TIPOS[tipo] + " de serie", "bloques": copy.deepcopy(b)}


# ---------------------------------------------------------------- factura A4: aplicar la plantilla a los datos
def aplicar_factura(datos, plt, demo=False):
    """Aplica una plantilla de factura A4 (ya validada) a los datos de la factura antes de dibujar el PDF:
    colores, títulos, secciones, columnas, etiquetas y textos libres. Lo usan PROYECTO ALLAS y el editor."""
    from .pdf import color_hex, eur
    est, tx = plt["estilo"], plt["textos"]
    if est.get("color"):
        datos["estilo"]["acento"] = color_hex(est["color"])
    if est.get("cabecera_tabla"):
        datos["estilo"]["cabecera_tabla"] = color_hex(est["cabecera_tabla"])
    datos["estilo"]["logo_alto"] = {"pequeno": 40, "mediano": 62, "grande": 90}[est["tam_logo"]]
    propio = tx.get("titulo_completa") if datos.get("cliente") else tx.get("titulo_simplificada")
    previo = datos["titulo"]
    prefijo = next((x for x in ("DEMOSTRACIÓN · SIN VALIDEZ · ", "MUESTRA · ") if previo.startswith(x)), "")
    if propio and not previo[len(prefijo):].startswith("FACTURA RECTIFICATIVA"):
        datos["titulo"] = prefijo + propio
    datos["plantilla"] = {"secciones": plt["secciones"], "columnas": plt["columnas"], "textos": tx}
    emp, cli = datos.get("empresa") or {}, datos.get("cliente") or {}
    campos = {"numero": datos["numero"], "fecha": datos["fecha"], "total": eur(datos["total"]),
              "nombre_parking": emp.get("nombre") or "", "razon_social": emp.get("razon_social") or "", "nif": emp.get("nif") or "",
              "direccion": emp.get("direccion") or "", "telefono": emp.get("telefono") or "", "web": emp.get("web") or "",
              "email": emp.get("email") or "", "cliente_nombre": cli.get("nombre") or "", "cliente_nif": cli.get("nif") or "",
              "matricula": next((v for k, v in datos.get("detalles") or [] if k == "Matrícula"), "")}
    datos["antes_tabla"] = _expandir(plt["antes_tabla"], campos, None)[0].strip() or None
    if plt["notas"].strip():
        datos["notas"] = _expandir(plt["notas"], campos, None)[0].strip()
    if plt["pie"].strip():
        datos["pie"] = _expandir(plt["pie"], campos, None)[0]
    return datos


def datos_factura_ejemplo(plt=None):
    """Datos de ejemplo de una factura A4 (para la vista previa del editor)."""
    campos = {a: e for a, _, e in CAMPOS["factura"]["campos"]}
    d = {"empresa": {"nombre": campos["nombre_parking"], "razon_social": campos["razon_social"], "nif": campos["nif"], "direccion": campos["direccion"],
                     "telefono": campos["telefono"], "email": campos["email"], "web": campos["web"]},
         "estilo": {}, "notas": None, "titulo": "FACTURA", "numero": campos["numero"], "fecha": campos["fecha"],
         "cliente": {"nombre": campos["cliente_nombre"], "nif": campos["cliente_nif"], "direccion": "C/ Mayor 1, 28013 Madrid", "observaciones": "Pedido 4521"},
         "detalles": [("Matrícula", "1234ABC"), ("Ticket", "PK0000123A3F9C"), ("Entrada", "12/10/2026 13:23"), ("Salida", "12/10/2026 15:00"), ("Tiempo", "1 h 37 min")],
         "lineas": [{"concepto": "Estacionamiento", "detalle": "1 h 37 min · tarifa General", "cantidad": 1, "precio": 441, "iva": 21.0, "importe": 441},
                    {"concepto": "Lavado exterior", "detalle": "Lavado a mano", "cantidad": 1, "precio": 1200, "iva": 21.0, "importe": 1200}],
         "desglose": [{"pct": 21.0, "base": 1356, "cuota": 285}], "total": 1641,
         "pago": {"metodo": "Efectivo", "entregado": 2000, "cambio": 359}, "pie": "Gracias por su visita", "marca": "Editor de plantillas",
         "logo": None, "verifactu": None}
    if plt:
        aplicar_factura(d, plt)
    return d
