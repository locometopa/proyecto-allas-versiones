"""3.9 · Periféricos opcionales: barrera (relé) y datáfono (pasarela de cobro con tarjeta).

Barrera: se abre con un relé. Conexiones:
- http: una URL (relés de red tipo Shelly, ESP, controladoras de acceso…): se hace GET (o POST si empieza por «POST »).
- tcp: IP:puerto y los bytes a enviar (relés Ethernet que reciben comandos por socket).
- serie: puerto COM/USB y los bytes (relés USB tipo LCUS: A0 01 01 A2 abre, A0 01 00 A1 cierra).
- programa: una orden del sistema (utilidad del fabricante).

Datáfono: el cobro con tarjeta se lanza a una pasarela y se espera la respuesta.
- simulado: aprueba siempre (para probar).
- http: POST JSON {importe_cent, importe, referencia} → {"ok": true, "autorizacion": "…", "mensaje": "…"}.
- programa: orden con {importe}, {importe_cent} y {referencia}; código de salida 0 = aprobada,
  la primera línea que escriba es el nº de autorización.
"""
import json
import os
import secrets
import shutil
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request

from . import visor


def bytes_de(texto):
    """'A0 01 01 A2' o '0xA0,0x01' → bytes; si no son hexadecimales, el texto tal cual (con \\r\\n)."""
    t = (texto or "").strip()
    if not t:
        return b""
    limpio = t.replace("0x", "").replace("0X", "").replace(",", " ").replace(":", " ")
    partes = limpio.split()
    try:
        if partes and all(len(p) <= 2 for p in partes):
            return bytes(int(p, 16) for p in partes)
        if len(limpio) % 2 == 0 and " " not in limpio:
            return bytes.fromhex(limpio)
    except ValueError:
        pass
    return t.encode("latin-1", "replace").replace(b"\\r", b"\r").replace(b"\\n", b"\n")


def _http(url, cuerpo=None, timeout=5):
    metodo = "GET"
    if url.upper().startswith("POST "):
        metodo, url = "POST", url[5:].strip()
    datos = json.dumps(cuerpo).encode() if cuerpo is not None else (b"" if metodo == "POST" else None)
    req = urllib.request.Request(url, data=datos, method=metodo if cuerpo is None else "POST",
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, r.read()


def _serie(puerto, baudios, datos):
    visor._configurar_serie(puerto, int(baudios or 9600))
    ruta = ("\\\\.\\" + puerto) if os.name == "nt" and not puerto.startswith("\\\\") else puerto
    with open(ruta, "wb", buffering=0) as f:
        f.write(datos)


def _programa(orden, valores, timeout=10):
    args = visor.comando_programa(orden, "", "")   # separa la orden respetando las comillas
    args = [a for a in args if a]                    # comando_programa añade 2 vacíos si no hay marcadores
    args = [_poner(a, valores) for a in args]
    extra = {"creationflags": 0x08000000} if os.name == "nt" else {}
    return subprocess.run(args, capture_output=True, timeout=timeout, **extra)


def _poner(texto, valores):
    for k, v in valores.items():
        texto = texto.replace("{" + k + "}", str(v))
    return texto


# ------------------------------------------------------------------ barrera
def abrir_barrera(cfg):
    """cfg: conexion, destino, abrir (bytes en texto), cerrar, pulso_ms, baudios. Devuelve un texto con lo hecho."""
    con, destino = cfg.get("conexion") or "http", (cfg.get("destino") or "").strip()
    if not destino:
        raise ValueError("Indique la dirección, el puerto o el programa de la barrera")
    abrir, cerrar = bytes_de(cfg.get("abrir")), bytes_de(cfg.get("cerrar"))
    pulso = max(0, min(10000, int(cfg.get("pulso_ms") or 0))) / 1000
    if con == "http":
        estado, _ = _http(destino)
        if cfg.get("cerrar") and pulso:   # algunos relés necesitan otra URL para soltar
            time.sleep(pulso)
            _http(cfg["cerrar"].strip())
        return f"HTTP {estado}"
    if con == "tcp":
        host, _, puerto = destino.partition(":")
        with socket.create_connection((host, int(puerto or 80)), timeout=3) as s:
            s.sendall(abrir)
            if cerrar:
                time.sleep(pulso)
                s.sendall(cerrar)
        return f"enviado a {destino}"
    if con == "serie":
        _serie(destino, cfg.get("baudios"), abrir)
        if cerrar:
            time.sleep(pulso)
            _serie(destino, cfg.get("baudios"), cerrar)
        return f"enviado a {destino}"
    if con == "programa":
        r = _programa(destino, {})
        if r.returncode != 0:
            raise ValueError(f"El programa de la barrera terminó con error {r.returncode}")
        return "programa ejecutado"
    raise ValueError(f"Conexión de barrera desconocida: {con}")


# ------------------------------------------------------------------ 4.4 · semáforo y cartel LIBRE / COMPLETO
def enviar_senal(cfg, estado):
    """cfg: conexion (http | tcp | serie | programa), destino, libre, completo, baudios.
    - http: «libre» y «completo» son las URL a llamar (si van vacías, se llama a destino con ?estado=libre|completo).
    - tcp / serie: destino = IP:puerto o COM3; «libre» y «completo» son los bytes (A0 01 00 A1) o el texto a enviar.
    - programa: destino es la orden; {estado} se cambia por libre o completo."""
    if estado not in ("libre", "completo"):
        raise ValueError("Estado no válido")
    con, destino = cfg.get("conexion") or "http", (cfg.get("destino") or "").strip()
    orden = (cfg.get(estado) or "").strip()
    if con == "http":
        url = orden or destino
        if not url:
            raise ValueError("Indique la URL de LIBRE y la de COMPLETO")
        if not orden:
            url += ("&" if "?" in url else "?") + "estado=" + estado
        st, _ = _http(url)
        return f"HTTP {st}"
    if not destino:
        raise ValueError("Indique la dirección, el puerto o el programa")
    if con == "tcp":
        host, _, puerto = destino.partition(":")
        with socket.create_connection((host, int(puerto or 80)), timeout=3) as s:
            s.sendall(bytes_de(orden) or estado.upper().encode() + b"\r\n")
        return f"enviado a {destino}"
    if con == "serie":
        _serie(destino, cfg.get("baudios"), bytes_de(orden) or estado.upper().encode() + b"\r\n")
        return f"enviado a {destino}"
    if con == "programa":
        r = _programa(destino, {"estado": estado})
        if r.returncode != 0:
            raise ValueError(f"El programa terminó con error {r.returncode}")
        return "programa ejecutado"
    raise ValueError(f"Conexión desconocida: {con}")


# ------------------------------------------------------------------ datáfono
def cobrar_datafono(cfg, importe_cent, referencia=None):
    """→ {"ok": bool, "autorizacion": str|None, "mensaje": str}. Espera la respuesta (hasta el tiempo indicado)."""
    modo = cfg.get("modo") or "simulado"
    referencia = referencia or secrets.token_hex(4).upper()
    espera = max(10, min(300, int(cfg.get("timeout") or 90)))
    valores = {"importe": f"{importe_cent / 100:.2f}", "importe_cent": importe_cent, "referencia": referencia}
    if modo == "simulado":
        time.sleep(min(2.0, float(cfg.get("simulado_segundos") or 1.5)))
        return {"ok": True, "autorizacion": "SIM" + secrets.token_hex(3).upper(), "mensaje": "Aprobada (datáfono simulado)"}
    destino = (cfg.get("destino") or "").strip()
    if not destino:
        return {"ok": False, "autorizacion": None, "mensaje": "Falta la dirección o el programa del datáfono (Ajustes)"}
    if modo == "http":
        try:
            _, cuerpo = _http(destino, {"importe_cent": importe_cent, "importe": valores["importe"],
                                        "referencia": referencia, "operacion": "venta"}, timeout=espera)
            r = json.loads(cuerpo or b"{}")
        except urllib.error.HTTPError as e:
            try:
                r = json.loads(e.read() or b"{}")
            except ValueError:
                r = {}
            return {"ok": False, "autorizacion": None, "mensaje": r.get("mensaje") or f"Error {e.code} de la pasarela"}
        except (urllib.error.URLError, OSError, ValueError) as e:
            return {"ok": False, "autorizacion": None, "mensaje": f"No se puede conectar con el datáfono: {getattr(e, 'reason', e)}"}
        ok = bool(r.get("ok") or r.get("aprobada"))
        return {"ok": ok, "autorizacion": str(r.get("autorizacion") or r.get("codigo") or "") or None,
                "mensaje": r.get("mensaje") or ("Aprobada" if ok else "Denegada")}
    if modo == "programa":
        try:
            r = _programa(destino, valores, timeout=espera)
        except subprocess.TimeoutExpired:
            return {"ok": False, "autorizacion": None, "mensaje": "El datáfono no ha respondido a tiempo"}
        except OSError as e:
            return {"ok": False, "autorizacion": None, "mensaje": f"No se pudo lanzar el programa del datáfono: {e}"}
        salida = (r.stdout or b"").decode("utf-8", "replace").strip().splitlines()
        if r.returncode == 0:
            return {"ok": True, "autorizacion": (salida[0].strip()[:40] if salida else None), "mensaje": "Aprobada"}
        error = (r.stderr or b"").decode("utf-8", "replace").strip() or (salida[0] if salida else "")
        return {"ok": False, "autorizacion": None, "mensaje": error[:200] or f"Denegada (código {r.returncode})"}
    return {"ok": False, "autorizacion": None, "mensaje": f"Modo de datáfono desconocido: {modo}"}


# ------------------------------------------------------------------ 4.1 · aplicaciones externas
def lanzar_programa(destino, argumentos=""):
    """Abre un programa, documento o carpeta en este PC sin esperar a que termine."""
    destino = (destino or "").strip().strip('"')
    if not destino:
        raise ValueError("Falta la ruta del programa")
    extra = visor.comando_programa(argumentos, "", "") if argumentos else []
    extra = [a for a in extra if a]
    if os.name == "nt":
        if not extra and not destino.lower().endswith((".exe", ".bat", ".cmd", ".com")):
            os.startfile(destino)   # documento, carpeta o acceso directo: con su programa
            return
        subprocess.Popen([destino, *extra], creationflags=0x00000008 | 0x00000200, close_fds=True)   # DETACHED | NEW_GROUP
        return
    if not os.path.exists(destino) and not shutil.which(destino):
        raise ValueError(f"No existe {destino}")
    if os.path.isdir(destino) or (not os.access(destino, os.X_OK) and os.path.isfile(destino)):
        abridor = "open" if sys.platform == "darwin" else "xdg-open"
        subprocess.Popen([abridor, destino], start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return
    subprocess.Popen([destino, *extra], start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
