"""PROYECTO ALLAS 1.6 · listados exportables (CSV, Excel, PDF), lectura de servicios y productos desde una tabla y borrado de clientes."""
import csv
import io
import re

from . import tablas
from .utiles import ErrorNegocio, _norm_txt, eur

CONJUNTOS = ("clientes-abonados", "clientes-no-abonados", "clientes-todos", "abonados", "servicios", "productos", "tarifas")

COLS_CLIENTES = [("nombre", 24), ("nif", 11), ("telefono", 12), ("email", 24), ("direccion", 28), ("matricula", 14),
                 ("marca", 10), ("modelo", 10), ("tipo", 11), ("notas", 24)]
COLS_CATALOGO = [("Nombre", 26, "izq"), ("Tipo", 9, "izq"), ("Precio (€)", 10, "der"), ("IVA (%)", 8, "der"), ("Activo", 7, "izq"),
                 ("Parking incluido (min)", 12, "der"), ("Descripción", 30, "izq"), ("Orden", 6, "der")]


def _entero_o_decimal(x):
    return int(x) if x is not None and float(x) == int(float(x)) else x


def numero(texto):
    """'12,50 €', '1.250,5', '12.5' o 12.5 → float; None si no es un número."""
    if isinstance(texto, (int, float)):
        return float(texto)
    s = re.sub(r"[€\s]", "", str(texto or ""))
    if not s:
        return None
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".") if s.rfind(",") > s.rfind(".") else s.replace(",", "")
    elif "," in s:
        s = s.replace(",", ".")
    elif re.fullmatch(r"\d{1,3}(\.\d{3})+", s):
        s = s.replace(".", "")
    try:
        return float(s)
    except ValueError:
        return None


class SvcTablas:
    # ------------------------------------------------------------------ exportar
    def _tabla_clientes(self, tipo):
        txt = self.exportar_clientes_csv().lstrip("﻿")
        filas = list(csv.reader(io.StringIO(txt), delimiter=";"))
        cab, datos = filas[0], filas[1:]
        i = cab.index("tipo")
        if tipo == "abonado":
            datos = [f for f in datos if f[i] == "abonado"]
        elif tipo == "no-abonado":
            datos = [f for f in datos if f[i] != "abonado"]
        titulo = {"abonado": "Abonados", "no-abonado": "Clientes sin abono"}.get(tipo, "Clientes")
        return tablas.Tabla(titulo, [(c, a) for c, a in COLS_CLIENTES], datos, resumen=f"{len(datos)} cliente(s)", hoja=titulo)

    def _tabla_catalogo(self, que):
        tipo = "servicio" if que == "servicios" else "producto"
        filas = [[x["nombre"], tipo, round((x["precio_cent"] or 0) / 100, 2) if not x.get("precio_variable") else None,
                  _entero_o_decimal(x["iva_pct"]), "Sí" if x["activo"] else "No", x["minutos_incluidos"] or 0,
                  x["descripcion"] or "", x["orden"] or 0]
                 for x in self.productos() if x["tipo"] == tipo and not x.get("solo_proveedor")]
        titulo = "Servicios" if tipo == "servicio" else "Productos de tienda"
        return tablas.Tabla(titulo, COLS_CATALOGO, filas, resumen=f"{len(filas)} {titulo.lower()}", hoja=titulo)

    def _tabla_tarifas(self):
        dias = {"1": "L", "2": "M", "3": "X", "4": "J", "5": "V", "6": "S", "7": "D"}
        filas = []
        for t in self.tarifas():
            if not t["activa"]:
                continue
            tramos = "; ".join(
                f"{x['desde_min']}–{x['hasta_min'] if x['hasta_min'] is not None else '∞'} min: {x['precio_mil'] / 1000:.3f}".replace(".", ",")
                + f" € cada {x['fraccion_min']} min" for x in t["tramos"])
            hor = ""
            if t.get("horario_desde") or t.get("horario_hasta"):
                hor = f"{t.get('horario_desde') or ''}–{t.get('horario_hasta') or ''} {t.get('horario_dias') or ''}".strip()
            filas.append([t["nombre"], t.get("modo") or "tramos", "Sí" if t["por_defecto"] else "No", t["gracia_min"] or 0,
                          round((t["maximo_diario_cent"] or 0) / 100, 2) if t.get("maximo_diario_cent") else None, hor, tramos])
        cols = [("Tarifa", 22, "izq"), ("Modo", 8, "izq"), ("Por defecto", 8, "izq"), ("Gracia (min)", 8, "der"),
                ("Máximo diario (€)", 10, "der"), ("Horario", 14, "izq"), ("Tramos", 50, "izq")]
        return tablas.Tabla("Tarifas", cols, filas, resumen=f"{len(filas)} tarifa(s)", hoja="Tarifas")

    def _tabla_abonados(self, estado="todos"):
        nombres = {"vigente": "Vigente", "caduca": "Caduca pronto", "caducado": "Caducado", "futuro": "Futuro", "sin_bono": "Sin bono"}
        filas = []
        for a in self.abonados_listado(estado, ""):
            b = a["bono"]
            filas.append([a["nombre"], a["nif"] or "", a["telefono"] or "", a["email"] or "",
                          ", ".join(v["matricula"] for v in a["vehiculos"]), b.get("plan") or "", b.get("desde") or "",
                          b.get("hasta") or "", nombres.get(b["estado"], b["estado"]), "Sí" if a["renovacion_auto"] else "No"])
        cols = [("Abonado", 22, "izq"), ("NIF/CIF", 11, "izq"), ("Teléfono", 12, "izq"), ("Email", 24, "izq"), ("Vehículos", 20, "izq"),
                ("Bono", 14, "izq"), ("Desde", 11, "izq"), ("Hasta", 11, "izq"), ("Estado", 12, "izq"), ("Renovación auto", 8, "izq")]
        return tablas.Tabla("Listado de abonados", cols, filas, resumen=f"{len(filas)} abonado(s)", hoja="Abonados")

    def tabla_exportable(self, conjunto):
        if conjunto == "clientes-abonados":
            t = self._tabla_clientes("abonado")
        elif conjunto == "clientes-no-abonados":
            t = self._tabla_clientes("no-abonado")
        elif conjunto == "clientes-todos":
            t = self._tabla_clientes(None)
        elif conjunto == "abonados":
            t = self._tabla_abonados()
        elif conjunto in ("servicios", "productos"):
            t = self._tabla_catalogo(conjunto)
        elif conjunto == "tarifas":
            t = self._tabla_tarifas()
        else:
            raise ErrorNegocio("Listado no válido")
        cfg = self.db.config()
        t.empresa = f"{cfg.get('nombre_parking', '')} · {cfg.get('razon_social', '')}"
        t.subtitulo = self.ahora().strftime("%d/%m/%Y %H:%M")
        return t

    def tabla_plantilla(self, que):
        """Archivo de ejemplo para rellenar e importar."""
        if que == "clientes":
            cols = [(c, a) for c, a in COLS_CLIENTES]
            filas = [["Lucía Fernández Ruiz", "12345678Z", "600111222", "lucia@ejemplo.com", "Calle Mayor 1, Madrid", "1234BCD", "Seat",
                      "Ibiza", "abonado", ""],
                     ["Talleres Ruiz S.L.", "B87654321", "910000000", "admin@ejemplo.com", "Calle del Taller 12", "", "", "",
                      "facturacion", "Factura mensual"]]
            return tablas.Tabla("Plantilla de clientes", cols, filas, hoja="Clientes")
        if que in ("servicios", "productos"):
            tipo = "servicio" if que == "servicios" else "producto"
            ej = ["Lavado básico", "servicio", 12.5, 21, "Sí", 0, "Lavado exterior", 1] if tipo == "servicio" else \
                 ["Ambientador", "producto", 2.9, 21, "Sí", 0, "", 1]
            return tablas.Tabla("Plantilla de " + que, COLS_CATALOGO, [ej], hoja=que.capitalize())
        raise ErrorNegocio("Plantilla no válida")

    # ------------------------------------------------------------------ importar servicios y productos desde una tabla
    def config_desde_tabla(self, filas, tipo_defecto="servicio"):
        """filas: lista de listas (la primera, con los títulos). Devuelve (datos con el formato de exportar_config, avisos)."""
        cab = [_norm_txt(c) for c in filas[0]]

        def col(*claves):
            for i, c in enumerate(cab):
                if any(c.startswith(k) for k in claves):
                    return i
            return None
        ic = {"nombre": col("nombre", "servicio", "producto", "articulo", "descripcion corta"), "tipo": col("tipo"),
              "precio": col("precio", "importe", "pvp"), "iva": col("iva"), "activo": col("activo", "estado"),
              "min": col("parking incluido", "minutos"), "desc": col("descripcion", "detalle", "notas"), "orden": col("orden")}
        if ic["nombre"] is None or ic["precio"] is None:
            raise ErrorNegocio("No encuentro las columnas «Nombre» y «Precio». Descargue la plantilla y use sus títulos.")
        if ic["desc"] == ic["nombre"]:
            ic["desc"] = None
        avisos, productos, vistos = [], [], set()

        def celda(f, k):
            i = ic[k]
            return f[i].strip() if i is not None and i < len(f) and f[i] is not None else ""
        for n, f in enumerate(filas[1:], start=2):
            nombre = celda(f, "nombre")
            if not nombre:
                continue
            if nombre.lower() in vistos:
                avisos.append(f"Fila {n}: «{nombre}» está repetido; se usa la primera")
                continue
            precio = numero(celda(f, "precio"))
            if precio is None or precio < 0:
                avisos.append(f"Fila {n}: «{nombre}» no tiene un precio válido; se salta")
                continue
            t = _norm_txt(celda(f, "tipo"))
            tipo = "producto" if t.startswith("prod") or t.startswith("art") else "servicio" if t.startswith("serv") else tipo_defecto
            iva = numero(celda(f, "iva"))
            act = _norm_txt(celda(f, "activo"))
            vistos.add(nombre.lower())
            productos.append({"nombre": nombre, "tipo": tipo, "precio_cent": int(round(precio * 100)),
                              "iva_pct": iva if iva is not None else None,
                              "activo": 0 if act in ("no", "0", "inactivo", "false", "n") else 1,
                              "orden": int(numero(celda(f, "orden")) or 0),
                              "minutos_incluidos": int(numero(celda(f, "min")) or 0),
                              "descripcion": celda(f, "desc")})
        if not productos:
            raise ErrorNegocio("El archivo no tiene ninguna fila válida")
        for x in productos:
            self._validar_producto(x)   # falla con un mensaje claro si algún dato no vale
        return {"formato": self.FORMATO_CONFIG, "version_formato": 1, "software": "Importado desde tabla", "tarifas": [],
                "productos": productos}, avisos

    # ------------------------------------------------------------------ borrar clientes
    _SQL_PROTEGIDOS = {
        "bono": "EXISTS (SELECT 1 FROM bonos b WHERE b.cliente_id=c.id)",
        "suscripcion": "EXISTS (SELECT 1 FROM suscripciones s WHERE s.cliente_id=c.id)",
        "dentro": "EXISTS (SELECT 1 FROM tickets t WHERE t.cliente_id=c.id AND t.estado IN ('dentro','pagado'))",
    }

    def _donde_ambito(self, ambito):
        if ambito not in ("no_abonados", "todos"):
            raise ErrorNegocio("Elija qué clientes borrar")
        return "" if ambito == "todos" else " AND COALESCE(c.tipo,'facturacion') <> 'abonado'"

    def resumen_borrar_clientes(self, ambito):
        base = f"FROM clientes c WHERE 1=1{self._donde_ambito(ambito)}"
        total = self.db.q1(f"SELECT COUNT(*) n {base}")["n"]
        borr = self.db.q(f"SELECT c.id, c.nombre {base} AND NOT {self._SQL_PROTEGIDOS['bono']} AND NOT {self._SQL_PROTEGIDOS['suscripcion']} "
                         f"AND NOT {self._SQL_PROTEGIDOS['dentro']} ORDER BY c.nombre COLLATE NOCASE")
        motivos = {k: self.db.q1(f"SELECT COUNT(*) n {base} AND {v}")["n"] for k, v in self._SQL_PROTEGIDOS.items()}
        return {"ambito": ambito, "total": total, "borrables": len(borr), "se_quedan": total - len(borr), "motivos": motivos,
                "ejemplos": [b["nombre"] for b in borr[:8]]}

    def borrar_clientes(self, actor_id, ambito, confirmacion):
        """Borra los clientes del ámbito que no tengan bono, suscripción ni vehículo dentro. Las facturas emitidas no cambian
        (guardan su copia del nombre, NIF y dirección) y los tickets conservan todo menos el enlace al cliente."""
        if (confirmacion or "").strip().upper() != "BORRAR":
            raise ErrorNegocio("Escriba BORRAR para confirmar")
        donde = self._donde_ambito(ambito)
        sql = (f"SELECT c.id FROM clientes c WHERE 1=1{donde} AND NOT {self._SQL_PROTEGIDOS['bono']} "
               f"AND NOT {self._SQL_PROTEGIDOS['suscripcion']} AND NOT {self._SQL_PROTEGIDOS['dentro']}")
        with self.db.transaccion() as c:
            ids = [r[0] for r in c.execute(sql).fetchall()]
            for i in range(0, len(ids), 500):
                lote = ids[i:i + 500]
                m = ",".join("?" * len(lote))
                c.execute(f"UPDATE facturas_destinatario SET cliente_id=NULL WHERE cliente_id IN ({m})", lote)
                c.execute(f"UPDATE tickets SET cliente_id=NULL WHERE cliente_id IN ({m})", lote)
                c.execute(f"UPDATE avisos SET cliente_id=NULL WHERE cliente_id IN ({m})", lote)
                c.execute(f"DELETE FROM vehiculo_fotos WHERE cliente_id IN ({m})", lote)
                c.execute(f"DELETE FROM cliente_matriculas WHERE cliente_id IN ({m})", lote)
                c.execute(f"DELETE FROM clientes WHERE id IN ({m})", lote)
            self.auditar(c, actor_id, "clientes_borrar", f"{ambito}: {len(ids)} cliente(s)")
        return {"borrados": len(ids)}
