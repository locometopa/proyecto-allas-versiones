@echo off
title PROYECTO ALLAS - web de pruebas de reservas
cd /d "%~dp0.."
REM Web local para probar las reservas de clientes. Arranque antes PROYECTO ALLAS (ARRANCAR.bat) y active las reservas en Ajustes.
set "PY="
if exist "%~dp0..\python\python.exe" set "PY="%~dp0..\python\python.exe""
if not defined PY where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo  ERROR: no se encuentra Python en este ordenador.
  pause
  exit /b 1
)
%PY% "%~dp0web_pruebas.py" --abrir %*
pause
