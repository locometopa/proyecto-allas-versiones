@echo off
REM Crea en el escritorio un acceso directo "PROYECTO ALLAS" con el icono de la A azul.
cd /d "%~dp0.."
set "DESTINO=%CD%\ARRANCAR.bat"
set "ICONO=%CD%\scripts\proyecto_allas.ico"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop') + '\PROYECTO ALLAS.lnk'); $s.TargetPath='%DESTINO%'; $s.WorkingDirectory='%CD%'; $s.IconLocation='%ICONO%'; $s.WindowStyle=7; $s.Save()"
if errorlevel 1 (
  echo No se pudo crear el acceso directo.
) else (
  echo Acceso directo "PROYECTO ALLAS" creado en el escritorio.
)
pause
