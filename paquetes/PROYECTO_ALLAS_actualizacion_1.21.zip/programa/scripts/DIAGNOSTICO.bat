@echo off
REM Ventana de diagnostico: se abre sola si el programa no arranca (la lanza arranque_progreso.ps1).
title PROYECTO ALLAS - diagnostico del arranque
cd /d "%~dp0.."
echo.
echo  ==========================================================
echo    PROYECTO ALLAS no ha podido arrancar
echo  ==========================================================
if exist "datos\motivo_arranque.txt" type "datos\motivo_arranque.txt"
echo.
if exist "datos\servidor.log" (
  echo  --- Ultimas lineas de datos\servidor.log ---
  powershell -NoProfile -Command "Get-Content 'datos\servidor.log' -Tail 25"
  echo  ---------------------------------------------
  echo.
)
echo  Ahora se arranca el servidor en esta ventana para ver el error.
echo  (Si arranca bien, dejela abierta o minimizada; para detenerlo, cierrela.)
echo.
set "PY="
if exist "python\python.exe" set "PY="python\python.exe""
if not defined PY py -3 --version >nul 2>nul && set "PY=py -3"
if not defined PY python --version >nul 2>nul && set "PY=python"
if not defined PY (
  echo  ERROR: no se encuentra Python. Instale Python 3.11 o superior de python.org
  echo  marcando "Add python.exe to PATH".
  exit /b 1
)
%PY% run.py --abrir
echo.
echo  El servidor se ha detenido. Copie el mensaje de arriba si necesita ayuda.
