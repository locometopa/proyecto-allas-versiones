#!/usr/bin/env python3
"""Web local de pruebas para las reservas de clientes, por línea de comandos (PROYECTO ALLAS).

Lo normal es activarla desde el programa: Ajustes → Reservas online → Probar en local. Este script hace lo mismo sin
tocar el programa, con el programa ya en marcha:

    python scripts/web_pruebas.py                  # http://127.0.0.1:8090  (busca solo el programa en marcha)
    python scripts/web_pruebas.py --abrir          # además abre el navegador
    python scripts/web_pruebas.py --programa http://127.0.0.1:8080 --puerto 8090
    python scripts/web_pruebas.py --host 0.0.0.0   # para probar desde el móvil (misma red Wi-Fi)
"""
import argparse
import os
import sys
import urllib.error
import urllib.request
import webbrowser
from http.server import ThreadingHTTPServer

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
from app.web_pruebas import PREFIJO, buscar_programa as _buscar, carpeta_kit, crear_handler as _crear  # noqa: E402

WEB = carpeta_kit(RAIZ)


def buscar_programa():
    return _buscar(RAIZ)


def crear_handler(programa):
    return _crear(programa, WEB)


def main():
    ap = argparse.ArgumentParser(description="Web local de pruebas para las reservas de clientes")
    ap.add_argument("--programa", help="dirección del programa (por defecto lo busca solo)")
    ap.add_argument("--puerto", type=int, default=8090)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--abrir", action="store_true")
    a = ap.parse_args()
    if not os.path.isdir(WEB):
        sys.exit("No se encuentra la carpeta integracion_web.")
    programa = (a.programa or buscar_programa() or "").rstrip("/")
    if not programa:
        sys.exit("No encuentro el programa en marcha. Arranque PROYECTO ALLAS primero (o use --programa http://127.0.0.1:8080).")
    try:
        srv = ThreadingHTTPServer((a.host, a.puerto), crear_handler(programa))
    except OSError as e:
        sys.exit(f"No se puede abrir el puerto {a.puerto}: {e}. Pruebe con --puerto 8091.")
    url = f"http://{'127.0.0.1' if a.host in ('0.0.0.0', '') else a.host}:{a.puerto}/"
    print(f"\n  Web de pruebas de reservas: {url}\n  Programa: {programa}\n  (Ctrl+C para cerrar)\n")
    try:
        with urllib.request.urlopen(programa + PREFIJO + "/config", timeout=3):
            pass
    except urllib.error.HTTPError as e:
        print("  AVISO: el programa responde", e.code, "- active las reservas en Ajustes → Reservas online "
              "(«Activar las reservas online» y «Aceptar reservas desde la web») y cree al menos una zona con cupo.\n")
    except OSError:
        pass
    if a.abrir:
        webbrowser.open(url)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n  Cerrado.")


if __name__ == "__main__":
    main()
