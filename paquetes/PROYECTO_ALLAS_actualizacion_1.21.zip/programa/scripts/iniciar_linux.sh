#!/bin/sh
# Abre la caja en modo quiosco. Si el servidor no corre como servicio, lo arranca.
# El puerto lo elige el programa al instalarse (el 8080 si está libre) y lo deja en datos/puerto.txt.
DIR="$(cd "$(dirname "$0")/.." && pwd)"
puerto() { cat "$DIR/datos/puerto.txt" 2>/dev/null || echo 8080; }
if ! curl -s "http://127.0.0.1:$(puerto)/api/estado" >/dev/null 2>&1; then
  rm -f "$DIR/datos/puerto.txt"
  (cd "$DIR" && nohup python3 run.py >/dev/null 2>&1 &)
  for i in $(seq 1 15); do
    [ -f "$DIR/datos/puerto.txt" ] && curl -s "http://127.0.0.1:$(puerto)/api/estado" >/dev/null 2>&1 && break
    sleep 1
  done
fi
URL="http://127.0.0.1:$(puerto)"
for nav in chromium chromium-browser google-chrome firefox; do
  if command -v "$nav" >/dev/null 2>&1; then
    exec "$nav" --kiosk "$URL"
  fi
done
echo "No se encontró navegador. Abra $URL"
