# PROYECTO ALLAS - arranque con pantalla de carga.
# Lo lanza ARRANCAR.bat. Arranca el servidor SIN ventana de comandos y abre al momento la pantalla de carga (web\cargando.html,
# con el mismo diseno que el programa); esa pantalla salta sola a la aplicacion cuando el servidor responde.
# Si hay un error o el servidor se para / no responde, cierra la pantalla de carga y abre una ventana de comandos con el diagnostico.
param(
  [Parameter(Mandatory=$true)][string]$Raiz,
  [Parameter(Mandatory=$true)][string]$Exe,        # python o pythonw (ruta o comando, p. ej. "pyw")
  [string]$ArgsExe = "",                           # argumentos previos a run.py (p. ej. "-3")
  [string]$Modo = "",                              # "quiosco" para pantalla completa
  [int]$Limite = 60                                # segundos maximos de espera
)
Set-Location $Raiz
$datos = Join-Path $Raiz "datos"
$puertoTxt = Join-Path $datos "puerto.txt"
$cargando = Join-Path $Raiz "web\cargando.html"

function Responde($puerto) {
  try {
    $r = Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:$puerto/api/estado" -TimeoutSec 2
    return ($r.Content -match 'primer_arranque')
  } catch { return $false }
}
function PuertoActual() {
  try { return [int]((Get-Content $puertoTxt -ErrorAction Stop | Select-Object -First 1).Trim()) } catch { return 0 }
}
function AbrirNavegador($url) {
  if ($Modo -eq "quiosco") { Start-Process "msedge" -ArgumentList "--kiosk `"$url`" --edge-kiosk-type=fullscreen --no-first-run" -ErrorAction SilentlyContinue; return }
  try { Start-Process "msedge" -ArgumentList "--app=`"$url`" --start-maximized --no-first-run" -ErrorAction Stop } catch { Start-Process $url }
}

# --- arrancar el servidor (sin ventana) ---
if (Test-Path $puertoTxt) { Remove-Item $puertoTxt -Force -ErrorAction SilentlyContinue }
$lista = @(); if ($ArgsExe) { $lista += $ArgsExe.Split(" ") }; $lista += "run.py"
$proc = $null; $motivo = ""
try {
  $proc = Start-Process -FilePath $Exe -ArgumentList $lista -WorkingDirectory $Raiz -WindowStyle Hidden -PassThru -ErrorAction Stop
} catch {
  $proc = $null; $motivo = "No se pudo iniciar Python: $($_.Exception.Message)"
}

# --- pantalla de carga: se abre ya, sin esperar al servidor ---
$pref = ""
try { $pref = (Get-Content (Join-Path $datos "puerto_preferido.txt") -ErrorAction Stop | Select-Object -First 1).Trim() } catch {}
$abiertaCarga = $false
if ($proc -and (Test-Path $cargando)) {
  $urlCarga = ([System.Uri]$cargando).AbsoluteUri
  if ($pref -match '^\d+$') { $urlCarga += "?p=$pref" }
  AbrirNavegador $urlCarga
  $abiertaCarga = $true
}

$inicio = Get-Date
$ok = $false; $puerto = 0
if ($proc) {
  while (((Get-Date) - $inicio).TotalSeconds -lt $Limite) {
    $puerto = PuertoActual
    if ($puerto -gt 0 -and (Responde $puerto)) { $ok = $true; break }
    if ($proc.HasExited) {
      # run.py termina enseguida si el parking ya estaba en marcha: comprobarlo antes de dar error
      Start-Sleep -Milliseconds 800
      $puerto = PuertoActual
      if ($puerto -gt 0 -and (Responde $puerto)) { $ok = $true }
      else { $motivo = "El servidor se ha cerrado al arrancar (codigo $($proc.ExitCode))." }
      break
    }
    Start-Sleep -Milliseconds 300
  }
  if (-not $ok -and -not $motivo) { $motivo = "El servidor no ha respondido en $Limite segundos." }
}

if ($ok) {
  # la pantalla de carga salta sola a la aplicacion; si no estaba abierta (o el puerto es raro), se abre directamente
  $habituales = @(8080, 8090, 8765, 18080, 28080, 38080, 47080)
  if (-not $abiertaCarga -or ($habituales -notcontains $puerto -and "$puerto" -ne $pref)) { AbrirNavegador "http://127.0.0.1:$puerto" }
  exit 0
}

# --- error: parar lo que haya quedado colgado, cerrar la pantalla de carga y abrir una ventana de comandos con el diagnostico ---
if ($proc -and -not $proc.HasExited) { try { & taskkill /F /T /PID $proc.Id 2>&1 | Out-Null } catch {} }
try { Get-Process msedge -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle -like "PROYECTO ALLAS*" } | ForEach-Object { [void]$_.CloseMainWindow() } } catch {}
try { Set-Content -Path (Join-Path $datos "motivo_arranque.txt") -Value $motivo -Encoding ASCII } catch {}
$diag = Join-Path $Raiz "scripts\DIAGNOSTICO.bat"
Start-Process -FilePath "cmd.exe" -ArgumentList "/k", "`"$diag`""
exit 1
