# Reservas en la web del aparcamiento

Esta carpeta es la página de reservas para clientes, lista para subir a **cualquier alojamiento web** (o a un servidor propio). El programa PROYECTO ALLAS ya no la sirve por sí mismo: la web del aparcamiento habla con él a través de la API pública `/api/publico/reservas/*`.

## Qué hay

- `reservas.html` y `reservas.js`: la página (móvil y escritorio). No necesita nada más, ni librerías ni servidor propio.
- En `reservas.html`, la línea `window.ALLAS_API = window.ALLAS_API || "";` es la **dirección del programa** visible desde Internet (por ejemplo `https://reservas.mi-parking.es`). El botón **Descargar kit para la web** de Ajustes → Reservas online la rellena sola con la dirección que hayas guardado.

## Pasos para publicarla

1. En el programa: Ajustes → Reservas online → **Reservas desde la web del aparcamiento**.
   - Activa las reservas desde la web.
   - Escribe la **dirección del programa** (la de la API) y la **página de reservas de tu web** (la que usará el enlace del email).
   - En **Webs autorizadas** pon el dominio de tu web (`https://www.mi-parking.es`). Sin esto el navegador bloquea las peticiones.
   - Marca **Aceptar peticiones desde Internet** solo cuando el programa esté publicado con HTTPS.
2. Pulsa **Descargar kit para la web**, descomprime y sube `reservas.html` y `reservas.js` a tu web (o copia su contenido dentro de una página de tu gestor de contenidos).
3. Prueba una reserva y comprueba que llega el email.

## Requisitos para abrirlo a Internet

- El programa tiene que ser alcanzable desde fuera: un proxy inverso (nginx, Caddy…) o un túnel, siempre con **HTTPS**. No abras el puerto del programa directamente.
- Si hay un proxy delante, anota su IP en **Proxy de confianza** para que el límite de peticiones se aplique a cada cliente y no al proxy.
- Solo se exponen `/api/publico/reservas/*`; el resto del programa sigue sin servirse desde Internet.
- Las reservas pasan por el límite de peticiones por IP, el campo trampa anti-robots y los cupos de cada zona.

Ejemplo de proxy con nginx (solo la API de reservas):

```
location /api/publico/reservas { proxy_pass http://IP_DEL_PARKING:8080; proxy_set_header X-Forwarded-For $remote_addr; }
```

## Alternativa sin abrir el PC del parking: servidor en la nube

Si no quiere exponer el programa a Internet, use `scripts/servidor_reservas/` (o el botón **Descargar el servidor (zip)** de Ajustes → Reservas online → Web de clientes): un servidor pequeño en Internet sirve esta misma página y el programa del parking le pregunta por las reservas (conexión saliente). Mire el `LEEME.md` de esa carpeta. En ese caso `ALLAS_API` se deja vacío (la página llama al mismo servidor).
