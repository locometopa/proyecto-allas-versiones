/* PROYECTO ALLAS · página de reservas para incrustar en la web del aparcamiento (móvil y escritorio).
   Habla solo con {ALLAS_API}/api/publico/reservas/*. Se sube a cualquier alojamiento web junto a reservas.html. */
"use strict";
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const eur = (c) => (c / 100).toLocaleString("es-ES", { style: "currency", currency: "EUR" });
const cuando = (iso) => new Date(iso).toLocaleString("es-ES", { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
const duracion = (m) => { const d = Math.floor(m / 1440), h = Math.floor((m % 1440) / 60), n = m % 60; return [d ? `${d} d` : "", h ? `${h} h` : "", !d && n ? `${n} min` : ""].filter(Boolean).join(" ") || "0 min"; };

const BASE_API = String(window.ALLAS_API || "").replace(/\/+$/, "");
async function api(metodo, ruta, cuerpo) {
  const r = await fetch(BASE_API + ruta, { method: metodo, headers: { "Content-Type": "application/json" }, body: cuerpo ? JSON.stringify(cuerpo) : undefined });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || "No disponible ahora mismo");
  return d;
}

let cfg = null;
const f = { zona_id: null, tipo_vehiculo: "", desde: "", hasta: "", matricula: "", nombre: "", email: "", telefono: "" };
let disponible = false, token = 0, ultimo = null;   // ultimo: última consulta de disponibilidad y precio

function aLocal(d) { const x = new Date(d.getTime() - d.getTimezoneOffset() * 60000); return x.toISOString().slice(0, 16); }

async function iniciar() {
  try { cfg = await api("GET", "/api/publico/reservas/config"); }
  catch (e) { $("#cargando").textContent = e.message; $("#cargando").className = "error"; return; }
  $("#nombre").textContent = cfg.parking; document.title = `Reservar plaza · ${cfg.parking}`;
  $("#cargando").hidden = true;
  $("#mi-reserva").hidden = false; $("#mi-reserva").onclick = () => pantallaBuscar();
  $("#pie-pag").textContent = `${cfg.parking} · Reserve ahora y pague al llegar al parking.`;
  const ahora = new Date(Date.now() + (cfg.antelacion_min_min + 60) * 60000); ahora.setMinutes(0, 0, 0);
  f.desde = aLocal(ahora); f.hasta = aLocal(new Date(ahora.getTime() + 24 * 3600000));
  f.zona_id = cfg.zonas.length ? cfg.zonas[0].id : null;
  const qs = new URLSearchParams(location.search), c = qs.get("c");
  if (c) {   // al volver del pago con tarjeta: se abre la reserva sola (la matrícula se guardó antes de salir)
    let mat = ""; try { mat = sessionStorage.getItem("allas_mat_" + c) || ""; } catch (e) { mat = ""; }
    if (mat && qs.get("pago")) {
      try {
        const v = qs.get("pago") === "ok" ? (await api("POST", "/api/publico/reservas/pago-confirmar", { codigo: c, matricula: mat })).reserva
          : await api("POST", "/api/publico/reservas/ver", { codigo: c, matricula: mat });
        return pantallaReserva(v, false, qs.get("pago") === "cancelado" ? "No se ha completado el pago. Puede intentarlo de nuevo cuando quiera." : v.pago === "pagada" ? "" : "Estamos comprobando su pago: en unos segundos la reserva aparecerá como pagada.");
      } catch (e) { /* si algo falla, pantalla normal de búsqueda */ }
    }
    return pantallaBuscar(c);
  }
  pantallaFechas();
}

function opciones(id, lista, actual) {
  return `<div class="opciones" id="${id}" role="group">${lista.map(([v, n]) => `<button type="button" data-v="${esc(v)}" aria-pressed="${String(v) === String(actual)}">${esc(n)}</button>`).join("")}</div>`;
}
function enlazar(id, fn) {
  $("#" + id).onclick = (e) => { const b = e.target.closest("button[data-v]"); if (!b) return; fn(b.dataset.v); $$btn(id, b); };
}
function $$btn(id, sel) { document.querySelectorAll(`#${id} button`).forEach((x) => x.setAttribute("aria-pressed", String(x === sel))); }

const PASOS = ["Fechas", "Sus datos", "Confirmación"];
function pasos(n) {
  const p = $("#pasos");
  p.hidden = !n;
  p.innerHTML = n ? PASOS.map((t, i) => `<li class="${i + 1 < n ? "hecho" : i + 1 === n ? "actual" : ""}" ${i + 1 === n ? 'aria-current="step"' : ""}><b>${i + 1 < n ? "✓" : i + 1}</b><span>${t}</span></li>`).join("") : "";
}

// Resumen de lo elegido (columna derecha en escritorio, bajo el formulario en el móvil)
function lineasResumen() {
  const z = cfg.zonas.find((x) => x.id === f.zona_id);
  const ok = f.desde && f.hasta;
  return `<dl><dt>Entrada</dt><dd>${ok ? esc(cuando(f.desde)) : ""}</dd><dt>Salida</dt><dd>${ok ? esc(cuando(f.hasta)) : ""}</dd>
    ${z ? `<dt>Zona</dt><dd>${esc(z.nombre)}</dd>` : ""}${f.tipo_vehiculo ? `<dt>Vehículo</dt><dd>${esc(f.tipo_vehiculo)}</dd>` : ""}
    <dt>Matrícula</dt><dd>${esc(f.matricula.toUpperCase())}</dd></dl>`;
}
function pintarLineas() { const d = $("#res-lineas"); if (d) d.innerHTML = lineasResumen(); }

function pantallaFechas(error = "") {
  pasos(1);
  const h = cfg.horario ? `<details><summary>Horario del parking</summary><p class="horario">${cfg.horario.map((d) => `<b>${esc(d.dia.slice(0, 3))}</b> ${esc(d.texto)}`).join(" · ")}</p></details>` : "";
  $("#vista").innerHTML = `<div class="intro"><h1>Reserve su plaza</h1><p class="sub">Elija fechas y vehículo. Pague al llegar y entre sin esperas.</p></div>
    <div class="cols"><div class="panel col-form">${error ? `<p class="error" role="alert">${esc(error)}</p>` : ""}
      <div class="dos"><label>Entrada<input type="datetime-local" id="desde" value="${esc(f.desde)}"></label>
        <label>Salida<input type="datetime-local" id="hasta" value="${esc(f.hasta)}"></label></div>
      ${cfg.zonas.length ? `<div class="titulo-campo">Zona</div>${opciones("zonas", cfg.zonas.map((z) => [z.id, z.nombre]), f.zona_id)}` : ""}
      ${cfg.tipos.length ? `<div class="titulo-campo">Vehículo</div>${opciones("tipos", cfg.tipos.map((t) => [t, t]), f.tipo_vehiculo)}` : ""}
      <label>Matrícula<input class="mat" id="mat" value="${esc(f.matricula)}" maxlength="12" autocomplete="off" autocapitalize="characters" inputmode="text"></label>
      ${cfg.min_minutos ? `<p class="pie" style="text-align:left">Reserva mínima: ${esc(duracion(cfg.min_minutos))}.</p>` : ""}
      ${h}</div>
    <aside class="panel col-resumen" aria-label="Resumen de su reserva"><h2>Su reserva</h2><div id="res-lineas">${lineasResumen()}</div>
      <div class="resumen" id="resumen" aria-live="polite">Elija las fechas para ver la disponibilidad y el precio.</div>
      <button class="btn" id="seguir" disabled>Continuar</button>
      <button class="btn sec" id="buscar">Ya tengo una reserva</button>
      <p class="pie">Cancelación gratuita hasta ${cfg.cancelar_horas} horas antes de la entrada.</p></aside></div>`;
  if (cfg.zonas.length) enlazar("zonas", (v) => { f.zona_id = Number(v); pintarLineas(); consultar(); });
  if (cfg.tipos.length) enlazar("tipos", (v) => { f.tipo_vehiculo = v; pintarLineas(); consultar(); });
  $("#desde").onchange = () => { f.desde = $("#desde").value; pintarLineas(); consultar(); };
  $("#hasta").onchange = () => { f.hasta = $("#hasta").value; pintarLineas(); consultar(); };
  $("#mat").oninput = () => { f.matricula = $("#mat").value; pintarLineas(); validar(); };
  $("#seguir").onclick = pantallaDatos;
  $("#buscar").onclick = () => pantallaBuscar();
  consultar();
}

function validar() { const b = $("#seguir"); if (b) b.disabled = !(disponible && f.matricula.replace(/\W/g, "").length >= 3); }

function textoResumen(r) {
  return r.estado === "completo" ? "No quedan plazas en esas fechas. Pruebe con otras." :
    `${r.estado === "pocas" ? "Quedan pocas plazas · " : "Plaza disponible · "}${esc(duracion(r.minutos))}<span class="total">${esc(eur(r.importe_cent))}</span>
       <small>${r.senal_cent ? (r.senal_cent >= r.importe_cent ? `a pagar por adelantado para mantener la reserva` : `señal a pagar ahora: ${esc(eur(r.senal_cent))} · el resto, ${esc(eur(r.importe_cent - r.senal_cent))}, en el parking`) : "a pagar en el parking (tarifa vigente)"}</small>`;
}

async function consultar() {
  const res = $("#resumen"), mi = ++token;
  disponible = false; ultimo = null; validar();
  if (!f.desde || !f.hasta) return;
  try {
    const r = await api("POST", "/api/publico/reservas/consulta", { zona_id: f.zona_id, tipo_vehiculo: f.tipo_vehiculo, desde: f.desde, hasta: f.hasta });
    if (mi !== token || !res.isConnected) return;
    ultimo = r; disponible = r.estado !== "completo";
    res.className = "resumen" + (r.estado === "pocas" ? " pocas" : r.estado === "completo" ? " mal" : "");
    res.innerHTML = textoResumen(r);
  } catch (e) { if (mi === token && res.isConnected) { res.className = "resumen mal"; res.textContent = e.message; } }
  validar();
}

function pantallaDatos(error = "") {
  pasos(2);
  $("#vista").innerHTML = `<div class="intro"><h1>Sus datos</h1><p class="sub">Le enviaremos la confirmación por email.</p></div>
    <div class="cols"><form class="panel col-form" id="datos" novalidate>${typeof error === "string" && error ? `<p class="error" role="alert">${esc(error)}</p>` : ""}
      <label>Nombre y apellidos<input id="nombre-cli" value="${esc(f.nombre)}" autocomplete="name" maxlength="80" required></label>
      <div class="dos"><label>Email<input id="email" type="email" value="${esc(f.email)}" autocomplete="email" maxlength="120" required></label>
        <label>Teléfono (opcional)<input id="tel" type="tel" value="${esc(f.telefono)}" autocomplete="tel" maxlength="30"></label></div>
      <div class="trampa" aria-hidden="true"><label>No rellenar<input id="web" tabindex="-1" autocomplete="off"></label></div>
      <details><summary>Condiciones de la reserva</summary><p>${esc(cfg.condiciones)}</p></details>
      <label class="marca-cond"><input type="checkbox" id="acepta"> <span>He leído y acepto las condiciones de la reserva.</span></label>
      <button class="btn" id="reservar">Reservar</button>
      <button class="btn sec" type="button" id="atras">Cambiar fechas</button></form>
    <aside class="panel col-resumen" aria-label="Resumen de su reserva"><h2>Su reserva</h2>${lineasResumen()}
      ${ultimo ? `<div class="resumen">${textoResumen(ultimo)}</div>` : ""}</aside></div>`;
  $("#atras").onclick = () => pantallaFechas();
  $("#datos").onsubmit = async (e) => {
    e.preventDefault();
    f.nombre = $("#nombre-cli").value; f.email = $("#email").value; f.telefono = $("#tel").value;
    if (f.nombre.trim().length < 2) return pantallaDatos("Indique su nombre");
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.email.trim())) return pantallaDatos("Indique un email válido: allí le enviamos la confirmación");
    if (!$("#acepta").checked) return pantallaDatos("Debe aceptar las condiciones de la reserva");
    const b = $("#reservar"); b.disabled = true; b.textContent = "Reservando…";
    try {
      const r = await api("POST", "/api/publico/reservas", { ...f, acepta: $("#acepta").checked, web: $("#web").value });
      pantallaReserva(r, true);
    } catch (err) { pantallaDatos(err.message); }
  };
}

function pantallaReserva(r, nueva = false, error = "") {
  pasos(nueva ? 3 : 0);
  const cancelada = r.estado === "cancelada";   // (r.no_presentada: no llegó a tiempo y se liberó la plaza)
  const sinPagar = r.pago === "pendiente_pago" && r.estado === "pendiente", conSenal = r.senal_cent > 0;
  const mail = r.email_estado === "sin_correo" ? "Este parking no envía emails: guarde su código." : r.email_estado === "error" ? "No hemos podido enviar el email: guarde su código."
    : r.email_estado === "enviado" ? `Le hemos enviado la confirmación a ${esc(r.email)}.` : r.email ? `Le enviaremos la confirmación a ${esc(r.email)}.` : "";
  const aPagar = sinPagar ? `<div class="aviso-pago"><b>Falta pagar ${esc(eur(r.senal_cent))}${r.senal_cent >= r.importe_cent ? "" : " de señal"}</b>${r.pago_limite ? ` antes del ${esc(cuando(r.pago_limite))}` : ""}.
      Si no se paga a tiempo, la reserva se cancela sola.${r.pago_instrucciones ? `<br><span>${esc(r.pago_instrucciones)}</span>` : ""}</div>` : "";
  const lateral = cancelada ? `<p>Esta reserva está cancelada y la plaza ha quedado libre.${r.pago === "a_devolver" ? " El parking le devolverá la señal que pagó." : r.pago === "devuelta" ? " La señal se ha devuelto a su tarjeta (puede tardar unos días en verla)." : r.no_presentada ? " No se presentó a tiempo; la señal no se devuelve." : ""}</p>` : `<h2>Qué hacer ahora</h2>${aPagar}
      <ol class="pasos-llegada">${sinPagar ? `<li><div><b>Pague ${r.senal_cent >= r.importe_cent ? "la reserva" : "la señal"}</b><small>Indique el código ${esc(r.codigo)} al pagar.</small></div></li>` : ""}<li><div><b>Guarde su código</b><small>${nueva && mail ? mail : "Es el código de arriba. También sirve el QR."}</small></div></li>
        <li><div><b>A su llegada</b><small>Dé su matrícula o enseñe el código al personal del parking.</small></div></li>
        <li><div><b>Pague al salir</b><small>${conSenal ? (r.senal_cent >= r.importe_cent ? "Ya estará pagado." : `Solo el resto: ${esc(eur(Math.max(0, r.importe_cent - r.senal_cent)))}.`) : "Se cobra la tarifa vigente en el parking."}</small></div></li></ol>`;
  $("#vista").innerHTML = `<div class="cols"><div class="panel col-form">${error ? `<p class="error" role="alert">${esc(error)}</p>` : ""}
      <span class="ok ${cancelada ? "cancelada" : sinPagar ? "pendiente" : ""}">${cancelada ? "Reserva cancelada" : r.estado === "usada" ? "Reserva utilizada" : sinPagar ? "Pendiente de pago" : nueva ? "Reserva confirmada" : "Reserva"}</span>
      ${cancelada ? "" : `<div class="qr">${r.qr}<span class="codigo">${esc(r.codigo)}</span><span class="pie">A la llegada, dé su matrícula o enseñe este código.</span></div>`}
      <dl><dt>Matrícula</dt><dd>${esc(r.matricula)}</dd><dt>Entrada</dt><dd>${esc(cuando(r.desde))}</dd><dt>Salida</dt><dd>${esc(cuando(r.hasta))}</dd>
        ${r.zona ? `<dt>Zona</dt><dd>${esc(r.zona)}</dd>` : ""}${conSenal ? `<dt>Importe</dt><dd>${esc(eur(r.importe_cent))}</dd><dt>Señal</dt><dd>${esc(eur(r.senal_cent))} ${r.pago === "pagada" ? "· pagada" : sinPagar ? "· sin pagar" : ""}</dd>` : `<dt>A pagar en el parking</dt><dd>${esc(eur(r.importe_cent))}</dd>`}</dl></div>
    <aside class="panel col-resumen">${lateral}
      ${r.puede_pagar_online ? `<button class="btn" id="pagar-ya">Pagar ${esc(eur(r.senal_cent))} con tarjeta</button>` : ""}
      ${r.puede_cancelar ? `<button class="btn sec" id="modificar">Cambiar fechas</button><button class="btn sec" id="cancelar">Cancelar reserva</button>` : r.estado === "pendiente" ? `<p class="pie">El plazo de cancelación gratuita ya terminó. Si no puede venir, avise al parking.</p>` : ""}
      ${cancelada ? "" : `<button class="btn sec" type="button" id="imprimir">Imprimir o guardar</button>`}
      <button class="btn sec" id="otra">Hacer otra reserva</button></aside></div>`;
  $("#otra").onclick = () => pantallaFechas();
  if ($("#imprimir")) $("#imprimir").onclick = () => window.print();
  if ($("#modificar")) $("#modificar").onclick = () => pantallaModificar(r);
  if ($("#pagar-ya")) $("#pagar-ya").onclick = async () => {
    const b = $("#pagar-ya"); b.disabled = true; b.textContent = "Abriendo el pago…";
    try {
      try { sessionStorage.setItem("allas_mat_" + r.codigo, r.matricula); } catch (e) { /* sin almacenamiento: tendrá que escribir la matrícula al volver */ }
      const p = await api("POST", "/api/publico/reservas/pagar", { codigo: r.codigo, matricula: r.matricula });
      if (p.pagada) return pantallaReserva(p.reserva);
      location.href = p.url;
    } catch (e) { pantallaReserva(r, nueva, e.message); }
  };
  if ($("#cancelar")) $("#cancelar").onclick = () => {
    $("#cancelar").outerHTML = `<button class="btn peligro" id="si-cancelar">Sí, cancelar mi reserva</button>`;
    $("#si-cancelar").onclick = async () => {
      try { pantallaReserva(await api("POST", "/api/publico/reservas/cancelar", { codigo: r.codigo, matricula: r.matricula })); }
      catch (e) { pantallaReserva(r, nueva, e.message); }
    };
  };
}

function pantallaModificar(r, error = "") {
  pasos(0);
  $("#vista").innerHTML = `<div class="centrado"><h1>Cambiar fechas</h1><p class="sub">Reserva ${esc(r.codigo)} · ${esc(r.matricula)}. Si hay plazas, se cambia al momento y se recalcula el precio.</p>
    <form class="panel" id="mod-f">${error ? `<p class="error" role="alert">${esc(error)}</p>` : ""}
      <div class="dos"><label>Entrada<input type="datetime-local" id="m-desde" value="${esc(String(r.desde).slice(0, 16))}"></label>
        <label>Salida<input type="datetime-local" id="m-hasta" value="${esc(String(r.hasta).slice(0, 16))}"></label></div>
      <button class="btn">Guardar cambios</button><button class="btn sec" type="button" id="m-atras">Volver sin cambiar</button></form></div>`;
  $("#m-atras").onclick = () => pantallaReserva(r);
  $("#mod-f").onsubmit = async (e) => {
    e.preventDefault();
    try { pantallaReserva(await api("POST", "/api/publico/reservas/modificar", { codigo: r.codigo, matricula: r.matricula, desde: $("#m-desde").value, hasta: $("#m-hasta").value })); }
    catch (err) { pantallaModificar(r, err.message); }
  };
}

function pantallaBuscar(codigo = "", error = "") {
  pasos(0);
  $("#vista").innerHTML = `<div class="centrado"><h1>Mi reserva</h1><p class="sub">Escriba el código que le enviamos y su matrícula.</p>
    <form class="panel" id="buscar-f">${error ? `<p class="error" role="alert">${esc(error)}</p>` : ""}
      <label>Código<input class="mat" id="cod" value="${esc(codigo)}" maxlength="12" autocomplete="off" placeholder="R-ABC234"></label>
      <label>Matrícula<input class="mat" id="mat2" maxlength="12" autocomplete="off"></label>
      <button class="btn">Ver mi reserva</button><button class="btn sec" type="button" id="nueva">Reservar una plaza</button></form></div>`;
  $("#nueva").onclick = () => pantallaFechas();
  $("#buscar-f").onsubmit = async (e) => {
    e.preventDefault();
    try { pantallaReserva(await api("POST", "/api/publico/reservas/ver", { codigo: $("#cod").value, matricula: $("#mat2").value })); }
    catch (err) { pantallaBuscar($("#cod").value, err.message); }
  };
}

iniciar();
