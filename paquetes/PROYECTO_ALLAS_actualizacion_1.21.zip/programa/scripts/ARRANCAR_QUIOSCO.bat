@echo off
REM Igual que ARRANCAR.bat pero a pantalla completa (modo quiosco). Salir con Alt+F4.
call "%~dp0..\ARRANCAR.bat" quiosco
