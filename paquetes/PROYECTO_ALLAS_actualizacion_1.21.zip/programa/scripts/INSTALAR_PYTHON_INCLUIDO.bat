@echo off
REM PROYECTO ALLAS 4.4 - Descarga Python "incluido" (version portable de python.org) en la carpeta "python" del programa.
REM Asi el programa usa siempre ese Python, aunque Windows o otro programa cambien el Python del ordenador.
REM Necesita Internet solo una vez. Ocupa unos 25 MB. Para volver al Python del sistema, borre la carpeta "python".
setlocal
cd /d "%~dp0.."
set "VER=3.12.10"
set "URL=https://www.python.org/ftp/python/%VER%/python-%VER%-embed-amd64.zip"
if not exist "python\python.exe" goto descargar
echo  Ya hay un Python incluido en la carpeta "python":
python\python.exe --version
pause
exit /b 0
:descargar
echo.
echo  Descargando Python %VER% portable de python.org...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing '%URL%' -OutFile 'python_portable.zip'; Expand-Archive -Force 'python_portable.zip' 'python'; Remove-Item 'python_portable.zip'"
if exist "python\python.exe" goto descargado
echo.
echo  ERROR: no se pudo descargar. Compruebe la conexion a Internet y vuelva a intentarlo.
pause
exit /b 1
:descargado
REM la carpeta del programa tambien entra en la ruta de modulos
for %%f in (python\python*._pth) do echo ..>>"%%f"
python\python.exe -c "import sqlite3, ssl, ctypes, sys; print('Python incluido listo:', sys.version.split()[0])"
if not errorlevel 1 goto listo
echo  ERROR: el Python descargado no funciona. Borre la carpeta "python" y vuelva a intentarlo.
pause
exit /b 1
:listo
echo.
echo  Listo. A partir de ahora ARRANCAR.bat usa este Python.
echo  Apague PROYECTO ALLAS (Ajustes - Sistema - Servidor - Apagar) y vuelva a abrir ARRANCAR.bat.
pause
