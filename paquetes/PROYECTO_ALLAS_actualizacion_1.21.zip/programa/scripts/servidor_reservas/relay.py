#!/usr/bin/env python3
"""PROYECTO ALLAS · servidor intermedio de reservas (para poner en Internet, en un servidor o hosting con Python 3.8+).

El PC del parking NO se abre a Internet. Es el programa el que llama a este servidor (conexión saliente):

    cliente (móvil) ──► ESTE SERVIDOR (público) ◄── agente del programa (el PC del parking pregunta cada pocos segundos)

Este servidor hace dos cosas:
  1. sirve la página de reservas (carpeta «web») y recibe las peticiones /api/publico/reservas/* del cliente;
  2. las guarda en una cola; el programa las recoge, las atiende en su base de datos real y devuelve la respuesta.

No guarda datos de clientes ni reservas: solo pasa mensajes. Si el programa está apagado, el cliente ve
«servicio no disponible». Solo usa la biblioteca estándar de Python.

Uso:   ALLAS_RELAY_TOKEN=<clave larga> python3 relay.py --puerto 8080 [--web web] [--confiar-proxy] [--origenes https://www.mi-parking.es]
Ponga delante un proxy con HTTPS (Caddy, nginx, el propio hosting): la clave viaja en cada llamada del programa.
"""
import argparse
import base64
import collections
import hmac
import json
import mimetypes
import os
import re
import secrets
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

PREFIJO = "/api/publico/reservas"
MAX_CUERPO = 20000          # bytes por petición del cliente
MAX_COLA = 200              # peticiones esperando al programa
ESPERA_RESPUESTA = 28       # segundos que espera el cliente a que el programa conteste
AGENTE_VIVO = 45            # el programa cuenta como conectado si preguntó hace menos de esto
LIMITE_IP = (240, 600)      # peticiones por IP y ventana (s): protege al programa del parking
TOKEN_MIN = 24
EXTENSIONES_WEB = {".html", ".js", ".css", ".png", ".svg", ".ico", ".jpg", ".jpeg", ".webp", ".woff2"}   # (los .md y demás no se sirven)


class Trabajo:
    def __init__(self, metodo, ruta, cuerpo, ip, origen):
        self.id = secrets.token_hex(12)
        self.metodo, self.ruta, self.ip, self.origen = metodo, ruta, ip, origen
        self.cuerpo_b64 = base64.b64encode(cuerpo).decode() if cuerpo else ""
        self.evento = threading.Event()
        self.respuesta = None

    def para_agente(self):
        return {"id": self.id, "metodo": self.metodo, "ruta": self.ruta, "cuerpo_b64": self.cuerpo_b64, "ip": self.ip}


class Estado:
    def __init__(self, token, web, origenes=(), confiar_proxy=False):
        if len(token or "") < TOKEN_MIN:
            raise ValueError(f"La clave debe tener al menos {TOKEN_MIN} caracteres")
        self.token, self.web, self.confiar_proxy = token, web, confiar_proxy
        self.origenes = [o.strip().rstrip("/").lower() for o in origenes if o.strip()]
        self.cola, self.trabajos = collections.deque(), {}
        self.cond = threading.Condition()
        self.agente_visto = 0.0
        self.lim, self.lim_lock = {}, threading.Lock()
        self.atendidas = 0

    def agente_conectado(self):
        return self.agente_visto and time.monotonic() - self.agente_visto < AGENTE_VIVO

    def limitar(self, ip):
        ahora = time.monotonic()
        with self.lim_lock:
            marcas = [t for t in self.lim.get(ip, []) if ahora - t < LIMITE_IP[1]]
            if len(marcas) >= LIMITE_IP[0]:
                self.lim[ip] = marcas
                return False
            marcas.append(ahora)
            self.lim[ip] = marcas
            if len(self.lim) > 5000:
                for k in [k for k, v in self.lim.items() if not v or ahora - v[-1] > 3600]:
                    self.lim.pop(k, None)
        return True

    def clave_ok(self, cabecera):
        m = re.fullmatch(r"Bearer (\S+)", cabecera or "")
        return bool(m) and hmac.compare_digest(m.group(1).encode(), self.token.encode())

    # --- cola
    def encolar(self, t):
        with self.cond:
            if len(self.cola) >= MAX_COLA:
                return False
            self.trabajos[t.id] = t
            self.cola.append(t)
            self.cond.notify()
        return True

    def esperar_trabajo(self, segundos):
        self.agente_visto = time.monotonic()
        with self.cond:
            self.cond.wait_for(lambda: self.cola, timeout=segundos)
            t = self.cola.popleft() if self.cola else None
        self.agente_visto = time.monotonic()
        return t

    def responder(self, tid, resp):
        with self.cond:
            t = self.trabajos.get(tid)
        if not t:
            return False
        t.respuesta = resp
        t.evento.set()
        return True

    def olvidar(self, t):
        with self.cond:
            self.trabajos.pop(t.id, None)
            try:
                self.cola.remove(t)
            except ValueError:
                pass


def crear_handler(estado):
    class H(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        server_version = "AllasRelay"

        def log_message(self, *a):
            pass

        # ---- utilidades
        def _ip(self):
            if estado.confiar_proxy:
                xs = [x.strip() for x in (self.headers.get("X-Forwarded-For") or "").split(",") if x.strip()]
                if xs:
                    return xs[-1][:45]
            return self.client_address[0]

        def _cors(self):
            o = (self.headers.get("Origin") or "").rstrip("/")
            if o and ("*" in estado.origenes or o.lower() in estado.origenes):
                return {"Access-Control-Allow-Origin": "*" if "*" in estado.origenes else o, "Vary": "Origin"}
            return {}

        def _enviar(self, codigo, cuerpo=b"", tipo="application/json; charset=utf-8", extra=None):
            self.send_response(codigo)
            if codigo != 204:
                self.send_header("Content-Type", tipo)
            self.send_header("Content-Length", str(len(cuerpo)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            for k, v in {**self._cors(), **(extra or {})}.items():
                self.send_header(k, v)
            self.end_headers()
            if cuerpo and self.command != "HEAD":
                self.wfile.write(cuerpo)

        def _json(self, codigo, obj):
            self._enviar(codigo, json.dumps(obj, ensure_ascii=False).encode("utf-8"))

        def _leer(self):
            n = int(self.headers.get("Content-Length") or 0)
            if n > MAX_CUERPO:
                return None
            return self.rfile.read(n) if n else b""

        # ---- métodos
        def do_OPTIONS(self):
            if not urlparse(self.path).path.startswith(PREFIJO):
                return self._enviar(404)
            if not self._cors():
                return self._enviar(403)
            self._enviar(204, b"", extra={"Access-Control-Allow-Methods": "GET, POST, OPTIONS", "Access-Control-Allow-Headers": "Content-Type",
                                          "Access-Control-Max-Age": "600"})

        def do_HEAD(self):
            self.do_GET()

        def do_GET(self):
            u = urlparse(self.path)
            if u.path.startswith("/agente/"):
                return self._agente_get(u)
            if u.path.startswith(PREFIJO):
                return self._publico(u, b"")
            if u.path == "/salud":
                return self._json(200, {"agente": bool(estado.agente_conectado())})
            self._estatico(u.path)

        def do_POST(self):
            u = urlparse(self.path)
            cuerpo = self._leer()
            if cuerpo is None:
                self.close_connection = True
                return self._json(413, {"error": "Petición demasiado grande"})
            if u.path.startswith("/agente/"):
                return self._agente_post(u, cuerpo)
            if u.path.startswith(PREFIJO):
                return self._publico(u, cuerpo)
            self._enviar(404)

        # ---- cliente → programa
        def _publico(self, u, cuerpo):
            ruta = u.path + ("?" + u.query if u.query else "")
            if len(ruta) > 400 or ".." in u.path or not re.fullmatch(r"[A-Za-z0-9/_\-.?=&%:+@]*", ruta):
                return self._json(400, {"error": "Solicitud no válida"})
            ip = self._ip()
            if not estado.limitar(ip):
                return self._json(429, {"error": "Demasiadas peticiones. Inténtelo de nuevo en unos minutos."})
            if not estado.agente_conectado():
                return self._json(503, {"error": "El servicio de reservas no está disponible ahora mismo. Inténtelo más tarde o llame al parking."})
            t = Trabajo(self.command, ruta, cuerpo, ip, self.headers.get("Origin"))
            if not estado.encolar(t):
                return self._json(503, {"error": "Hay demasiadas reservas en curso. Inténtelo de nuevo en un minuto."})
            if not t.evento.wait(ESPERA_RESPUESTA):
                estado.olvidar(t)
                return self._json(504, {"error": "El parking no ha respondido a tiempo. Inténtelo de nuevo."})
            estado.olvidar(t)
            r = t.respuesta
            estado.atendidas += 1
            cuerpo_r = base64.b64decode(r.get("cuerpo_b64") or "")
            self._enviar(int(r.get("estado") or 502), cuerpo_r, str(r.get("tipo") or "application/json; charset=utf-8")[:100])

        # ---- programa ↔ servidor
        def _agente_ok(self):
            if not estado.clave_ok(self.headers.get("Authorization")):
                time.sleep(0.5)   # frena los intentos de adivinar la clave
                self._json(401, {"error": "Clave incorrecta"})
                return False
            return True

        def _agente_get(self, u):
            if not self._agente_ok():
                return
            if u.path == "/agente/ping":
                estado.agente_visto = time.monotonic()
                return self._json(200, {"ok": True})
            if u.path == "/agente/esperar":
                try:
                    seg = max(0, min(30, int(parse_qs(u.query).get("max", ["25"])[0])))
                except ValueError:
                    seg = 25
                t = estado.esperar_trabajo(seg)
                return self._enviar(204) if t is None else self._json(200, t.para_agente())
            self._enviar(404)

        def _agente_post(self, u, cuerpo):
            if not self._agente_ok():
                return
            m = re.fullmatch(r"/agente/responder/([0-9a-f]{24})", u.path)
            if not m:
                return self._enviar(404)
            try:
                resp = json.loads(cuerpo or b"{}")
                assert isinstance(resp, dict)
            except (ValueError, AssertionError):
                return self._json(400, {"error": "Respuesta no válida"})
            self._json(200, {"ok": True}) if estado.responder(m.group(1), resp) else self._json(404, {"error": "La petición ya no existe"})

        # ---- página de reservas
        def _estatico(self, ruta):
            nombre = "reservas.html" if ruta in ("/", "/index.html") else os.path.basename(ruta)
            archivo = os.path.join(estado.web, nombre)
            if os.path.splitext(nombre)[1].lower() not in EXTENSIONES_WEB or not os.path.isfile(archivo) or os.path.dirname(os.path.abspath(archivo)) != os.path.abspath(estado.web):
                return self._json(404, {"error": "No encontrado"})
            with open(archivo, "rb") as fh:
                datos = fh.read()
            tipo = mimetypes.guess_type(nombre)[0] or "application/octet-stream"
            self._enviar(200, datos, tipo + ("; charset=utf-8" if tipo.startswith("text/") or tipo.endswith("javascript") else ""))
    return H


def crear_servidor(host, puerto, token, web, origenes=(), confiar_proxy=False):
    estado = Estado(token, web, origenes, confiar_proxy)

    class Srv(ThreadingHTTPServer):
        daemon_threads = True
        allow_reuse_address = True
    return Srv((host, puerto), crear_handler(estado)), estado


def main():
    ap = argparse.ArgumentParser(description="Servidor intermedio de reservas de PROYECTO ALLAS")
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--puerto", type=int, default=int(os.environ.get("PORT", "8080")))
    ap.add_argument("--token", default=os.environ.get("ALLAS_RELAY_TOKEN", ""), help="clave compartida con el programa (mejor por la variable ALLAS_RELAY_TOKEN)")
    ap.add_argument("--web", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "web"), help="carpeta con reservas.html y reservas.js")
    ap.add_argument("--origenes", default=os.environ.get("ALLAS_RELAY_ORIGENES", ""), help="webs que pueden usar la API desde otro dominio (separadas por comas)")
    ap.add_argument("--confiar-proxy", action="store_true", help="hay un proxy delante (Caddy, nginx…): la IP del cliente es la última de X-Forwarded-For")
    a = ap.parse_args()
    if len(a.token) < TOKEN_MIN:
        sys.exit(f"Falta la clave (mínimo {TOKEN_MIN} caracteres). Ejemplo para crear una:  python3 -c \"import secrets; print(secrets.token_urlsafe(32))\"")
    if not os.path.isfile(os.path.join(a.web, "reservas.html")):
        alt = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "integracion_web")   # dentro de la carpeta del programa
        if os.path.isfile(os.path.join(alt, "reservas.html")):
            a.web = alt
    if not os.path.isfile(os.path.join(a.web, "reservas.html")):
        sys.exit(f"No encuentro {os.path.join(a.web, 'reservas.html')}. Use --web con la carpeta de la página de reservas.")
    srv, _ = crear_servidor(a.host, a.puerto, a.token, a.web, a.origenes.split(","), a.confiar_proxy)
    print(f"Servidor de reservas en el puerto {a.puerto}. Esperando al programa del parking…", flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
