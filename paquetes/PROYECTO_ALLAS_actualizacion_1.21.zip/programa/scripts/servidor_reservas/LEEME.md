# Servidor de reservas en la nube (opcional)

Sirve para que los clientes reserven desde Internet **sin abrir el PC del parking**:

```
móvil del cliente ──► este servidor (en Internet) ◄── programa del parking (llama él, cada pocos segundos)
```

* El servidor **no guarda nada**: solo pasa las peticiones. Las reservas viven en la base de datos del parking.
* Si el programa del parking está apagado o sin Internet, el cliente ve «servicio no disponible» (no pierde datos).
* Solo se reenvían las rutas `/api/publico/reservas*`; el resto del programa nunca se ve desde fuera.

## 1. Poner el servidor (cualquier máquina con Python 3.8+)

1. Cree una clave larga (la misma irá en el programa):
   `python3 -c "import secrets; print(secrets.token_urlsafe(32))"`
2. Copie esta carpeta (`servidor_reservas`, con su subcarpeta `web`) al servidor.
3. Arránquelo:
   `ALLAS_RELAY_TOKEN=<la clave> python3 relay.py --puerto 8080 --confiar-proxy`
4. **Póngale HTTPS delante** (Caddy, nginx o el panel de su hosting). Ejemplo con Caddy, en un `Caddyfile`:
   ```
   reservas.mi-parking.es {
       reverse_proxy 127.0.0.1:8080
   }
   ```
   Con Caddy delante use `--confiar-proxy` (así el límite de peticiones es por cliente y no del proxy). Sin proxy, no lo use.
   Es obligatorio: la clave viaja en cada llamada del programa y los datos de los clientes pasan por aquí.
5. Para que arranque solo con la máquina use un servicio (`systemd`) o el `Dockerfile` de esta carpeta.

Opciones: `--origenes https://www.mi-parking.es` (si la página de reservas está en otra web y llama a esta API),
`--web carpeta` (la página que se sirve), `--host`, `--puerto`.

## 2. Conectar el programa

En el programa: **Ajustes → Reservas online → Web de clientes → Servidor en la nube**:

* Dirección: `https://reservas.mi-parking.es`
* Clave: la del paso 1
* Active «Usar el servidor en la nube» y pulse **Probar conexión**.

Después ponga como «Página de reservas en su web» la dirección del servidor (o la de su web si la incrusta), para que el
email de confirmación y el pago con tarjeta vuelvan al sitio correcto.

## 3. Comprobar

* `https://reservas.mi-parking.es/salud` → `{"agente": true}` si el programa del parking está conectado.
* Abra `https://reservas.mi-parking.es/` en el móvil y haga una reserva de prueba.

## Seguridad en pocas palabras

* La clave es un secreto: quien la tenga puede leer las peticiones de los clientes. Cámbiela si sospecha que se filtró
  (en el servidor y en el programa).
* El programa limita las peticiones por IP del cliente, protege contra robots (campo trampa) y el servidor limita además
  por IP para no saturar el PC del parking.
* Las rutas del personal (caja, ajustes, etc.) **no** pasan por aquí.
