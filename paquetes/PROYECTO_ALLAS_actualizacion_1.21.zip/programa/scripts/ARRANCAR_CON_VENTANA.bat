@echo off
REM Arranca PROYECTO ALLAS con la ventana del servidor visible (para ver mensajes o errores).
set "ALLAS_VENTANA=1"
call "%~dp0..\ARRANCAR.bat" %*
