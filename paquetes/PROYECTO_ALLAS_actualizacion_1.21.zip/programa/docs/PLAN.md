# Plan de implementación

## Fase 0 — Análisis ✅
Requisitos fijados: atendido con empleado en caja, local sin Internet, desarrollo propio, impresora térmica + lector QR + cajón.

## Fase 1 — Núcleo y versión operativa (MVP) ✅ *(esta entrega)*

| Bloque | Estado |
|---|---|
| Base de datos SQLite, migraciones, transacciones, auditoría | ✅ |
| Motor de tarifas (tramos, fracción por minuto, cortesía, tope 24 h, versionado) | ✅ |
| Entrada con QR firmado (HMAC), aforo, matrícula duplicada | ✅ |
| Cobro efectivo/tarjeta, cambio, importe congelado al consultar, exceso tras pagar | ✅ |
| Ticket perdido por matrícula + recargo | ✅ |
| Turnos: apertura, ingresos/retiradas, apertura de cajón registrada, arqueo ciego, cierre Z | ✅ |
| Factura simplificada numerada + registro encadenado SHA-256 inalterable | ✅ |
| Impresión ESC/POS (USB Linux, red, Windows RAW, archivo) + cajón | ✅ |
| Usuarios y roles, anulación con PIN de supervisor | ✅ |
| Informes, CSV para gestoría, verificación de cadena | ✅ |
| Copias de seguridad automáticas y a carpeta externa | ✅ |
| Código de barras Code128 además de QR (lectores láser/infrarrojos) | ✅ |
| Diseño de tickets renovado, textos editables y vista previa en vivo | ✅ |
| Clientes, matrículas, bonos mensuales/trimestrales, tarjeta de abonado | ✅ |
| Marca y modelo por vehículo del cliente | ✅ |
| Ticket manual (entrada, o entrada + salida con cobro) con autorización | ✅ |
| Copias: registro, descarga, subida y restauración desde la aplicación | ✅ |
| Servicios y productos en la estancia con IVA por tipos | ✅ |
| Eliminar copias de seguridad; motivo opcional en ticket manual | ✅ |
| Tarifas con redondeo a 0,05 € y texto en ticket; servicios con minutos de parking incluidos | ✅ |
| Factura con datos del cliente, PDF y envío por email con cola de reintentos | ✅ |
| Ticket manual con salida futura (prepago); menú Entrada / Salida | ✅ |
| 74 pruebas automáticas (unitarias, API HTTP, migraciones, restauración, SMTP) y pruebas de navegador | ✅ |

## Fase 2 — Piloto en el parking (1–2 semanas)

1. **Instalación** (½ día): Python 3.11+, copiar carpeta, accesos directos de arranque en quiosco (`scripts/`), arranque automático con Windows.
2. **Hardware** (½ día): impresora en modo `windows` o `red`, ancho de línea, prueba de acentos/€ y QR; cajón en pin 2/5; lector con sufijo Intro y distribución de teclado correcta (ver `HARDWARE.md`).
3. **Configuración** (½ día): datos fiscales, aforo, tarifas reales (usar el simulador para cuadrar con el cartel de precios), recargo por pérdida, minutos de salida, usuarios.
4. **Formación** (1–2 h por empleado): entrada, cobro, ticket perdido, cierre con arqueo.
5. **Funcionamiento en paralelo** con el sistema actual 3–7 días: comparar recaudación y arqueos diarios.
6. **Ajustes** según incidencias y paso a producción.

**Criterios de aceptación:** cero diferencias no explicadas en arqueos durante el paralelo; tiempo de cobro < 15 s por vehículo; tickets legibles por el lector al 100 % (también arrugados); copia de seguridad diaria verificada fuera del PC.

## Fase 3 — Cumplimiento fiscal VERI\*FACTU (obligatorio en 2027)

El Reglamento de sistemas informáticos de facturación (RD 1007/2023) afecta a este software porque emite facturas simplificadas. Tras el último aplazamiento, la obligación empieza el **1 de enero de 2027 para sociedades** y el **1 de julio de 2027 para el resto** (autónomos). Conviene confirmarlo con la asesoría porque las fechas ya se han movido más de una vez.

Lo ya preparado: numeración correlativa sin huecos por serie, registro de facturación encadenado con huella SHA-256, registros inalterables, auditoría de eventos.

Lo que falta, según la modalidad elegida:

| | Modalidad **VERI\*FACTU** | Modalidad **no VERI\*FACTU** |
|---|---|---|
| Conexión | Envía cada registro a la AEAT. Admite conexión intermitente (cola y reenvío), p. ej. un router 4G | Sin envío: compatible con el funcionamiento 100 % offline |
| Firma | No exige firma electrónica de los registros | Cada registro firmado (XAdES) con certificado del obligado |
| Otros | QR y leyenda VERI\*FACTU en la factura | Registro de eventos más exigente; exportación a requerimiento de la AEAT |

Trabajo estimado (2–4 semanas): adaptar la huella al formato y campos exactos de la especificación técnica de la AEAT, QR tributario en la factura, registros de anulación, registro de eventos del sistema, firma XAdES (modalidad no VERI\*FACTU) o cliente de envío con cola (VERI\*FACTU), y la **declaración responsable** del productor del software.

**Recomendación:** decidir la modalidad con la asesoría antes de empezar. Si un router 4G es aceptable, VERI\*FACTU suele ser más simple de mantener (sin firma electrónica local); el resto del sistema seguiría funcionando sin conexión.

## Fase 4 — Ampliaciones (priorizar según negocio)

| Prioridad | Funcionalidad | Esfuerzo |
|---|---|---|
| Alta | Devoluciones con factura rectificativa | 2–3 días |
| Media | Validaciones de comercios (descuentos con sello/QR de tienda) | 3–5 días |
| Media | Factura con datos del cliente: hoy se añaden a la misma factura (mismo número). Revisar con la asesoría si, cuando el cliente los pide **después** de la venta, debe emitirse una factura de canje en serie aparte que referencie la simplificada (encaja con la adaptación VERI\*FACTU) | 2–3 días |
| Media | Avisos de renovación por SMS/email (requiere conexión) y domiciliación de bonos | 1 semana |
| Media | Integración de datáfono (cobro automático del importe) — depende del banco/TPV | 1–2 semanas |
| Media | Segunda caja o tablet en red local (ya soportado a nivel servidor; falta multi-turno) | 3–5 días |
| Baja | Barrera por relé USB/Ethernet al pagar | 2–3 días + hardware |
| Baja | Lectura de matrículas (LPR) en entrada | 2–4 semanas + cámara |
| Baja | Informes en PDF, tarifas por franja horaria/día de la semana | 3–5 días |

## Fase 5 — Mantenimiento

- Copia diaria fuera del PC (pendrive rotatorio o NAS) y prueba de restauración trimestral.
- Revisión semanal de descuadres y anulaciones en *Informes → Auditoría*.
- Actualizaciones: sustituir la carpeta `app/` y `web/` (los datos están en `datos/`); las migraciones de BD se aplican solas al arrancar.
