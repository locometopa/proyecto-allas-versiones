# Hardware e instalación

## Equipo recomendado

| Elemento | Requisito | Ejemplos habituales |
|---|---|---|
| PC de caja | Windows 10/11 o Linux, 4 GB RAM, SSD, pantalla ≥ 15" (táctil opcional) | Cualquier PC TPV o mini-PC |
| Impresora térmica | 80 mm, **ESC/POS**, con conector RJ11 para cajón, que imprima QR nativo | Epson TM-T20III / TM-T88, Bixolon SRP-350, Star TSP143 (modo ESC/POS), clónicas 80 mm |
| Lector de códigos | USB, **emulación de teclado (HID)**. Sirve un lector **1D láser/infrarrojo/CCD** (lee el código de barras) o uno **2D de imagen** (lee QR y barras) | 1D: Honeywell Voyager 1200g, Zebra LS2208 · 2D: Honeywell 1450g, Zebra DS2208 |
| Cajón portamonedas | Conector **RJ11 a impresora**, 24 V | El de la marca de la impresora o compatible |
| SAI (recomendado) | 600 VA para PC + impresora | Evita cortes a mitad de cobro |

## Impresora

Configúrela en *Ajustes → Impresora y cajón* y pulse **Imprimir prueba** (debe salir con acentos, ñ, €, texto invertido, un QR y un código de barras). Escanee ambos con su lector para confirmar.

- **Windows (USB):** instale el driver del fabricante, use el **nombre exacto** de la impresora (Panel de control → Impresoras) y modo `windows`. El programa envía datos RAW, así que el driver solo hace de "tubería".
- **Red/Ethernet:** modo `red`, destino `192.168.1.50:9100` (IP fija en la impresora).
- **Linux USB:** modo `dispositivo`, destino `/dev/usb/lp0`. Añada el usuario al grupo `lp`.
- **Sin impresora (pruebas):** modo `archivo`; los tickets se guardan como `.txt` (vista previa) y `.bin` (bytes ESC/POS).
- **Ancho:** 42 caracteres para 80 mm con fuente A (48 con fuente B), 32 para 58 mm.
- **Página de códigos:** se usa PC858 (con €). Si salen símbolos raros, active en la impresora la página 858 o 850 con su utilidad de configuración.

## Cajón

Se conecta por RJ11 a la impresora; se abre con un pulso ESC/POS al cobrar en efectivo, al hacer ingresos/retiradas y al cerrar turno. Si no abre, cambie **Pin del cajón** entre "Pin 2" y "Pin 5". Cada apertura sin venta queda registrada con usuario, hora y motivo.

## Lector de códigos

Los tickets y tarjetas llevan **QR y código de barras Code128** con el mismo contenido (se puede elegir solo uno en *Ajustes → Ticket*). Los lectores **láser, infrarrojos o CCD (1D) solo leen el código de barras**; los de imagen (2D) leen los dos. Si su lector 1D no lee el ticket, compruebe en su manual que la simbología **Code 128** está activada (lo está casi siempre de fábrica).

El lector funciona como un teclado: escribe el código y pulsa Intro. Configúrelo (con los códigos de su manual) así:

1. **Sufijo: Intro (CR)** — imprescindible.
2. **Distribución de teclado: Español** (la misma que Windows). Los códigos del parking son solo letras y números, así que aunque no coincida suele funcionar, pero es la causa n.º 1 de lecturas raras.
3. Retardo entre caracteres: 0 (modo rápido).

La interfaz reconoce el código escaneado aunque el cursor no esté en el campo de búsqueda: se puede escanear desde cualquier pantalla y se abre el cobro.

## Instalación en Windows

1. Instale **Python 3.11 o superior** desde python.org (marque *Add python.exe to PATH*). Es lo único que necesita; el programa no usa librerías externas. Guarde el instalador para reinstalar sin Internet.
2. Copie la carpeta `parking` a `C:\parking`.
3. Ejecute `ARRANCAR.bat`: arranca el servidor (ventana "SERVIDOR", no cerrar) y abre la caja en Edge. Para pantalla completa use `scripts\ARRANCAR_QUIOSCO.bat`.
4. Primera vez: cree el usuario administrador y los datos fiscales.
5. Arranque automático: cree un acceso directo a `scripts\ARRANCAR_QUIOSCO.bat` en `shell:startup` (Win+R → `shell:startup`).
6. Para salir del modo quiosco: Alt+F4.

## Instalación en Linux

```bash
sudo cp -r parking /opt/parking
sudo cp /opt/parking/scripts/parking.service /etc/systemd/system/
sudo systemctl enable --now parking
/opt/parking/scripts/iniciar_linux.sh     # abre el navegador en quiosco
```

## Datos y copias

- Base de datos: `datos/parking.db`. Copias: `datos/backups/` (al arrancar, cada 6 h, en cada cierre de turno; se conservan 30).
- Configure una **carpeta adicional** (pendrive o NAS) en *Ajustes → Copias de seguridad*.
- Restaurar: desde *Ajustes → Copias de seguridad → Restaurar…* (no hace falta detener el programa). Si el programa no arranca en absoluto: detenerlo, copiar la copia deseada como `datos/parking.db`, borrar `parking.db-wal` y `parking.db-shm` si existen, y arrancar.
- El registro de copias está en `datos/backups/registro.jsonl` (fuera de la base de datos, para que no se pierda al restaurar).


## Visor TPV de cliente (opcional, 3.3)

Visores de 2 líneas × 20 caracteres (VFD o LCD) por puerto serie, USB‑serie (aparece como COMx en el Administrador de dispositivos), como impresora de Windows o por red. En *Ajustes → Equipos → Pantalla de cliente* elija *Visor TPV de texto*, la conexión, el puerto y el protocolo (pruebe primero *ESC/POS · Epson*; si salen caracteres raros, *CD5220*), y pulse *Probar el visor*.

## Barrera y datáfono (opcionales, 3.9)

**Barrera.** Hace falta un relé que cierre el contacto de apertura de la barrera (pregunte al instalador de la barrera cuál es la entrada de «abrir»). Lo más sencillo:

- **Relé de red** (Shelly 1, módulos ESP, relés Ethernet): se configura su URL de apertura (con temporizador de 1 s si lo admite).
- **Relé USB** (tipo LCUS-1, CH340): aparece como puerto COM; bytes `A0 01 01 A2` para cerrar el contacto y `A0 01 00 A1` para soltarlo, pulso de 1000 ms.
- **Controladora de accesos** con utilidad propia: se configura como programa.

**Datáfono.** Los datáfonos bancarios no se manejan igual: unos tienen un programa «TPV-PC» del banco, otros una pasarela por red o un SDK. PROYECTO ALLAS llama a esa pasarela o programa con el importe y espera la respuesta; si su banco no ofrece integración, deje el datáfono sin integrar y teclee el importe como siempre.

**NAS.** Cree una carpeta compartida (p. ej. `copias_parking`) con permiso de escritura para el usuario de Windows del PC del parking y escriba su ruta de red (`\\NAS\copias_parking`) en *Copia también en el NAS*.
