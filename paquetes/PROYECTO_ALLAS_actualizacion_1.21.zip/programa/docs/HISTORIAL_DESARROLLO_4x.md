# PROYECTO ALLAS · historial de versiones

La versión se muestra en el menú lateral, en la pantalla de acceso, en la ventana del servidor y al pie de las facturas en PDF. Se incrementa con cada entrega de cambios (1.1, 1.2…); un cambio grande de estructura pasaría a 2.0.

## 4.65 — 15 de octubre de 2026

- **Ventanas que se ajustan:** si el contenido de una ventana no cabe en alto, se ensancha sola (hasta el ancho de la pantalla) para evitar la barra de desplazamiento vertical; solo se ensancha si con ello gana altura. Además, pueden ocupar casi toda la altura de la pantalla.
- **Ficha del cliente reorganizada:** dos columnas. A la izquierda, bonos, facturas y últimas estancias; a la derecha, un cuadro con su situación (dentro o fuera), vehículos, tarjeta, renovación automática, descuento y notas. Las acciones (vender bono, tarjeta, entrada, editar) quedan juntas bajo el nombre. Los clientes sin abono no ven el apartado de bonos.
- **Nuevo cliente más compacto:** NIF, teléfono, email y dirección en una sola fila en pantallas anchas.

## 4.64 — 15 de octubre de 2026

- **Estado de las facturas:** cada factura (también las de abonados) está «Generada», «Enviada» o «Cobrada», y se cambia a mano desde la factura. Lo cobrado en efectivo o tarjeta nace «Cobrada»; al enviarla por email pasa sola a «Enviada». Hay una columna de estado en la lista de Facturas.
- **Facturas a proveedor solo en A4:** se pueden imprimir en A4, descargar en PDF o enviar por email; ya no hay impresión en ticket (si no hay impresora A4 configurada, se imprime desde el navegador).

## 4.63 — 15 de octubre de 2026

- **Servicios del proveedor en su ficha:** igual que a un abonado se le venden bonos desde su ficha, a un proveedor se le añaden, cambian o quitan sus servicios y precios desde su ficha («Añadir servicio»). El formulario de nuevo proveedor ya no los pide.
- **Tipo arriba del todo:** en la pantalla de cliente, el tipo (Abonado, Cliente sin abono o Proveedor) va encima del nombre y apellidos.
- **Error al guardar un proveedor:** corregido («Cannot read properties of null»). Editar los datos de un proveedor tampoco borra ya sus servicios.

## 4.62 — 15 de octubre de 2026

- **Historial de actualizaciones en Ajustes:** en Sistema → Actualizaciones aparece el historial de versiones con sus novedades. Si es largo se ven las 5 últimas (con «Mostrar todas») y todo el historial se puede descargar en un archivo de texto.
- **Novedades con mayúscula inicial:** en cada cambio de una actualización, la primera letra que sigue a los dos puntos va en mayúscula (en pantalla, en el archivo de texto y en este historial).
- **Servicios sin precio fijo:** si en Ajustes → Precios se deja el precio vacío, el servicio es de «precio variable» y el precio se pide al seleccionarlo en Entrada, Salida y Tienda (el servidor no lo acepta sin precio). En la lista aparece «Al vender».

## 4.61 — 15 de octubre de 2026

- **Servicios: Parking incluido en minutos, horas o días:** El tiempo de parking que incluye un servicio se escribe con la unidad que se elija (se guarda en minutos y se vuelve a mostrar en la unidad más cómoda). El máximo pasa de una semana a 31 días.

## 4.60 — 15 de octubre de 2026

- **Proveedores como apartado propio:** En Clientes hay un filtro «Proveedores» (separado de los clientes sin abono) con sus servicios y precios a la vista y un botón **Facturar**. Al proveedor solo se le hace factura: no tiene ticket, bonos, vehículos ni descuentos.
- **Servicio y precio personalizados:** En el formulario, donde antes estaban los vehículos, un proveedor tiene «Servicios y precios» (cada proveedor con su precio, aunque el servicio sea el mismo). La factura a proveedor ofrece solo los servicios de ese proveedor, con su precio.
- **Pantalla de cliente ordenada:** Formulario por bloques (Datos, Vehículos o Servicios y precios, Opciones, Notas). El tipo (Abonado, Cliente sin abono o Proveedor) cambia al momento lo que se muestra: bonos y renovación solo para abonados; descuento fijo no para proveedores.
- Ficha propia del proveedor con sus servicios, precios y facturas.

## 4.59 — 15 de octubre de 2026

- **QR de turnos más grande:** En el ticket (por defecto tamaño 10, hasta 15), en la hoja PDF y en la vista previa de Usuarios, para que el lector lo lea con más facilidad.
- **Barra superior:** Vuelve el orden logo y nombre del parking a la izquierda y, a continuación, la ocupación (se deshace el centrado de la 4.58).

## 4.58 — 15 de octubre de 2026

- **Impresión en pantalla:** Nueva conexión «Solo en pantalla» (Ajustes → Tickets → Impresoras y cajón). El ticket se enseña en un panel flotante y no se gasta papel; también se usa solo cuando la impresora no está configurada (modo físico sin destino). Las instalaciones con la impresora sin tocar pasan a este modo.
- **Factura a proveedor:** Nuevo botón en Facturas. Los proveedores se marcan en la ficha del cliente («Es un proveedor»; son clientes de facturación, **nunca llevan bonos**) y sus servicios en Ajustes → Precios → «Solo para proveedores» (no salen en Entrada, Salida ni Tienda). Serie y numeración propias (por defecto **P**), editables en Ajustes → Preferencias y numeración. Se emite como factura completa y se paga por transferencia, efectivo o tarjeta.
- **Sello del garaje:** Ajustes → Empresa → Datos y cobro. Se sube una imagen y sale al final del ticket de cobro y en la factura PDF (abajo a la derecha); se puede activar o no en cada sitio. Va incluido en las copias de seguridad.
- **Barra superior:** El nombre del parking va centrado entre la ocupación y los botones.
- **Supervisión:** Nuevo panel «Actualizaciones online» para cambiar el enlace de descarga (y de dónde se descargan) y probarlo.

## 4.57 — 15 de octubre de 2026

- **Modo demostración con cantidades a elegir:** Al activar la demo (o al «Empezar la demo de cero») se elige cuántos clientes, bonos vendidos, vehículos dentro ahora y días de historial se crean, con atajos Pequeña / Normal / Grande (por defecto, como hasta ahora). Los bonos no pueden superar el número de clientes y los vehículos dentro se reparten entre abonados con bono vigente y tickets normales.

## 4.56 — 15 de octubre de 2026

- **Lista de vehículos:** «Cambiar matrícula» y «Cambiar tarifa» se unen en un solo botón del menú «⋯»: **Modificar matrícula y tarifa…** (la tarifa solo se ofrece cuando se puede cambiar: ticket sin pagos y que no sea de abonado).
- **Daños del vehículo:** El programa ya registraba el estado del vehículo (notas de daños y hasta 6 fotos, guardadas con el ticket); ahora también se abre desde el menú «⋯» de la lista «Dentro ahora» («Estado del vehículo (daños y fotos)»), además del último ticket y la Salida. Se activa en Ajustes → Empresa → Opciones («Estado del vehículo al entrar»).

## 4.55 — 15 de octubre de 2026

- **Salida con un solo campo:** El mismo campo sirve para escanear el ticket o la tarjeta de abonado (o un vale mientras se cobra), el QR de fichaje o escribir la matrícula; el programa detecta solo de qué se trata al pulsar Intro. Se quita el segundo campo «Buscar matrícula». La lista de vehículos dentro se despliega al pulsar el campo o al escribir una matrícula (no con un código escaneado).

## 4.54 — 15 de octubre de 2026

- **Descuento fijo por cliente:** En la ficha del cliente (Editar datos) se activa un «Descuento fijo en sus estancias» con su porcentaje. Al cobrar la salida de un vehículo de ese cliente (por su ticket o por su matrícula) el descuento aparece ya elegido en el desplegable de descuentos (se puede cambiar por otro o quitar en el momento) y sale en el recibo y la factura. No depende del módulo de descuentos y no afecta a abonados con bono vigente. Migración v31.
- **Confirmar la salida al fichar:** Al pasar el QR para fichar una salida sale una ventana con lo trabajado y el resumen del turno de caja (entradas, cobros, efectivo y tarjeta) para «Confirmar salida» o cancelar. Es opcional: se activa o desactiva en Ajustes → Empresa → Usuarios (por defecto, activada). Las entradas se fichan directamente.
- **Licencia:** Se quita el botón «Ver Acerca de» de Ajustes → Sistema → Licencia (el panel del fabricante sigue mostrando sus datos).
- **Matrícula o ticket que ya está dentro:** En Entrada, si se escribe o escanea una matrícula o un código de ticket de un vehículo que ya está dentro, en vez de un error sale una ventana con sus datos y las opciones **Reimprimir ticket**, **Modificar matrícula o tarifa**, **Anular ticket** (con la autorización de supervisor que ya hacía falta) y **Cancelar**.

## 4.53 — 15 de octubre de 2026

- **El QR de fichaje se lee siempre:** El código ahora es «FICHA» + 12 dígitos (antes llevaba signos y mayúsculas/minúsculas mezcladas, que el lector del equipo escribía mal según el teclado o el Bloq Mayús). Se reconoce aunque el lector añada caracteres, y **en cualquier pantalla**, sin necesidad de tener un campo seleccionado (antes solo en Caja, Entrada y Salida). Los QR anteriores dejan de valer: hay que imprimir los nuevos (Ajustes → Empresa → Usuarios → «QR»).
- **Textos opcionales del QR impreso:** Nombre del parking, nombre del empleado, texto superior, texto bajo el QR y texto final se activan, se quitan o se escriben a gusto; con vista previa. Valen igual para el ticket, el PDF y el correo. Además, tamaño del QR y papel antes del corte.
- **Fichaje integrado con el turno de caja:** Panel «Jornada y turno» en Caja y turno (estado de su jornada y de su turno, aviso si falta fichar, quién está dentro con su turno). Opción en Ajustes → Empresa → Usuarios: *independientes*, *al abrir el turno se ficha la entrada* o *entrada al abrir y salida al cerrar*. Cada fichaje guarda el turno de caja en que se hizo y se ve en el listado y en el CSV. Migración v30.

## 4.52 — 15 de octubre de 2026

- **Acceso:** El PIN no se puede escribir (ni con el teclado de pantalla ni con el físico) mientras no haya un usuario seleccionado; se avisa «Elija primero su usuario» y el teclado se ve atenuado.
- **Comentario interno más ordenado:** En Salida y en el historial se muestra como tarjeta con icono, título «Comentario interno», el texto debajo y el botón «Editar» a la derecha.
- **Lista de vehículos:** Ya no muestra el texto del comentario, solo un icono junto a la matrícula; al pulsarlo se lee el comentario (con botón para editarlo).

## 4.51 — 15 de octubre de 2026

- **Fichaje con el lector de códigos del equipo:** Se quita la pantalla de fichar con móvil o tablet (`/fichar`). El QR personal ahora se lee con el mismo lector de los tickets: el lector «escribe» el código y el programa lo reconoce (`ALLAS-FICHAJE:…`) estés donde estés: en **Caja y turno** (nuevo panel «Fichaje del personal» con campo de lectura, quién está dentro y los últimos fichajes), en **Entrada** y en **Salida**. Aparece un aviso con el nombre, la hora y, si es salida, lo trabajado. Los QR de la 4.49 siguen valiendo; la ruta de fichar ya exige sesión abierta.
- **QR del personal:** Desde Ajustes → Empresa → Usuarios → «QR» se puede **imprimir en la impresora de tickets** (con las líneas de papel antes del corte ajustables en el momento), **guardar en PDF** o **enviar el PDF por correo**.
- **Actualizaciones en «Acerca de»:** Nuevo botón «Actualizaciones» que lleva directamente a Ajustes → Sistema → Actualizaciones.
- **Fabricante junto al serial:** Los datos del fabricante se muestran dentro del panel de la licencia (Ajustes → Sistema → Licencia) y llegan con el serial (.lic o comprobación online); se quita el botón de cargarlos por separado.

## 4.50 — 15 de octubre de 2026

- **Historial del vehículo:** En «Vehículos → Dentro ahora», menú «⋯» → «Historial del vehículo» (y botón «Historial» en Salida): todas las visitas de esa matrícula con entrada, salida, tiempo, tarifa y lo pagado, más el total de visitas, lo pagado en total, la estancia media y la primera visita.
- **Comentarios internos:** Menú «⋯» → «Comentario interno» (por matrícula; no sale en tickets ni facturas). Si el vehículo tiene comentario, se ve en la lista de Dentro ahora, como aviso amarillo en **Entrada** al escribir la matrícula y en **Salida** al cobrar (con botón para editarlo). Queda en auditoría. Migración v29.

## 4.49 — 15 de octubre de 2026

- **Eliminar usuarios:** Botón «Eliminar» en Ajustes → Empresa → Usuarios. El usuario desaparece de las listas, no puede entrar y su nombre de usuario queda libre; sus tickets, turnos y cobros anteriores se conservan con su nombre. No se puede eliminar a uno mismo, al último administrador ni a quien tenga el turno de caja abierto (para suspender sin eliminar sigue estando «Usuario activo»).
- **Control de turnos por QR (se activa y desactiva en Ajustes → Empresa → Usuarios):** Cada usuario tiene un QR personal (botón «QR», con impresión y opción de generar uno nuevo). Al escanearlo —con un lector USB en la pantalla de fichaje (`/fichar`), con la tablet o con la cámara del móvil dentro de la red del parking— se registra la entrada o la salida de su jornada. Se ve quién está dentro, el listado de fichajes por fechas con las horas de cada persona, se puede exportar a CSV y cerrar una jornada olvidada. Es independiente del turno de caja. Migración v28.

## 4.48 — 15 de octubre de 2026

- **Ticket manual compacto:** La ventana se reorganiza en dos columnas (datos a la izquierda; importe, forma de pago, entregado y cambio a la derecha), con Entrada y Salida en la misma fila, el tipo de ticket arriba y los botones más pequeños, para que quepa entera en pantalla sin desplazarse.
- **Reserva / hotel con otro diseño:** Fecha de entrada y de salida reservada en dos bloques unidos por una flecha, «Cambiar fecha de entrada» como enlace, número de reserva debajo y la frase «Sin cargo hasta…» destacada.

## 4.47 — 15 de octubre de 2026

- **Ventana de «Instalar» y «Descargar e instalar»:** Ya no repite el listado de novedades (se ven en el panel de la actualización). Ahora muestra los datos que importan: versión actual → nueva, fecha de publicación, tamaño del paquete, número de novedades, copia de seguridad automática, comprobación de la firma y tiempo estimado.

## 4.46 — 15 de octubre de 2026

- **El tema solo se aplica en el programa:** El icono, los logos, la pantalla de acceso y la pantalla de carga mantienen el azul original (se deshace lo que hizo la 4.44). El logo del parking que se sube como imagen se ve sobre fondo claro en el tema oscuro.
- **Reserva hotel:** El ticket de entrada pone «Sin cargo hasta» (fecha fin de la reserva) en lugar de «Reserva hasta».

## 4.45 — 15 de octubre de 2026

- **Sin precios en el ticket de entrada:** El ticket ya no imprime precio, cortesía ni máximo diario (instalaciones existentes incluidas). En Ajustes → Tickets se puede activar **«Imprimir una dirección para consultar las tarifas»** y escribir la dirección (web del parking); sale en el ticket como «Consulte las tarifas en: …». Los precios se pueden volver a mostrar marcando la opción de siempre.
- **Nuevo color «Blanco y negro»** (claro: negro sobre blanco; oscuro: blanco sobre negro), también en el icono y la pantalla de carga.
- **Revisión del aspecto:** Lo que se guarda en Ajustes → Aspecto ahora manda sobre el cambio rápido de tema de Herramientas (antes lo ignoraba en ese equipo); la vista previa del color actualiza también el icono; botones, pestañas e insignias con letra blanca sobre colores claros en el tema oscuro (verde, turquesa, naranja, grafito, amarillo) pasan a letra oscura; las pastillas de la pantalla de cliente, «Sin logo», el globo de avisos y «Borrar todos los datos» se leen bien en el tema oscuro.

## 4.43 — 15 de octubre de 2026

- **Tickets más cortos:** Sin líneas en blanco de adorno, razón social y NIF en la misma línea, base e IVA en una sola línea, cortesía y máximo diario juntos en el ticket de entrada, y solo 2 líneas de papel antes del corte (antes 4; se puede cambiar en Ajustes → Tickets). Afecta a todos los tickets, incluidos los de las plantillas del Editor.
- **Reserva hotel «por fecha»** (sustituye a la reserva por horas): al emitir el ticket aparece la fecha de entrada (la actual) con el botón **Cambiar fecha de entrada**, y la fecha de salida reservada. Entre ambas fechas no se cobra; antes de la entrada reservada y después de la salida se cobra con la tarifa indicada. El ticket muestra «Reserva desde / hasta». Las tarifas de reserva por horas ya creadas pasan a «por fecha».
- **Orden de las tarifas:** Flechas ↑ ↓ en Ajustes → Precios → Tarifas para cambiar el orden en que salen en el selector de Entrada.

## 4.42 — 15 de octubre de 2026

- **Se retira el tema «Negro y amarillo»** Añadido en la 4.41. El tema vuelve a ser claro, oscuro o automático.
- **Nuevo color de acento «Amarillo»** (Ajustes → Empresa → Aspecto → Color), con botones amarillos y texto oscuro, en tema claro y oscuro.
- **Novedades en la actualización:** Al buscar actualizaciones online (Drive), el texto de lo nuevo ya aparece antes de descargar; se lee del propio paquete. Si no se pudiera leer, se avisa de que se mostrará al descargar.

## 4.41 — 15 de octubre de 2026

- **Tema «Negro y amarillo»** De alto contraste: fondo negro, texto y bordes amarillos, botón principal en amarillo. Se elige en Ajustes → Empresa → Aspecto (para todo el programa) o desde Herramientas en cada puesto, que ahora rota entre claro, oscuro y negro y amarillo.

## 4.40 — 15 de octubre de 2026

- **Tema y densidad por puesto:** En «Herramientas» hay dos interruptores rápidos: tema claro/oscuro (para turnos de noche) y densidad compacta/cómoda. Se guardan en ese equipo y no cambian los Ajustes del resto.
- **Densidad automática:** Si no se elige, es compacta en monitores pequeños y cómoda en pantallas táctiles. Antes el modo compacto solo se podía activar para todo el programa desde Ajustes.

## 4.39 — 15 de octubre de 2026

- Se quita el botón «Reimprimir ticket de entrada» de la pantalla de cobrado.

## 4.38 — 15 de octubre de 2026

- **Deja las llaves:** Nueva casilla en Entrada (marcada por defecto). Si está marcada, el ticket dice «(nombre del parking) se queda con las llaves», también al reimprimirlo. Se puede ocultar o dejar desmarcada por defecto en Ajustes → Tickets.
- **Ticket de entrada:** La matrícula pasa arriba, en grande, y la hora de entrada a una línea normal debajo. Sin matrícula se mantiene la hora grande.
- **Anular ticket:** El motivo es opcional.
- **Imprimir ticket de salida:** Empieza desmarcado en cada cobro y ya no recuerda la última elección. En Ajustes → Tickets se puede marcar por defecto.
- **Ver recibo** (tras cobrar): nuevo botón **Imprimir**.
- **Tras cobrar** Se puede **reimprimir el ticket de entrada**.
- Se quita el ajuste «Matrícula en grande» (ahora siempre lo está).

## 4.37 — 14 de octubre de 2026

Revisión de accesibilidad e interfaz (guía Web Interface Guidelines).

- **Teclado y lectores de pantalla:** Botones solo con símbolo (✕, −, +, ⌫) con nombre accesible; «Acerca de» y «Aplicaciones externas» son botones reales; adornos ocultos para lectores; enlace «Saltar al contenido».
- **Foco:** Anillo de foco visible en todo el programa; las ventanas atrapan el tabulador, tienen título asociado y devuelven el foco al cerrarse.
- **Movimiento y táctil:** Respeta «reducir movimiento» del sistema; sin zoom por doble toque; el desplazamiento de una ventana ya no mueve la pantalla de fondo.
- **Quitar un servicio** En la pantalla de cobro ahora ofrece «Deshacer».
- **Detalles:** El color de la barra del navegador sigue al tema; marcadores con «…»; sin autocorrección en matrículas; en pantallas táctiles las ventanas ya no abren el teclado solas.

## 4.36 — 14 de octubre de 2026

- **Ajustes: Los apartados vuelven a ser las tarjetas de siempre** (nombre + descripción en cada botón). Se mantiene el buscador de ajustes de la 4.35.

## 4.35 — 14 de octubre de 2026

- **Barra superior más ordenada**: A la izquierda el estado (nombre, plazas), a la derecha avisos, turno y usuario. «Pantalla del cliente» y «Última impresión» pasan a un único menú **Herramientas ▾**; la barrera y la campana de avisos siguen a la vista.
- **Ajustes con buscador**: Escriba «impresora», «IVA», «tarifa», «copias»… y salta a la pestaña que corresponde (Intro abre la primera; Esc limpia). Entiende sinónimos y acentos.
- **Menos navegación en Ajustes**: Los apartados son ahora una fila compacta de botones (la descripción pasa a ser ayuda al pasar el ratón) y se ven antes las pestañas y el formulario.

## 4.34 — 14 de octubre de 2026

- **Acciones de fila con una sola regla en todo el programa**: Una acción principal visible y el resto en el menú **⋯**; lo que borra o anula va siempre al final, en rojo y separado. Aplicado ya en Vehículos dentro, Reservas, Lista negra, Bonos del cliente (Cobrar + «Cancelar deuda» / «Anular bono»), Servicios y productos, Tarifas, Descuentos, Vales, Zonas y Botones de aplicaciones. El menú no se corta dentro de tablas con desplazamiento ni de ventanas, se abre hacia arriba si no cabe debajo y se cierra al pulsar fuera, con Esc o al desplazarse.
- **Aviso de licencia más discreto**: Durante la prueba solo se muestra la línea «Prueba: N días» del menú lateral; la franja de aviso aparece **solo en los últimos 3 días** (o si falta poco para que caduque una licencia) y es más baja. Si se cierra, **no vuelve hasta el día siguiente** (antes volvía a los 5 minutos).
- **Coherencia de colores y textos**: Azul = acción principal (Instalar, Descargar e instalar, Abrir WhatsApp, Cargar copia), verde = cobrar o registrar entrada/salida, rojo = anular/eliminar, gris = secundaria. Textos con verbo y más claros: «Ver ficha», «Ver o enviar», «Datos y envío», «Ver o cerrar turno», «Cancelar reserva», «Retirar de la lista negra», «Quitar zona»…

## 4.33 — 14 de octubre de 2026

- **Sección «Actualización lista para instalar» rediseñada**: Arriba se ve de un vistazo de qué versión a cuál se actualiza (p. ej. 4.25 → 4.32), la fecha, el tamaño y cuántas novedades trae; el botón principal (**Instalar** / **Descargar e instalar**) queda siempre a la vista.
- **Novedades legibles**: Ocupan todo el ancho en **una sola columna**, con una zona de desplazamiento propia (la cabecera de cada versión se queda fija mientras se desplaza) en lugar de columnas estrechas cortadas por el borde de la pantalla.
- El mismo diseño se usa en el resultado de **Buscar actualizaciones online** y en la confirmación previa a instalar.

## 4.32 — 14 de octubre de 2026

- **Vehículos dentro: Acciones agrupadas**: Cada fila muestra solo **Cobrar** y un menú **⋯**. El menú reúne «+ Servicio o producto», «Cambiar matrícula», «Cambiar tarifa», «Cambiar zona» y «Reimprimir ticket», y deja **«Anular ticket»** al final, en rojo y separado, para evitar pulsaciones por error. Se cierra al elegir, al pulsar fuera o con Esc.

## 4.31 — 14 de octubre de 2026

- **Servicio personalizado solo para la venta en curso**: En *Añadir servicio o producto* hay un cuadro «Servicio personalizado» (descripción, precio, IVA y cantidad). Se añade únicamente a ese cobro y a su factura; **no se guarda en el catálogo**. También funciona si el catálogo está vacío.
- **«Ticket perdido…» sustituido por «Anular ticket…»** En la pantalla de Salida: se busca el vehículo por matrícula o código y se anula su ticket (con motivo y, si el usuario no es supervisor, la autorización de un supervisor). Solo tickets dentro y sin cobros. Se quita el apartado «Ticket perdido» de Ajustes → Empresa y cobro.

## 4.30 — 14 de octubre de 2026

- **El programa se abre maximizado**: La ventana de la aplicación arranca a pantalla completa de trabajo (sin tapar la barra de tareas). Se pide al abrir Edge (`--start-maximized`) y, si el navegador no lo respeta, la propia pantalla de carga y la aplicación ajustan la ventana al tamaño disponible de la pantalla.

## 4.29 — 14 de octubre de 2026

- **Aviso de actualización al arrancar**: En cada arranque el programa busca (a los pocos segundos) si hay una versión nueva online y, si la hay, deja el aviso en las notificaciones. Antes esperaba hasta 40 s y podía saltarse la búsqueda si ya se había hecho el mismo día.
- **«Novedades desde la versión…» completas**: Con el paquete descargado, las novedades salen de su propio CHANGELOG e incluyen **todos los cambios nuevos** desde la versión instalada.
- **Pantalla de carga con logo y nombre**: El logo y «PROYECTO ALLAS» aparecen en la barra y en el centro de la pantalla.

## 4.28 — 14 de octubre de 2026

- **Imprimir o no el ticket de salida**: En *Ajustes → Tickets* hay una casilla «Imprimir el ticket de salida al cobrar», y la pantalla de cobro tiene la misma casilla encima del botón *Cobrar*. Lo que se marca se **guarda al pulsar «Siguiente»** y vale para los cobros siguientes.
- Si no se imprime, el cobro se registra igual, **el cajón se abre** en efectivo y el recibo se puede **ver en pantalla** («Ver recibo»). Las salidas manuales siguen el ajuste de Tickets; los recibos de tienda y bonos no cambian.

## 4.27 — 14 de octubre de 2026

- **Pantalla de carga con el diseño del programa**: Al arrancar se abre al instante una pantalla (`web/cargando.html`) con la misma barra oscura con la «P», el fondo, el azul y la tipografía del software, y una barra de progreso. En cuanto el servidor responde **salta sola a la aplicación**. Si hay un error o el servidor no responde, avisa en rojo, cierra la pantalla de carga y abre la ventana de comandos de diagnóstico. Sustituye a la ventana propia de 4.18/4.23.
- **Novedades de la actualización legibles antes de instalar**: La pestaña usa todo el ancho de la pantalla (también maximizada) y las novedades se reparten en columnas; además, al pulsar *Instalar* o *Descargar e instalar* se muestran **dentro de la confirmación**, en un cuadro con desplazamiento.
- **Eliminado «Versiones anteriores instaladas»** De la pestaña Actualizaciones.
- **«Buscar actualizaciones online» activado de fábrica** En Supervisión (en instalaciones anteriores se activa una sola vez al actualizar; se puede volver a ocultar).

## 4.26 — 14 de octubre de 2026

- **Impresoras de Windows detectadas solas**: En *Ajustes → Tickets → Impresoras y cajón* el programa lee las impresoras instaladas en el equipo y las ofrece en una lista (con «↻ Buscar»). Las **térmicas de tickets** (POS, Epson TM, Star, Bixolon…) salen primero y las virtuales (PDF, OneNote) al final; la predeterminada va marcada. Si el destino está sin configurar, se propone sola la impresora de tickets detectada («Pulse Guardar para usarla»). La *Impresora A4 de facturas* usa la misma lista. Siempre se puede escribir otro nombre.
- **Asistente de primer inicio más pequeño**: Ahora **entra entero en pantalla** (también en pantallas bajas, ~620 px) sin desplazarse: tarjeta más compacta y los datos del parking en dos columnas.

## 4.25 — 14 de octubre de 2026

- **Versiones anteriores: Solo las instaladas en este equipo**: La lista «Versiones anteriores instaladas» muestra únicamente las versiones que se instalaron **como actualización** en este equipo (con la fecha de instalación), no todo el historial del programa. Pulse en una para ver sus novedades.
- **Changelog con formato más cuidado**: Cada versión lleva su cabecera (píldora azul con el número y la fecha), los apartados se distinguen y cada novedad es una **tarjeta** con el título en negrita y el detalle debajo en gris. Vale para «Novedades desde la versión X», «Buscar actualizaciones online» y las versiones anteriores.

## 4.24 — 14 de octubre de 2026

- **Búsqueda automática de actualizaciones**: El programa busca una versión nueva **unos segundos después de arrancar y, después, una vez al día**. Si la hay, aparece un aviso en **notificaciones** («Hay una nueva versión: X») con botón *Ver* que lleva a Ajustes → Sistema → Actualizaciones. Si no hay Internet, simplemente no avisa. Se respeta la opción de ocultar la búsqueda online (Supervisión); ajuste interno `actualizaciones_auto` = 0 para desactivarla. Una búsqueda manual también refresca el aviso. No se hace en modo demostración.
- **Pantalla de cliente mejor organizada** (visor y segundo monitor, sin cambiar su funcionamiento): barra de secciones fija arriba — *General · Visor TPV · Aspecto del monitor · Fotos* — que lleva directamente a cada bloque y oculta las que no aplican al modo elegido.

## 4.23 — 14 de octubre de 2026

- **Barra de carga con la imagen del programa**: La ventana de arranque usa ahora el mismo estilo que el software (barra superior oscura con la «P» azul, fondo gris claro, barra de progreso en azul señal y tipografía del sistema); en caso de error se vuelve roja y avisa de que se abre la ventana de diagnóstico.
- **Versiones anteriores: Solo novedades**: Ya **no se puede restaurar** ninguna versión desde el programa (ni con «Volver», ni instalando un paquete anterior; el servidor lo rechaza). El cuadro pasa a llamarse «Novedades de versiones anteriores» y muestra, al pulsar cada versión, qué trajo (leído del historial del programa).

## 4.22 — 14 de octubre de 2026

- **Solo se ofrece la última actualización**, Tanto en «Actualización lista para instalar» como en el resultado de «Buscar actualizaciones online» (aunque haya varias versiones nuevas publicadas).
- **Novedades acumuladas**: Cada actualización muestra un desplegable «Novedades desde la versión X» con **todos los cambios desde la versión instalada** hasta la última (si se salta de la 4.20 a la 4.22, salen la 4.21 y la 4.22). Se lee del historial que viaja dentro del paquete firmado, y en la búsqueda online se reúne con las notas de cada versión nueva.

## 4.21 — 14 de octubre de 2026

- **Volver a una versión anterior también con paquete**: Además de las copias guardadas al actualizar, ahora se puede **instalar el paquete firmado de una versión anterior** (subido o en la carpeta) con «Volver a esta versión». Antes el programa lo rechazaba («ya tiene la … o posterior»). Se hace copia de seguridad y los datos no se tocan.
- **Pestaña Actualizaciones reordenada**: (1) versión instalada con «Buscar actualizaciones online» y «Subir paquete…»; (2) «Actualización lista para instalar», que **solo aparece si hay una**; (3) «Versiones anteriores», una única lista con «Volver a esta versión». Desaparecen «Paquetes disponibles», «Paquetes ya instalados» y los textos largos.

## 4.20 — 14 de octubre de 2026

- **Actualizaciones en un solo cuadro**: «Buscar actualizaciones online» y «Subir paquete…» (local) están ahora juntos, junto a la versión instalada. Debajo, en el mismo cuadro, aparecen el resultado de la búsqueda y los paquetes disponibles. «Paquetes ya instalados» sigue aparte.

## 4.19 — 14 de octubre de 2026

- **Segunda pantalla reorganizada**: En **entrada** y **salida** la **matrícula va en el centro**, grande y con aspecto de placa (franja azul europea, brillo y borde). Debajo, los datos (entrada, tiempo, tarifa u hora de entrada) en **fichas**; en la salida, una **banda inferior** con el total a pagar a la izquierda y el desglose, lo entregado y el cambio a la derecha. Etiqueta «Entrada/Salida de vehículo» arriba y aviso «Recoja su ticket» en la entrada. Se adapta a 720p y a pantallas verticales.

## 4.18 — 14 de octubre de 2026

- **Arranque con barra de progreso**: Al abrir `ARRANCAR.bat` ya no se ve una ventana negra de comandos. Aparece una ventanita con una **barra de progreso** mientras el servidor carga; al estar listo se cierra sola y se abre el programa.
- **Si hay un error o el servidor se para** (se cierra al arrancar o no responde en 60 s), la barra avisa y se abre una **ventana de comandos de diagnóstico** (`scripts\DIAGNOSTICO.bat`) con el motivo, las últimas líneas de `datos\servidor.log` y el servidor arrancado a la vista para ver el error.
- `scripts\ARRANCAR_CON_VENTANA.bat` sigue arrancando con ventana de servidor visible. Modo quiosco y arranque con Windows funcionan igual.

## 4.17 — 14 de octubre de 2026

- **Actualizaciones sin jerga técnica**: La pantalla de actualizaciones muestra solo **«Buscar actualizaciones online»** y **«Subir paquete…»** (local). Desaparecen el selector de origen, la dirección del servidor y cualquier mención a Drive o servidor; los mensajes de error también son neutros («servicio de actualizaciones»).
- **El origen se configura internamente**: `actualizaciones_origen` (`servidor`/`drive`), `actualizaciones_url` y la carpeta/clave siguen existiendo como ajustes internos (distribuidor). Si no se indica origen, se usa el servidor si hay dirección configurada y, si no, la carpeta integrada.

## 4.16 — 14 de octubre de 2026

- **Actualizar online desde una carpeta de Google Drive** (*Ajustes → Sistema → Actualizaciones → Buscar actualizaciones online → Google Drive*). El distribuidor sube los paquetes firmados (`PROYECTO_ALLAS_actualizacion_X.Y.zip`, la versión va en el nombre) a su carpeta de Drive; el programa lista las versiones, muestra cuáles son nuevas y las descarga con **Descargar** o **Descargar e instalar** (copia de seguridad + instalación + reinicio, como siempre). **La carpeta va integrada en el programa y no se muestra en ninguna pantalla** ni sale por la API: el usuario no tiene que escribir ningún enlace. Sigue pudiendo usarse el servidor del distribuidor (se elige con un selector).
- **Seguridad igual que antes**: Un paquete solo se guarda si lleva la **firma del fabricante**; aunque alguien cambiase un archivo de la carpeta, no se instalaría. Sin clave de API (lo normal) se lee el listado público de la carpeta; si hiciera falta, existe el ajuste oculto `actualizaciones_drive_clave` (clave de la API de Drive v3), que nunca sale hacia la pantalla.
- **Paquetes disponibles y paquetes ya instalados, por separado**: *Paquetes disponibles* solo muestra los **más nuevos** que la versión instalada (descargados y comprobados, con *Instalar*); *Paquetes ya instalados* muestra la versión actual, las versiones anteriores a las que se puede **volver** y, desplegable, los paquetes ya aplicados que siguen en la carpeta. Los resultados de la búsqueda online dicen si cada versión es nueva, está ya descargada, es la instalada o es anterior.

## 4.15 — 14 de octubre de 2026

- **Visor TPV: Asistente «Ajustar las letras del visor»** (*Ajustes → Tickets → Pantalla de cliente*). Cuando las letras salen raras casi siempre es la velocidad (baudios) o el protocolo, y antes había que adivinarlo. Ahora el asistente escribe en el visor `ABCDEFGHIJKLMNOPQRST` y, en la segunda línea, la combinación que está probando (p. ej. *9600 ESC/POS Epson*); usted mira el visor y pulsa **Se lee bien: usar este ajuste** o **probar otro**. Recorre 4 protocolos × 7 velocidades, empezando por lo que ya tenía puesto, y guarda lo elegido.
- **Envío por puerto COM más fiable en Windows**: El programa ya no depende del comando `mode`; abre el puerto con la API del sistema, fija velocidad, bits, paridad y parada en cada envío y lo suelta (no bloquea otros programas). Nuevo ajuste avanzado **Bits y paridad** (8N1 de serie; 7E1, 7O1, 8E1, 8O1, 7N1, 8N2 para visores que lo piden).
- **Símbolos que salían como «?»**: «·», «—», «…», las comillas tipográficas y « » ahora salen como `-`, `...` y `"` en el visor (los visores solo tienen ASCII). Antes un texto como «Abierto 24 h · Bienvenido» salía con signos de interrogación.
- **Visor de muestra rehecho**: Una celda por carácter, con letra de ancho fijo y sin recortes, como un visor de 20×2 de verdad; así las letras se leen siempre y se ve exactamente lo que recibe el visor.
- **Panel del visor más ordenado**: Conexión y puerto, textos de reposo, efecto, y los dos botones (*Probar el visor* y el asistente). Velocidad, protocolo, bits y caracteres quedan en *Ajustes avanzados*.
- **Fotos del segundo monitor: «Se ve» pasa a «Ocultar»** (marcado = la foto no se muestra; la tarjeta enseña la etiqueta «Oculta» solo cuando lo está).
- **17 imágenes de ejemplo de diseño plano** (colores lisos, formas sencillas, sin degradados ni texto): señal de parking, plazas vistas desde arriba, coche eléctrico, reloj 24 h, vigilancia, tarifas, bici y moto, coche bajo paraguas, ubicación, accesibilidad, acceso seguro, ticket, edificio… En la carpeta `imagenes_ejemplo`. Las cuatro de «Poner fotos de ejemplo» también pasan a diseño plano.

## 4.14 — 14 de octubre de 2026

- **Miniaturas de las fotos rehechas** (*Ajustes → Tickets → Pantalla de cliente*): cada tarjeta enseña la foto con su **número** y una etiqueta **Se ve / Oculta**; al **pulsar la miniatura se abre la foto grande**, con flechas (también las del teclado) para pasar de una a otra y *Esc* para cerrar. Si una miniatura no carga, la tarjeta dice **por qué** (p. ej. «la petición fue bloqueada (¿un bloqueador de anuncios del navegador?)») y tiene un botón **Reintentar**.
- **Causa probable de que no se vieran las fotos**: Los bloqueadores de anuncios del navegador (uBlock, AdBlock, listas «EasyList España»…) filtran direcciones con la palabra *publicidad* y elementos con clase *anuncio*, justo lo que usaba el programa. Ahora las fotos se piden en `/api/pantalla-cliente/foto/<id>` y la pantalla de cliente usa las clases `diapo`/`diapos`. La dirección antigua sigue funcionando. Si aun así tu navegador las bloquea, la pantalla lo dirá y bastará con añadir esta dirección a las excepciones del bloqueador.

## 4.13 — 14 de octubre de 2026

- **Pantalla de cliente: Las fotos se gestionan de otra forma.** Antes cada foto era una imagen suelta que el navegador cargaba cuando quería y, si fallaba, se quedaba solo el texto de bienvenida sin explicación. Ahora la pantalla **descarga primero cada foto**, comprueba que el navegador sabe dibujarla y **solo entonces** la pone en la rotación. Las que fallan se **reintentan solas** en cada vuelta (cada 20 s) y la pantalla de bienvenida dice **qué ha pasado** («No se han podido cargar 2 de 2 foto(s): el servidor respondió 500», «tardó demasiado», «formato de imagen no válido») o, si no hay ninguna, «No hay fotos de publicidad activas: se añaden en Ajustes». Una foto estropeada ya no bloquea las demás.

## 4.12 — 13 de octubre de 2026

- **Pantalla de cliente reorganizada, sin botones repetidos** (*Ajustes → Tickets → Pantalla de cliente*): quitado el botón **Guardar** (todo el formulario se **guarda solo** al cambiarlo, con el aviso «Guardado ✓»), los dos botones de *Abrir la pantalla de cliente* (queda uno solo, **Abrir en el segundo monitor**, en el panel del monitor), *Probar el visor* + *Ver el efecto* (queda **Probar el visor**; si el visor no responde, lo enseña igualmente en el visor de muestra y dice el motivo) y los dos botones de fotos de ejemplo (queda uno que alterna **Poner / Quitar las fotos de ejemplo**).
- **Segundo monitor con el modo «Visor»**: Antes el panel de fotos desaparecía y parecía que las imágenes «no cargaban»; ahora se explica que en ese modo no se usa el monitor y cómo activarlo (*Segundo monitor* o *Los dos*).
- **Fotos más fiables**: Al **añadir fotos** se reducen a 1920 px y se baja la calidad hasta que pesen menos de 1,2 MB (antes una foto grande podía rechazarse), cada foto se procesa por separado y se avisa de cuántas se añadieron y de cuáles fallaron. La pantalla de cliente **reintenta** una imagen que no carga y, si sigue fallando, muestra el rótulo sin ella.
- **Visor en modo «Archivo»**: Si el destino era un puerto (`COM3`) o una IP, se crea la carpeta de pruebas `salida_visor` en lugar de una carpeta llamada como el puerto (en Windows «COM3» es un nombre reservado y no se puede crear ni descomprimir).
- **Carpeta `imagenes_ejemplo`** (junto a la carpeta de la aplicación): 8 imágenes 16:9 listas para cargar con **Añadir fotos…**. Ajustes indica su ruta (`GET /api/publicidad/carpeta-ejemplos`).

## 4.11 — 13 de octubre de 2026

- **Visor TPV más sencillo** (*Ajustes → Tickets → Pantalla de cliente*): quitado el selector de **modelo de visor**. En su lugar, el **puerto COM** se elige en una lista con los **puertos que detecta el equipo** (con el nombre del dispositivo, p. ej. *COM3 · USB Serial Port*, y «en uso» si otro programa lo ocupa), con el botón **↻ Buscar** para volver a mirar al conectar el visor. Si no hay ninguno elegido se pone el primero libre, y *Escribir otro…* permite teclearlo. Protocolo (ESC/POS), velocidad (9600) y caracteres por línea (20) pasan a **Ajustes avanzados del visor**, ya puestos con los valores de casi todos los visores.
- **Efectos en el visor**: *Desplazar el texto* (los textos largos salen enteros aunque el visor tenga 20 caracteres), *Parpadear*, *Escribir letra a letra* y *Entrar por la derecha*, con velocidad lenta, normal o rápida. Se aplican a los **mensajes de texto** (reposo, bienvenida y despedida); los **importes, el cambio y la matrícula salen siempre fijos**. Los efectos funcionan con cualquier visor de texto (el programa reenvía el texto cuadro a cuadro) salvo con el *programa del fabricante*, donde se desactivan.
- **Probar el visor** Usa lo que hay en pantalla sin necesidad de guardar, y el visor de muestra de Ajustes **reproduce el efecto**; **Ver el efecto** lo enseña sin enviar nada (para quien aún no tiene el visor conectado).

## 4.10 — 12 de octubre de 2026

- **Planes de licencia reordenados**, De menor a mayor: **Lite · Básico · Abonados · Básico plus · Profesional · Completo**. Así salen en el Gestor de licencias (al emitir) y en *Supervisión → Tipo de licencia*.
- **Dos planes con nombre nuevo**: *Solo abonados* ahora se llama **Abonados** y *Solo entradas y salidas* se llama **Básico plus**. Solo cambia el nombre: las licencias ya emitidas siguen valiendo y con los mismos módulos.
- **Un color por plan**: Cada tipo de licencia tiene el suyo (Lite gris, Básico azul, Abonados violeta, Básico plus verde azulado, Profesional naranja, Completo verde). Se ve en una etiqueta junto a la versión (menú lateral y pantalla de acceso), en los botones de plan de *Supervisión* y, en el **Gestor de licencias 1.11**, en los botones de plan al emitir y en la lista de licencias. La prueba, la demostración y «sin licencia» también tienen color propio.

## 4.9 — 12 de octubre de 2026

- **Plantillas de tickets y facturas**: Ahora se pueden **cambiar el diseño** de la entrada, el recibo, el recibo de bono, la tarjeta de abonado y la factura A4. Se diseñan en un programa aparte, el **Editor de plantillas** (se entrega en su propia carpeta, sirve también para otros programas) y se cargan en *Ajustes → Tickets* y *Ajustes → Factura* (*Plantillas del Editor de plantillas* → **Cargar plantilla…**). También se puede **descargar** la plantilla en uso (o la de serie, como punto de partida) y **volver al diseño de serie**.
- **Formato abierto**: La plantilla es un archivo **JSON** (`allas-plantilla`, descrito en `docs/PLANTILLAS.md`). En los tickets, una lista de bloques (cabecera, texto, línea con valor, separador, espacio, logo, código QR/barras y repetición de listas) con campos como `{matricula}` o `{total}` y condiciones («imprimir solo si…»). En la factura A4, colores, tamaño del logo, qué secciones y columnas se ven, textos y rótulos.
- **El diseño de serie no cambia**: Está comprobado que, sin plantilla, todos los documentos salen exactamente igual que en la 4.8 y que la plantilla de serie del editor imprime lo mismo que el diseño interno. Una plantilla dañada nunca impide imprimir (se usa el diseño de serie). Los datos fiscales, el desglose de IVA y el QR VERI*FACTU de las facturas no se pueden quitar.
- Solo el administrador puede cargar o quitar plantillas, y queda en la auditoría.
- **Editor de plantillas 1.0** (carpeta aparte, sin instalar nada más que Python): bloques que se arrastran, campos que se insertan con un clic, datos de ejemplo editables, vista previa del ticket con el ancho de papel elegido y vista previa real del PDF de la factura. Guarda y abre archivos `.json`. Solo escucha en el propio ordenador.

## 4.8 — 12 de octubre de 2026

- **Cambiar el tipo de licencia desde Supervisión** (*Sistema → Supervisión → Tipo de licencia*): el programa se puede usar como un tipo **igual o más reducido** que el contratado (por ejemplo, una licencia *Completo* o *Profesional* usada como **Lite**) y volver a «Según la licencia» cuando se quiera. No se borra nada; los módulos recortados salen como *Desactivado* en *Licencia → Módulos*, el tipo elegido aparece junto a la versión y el cambio queda en la auditoría. Para ampliar hace falta una licencia nueva.
- **Contraseña de Supervisión de fábrica: 8888**, Mientras no se haya fijado ninguna (ni maestra ni propia de la licencia). Al entrar con ella se avisa de que hay que cambiarla en el **Gestor de licencias 1.10**; en cuanto llega otra, la 8888 deja de servir.
- **Puertos sin conflictos**: En la primera instalación se comprueba qué puertos están libres (8080, 8090, 8765…) y se guarda el primero que lo esté para los siguientes arranques. Si más adelante otro programa ocupa ese puerto, se usa el siguiente libre y se avisa. En Windows el puerto se abre **en exclusiva**, para que dos programas no puedan compartirlo por error.

## 4.7 — 12 de octubre de 2026

- **Licencia Lite**: Lo mínimo para cobrar por horas (Entrada, Salida, vehículos dentro, caja y turno, tarifas, ticket, informe resumen y copias). Todo lo demás pasa al nuevo módulo **Gestión ampliada**, que llevan todos los demás planes y todas las licencias ya emitidas. Se emite con el **Gestor de licencias 1.9**.
- **Tipo de licencia junto a la versión** (menú lateral y pantalla de acceso): *versión 4.7 · Lite*, *· Completo*, *· Prueba*…

## 4.6 — 12 de octubre de 2026

- **Código de la interfaz unificado** Para que el programa sea más estable y fácil de mantener: los 26 archivos que se habían ido añadiendo versión a versión pasan a 20 archivos ordenados por áreas (Entrada, Salida, Vehículos, Clientes, Caja, Tienda, Facturas, Informes y cada apartado de Ajustes). Cada pantalla se pinta de una vez, sin «parches» encadenados entre versiones, y se ha quitado el código y los estilos que ya no se usaban.
- Se ha comprobado automáticamente que las 117 pantallas, pestañas y ventanas del programa se ven y funcionan igual que en la 4.5 (mismo contenido y mismo aspecto, en tema claro y oscuro, en pantalla pequeña y con un cajero).
- Corregido: En *Preferencias y numeración*, el panel de numeración podía salir en otro sitio (o tardar en salir) según lo que tardara el servidor en responder; ahora sale siempre en su sitio y, al guardarlo, no se mueve.
- Barrera y Datáfono, y Cobro online de bonos y Avisos por email, son ahora pantallas independientes (antes compartían formulario).

## 4.5 — 11 de octubre de 2026

- **Pantalla de cliente más clara**: Dos partes numeradas (*1 · Pantalla de cliente* y *2 · Publicidad del segundo monitor*), **vista previa real** de la pantalla del cliente, fotos en miniatura que ahora sí se ven, con flechas para ordenarlas, y los cambios de la presentación se guardan y se ven al momento (también en la pantalla del cliente ya abierta).
- **Zonas con color**: Cada zona tiene su color; en Entrada se elige con botones de color y se ve en Vehículos dentro y en Salida.
- **Cambiar de zona** Un vehículo que ya está dentro (*Vehículos → Zona* o *Salida → Cambiar zona*), sin pasar de la capacidad.
- **Arrancar con Windows** (*Sistema → Servidor*): abrir el programa al iniciar Windows, en modo **normal** o **quiosco**.
- **Supervisión**: *Guardar y aplicar* recarga solos los demás puestos; *Marcar todo* y *Restablecer valores de fábrica*.
- **Barrera**: Quitado el texto sobre la nueva ubicación del datáfono.
- **Licencias**: Dos modos nuevos, **Solo abonados** (sin tickets por horas) y **Solo entradas y salidas** (sin gestión de abonados). Nuevo módulo *Entradas y salidas por horas*; las licencias ya emitidas lo conservan. Necesita el **Gestor de licencias 1.8** para emitirlas.

## 4.4 — 11 de octubre de 2026

- **Supervisión** (*Sistema → Supervisión*): menú reservado al fabricante o instalador, con contraseña **maestra** (Gestor de licencias 1.7) o **propia de cada licencia**. Oculta menús, pestañas y opciones que el parking no necesita. De fábrica quedan ocultas la búsqueda de actualizaciones online y la comprobación online de la licencia.
- **Importar y exportar** En su propia pestaña (aparte de las copias): tarifas, servicios y productos **por separado**; abonados y clientes sin abono **por separado**; y **Borrar los clientes sin abono** de una vez (las facturas emitidas no cambian).
- **Abonados y clientes sin abono** Bien diferenciados en *Clientes y bonos* (con su número y filtros propios), en las fichas y en las exportaciones.
- **Cobro online de bonos (Stripe)** Pasa a *Conexiones*; en *Abonados* quedan los avisos y facturas por email.
- **Logo y opciones del ticket y de la factura**, Cada uno en su menú: la factura PDF tiene su propio logo (en color) y su título; email y web de la empresa, en *Empresa → Datos*.
- **Pantalla de cliente**: Fotos de publicidad de ejemplo (se pueden quitar) y presentación a medida: transición, duración, segundos por foto, orden aleatorio, encaje, rótulo, tema claro u oscuro, color, movimiento, barra de progreso y pie.
- **Semáforo y cartel LIBRE / COMPLETO** (desactivados de inicio): por relé de red, USB/COM o programa, con margen de plazas y por zona.
- **Impresora A4 para las facturas**: Abrir el PDF, impresora de Windows, programa (SumatraPDF) o carpeta; botón *Imprimir en A4*.
- **Caja móvil con cámara**: Leer el QR o el código de barras del ticket o la tarjeta y la matrícula (OCR de Windows en el PC del parking).
- **Estabilidad**: Vigilante que vuelve a arrancar el programa si se cae o deja de responder, comprobación de la base de datos al arrancar, registro de errores de las pantallas y opción de **Python incluido** en la carpeta del programa.
- *Subir una copia (.db)* es ahora un botón; *Actualizaciones* va antes que *Licencia*; la *Tienda* queda separada en el menú lateral.

## 4.3 — 11 de octubre de 2026

- **Reservas de plataformas** (*Vehículos → Reservas*): importar el listado de Parclick, ElParking, Parkimeter, el hotel o la web (Excel o CSV, columnas reconocidas solas, vista previa y sin duplicados) o apuntarlas a mano. Al entrar esa matrícula, el ticket sale solo con la tarifa de reserva.
- **Pago con el móvil**: QR «Pague con su móvil» en el ticket; el cliente paga con tarjeta, Apple Pay o Google Pay (Stripe) y sale sin pasar por la caja. Desde Internet solo responde la página de pago.
- **Cierre diario por email** Al cerrar el último turno, con el **libro de facturas** adjunto; libro de facturas por fechas en CSV para la gestoría.
- **Alertas en la campana**: Casi lleno o zona completa, vehículos muchos días dentro, demasiado efectivo en una caja, abonado caducado que entra y matrícula de la lista negra leída por la cámara.
- **Estadísticas con gráficos**: Ingresos por día frente al periodo anterior, ticket medio, estancia media, rotación, ocupación por hora, mapa de calor de entradas por día y hora, tarifas, servicios y tipos de vehículo.
- **Tarifas por tipo de vehículo** (botones Coche / Moto / Furgoneta… en Entrada) y **tarifas de evento** con precio cerrado por día.
- **Plazas y zonas**: Capacidad por planta o sector, completo por zona y plazas reservadas para abonados.
- **Ticket digital** Por SMS o WhatsApp en lugar del papel.
- **Estado del vehículo al entrar**: Notas y fotos (móvil, tablet o cámara del PC), visibles al cobrar.
- **Permisos a medida** Por usuario, además del rol.
- **Auditoría con filtros** (fechas, usuario, acción, texto) y exportación a CSV.
- **Copia de seguridad cifrada en la nube** (carpeta de OneDrive/Google Drive/Dropbox o WebDAV), con recuperación.
- Nuevo **icono de avisos** (campana de línea, a juego con el resto del programa).

## 4.2.1 — 11 de octubre de 2026

- **Entrada** Con las mismas proporciones que **Salida** (columna de datos ancha y columna derecha fija): las dos pantallas ya no se descuadran al cambiar de una a otra.
- **Reserva / hotel** Con un diseño más claro y centrado: cabecera con icono, *Noches* «o» *Hasta (fecha y hora)* alineados, nº de reserva debajo y aviso al momento de **hasta cuándo no se cobra** (también al aplicar la reserva en Salida).

## 4.2 — 11 de octubre de 2026

- **Tarifa de reservas / hotel**: El tiempo reservado (pagado en el hotel o en la web de reservas) no se cobra; pasado, se cobra desde el fin de la reserva con la tarifa del parking. Noches con hora de salida, horas o fecha exacta y nº de reserva/habitación, en Entrada, en Salida (*🏨 Reserva…*), en el ticket y en la factura.
- **Tarifa de precio fijo + después** (p. ej. 3 € las 2 primeras horas y 1,50 € cada hora más).
- **Devoluciones** Y **Rectificación de facturas** se activan por separado.
- *Aplicaciones externas* pasa a **Empresa**; el **Datáfono** a **Conexiones** (la Barrera sigue en Tickets).
- **Más personalización**: Diseño del ticket (tamaño del nombre, separadores, qué datos mostrar, matrícula grande, cajero, papel antes del corte) y nueva pestaña **Factura (PDF)** con colores, logo, títulos, email/web, notas (IBAN, condiciones) y pie, con vista previa.
- **Confirmación al cerrar** La ventana con la X (configurable).
- **Datos del fabricante**: Van también dentro del archivo .lic y se pueden cargar en *Ajustes → Licencia*; el Gestor 1.6 permite descargar `fabricante.json` desde cada licencia.

## 4.1 — 11 de octubre de 2026

- **Acerca de**: Al pulsar *PROYECTO ALLAS* en el menú se ve el copyright y los derechos reservados, el logo y los datos de contacto del creador del software (con enlace a su web) y los datos de la licencia (titular, nº, plan, validez, módulos, ID del equipo). Esos datos se escriben en el **Gestor de licencias 1.5** y llegan firmados con las actualizaciones, la comprobación online o un archivo `fabricante.json`.
- **Aplicaciones externas**: Apartado nuevo en el menú lateral con botones que abren una web o un programa, documento o carpeta del PC, configurables en *Ajustes → Conexiones → Aplicaciones externas* (icono, color y quién los ve).
- **Lista negra de matrículas** Con su motivo (*Vehículos → Lista negra*): aviso al escribir la matrícula en Entrada, al emitir el ticket (avisar o bloquear salvo supervisor), en la Salida, en la caja móvil y en el lector de matrículas.
- *Guardar en Clientes para próximas facturas* aparece **desmarcado**.
- **Aspecto**: 7 colores (azul, verde, turquesa, violeta, granate, naranja, grafito) y 4 diseños (clásico, moderno, compacto y alto contraste), combinables con el tema claro u oscuro.

## 4.0 — 10 de octubre de 2026

- **Rectificación de facturas** Integrada: *Rectificar…* corrige los datos del cliente de una factura ya emitida con una **factura rectificativa** que la anula y una **factura nueva** que la sustituye («Sustituye a la …»), sin mover la caja; PDF, ticket, registro encadenado y VERI\*FACTU (R5). Las facturas emitidas ya no se reescriben.
- **Devoluciones y rectificación, opcionales**: Se activan en *Preferencias → Opciones* (quien ya las usaba las conserva).
- **Actualizaciones online (experimental)**: Buscar y descargar las versiones que publique el distribuidor, con comprobación de huella y firma. Las **notas de los paquetes** se ven con formato (lista, negritas).
- **Servidor** Con menú propio en *Sistema*: reiniciar / apagar, conexión, sesiones abiertas (y cerrar las de otros puestos) y registro.
- **Más módulos** Para la licencia: *Descuentos y vales*, *Pantalla de cliente*, *Varios cajeros*, *Tarifas por horario*, *Devoluciones y rectificación* y *Barrera y datáfono*. Las licencias anteriores los conservan.
- **Monitores pequeños** (1024×768) y **modo táctil** (automático, sí o no; también solo en un equipo).

## 3.9 — 10 de octubre de 2026

- **Bloqueo tras PIN incorrectos**: 5 fallos seguidos (configurable) bloquean ese usuario unos minutos, y también el equipo que prueba muchos usuarios (caja móvil incluida). Aviso en la 🔔 y botón *Desbloquear* en Usuarios.
- **Devoluciones con factura rectificativa** (total o parcial, efectivo, tarjeta o transferencia), en serie aparte, con el IVA de la original, ticket para firmar y PDF. Restan de la caja de quien devuelve y de los informes. Solo supervisor o con su autorización.
- **Varios cajeros a la vez**, Cada uno con su turno y su arqueo; los supervisores ven y cierran los turnos de los demás.
- **Tarifas por horario** (nocturna, fin de semana…): la tarifa se elige sola según la hora de entrada.
- **Opcionales**: Copia de seguridad también en el **NAS** (con prueba y aviso si falla), **barrera** por relé (red, USB/serie o programa; automática y con botón 🚧) y **datáfono integrado** (simulado, pasarela por red o programa del banco).
- **Validaciones de comercios**: Descuentos marcados con el comercio que valida y resumen en Informes.
- Las sesiones ya no se pierden al reiniciar el programa.

## 3.8 — 10 de octubre de 2026

- **Comprobación periódica de la licencia** (configurable en cada licencia desde el Gestor de licencias 1.3): el programa comprueba la licencia por Internet con el servidor del distribuidor cada N días; si no puede, avisa y, pasados los días de gracia, deja de registrar entradas hasta que se compruebe. Sin Internet se valida con un **código de validación** del distribuidor. Las respuestas van firmadas (no se pueden falsificar ni copiar a otro PC), la licencia se puede **anular** a distancia, se controla el número de puestos y atrasar el reloj del PC no alarga los plazos. Panel nuevo en *Ajustes → Sistema → Licencia*.
- Las licencias sin comprobación siguen funcionando igual, sin Internet.

## 3.7 — 10 de octubre de 2026

- **Copias de seguridad e importar / exportar en una sola pestaña** (*Ajustes → Sistema → Copias, importar y exportar*): arriba las copias (hacer, programar, lista y subir una copia), debajo importar y exportar clientes, abonados, tarifas y servicios, y al final el registro de copias y *Borrar todos los datos*. Desaparece el acceso repetido a las copias.

## 3.6 — 10 de octubre de 2026

- **Importar / exportar** Pasa al apartado *Ajustes → Sistema* (junto a Copias de seguridad).
- **Clientes y abonados juntos** En un solo bloque: importar desde Excel/CSV, plantilla y exportar todos los clientes o los abonados con su bono (CSV o PDF).

## 3.5 — 10 de octubre de 2026

- **Módulo Caja móvil / tablet** (incluido en el plan Completo): entradas, cobros en efectivo o tarjeta, salidas y lista de vehículos dentro desde un móvil o tablet de la red local. Se activa en *Ajustes → Empresa → Caja móvil*, que muestra el **código QR** para abrirla. Cobra en el turno abierto en el PC (opcional). Sin el módulo, el programa no atiende a otros equipos de la red.
- **Importar clientes desde Excel (.xlsx) o CSV** Con asistente: columnas propuestas según los títulos, vista previa (nuevos, actualizados y filas con problemas), clientes existentes reconocidos por NIF, matrícula o email, plantilla y exportación de clientes con las mismas columnas. **Importar / exportar** reúne en *Ajustes → Empresa* clientes, tarifas y servicios, y abonados.
- **Arqueo configurable** (*Ajustes → Empresa → Caja y arqueo*): contar por billetes y monedas al cerrar (y opcionalmente al abrir), elegir qué billetes y monedas se usan y **fondo de caja predefinido**. El desglose se guarda y sale en el ticket de cierre.
- **La demostración caduca con la licencia** (o la prueba) del programa y muestra los días que quedan.
- **Visor TPV**: Lista de **modelos** (Posiflex PD-2100/2300/2600/2800/300/320/320UE/2800UE/6300/7600, Epson DM-D110/D210, Partner CD-7220, Aures OCD-300, Bematech, genérico) que pone protocolo, velocidad y caracteres; nuevo protocolo **AEDEX**; y nueva conexión **Programa del fabricante** para los visores que se manejan con `customerdisplay.exe` (Posiflex) u otra utilidad.
- **Fotos de los vehículos** De los abonados (opcional): en la ficha, y se ven al cobrar y en la caja móvil.
- **Avisos y recordatorios** Con icono 🔔 en la barra superior (opcional): recordatorios para todos, por puesto o para una persona, programados, con visto y hecho, y avisos del propio programa (licencia, copias, pagos pendientes, emails con error).
- Campo **Observaciones** en los datos de la factura (sale en el ticket y en el PDF).
- Pantalla de acceso más ancha.

## 3.4 — 10 de octubre de 2026

- **Cuenta de demostración** Activable desde *Ajustes → Sistema → Demostración* o desde el primer arranque: datos de ejemplo guardados aparte (abonados con bonos en todos los estados, clientes de facturación, tarifas, productos con foto, descuentos, vales, publicidad, un mes de cobros, ventas y turnos, y vehículos dentro). Usuarios `admin`/1234, `supervisor`/2222 y `caja`/1111. Aviso permanente con *Volver a mis datos* y *Empezar de cero*; lo impreso lleva «DEMOSTRACIÓN - SIN VALIDEZ». Los datos reales no se tocan.

## 3.3 — 10 de octubre de 2026

- **Visor TPV de texto** Como alternativa (o además) al segundo monitor: en *Ajustes → Tickets → Pantalla de cliente* se elige *Segundo monitor*, *Visor TPV de texto* o *Los dos*. El visor (2 líneas, 16–40 caracteres) se conecta por puerto serie/USB, como impresora de Windows o por red, con protocolo ESC/POS Epson, CD5220 o texto. Muestra matrícula y tiempo, total, entregado y cambio, la compra de la tienda, la despedida y un mensaje de reposo. Botón de prueba y visor imitado en pantalla.

## 3.2 — 10 de octubre de 2026

- **Pantalla de cliente para un segundo monitor** (modo TPV), activable en *Ajustes → Tickets → Pantalla de cliente*: matrícula, tiempo, importe, descuento, entregado y cambio mientras se cobra; la compra de la tienda; bienvenida al entrar y despedida al pagar. Cuando no hay operación muestra la **publicidad del parking** con las fotos y textos que se suban. Botón *🖥 Cliente* en la barra superior.
- **Vales de descuento imprimibles**: Se generan desde *Ajustes → Precios → Descuentos* (de un uso, de varios usos o ilimitados, con caducidad y nota), se imprimen con QR y código de barras y se canjean escaneándolos en Salida o en la Tienda. Listado con usos y estado, reimpresión y anulación.
- **El servidor ya no muestra su ventana**: Arranca en segundo plano, guarda sus mensajes en `datos/servidor.log` y se apaga o reinicia desde *Ajustes → Sistema → Actualizaciones*. `scripts\ARRANCAR_CON_VENTANA.bat` lo arranca con ventana para diagnóstico.
- La barra superior ya no parte los textos en dos líneas.

## 3.1 — 10 de octubre de 2026

- **Fotos en los productos y servicios**: Se ponen o quitan al editarlos (*Ajustes → Precios → Servicios y productos*), se reducen solas a pocos KB y se ven en los botones de la Tienda y en la lista. Van incluidas en las copias de seguridad.
- **Servicio de descuentos**, Activable en *Ajustes → Precios → Descuentos* (desactivado por defecto): descuentos por porcentaje, importe fijo o minutos gratis, para la estancia, la tienda o ambas, con código opcional para escanear. Se aplican en *Salida* y en la *Tienda*, aparecen en ticket, factura y PDF (con el IVA ya descontado) y se suman en *Informes*.
- Arranque más seguro de la interfaz: Espera a que estén cargadas todas las pantallas.

## 3.0 — 10 de octubre de 2026

- **PROYECTO ALLAS por módulos.** Una base siempre incluida (entrada, salida, vehículos, caja, tarifas, ticket manual, facturas, informes, copias) y seis módulos que se activan según la licencia: **Abonados**, **Tienda**, **Pagos online**, **Mensajería** (WhatsApp/SMS y comunicados), **Madrid 360 y cámaras** y **VERI\*FACTU**.
- **Planes** *Básico*, *Profesional* y *Completo*, y módulos sueltos añadidos o quitados a cada licencia desde el Gestor de licencias (1.1).
- Lo no contratado se oculta del menú, de Ajustes y de las fichas, y el servidor lo bloquea. *Ajustes → Licencia* muestra el plan y los módulos incluidos y no incluidos.
- Compatible: La prueba y las licencias anteriores tienen todos los módulos; los seriales nuevos también funcionan en las versiones 2.x (que ignoran los módulos). Al activar una licencia nueva, el menú se actualiza al momento y no se pierde ningún dato.

## 2.5 — 10 de octubre de 2026

- **Primer arranque: Empezar de cero o cargar una copia de seguridad.** Al abrir el programa recién instalado (o tras *Borrar todos los datos*) se elige entre crear el administrador o recuperar una copia: subiendo un archivo `.db` o eligiendo una copia que ya esté en el equipo. Se muestra lo que contiene (usuarios, clientes, tickets, cobros) antes de cargarla, y después se entra con los usuarios de la copia. Solo disponible mientras no hay usuarios.
- **Aviso de versión de prueba en rojo** Y con botón ✕ para cerrarlo; vuelve a aparecer a los 5 minutos.

## 2.4 — 10 de octubre de 2026

- **Ticket manual sin autorización de supervisor**: Cualquier usuario con su turno abierto puede hacerlo, sin pedir usuario y PIN de un supervisor. Sigue quedando marcado como manual, a nombre de quien lo hace, en ticket, factura, *Vehículos*, *Informes* y *Auditoría*.
- **Copias de seguridad más sencillas** (*Ajustes → Sistema → Copias de seguridad*): arriba, un resumen con solo dos botones (*Hacer copia ahora* y *Programar copias…*); la programación pasa a una ventana aparte con la frecuencia en un desplegable y lo menos usado en *Más opciones*; cada copia tiene un solo botón *Opciones…* (Descargar, Restaurar, Eliminar) en lugar de tres; se ven las 6 más recientes, y el registro y *Borrar todos los datos* quedan plegados.

## 2.3 — 10 de octubre de 2026

- **Avisos y comunicados por WhatsApp / SMS**, Activables en *Ajustes → Conexiones → WhatsApp / SMS*: modo **WhatsApp manual** (gratis: abre WhatsApp con el mensaje escrito) o **automático con Twilio** (SMS o WhatsApp, con mensaje de prueba). Botón *💬 WhatsApp / SMS* en la ficha del abonado con deuda, canal WhatsApp/SMS en los comunicados a abonados y, opcionalmente, los avisos automáticos también por mensaje. El token de Twilio no se muestra nunca.

## 2.2 — 10 de octubre de 2026

- **Luz de estado de Madrid 360** En la barra superior cuando está activado: verde (al día), ámbar (falta el listado de ayer) o roja (días anteriores sin comunicar o envío fallido). Al pulsarla se abren los listados. Cuenta desde el día en que se activa.
- **Comunicados generales por email a los abonados** (*Clientes y bonos → ✉ Comunicado a abonados*): a todos o por grupo (bono vigente, pago pendiente, caducado), personalizado con {nombre}, por envío automático con progreso o por Gmail en copia oculta; con confirmación, historial y registro en auditoría.

## 2.1 — 10 de octubre de 2026

- **Recordatorio de deuda por email** Desde la ficha del abonado (botón *✉ Recordar por email* junto a la deuda pendiente): mensaje con el detalle de lo que debe, el IBAN para transferencia y el enlace de pago online cuando procede; editable antes de enviar; envío automático (SMTP) o con Gmail. Se anota la fecha del último recordatorio en la ficha y en auditoría, y se pueden enviar tantos como haga falta. Texto configurable en *Ajustes → Abonados → Pagos online y avisos*.

## 2.0 — 10 de octubre de 2026

- **PROYECTO ALLAS pasa a la versión 2.0.** Reúne todo lo añadido desde la 1.0: tienda, abonados con pagos parciales, transferencias y cancelación de deudas, pagos online (Stripe), copias de seguridad programadas y a elegir, cambio de tarifa, historial de ventas, Ajustes agrupados en seis apartados e integraciones preparadas (Madrid 360, cámaras de matrículas, VERI*FACTU).
- Sin cambios de funcionamiento respecto a la 1.10: Los datos, la licencia y los ajustes se conservan al actualizar.

## 1.10 — 10 de octubre de 2026

- Corregido: En el pago parcial de un bono en efectivo, el recuadro del cambio mostraba «Importe no válido». Ahora pide primero el importe a cobrar y calcula el cambio sobre esa parte (también al cobrar lo pendiente).
- **Ajustes simplificados**: De 15 pestañas sueltas a 6 apartados (Empresa, Precios, Abonados, Tickets, Conexiones, Sistema), cada uno con sus pestañas.
- *Datos y cobro* ordenado por bloques (empresa, cobro, ticket perdido, transferencias); los campos que dependen de otra opción solo se muestran cuando aplican.
- *Copias de seguridad*: La carpeta adicional y las copias a conservar pasan al panel de copias automáticas (un solo botón Guardar); el registro de copias queda plegado.

## 1.9 — 10 de octubre de 2026

- **Copias de seguridad programadas** En *Ajustes → Copias de seguridad*: cada N horas, a horas fijas en los días de la semana elegidos, o desactivadas; y qué guardar (todo o algunos grupos). Muestra cuándo será la próxima. Si el equipo estaba apagado a la hora prevista, la copia se hace al encenderlo. Se mantienen la copia al arrancar y al cerrar cada turno.
- **Efectivo: Cantidad recibida obligatoria**. Al cobrar en efectivo (salida, tienda, bonos, ticket manual) hay que escribir lo que entrega el cliente (o pulsar *Exacto* / un billete); si no, no deja continuar. También lo comprueba el servidor.

## 1.8 — 10 de octubre de 2026

- **Menú sin iconos y con color**: Fondo azul suave, opción activa en azul con texto blanco (también en tema oscuro).
- **Pago de bonos por transferencia bancaria** (activado por defecto): tercer botón *Transferencia* al vender un bono o cobrar lo pendiente, también en pagos parciales, con referencia opcional que sale en el ticket y la factura. No abre el cajón ni cuenta como efectivo; aparece aparte en el turno, en Caja y en Informes. En *Ajustes → Empresa y cobro*: activar/desactivar, IBAN y titular; si hay IBAN, el aviso de pago pendiente lo incluye con el número de bono como concepto.

## 1.7 — 10 de octubre de 2026

- **Pagos parciales de bonos**: Al vender o cobrar un bono se puede cobrar solo una parte (efectivo o tarjeta); el resto queda pendiente en la ficha del abonado. Cada pago tiene su factura simplificada, que indica que es un pago parcial y lo que queda pendiente.
- **Cancelar deudas de abonados a mano** (supervisor o administrador): por bono o todas a la vez, con motivo y opción de quitar la renovación automática. Sin pagos, el periodo se anula; pagado en parte, se cierra con lo cobrado. Queda en auditoría.
- **Entrada y Salida vuelven al diseño anterior** (se mantienen las lecturas de cámara).
- **Salida: Lista de vehículos dentro** Al escribir la matrícula (todos al entrar en el campo, filtrando al escribir); se elige con el ratón o con ↑ ↓ e Intro.
- **Cambiar la tarifa** De un vehículo que ya ha entrado (en Salida, junto a la tarifa, y en *Vehículos → Dentro ahora*), mientras no tenga cobros.
- **Historial de ventas de la tienda**: Por fechas, búsqueda, reimpresión del ticket y factura con datos / email.
- **Copia de seguridad manual a elegir**: Todo o solo configuración (con el logo), clientes y bonos, movimientos o auditoría. Las copias parciales se restauran sin borrar el resto de datos.
- Corregido: La vista previa de la factura con datos de cliente de una venta de tienda.

## 1.6 — 10 de octubre de 2026

- **Tienda (F8)**: Venta de productos y servicios sin matrícula ni tiempo. Cuadrícula de productos, carrito con cantidades, efectivo (con cambio) o tarjeta; imprime recibo, abre el cajón y permite factura con datos o envío por email. Las ventas salen en Informes (columna *Tienda*) y en los productos vendidos.
- **Borrar todo** En *Ajustes → Copias de seguridad* (solo administrador): con el PIN del administrador y escribiendo «BORRAR TODO», deja el programa como recién instalado. Antes guarda una copia completa (tipo «Antes de restablecer») por si hay que volver atrás. Se conservan la licencia y la fecha de instalación.
- **Entrada y Salida renovadas**: Cabecera con distintivo de color, pasos numerados, escáner animado y campo de matrícula con aspecto de placa europea. Mismas teclas y mismo funcionamiento.
- **Informes y Ajustes** Pasan a la parte inferior del menú, encima de «PROYECTO ALLAS versión».
- Nueva pestaña **Ajustes → Integraciones** (todo **desactivado por defecto**):
  - **Madrid 360 (ZBE Distrito Centro)**: Código de aparcamiento autorizado, listado diario de matrículas que han entrado (`matrícula;AAAAMMDD;HH:MM`) para descargar y marcar como enviado. Envío automático preparado, pendiente de las especificaciones del Ayuntamiento.
  - **Cámaras lectoras de matrículas**: Las cámaras envían la lectura a `/api/lpr/lectura` con su token; en Entrada se rellena la matrícula (o se emite el ticket automáticamente) y en Salida se propone el vehículo. Confianza mínima configurable y botón para simular lecturas.
  - **VERI*FACTU**: Registro de alta por factura con huella SHA-256 encadenada en el formato de la AEAT, código QR y leyenda «VERI*FACTU» en ticket y PDF, XML del registro descargable. Falta el envío a la AEAT con certificado; no activar en producción sin su asesoría.
- Corregido: El escaneo desde cualquier pantalla no reconocía tickets con una letra de ticket personalizada.
- Corregido: Un PIN equivocado al restaurar una copia cerraba la sesión.

## 1.5 — 10 de octubre de 2026

- **Logo junto al nombre del parking**: Una P blanca sobre fondo azul (el icono del programa sigue siendo la A).
- **NIF/CIF incorrecto**: Ahora solo avisa y deja continuar (en la factura con datos y en la ficha del cliente).
- **Licencia de prueba de 5 días** (antes 30).
- **Exportar vehículos** (*Vehículos → Exportar…*, en «Dentro ahora» y en el historial): **PDF** con el listado o **CSV** con una línea por matrícula `matrícula;día;hora` (p. ej. `9999ZZZ;20261009;23:59`), con la hora de entrada, la de salida o una fecha y hora a elegir.
- **Listado de abonados** En *Ajustes → Abonados*: todos sus datos, vehículos, bono y renovación, con filtros; exportación a **PDF** y a **CSV** `matrícula;día;hora` (por defecto el día en que caduca el bono a las 23:59, o la fecha y hora que se elija).
- **Numeración configurable** En *Ajustes → General*: letra/serie y número inicial de facturas, tickets y bonos. Los tickets antiguos se siguen leyendo.
- **Registro encadenado de facturación desactivado** Por defecto, con opción para activarlo (será necesario con VERI*FACTU).
- **Ticket perdido** Activable o desactivable en *Ajustes → Empresa y cobro*.
- **Renovación automática de bonos** (marcada por defecto, por cliente y al vender el bono): el último día del bono se crea el siguiente periodo **pendiente de pago** y se avisa al abonado por email (con enlace para pagar online si están activos los pagos online). Durante unos días de gracia (7 por defecto) puede seguir entrando. Se cobra en caja (efectivo o tarjeta) desde la ficha o al escanear su tarjeta, o online; la factura se le envía por email. Los suscriptores con cargo automático en tarjeta siguen renovándose con Stripe.

## 1.4 — 9 de octubre de 2026

- **Descripción opcional en servicios y productos**: Se escribe al crear o editar el servicio y aparece debajo del nombre en el ticket, la factura y el PDF. Se guarda la del momento de la venta (cambiarla después no altera facturas ya emitidas).
- **Facturas por email a los abonados**: Al vender o renovar un bono, si el abonado tiene email (y la casilla «Enviarle sus facturas por email» en su ficha), se le envía la factura en PDF automáticamente. Cada bono de la ficha tiene su botón *Factura / email*.
- **Avisos a los abonados**: Email automático unos días antes de que caduque el bono (con el enlace para suscribirse, si hay pagos online) y cuando no se puede cobrar una renovación («tiene una factura pendiente», con el enlace para pagarla). En *Clientes → Avisos de caducidad* se ve a quién toca avisar y se puede mandar también con Gmail.
- **Suscripciones con cargo automático en tarjeta (Stripe)**: En *Ajustes → Pagos online y avisos* se activa con la clave de Stripe. Desde la ficha del abonado, *Suscribir con tarjeta…* muestra un QR y un enlace de pago para el móvil. Cada cobro renueva el bono sin huecos, emite la factura simplificada (forma de pago «Tarjeta (pago online)») y se la envía. Bajas al final del periodo o inmediatas. No necesita abrir puertos: el programa consulta Stripe cada 10 minutos.
- Los cobros online aparecen en Informes (columna *Online*) y en el CSV, y no cuentan en la caja del turno.

## 1.3 — 9 de octubre de 2026

- **Logo de la empresa (opcional)** En *Ajustes → Ticket*: se sube un PNG o JPG y se elige si sale en los tickets (entrada, factura, bono, tarjeta) y/o en la factura PDF. Tamaño en el ticket ajustable y opción de tramado para fotos.
- **Entrada al arrancar**: El programa abre Entrada al entrar (se puede cambiar en *Ajustes → General*).
- **Tema claro / oscuro / automático** En la nueva pestaña *Ajustes → General*.
- **Eliminar tarifas** En *Ajustes → Tarifas* (las que ya usó algún ticket se ocultan; los vehículos que estén dentro la siguen pagando igual).
- **Icono nuevo**: Una A blanca sobre fondo azul (pestaña del navegador, ventana y `scripts\CREAR_ACCESO_DIRECTO.bat` para el escritorio).
- **Historial de vehículos** En *Vehículos → Historial de entradas y salidas*: por fechas, matrícula y estado, con resumen y exportación a CSV.
- **Licencias por serial** (*Ajustes → Licencia*): 30 días de prueba; activación sin Internet con el serial o el archivo `.lic`; licencias perpetuas o de suscripción, ligadas o no a un equipo. Sin licencia válida no se registran entradas nuevas, pero los vehículos que están dentro pueden pagar y salir.
- **Actualizaciones** (*Ajustes → Actualizaciones*): paquetes firmados que se suben e instalan sin Internet, con copia de seguridad previa, reinicio automático y vuelta a la versión anterior.
- **Gestor de licencias** (programa aparte, carpeta `GESTOR_LICENCIAS`): clientes, emisión y renovación de seriales, comprobación de seriales y creación de paquetes de actualización firmados.

## 1.2 — 9 de octubre de 2026

- **Copias del ticket de entrada**: En *Ajustes → Ticket* se elige cuántas copias se imprimen al emitir cada ticket (de 1 a 5). La reimpresión sigue siendo de una copia.
- **Sumar o restar minutos en Entrada**: Botones −15 / −5 / −1 / +1 / +5 / +15 y *Ahora* (también las teclas − y + del teclado numérico) para ajustar la hora de entrada antes de emitir el ticket. El ticket indica «hora ajustada en caja», queda en auditoría y el máximo permitido se fija en *Ajustes → Ticket* (120 min por defecto; 0 lo desactiva).

## 1.1 — 9 de octubre de 2026

- **Eliminar servicios y productos** Desde *Ajustes → Servicios y productos*. Si ya se vendieron alguna vez se ocultan (las facturas y las estancias abiertas conservan su nombre y precio); si no, se borran.
- **Cambiar la matrícula** De un vehículo que está dentro: botón *Matrícula* en *Vehículos* y *✎ Cambiar* en *Salida*. Queda en auditoría la anterior y la nueva.
- **Clientes de facturación**: En la factura con datos, la casilla *Guardar en Clientes* (marcada por defecto) guarda nombre, NIF/CIF, dirección, email y la matrícula de la estancia, para que la próxima vez salgan solos. Se distinguen de los **abonados** con una etiqueta y un filtro propio en *Clientes*; si se le vende un bono pasa a abonado. La factura incluye un buscador de clientes guardados y la ficha del cliente lista sus facturas.
- **Exportar e importar tarifas y servicios** (archivo `.json`) desde *Ajustes → Tarifas* o *Servicios y productos*: vista previa de los cambios, modo *Combinar* o *Reemplazar* y copia de seguridad automática antes de aplicar.
- **Servicios en el ticket manual**: Se añaden con su cantidad; se cobran junto con la estancia (descontando los minutos de parking incluidos) o quedan pendientes si solo se registra la entrada.

## 1.0 — 9 de octubre de 2026

Primera versión con el nombre **PROYECTO ALLAS**.

- **Arqueo de caja opcional**: Al abrir turno se elige si se hará arqueo al cerrar (se recuerda la última elección). Sin arqueo, el cierre no pide contar el efectivo y el cierre Z lo indica.
- **Salida por matrícula**: Segundo campo en *Salida* para escribir la matrícula cuando no hay ticket que escanear (coincidencia exacta, lista si hay varias, o propuesta de ticket manual si no está dentro).
- **Factura en PDF rediseñada**: Formato A4 con tipografía Poppins incrustada (tildes, ñ y €), bloque de cliente, tabla de conceptos con cantidad, precio e IVA, desglose por tipos y total destacado.
- Factura con datos: El botón **Guardar datos** pasa a ser el principal.
- Nombre y versión del programa visibles en toda la aplicación.

### Antes de la 1.0 (desarrollo)

- 0.9 · Alternativas al envío por SMTP (Gmail en el navegador, borrador para Outlook) y corrección: los datos del cliente no se guardaban al imprimir o ver el PDF.
- 0.8 · Al cobrar, el vehículo sale y la plaza queda libre.
- 0.7 · Factura con datos del cliente y envío por email; minutos de parking incluidos en servicios; redondeo y texto por tarifa; ticket manual con salida futura; menú Entrada / Salida.
- 0.6 · Servicios y productos en la estancia con IVA por tipos; eliminar copias; motivo opcional en ticket manual.
- 0.5 · Marca y modelo de vehículos; restaurar copias desde la aplicación; ticket manual.
- 0.4 · Código de barras Code128; ticket rediseñado con textos configurables; clientes y bonos mensuales.
- 0.3 · Arranque robusto en Windows (ARRANCAR.bat, detección de puertos ocupados).
- 0.1 · Versión inicial: Entrada, cobro, turnos, facturación encadenada, informes, copias.
