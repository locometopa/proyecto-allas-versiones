# Formato de plantillas de PROYECTO ALLAS (`allas-plantilla`, versión 1)

Una plantilla es un archivo **JSON** (UTF-8) que describe cómo se imprime un documento. Es un formato abierto: el **Editor de plantillas**
las crea, **PROYECTO ALLAS** las carga en *Ajustes → Tickets* (y *Ajustes → Factura*), y cualquier otro programa puede leerlas o generarlas.
Los módulos `plantillas.py` (validación y dibujo) y `impresion.py` son de la biblioteca estándar de Python y se pueden reutilizar.

## Estructura común

```json
{"formato": "allas-plantilla", "version": 1, "tipo": "entrada", "nombre": "Mi ticket", "bloques": [ ... ]}
```

| Clave | Valor |
|---|---|
| `formato` | siempre `"allas-plantilla"` |
| `version` | `1` (un programa rechaza versiones más nuevas que la que entiende) |
| `tipo` | `entrada`, `recibo`, `bono`, `tarjeta` (tickets térmicos) o `factura` (PDF A4) |
| `nombre` | nombre que se muestra (hasta 80 caracteres) |

Límites: 200 KB, 150 bloques, 400 caracteres por texto. Las claves desconocidas se descartan al cargar.

## Campos y condiciones

Los textos pueden llevar **campos entre llaves**: `{matricula}`, `{total}`… Cada tipo tiene sus campos (tablas más abajo).

- Si un texto tiene campos y **todos están vacíos**, esa línea no se imprime (por ejemplo `Cliente: {cliente_nombre}` en un ticket sin cliente).
- Un campo desconocido sale vacío (el editor avisa de ello).
- Todos los bloques admiten `"si"`, una **condición** para imprimirlos: `campo` (tiene valor), `!campo` (no tiene valor),
  `campo=valor`, `campo!=valor`. Los campos «1 si …» (`duplicado`, `manual`, `copia`, `matricula_grande`) sirven para esto.

## Tickets: bloques

`bloques` es una lista que se imprime de arriba abajo. Cada bloque es un objeto con `"t"` (tipo) y sus opciones.

| `t` | Opciones | Qué imprime |
|---|---|---|
| `cabecera` | `nombre_tam` (`auto`/`normal`/`alto`/`grande`), `invertida`, `logo`, `razon`, `nif`, `direccion`, `telefono`, `web` (`true`/`false`/`"auto"` = según Ajustes), `extra` | Logo, nombre del parking y datos de la empresa |
| `texto` | `texto`, `alinear` (`izq`/`centro`/`der`), `negrita`, `tam` (`normal`/`alto`/`grande`), `inverso`, `ajustar` | Una o varias líneas de texto (`\n` para saltar de línea) |
| `par` | `izq`, `der`, `negrita`, `inverso`, `tam` (`normal`/`alto`) | Una línea con un texto a la izquierda y otro a la derecha (etiqueta y valor) |
| `sep` | `c`: `"auto"` (el de Ajustes) o uno de `- = · * _ .` o espacio | Línea separadora |
| `espacio` | `n`: 1 a 5 | Líneas en blanco |
| `logo` | — | El logo de Ajustes (si hay) |
| `codigo` | `dato` (por defecto `{codigo}`), `tipo` (`auto`/`ambos`/`qr`/`barras`), `tam` (`"auto"` o 3 a 8), `mostrar_texto`, `espacio` | Código QR y/o de barras |
| `repetir` | `lista` (nombre de una lista del tipo), `bloques` (texto, par, sep, espacio) | Repite sus bloques una vez por cada elemento de la lista; dentro, los campos son los del elemento |

Los valores `"auto"` leen la configuración de *Ajustes → Tickets* (tamaño del nombre, qué datos de empresa se muestran, tipo de código, separador…),
de modo que la plantilla de serie sigue obedeciendo a Ajustes.

## Factura A4

```json
{"formato": "allas-plantilla", "version": 1, "tipo": "factura", "nombre": "Mi factura",
  "estilo": {"color": "#1d4ed8", "cabecera_tabla": "#111827", "tam_logo": "mediano"},
  "secciones": {"logo": true, "detalle": true, "observaciones": true, "notas": true, "pie": true},
  "columnas": {"cantidad": true, "precio": true, "iva": true},
  "textos": {"titulo_completa": "FACTURA", "concepto": "Concepto"},
  "antes_tabla": "", "notas": "", "pie": ""}
```

- `estilo`: `color` y `cabecera_tabla` (`#rrggbb`); `tam_logo`: `pequeno`, `mediano`, `grande`.
- `secciones` y `columnas`: qué se muestra. Concepto e importe siempre van. **Los datos de la empresa y del cliente, el desglose de IVA y el
  QR VERI\*FACTU son obligatorios y no se pueden quitar.**
- `textos` (hasta 80 caracteres): `titulo_completa`, `titulo_simplificada`, `cliente`, `detalle`, `concepto`, `cantidad`, `precio`, `iva`, `importe`,
  `base`, `cuota`, `total`, `forma_pago`, `entregado`, `cambio`. Los que no se indican quedan como de serie.
- `antes_tabla`, `notas`, `pie` (hasta 1000 caracteres): texto libre sobre la tabla, en las notas y al pie. En PROYECTO ALLAS, `notas` y `pie`
  se completan con los de *Ajustes → Factura* si la plantilla los deja vacíos.

## Campos por tipo

### `entrada` — Ticket de entrada

| Campo | Qué es | Ejemplo |
|---|---|---|
| `{nombre_parking}` | Nombre del parking | PARKING DEMO CENTRO |
| `{razon_social}` | Razón social | Demo Parking S.L. |
| `{nif}` | NIF de la empresa | B12345674 |
| `{direccion}` | Dirección | C/ Mayor 1, 28013 Madrid |
| `{telefono}` | Teléfono | 912 345 678 |
| `{web}` | Web | www.demoparking.es |
| `{email}` | Email | info@demoparking.es |
| `{titulo}` | Título configurado en Ajustes | TICKET DE ENTRADA |
| `{hora}` | Hora de entrada | 13:23 |
| `{fecha_larga}` | Fecha de entrada | lunes, 12 de octubre de 2026 |
| `{ajuste_hora}` | Aviso de hora ajustada (si la hay) | — |
| `{duplicado}` | «1» si es un duplicado | — |
| `{manual}` | «1» si es entrada manual | — |
| `{matricula}` | Matrícula | 1234ABC |
| `{matricula_grande}` | «1» si Ajustes pide la matrícula grande | — |
| `{tarifa}` | Nombre de la tarifa | General |
| `{reserva_hasta}` | Reserva hasta (si la hay) | — |
| `{reserva_ref}` | Nº de reserva (si lo hay) | — |
| `{tarifa_despues}` | Tarifa después de la reserva | — |
| `{texto_tarifa}` | Texto del ticket de la tarifa | — |
| `{cajero}` | Cajero (si está activado en Ajustes) | Ana García |
| `{codigo}` | Código del ticket (QR / barras) | PK0000123A3F9C |
| `{qr_pago}` | Enlace de pago con el móvil (si está activo) | — |
| `{pie}` | Pie configurado en Ajustes | Conserve este ticket |
| **lista `precios`** | cada elemento tiene: `{etiqueta}`, `{valor}` | |

### `recibo` — Factura / recibo (ticket)

| Campo | Qué es | Ejemplo |
|---|---|---|
| `{nombre_parking}` | Nombre del parking | PARKING DEMO CENTRO |
| `{razon_social}` | Razón social | Demo Parking S.L. |
| `{nif}` | NIF de la empresa | B12345674 |
| `{direccion}` | Dirección | C/ Mayor 1, 28013 Madrid |
| `{telefono}` | Teléfono | 912 345 678 |
| `{web}` | Web | www.demoparking.es |
| `{email}` | Email | info@demoparking.es |
| `{total}` | Importe total | 19,41 € |
| `{forma_pago}` | Forma de pago | Efectivo |
| `{referencia}` | Referencia del pago | — |
| `{entregado}` | Efectivo entregado (solo efectivo) | 20,00 € |
| `{cambio}` | Cambio (solo efectivo) | 0,59 € |
| `{cajero}` | Cajero (si está activado en Ajustes) | Ana García |
| `{qr_verifactu}` | Enlace del QR VERI*FACTU (si lo hay) | — |
| `{copia}` | «1» si es una copia | — |
| `{sustituye}` | Texto «Sustituye a la …» (si lo hay) | — |
| `{numero}` | Número de factura | A-000123 |
| `{fecha_hora}` | Fecha y hora del cobro | 12/10/2026 15:00 |
| `{titulo}` | Título configurado en Ajustes | FACTURA SIMPLIFICADA |
| `{pie}` | Pie configurado en Ajustes | Gracias por su visita |
| `{cliente_nombre}` | Cliente (si es factura completa) | — |
| `{cliente_nif}` | NIF del cliente | — |
| `{cliente_direccion}` | Dirección del cliente | — |
| `{cliente_observaciones}` | Observaciones del cliente | — |
| `{matricula}` | Matrícula | 1234ABC |
| `{ticket}` | Código del ticket | PK0000123A3F9C |
| `{manual}` | «1» si es ticket manual | — |
| `{entrada}` | Fecha y hora de entrada | 12/10/2026 13:23 |
| `{salida}` | Fecha y hora de salida | 12/10/2026 15:00 |
| `{pagado_hasta}` | Pagado hasta (si se paga por adelantado) | — |
| `{tiempo}` | Tiempo de estancia | 1 h 37 min |
| `{incluido_servicios}` | Tiempo incluido en servicios | — |
| `{pago_fecha}` | Fecha y hora del pago | 12/10/2026 15:00 |
| `{estacionamiento}` | Importe del estacionamiento | 4,41 € |
| `{recargo}` | Recargo por ticket perdido | — |
| `{descuento_nombre}` | Texto «Descuento X» | — |
| `{descuento}` | Importe del descuento | — |
| `{aviso_salida}` | Aviso «salga antes de las …» | — |
| **lista `lineas`** | cada elemento tiene: `{nombre}`, `{importe}`, `{precio_unidad}`, `{descripcion}`, `{incluye}` | |
| **lista `desglose`** | cada elemento tiene: `{izq}`, `{der}` | |

### `bono` — Recibo de bono

| Campo | Qué es | Ejemplo |
|---|---|---|
| `{nombre_parking}` | Nombre del parking | PARKING DEMO CENTRO |
| `{razon_social}` | Razón social | Demo Parking S.L. |
| `{nif}` | NIF de la empresa | B12345674 |
| `{direccion}` | Dirección | C/ Mayor 1, 28013 Madrid |
| `{telefono}` | Teléfono | 912 345 678 |
| `{web}` | Web | www.demoparking.es |
| `{email}` | Email | info@demoparking.es |
| `{total}` | Importe total | 19,41 € |
| `{forma_pago}` | Forma de pago | Efectivo |
| `{referencia}` | Referencia del pago | — |
| `{entregado}` | Efectivo entregado (solo efectivo) | 20,00 € |
| `{cambio}` | Cambio (solo efectivo) | 0,59 € |
| `{cajero}` | Cajero (si está activado en Ajustes) | Ana García |
| `{qr_verifactu}` | Enlace del QR VERI*FACTU (si lo hay) | — |
| `{copia}` | «1» si es una copia | — |
| `{sustituye}` | Texto «Sustituye a la …» (si lo hay) | — |
| `{numero}` | Número de factura | A-000123 |
| `{fecha_hora}` | Fecha y hora del cobro | 12/10/2026 15:00 |
| `{titulo}` | Título configurado en Ajustes | FACTURA SIMPLIFICADA |
| `{pie}` | Pie configurado en Ajustes | Gracias por su visita |
| `{cliente_nombre}` | Cliente (si es factura completa) | — |
| `{cliente_nif}` | NIF del cliente | — |
| `{cliente_direccion}` | Dirección del cliente | — |
| `{cliente_observaciones}` | Observaciones del cliente | — |
| `{abonado_nombre}` | Nombre del abonado | Laura Martín Gómez |
| `{abonado_nif}` | NIF del abonado | 12345678Z |
| `{plan}` | Plan del bono | Mensual 24 horas |
| `{numero_bono}` | Nº de bono | B-0007 |
| `{periodo}` | «Del 12/10/2026 al 11/11/2026» | Del 12/10/2026 al 11/11/2026 |
| `{importe_bono}` | Importe de este pago | 90,00 € |
| `{bono_total}` | Importe total del bono (si se paga a plazos) | — |
| `{bono_pagado}` | Pagado hasta hoy (a plazos) | — |
| `{bono_pendiente}` | Queda pendiente (a plazos) | — |
| `{valido_hasta}` | Válido hasta | 11/11/2026 |
| **lista `vehiculos`** | cada elemento tiene: `{texto}` | |
| **lista `desglose`** | cada elemento tiene: `{izq}`, `{der}` | |

### `tarjeta` — Tarjeta de abonado

| Campo | Qué es | Ejemplo |
|---|---|---|
| `{nombre_parking}` | Nombre del parking | PARKING DEMO CENTRO |
| `{razon_social}` | Razón social | Demo Parking S.L. |
| `{nif}` | NIF de la empresa | B12345674 |
| `{direccion}` | Dirección | C/ Mayor 1, 28013 Madrid |
| `{telefono}` | Teléfono | 912 345 678 |
| `{web}` | Web | www.demoparking.es |
| `{email}` | Email | info@demoparking.es |
| `{titulo}` | Título configurado en Ajustes | TARJETA DE ABONADO |
| `{nombre}` | Nombre del abonado | Laura Martín Gómez |
| `{plan}` | Plan del bono | Mensual 24 horas |
| `{valido_hasta}` | Válido hasta | 11/11/2026 |
| `{codigo}` | Código de la tarjeta (QR / barras) | CL0000001A3F9C |
| `{pie}` | Pie configurado en Ajustes | Presente esta tarjeta en el lector |
| **lista `vehiculos`** | cada elemento tiene: `{texto}` | |

### `factura` — Factura A4 (PDF)

Los textos libres (`antes_tabla`, `notas`, `pie`) admiten estos campos de la empresa y del documento:

| Campo | Qué es | Ejemplo |
|---|---|---|
| `{nombre_parking}` | Nombre del parking | PARKING DEMO CENTRO |
| `{razon_social}` | Razón social | Demo Parking S.L. |
| `{nif}` | NIF de la empresa | B12345674 |
| `{direccion}` | Dirección | C/ Mayor 1, 28013 Madrid |
| `{telefono}` | Teléfono | 912 345 678 |
| `{web}` | Web | www.demoparking.es |
| `{email}` | Email | info@demoparking.es |
| `{numero}` | Número de factura | A-000123 |
| `{fecha}` | Fecha y hora | 12/10/2026  15:00 |
| `{total}` | Total | 16,41 € |
| `{cliente_nombre}` | Cliente | Transportes Ejemplo S.L. |
| `{cliente_nif}` | NIF del cliente | B12345674 |
| `{matricula}` | Matrícula | 1234ABC |

## Obligaciones legales

Las plantillas cambian la **presentación**, no el contenido legal. En PROYECTO ALLAS, el número de factura, los datos fiscales, el desglose de IVA y
el QR VERI*FACTU los pone siempre el programa; si una plantilla no los incluye, el documento puede quedar incompleto y la responsabilidad
de revisarlo es de quien la diseña. Una plantilla dañada o rechazada nunca impide imprimir: se usa el diseño de serie.

## Usar el formato desde otro programa

El Editor de plantillas lleva la carpeta `nucleo/` (paquete de Python con `plantillas.py`, `impresion.py`, `codigos.py` y `pdf.py`, solo biblioteca estándar).
Copiándola junto a su programa:

```python
from nucleo.plantillas import validar, dibujar_ticket, ejemplo
from nucleo.impresion import Ticket
plt = validar(open("mi_ticket.json", encoding="utf-8").read())          # lanza ErrorPlantilla si no es válida
doc = dibujar_ticket(Ticket(42), plt, {**ejemplo("entrada"), "matricula": "9999ZZZ"}, logo=None)
print(doc.texto())            # vista previa en texto; doc.elementos son las órdenes de impresión (ESC/POS)
```

Si solo necesita leer el JSON, basta cualquier lector de JSON: el formato es el descrito arriba.
