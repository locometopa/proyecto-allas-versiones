@echo off
title PROYECTO ALLAS - arranque
cd /d "%~dp0"

echo.
echo  ==========================================
echo    PROYECTO ALLAS - arrancando...
echo  ==========================================
echo.

REM --- 0. Se esta ejecutando desde dentro del zip? ---
echo "%~dp0" | find /i ".zip" >nul
if not errorlevel 1 (
  echo  ERROR: esta ejecutando el programa DESDE DENTRO DEL ZIP.
  echo.
  echo  Cierre esta ventana, haga clic derecho en parking.zip,
  echo  elija "Extraer todo..." y abra ARRANCAR.bat desde la carpeta extraida.
  echo.
  pause
  exit /b 1
)

REM --- 1. Buscar Python: el incluido en la carpeta "python" (4.4), luego el lanzador "py" y luego "python" ---
set "PY="
set "PYW="
if not exist "%~dp0python\python.exe" goto buscar_py
set "PY="%~dp0python\python.exe""
if exist "%~dp0python\pythonw.exe" set "PYW="%~dp0python\pythonw.exe""
echo  Python incluido en el programa (carpeta python)
goto py_listo
:buscar_py
py -3 --version >nul 2>nul && set "PY=py -3"
if not defined PY (
  python --version >nul 2>nul && set "PY=python"
)
if not defined PY (
  echo  ERROR: no se encuentra Python en este ordenador.
  echo.
  echo  1. Descargue Python 3.11 o superior de https://www.python.org/downloads/
  echo  2. Al instalar, MARQUE la casilla "Add python.exe to PATH".
  echo  3. Vuelva a abrir ARRANCAR.bat
  echo.
  pause
  exit /b 1
)
for /f "tokens=*" %%v in ('%PY% --version 2^>^&1') do echo  Python encontrado: %%v
:py_listo

REM --- 2. Ya estaba en marcha? Entonces solo abrimos el navegador ---
set "PUERTO=8080"
if exist "datos\puerto.txt" set /p PUERTO=<"datos\puerto.txt"
call :responde %PUERTO%
if not errorlevel 1 (
  echo  PROYECTO ALLAS ya estaba en marcha en el puerto %PUERTO%.
  goto abrir
)

REM --- 3. Arrancar el servidor SIN ventana de comandos, con una barra de progreso (scripts\arranque_progreso.ps1) ---
REM     Si hay un error o el servidor se para, se abre una ventana de comandos con el diagnostico.
REM     Los mensajes del servidor van a datos\servidor.log. Con ALLAS_VENTANA=1 (scripts\ARRANCAR_CON_VENTANA.bat) se ve el servidor en una ventana.
if exist "datos\puerto.txt" del "datos\puerto.txt"
if defined ALLAS_VENTANA goto clasico
if not exist "scripts\arranque_progreso.ps1" goto clasico
set "PSEXE=" & set "PSARGS="
if exist "%~dp0python\pythonw.exe" set "PSEXE=%~dp0python\pythonw.exe"
if not defined PSEXE if exist "%~dp0python\python.exe" set "PSEXE=%~dp0python\python.exe"
if not defined PSEXE where pyw >nul 2>nul && set "PSEXE=pyw" && set "PSARGS=-3"
if not defined PSEXE where pythonw >nul 2>nul && set "PSEXE=pythonw"
if not defined PSEXE if "%PY%"=="py -3" set "PSEXE=py" & set "PSARGS=-3"
if not defined PSEXE set "PSEXE=python"
set "PSMODO="
if /i "%~1"=="quiosco" set "PSMODO=quiosco"
echo  Abriendo la ventana de arranque...
start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0scripts\arranque_progreso.ps1" -Raiz "%~dp0." -Exe "%PSEXE%" -ArgsExe "%PSARGS%" -Modo "%PSMODO%"
exit /b 0

:clasico
if not defined PYW (
  where pyw >nul 2>nul && set "PYW=pyw -3"
  if not defined PYW where pythonw >nul 2>nul && set "PYW=pythonw"
)
if defined ALLAS_VENTANA set "PYW="
if defined PYW (
  start "" %PYW% run.py
) else (
  start "PROYECTO ALLAS - SERVIDOR (no cerrar)" /min %PY% run.py
)
echo  Esperando a que el servidor responda...

set /a intentos=0
:espera
timeout /t 1 /nobreak >nul
set /a intentos+=1
if not exist "datos\puerto.txt" goto seguir
set /p PUERTO=<"datos\puerto.txt"
call :responde %PUERTO%
if not errorlevel 1 goto abrir
:seguir
if %intentos% lss 25 goto espera

echo.
echo  ERROR: el servidor no ha respondido en 25 segundos.
echo  El motivo esta en el archivo datos\servidor.log
echo  o abra scripts\ARRANCAR_CON_VENTANA.bat para ver el servidor en una ventana.
echo.
pause
exit /b 1

:abrir
set "URL=http://127.0.0.1:%PUERTO%"
echo.
echo  Abriendo %URL%
REM Edge en modo aplicacion (ventana sin barra de direcciones). Si no hay Edge, navegador por defecto.
if /i "%~1"=="quiosco" (
  start "" msedge --kiosk %URL% --edge-kiosk-type=fullscreen --no-first-run
) else (
  start "" msedge --app=%URL% --start-maximized --no-first-run 2>nul || start "" %URL%
)
echo  Listo. El servidor funciona en segundo plano, sin ventana.
echo  Para apagarlo: Ajustes - Sistema - Actualizaciones - Apagar.
timeout /t 3 >nul
exit /b 0

:responde
powershell -NoProfile -Command "try { $r = Invoke-WebRequest -UseBasicParsing http://127.0.0.1:%1/api/estado -TimeoutSec 2; if ($r.Content -match 'primer_arranque') { exit 0 } else { exit 1 } } catch { exit 1 }" >nul 2>nul
exit /b %errorlevel%
