/* PROYECTO ALLAS · Vehículos: dentro, historial y lista negra (y la sección Reservas) */
"use strict";

// ============================================================ Vehículos dentro

function pestanasVehiculos() {
  return `<div class="pestanas">${[["dentro", "Presentes"], ["historial", "Historial de entradas y salidas"], ["listanegra", "Lista negra"]]
    .filter(([id]) => id === "dentro" || (tieneModulo("gestion") && !oculto("veh:" + id))).map(([id, n]) => `<button data-vt="${id}" class="${(S.vehTab || "dentro") === id ? "activo" : ""}">${n}</button>`).join("")}</div>`;
}

function vistaVehiculos(v) {
  if (!tieneModulo("gestion")) S.vehTab = "dentro";   // licencia Lite: solo los vehículos que están dentro
  if (S.vehTab === "historial") return vistaHistorial(v);
  if (S.vehTab === "listanegra") return vistaListaNegra(v);
  if (S.vehTab === "reservas") S.vehTab = "dentro";   // 1.11: Reservas es una sección propia del menú
  v.innerHTML = `<div class="cab"><h2>Vehículos presentes</h2>
    <div class="fila"><input class="ent" id="v-buscar" placeholder="Buscar matrícula o código…" style="min-width:280px" autocomplete="off">
      <button class="btn" id="v-exp">Exportar…</button></div></div>
    ${pestanasVehiculos()}
    <div class="panel" id="v-tabla"><div class="vacio">Cargando…</div></div>`;
  let tm;
  const cargar = accion(async () => {
    if (!$("#v-buscar")) return;
    const filas = await api("GET", "/api/dentro?buscar=" + encodeURIComponent($("#v-buscar").value.trim()));
    if (!$("#v-tabla")) return;
    const sup = permitido("anular_tickets");
    $("#v-tabla").innerHTML = filas.length ? `<table class="tabla"><thead><tr><th>Código</th><th>Matrícula</th><th>Entrada</th><th>Tiempo</th><th class="der" title="Lo que pagaría si saliera ahora (ya descontado lo pagado y la señal de la reserva)">Pago estimado</th><th>Estado</th><th></th></tr></thead>
      <tbody>${filas.map((f) => `<tr><td class="mono">${esc(f.codigo)}</td><td><b>${esc(f.matricula || "—")}</b>${f.nota ? ` <button class="nota-chip" data-nota-ver="${f.id}" title="Tiene comentario interno: pulse para leerlo" aria-label="Leer el comentario interno">${icono("nota", 15)}</button>` : ""}${f.zona_id ? " " + chipZona(f.zona_id) : ""}${f.reserva_codigo ? ` <span class="etiqueta e-aviso" title="Entró con una reserva">Reserva ${f.reserva_codigo === "Reserva" ? "" : esc(f.reserva_codigo)}</span>` : ""}${f.manual ? ' <span class="etiqueta e-aviso">manual</span>' : ""}${f.vehiculo ? `<div class="suave" style="font-size:.82rem">${esc(f.vehiculo)}</div>` : ""}${f.cliente_nombre ? `<div style="font-size:.82rem"><span class="etiqueta e-abonado">Abonado</span> ${esc(f.cliente_nombre)}</div>` : ""}</td>
        <td>${fechaHora(f.entrada)}${f.tarifa_nombre && !f.cliente_id ? `<div class="suave" style="font-size:.8rem">${esc(f.tarifa_nombre)}</div>` : ""}</td><td class="num">${duracion(f.minutos)}</td><td class="num der">${f.cliente_id && f.pago_estimado_cent === 0 ? '<span class="suave">Abonado</span>' : f.pago_estimado_cent == null ? "—" : f.pago_estimado_cent === 0 ? '<span class="suave">0,00 €</span>' : `<b>${eur(f.pago_estimado_cent)}</b>`}</td><td>${etiquetaEstado(f.estado)}
        ${f.estado === "pagado" ? `<div class="suave" style="font-size:.8rem">sale antes de ${hora(f.salida_limite)}</div>` : ""}</td>
        <td class="der"><div class="fila" style="justify-content:flex-end">
          <button class="btn prim" data-cobrar="${f.id}">Cobrar</button>
          <details class="menu-mas"><summary class="btn" aria-label="Más acciones" title="Más acciones">⋯</summary>
            <div class="menu-mas-lista" role="menu">
              <button class="mi" data-serv="${f.id}" title="Añadir servicio o producto">+ Servicio o producto</button>
              <button class="mi" data-mod="${f.id}" title="Corregir la matrícula y cambiar la tarifa">Modificar matrícula y tarifa…</button>
              ${S.estado.estado_vehiculo ? `<button class="mi" data-estado="${f.id}" title="Daños que traía, notas y fotos">Estado del vehículo (daños y fotos)</button>` : ""}
              ${f.matricula ? `<button class="mi" data-hist="${f.id}" title="Visitas anteriores de este vehículo">Historial del vehículo</button>
              <button class="mi" data-nota="${f.id}" title="Comentario interno (se avisa en Entrada y Salida)">${f.nota ? "Editar comentario interno" : "Comentario interno"}</button>` : ""}
              ${(S.estado.zonas || []).length > 1 ? `<button class="mi" data-zona-v="${f.id}" title="Cambiar de zona">Cambiar zona</button>` : ""}
              <button class="mi" data-reimp="${f.id}">Reimprimir ticket</button>
              ${f.estado === "dentro" && !f.cliente_id ? `<hr><button class="mi peligro" data-anular="${f.id}" data-cod="${esc(f.codigo)}">Anular ticket${sup ? "" : "…"}</button>` : ""}
            </div></details>
        </div></td></tr>`).join("")}</tbody></table>
        <p class="suave" style="margin:12px 0 0">${filas.length} vehículo(s) · los que llevan menos tiempo, arriba · ${eur(filas.reduce((a, f) => a + (f.pago_estimado_cent || 0), 0))} de pago estimado en total.</p>`
      : `<div class="vacio">No hay vehículos ${$("#v-buscar").value ? "que coincidan" : "presentes"}.</div>`;
    $$("[data-cobrar]").forEach((b) => (b.onclick = () => buscarTicket("", { id: b.dataset.cobrar })));
    $$("[data-serv]").forEach((b) => (b.onclick = () => modalServicios(Number(b.dataset.serv))));
    $$("[data-mod]").forEach((b) => (b.onclick = () => { const f = filas.find((x) => x.id === Number(b.dataset.mod)); modalModificarEntrada(f, cargar, { tarifa: f.estado === "dentro" && !f.cliente_id && !f.n_pagos }); }));
    $$("[data-estado]").forEach((b) => (b.onclick = () => modalEstadoVehiculo(filas.find((f) => f.id === Number(b.dataset.estado)))));
    $$("[data-hist]").forEach((b) => (b.onclick = () => modalHistorialVehiculo(filas.find((f) => f.id === Number(b.dataset.hist)).matricula)));
    $$("[data-nota-ver]").forEach((b) => (b.onclick = () => modalLeerNota(filas.find((f) => f.id === Number(b.dataset.notaVer)), cargar)));
    $$("[data-nota]").forEach((b) => (b.onclick = () => modalNotaVehiculo(filas.find((f) => f.id === Number(b.dataset.nota)).matricula, cargar)));
    $$("[data-zona-v]").forEach((b) => (b.onclick = () => modalCambiarZona(filas.find((f) => f.id === Number(b.dataset.zonaV)), cargar)));
    $$("[data-reimp]").forEach((b) => (b.onclick = accion(async () => { notarImpresion(await api("POST", `/api/tickets/${b.dataset.reimp}/reimprimir`)); toast("Reimpreso", "ok"); })));
    $$("[data-anular]").forEach((b) => (b.onclick = () => modalAnular(b.dataset.anular, b.dataset.cod, cargar)));
  });
  $("#v-buscar").oninput = () => { clearTimeout(tm); tm = setTimeout(cargar, 250); };
  $$("[data-vt]").forEach((b) => (b.onclick = () => { S.vehTab = b.dataset.vt; vistaVehiculos(v); }));
  $("#v-exp").onclick = () => modalExportar("vehiculos", { origen: "dentro", buscar: $("#v-buscar").value.trim() }, "Vehículos presentes en el parking");
  $("#v-buscar").focus();
  cargar();
}

// Corregir la matrícula de un vehículo que está dentro (mal escrita al entrar o sin matrícula)
function modalMatricula(t, despues) {
  const c = modal(`<h2>Cambiar matrícula</h2>
    <p class="suave">Ticket <span class="mono">${esc(t.codigo)}</span> · entrada ${fechaHora(t.entrada)}</p>
    <form id="f-mat"><label class="campo">Matrícula<input class="ent grande mono" id="m-mat" value="${esc(t.matricula || "")}" style="text-transform:uppercase" autocomplete="off" placeholder="Vacío = sin matrícula…" spellcheck="false"></label>
    <p class="ayuda">Queda registrado en auditoría (matrícula anterior y nueva).</p>
    <div class="modal-pie"><button type="button" class="btn" data-c>Cancelar</button><button class="btn prim">Guardar matrícula</button></div></form>`);
  const inp = $("#m-mat"); inp.focus(); inp.select();
  $("[data-c]", c).onclick = cerrarModal;
  $("#f-mat").onsubmit = accion(async (e) => {
    e.preventDefault();
    const tk = await api("POST", `/api/tickets/${t.id}/matricula`, { matricula: inp.value });
    cerrarModal();
    toast(tk.matricula ? `Matrícula cambiada a ${tk.matricula}` : "Matrícula quitada", "ok");
    despues && despues();
  });
}

function modalAnular(id, codigo, despues) {
  const sup = permitido("anular_tickets");
  const c = modal(`<h2>Anular ticket</h2><p class="suave mono">${esc(codigo)}</p>
    <p>Solo para tickets emitidos por error y sin cobros. Queda registrado en auditoría.</p>
    <label class="campo">Motivo <span class="ayuda">opcional</span><input class="ent" id="a-motivo" autofocus autocomplete="off"></label>
    ${sup ? "" : `<h3 style="margin-top:16px">Autorización de supervisor</h3>
      <div class="rejilla r2" style="margin-top:8px"><label class="campo">Usuario<input class="ent" id="a-usu" autocomplete="off"></label>
      <label class="campo">PIN<input class="ent" id="a-pin" type="password" inputmode="numeric"></label></div>`}
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn peligro lleno" data-ok>Anular ticket</button></div>`);
  $("[data-c]", c).onclick = cerrarModal;
  $("[data-ok]", c).onclick = accion(async () => {
    const cuerpo = { motivo: $("#a-motivo").value };
    if (!sup) cuerpo.autorizacion = { usuario: $("#a-usu").value, pin: $("#a-pin").value };
    await api("POST", `/api/tickets/${id}/anular`, cuerpo);
    cerrarModal(); toast("Ticket anulado", "ok"); refrescarEstado(); despues && despues();
  });
}

const modalEstadoVehiculo = accion(async (t) => {
  const e = await api("GET", `/api/tickets/${t.id}/estado`);
  const urlFoto = (f) => `/api/tickets/${t.id}/fotos/${f.id}?token=${encodeURIComponent(S.token)}`;
  const m = modal(`<h2 class="titulo-icono">${icono("camara", 24)}Estado del vehículo · ${esc(t.matricula || t.codigo)}</h2>
    <p class="suave">Daños, rayones o detalles que ya traía al entrar. Queda guardado con el ticket por si hay una reclamación.</p>
    <label class="campo" style="margin-top:10px">Notas<textarea class="ent" id="ev-nota" rows="3" maxlength="500" placeholder="Rayón en la puerta trasera izquierda, retrovisor roto…">${esc(e.nota || "")}</textarea></label>
    <div class="fotos43" id="ev-fotos">${e.fotos.map((f) => `<a href="${urlFoto(f)}" target="_blank" rel="noopener"><img src="${urlFoto(f)}" alt="Foto"></a>`).join("")
      || '<span class="suave">Sin fotos.</span>'}</div>
    <div class="fila" style="margin-top:10px">
      <label class="btn">${icono("camara")} Hacer o elegir foto<input type="file" id="ev-arch" accept="image/*" capture="environment" hidden multiple></label>
      ${navigator.mediaDevices && navigator.mediaDevices.getUserMedia ? `<button class="btn" id="ev-webcam">Cámara del PC</button>` : ""}
      <span class="suave" style="font-size:.85rem">Hasta 6 fotos</span></div>
    <div id="ev-video" class="oculto"><video autoplay playsinline muted></video><div class="fila" style="margin-top:8px"><button class="btn prim" id="ev-disparar">Hacer la foto</button><button class="btn" id="ev-parar">Cerrar cámara</button></div></div>
    <div class="modal-pie"><button class="btn" data-c>Cerrar</button><button class="btn prim" data-ok>Guardar notas</button></div>`);
  let flujo = null;
  const parar = () => { if (flujo) flujo.getTracks().forEach((x) => x.stop()); flujo = null; $("#ev-video", m) && $("#ev-video", m).classList.add("oculto"); };
  const subir = async (blob) => {
    const r = await subirBinario(`/api/tickets/${t.id}/fotos`, blob, "image/jpeg");
    $("#ev-fotos", m).innerHTML = r.fotos.map((f) => `<a href="${urlFoto(f)}" target="_blank" rel="noopener"><img src="${urlFoto(f)}" alt="Foto"></a>`).join("");
    toast("Foto guardada", "ok");
  };
  $("#ev-arch", m).onchange = accion(async (ev) => { for (const a of ev.target.files) await subir(await aJpeg(a)); });
  if ($("#ev-webcam", m)) $("#ev-webcam", m).onclick = accion(async () => {
    flujo = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment", width: { ideal: 1600 } } });
    const v = $("#ev-video video", m); v.srcObject = flujo; $("#ev-video", m).classList.remove("oculto");
  });
  $("#ev-disparar", m).onclick = accion(async () => {
    const v = $("#ev-video video", m); const c = document.createElement("canvas");
    c.width = v.videoWidth; c.height = v.videoHeight; c.getContext("2d").drawImage(v, 0, 0);
    await subir(await aJpeg(c));
  });
  $("#ev-parar", m).onclick = parar;
  $("[data-c]", m).onclick = () => { parar(); cerrarModal(); };
  $("[data-ok]", m).onclick = accion(async () => {
    await api("PUT", `/api/tickets/${t.id}/estado`, { nota: $("#ev-nota", m).value });
    parar(); cerrarModal(); toast("Estado del vehículo guardado", "ok");
    if (S.cobro && S.cobro.ticket && S.cobro.ticket.id === t.id) { S.cobro.ticket.estado_nota = $("#ev-nota", m) ? $("#ev-nota", m).value : S.cobro.ticket.estado_nota; }
  });
});

// ======================================================================= Zonas

const COLORES_ZONA = ["#2563eb", "#16a34a", "#d97706", "#7c3aed", "#db2777", "#0891b2", "#dc2626", "#475569"];

function chipZona(zid) {
  const z = ((S.estado && S.estado.zonas) || []).find((x) => x.id === zid);
  return z ? `<span class="chip-zona-mini" style="--zc:${esc(z.color || "#64748b")}"><i></i>${esc(z.nombre)}</span>` : "";
}

function modalCambiarZona(t, despues) {
  if (!t) return;
  const zonas = (S.estado && S.estado.zonas) || [];
  const oc = ((S.estado && S.estado.ocupacion && S.estado.ocupacion.zonas) || []);
  const m = modal(`<h2>Cambiar de zona · ${esc(t.matricula || t.codigo)}</h2>
    <p class="suave">Elija la zona donde está ahora el vehículo. Las completas no se pueden elegir.</p>
    <div class="chips-zona grandes" style="margin-top:12px">${zonas.map((z) => {
      const o = oc.find((x) => x.id === z.id) || {};
      const llena = z.capacidad && o.ocupadas >= z.capacidad && z.id !== t.zona_id;
      return `<button type="button" class="chip-zona ${z.id === t.zona_id ? "activo" : ""}" data-z="${z.id}" style="--zc:${esc(z.color || "#64748b")}" ${llena ? "disabled" : ""}>
        <i></i>${esc(z.nombre)}${z.capacidad ? `<span>${o.ocupadas || 0}/${z.capacidad}${llena ? " · completa" : ""}</span>` : ""}</button>`;
    }).join("")}</div>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button></div>`);
  $("[data-c]", m).onclick = cerrarModal;
  $$("[data-z]", m).forEach((b) => (b.onclick = accion(async () => {
    const zid = Number(b.dataset.z);
    await api("PUT", `/api/tickets/${t.id}/zona`, { zona_id: zid });
    cerrarModal();
    S.estado = await api("GET", "/api/estado"); pintarBarra();
    toast(`${t.matricula || t.codigo}: ahora en ${zonas.find((z) => z.id === zid).nombre}`, "ok");
    despues && despues(zid);
  })));
}

// ============================================= Historial de entradas y salidas

function vistaHistorial(v) {
  const h = S.historial;
  v.innerHTML = `<div class="cab"><h2>Vehículos</h2></div>${pestanasVehiculos()}
    <form class="panel fila" id="f-hist" style="margin-bottom:14px;align-items:flex-end">
      <label class="campo">Desde<input class="ent" type="date" name="desde" value="${h.desde}"></label>
      <label class="campo">Hasta<input class="ent" type="date" name="hasta" value="${h.hasta}"></label>
      <label class="campo" style="flex:1;min-width:200px">Matrícula, ticket o cliente<input class="ent" name="buscar" value="${esc(h.buscar)}" autocomplete="off"></label>
      <label class="campo">Estado<select class="ent" name="estado">${[["", "Todos"], ["dentro", "Siguen dentro"], ["salido", "Salidos"], ["anulado", "Anulados"]]
        .map(([k, n]) => `<option value="${k}" ${h.estado === k ? "selected" : ""}>${n}</option>`).join("")}</select></label>
      <div class="fila"><button class="btn prim">Buscar</button>
        ${[["Hoy", 0, 0], ["7 días", -6, 0], ["30 días", -29, 0]].map(([n, d, a]) => `<button type="button" class="btn" data-rango="${d},${a}">${n}</button>`).join("")}
        <button type="button" class="btn" id="h-csv">Exportar…</button></div>
    </form>
    <div class="historial-resumen" id="h-res"></div>
    <div class="panel" id="h-tabla"><div class="vacio">Cargando…</div></div>`;
  $$("[data-vt]").forEach((b) => (b.onclick = () => { S.vehTab = b.dataset.vt; vistaVehiculos(v); }));
  const f = $("#f-hist");
  const leer = () => Object.assign(S.historial, Object.fromEntries(new FormData(f)));
  const qs = () => new URLSearchParams({ desde: h.desde, hasta: h.hasta, buscar: h.buscar, estado: h.estado }).toString();
  const cargar = accion(async () => {
    leer();
    const r = await api("GET", "/api/historial?" + qs());
    if (!$("#h-tabla")) return;
    const z = r.resumen;
    $("#h-res").innerHTML = `
      <div class="panel kpi"><div class="t">Entradas</div><div class="v num">${z.entradas}</div></div>
      <div class="panel kpi"><div class="t">Salidas</div><div class="v num">${z.salidas}</div></div>
      <div class="panel kpi"><div class="t">Siguen dentro</div><div class="v num">${z.dentro}</div></div>
      <div class="panel kpi"><div class="t">Cobrado por estancias</div><div class="v num verde">${eur(z.cobrado_cent)}</div></div>`;
    $("#h-tabla").innerHTML = r.filas.length ? `<div style="overflow-x:auto"><table class="tabla"><thead><tr><th>Matrícula</th><th>Ticket</th><th>Entrada</th><th>Salida</th><th>Tiempo</th><th>Estado</th><th class="der">Cobrado</th></tr></thead><tbody>
      ${r.filas.map((x) => `<tr><td><b class="mono">${esc(x.matricula || "—")}</b>${x.vehiculo ? `<div class="suave" style="font-size:.82rem">${esc(x.vehiculo)}</div>` : ""}
          ${x.cliente_nombre ? `<div style="font-size:.82rem">${chipTipo(x.cliente_tipo)} ${esc(x.cliente_nombre)}</div>` : ""}</td>
        <td class="mono" style="font-size:.85rem">${esc(x.codigo)}${x.manual ? ' <span class="etiqueta e-aviso">manual</span>' : ""}${x.perdido ? ' <span class="etiqueta e-err">perdido</span>' : ""}</td>
        <td class="num">${fechaHora(x.entrada)}${x.ajuste_min ? ` <span class="etiqueta e-aviso">${x.ajuste_min > 0 ? "+" : "−"}${Math.abs(x.ajuste_min)} min</span>` : ""}</td>
        <td class="num">${x.salida ? fechaHora(x.salida) : "—"}</td><td class="num">${duracion(x.minutos)}</td>
        <td>${etiquetaEstado(x.estado)}${x.anulado_motivo ? `<div class="suave" style="font-size:.8rem">${esc(x.anulado_motivo)}</div>` : ""}</td>
        <td class="der num">${x.cobrado_cent ? eur(x.cobrado_cent) : "—"}</td></tr>`).join("")}</tbody></table></div>
      <p class="suave" style="margin:12px 0 0">${r.filas.length} vehículo(s)${r.limite_alcanzado ? " · se muestran los 2000 más recientes; acote las fechas o use el CSV" : ""}.</p>`
      : '<div class="vacio">No hay entradas ni salidas en esas fechas.</div>';
  });
  f.onsubmit = (e) => { e.preventDefault(); cargar(); };
  $$("[data-rango]").forEach((b) => (b.onclick = () => {
    const [d, a] = b.dataset.rango.split(",").map(Number);
    f.desde.value = diaISO(d); f.hasta.value = diaISO(a); cargar();
  }));
  $("#h-csv").onclick = () => {
    leer();
    modalExportar("vehiculos", { origen: "historial", desde: h.desde, hasta: h.hasta, buscar: h.buscar, estado: h.estado },
      `Historial del ${fechaCorta2(h.desde)} al ${fechaCorta2(h.hasta)}`);
  };
  cargar();
}

// =========================================== Reservas de plataformas y hoteles

// 1.12: estado del cobro de la señal de una reserva online
function etiquetaPagoReserva(x) {
  if (!x.senal_cent || x.origen === "plataforma") return "";
  const m = eur(x.senal_cent);
  if (x.pago === "pendiente_pago") return `<span class="etiqueta e-aviso" title="Se cancela sola si no se cobra a tiempo">Señal ${m} sin cobrar${x.pago_limite ? " · hasta " + fechaHora(x.pago_limite) : ""}</span>`;
  if (x.pago === "pagada" && x.noshow) return `<span class="etiqueta e-aviso" title="No se presentó: la señal no se devuelve">Señal ${m} retenida (no se presentó)</span>`;
  if (x.pago === "pagada") return `<span class="etiqueta e-pagado">Señal ${m} cobrada${x.pago_metodo ? " · " + esc(x.pago_metodo) : ""}</span>`;
  if (x.pago === "a_devolver") return `<span class="etiqueta e-err">Devolver señal ${m}</span>`;
  if (x.pago === "devuelta") return `<span class="etiqueta e-salido">Señal ${m} devuelta</span>`;
  return "";
}

function modalSenalCobrada(x, despues, volver = null) {
  const m = modal(`<h2>Señal cobrada</h2><p>Reserva <b class="mono">${esc(x.codigo || x.ref || "")}</b> de <b>${esc(x.matricula)}</b>: señal de <b>${eur(x.senal_cent)}</b>.</p>
    <label class="campo">¿Cómo la ha pagado?<select class="ent" id="sc-met">${["Bizum", "Transferencia", "Efectivo en mostrador", "Tarjeta en mostrador", "Otro"].map((t) => `<option>${t}</option>`).join("")}</select></label>
    <p class="ayuda">Esto solo anota que se ha cobrado y mantiene la reserva; el dinero no entra en la caja del turno.</p>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Marcar como cobrada</button></div>`);
  $("[data-c]", m).onclick = () => { cerrarModal(); if (volver) volver(); };
  $("[data-ok]", m).onclick = accion(async () => {
    await api("POST", `/api/reservas-online/${x.id}/senal`, { metodo: $("#sc-met", m).value });
    cerrarModal(); toast("Señal anotada como cobrada", "ok"); refrescarEstado(); despues && despues();
  });
}

const ESTADO_RESERVA = { pendiente: ["e-dentro", "Pendiente"], usada: ["e-pagado", "Ha entrado"], cancelada: ["e-salido", "Cancelada"] };

function vistaReservas(v) {
  const r = S.reservas43;
  const puede = permitido("reservas");
  v.innerHTML = `<div class="cab"><h2>Reservas</h2>
      <div class="fila">${puede ? `<button class="btn" id="rs-importar">${icono("subir")} Importar listado…</button><button class="btn" id="rs-nueva">Añadir reserva…</button><button class="btn" id="rs-informe" hidden>Informe…</button><button class="btn prim" id="rs-online" hidden>Nueva reserva online…</button>` : ""}</div></div>
    <form class="panel fila" id="rs-filtro" style="margin-bottom:14px;align-items:flex-end">
      <label class="campo">Desde el día<input class="ent" type="date" name="desde" value="${esc(r.desde)}"></label>
      <label class="campo">Estado<select class="ent" name="estado">${[["pendiente", "Pendientes"], ["usada", "Han entrado"], ["cancelada", "Canceladas"], ["a_devolver", "Señal por devolver"], ["", "Todas"]]
        .map(([k, n]) => `<option value="${k}" ${r.estado === k ? "selected" : ""}>${n}</option>`).join("")}</select></label>
      <label class="campo" style="flex:1;min-width:200px">Matrícula, nº de reserva, cliente o plataforma<input class="ent" name="buscar" value="${esc(r.buscar)}" autocomplete="off"></label>
      <button class="btn prim">Buscar</button></form>
    <div id="rs-avisos"></div>
    <div class="panel" id="rs-tabla"><div class="vacio">Cargando…</div></div>
    <p class="ayuda" style="margin-top:10px">Las reservas pendientes se aplican solas cuando entra su matrícula (por la caja o por la cámara), desde 2 horas antes de la hora reservada: no se cobra el tiempo reservado y después se cobra con la tarifa del parking. Las reservas online solo guardan la plaza: se cobran con la tarifa normal al salir.</p>`;
  const f = $("#rs-filtro", v);
  const cargar = accion(async () => {
    Object.assign(S.reservas43, Object.fromEntries(new FormData(f)));
    const [lista, est] = await Promise.all([api("GET", "/api/reservas-previstas?" + new URLSearchParams({ desde: r.desde, estado: r.estado, buscar: r.buscar })),
      api("GET", "/api/reservas-online/estado").catch(() => ({ activas: false })), cargarTarifas()]);
    S.reservasOnline = !!est.activas;
    if ($("#rs-online", v)) $("#rs-online", v).hidden = !S.reservasOnline;
    if ($("#rs-informe", v)) $("#rs-informe", v).hidden = !S.reservasOnline;
    const res = S.reservasOnline ? await api("GET", "/api/reservas-online/resumen").catch(() => null) : null;
    if ($("#rs-avisos", v)) {
      $("#rs-avisos", v).innerHTML = res && (res.a_devolver || res.senal_pendiente) ? `<div class="aviso" style="margin-bottom:12px">${res.senal_pendiente ? `<b>${res.senal_pendiente}</b> reserva(s) con la señal sin cobrar (se cancelan solas al pasar su plazo). ` : ""}${res.a_devolver ? `<b>${res.a_devolver}</b> señal(es) por devolver: <button class="btn mini" id="rs-ver-dev">verlas</button>` : ""}</div>` : "";
      if ($("#rs-ver-dev", v)) $("#rs-ver-dev", v).onclick = () => { S.reservas43.estado = "a_devolver"; S.reservas43.desde = "2000-01-01"; vistaReservas(v); };
    }
    const hayTarifa = (S.tarifas || []).some((t) => t.activa && t.modo === "reserva");
    if (!$("#rs-tabla", v)) return;
    $("#rs-tabla", v).innerHTML = `${hayTarifa || S.reservasOnline ? "" : '<div class="aviso" style="margin-bottom:12px">Para usar reservas hace falta una tarifa de tipo <b>Reserva / hotel</b> (Ajustes → Precios → Tarifas): indica con qué tarifa se cobra al terminar la reserva.</div>'}
      ${lista.length ? `<div style="overflow-x:auto"><table class="tabla"><thead><tr><th>Matrícula</th><th>Reserva</th><th>Plataforma</th><th>Cliente</th><th>Estado</th><th></th></tr></thead><tbody>
      ${lista.map((x) => `<tr class="${x.estado === "cancelada" ? "inactiva" : ""}"><td><span class="placa-mini">${esc(x.matricula)}</span></td>
        <td class="num" style="white-space:nowrap">${fechaHora(x.desde)}<div class="suave" style="font-size:.85rem">hasta ${fechaHora(x.hasta)}</div></td>
        <td>${esc(x.plataforma || "—")}${x.origen === "web" && x.estado === "pendiente" && !x.revisada ? ' <span class="etiqueta e-aviso">Nueva</span>' : ""}${x.ref ? `<div class="mono suave" style="font-size:.82rem">${esc(x.ref)}</div>` : ""}
          ${x.origen === "web" ? `<div class="suave" style="font-size:.82rem">Reservada por el cliente${x.email_estado === "enviado" ? " · email enviado" : x.email_estado === "sin_correo" ? " · sin email (correo sin configurar)" : x.email_estado === "pendiente" ? " · email pendiente" : x.email_estado === "error" ? " · email fallido" : ""}</div>` : ""}${x.origen && x.origen !== "plataforma" ? `<div class="suave" style="font-size:.82rem">${[x.zona_nombre, x.tipo_vehiculo].filter(Boolean).map(esc).join(" · ")}${x.zona_nombre || x.tipo_vehiculo ? " · " : ""}${x.plazas > 1 ? x.plazas + " plazas · " : ""}${eur(x.importe_cent)}${x.senal_cent ? " en total" : " en el parking"}</div><div>${etiquetaPagoReserva(x)}</div>` : ""}</td>
        <td>${esc(x.cliente || "")}${x.nota ? `<div class="suave" style="font-size:.82rem">${esc(x.nota)}</div>` : ""}</td>
        <td><span class="etiqueta ${x.noshow ? "e-aviso" : (ESTADO_RESERVA[x.estado] || [])[0]}">${x.noshow ? "No se presentó" : (ESTADO_RESERVA[x.estado] || [])[1] || esc(x.estado)}</span>
          ${x.ticket_codigo ? `<div class="mono suave" style="font-size:.8rem">${esc(x.ticket_codigo)}</div>` : ""}</td>
        <td class="der" style="white-space:nowrap">${puede && x.pago === "a_devolver" && x.pago_ref ? `<button class="btn mini prim" data-rf="${x.id}">Devolver por Stripe</button> ` : ""}${puede && x.pago === "a_devolver" ? `<button class="btn mini" data-dv="${x.id}">Señal devuelta</button>` : ""}${puede && x.estado === "pendiente" && x.pago === "pendiente_pago" ? `<button class="btn mini prim" data-sc="${x.id}">Señal cobrada</button> ` : ""}${puede && x.estado === "pendiente" ? `${x.origen === "web" && !x.revisada ? `<button class="btn mini prim" data-cf="${x.id}">Confirmar</button> ` : ""}${x.origen && x.origen !== "plataforma" ? `<button class="btn mini" data-mo="${x.id}">Cambiar fechas</button> ` : `<button class="btn mini" data-ed="${x.id}">Editar</button> `}${menuAcciones([...(x.origen && x.origen !== "plataforma" && x.email ? [{ attr: `data-em="${x.id}"`, texto: "Reenviar confirmación por email" }] : []), { attr: `data-ca="${x.id}"`, texto: "Cancelar reserva", peligro: true }])}` : ""}</td></tr>`).join("")}
      </tbody></table></div>` : '<div class="vacio" style="padding:18px">No hay reservas con estos filtros.</div>'}`;
    $$("[data-ed]", v).forEach((b) => (b.onclick = () => modalReserva(lista.find((x) => String(x.id) === b.dataset.ed), cargar)));
    $$("[data-mo]", v).forEach((b) => (b.onclick = () => modalModificarReserva(lista.find((x) => String(x.id) === b.dataset.mo), cargar)));
    $$("[data-sc]", v).forEach((b) => (b.onclick = () => modalSenalCobrada(lista.find((x) => String(x.id) === b.dataset.sc), () => vistaReservas(v))));
    $$("[data-rf]", v).forEach((b) => (b.onclick = accion(async () => {
      const x = lista.find((y) => String(y.id) === b.dataset.rf);
      if (!(await confirmar("Devolver la señal", `Se devolverán <b>${eur(x.senal_cent)}</b> a la tarjeta de ${esc(x.cliente || x.matricula)} desde Stripe.`, { boton: "Devolver ahora" }))) return;
      await api("POST", `/api/reservas-online/${x.id}/senal-reembolsar`, {});
      toast("Señal devuelta por Stripe", "ok"); vistaReservas(v);
    })));
    $$("[data-dv]", v).forEach((b) => (b.onclick = accion(async () => {
      const x = lista.find((y) => String(y.id) === b.dataset.dv);
      if (!(await confirmar("Señal devuelta", `¿Ya ha devuelto la señal de <b>${eur(x.senal_cent)}</b> a ${esc(x.cliente || x.matricula)}?`, { boton: "Sí, devuelta" }))) return;
      await api("POST", `/api/reservas-online/${x.id}/senal-devuelta`, {});
      toast("Señal marcada como devuelta", "ok"); vistaReservas(v);
    })));
    $$("[data-cf]", v).forEach((b) => (b.onclick = accion(async () => {
      await api("POST", `/api/reservas-online/${b.dataset.cf}/confirmar`, {});
      toast("Reserva confirmada", "ok"); refrescarEstado(); cargar();
    })));
    $$("[data-em]", v).forEach((b) => (b.onclick = accion(async () => {
      const r = await api("POST", `/api/reservas-online/${b.dataset.em}/email`, {});
      toast(r.estado === "enviado" ? "Confirmación enviada" : r.estado === "sin_correo" ? "Falta configurar el correo (Ajustes → Email)" : "No se pudo enviar; se reintentará", r.estado === "enviado" ? "ok" : "err");
      cargar();
    })));
    $$("[data-ca]", v).forEach((b) => (b.onclick = accion(async () => {
      const x = lista.find((y) => String(y.id) === b.dataset.ca);
      if (!(await confirmar("Cancelar reserva", `¿Cancelar la reserva de <b>${esc(x.matricula)}</b>${x.ref ? ` (${esc(x.ref)})` : ""}? Si entra, se cobrará normal.`, { boton: "Cancelar reserva", peligro: true }))) return vistaReservas(v);
      await api("DELETE", x.origen && x.origen !== "plataforma" && S.reservasOnline ? `/api/reservas-online/${x.id}` : `/api/reservas-previstas/${x.id}`);
      toast("Reserva cancelada", "ok"); refrescarEstado(); vistaReservas(v);
    })));
  });
  f.onsubmit = (e) => { e.preventDefault(); cargar(); };
  if ($("#rs-nueva", v)) $("#rs-nueva", v).onclick = () => modalReserva(null, cargar);
  if ($("#rs-importar", v)) $("#rs-importar", v).onclick = () => modalImportarReservas(cargar);
  if ($("#rs-online", v)) $("#rs-online", v).onclick = () => modalReservaOnline(cargar);
  if ($("#rs-informe", v)) $("#rs-informe", v).onclick = () => modalInformeReservas();
  cargar();
}

// 1.18: el personal cambia las fechas de una reserva online (se vuelve a comprobar el cupo y se recalcula el precio)
function modalModificarReserva(x, despues) {
  const aLocal = (iso) => String(iso || "").slice(0, 16);
  const m = modal(`<h2>Cambiar fechas de la reserva</h2><p>Reserva <b class="mono">${esc(x.codigo || "")}</b> de <b>${esc(x.matricula)}</b>.</p>
    <div class="rejilla r2"><label class="campo">Entrada<input class="ent" type="datetime-local" id="mo-desde" value="${esc(aLocal(x.desde))}"></label>
    <label class="campo">Salida<input class="ent" type="datetime-local" id="mo-hasta" value="${esc(aLocal(x.hasta))}"></label></div>
    <p class="ayuda">Se comprueba que haya plazas y se recalcula el importe${x.pago === "pagada" ? ". La señal ya está pagada: solo se admiten fechas con la misma señal" : ""}. Se avisa al cliente por email si tiene.</p>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Guardar</button></div>`);
  $("[data-c]", m).onclick = cerrarModal;
  $("[data-ok]", m).onclick = accion(async () => {
    await api("PUT", `/api/reservas-online/${x.id}`, { desde: $("#mo-desde", m).value, hasta: $("#mo-hasta", m).value });
    cerrarModal(); toast("Reserva modificada", "ok"); despues && despues();
  });
}

// 1.18: informe de reservas (totales, señales, no presentados y excesos de estancia) con descarga en CSV
function modalInformeReservas() {
  const hoy = new Date(), pad = (n) => String(n).padStart(2, "0");
  const ini = `${hoy.getFullYear()}-${pad(hoy.getMonth() + 1)}-01`, fin = `${hoy.getFullYear()}-${pad(hoy.getMonth() + 1)}-${pad(hoy.getDate())}`;
  const m = modal(`<h2>Informe de reservas</h2>
    <div class="fila" style="gap:10px;align-items:flex-end;flex-wrap:wrap"><label class="campo">Entradas desde<input class="ent" type="date" id="in-d" value="${ini}"></label>
      <label class="campo">hasta<input class="ent" type="date" id="in-h" value="${fin}"></label><button class="btn" id="in-ver">Ver</button><button class="btn" id="in-csv">Descargar CSV</button></div>
    <div id="in-res" style="margin-top:14px"><span class="suave">Cargando…</span></div>
    <div class="modal-pie"><button class="btn prim" data-c>Cerrar</button></div>`, { ancho: true });
  $("[data-c]", m).onclick = cerrarModal;
  const cargar = accion(async () => {
    const i = await api("GET", "/api/reservas-online/informe?" + new URLSearchParams({ desde: $("#in-d", m).value, hasta: $("#in-h", m).value }));
    const e = i.por_estado, sn = i.senal;
    $("#in-res", m).innerHTML = `<div class="rejilla r3" style="gap:10px">
      ${[["Reservas", i.total], ["Pendientes", e.pendiente], ["Han entrado", e.usada], ["Canceladas", e.cancelada], ["No se presentaron", `${e.no_presentada} (${i.no_presentadas_pct} %)`], ["Importe previsto", eur(i.importe_previsto_cent)]]
        .map(([k, val]) => `<div class="panel"><div class="suave">${k}</div><b style="font-size:1.3rem">${val}</b></div>`).join("")}</div>
      <h4 style="margin:14px 0 6px">Señales</h4>
      <p class="suave" style="margin:0">Cobradas ${eur(sn.cobrada)} · devueltas ${eur(sn.devuelta)} · por devolver ${eur(sn.por_devolver)} · retenidas por no presentarse ${eur(sn.retenida)} · pendientes de cobro ${eur(sn.pendiente)}</p>
      <h4 style="margin:14px 0 6px">Estancias que se pasaron de la hora reservada</h4>
      <p class="suave" style="margin:0">${i.excesos.n ? `<b>${i.excesos.n}</b> reserva(s), de media <b>${i.excesos.minutos_medios}</b> min (máximo ${i.excesos.max} min). El tiempo de más se cobra con la tarifa normal al salir.` : "Ninguna."}</p>`;
  });
  $("#in-ver", m).onclick = cargar;
  $("#in-csv", m).onclick = () => descargarUrl("/api/reservas-online/informe.csv", { desde: $("#in-d", m).value, hasta: $("#in-h", m).value });
  cargar();
}

// 1.8: reserva online hecha por el personal (zona, fechas, disponibilidad y precio en vivo)
async function modalReservaOnline(despues) {
  const [zonas, cfg] = await Promise.all([api("GET", "/api/zonas"), api("GET", "/api/reservas-online/estado")]);
  if (!cfg.activas) return toast("Las reservas online están desactivadas (Ajustes → Reservas online)", "err");
  const tipos = (S.estado && S.estado.tipos_vehiculo) || [];
  const activas = ((zonas && zonas.zonas) || []).filter((z) => z.activa);
  const m = modal(`<h2>Nueva reserva online</h2>
    <div class="rejilla r2" style="margin-top:12px">
      <label class="campo">Matrícula<input class="ent grande mono" id="ro-mat" style="text-transform:uppercase" autofocus></label>
      ${activas.length ? `<label class="campo">Zona<select class="ent" id="ro-zona">${activas.map((z) => `<option value="${z.id}">${esc(z.nombre)}</option>`).join("")}</select></label>` : ""}
      <label class="campo">Entrada<input class="ent" type="datetime-local" id="ro-desde"></label>
      <label class="campo">Salida<input class="ent" type="datetime-local" id="ro-hasta"></label>
      ${cfg.max_plazas > 1 ? `<label class="campo">Plazas<input class="ent num" type="number" id="ro-plazas" min="1" max="${cfg.max_plazas}" value="1"></label>` : ""}
      ${tipos.length ? `<label class="campo">Tipo de vehículo<select class="ent" id="ro-tipo"><option value="">—</option>${tipos.map((t) => `<option>${esc(t)}</option>`).join("")}</select></label>` : ""}
      <label class="campo">Cliente<input class="ent" id="ro-cli" maxlength="80"></label>
      <label class="campo">Email<input class="ent" type="email" id="ro-email" maxlength="120"></label>
      <label class="campo">Teléfono<input class="ent" id="ro-tel" maxlength="30"></label>
      <label class="campo" style="grid-column:1/-1">Notas<input class="ent" id="ro-nota" maxlength="200"></label></div>
    <div class="panel" id="ro-resumen" style="margin-top:12px"><span class="suave">Elija las fechas para ver las plazas libres y el precio.</span></div>
    <div id="ro-senal" class="fila" style="margin-top:10px;gap:12px;flex-wrap:wrap" hidden>
      <label class="fila" style="gap:8px;font-weight:600"><input type="checkbox" id="ro-cobrada"> Señal cobrada ahora</label>
      <select class="ent" id="ro-met" style="width:auto"><option>Efectivo en mostrador</option><option>Tarjeta en mostrador</option><option>Bizum</option><option>Transferencia</option></select></div>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok disabled>Reservar</button></div>`, { ancho: true });
  const datos = () => ({ matricula: $("#ro-mat", m).value, zona_id: $("#ro-zona", m) ? Number($("#ro-zona", m).value) : null,
    desde: $("#ro-desde", m).value, hasta: $("#ro-hasta", m).value, plazas: $("#ro-plazas", m) ? Number($("#ro-plazas", m).value || 1) : 1, tipo_vehiculo: $("#ro-tipo", m) ? $("#ro-tipo", m).value : "",
    cliente: $("#ro-cli", m).value, email: $("#ro-email", m).value, telefono: $("#ro-tel", m).value, nota: $("#ro-nota", m).value,
    senal_cobrada: $("#ro-cobrada", m).checked && !$("#ro-senal", m).hidden, senal_metodo: $("#ro-met", m).value });
  let n = 0;
  const calcular = async () => {
    const d = datos(), mi = ++n, res = $("#ro-resumen", m), ok = $("[data-ok]", m);
    ok.disabled = true;
    if (!d.desde || !d.hasta) return;
    try {
      const q = new URLSearchParams({ zona_id: d.zona_id || "", desde: d.desde, hasta: d.hasta, plazas: d.plazas });
      const [disp, pr] = await Promise.all([api("GET", "/api/reservas-online/disponibilidad?" + q), api("POST", "/api/reservas-online/presupuesto", d)]);
      if (mi !== n || !res.isConnected) return;
      res.innerHTML = disp.disponible
        ? `<b>${disp.libres}</b> plaza(s) libre(s) de ${disp.cupo} · ${Math.floor(pr.minutos / 1440)} d ${Math.floor(pr.minutos % 1440 / 60)} h · <b>${eur(pr.importe_cent)}</b> ${pr.senal_cent ? `· señal <b>${eur(pr.senal_cent)}</b> (resto ${eur(pr.importe_cent - pr.senal_cent)} en el parking)` : "a pagar en el parking"} <span class="suave">(tarifa ${esc(pr.tarifa)})</span>`
        : `<b style="color:var(--rojo)">No quedan plazas libres en esas fechas.</b>`;
      ok.disabled = !disp.disponible;
      $("#ro-senal", m).hidden = !(disp.disponible && pr.senal_cent);
    } catch (e) { if (mi === n && res.isConnected) res.innerHTML = `<b style="color:var(--rojo)">${esc(e.message)}</b>`; }
  };
  ["#ro-zona", "#ro-desde", "#ro-hasta", "#ro-tipo", "#ro-plazas"].forEach((id) => { if ($(id, m)) $(id, m).onchange = calcular; });
  $("[data-c]", m).onclick = cerrarModal;
  $("[data-ok]", m).onclick = accion(async () => {
    const r = await api("POST", "/api/reservas-online", datos());
    cerrarModal(); toast(`Reserva ${r.codigo} creada`, "ok"); despues && despues();
  });
}

function opcionesTarifaReserva(sel) {
  return (S.tarifas || []).filter((t) => t.activa && t.modo === "reserva")
    .map((t) => `<option value="${t.id}" ${Number(sel) === t.id ? "selected" : ""}>${esc(t.nombre)}</option>`).join("");
}

function modalReserva(x, despues) {
  const m = modal(`<h2>${x ? "Editar reserva" : "Añadir reserva"}</h2>
    <div class="rejilla r2" style="margin-top:12px">
      <label class="campo">Matrícula<input class="ent grande mono" id="rv-mat" value="${esc(x ? x.matricula : "")}" style="text-transform:uppercase" autofocus></label>
      <label class="campo">Tarifa de reserva<select class="ent" id="rv-tar">${opcionesTarifaReserva(x && x.tarifa_id)}</select></label>
      <label class="campo">Entrada (desde)<input class="ent" type="datetime-local" id="rv-desde" value="${esc(x ? aLocalInput(x.desde) : "")}"></label>
      <label class="campo">Salida (hasta)<input class="ent" type="datetime-local" id="rv-hasta" value="${esc(x ? aLocalInput(x.hasta) : "")}"></label>
      <label class="campo">Plataforma / canal<input class="ent" id="rv-plat" maxlength="40" value="${esc(x ? x.plataforma || "" : "")}" list="rv-plats" placeholder="Parclick, ElParking, Hotel Sol…">
        <datalist id="rv-plats">${["Parclick", "ElParking", "Parkimeter", "Booking", "Teléfono", "Web propia"].map((p) => `<option value="${p}">`).join("")}</datalist></label>
      <label class="campo">Nº de reserva<input class="ent mono" id="rv-ref" maxlength="60" value="${esc(x ? x.ref || "" : "")}"></label>
      <label class="campo">Cliente<input class="ent" id="rv-cli" maxlength="80" value="${esc(x ? x.cliente || "" : "")}"></label>
      <label class="campo">Notas<input class="ent" id="rv-nota" maxlength="200" value="${esc(x ? x.nota || "" : "")}"></label></div>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Guardar</button></div>`, { ancho: true });
  $("[data-c]", m).onclick = cerrarModal;
  $("[data-ok]", m).onclick = accion(async () => {
    const d = { matricula: $("#rv-mat", m).value, desde: $("#rv-desde", m).value, hasta: $("#rv-hasta", m).value, plataforma: $("#rv-plat", m).value,
      ref: $("#rv-ref", m).value, cliente: $("#rv-cli", m).value, nota: $("#rv-nota", m).value, tarifa_id: Number($("#rv-tar", m).value) || null };
    await api(x ? "PUT" : "POST", x ? `/api/reservas-previstas/${x.id}` : "/api/reservas-previstas", d);
    cerrarModal(); toast("Reserva guardada", "ok"); despues && despues();
  });
}

function modalImportarReservas(despues) {
  const m = modal(`<h2 class="titulo-icono">${icono("subir", 24)}Importar reservas</h2>
    <p class="suave">Listado de reservas de Parclick, ElParking, Parkimeter, su hotel o su web, en <b>Excel (.xlsx)</b> o <b>CSV</b>. Cada plataforma lo descarga desde su panel.
      Se reconocen las columnas solas; revíselas antes de importar. Si vuelve a importar el mismo listado, las reservas no se repiten.</p>
    <div class="rejilla r2" style="margin-top:12px">
      <label class="campo">Plataforma <span class="ayuda">si el listado no la trae</span><input class="ent" id="ir-plat" list="rv-plats2" placeholder="Parclick">
        <datalist id="rv-plats2">${["Parclick", "ElParking", "Parkimeter", "Booking"].map((p) => `<option value="${p}">`).join("")}</datalist></label>
      <label class="campo">Tarifa de reserva<select class="ent" id="ir-tar">${opcionesTarifaReserva()}</select></label></div>
    <label class="btn prim" style="margin-top:12px">Elegir el archivo…<input type="file" id="ir-arch" accept=".csv,.xlsx,.txt" hidden></label>
    <div id="ir-paso2" style="margin-top:14px"></div>
    <div class="modal-pie"><button class="btn" data-c>Cerrar</button><button class="btn" id="ir-comprobar" disabled>Comprobar</button><button class="btn prim" id="ir-ok" disabled>Importar</button></div>`, { ancho: true });
  let leido = null;
  $("[data-c]", m).onclick = cerrarModal;
  const mapeo = () => Object.fromEntries($$("[data-campo]", m).map((s) => [s.dataset.campo, s.value === "" ? "" : Number(s.value)]));
  const cuerpo = (aplicar) => ({ token: leido.token, mapeo: mapeo(), plataforma: $("#ir-plat", m).value.trim(), tarifa_id: Number($("#ir-tar", m).value) || null, aplicar });
  const resumen = (r) => `<div class="aviso ${r.errores.length ? "" : "verde"}" style="margin-top:12px">${r.aplicado ? "Importado" : "Se importarían"}:
      <b>${r.nuevas}</b> nuevas · <b>${r.actualizadas}</b> actualizadas · ${r.iguales} sin cambios${r.errores.length ? ` · <b>${r.errores.length}</b> filas con error` : ""}</div>
    ${r.errores.length ? `<ul class="errores-imp">${r.errores.map((e) => `<li>${esc(e)}</li>`).join("")}</ul>` : ""}`;
  $("#ir-arch", m).onchange = accion(async (e) => {
    const a = e.target.files[0]; if (!a) return;
    leido = await subirBinario("/api/reservas-previstas/leer?nombre=" + encodeURIComponent(a.name), a, "application/octet-stream");
    const pl = $("#ir-plat", m);
    if (!pl.value.trim()) {
      const g = ["Parclick", "ElParking", "Parkimeter", "Booking"].find((x) => a.name.toLowerCase().replace(/[^a-z]/g, "").includes(x.toLowerCase()));
      if (g) pl.value = g;
    }
    const op = (sel) => `<option value="">—</option>` + leido.cabeceras.map((c, i) => `<option value="${i}" ${sel === i ? "selected" : ""}>${esc(c || `Columna ${i + 1}`)}</option>`).join("");
    $("#ir-paso2", m).innerHTML = `<h3 style="margin-bottom:10px">${esc(a.name)} · ${leido.total} fila(s)</h3>
      <div class="mapeo43">${leido.campos.map(([k, n]) => `<label class="campo">${esc(n)}${["matricula", "desde", "hasta"].includes(k) ? " *" : ""}<select class="ent" data-campo="${k}">${op(leido.sugerencia[k])}</select></label>`).join("")}</div>
      <div style="overflow-x:auto;margin-top:10px"><table class="tabla mini43"><thead><tr>${leido.cabeceras.map((c) => `<th>${esc(c)}</th>`).join("")}</tr></thead>
        <tbody>${leido.muestra.slice(0, 5).map((f) => `<tr>${f.map((c) => `<td>${esc(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>
      <div id="ir-res"></div>`;
    $("#ir-comprobar", m).disabled = false; $("#ir-ok", m).disabled = false;
  });
  $("#ir-comprobar", m).onclick = accion(async () => { $("#ir-res", m).innerHTML = resumen(await api("POST", "/api/reservas-previstas/importar", cuerpo(false))); });
  $("#ir-ok", m).onclick = accion(async () => {
    const r = await api("POST", "/api/reservas-previstas/importar", cuerpo(true));
    $("#ir-res", m).innerHTML = resumen(r);
    $("#ir-ok", m).disabled = true;
    toast(`${r.nuevas} reservas nuevas importadas`, "ok");
    despues && despues();
  });
}

// ================================================================= Lista negra

function vistaListaNegra(v) {
  const sup = tieneRol("admin", "supervisor");
  v.innerHTML = `<div class="cab"><h2>Lista negra de matrículas</h2>
      <div class="fila"><input class="ent" id="ln-buscar" placeholder="Buscar matrícula o motivo…" style="min-width:260px" value="${esc(S.listaNegra.buscar)}" autocomplete="off">
      ${sup ? '<button class="btn prim" id="ln-nueva">Añadir matrícula…</button>' : ""}</div></div>
    ${pestanasVehiculos()}
    <div class="panel" id="ln-modo"></div>
    <div class="panel" id="ln-tabla" style="margin-top:14px"><div class="vacio">Cargando…</div></div>`;
  $$("[data-vt]").forEach((b) => (b.onclick = () => { S.vehTab = b.dataset.vt; vistaVehiculos(v); }));
  const cargar = accion(async () => {
    const r = await api("GET", "/api/lista-negra?" + new URLSearchParams({ buscar: S.listaNegra.buscar, todas: S.listaNegra.todas ? "1" : "" }));
    if (!$("#ln-tabla")) return;
    const admin = tieneRol("admin");
    $("#ln-modo").innerHTML = `<div class="fila" style="justify-content:space-between;align-items:center">
      <div><b>Al registrar la entrada</b> de una de estas matrículas:
        ${admin ? `<select class="ent" id="ln-modo-sel" style="width:auto;display:inline-block;margin-left:6px">
          <option value="avisar" ${r.modo === "avisar" ? "selected" : ""}>Avisar (el cajero decide y queda anotado)</option>
          <option value="bloquear" ${r.modo === "bloquear" ? "selected" : ""}>Bloquear (solo entra con autorización de un supervisor)</option></select>`
          : `<b>${r.modo === "bloquear" ? "se bloquea (hace falta un supervisor)" : "se avisa"}</b>`}</div>
      <label class="fila" style="gap:6px"><input type="checkbox" id="ln-todas" ${S.listaNegra.todas ? "checked" : ""}> Ver también las retiradas</label></div>
      <p class="ayuda" style="margin:6px 0 0">También se avisa al escribir la matrícula en Entrada, en la Salida y en la caja móvil.</p>`;
    $("#ln-todas").onchange = (e) => { S.listaNegra.todas = e.target.checked; cargar(); };
    if ($("#ln-modo-sel")) $("#ln-modo-sel").onchange = accion(async (e) => { await api("PUT", "/api/config", { lista_negra_modo: e.target.value }); toast("Guardado", "ok"); refrescarEstado(); });
    $("#ln-tabla").innerHTML = r.filas.length ? `<table class="tabla"><thead><tr><th>Matrícula</th><th>Motivo</th><th>Añadida</th><th>Estado</th><th></th></tr></thead><tbody>
      ${r.filas.map((x) => `<tr class="${x.activa ? "" : "inactiva"}"><td><span class="placa-mini">${esc(x.matricula)}</span></td>
        <td><b>${esc(x.motivo)}</b>${x.nota ? `<div class="suave" style="font-size:.85rem">${esc(x.nota)}</div>` : ""}</td>
        <td class="suave" style="font-size:.88rem">${fechaHora(x.creada)}${x.creada_por ? `<br>${esc(x.creada_por)}` : ""}</td>
        <td>${x.activa ? (x.dentro ? '<span class="etiqueta e-err">Dentro ahora</span>' : '<span class="etiqueta e-err">En lista</span>')
          : `<span class="etiqueta e-salido">Retirada</span><div class="suave" style="font-size:.8rem">${fechaHora(x.retirada)}${x.retirada_por_nombre ? " · " + esc(x.retirada_por_nombre) : ""}</div>`}</td>
        <td class="der" style="white-space:nowrap">${sup && x.activa ? `<button class="btn mini" data-ed="${x.id}">Editar</button> ${menuAcciones([{ attr: `data-qu="${x.id}"`, texto: "Retirar de la lista negra", peligro: true }])}` : ""}</td></tr>`).join("")}</tbody></table>`
      : `<div class="vacio" style="padding:18px">${S.listaNegra.buscar ? "Ninguna coincide con la búsqueda." : "La lista negra está vacía."}</div>`;
    $$("[data-ed]", v).forEach((b) => (b.onclick = () => modalListaNegra(r.filas.find((x) => String(x.id) === b.dataset.ed), cargar)));
    $$("[data-qu]", v).forEach((b) => (b.onclick = accion(async () => {
      const x = r.filas.find((y) => String(y.id) === b.dataset.qu);
      if (!(await confirmar("Retirar de la lista negra", `¿Retirar la matrícula <b>${esc(x.matricula)}</b>? Queda en el historial.`, { boton: "Retirar" }))) return vistaListaNegra(v);
      await api("DELETE", `/api/lista-negra/${x.id}`); toast("Retirada", "ok"); vistaListaNegra(v);
    })));
  });
  let tm;
  $("#ln-buscar").oninput = (e) => { S.listaNegra.buscar = e.target.value.trim(); clearTimeout(tm); tm = setTimeout(cargar, 250); };
  if ($("#ln-nueva")) $("#ln-nueva").onclick = () => modalListaNegra(null, cargar);
  cargar();
}

function modalListaNegra(x, despues) {
  const m = modal(`<h2>${x ? "Editar" : "Añadir a la lista negra"}</h2>
    <div class="rejilla" style="margin-top:10px">
      <label class="campo">Matrícula<input class="ent grande mono" id="ln-mat" value="${esc(x ? x.matricula : "")}" ${x ? "disabled" : "autofocus"} style="text-transform:uppercase" placeholder="1234 ABC…" spellcheck="false" autocomplete="off"></label>
      <label class="campo">Motivo<input class="ent" id="ln-mot" maxlength="200" value="${esc(x ? x.motivo : "")}" placeholder="Impago, daños, vehículo abandonado, orden policial…" ${x ? "autofocus" : ""}></label>
      <label class="campo">Nota interna <span class="ayuda">opcional</span><textarea class="ent" id="ln-nota" rows="2" maxlength="500">${esc(x && x.nota || "")}</textarea></label></div>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn peligro" data-ok>${x ? "Guardar" : "Añadir"}</button></div>`);
  $("[data-c]", m).onclick = cerrarModal;
  $("[data-ok]", m).onclick = accion(async () => {
    const d = { matricula: $("#ln-mat", m).value, motivo: $("#ln-mot", m).value, nota: $("#ln-nota", m).value };
    await api(x ? "PUT" : "POST", x ? `/api/lista-negra/${x.id}` : "/api/lista-negra", d);
    cerrarModal(); toast(x ? "Guardado" : "Añadida a la lista negra", "ok"); despues && despues();
  });
}

// ====================================== Fotos de los vehículos de los abonados

const fotosVehiculoActivas = () => tieneModulo("abonados") && !(S.estado && S.estado.vehiculo_fotos === false);

const urlFotoVehiculo = (cid, mat, v) => `/api/clientes/${cid}/vehiculos/${encodeURIComponent(mat)}/foto?token=${encodeURIComponent(S.token)}&v=${encodeURIComponent(v || "")}`;

// Lista de vehículos con miniatura (ficha y salida). editable: con botón para poner / cambiar la foto
function vehiculosConFoto(c, editable) {
  if (!c.vehiculos.length) return "—";
  if (!fotosVehiculoActivas() || c.tipo === "facturacion") return c.vehiculos.map((v) => descVehiculo(v)).join("<br>");
  return `<div class="veh-fotos">${c.vehiculos.map((v) => `<div class="veh-foto">
      ${v.foto ? `<img src="${urlFotoVehiculo(c.id, v.matricula, v.foto)}" alt="${esc(v.matricula)}" data-ver-foto="${esc(urlFotoVehiculo(c.id, v.matricula, v.foto))}" title="Ver en grande">`
        : `<span class="sin-foto">🚗</span>`}
      <div>${descVehiculo(v)}${editable ? `<div class="fila" style="gap:4px;margin-top:4px">
        <label class="btn mini">${v.foto ? "Cambiar foto" : "📷 Foto"}<input type="file" accept="image/*" capture="environment" hidden data-vfoto="${c.id}" data-mat="${esc(v.matricula)}"></label>
        ${v.foto ? `<button class="btn mini peligro" data-vquitar="${c.id}" data-mat="${esc(v.matricula)}" title="Quitar la foto">✕</button>` : ""}</div>` : ""}</div></div>`).join("")}</div>`;
}

// ============================================================ al cargar

S.historial = S.historial || { desde: diaISO(-6), hasta: diaISO(0), buscar: "", estado: "" };

S.reservas43 = S.reservas43 || { desde: hoyISO(), estado: "pendiente", buscar: "" };

// Vehículos → Lista negra
S.listaNegra = S.listaNegra || { buscar: "", todas: false };

// Fotos de los vehículos de los abonados: subir, quitar y ver en grande
document.addEventListener("change", accion(async (e) => {
  const i = e.target.closest && e.target.closest("[data-vfoto]");
  if (!i || !i.files[0]) return;
  const blob = await reducirFoto(i.files[0], 800);
  const r = await fetch(`/api/clientes/${i.dataset.vfoto}/vehiculos/${encodeURIComponent(i.dataset.mat)}/foto`,
    { method: "POST", headers: { "X-Token": S.token, "Content-Type": "application/octet-stream" }, body: blob });
  if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || "No se pudo guardar la foto");
  toast("Foto del vehículo guardada", "ok");
  abrirFicha(Number(i.dataset.vfoto));
}));

document.addEventListener("click", (e) => {
  const q = e.target.closest && e.target.closest("[data-vquitar]");
  if (q) {
    accion(async () => {
      await api("DELETE", `/api/clientes/${q.dataset.vquitar}/vehiculos/${encodeURIComponent(q.dataset.mat)}/foto`);
      toast("Foto quitada", "ok"); abrirFicha(Number(q.dataset.vquitar));
    })();
    return;
  }
  const v = e.target.closest && e.target.closest("[data-ver-foto]");
  if (v) {
    const capa = document.createElement("div");
    capa.className = "foto-grande";
    capa.innerHTML = `<img src="${v.dataset.verFoto}" alt="">`;
    capa.onclick = () => capa.remove();
    document.body.appendChild(capa);
  }
});



// ============================================================ 4.50: comentario interno e historial del vehículo

const modalNotaVehiculo = accion(async (matricula, despues) => {
  const r = await api("GET", "/api/vehiculo/nota?matricula=" + encodeURIComponent(matricula));
  const n = r.nota;
  const m = modal(`<h2>Comentario interno · ${esc(matricula)}</h2>
    <p class="suave">Solo lo ve el personal: no sale en tickets ni facturas. Se avisa en <b>Entrada</b> al escribir esta matrícula y en <b>Salida</b> al cobrar.</p>
    <label class="campo" style="margin-top:10px">Comentario<textarea class="ent" id="nv-txt" rows="4" maxlength="500" placeholder="Ej.: dejó el maletero abierto; avisar a Marta al salir; golpe en el parachoques…">${esc(n ? n.nota : "")}</textarea></label>
    ${n ? `<p class="ayuda">Último cambio: ${fechaHora(n.actualizada)}${n.usuario ? " · " + esc(n.usuario) : ""}</p>` : ""}
    <div class="modal-pie">${n ? '<button class="btn peligro" id="nv-quitar">Quitar comentario</button><span style="flex:1"></span>' : ""}
      <button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Guardar</button></div>`);
  $("#nv-txt", m).focus();
  $("[data-c]", m).onclick = cerrarModal;
  const guardar = accion(async (texto) => {
    await api("PUT", "/api/vehiculo/nota", { matricula, nota: texto });
    cerrarModal(); toast(texto ? "Comentario guardado" : "Comentario quitado", "ok"); despues && despues();
  });
  $("[data-ok]", m).onclick = () => guardar($("#nv-txt", m).value);
  if (n) $("#nv-quitar", m).onclick = () => guardar("");
});

// Lectura rápida del comentario (desde el icono de la lista)
function modalLeerNota(f, despues) {
  const m = modal(`<h2>Comentario interno · ${esc(f.matricula)}</h2>
    <div class="nota-lectura">${esc(f.nota)}</div>
    <div class="modal-pie"><button class="btn" data-c>Cerrar</button><button class="btn prim" data-ed>Editar</button></div>`);
  $("[data-c]", m).onclick = cerrarModal;
  $("[data-ed]", m).onclick = () => { cerrarModal(); modalNotaVehiculo(f.matricula, despues); };
}

const modalHistorialVehiculo = accion(async (matricula) => {
  const h = await api("GET", "/api/vehiculo/historial?matricula=" + encodeURIComponent(matricula));
  const m = modal(`<h2>Historial · ${esc(h.matricula)}</h2>
    ${h.cliente ? `<p class="suave">Vehículo de <b>${esc(h.cliente)}</b></p>` : ""}
    ${h.nota ? `<div class="aviso-nota"><span class="an-ico">${icono("nota", 18)}</span><div class="an-cuerpo"><div class="an-tit">Comentario interno</div><div class="an-txt">${esc(h.nota.nota)}</div></div></div>` : ""}
    <div class="hv-resumen"><div><span class="v num">${h.visitas}</span><span>visita${h.visitas === 1 ? "" : "s"}</span></div>
      <div><span class="v num">${eur(h.total_cent)}</span><span>pagado en total</span></div>
      <div><span class="v num">${h.visitas ? duracion(h.media_min) : "—"}</span><span>estancia media</span></div>
      <div><span class="v num">${h.primera ? fecha(h.primera) : "—"}</span><span>primera visita</span></div></div>
    ${h.filas.length ? `<div class="hv-tabla"><table class="tabla"><thead><tr><th>Entrada</th><th>Salida</th><th>Tiempo</th><th>Tarifa</th><th class="der">Pagado</th><th>Estado</th></tr></thead><tbody>
      ${h.filas.map((f) => `<tr><td>${fechaHora(f.entrada)}</td><td>${f.salida ? fechaHora(f.salida) : "—"}</td><td class="num">${duracion(f.minutos)}</td>
        <td>${esc(f.tarifa_nombre || "")}${f.manual ? ' <span class="etiqueta e-aviso">manual</span>' : ""}</td><td class="der num">${f.pagado_cent ? eur(f.pagado_cent) : "—"}</td><td>${etiquetaEstado(f.estado)}</td></tr>`).join("")}</tbody></table></div>`
      : '<div class="vacio">Sin visitas registradas.</div>'}
    <div class="modal-pie"><button class="btn" data-c>Cerrar</button></div>`, { ancho: true });
  $("[data-c]", m).onclick = cerrarModal;
});

// Aviso con el comentario interno (Entrada y Salida)
function htmlNotaVehiculo(n, editable) {
  return n ? `<div class="aviso-nota"><span class="an-ico">${icono("nota", 18)}</span><div class="an-cuerpo"><div class="an-tit">Comentario interno</div><div class="an-txt">${esc(n.nota)}</div></div>
    ${editable ? `<button type="button" class="btn mini" data-nota-edit>Editar</button>` : ""}</div>` : "";
}
