/* PROYECTO ALLAS · arranque.js: se carga el último. */
"use strict";

// Se arranca cuando ya están cargados todos los scripts, para que no falte ninguna pantalla
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar); else iniciar();
