/* PROYECTO ALLAS · Caja y turno */
"use strict";

// ================================================================ Caja y turno

// Cada cajero tiene su turno; un supervisor puede ver y cerrar los de los demás
function otrosTurnosHtml() {
  const otros = (S.estado.turnos_abiertos || []).filter((x) => x.usuario_id !== S.usuario.id);
  if (!otros.length) return "";
  const sup = permitido("turnos_ajenos");
  return `<div class="panel" style="margin-top:16px;max-width:760px"><h3>Otros turnos abiertos</h3>
    <table class="tabla" style="margin-top:8px"><tbody>${otros.map((x) => `<tr><td><b>Turno ${x.id}</b></td><td>${esc(x.usuario_nombre)}</td>
      <td class="suave">desde ${fechaHora(x.apertura)}</td><td class="der">${sup ? `<button class="btn" data-ver-turno="${x.id}">Ver o cerrar turno</button>` : ""}</td></tr>`).join("")}</tbody></table>
    ${sup ? "" : '<p class="suave" style="margin:8px 0 0">Cada cajero cierra su turno (o un supervisor).</p>'}</div>`;
}

function montarOtrosTurnos(v) {
  $$("[data-ver-turno]", v).forEach((b) => (b.onclick = () => { S.turnoAjeno = Number(b.dataset.verTurno); vistaCaja(v); }));
  montarFichaje(v);
}

// ---- Control de turnos del personal por QR (rehecho en 4.53). El lector del equipo «escribe» el código (FICHA + 12 dígitos) donde esté el cursor
const esFichaje = (t) => /FICHA\d{12}/i.test((t || "").replace(/[^A-Za-z0-9]/g, ""));

// Registra la lectura y avisa con el nombre y la hora; devuelve la respuesta (o null si falla o se cancela).
// Si es una salida y la confirmación está activada, antes enseña el resumen de la jornada y del turno.
async function fichajeLeido(texto) {
  try {
    const pre = await api("POST", "/api/fichar/previa", { codigo: texto });
    if (pre.confirmar && !(await confirmarSalidaFichaje(pre))) { toast("Salida no registrada", ""); return null; }
    const r = await api("POST", "/api/fichar", { codigo: texto });
    const dur = r.minutos != null ? ` (${duracionFich(r.minutos)})` : "";
    toast(r.repetido ? `${r.usuario}: ya fichado hace un momento` : `${r.accion === "entrada" ? "Entrada" : "Salida"} de ${r.usuario} a las ${r.hora}${dur}`,
      r.repetido ? "" : "ok");
    return r;
  } catch (e) { toast(e.message, "err"); return null; }
}

const duracionFich = (min) => `${Math.floor(min / 60)} h ${String(min % 60).padStart(2, "0")} min`;

function confirmarSalidaFichaje(pre) {
  return new Promise((ok) => {
    const hm = (iso) => new Date(iso).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
    const t = pre.turno;
    const m = modal(`<h2>Fichar salida de ${esc(pre.usuario)}</h2>
      <dl class="datos-ticket"><dt>Entrada</dt><dd>${hm(pre.desde)}</dd><dt>Trabajado</dt><dd><b>${duracionFich(pre.minutos)}</b></dd></dl>
      ${t ? `<h3 style="margin:14px 0 6px">Resumen del turno de caja ${t.id}</h3>
        <div class="rejilla r4" style="margin:0 0 8px">
          <div class="panel kpi"><div class="t">Entradas</div><div class="v num">${t.entradas}</div></div>
          <div class="panel kpi"><div class="t">Cobros</div><div class="v num">${t.cobros}</div></div>
          <div class="panel kpi"><div class="t">Efectivo</div><div class="v num">${eur(t.efectivo_cent)}</div></div>
          <div class="panel kpi"><div class="t">Tarjeta</div><div class="v num">${eur(t.tarjeta_cent)}</div></div></div>
        <p class="ayuda" style="margin:0">${t.auto_cierre ? "El turno de caja sigue abierto: al cerrarlo se volverá a fichar la salida solo si no la ha fichado ya." : "El turno de caja sigue abierto; la salida del trabajo es independiente del cierre de caja."}</p>`
        : '<p class="suave" style="margin:12px 0 0">No tiene ningún turno de caja abierto.</p>'}
      <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Confirmar salida</button></div>`);
    $("[data-c]", m).onclick = () => { cerrarModal(); ok(false); };
    $("[data-ok]", m).onclick = () => { cerrarModal(); ok(true); };
    $("[data-ok]", m).focus();
  });
}

// Panel «Jornada y turno»: la jornada del personal (fichaje) junto al turno de caja
function avisoFichajeTurno(r) {
  if (r && r.fichaje) toast(`Jornada iniciada a las ${r.fichaje.hora} (entrada fichada con el turno)`, "ok");
}

const montarFichaje = accion(async (v) => {
  const p = await api("GET", "/api/fichaje/panel").catch(() => null);
  if (!p || !p.activo) return;
  const hm = (iso) => new Date(iso).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
  const yo = p.yo || {};
  let estado;
  if (yo.dentro && yo.turno_id) estado = ["ok", `Jornada iniciada a las ${hm(yo.desde)} · Turno de caja ${yo.turno_id} abierto`];
  else if (yo.turno_id) estado = ["aviso", p.modo === "no" ? "Tiene el turno de caja abierto pero no ha fichado su entrada. Pase su QR por el lector." : "Turno abierto sin jornada: pase su QR por el lector."];
  else if (yo.dentro) estado = ["ok", `Jornada iniciada a las ${hm(yo.desde)} · aún sin turno de caja`];
  else estado = ["", "Sin jornada iniciada ni turno de caja."];
  const modoTxt = { no: "El fichaje es independiente del turno de caja.", abrir: "Al abrir el turno de caja se ficha su entrada automáticamente.",
    ambos: "Al abrir el turno se ficha su entrada y al cerrarlo, su salida (automático)." }[p.modo] || "";
  const html = `<div class="panel" id="c-fichaje" style="margin-top:16px;max-width:760px"><h3>Jornada y turno</h3>
    <div class="fj-estado ${estado[0]}">${esc(estado[1])}</div>
    <form class="escaner" id="f-fichaje" autocomplete="off" style="margin-top:10px">
      <input class="ent mono" id="fi-cod" placeholder="Pase su QR de fichaje por el lector" aria-label="Código de fichaje">
      <button class="btn">Fichar</button></form>
    <p class="ayuda" style="margin:6px 0 0">${esc(modoTxt)} También funciona con el lector desde cualquier pantalla.</p>
    <div class="fila" style="gap:8px;flex-wrap:wrap;margin:12px 0 4px"><span class="suave">Dentro ahora:</span>
      ${p.dentro.length ? p.dentro.map((x) => `<span class="etiqueta e-dentro">${esc(x.nombre)} · desde ${hm(x.entrada)}${x.turno_id ? ` · turno ${x.turno_id}` : ""}</span>`).join("") : '<span class="suave">nadie</span>'}</div>
    ${p.recientes.length ? `<table class="tabla" style="margin-top:8px"><tbody>${p.recientes.slice(0, 6).map((x) => `<tr><td><b>${esc(x.nombre)}</b></td>
      <td>${x.accion === "entrada" ? "Entrada" : "Salida"}</td><td class="num">${hm(x.hora)}</td></tr>`).join("")}</tbody></table>` : ""}</div>`;
  const viejo = $("#c-fichaje", v); if (viejo) viejo.remove();
  v.insertAdjacentHTML("beforeend", html);
  $("#f-fichaje", v).onsubmit = accion(async (e) => {
    e.preventDefault();
    const t = $("#fi-cod", v).value.trim(); $("#fi-cod", v).value = "";
    if (!t) return;
    await fichajeLeido(t);
    montarFichaje(v);
  });
  if (!estado[0] || estado[0] === "aviso") { const c = $("#fi-cod", v); if (c && !document.activeElement.matches?.("input,textarea,select")) c.focus({ preventScroll: true }); }
});

async function vistaCaja(v) {
  await refrescarEstado();
  let t = S.estado.turno;
  if (S.turnoAjeno) {
    try {
      const x = await api("GET", `/api/turnos/${S.turnoAjeno}`);
      if (x.estado === "abierto") t = x; else S.turnoAjeno = null;
    } catch (_) { S.turnoAjeno = null; }
  }
  if (!t) {
    const aq = S.estado.arqueo || { denominaciones: DENOM, fondo_predefinido: {}, fondo_predefinido_cent: 0 };
    const conDesglose = aq.desglose_apertura;
    v.innerHTML = `<div class="cab"><h2>Abrir turno de caja</h2></div>
    <form class="panel" id="f-abrir" style="max-width:${conDesglose ? 760 : 520}px">
      <p class="suave" style="margin-top:0">Cuente el efectivo con el que empieza (fondo de cambio) e indíquelo${conDesglose ? " por billetes y monedas" : ""}.</p>
      ${conDesglose ? `${gridDenominaciones(aq.denominaciones, aq.fondo_predefinido)}
        <div class="cambio" style="margin-top:12px"><span>Fondo inicial</span><span class="v num" id="ab-total">${eur(aq.fondo_predefinido_cent)}</span></div>`
      : `<label class="campo">Fondo inicial (€)<input class="ent grande num" name="fondo" inputmode="decimal" value="${aq.fondo_predefinido_cent ? aEurTxt(aq.fondo_predefinido_cent) : "100,00"}" autofocus></label>`}
      <label class="opcion-turno"><input type="checkbox" name="arqueo" ${S.estado.arqueo_defecto !== false ? "checked" : ""}>
        <span><b>Hacer arqueo de caja al cerrar</b><br><span class="suave">Al cerrar el turno se cuenta el efectivo y se comprueba si cuadra. Desactívelo si no quiere contar la caja en este turno.</span></span></label>
      <button class="btn prim xl bloque" style="margin-top:18px">Abrir turno</button></form>${otrosTurnosHtml()}`;
    montarOtrosTurnos(v);
    if (conDesglose) $$("[data-d]", v).forEach((i) => (i.oninput = () => ($("#ab-total").textContent = eur(leerDenominaciones(v).total))));
    $("#f-abrir").onsubmit = accion(async (e) => {
      e.preventDefault();
      if (conDesglose) {
        const d = leerDenominaciones(v);
        avisoFichajeTurno(await api("POST", "/api/turno/abrir", { fondo_cent: d.total, fondo_desglose: d.desglose, arqueo: e.target.arqueo.checked }));
        toast("Turno abierto", "ok"); await refrescarEstado(); return ir("cobrar");
      }
      const f = aCent(new FormData(e.target).get("fondo"));
      if (Number.isNaN(f) || f === null) throw new Error("Fondo no válido");
      avisoFichajeTurno(await api("POST", "/api/turno/abrir", { fondo_cent: f, arqueo: e.target.arqueo.checked }));
      toast("Turno abierto", "ok");
      await refrescarEstado();
      ir("cobrar");
    });
    return;
  }
  const propio = t.usuario_id === S.usuario.id;
  const sup = permitido("turnos_ajenos");
  v.innerHTML = `<div class="cab"><div><h2>Turno ${t.id} · ${esc(t.usuario_nombre)}</h2>
      <span class="suave">Abierto el ${fechaHora(t.apertura)}</span></div>
    <div class="fila">
      ${propio && permitido("movimientos_caja") ? `<button class="btn" id="b-ingreso">Ingreso</button><button class="btn" id="b-retirada">Retirada</button>` : ""}
      ${permitido("abrir_cajon") ? '<button class="btn" id="b-cajon">Abrir cajón</button>' : ""}
      ${propio || sup ? `<button class="btn prim" id="b-cerrar">Cerrar turno y arqueo</button>` : ""}
    </div></div>
    ${!propio ? `<div class="aviso fila" style="justify-content:space-between">Este turno es de ${esc(t.usuario_nombre)}. ${sup ? "Como supervisor puede cerrarlo." : "Pida que lo cierre o avise a un supervisor."}
      <button class="btn" id="b-mi-caja">Volver a mi caja</button></div>` : ""}
    <div class="rejilla r4" style="margin:16px 0">
      <div class="panel kpi"><div class="t">Entradas</div><div class="v num">${t.num_entradas}</div></div>
      <div class="panel kpi"><div class="t">Cobros</div><div class="v num">${t.num_cobros}</div>
        ${t.num_devoluciones ? `<div class="suave" style="font-size:.85rem;margin-top:4px">${t.num_devoluciones} devolución(es) · −${eur(t.devuelto_cent)}</div>` : ""}</div>
      <div class="panel kpi"><div class="t">Efectivo cobrado</div><div class="v num">${eur(t.cobrado_efectivo_cent)}</div></div>
      <div class="panel kpi"><div class="t">Tarjeta</div><div class="v num">${eur(t.cobrado_tarjeta_cent)}</div>
        ${t.cobrado_transferencia_cent ? `<div class="suave" style="font-size:.85rem;margin-top:4px">Transferencias ${eur(t.cobrado_transferencia_cent)}</div>` : ""}</div>
    </div>
    <div class="panel"><h3>Movimientos de caja</h3><div id="c-movs" style="margin-top:10px"></div>
      <p class="suave" style="margin-bottom:0">${t.arqueo === 0 ? "Turno <b>sin arqueo</b>: al cerrar no se contará el efectivo." : "El efectivo esperado no se muestra hasta el cierre (arqueo ciego)."}</p></div>`;
  if ($("#b-ingreso")) $("#b-ingreso").onclick = () => modalMovimiento("ingreso");
  if ($("#b-retirada")) $("#b-retirada").onclick = () => modalMovimiento("retirada");
  if ($("#b-cajon")) $("#b-cajon").onclick = () => {
    const c = modal(`<h2>Abrir cajón sin venta</h2><p class="suave">Quedará registrado con su nombre y hora.</p>
      <label class="campo">Motivo<input class="ent" id="cj-m" autofocus placeholder="Cambio de moneda, revisión…"></label>
      <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Abrir cajón</button></div>`);
    $("[data-c]", c).onclick = cerrarModal;
    $("[data-ok]", c).onclick = accion(async () => {
      const m = $("#cj-m").value.trim(); if (!m) throw new Error("Indique un motivo");
      notarImpresion(await api("POST", "/api/caja/abrir", { motivo: m })); cerrarModal(); toast("Cajón abierto", "ok"); vistaCaja(v);
    });
  };
  S.cierreTurnoId = propio ? null : t.id;
  if ($("#b-cerrar")) $("#b-cerrar").onclick = () => (t.arqueo === 0 ? cierreSinArqueo(v) : modalCierre(v));
  if ($("#b-mi-caja")) $("#b-mi-caja").onclick = () => { S.turnoAjeno = null; vistaCaja(v); };
  if (propio) { v.insertAdjacentHTML("beforeend", otrosTurnosHtml()); montarOtrosTurnos(v); }
  if (sup) {
    const det = await api("GET", `/api/turnos/${t.id}`);
    pintarMovs(det.movimientos);
  } else {
    $("#c-movs").innerHTML = `<p class="suave">Fondo inicial: ${eur(t.fondo_inicial_cent)} · Ingresos: ${eur(t.ingresos_cent)} · Retiradas: ${eur(t.retiradas_cent)}</p>`;
  }
}

function pintarMovs(movs) {
  $("#c-movs").innerHTML = movs.length ? `<table class="tabla"><thead><tr><th>Hora</th><th>Tipo</th><th>Empleado</th><th>Motivo</th><th class="der">Importe</th></tr></thead>
    <tbody>${movs.map((m) => `<tr><td>${hora(m.fecha)}</td><td>${esc(m.tipo.replace("_", " "))}</td><td>${esc(m.usuario_nombre)}</td>
    <td>${esc(m.motivo || "")}</td><td class="der num">${m.importe_cent ? eur(m.importe_cent) : ""}</td></tr>`).join("")}</tbody></table>`
    : `<div class="vacio">Sin movimientos.</div>`;
}

function modalMovimiento(tipo) {
  const c = modal(`<h2>${tipo === "retirada" ? "Retirada de efectivo" : "Ingreso de efectivo"}</h2>
    <p class="suave">${tipo === "retirada" ? "Saca dinero del cajón (p. ej. llevar al banco o a caja fuerte)." : "Mete dinero en el cajón (p. ej. más cambio)."} Se imprime un justificante para firmar.</p>
    <label class="campo">Importe (€)<input class="ent grande num" id="mv-i" inputmode="decimal" autofocus></label>
    <label class="campo" style="margin-top:12px">Motivo<input class="ent" id="mv-m"></label>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Registrar</button></div>`);
  $("[data-c]", c).onclick = cerrarModal;
  $("[data-ok]", c).onclick = accion(async () => {
    const i = aCent($("#mv-i").value);
    if (!i || Number.isNaN(i)) throw new Error("Importe no válido");
    notarImpresion(await api("POST", "/api/caja/movimiento", { tipo, importe_cent: i, motivo: $("#mv-m").value }));
    cerrarModal(); toast("Movimiento registrado", "ok"); vistaCaja($("#vista"));
  });
}

// ============================================================= Cierre y arqueo

const DENOM = [50000, 20000, 10000, 5000, 2000, 1000, 500, 200, 100, 50, 20, 10, 5, 2, 1];

// Rejilla de billetes y monedas (las elegidas en Ajustes) con cantidades iniciales opcionales
const nombreDen = (d) => (d >= 100 ? d / 100 + " €" : d + " ct");

function gridDenominaciones(dens, valores = {}) {
  const fila = (lista, titulo) => lista.length ? `<div class="arqueo-grupo"><div class="suave" style="font-size:.85rem;margin-bottom:6px">${titulo}</div><div class="arqueo">${lista.map((d) => `<label><span>${nombreDen(d)}</span>
      <input class="ent num" type="number" min="0" step="1" data-d="${d}" placeholder="0" value="${valores[String(d)] || ""}"></label>`).join("")}</div></div>` : "";
  return fila(dens.filter((d) => d >= 500), "Billetes") + fila(dens.filter((d) => d < 500), "Monedas");
}

function leerDenominaciones(el) {
  const desglose = {};
  let total = 0;
  $$("[data-d]", el).forEach((i) => {
    const n = parseInt(i.value, 10) || 0;
    if (n > 0) { desglose[i.dataset.d] = n; total += n * Number(i.dataset.d); }
  });
  return { desglose, total };
}

function modalCierre(v) {
  const aq = S.estado.arqueo || { desglose_cierre: true, denominaciones: DENOM };
  const conDesglose = aq.desglose_cierre !== false;
  const c = modal(`<h2>Cierre de turno · arqueo</h2>
    <p class="suave">${conDesglose ? "Cuente el efectivo del cajón por billetes y monedas." : "Cuente el efectivo del cajón e indique el total."} El sistema comparará con lo esperado al confirmar.</p>
    ${conDesglose ? gridDenominaciones(aq.denominaciones) : `<label class="campo">Efectivo contado (€)<input class="ent grande num" id="ar-unico" inputmode="decimal" autofocus></label>`}
    <div class="cambio" style="margin-top:16px"><span>Total contado</span><span class="v num" id="ar-total">0,00 €</span></div>
    <label class="campo" style="margin-top:12px">Observaciones<textarea class="ent" id="ar-obs" rows="2"></textarea></label>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Cerrar turno</button></div>`, { ancho: true });
  const total = () => (conDesglose ? leerDenominaciones(c).total : (aCent($("#ar-unico").value) || 0));
  $$("[data-d]", c).forEach((i) => (i.oninput = () => ($("#ar-total").textContent = eur(total()))));
  if ($("#ar-unico")) $("#ar-unico").oninput = () => ($("#ar-total").textContent = eur(total()));
  $("[data-c]", c).onclick = cerrarModal;
  $("[data-ok]", c).onclick = accion(async () => {
    const t = total();
    if (!(await confirmar("¿Cerrar el turno?", `Efectivo contado: <b>${eur(t)}</b>. Después no podrá cobrar hasta abrir un turno nuevo.`, { boton: "Cerrar turno" }))) return;
    const r = await api("POST", "/api/turno/cerrar", { contado_cent: t, observaciones: $("#ar-obs") ? $("#ar-obs").value : "",
      contado_desglose: conDesglose ? leerDenominaciones(c).desglose : null, turno_id: S.cierreTurnoId || undefined });
    S.turnoAjeno = null;
    if (r.fichaje) toast(`Salida fichada a las ${r.fichaje.hora} con el cierre del turno`, "ok");
    notarImpresion(r.impresion);
    await refrescarEstado();
    vistaCaja(v);
    const dif = r.diferencia_cent;
    const cc = modal(`<h2>Turno ${r.id} cerrado</h2>
      <div class="rejilla r3" style="margin:14px 0">
        <div class="panel kpi"><div class="t">Esperado</div><div class="v num">${eur(r.efectivo_esperado_cent)}</div></div>
        <div class="panel kpi"><div class="t">Contado</div><div class="v num">${eur(r.efectivo_contado_cent)}</div></div>
        <div class="panel kpi"><div class="t">Diferencia</div><div class="v num ${dif === 0 ? "verde" : "rojo"}">${eur(dif)}</div></div></div>
      ${dif !== 0 ? `<div class="aviso ${dif < 0 ? "rojo" : ""}">${dif < 0 ? "Falta" : "Sobra"} dinero en caja. Queda registrado en el cierre.</div>` : '<div class="aviso verde">La caja cuadra.</div>'}
      ${r.aviso_backup ? `<div class="aviso rojo">Copia de seguridad fallida: ${esc(r.aviso_backup)}</div>` : ""}
      <div style="margin-top:14px">${renderTicket(r.impresion)}</div>
      <div class="modal-pie"><button class="btn prim" data-c>Aceptar</button></div>`, { ancho: true });
    $("[data-c]", cc).onclick = () => { cerrarModal(); vistaCaja(v); };
    refrescarEstado();
  });
}

// Cierre de un turno abierto sin arqueo: no se cuenta el efectivo
const cierreSinArqueo = accion(async (v) => {
  const c = modal(`<h2>Cerrar turno</h2>
    <p>Este turno se abrió <b>sin arqueo de caja</b>: no hay que contar el efectivo.</p>
    <label class="campo">Observaciones<textarea class="ent" id="sa-obs" rows="2"></textarea></label>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok autofocus>Cerrar turno</button></div>`);
  $("[data-c]", c).onclick = cerrarModal;
  $("[data-ok]", c).onclick = accion(async () => {
    const r = await api("POST", "/api/turno/cerrar", { contado_cent: 0, observaciones: $("#sa-obs").value, turno_id: S.cierreTurnoId || undefined });
    S.turnoAjeno = null;
    if (r.fichaje) toast(`Salida fichada a las ${r.fichaje.hora} con el cierre del turno`, "ok");
    notarImpresion(r.impresion);
    await refrescarEstado();
    vistaCaja(v);
    const cc = modal(`<h2>Turno ${r.id} cerrado</h2>
      <div class="rejilla r3" style="margin:14px 0">
        <div class="panel kpi"><div class="t">Cobrado efectivo</div><div class="v num">${eur(r.cobrado_efectivo_cent)}</div></div>
        <div class="panel kpi"><div class="t">Cobrado tarjeta</div><div class="v num">${eur(r.cobrado_tarjeta_cent)}</div>
          ${r.cobrado_transferencia_cent ? `<div class="suave" style="font-size:.85rem;margin-top:4px">Transferencias ${eur(r.cobrado_transferencia_cent)}</div>` : ""}</div>
        <div class="panel kpi"><div class="t">Efectivo en caja (calculado)</div><div class="v num">${eur(r.efectivo_esperado_cent)}</div></div></div>
      <div class="aviso">Turno sin arqueo: no se ha comprobado el efectivo.</div>
      ${r.aviso_backup ? `<div class="aviso rojo">Copia de seguridad fallida: ${esc(r.aviso_backup)}</div>` : ""}
      <div style="margin-top:14px">${renderTicket(r.impresion)}</div>
      <div class="modal-pie"><button class="btn prim" data-c>Aceptar</button></div>`, { ancho: true });
    $("[data-c]", cc).onclick = cerrarModal;
  });
});
