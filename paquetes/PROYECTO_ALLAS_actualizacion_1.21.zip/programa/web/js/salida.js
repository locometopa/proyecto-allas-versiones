/* PROYECTO ALLAS · Salida: búsqueda del ticket y cobro */
"use strict";

// ====================================================================== Salida

function vistaCobrar(v) {
  if (!exigirTurnoPropio(v)) return;
  const c = S.cobro;
  v.innerHTML = `
  <div class="cab"><h2>Salida · cobro</h2>
    <div class="fila"><button class="btn" id="b-facturas">Facturas…</button><button class="btn" id="b-manual">Ticket manual…</button><button class="btn" id="b-anular">Anular ticket…</button>
    <button class="btn" id="b-limpiar">Nuevo cobro <kbd>Esc</kbd></button></div></div>
  <div class="cobro">
    <div class="panel">
      <form class="escaner" id="f-escaner" autocomplete="off">
        <input class="ent grande mono" id="escaner" placeholder="Ticket o matrícula…" aria-label="Ticket, tarjeta o matrícula" style="text-transform:uppercase">
        <button class="btn prim">Buscar</button>
      </form>
      <div class="pista"><span class="led"></span>Un solo campo: escanee el ticket o la tarjeta, o escriba la matrícula y pulse Intro. Se detecta solo lo que es.</div>
      <div id="lpr-salida"></div>
      <div id="c-detalle"></div>
    </div>
    <div id="c-pago"></div>
  </div>`;
  $("#f-escaner").onsubmit = (e) => { e.preventDefault(); buscarAuto($("#escaner").value); };
  montarListaSalida();   // lista desplegable de vehículos dentro
  $("#b-facturas").onclick = modalBuscarFactura;
  $("#b-manual").onclick = () => modalTicketManual("salida");
  $("#b-limpiar").onclick = limpiarCobro;
  if ($("#b-anular")) $("#b-anular").onclick = modalAnularSalida;
  pintarCobro();
  enfocarEscaner();
}

const buscarTicket = accion(async (codigo, { id, perdido } = {}) => {
  codigo = (codigo || "").trim();
  if (!codigo && !id) return;
  if (esFichaje(codigo)) {   // QR personal de fichaje leído con el lector de tickets
    const e = $("#escaner"); if (e) e.value = "";
    return fichajeLeido(codigo);
  }
  // Un vale escaneado mientras se cobra un ticket se aplica a ese ticket
  if (!id && /^V[A-Z0-9]{8}$/i.test(codigo.replace(/[^A-Za-z0-9]/g, "")) && S.cobro.ticket && !S.cobro.resultado && S.estado.descuentos) {
    const e = $("#escaner"); if (e) e.value = "";
    return aplicarCodigoDescuento(codigo);
  }
  if (S.vista !== "cobrar") ir("cobrar");
  const q = id ? `id=${id}` : `codigo=${encodeURIComponent(codigo)}`;
  try {
    const t = await api("GET", `/api/tickets/consultar?${q}${perdido ? "&perdido=1" : ""}`);
    const metodo = S.cobro.metodo || "efectivo";
    if (t.tipo === "abonado") {
      S.cobro = { ticket: t.dentro || null, metodo, entregado: "", resultado: null, perdido: false, abonado: t };
    } else {
      S.cobro = { ticket: t, metodo, entregado: "", resultado: null, perdido: !!perdido, abonado: null };
    }
  } finally {
    const e = $("#escaner"); if (e) e.value = "";
  }
  pintarCobro();
  const foco = $("#entregado") || $("#b-accion");
  if (foco) foco.focus(); else enfocarEscaner();
});

// Un solo campo para todo: detecta si lo escrito o escaneado es un fichaje, un ticket/tarjeta (o vale) o una matrícula
const CODIGO_TICKET = /^[A-Z]{1,3}\d{7}[0-9A-F]{5}$/i;
function tipoLectura(texto) {
  const t = (texto || "").trim();
  if (esFichaje(t)) return "fichaje";
  if (esCodigoReserva(t)) return "reserva";
  const limpio = t.replace(/[^A-Za-z0-9]/g, "");
  if (CODIGO_TICKET.test(limpio)) return "ticket";
  if (/^V[A-Z0-9]{8}$/i.test(limpio) && S.cobro.ticket && !S.cobro.resultado && S.estado.descuentos) return "ticket";   // vale mientras se cobra
  return "matricula";
}

const buscarAuto = accion(async (texto) => {
  const t = (texto || "").trim();
  if (!t) return;
  const tipo = tipoLectura(t);
  if (tipo === "ticket") return buscarTicket(t);
  if (tipo === "fichaje") { const e = $("#escaner"); if (e) e.value = ""; return fichajeLeido(t); }
  if (tipo === "reserva") { const e = $("#escaner"); if (e) e.value = ""; return leerCodigoReserva(t); }   // 1.11: QR de la reserva
  return buscarPorMatricula(t);
});

const buscarPorMatricula = accion(async (texto) => {
  if (esFichaje(texto)) { const e = $("#escaner"); if (e) e.value = ""; return fichajeLeido(texto); }
  const mat = normMat(texto);
  if (mat.length < 2) throw new Error("Escriba la matrícula (al menos 2 caracteres)");
  const filas = await api("GET", "/api/dentro?buscar=" + encodeURIComponent(mat));
  const exacta = filas.filter((f) => normMat(f.matricula) === mat);
  const elegir = (f) => { const i = $("#escaner"); if (i) i.value = ""; buscarTicket("", { id: f.id }); };
  if (exacta.length === 1) return elegir(exacta[0]);
  const lista = exacta.length ? exacta : filas;
  if (lista.length === 1) return elegir(lista[0]);
  if (!lista.length) {
    if (!tieneModulo("gestion")) throw new Error(`No hay ningún vehículo dentro con la matrícula ${mat}`);   // Lite: sin ticket manual
    if (await confirmar("Matrícula no encontrada", `No hay ningún vehículo dentro con la matrícula <b>${esc(mat)}</b>.<br>¿Quiere hacer un ticket manual?`, { boton: "Ticket manual…" })) {
      modalTicketManual("salida");
      setTimeout(() => { const m = $("#mn-mat"); if (m) m.value = mat; }, 80);
    }
    return;
  }
  const c = modal(`<h2>Varios vehículos coinciden</h2>
    <table class="tabla" style="margin-top:10px"><tbody>${lista.slice(0, 20).map((f) => `<tr>
      <td><b class="mono">${esc(f.matricula || "—")}</b>${f.vehiculo ? ` <span class="suave">${esc(f.vehiculo)}</span>` : ""}${f.cliente_nombre ? ` <span class="etiqueta e-abonado">${esc(f.cliente_nombre)}</span>` : ""}</td>
      <td class="num">${fechaHora(f.entrada)}</td><td class="der"><button class="btn prim" data-id="${f.id}">Elegir</button></td></tr>`).join("")}</tbody></table>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button></div>`);
  $("[data-c]", c).onclick = cerrarModal;
  $$("[data-id]", c).forEach((b) => (b.onclick = () => { cerrarModal(); elegir(lista.find((f) => f.id === Number(b.dataset.id))); }));
});

// Al escribir la matrícula se despliega la lista de vehículos que están dentro y se elige uno.
const ListaSalida = { filas: null, cargado: 0, sel: -1, vista: [] };

async function cargarDentroSalida(forzar) {
  if (!forzar && ListaSalida.filas && Date.now() - ListaSalida.cargado < 15000) return ListaSalida.filas;
  ListaSalida.filas = await api("GET", "/api/dentro");
  ListaSalida.cargado = Date.now();
  return ListaSalida.filas;
}

function montarListaSalida() {
  const inp = $("#escaner");
  if (!inp || inp.dataset.lista) return;
  inp.dataset.lista = "1";
  inp.setAttribute("autocomplete", "off");
  const form = $("#f-escaner");
  form.style.position = "relative";
  const caja = document.createElement("div");
  caja.className = "lista-dentro oculto";
  caja.id = "sal-lista";
  form.appendChild(caja);
  const cerrar = () => { caja.classList.add("oculto"); ListaSalida.sel = -1; };
  const elegir = (f) => { cerrar(); inp.value = ""; buscarTicket("", { id: f.id }); };
  const pintar = async (forzar) => {
    let filas;
    try { filas = await cargarDentroSalida(forzar); } catch (e) { return; }
    if (document.activeElement !== inp) return;
    const q = normMat(inp.value);
    ListaSalida.vista = filas.filter((f) => !q || normMat(f.matricula).includes(q) || (f.cliente_nombre || "").toUpperCase().includes(inp.value.trim().toUpperCase()))
      .sort((a, b) => (normMat(a.matricula).startsWith(q) ? 0 : 1) - (normMat(b.matricula).startsWith(q) ? 0 : 1)).slice(0, 40);
    if (ListaSalida.sel >= ListaSalida.vista.length) ListaSalida.sel = ListaSalida.vista.length - 1;
    caja.innerHTML = `<div class="cab-lista"><span>${filas.length ? `${ListaSalida.vista.length} de ${filas.length} vehículo(s) dentro` : "No hay vehículos dentro"}</span><span class="suave">↑ ↓ e Intro para elegir</span></div>`
      + (ListaSalida.vista.length ? ListaSalida.vista.map((f, i) => `<button type="button" class="item ${i === ListaSalida.sel ? "sel" : ""}" data-i="${i}">
          <b class="mono">${esc(f.matricula || "Sin matrícula")}</b>
          <span class="suave">${f.vehiculo ? esc(f.vehiculo) + " · " : ""}${f.cliente_nombre ? `<span class="etiqueta e-abonado">Abonado</span> ${esc(f.cliente_nombre)} · ` : ""}${esc(f.tarifa_nombre || "")}</span>
          <span class="num der">${hora(f.entrada)} · ${duracion(f.minutos)}</span></button>`).join("")
        : (filas.length ? `<div class="vacio" style="padding:12px">Ningún vehículo dentro coincide con «${esc(inp.value)}».</div>` : ""));
    caja.classList.remove("oculto");
    $$("[data-i]", caja).forEach((b) => (b.onmousedown = (e) => { e.preventDefault(); elegir(ListaSalida.vista[Number(b.dataset.i)]); }));
  };
  // La lista se abre al pulsar el campo o al escribir una matrícula (no al enfocarlo solo, ni con un código escaneado)
  inp.addEventListener("click", () => pintar(true));
  inp.addEventListener("input", () => {
    if (tipoLectura(inp.value) !== "matricula") { cerrar(); return; }
    ListaSalida.sel = normMat(inp.value) ? 0 : -1; pintar(false);
  });
  inp.addEventListener("blur", () => setTimeout(cerrar, 120));
  inp.addEventListener("keydown", (e) => {
    if (caja.classList.contains("oculto") || tipoLectura(inp.value) !== "matricula") return;
    const n = ListaSalida.vista.length;
    if (e.key === "ArrowDown" && n) { e.preventDefault(); ListaSalida.sel = (ListaSalida.sel + 1) % n; pintar(false); }
    else if (e.key === "ArrowUp" && n) { e.preventDefault(); ListaSalida.sel = (ListaSalida.sel - 1 + n) % n; pintar(false); }
    else if (e.key === "Enter" && ListaSalida.sel >= 0 && ListaSalida.vista[ListaSalida.sel]) { e.preventDefault(); e.stopPropagation(); elegir(ListaSalida.vista[ListaSalida.sel]); }
    else if (e.key === "Escape") { e.stopPropagation(); cerrar(); }
  });
}

// 4.38: la casilla «Imprimir ticket de salida» empieza desmarcada en cada cobro (salvo que Ajustes → Tickets la marque por defecto)
// y ya no se recuerda la última elección.
const imprimirSalida = () => (S.cobro.imprimir === undefined ? S.estado.imprimir_salida === true : !!S.cobro.imprimir);
async function guardarImprimirSalida() { /* sin preferencia que guardar */ }

function limpiarCobro() {
  S.cobro = { ticket: null, metodo: "efectivo", entregado: "", resultado: null, perdido: false, abonado: null };
  if (S.vista === "cobrar") { pintarCobro(); const e = $("#escaner"); if (e) e.value = ""; enfocarEscaner(); }
}

function enfocarEscaner() {
  if (!$("#modal").classList.contains("oculto")) return;
  const e = $("#escaner");
  if (e && S.vista === "cobrar" && !$("#b-accion") && !(S.cobro.ticket && S.cobro.metodo === "efectivo" && !S.cobro.resultado)) e.focus();
}

// ===================================================== Datos del ticket y pago

// Pantalla de cobro: datos del ticket (o del abonado) a la izquierda y el pago a la derecha.
// También informa a la pantalla del cliente de lo que se está cobrando.
function pintarCobro() {
  pintarPanelesCobro();
  informarCobroCliente();
  const e = $("#entregado");
  if (e) e.addEventListener("input", () => { S.cobro.entregado = e.value; informarCobroCliente(); });
}

function pintarPanelesCobro() {
  const det = $("#c-detalle"), pago = $("#c-pago");
  if (!det) return;
  const { ticket: t, resultado: r } = S.cobro;
  if (S.cobro.abonado && !t) return pintarAbonado(det, pago);
  if (!t) {
    det.innerHTML = `<div class="vacio">Sin ticket. El importe aparecerá aquí al escanear.</div>`;
    pago.innerHTML = `<div class="panel vacio">Esperando ticket…</div>`;
    return;
  }
  const l = t.liquidacion;
  det.innerHTML = `${t.lista_negra ? htmlListaNegra(t.lista_negra) : ""}${htmlNotaVehiculo(t.nota_vehiculo, true)}${htmlAvisoReservaTicket(t)}${htmlFotoSalida(t)}<dl class="datos-ticket">
      ${t.cliente_nombre ? `<dt>Abonado</dt><dd><b>${esc(t.cliente_nombre)}</b> <span class="etiqueta e-abonado">Abonado</span></dd>` : ""}
      <dt>Ticket</dt><dd class="mono">${esc(t.codigo)} ${etiquetaEstado(t.estado)}${t.perdido || S.cobro.perdido ? ' <span class="etiqueta e-aviso">Perdido</span>' : ""}</dd>
      <dt>Matrícula</dt><dd>${esc(t.matricula || "—")}${t.matricula ? ` <button class="btn mini" id="b-hist-veh" title="Visitas anteriores de este vehículo">Historial</button>` : ""}${!r && ["dentro", "pagado"].includes(t.estado) ? ` <button class="btn mini" id="b-mat" title="Corregir matrícula">✎ Cambiar</button>` : ""}</dd>
      <dt>Entrada</dt><dd>${fechaHora(t.entrada)}</dd>
      <dt>Estancia</dt><dd>${l ? duracion(l.minutos) : "—"}</dd>
      <dt>Tarifa</dt><dd>${esc(t.tarifa_nombre)}${!r && t.estado === "dentro" && !t.cliente_id && !t.pagos.length ? ` <button class="btn mini" id="b-tarifa" title="Cambiar la tarifa">✎ Cambiar</button>` : ""}</dd>
      ${t.pagos.length ? `<dt>Pagos previos</dt><dd>${t.pagos.map((p) => `${eur(p.importe_cent)} (${p.metodo}, ${hora(p.fecha)})`).join("<br>")}</dd>` : ""}
    </dl>${htmlVehiculoCobro(t)}
    ${t.mensaje ? `<div class="aviso ${l && l.pendiente_cent === 0 ? "verde" : ""}">${esc(t.mensaje)}</div>` : ""}
    <div id="c-extras"></div>
    <div class="fila" style="margin-top:16px">
      ${t.cliente_id ? `<button class="btn" id="b-ficha">Ficha del cliente</button>` : `<button class="btn" id="b-reimp">Reimprimir ticket</button>`}
    </div>${r ? "" : htmlReservaCobro(t)}`;
  if ($("#b-estado-sal", det)) $("#b-estado-sal", det).onclick = () => modalEstadoVehiculo(t);
  if ($("#b-zona-sal", det)) $("#b-zona-sal", det).onclick = () => modalCambiarZona(t, (zid) => { t.zona_id = zid; pintarCobro(); });
  if ($("#b-res-cambiar", det)) $("#b-res-cambiar", det).onclick = () => modalReservaTicket(t);
  if ($("#b-res-quitar", det)) $("#b-res-quitar", det).onclick = accion(async () => {
    await api("POST", `/api/tickets/${t.id}/reserva`, { quitar: true });
    toast("Reserva quitada", "ok"); buscarTicket("", { id: t.id });
  });
  if ($("#b-ficha")) $("#b-ficha").onclick = () => abrirFicha(t.cliente_id);
  if ($("#b-mat")) $("#b-mat").onclick = () => modalMatricula(t, recargarTicketCobro);
  if ($("#b-hist-veh")) $("#b-hist-veh").onclick = () => modalHistorialVehiculo(t.matricula);
  if ($("[data-nota-edit]", det)) $("[data-nota-edit]", det).onclick = () => modalNotaVehiculo(t.matricula, recargarTicketCobro);
  if ($("#b-tarifa")) $("#b-tarifa").onclick = () => modalCambiarTarifa(t, recargarTicketCobro);
  if (!r) pintarExtrasCobro(t);
  if ($("#b-reimp")) $("#b-reimp").onclick = accion(async () => { notarImpresion(await api("POST", `/api/tickets/${t.id}/reimprimir`)); toast("Ticket reimpreso", "ok"); });


  // --- resultado tras cobrar
  if (r) {
    const p = r.pago;
    pago.innerHTML = `<div class="panel exito">
      <div class="icono">✓</div>
      <h2>${p ? `Cobrado ${eur(p.importe_cent)}` : "Salida sin cargo"}</h2>
      ${p && p.metodo === "efectivo" ? `<p class="suave" style="margin:14px 0 2px">Cambio a devolver</p><div class="grande num">${eur(p.cambio_cent)}</div>` : ""}
      ${p ? `<p class="suave">Factura simplificada ${esc(p.serie)}-${String(p.numero).padStart(6, "0")} · ${esc(p.metodo)}</p>` : ""}
      ${r.impresion && r.impresion.omitida ? '<p class="suave" style="margin:8px 0 0">Ticket de salida sin imprimir (desactivado). Puede verlo en «Ver recibo».</p>' : ""}
      <div class="aviso verde">${r.salida ? `Salida registrada a las ${hora(r.salida)} · plaza libre` : `Puede salir hasta las ${hora(r.salida_limite)}`}</div>
      <div class="fila" style="justify-content:center;margin-top:18px">
        <button class="btn" id="b-ver-recibo">Ver recibo</button>
        ${p ? '<button class="btn" id="b-factura">Factura con datos / email</button>' : ""}
        <button class="btn prim xl" id="b-siguiente" autofocus>Siguiente <kbd>Intro</kbd></button></div></div>`;
    $("#b-ver-recibo").onclick = () => verImpresion(r.impresion, p ? { pagoId: p.id } : {});
    if ($("#b-factura")) $("#b-factura").onclick = () => modalFactura(p.id);
    $("#b-siguiente").onclick = accion(async () => { await guardarImprimirSalida(); limpiarCobro(); });
    $("#b-siguiente").focus();
    return;
  }

  if (!l) { pago.innerHTML = `<div class="panel vacio">${esc(t.mensaje || "")}</div>`; return; }
  // Descuentos de estancia (el servidor ya trae cuánto descuenta cada uno)
  const opsDto = l.descuentos || [];
  if (S.cobro.descuento == null && !S.cobro.dtoManual && opsDto.some((o) => o.cliente)) S.cobro.descuento = "cliente";   // descuento fijo del cliente: se aplica solo
  const dSel = opsDto.find((o) => o.id === S.cobro.descuento);
  if (!dSel) S.cobro.descuento = null;
  const dto = dSel ? dSel.descuento_cent : 0;
  const total = l.pendiente_cent - dto;
  pago.innerHTML = `<div class="panel">
    <div class="total ${total === 0 ? "cero" : ""}"><div class="t">${l.abonado && l.abonado.vigente ? "Abonado · bono vigente" : total === 0 ? "Nada que pagar" : "Total a cobrar"}</div>
      <div class="v num">${l.abonado && l.abonado.vigente ? "Sin cargo" : eur(total)}</div>
      <div class="desglose num">
        ${l.pendiente_estancia_cent || !l.extras_pendientes_cent ? `<div><span>Estancia (${duracion(l.minutos)}${l.minutos_incluidos ? ` − ${duracion(l.minutos_incluidos)} incluidos` : ""})</span><span>${eur(l.importe_estancia_cent)}</span></div>
        ${l.recargo_cent ? `<div><span>Recargo ticket perdido</span><span>${eur(l.recargo_cent)}</span></div>` : ""}
        ${l.pagado_cent ? `<div><span>Ya pagado</span><span>−${eur(l.pagado_cent)}</span></div>` : ""}` : ""}
        ${l.extras_pendientes_cent ? `<div><span>Servicios y productos</span><span>${eur(l.extras_pendientes_cent)}</span></div>` : ""}
        ${dto ? `<div><span>Descuento ${esc(dSel.nombre)}</span><span>−${eur(dto)}</span></div>` : ""}
      </div></div>
    ${(S.estado.descuentos || opsDto.length) && l.pendiente_estancia_cent > 0 && !(l.abonado && l.abonado.vigente) ? `<div class="descuento-cobro">
      <label class="campo">Descuento<select class="ent" id="c-dto"><option value="">Sin descuento</option>
        ${opsDto.map((o) => `<option value="${o.id}" ${o.id === S.cobro.descuento ? "selected" : ""}>${esc(o.nombre)} · ${esc(o.texto)} (−${eur(o.descuento_cent)})</option>`).join("")}</select></label>
      ${S.estado.descuentos ? `<label class="campo" style="max-width:190px;min-width:150px">Código o vale<input class="ent mono" id="c-dto-cod" placeholder="Escanear…" autocomplete="off" style="text-transform:uppercase"></label>` : ""}</div>` : ""}
    ${total > 0 ? `
    <div class="metodos">
      <button class="btn xl ${S.cobro.metodo === "efectivo" ? "sel" : ""}" data-m="efectivo">Efectivo</button>
      <button class="btn xl ${S.cobro.metodo === "tarjeta" ? "sel" : ""}" data-m="tarjeta">Tarjeta</button></div>
    <div id="c-efectivo"></div>
    <label class="fila" style="gap:8px;margin-top:12px;font-weight:600"><input type="checkbox" id="c-imprimir" ${imprimirSalida() ? "checked" : ""}> Imprimir ticket de salida</label>
    <button class="btn ok xl bloque" id="b-cobrar" style="margin-top:10px">${S.estado.salida_al_cobrar ? "Cobrar y dar salida" : "Cobrar"} ${eur(total)} <kbd>Intro</kbd></button>`
    : dto ? `<button class="btn ok xl bloque" id="b-cobrar" style="margin-top:14px">Aplicar descuento y dar salida <kbd>Intro</kbd></button>` : ""}
  </div>`;
  if ($("#c-imprimir")) $("#c-imprimir").onchange = (e) => { S.cobro.imprimir = e.target.checked; };
  if ($("#c-dto")) $("#c-dto").onchange = (e) => { S.cobro.dtoManual = true; S.cobro.descuento = idDescuento(e.target.value); S.cobro.entregado = ""; pintarCobro(); };
  if ($("#c-dto-cod")) $("#c-dto-cod").onkeydown = (e) => {
    if (e.key !== "Enter") return;
    e.preventDefault(); e.stopPropagation();
    aplicarCodigoDescuento(e.target.value);
  };
  if (total === 0 && dto) { $("#b-cobrar").onclick = cobrar; return; }
  if (total === 0) {
    if (t.estado !== "salido") {
      pago.querySelector(".panel").insertAdjacentHTML("beforeend",
        `<button class="btn ok xl bloque" id="b-accion" style="margin-top:14px">Registrar SALIDA <kbd>Intro</kbd></button>`);
      $("#b-accion").onclick = accion(async () => {
        await api("POST", `/api/tickets/${t.id}/salida`);
        toast((t.cliente_nombre ? t.cliente_nombre + ": " : "") + "salida registrada", "ok");
        refrescarEstado(); limpiarCobro();
      });
    }
    return;
  }
  $$("[data-m]").forEach((b) => (b.onclick = () => { S.cobro.metodo = b.dataset.m; pintarCobro(); const e = $("#entregado"); if (e) e.focus(); }));
  $("#b-cobrar").onclick = cobrar;
  if (S.cobro.metodo === "efectivo") pintarEfectivo(total);
  else $("#c-efectivo").innerHTML = `<p class="suave">Cobre en el datáfono y, cuando la operación sea aceptada, pulse Cobrar.</p>`;
}

// Foto del vehículo del abonado junto a los datos del ticket
function htmlFotoSalida(t) {
  if (!t.foto_vehiculo || !t.foto_cliente_id || !fotosVehiculoActivas()) return "";
  const url = urlFotoVehiculo(t.foto_cliente_id, t.matricula, t.foto_vehiculo);
  return `<div class="foto-salida"><img src="${url}" alt="Foto del vehículo" data-ver-foto="${url}" title="Ver en grande"><span class="suave">Foto del vehículo registrado</span></div>`;
}

// Tipo de vehículo, zona, estado al entrar y botones «Estado y fotos» / «Cambiar zona»
function htmlVehiculoCobro(t) {
  const zonas = S.estado.zonas || [];
  const zona = zonas.find((z) => z.id === t.zona_id);
  const chips = [t.tipo_vehiculo ? `<span class="etiqueta e-abonado">${esc(t.tipo_vehiculo)}</span>` : "",
    zona && zonas.length > 1 ? chipZona(zona.id) : ""].join(" ").trim();
  if (!chips && !t.estado_nota && !S.estado.estado_vehiculo && zonas.length < 2) return "";
  return `<div class="veh43">${chips ? `<div class="fila" style="gap:6px">${chips}</div>` : ""}
      ${t.estado_nota ? `<div class="nota-estado">${icono("nota")}<span><b>Al entrar:</b> ${esc(t.estado_nota)}</span></div>` : ""}
      <div class="fila" style="gap:6px">${S.estado.estado_vehiculo && t.estado !== "salido" ? `<button class="btn mini" id="b-estado-sal">${icono("camara", 16)} Estado y fotos</button>` : ""}
        ${zonas.length > 1 && t.estado !== "salido" && t.id ? '<button class="btn mini" id="b-zona-sal">Cambiar zona</button>' : ""}</div></div>`;
}

// Reserva (hotel, plataforma) del ticket y botón para aplicarla o quitarla
function htmlReservaCobro(t) {
  const l = t.liquidacion || {}, r = l.reserva;
  const puede = t.estado === "dentro" && !(t.pagos || []).length && !t.cliente_id;
  const hayReservas = (S.tarifas || []).some((x) => x.activa && x.modo === "reserva");
  if (!r && !(puede && hayReservas)) return "";
  return `<div class="reserva-caja">${r ? `🏨 <b>Reserva ${esc(r.tarifa_reserva)}</b>${r.ref ? ` · ${esc(r.ref)}` : ""}<br>
        Incluida hasta el <b>${fechaHora(r.hasta)}</b>${r.vigente ? ' <span class="etiqueta e-pagado">Dentro de la reserva</span>'
          : ` · después se cobra con <b>${esc(r.tarifa_despues)}</b>.<br>Tiempo fuera de la reserva: <b>${duracion(l.minutos_cobrables || 0)}</b> (de ${duracion(l.minutos || 0)} de estancia)`}
        ${puede ? '<div class="fila" style="margin-top:6px"><button class="btn mini" id="b-res-cambiar">Cambiar…</button><button class="btn mini" id="b-res-quitar">Quitar reserva</button></div>' : ""}`
      : `<div class="fila" style="justify-content:space-between"><span>¿Tiene reserva de hotel o parking pagada en otro sitio?</span><button class="btn mini" id="b-res-cambiar">🏨 Reserva…</button></div>`}</div>`;
}

function pintarAbonado(det, pago) {
  const a = S.cobro.abonado, c = a.cliente;
  det.innerHTML = `
    <div class="abonado-cab">
      <div class="avatar">${esc((c.nombre || "?").trim().charAt(0).toUpperCase())}</div>
      <div><div class="suave" style="font-size:.85rem">Tarjeta de abonado · <span class="mono">${esc(c.codigo)}</span></div>
        <h2 style="font-size:1.6rem">${esc(c.nombre)}</h2>
        <div style="margin-top:6px">${chipBono(a.bono)} ${a.bono.plan ? `<span class="suave">${esc(a.bono.plan)}</span>` : ""}</div></div>
    </div>
    <dl class="datos-ticket">
      <dt>Vehículos</dt><dd>${vehiculosConFoto(c, false)}</dd>
      ${c.telefono ? `<dt>Teléfono</dt><dd>${esc(c.telefono)}</dd>` : ""}
    </dl>
    <div class="fila" style="margin-top:16px"><button class="btn" id="b-ficha">Ficha del cliente</button></div>`;
  $("#b-ficha").onclick = () => abrirFicha(c.id);

  const pend = a.bono.pendiente;
  const bloquePend = pend ? `<div class="aviso rojo" style="margin-top:14px">Bono pendiente de pago: <b>${eur(pend.importe_cent)}</b>
      (${fechaCorta(pend.desde)} → ${fechaCorta(pend.hasta)}${pend.pagado_cent ? `; pagado ${eur(pend.pagado_cent)} de ${eur(pend.total_cent)}` : ""}). ${a.vigente ? `Puede entrar hasta el ${fechaCorta(pend.pagar_antes)}.` : "Plazo para pagar superado."}
      <button class="btn ok bloque" id="b-cobrar-renov" style="margin-top:8px">Cobrar renovación ${eur(pend.importe_cent)}</button></div>` : "";
  const montarPend = () => { if ($("#b-cobrar-renov")) $("#b-cobrar-renov").onclick = () => modalCobrarRenovacion(pend, c, () => buscarTicket(c.codigo)); };
  if (!a.vigente) {
    pago.innerHTML = `<div class="panel">${bloquePend}
      <div class="total" style="background:var(--rojo)"><div class="t">Acceso de abonado</div>
        <div class="v" style="font-size:2rem">${c.activo ? (a.bono.estado === "futuro" ? "Bono aún no empezado" : "Sin bono vigente") : "Cliente de baja"}</div></div>
      <p>Puede renovar el bono ahora, o emitir un ticket normal en <b>Entrada</b> (F2).</p>
      <button class="btn prim xl bloque" id="b-accion">Renovar bono <kbd>Intro</kbd></button></div>`;
    $("#b-accion").onclick = () => (pend ? modalCobrarRenovacion(pend, c, () => buscarTicket(c.codigo)) : modalVenderBono(c.id, () => buscarTicket(c.codigo)));
    if (pend) $("#b-accion").innerHTML = `Cobrar renovación ${eur(pend.importe_cent)} <kbd>Intro</kbd>`;
    montarPend();
    return;
  }
  pago.innerHTML = `<div class="panel">
    <div class="total cero"><div class="t">Abonado</div><div class="v" style="font-size:2.2rem">Acceso permitido</div>
      <div class="desglose"><div><span>Bono</span><span>${esc(a.bono.plan || "")}</span></div>
      <div><span>Válido hasta</span><span>${fechaCorta(a.bono.hasta)}</span></div></div></div>
    ${c.vehiculos.length > 1 ? `<label class="campo" style="margin-top:14px">Vehículo
      <select class="ent" id="ab-mat">${c.vehiculos.map((v) => `<option value="${esc(v.matricula)}">${esc(descVehiculo(v, false))}</option>`).join("")}</select></label>` : ""}
    <button class="btn ok xl bloque" id="b-accion" style="margin-top:14px">Registrar ENTRADA <kbd>Intro</kbd></button>${bloquePend}</div>`;
  montarPend();
  $("#b-accion").onclick = accion(async () => {
    const sel = $("#ab-mat");
    const tk = await api("POST", `/api/clientes/${c.id}/entrada`, { matricula: sel ? sel.value : null });
    toast(tk.mensaje, "ok");
    refrescarEstado();
    limpiarCobro();
  });
}

function pintarEfectivo(total) {
  const billetes = [500, 1000, 2000, 5000].filter((b) => b >= total).slice(0, 4);
  $("#c-efectivo").innerHTML = `
    <label class="campo">Entregado por el cliente
      <input class="ent grande num" id="entregado" inputmode="decimal" placeholder="Cantidad recibida…" autocomplete="off" value="${esc(S.cobro.entregado)}"></label>
    <div class="billetes"><button class="btn" data-b="${total}">Exacto</button>
      ${billetes.map((b) => `<button class="btn" data-b="${b}">${b / 100} €</button>`).join("")}</div>
    <div id="c-cambio"></div>`;
  const inp = $("#entregado");
  const actualizar = () => {
    S.cobro.entregado = inp.value;
    const cc = $("#c-cambio");
    if (inp.value.trim() === "") { cc.innerHTML = `<div class="cambio falta"><span>Escriba la cantidad recibida</span></div>`; return; }
    const ent = aCent(inp.value);
    if (Number.isNaN(ent)) { cc.innerHTML = `<div class="cambio falta"><span>Importe no válido</span></div>`; return; }
    const dif = ent - total;
    cc.innerHTML = dif >= 0 ? `<div class="cambio"><span>Cambio</span><span class="v num">${eur(dif)}</span></div>`
      : `<div class="cambio falta"><span>Faltan</span><span class="v num">${eur(-dif)}</span></div>`;
  };
  inp.oninput = actualizar;
  inp.onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); cobrar(); } };
  $$("[data-b]").forEach((b) => (b.onclick = () => { inp.value = aEurTxt(+b.dataset.b); actualizar(); inp.focus(); }));
  actualizar();
}

let cobrando = false;

const cobrar = accion(async () => {
  if (cobrando) return;
  const t = S.cobro.ticket;
  if (!t || !t.liquidacion || t.liquidacion.pendiente_cent <= 0) return;
  const dSel = (t.liquidacion.descuentos || []).find((o) => o.id === S.cobro.descuento);
  const neto = t.liquidacion.pendiente_cent - (dSel ? dSel.descuento_cent : 0);
  let entregado = null;
  if (S.cobro.metodo === "efectivo" && neto > 0) {
    entregado = entregadoEfectivo(S.cobro.entregado, neto, "#entregado");
  }
  cobrando = true;
  const b = $("#b-cobrar"); if (b) b.disabled = true;
  try {
    // Datáfono integrado (opcional): primero se cobra en el datáfono y, si se aprueba, se registra
    const dref = S.cobro.metodo === "tarjeta" ? await pasoDatafono(neto, t.codigo) : null;
    const r = await api("POST", `/api/tickets/${t.id}/cobrar`, {
      metodo: S.cobro.metodo, entregado_cent: entregado, perdido: S.cobro.perdido, calculo_en: t.calculo_en,
      descuento_id: dSel ? dSel.id : null, datafono_ref: dref, imprimir: imprimirSalida() });
    notarImpresion(r.impresion);
    S.cobro.resultado = r;
    S.cobro.ticket = { ...t, estado: "pagado", mensaje: null };
    pintarCobro();
    refrescarEstado();
  } finally {
    cobrando = false;
    const b2 = $("#b-cobrar"); if (b2) b2.disabled = false;
  }
});

// Devuelve el nº de autorización (o null si se cobra sin datáfono); lanza un error si se cancela.
function pasoDatafono(importe, referencia) {
  if (!S.estado || !S.estado.datafono || !(importe > 0)) return Promise.resolve(null);
  return new Promise((ok, mal) => {
    const intentar = async () => {
      const m = modal(`<div class="exito"><div class="icono">💳</div><h2>Pase la tarjeta por el datáfono</h2>
        <p style="font-size:2rem;font-weight:800;margin:6px 0" class="num">${eur(importe)}</p>
        <p class="suave">Esperando la respuesta del datáfono…</p></div>`);
      m.dataset.esperando = "1";
      let r;
      try { r = await api("POST", "/api/datafono/cobrar", { importe_cent: importe, referencia }); }
      catch (e) { r = { ok: false, mensaje: e.message }; }
      if (r.ok) {
        cerrarModal();
        toast(`Tarjeta aprobada${r.autorizacion ? " · aut. " + r.autorizacion : ""}`, "ok");
        return ok(r.autorizacion || "OK");
      }
      const c = modal(`<h2>El datáfono no ha aprobado el cobro</h2>
        <div class="aviso rojo" style="margin-top:10px">${esc(r.mensaje || "Operación no aprobada")}</div>
        <p class="suave">Puede reintentarlo, cobrar con el datáfono por separado (sin conexión) o cancelar.</p>
        <div class="modal-pie"><button class="btn" data-x>Cancelar cobro</button>
          <button class="btn" data-manual>Ya cobrado aparte</button><button class="btn prim" data-r autofocus>Reintentar</button></div>`);
      $("[data-x]", c).onclick = () => { cerrarModal(); mal(new Error("Cobro con tarjeta cancelado")); };
      $("[data-manual]", c).onclick = () => { cerrarModal(); ok(null); };
      $("[data-r]", c).onclick = () => intentar();
    };
    intentar();
  });
}

// ========================================================== Descuentos y vales

// Id de un descuento elegido en un desplegable (número) o código de vale (texto)
const idDescuento = (v) => (v === "" || v == null ? null : /^\d+$/.test(String(v)) ? Number(v) : String(v));

// Código tecleado o escaneado en Salida: un descuento con código o un vale
const aplicarCodigoDescuento = accion(async (codigo) => {
  const t = S.cobro.ticket, l = t && t.liquidacion;
  const cod = (codigo || "").trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
  if (!l || !cod) return;
  l.descuentos = l.descuentos || [];
  let o = l.descuentos.find((x) => (x.codigo || "").toUpperCase().replace(/[^A-Z0-9]/g, "") === cod);
  if (!o) {
    o = await api("POST", `/api/tickets/${t.id}/descuento`, { codigo: cod, calculo_en: t.calculo_en, perdido: S.cobro.perdido });
    l.descuentos.push(o);
  }
  S.cobro.descuento = o.id; S.cobro.entregado = "";
  toast(`Descuento aplicado: ${o.nombre} (−${eur(o.descuento_cent)})`, "ok");
  pintarCobro();
});

// ======================================== Servicios y productos de la estancia

// Se añaden a la estancia y se cobran junto con ella (igual que el recargo por ticket perdido).
const TIPO_PROD = { servicio: "Servicio", producto: "Producto" };

function pintarExtrasCobro(t) {
  const cont = $("#c-extras");
  if (!cont || !t || !["dentro", "pagado"].includes(t.estado)) { if (cont) cont.innerHTML = ""; return; }
  const lineas = t.extras || [];
  cont.innerHTML = `<div class="extras-caja">
    <div class="fila" style="justify-content:space-between"><b>Servicios y productos</b>
      <button class="btn" id="b-extra">+ Añadir servicio o producto</button></div>
    ${lineas.length ? `<table class="tabla extras-tabla"><tbody>${lineas.map((e) => `<tr class="${e.pago_id ? "cobrada" : ""}">
      <td>${esc(e.nombre)}${e.pago_id ? ' <span class="etiqueta e-salido">cobrado</span>' : ""}${e.minutos_incluidos ? `<div class="suave" style="font-size:.8rem">incluye ${duracion(e.minutos_incluidos * e.cantidad)} de parking</div>` : ""}</td>
      <td class="der num" style="white-space:nowrap">${e.pago_id ? `${e.cantidad} ×` : `
        <button class="btn mini" data-menos="${e.id}" data-c="${e.cantidad}" aria-label="Uno menos">−</button>
        <b style="display:inline-block;min-width:1.6em;text-align:center">${e.cantidad}</b>
        <button class="btn mini" data-mas="${e.id}" data-c="${e.cantidad}" aria-label="Uno más">+</button>`}</td>
      <td class="der num">${eur(e.precio_cent * e.cantidad)}</td>
      <td class="der">${e.pago_id ? "" : `<button class="btn mini peligro" data-quitar="${e.id}" title="Quitar" aria-label="Quitar ${esc(e.nombre)}"><span aria-hidden="true">✕</span></button>`}</td></tr>`).join("")}
      </tbody></table>` : `<div class="suave" style="font-size:.9rem;margin-top:6px">Lavado, agua, recarga… se cobran junto con la estancia.</div>`}</div>`;
  $("#b-extra").onclick = () => modalServicios(t.id, recargarTicketCobro);
  const cambiar = (id, cant) => accion(async () => { await api("POST", `/api/extras/${id}/cantidad`, { cantidad: cant }); await recargarTicketCobro(); })();
  $$("[data-mas]", cont).forEach((b) => (b.onclick = () => cambiar(b.dataset.mas, Number(b.dataset.c) + 1)));
  $$("[data-menos]", cont).forEach((b) => (b.onclick = () => cambiar(b.dataset.menos, Number(b.dataset.c) - 1)));
  // 4.37: quitar un servicio ya no es definitivo: «Deshacer» lo vuelve a añadir
  $$("[data-quitar]", cont).forEach((b) => (b.onclick = () => {
    const e = lineas.find((x) => String(x.id) === b.dataset.quitar);
    cambiar(b.dataset.quitar, 0);
    if (!e) return;
    toast(`Quitado: ${e.nombre}`, "", { accion: { texto: "Deshacer", fn: () => accion(async () => {
      const cuerpo = e.producto_id ? { producto_id: e.producto_id, cantidad: e.cantidad, precio_cent: e.precio_cent }
        : { personalizado: { nombre: e.nombre, precio_cent: e.precio_cent, iva_pct: e.iva_pct == null ? null : Number(e.iva_pct) }, cantidad: e.cantidad };
      await api("POST", `/api/tickets/${t.id}/extras`, cuerpo);
      await recargarTicketCobro();
    })() } });
  }));
}

// Vuelve a consultar el ticket en pantalla de cobro conservando «perdido», método y abonado.
async function recargarTicketCobro() {
  const t = S.cobro.ticket;
  if (!t) return;
  const nuevo = await api("GET", `/api/tickets/consultar?id=${t.id}${S.cobro.perdido ? "&perdido=1" : ""}`);
  S.cobro.ticket = nuevo;
  S.cobro.entregado = "";
  pintarCobro();
}

const modalServicios = accion(async (ticketId, alCambiar) => {
  const prods = await api("GET", "/api/productos?activos=1");
  let cant = 1;
  const m = modal(`<h2>Añadir servicio o producto</h2>
    <div class="fila" style="margin:10px 0 14px"><span class="suave">Cantidad</span>
      <button class="btn mini" id="sv-menos">−</button><b id="sv-cant" class="num" style="min-width:2em;text-align:center;font-size:1.3rem">1</b>
      <button class="btn mini" id="sv-mas">+</button></div>
    <div class="catalogo">${!prods.length ? '<div class="suave">No hay servicios en el catálogo (Ajustes → Servicios y productos). Puede crear uno personalizado aquí abajo.</div>' : ""}${prods.map((p) => `<button class="prod" data-p="${p.id}">
      <span class="etiqueta ${p.tipo === "producto" ? "e-dentro" : "e-abonado"}">${TIPO_PROD[p.tipo]}</span>
      <span class="prod-n">${esc(p.nombre)}</span><span class="prod-p num">${textoPrecio(p)}</span>
      ${p.minutos_incluidos ? `<span class="etiqueta e-pagado">+ ${duracion(p.minutos_incluidos)} de parking</span>` : ""}
      <span class="suave" style="font-size:.75rem">IVA ${p.iva_efectivo}%</span></button>`).join("")}</div>
    <div class="sv-libre"><b>Servicio personalizado</b> <span class="suave">(solo para esta venta; no se guarda en el catálogo)</span>
      <div class="sv-libre-f"><input class="ent" id="sv-nombre" maxlength="80" placeholder="Descripción (p. ej. Lavado especial)" autocomplete="off">
        <input class="ent" id="sv-precio" inputmode="decimal" placeholder="Precio €" autocomplete="off">
        <select class="ent" id="sv-iva" title="IVA"><option value="">IVA general</option><option value="21">21 %</option><option value="10">10 %</option><option value="4">4 %</option><option value="0">0 %</option></select>
        <button class="btn prim" id="sv-libre">Añadir</button></div></div>
    <div id="sv-ok" class="aviso verde oculto" style="margin-top:12px"></div>
    <div class="modal-pie"><button class="btn prim" data-c>Listo</button></div>`, { ancho: true });
  const pintarCant = () => ($("#sv-cant").textContent = cant);
  $("#sv-menos").onclick = () => { cant = Math.max(1, cant - 1); pintarCant(); };
  $("#sv-mas").onclick = () => { cant = Math.min(99, cant + 1); pintarCant(); };
  $$("[data-p]", m).forEach((b) => (b.onclick = accion(async () => {
    const p = prods.find((x) => x.id === Number(b.dataset.p));
    let precio = p.precio_cent;
    if (p.precio_variable) { precio = await pedirPrecio(p.nombre); if (precio === null) return; }   // 4.62: sin precio fijo → se pregunta
    await api("POST", `/api/tickets/${ticketId}/extras`, p.precio_variable ? { producto_id: p.id, cantidad: cant, precio_cent: precio } : { producto_id: p.id, cantidad: cant });
    const ok = $("#sv-ok");
    ok.classList.remove("oculto");
    ok.textContent = `Añadido: ${cant > 1 ? cant + " × " : ""}${p.nombre} (${eur(precio * cant)})`;
    b.classList.add("anadido"); setTimeout(() => b.classList.remove("anadido"), 500);
    cant = 1; pintarCant();
    if (alCambiar) await alCambiar();
  })));
  $("#sv-libre").onclick = accion(async () => {
    const nombre = $("#sv-nombre").value.trim();
    const precio = Math.round(parseFloat($("#sv-precio").value.replace(",", ".")) * 100);
    if (!nombre) throw new Error("Escriba la descripción del servicio");
    if (!Number.isFinite(precio) || precio < 0) throw new Error("Indique un precio válido");
    const iva = $("#sv-iva").value;
    await api("POST", `/api/tickets/${ticketId}/extras`, { personalizado: { nombre, precio_cent: precio, iva_pct: iva === "" ? null : Number(iva) }, cantidad: cant });
    const ok = $("#sv-ok");
    ok.classList.remove("oculto");
    ok.textContent = `Añadido: ${cant > 1 ? cant + " × " : ""}${nombre} (${eur(precio * cant)}) · solo esta venta`;
    $("#sv-nombre").value = ""; $("#sv-precio").value = ""; cant = 1; pintarCant();
    if (alCambiar) await alCambiar();
  });
  $("[data-c]", m).onclick = () => { cerrarModal(); };
});

// ================================== Anular ticket, cambio de tarifa y barrera

// 4.31: sustituye a «Ticket perdido…»: se busca el vehículo y se anula su ticket (emitido por error, sin cobros).
function modalAnularSalida() {
  const c = modal(`<h2>Anular ticket</h2>
    <p class="suave">Busque el vehículo por matrícula o código. Solo se pueden anular tickets que siguen dentro y sin cobros; queda en auditoría.</p>
    <input class="ent grande" id="p-buscar" placeholder="Matrícula o código" autofocus autocomplete="off">
    <div id="p-res" style="margin-top:12px"></div>
    <div class="modal-pie"><button class="btn" data-c>Cerrar</button></div>`, { ancho: true });
  $("[data-c]", c).onclick = cerrarModal;
  let tm;
  const buscar = async () => {
    if (!$("#p-buscar")) return;
    const q = $("#p-buscar").value.trim();
    const filas = await api("GET", "/api/dentro?buscar=" + encodeURIComponent(q));
    $("#p-res").innerHTML = filas.length ? `<table class="tabla"><thead><tr><th>Matrícula</th><th>Entrada</th><th>Tiempo</th><th>Estado</th><th></th></tr></thead><tbody>
      ${filas.slice(0, 30).map((f) => `<tr><td><b>${esc(f.matricula || "—")}</b><div class="suave mono" style="font-size:.8rem">${esc(f.codigo)}</div></td>
        <td>${fechaHora(f.entrada)}</td><td>${duracion(f.minutos)}</td><td>${etiquetaEstado(f.estado)}</td>
        <td class="der">${f.estado === "dentro" && !f.n_pagos && !f.cliente_id ? `<button class="btn peligro" data-id="${f.id}" data-cod="${esc(f.codigo)}">Anular</button>`
          : `<span class="suave" style="font-size:.85rem">${f.cliente_id ? "De un abonado" : "Con cobros"}</span>`}</td></tr>`).join("")}</tbody></table>`
      : `<div class="vacio">Ningún vehículo coincide.</div>`;
    $$("[data-id]", $("#p-res")).forEach((b) => (b.onclick = () => { cerrarModal(); modalAnular(b.dataset.id, b.dataset.cod, () => { if (S.cobro.ticket && String(S.cobro.ticket.id) === b.dataset.id) limpiarCobro(); }); }));
  };
  $("#p-buscar").oninput = () => { clearTimeout(tm); tm = setTimeout(accion(buscar), 250); };
  accion(buscar)();
}

const modalCambiarTarifa = accion(async (t, despues) => {
  const tarifas = (await api("GET", "/api/tarifas")).filter((x) => x.activa);
  if (tarifas.length < 2) throw new Error("Solo hay una tarifa activa. Cree otras en Ajustes → Tarifas.");
  const c = modal(`<h2>Cambiar tarifa</h2>
    <p class="suave">${t.matricula ? `<b class="mono">${esc(t.matricula)}</b> · ` : ""}ticket <span class="mono">${esc(t.codigo)}</span> · entrada ${fechaHora(t.entrada)}</p>
    <div class="lista-tarifas">${tarifas.map((x) => `<label class="opcion-tarifa"><input type="radio" name="tf" value="${x.id}" ${x.id === t.tarifa_id ? "checked" : ""}>
      <span><b>${esc(x.nombre)}</b>${x.por_defecto ? ' <span class="etiqueta e-pagado">por defecto</span>' : ""}
      <span class="suave" style="display:block;font-size:.85rem">${x.gracia_min ? `${x.gracia_min} min gratis · ` : ""}${x.maximo_diario_cent ? `máximo ${eur(x.maximo_diario_cent)} / 24 h` : "sin máximo diario"}${x.texto_ticket ? " · " + esc(x.texto_ticket) : ""}</span></span></label>`).join("")}</div>
    <p class="ayuda">El importe se recalcula con la tarifa nueva desde la hora de entrada. Queda registrado en auditoría.</p>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Guardar tarifa</button></div>`);
  $("[data-c]", c).onclick = cerrarModal;
  $("[data-ok]", c).onclick = accion(async () => {
    const sel = $('[name="tf"]:checked', c);
    if (!sel) throw new Error("Elija una tarifa");
    const tk = await api("POST", `/api/tickets/${t.id}/tarifa`, { tarifa_id: Number(sel.value) });
    cerrarModal();
    toast(`Tarifa cambiada a ${tk.tarifa_nombre}`, "ok");
    despues && despues();
  });
});

const abrirBarraManual = accion(async () => {
  const motivo = await new Promise((ok) => {
    const m = modal(`<h2>Abrir la barrera</h2><p class="suave">Queda anotado con su nombre y la hora.</p>
      <label class="campo" style="margin-top:10px">Motivo <span class="ayuda">opcional</span><input class="ent" id="br-m" placeholder="Cliente sin ticket, proveedor…" autofocus></label>
      <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Abrir barrera</button></div>`);
    $("[data-c]", m).onclick = () => { cerrarModal(); ok(null); };
    const seguir = () => { const v = $("#br-m", m).value; cerrarModal(); ok(v); };
    $("[data-ok]", m).onclick = seguir;
    $("#br-m", m).onkeydown = (e) => { if (e.key === "Enter") seguir(); };
  });
  if (motivo === null) return;
  await api("POST", "/api/barrera/abrir", { motivo });
  toast("Barrera abierta", "ok");
});
