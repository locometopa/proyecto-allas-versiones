/* PROYECTO ALLAS · Clientes y bonos */
"use strict";

// ==================================================================== Clientes

const TIPO_CLIENTE = { abonado: ["e-abonado", "Abonado"], facturacion: ["e-factura", "Sin abono"] };

const chipTipo = (t) => `<span class="etiqueta ${TIPO_CLIENTE[t || "abonado"][0]}">${TIPO_CLIENTE[t || "abonado"][1]}</span>`;

function chipBono(b) {
  if (!b) return "";
  const txt = {
    vigente: `Vigente hasta ${fechaCorta(b.hasta)}`,
    caduca: `Caduca el ${fechaCorta(b.hasta)} (${b.dias} día${b.dias === 1 ? "" : "s"})`,
    caducado: `Caducado el ${fechaCorta(b.hasta)}`,
    futuro: `Empieza el ${fechaCorta(b.desde)}`,
    sin_bono: "Sin bono",
  }[b.estado];
  return `<span class="etiqueta e-bono-${b.estado}">${txt}</span>` +
    (b.pendiente ? ` <span class="etiqueta e-err" title="Bono ${esc(b.pendiente.numero)}">${b.deudas > 1 ? `Deuda ${eur(b.deuda_total_cent)} (${b.deudas} periodos)` : `Pago pendiente ${eur(b.pendiente.importe_cent)}`}</span>` : "");
}

function estadoPeriodo(b) {
  const hoy = hoyISO();
  if (b.hasta < hoy) return '<span class="etiqueta e-salido">Terminado</span>';
  if (b.desde > hoy) return '<span class="etiqueta e-dentro">Próximo</span>';
  return '<span class="etiqueta e-pagado">En curso</span>';
}

// 4.60: los proveedores (solo se les factura, con servicios y precios propios) necesitan el módulo de gestión o de tienda
const puedeProveedores = () => tieneModulo("gestion") || tieneModulo("tienda");

function vistaClientes(v) {
  const F = [["todos", "Todos"], ["vigente", "Bono vigente"], ["caduca", "Caducan pronto"], ["caducado", "Caducados"], ["sin_bono", "Sin bono"], ["pendiente", "Pago pendiente"]];
  v.innerHTML = `<div class="cab"><h2>${tieneModulo("abonados") ? "Clientes y bonos" : "Clientes"}</h2>
      <div class="fila"><input class="ent" id="cl-buscar" placeholder="Nombre, matrícula, NIF o teléfono" style="min-width:300px" autocomplete="off" value="${esc(S.clientes.buscar)}">
      <button class="btn mod-abonados" id="b-avisos">Avisos de caducidad</button>
      ${tieneRol("admin", "supervisor") ? '<button class="btn mod-abonados mod-mensajeria" id="b-cl-comunicado">✉ Comunicado a abonados</button>' : ""}
      <button class="btn prim" id="b-cl-nuevo">Nuevo cliente</button></div></div>
    <div class="rejilla r3 mod-abonados" id="cl-kpis" style="margin-bottom:16px"></div>
    <div class="chips mod-abonados"><span class="filtro-tipo">${[["abonado", "Abonados"], ["facturacion", "Clientes sin abono"], ...(puedeProveedores() ? [["proveedor", "Proveedores"]] : []), ["todos", "Todos"]].map(([id, n]) =>
      `<button class="chip ${S.clientes.tipo === id ? "activo" : ""}" data-tipo="${id}">${n}</button>`).join("")}</span>
      <span class="suave" style="margin:0 6px">|</span>
      ${F.map(([id, n]) => `<button class="chip ${S.clientes.filtro === id ? "activo" : ""}" data-f="${id}">${n}</button>`).join("")}</div>
    <div class="panel" id="cl-tabla"><div class="vacio">Cargando…</div></div>`;
  let tm;
  const cargar = accion(async () => {
    if (!$("#cl-tabla")) return;
    const todos = await api("GET", `/api/clientes?buscar=${encodeURIComponent(S.clientes.buscar)}`);
    if (!$("#cl-tabla")) return;
    const cuenta = (est) => todos.filter((c) => est.includes(c.bono.estado)).length;
    $("#cl-kpis").innerHTML = `
      <div class="panel kpi"><div class="t">Bonos vigentes</div><div class="v num verde">${cuenta(["vigente", "caduca"])}</div></div>
      <div class="panel kpi"><div class="t">Caducan en 7 días</div><div class="v num" style="color:var(--ambar)">${cuenta(["caduca"])}</div></div>
      <div class="panel kpi"><div class="t">Caducados</div><div class="v num rojo">${cuenta(["caducado"])}</div></div>`;
    const f = S.clientes.filtro, tp = S.clientes.tipo;
    // Abonados y clientes sin abono bien separados (con su número); los filtros de bono solo para abonados
    const nTipo = { abonado: todos.filter((c) => c.tipo !== "facturacion").length, facturacion: todos.filter((c) => c.tipo === "facturacion" && !c.proveedor).length,
      proveedor: todos.filter((c) => c.proveedor).length, todos: todos.length };
    $$("[data-tipo]").forEach((b) => { b.innerHTML = `${esc(b.dataset.n || (b.dataset.n = b.textContent))} <span class="cuenta-chip">${nTipo[b.dataset.tipo]}</span>`; });
    const sinBonos = tp === "facturacion" || tp === "proveedor";
    $$("[data-f]").forEach((b) => b.classList.toggle("oculto", sinBonos));
    $$(".chips .suave").forEach((x) => x.classList.toggle("oculto", sinBonos));
    $("#cl-kpis").classList.toggle("oculto", sinBonos);
    const filas = todos.filter((c) => tp === "todos" || (tp === "proveedor" ? c.proveedor : tp === "facturacion" ? c.tipo === "facturacion" && !c.proveedor : c.tipo === tp))
      .filter((c) => sinBonos || f === "todos" || (f === "pendiente" ? !!c.bono.pendiente : c.bono.estado === f || (f === "vigente" && c.bono.estado === "caduca")));
    const prov = tp === "proveedor";
    $("#cl-tabla").innerHTML = filas.length ? `<table class="tabla"><thead><tr><th>${prov ? "Proveedor" : "Cliente"}</th><th>${prov ? "Servicios y precios" : "Matrículas"}</th>${sinBonos ? "" : '<th class="mod-abonados">Bono</th>'}<th>Teléfono</th><th></th></tr></thead><tbody>
      ${filas.map((c) => `<tr class="clic" data-id="${c.id}">
        <td><b>${esc(c.nombre)}</b> <span class="mod-abonados">${chipTipo(c.tipo)}</span>${c.proveedor ? ' <span class="etiqueta e-aviso">Proveedor</span>' : ""}${c.activo ? "" : ' <span class="etiqueta e-salido">baja</span>'}${c.dentro ? ' <span class="etiqueta e-dentro">dentro</span>' : ""}
          ${c.nif || c.direccion ? `<div class="suave" style="font-size:.82rem">${esc([c.nif, c.direccion].filter(Boolean).join(" · "))}</div>` : ""}</td>
        <td ${c.proveedor ? "" : 'class="mono"'} style="font-size:.9rem">${esc(c.proveedor ? (c.servicios_txt || "Sin servicios: añádalos en su ficha") : (c.vehiculos_txt || "—"))}</td>
        ${sinBonos ? "" : `<td class="mod-abonados">${c.tipo === "facturacion" && c.bono.estado === "sin_bono" ? '<span class="suave">—</span>' : chipBono(c.bono)}${c.bono.plan ? `<div class="suave" style="font-size:.82rem">${esc(c.bono.plan)}</div>` : ""}</td>`}
        <td>${esc(c.telefono || "")}</td>
        <td class="der">${c.proveedor && c.activo ? `<button class="btn prim" data-facturar="${c.id}">Facturar</button> ` : ""}<button class="btn" data-id="${c.id}">Ver ficha</button></td></tr>`).join("")}</tbody></table>`
      : `<div class="vacio">${todos.length ? "Ningún cliente en este filtro." : "Aún no hay clientes. Pulse «Nuevo cliente» para dar de alta el primero."}</div>`;
    $$("[data-id]", $("#cl-tabla")).forEach((el) => (el.onclick = (ev) => { ev.stopPropagation(); abrirFicha(Number(el.dataset.id)); }));
    $$("[data-facturar]", $("#cl-tabla")).forEach((b) => (b.onclick = (ev) => { ev.stopPropagation(); modalFacturaProveedor(cargar, Number(b.dataset.facturar)); }));
  });
  S.clientes.recargar = cargar;
  $("#cl-buscar").oninput = (e) => { S.clientes.buscar = e.target.value; clearTimeout(tm); tm = setTimeout(cargar, 250); };
  $$("[data-f]").forEach((b) => (b.onclick = () => { S.clientes.filtro = b.dataset.f; $$("[data-f]").forEach((x) => x.classList.toggle("activo", x === b)); cargar(); }));
  $$("[data-tipo]").forEach((b) => (b.onclick = () => { S.clientes.tipo = b.dataset.tipo; $$("[data-tipo]").forEach((x) => x.classList.toggle("activo", x === b)); cargar(); }));
  $("#b-cl-nuevo").onclick = () => formCliente(null);
  if ($("#b-cl-comunicado")) $("#b-cl-comunicado").onclick = () => modalComunicado();
  $("#b-avisos").onclick = () => modalAvisos();
  if (tieneModulo("abonados")) contarAvisos();
  $("#cl-buscar").focus();
  cargar();
}

function recargarClientes() { if (S.vista === "clientes" && S.clientes.recargar) S.clientes.recargar(); }

function formCliente(c, alGuardar) {
  // 4.60: pantalla ordenada por bloques; al elegir «Proveedor» los vehículos pasan a «Servicios y precios» y se quitan bonos y descuentos
  const puedeProv = puedeProveedores();
  const t0 = c ? (c.proveedor ? "proveedor" : c.tipo) : (S.clientes.tipo === "proveedor" && puedeProv ? "proveedor"
    : S.clientes.tipo === "facturacion" || !tieneModulo("abonados") ? "facturacion" : "abonado");
  const m = modal(`<h2>${c ? "Editar" : "Nuevo"} ${t0 === "proveedor" ? "proveedor" : "cliente"}</h2>
    <form id="f-cli" class="form-cli" autocomplete="off">
      <section class="fc-sec"><h3>Datos</h3><div class="rejilla r2">
        <label class="campo" style="grid-column:1/-1">Tipo
          <select class="ent" name="tipo" id="cl-tipo">
            ${tieneModulo("abonados") ? `<option value="abonado" ${t0 === "abonado" ? "selected" : ""}>Abonado: bonos mensuales y vehículos</option>` : ""}
            <option value="facturacion" ${t0 === "facturacion" ? "selected" : ""} ${c && c.bonos && c.bonos.some((b) => b.estado === "activo") ? "disabled" : ""}>Cliente sin abono: horas, productos o servicios (solo datos para facturas)</option>
            ${puedeProv ? `<option value="proveedor" ${t0 === "proveedor" ? "selected" : ""} ${c && c.bonos && c.bonos.some((b) => b.estado === "activo") ? "disabled" : ""}>Proveedor: solo factura, con sus servicios y precios (se añaden en su ficha)</option>` : ""}
          </select></label>
        <label class="campo" style="grid-column:1/-1">Nombre y apellidos o razón social<input class="ent" name="nombre" value="${esc(c?.nombre || "")}" required autofocus></label>
        <label class="campo">NIF / CIF <span class="ayuda">para la factura</span><input class="ent" name="nif" value="${esc(c?.nif || "")}"></label>
        <label class="campo">Teléfono<input class="ent" name="telefono" value="${esc(c?.telefono || "")}" inputmode="tel"></label>
        <label class="campo">Email<input class="ent" name="email" type="email" value="${esc(c?.email || "")}"></label>
        <label class="campo">Dirección<input class="ent" name="direccion" value="${esc(c?.direccion || "")}"></label>
      </div></section>
      <section class="fc-sec" id="fc-veh"><h3>Vehículos</h3>
        <p class="ayuda" style="margin:0 0 6px">Al entrar con estas matrículas se reconoce al cliente.</p>
        <div class="vehiculos" id="cl-vehs"></div>
        <button type="button" class="btn" id="cl-veh-add" style="align-self:flex-start;margin-top:6px">+ Añadir vehículo</button></section>
      <section class="fc-sec"><h3>Opciones</h3>
        <label class="fila" style="font-weight:600;gap:8px"><input type="checkbox" name="enviar_facturas" ${!c || c.enviar_facturas !== 0 ? "checked" : ""}>
          Enviarle sus facturas por email automáticamente <span class="ayuda">(necesita el envío automático SMTP en Ajustes → Email)</span></label>
        <label class="fila" id="fc-renov" style="font-weight:600;gap:8px;margin-top:8px"><input type="checkbox" name="renovacion_auto" ${!c || c.renovacion_auto !== 0 ? "checked" : ""}>
          Renovar su bono automáticamente al caducar <span class="ayuda">(queda pendiente de pago y se le avisa)</span></label>
        <div id="fc-dto" style="margin-top:8px"><label class="fila" style="font-weight:600;gap:8px"><input type="checkbox" id="cl-dto-on" ${c && c.descuento_pct > 0 ? "checked" : ""}>
          Descuento fijo en sus estancias</label>
          <div class="fila" style="gap:8px;margin:6px 0 0 26px"><input class="ent num" id="cl-dto" type="number" min="0.5" max="100" step="0.5" value="${c && c.descuento_pct > 0 ? c.descuento_pct : 10}" style="width:100px" ${c && c.descuento_pct > 0 ? "" : "disabled"} aria-label="Porcentaje de descuento"> <span>%</span>
            <span class="ayuda">se aplica solo al cobrar la salida (puede quitarse en el momento)</span></div></div>
      </section>
      <section class="fc-sec"><h3>Notas</h3>
        <textarea class="ent" name="notas" rows="2" aria-label="Notas">${esc(c?.notas || "")}</textarea>
        ${c ? `<label class="fila" style="font-weight:600;margin-top:8px"><input type="checkbox" name="activo" ${c.activo ? "checked" : ""}> Cliente activo</label>` : ""}</section>
    </form>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>${c ? "Guardar" : "Crear"}</button></div>`, { ancho: true });
  $("[data-c]", m).onclick = () => (c ? abrirFicha(c.id) : cerrarModal());
  // editor de vehículos: una fila por matrícula con su marca y modelo
  const vehs = (c?.vehiculos || []).map((v) => ({ ...v }));
  if (!vehs.length) vehs.push({ matricula: "", marca: "", modelo: "" });
  const leerVehs = () => $$("#cl-vehs .veh-fila:not(.veh-cab)").forEach((f, i) => {
    vehs[i] = { matricula: $(".v-mat", f).value, marca: $(".v-marca", f).value, modelo: $(".v-modelo", f).value };
  });
  const pintarVehs = () => {
    $("#cl-vehs").innerHTML = `<div class="veh-fila veh-cab"><span>Matrícula</span><span>Marca</span><span>Modelo</span><span></span></div>` +
      vehs.map((v, i) => `<div class="veh-fila">
        <input class="ent mono v-mat" value="${esc(v.matricula || "")}" placeholder="1234 ABC" style="text-transform:uppercase" aria-label="Matrícula">
        <input class="ent v-marca" value="${esc(v.marca || "")}" placeholder="Seat" list="marcas-comunes" aria-label="Marca">
        <input class="ent v-modelo" value="${esc(v.modelo || "")}" placeholder="Ibiza" aria-label="Modelo">
        <button type="button" class="btn peligro" data-qv="${i}" title="Quitar vehículo">✕</button></div>`).join("");
    $$("[data-qv]", $("#cl-vehs")).forEach((b) => (b.onclick = () => { leerVehs(); vehs.splice(Number(b.dataset.qv), 1); pintarVehs(); }));
  };
  pintarVehs();
  // lo que se ve según el tipo
  const ajustarTipo = () => {
    const t = $("#cl-tipo").value, prov = t === "proveedor", ab = t === "abonado";
    $("#fc-veh").classList.toggle("oculto", prov);
    $("#fc-renov").classList.toggle("oculto", !ab);
    $("#fc-dto").classList.toggle("oculto", prov);
    $("#fc-veh h3").textContent = ab ? "Vehículos" : "Vehículos habituales";
    $("h2", m).textContent = `${c ? "Editar" : "Nuevo"} ${prov ? "proveedor" : "cliente"}`;
  };
  $("#cl-tipo").onchange = ajustarTipo; ajustarTipo();
  $("#cl-dto-on").onchange = (e) => { $("#cl-dto").disabled = !e.target.checked; if (e.target.checked) $("#cl-dto").focus(); };
  $("#cl-veh-add").onclick = () => { leerVehs(); vehs.push({ matricula: "", marca: "", modelo: "" }); pintarVehs(); $$("#cl-vehs .v-mat").pop().focus(); };
  const guardar = accion(async () => {
    const f = $("#f-cli");
    if (!f.nombre.value.trim()) throw new Error("Escriba el nombre del cliente");
    const d = Object.fromEntries(new FormData(f));
    const prov = d.tipo === "proveedor";
    leerVehs();
    d.vehiculos = prov ? [] : vehs.filter((v) => (v.matricula || v.marca || v.modelo || "").trim());
    d.activo = c ? !!f.activo?.checked : true;
    d.enviar_facturas = !!f.enviar_facturas.checked;
    d.renovacion_auto = !!f.renovacion_auto.checked;
    d.proveedor = prov;
    if (prov) {
      d.tipo = "facturacion";
      d.descuento_pct = 0;
    } else {
      d.descuento_pct = $("#cl-dto-on").checked ? Number($("#cl-dto").value) : 0;
      if ($("#cl-dto-on").checked && !(d.descuento_pct > 0 && d.descuento_pct <= 100)) throw new Error("Indique un descuento entre 0,5 y 100 %");
    }
    const r = await api(c ? "PUT" : "POST", c ? `/api/clientes/${c.id}` : "/api/clientes", d);
    toast(c ? "Cliente guardado" : "Cliente creado", "ok");
    if (r.aviso) toast(r.aviso, "aviso");
    recargarClientes();
    alGuardar ? alGuardar(r) : abrirFicha(r.id, r);
  });
  $("[data-ok]", m).onclick = guardar;
  $("#f-cli").onsubmit = (e) => { e.preventDefault(); guardar(); };
}

const abrirFicha = accion(async (id, datos) => {
  const c = datos || await api("GET", `/api/clientes/${id}`);
  const sup = tieneRol("admin", "supervisor");
  const vig = ["vigente", "caduca"].includes(c.bono.estado);
  if (c.proveedor) return fichaProveedor(c);
  const sinBonos = c.tipo === "facturacion" && !c.bonos.length;   // cliente sin abono: no se enseña el apartado de bonos
  const m = modal(`
    <div class="fila" style="justify-content:space-between;align-items:flex-start">
      <div class="abonado-cab" style="margin:0"><div class="avatar">${esc(c.nombre.charAt(0).toUpperCase())}</div>
        <div><h2>${esc(c.nombre)}</h2><div class="suave">${[c.nif, c.telefono, c.email].filter(Boolean).map(esc).join(" · ") || "Sin datos de contacto"}</div>
        <div style="margin-top:6px"><span class="mod-abonados">${chipTipo(c.tipo)} ${c.tipo === "facturacion" && !c.bonos.length ? "" : chipBono(c.bono)}</span> ${c.activo ? "" : '<span class="etiqueta e-salido">Baja</span>'}</div>
        ${c.direccion ? `<div class="suave" style="font-size:.88rem;margin-top:4px">${esc(c.direccion)}</div>` : ""}</div></div>
      <button class="btn" data-c>Cerrar</button></div>
    <div class="fila" style="margin:16px 0 14px;flex-wrap:wrap">
      <button class="btn prim mod-abonados" id="f-vender">${c.bonos.length ? "Renovar / vender bono" : "Vender bono"}</button>
      <button class="btn mod-abonados" id="f-tarjeta">Imprimir tarjeta</button>
      ${vig && !c.dentro && c.activo ? `<button class="btn ok mod-abonados" id="f-entrada">Registrar entrada</button>` : ""}
      <button class="btn" id="f-editar">Editar datos</button>
    </div>
    ${c.deudas && c.deudas.length ? `<div class="aviso rojo fila" style="margin-bottom:10px;justify-content:space-between">
      <span>Deuda pendiente: <b>${eur(c.deudas.reduce((t, d) => t + d.pendiente_cent, 0))}</b> en ${c.deudas.length} bono(s)
        <span id="f-ult-recordatorio" class="suave" style="display:block;font-size:.82rem"></span></span>
      <span class="fila" style="gap:8px"><button class="btn" id="f-recordar" ${c.email ? "" : 'disabled title="Añada su email en «Editar datos»"'}>✉ Recordar por email</button>
      ${S.estado.mensajes && S.estado.mensajes !== "no" ? `<button class="btn mod-mensajeria" id="f-recordar-msg" ${c.telefono ? "" : 'disabled title="Añada su móvil en «Editar datos»"'}>💬 WhatsApp / SMS</button>` : ""}
      ${sup ? '<button class="btn peligro" id="f-cancelar-deudas">Cancelar deudas…</button>' : ""}</span></div>` : ""}
    <div class="ficha-grid">
      <div class="ficha-main">
        <div class="mod-abonados ${sinBonos ? "oculto" : ""}"><h3 style="margin:0 0 8px">Bonos</h3>
          <div id="f-suscripcion"></div>
    ${c.bonos.length ? `<div style="overflow-x:auto"><table class="tabla"><thead><tr><th>Periodo</th><th>Nº bono</th><th>Tipo</th><th>Factura</th><th class="der">Importe</th><th>Estado</th><th></th></tr></thead><tbody>
      ${c.bonos.map((b) => `<tr><td class="num" style="white-space:nowrap">${fechaCorta(b.desde)} →<br>${fechaCorta(b.hasta)}</td><td class="mono" style="font-size:.85rem">${esc(b.numero_txt || "")}</td><td>${esc(b.plan_nombre)}</td>
        <td class="mono" style="font-size:.85rem">${(b.pagos || []).length ? b.pagos.map((x) => `<button class="btn mini" data-fac="${x.id}" title="${eur(x.importe_cent)} · ${esc(x.metodo)} · ver, imprimir o enviar">${esc(x.serie)}-${String(x.numero).padStart(6, "0")}</button>`).join("<br>") : "—"}</td>
        <td class="der num">${eur(b.importe_cent)}${b.estado === "activo" && b.pagado_cent && b.pagado_cent < b.importe_cent ? `<div class="suave" style="font-size:.8rem">pagado ${eur(b.pagado_cent)}</div>` : ""}${b.cancelado_cent ? `<div class="suave" style="font-size:.8rem" title="${esc(b.cancelado_motivo || "")}">cancelado ${eur(b.cancelado_cent)}</div>` : ""}</td>
        <td>${b.estado === "anulado" ? `<span class="etiqueta e-anulado" title="${esc(b.anulado_motivo || "")}">Anulado</span>` : estadoPeriodo(b)}
          ${b.estado === "activo" && !b.pagado ? `<span class="etiqueta e-err">Pendiente ${eur(b.pendiente_cent)}</span>` : ""}</td>
        <td class="der"><div class="acciones-bono">${b.estado === "activo" && !b.pagado ? `<button class="btn ok" data-cobrar-bono="${b.id}">Cobrar</button>` : ""}${menuAcciones([b.estado === "activo" && !b.pagado && sup ? { attr: `data-cancelar-deuda="${b.id}"`, texto: "Cancelar deuda" } : null, b.estado === "activo" && sup ? { attr: `data-anular="${b.id}"`, texto: "Anular bono", peligro: true } : null])}</div></td></tr>`).join("")}</tbody></table></div>`
      : `<div class="vacio" style="padding:18px">Todavía no ha comprado ningún bono.</div>`}
        </div>
    ${c.facturas && c.facturas.length ? `<h3 style="margin:22px 0 8px" class="ficha-h">Facturas a su nombre</h3><table class="tabla"><tbody>
      ${c.facturas.slice(0, 8).map((x) => `<tr><td class="mono">${esc(x.serie)}-${String(x.numero).padStart(6, "0")}</td><td class="num">${fechaHora(x.fecha)}</td>
        <td>${x.concepto === "bono" ? "Bono" : "Estancia"}${x.matricula ? ` · <span class="mono">${esc(x.matricula)}</span>` : ""}</td><td class="der num">${eur(x.importe_cent)}</td>
        <td class="der"><button class="btn" data-fac="${x.id}">Ver o enviar</button></td></tr>`).join("")}</tbody></table>` : ""}
    ${c.estancias.length ? `<h3 style="margin:22px 0 8px" class="ficha-h">Últimas estancias</h3><table class="tabla"><tbody>
      ${c.estancias.slice(0, 6).map((e) => `<tr><td class="num">${fechaHora(e.entrada)}</td><td class="num">${e.salida ? "→ " + fechaHora(e.salida) : ""}</td><td class="mono">${esc(e.matricula || "")}</td><td>${etiquetaEstado(e.estado)}</td></tr>`).join("")}</tbody></table>` : ""}
      </div>
      <aside class="ficha-lado">
        <div class="panel ficha-datos">
          <div class="fd-fila"><span class="t">Ahora</span><span>${c.dentro ? `Dentro desde ${hora(c.dentro.entrada)} · <span class="mono">${esc(c.dentro.matricula || "")}</span>` : "Fuera del parking"}</span></div>
          <div class="fd-fila"><span class="t">Vehículos</span><span style="line-height:1.5">${vehiculosConFoto(c, true)}</span></div>
          <div class="fd-fila mod-abonados ${sinBonos ? "oculto" : ""}"><span class="t">Tarjeta</span><span class="mono">${esc(c.codigo)}</span></div>
          <div class="fd-fila mod-abonados ${sinBonos ? "oculto" : ""}"><span class="t">Renovación automática</span><span><b>${c.renovacion_auto === 0 ? "No" : "Sí"}</b>${c.renovacion_auto === 0 ? "" : '<span class="suave" style="display:block;font-size:.8rem">al caducar se crea el siguiente periodo pendiente de pago</span>'}</span></div>
          ${c.descuento_pct > 0 ? `<div class="fd-fila"><span class="t">Descuento fijo</span><span><span class="etiqueta e-pagado">${esc(String(c.descuento_pct).replace(".", ","))} %</span> <span class="suave">en sus estancias</span></span></div>` : ""}
        </div>
        ${c.notas ? `<div class="aviso" style="margin-top:12px"><b>Notas</b><br>${esc(c.notas)}</div>` : ""}
      </aside>
    </div>
  `, { ancho: true });
  $("#modal-caja").classList.add("muy-ancho");
  $("[data-c]", m).onclick = () => { cerrarModal(); recargarClientes(); };
  $("#f-editar").onclick = () => formCliente(c);
  $$("[data-fac]", m).forEach((b) => (b.onclick = () => modalFactura(Number(b.dataset.fac), () => abrirFicha(c.id))));
  pintarSuscripcionFicha(c, $("#f-suscripcion"));
  $$("[data-cobrar-bono]", m).forEach((b) => (b.onclick = () => {
    const bono = c.bonos.find((x) => x.id === Number(b.dataset.cobrarBono));
    modalCobrarRenovacion({ bono_id: bono.id, importe_cent: bono.pendiente_cent, total_cent: bono.importe_cent, pagado_cent: bono.pagado_cent,
      desde: bono.desde, hasta: bono.hasta, numero: bono.numero_txt, plan: bono.plan_nombre }, c, () => abrirFicha(c.id));
  }));
  $$("[data-cancelar-deuda]", m).forEach((b) => (b.onclick = () => modalCancelarDeuda(c, c.deudas.filter((d) => d.id === Number(b.dataset.cancelarDeuda)))));
  if ($("#f-cancelar-deudas")) $("#f-cancelar-deudas").onclick = () => modalCancelarDeuda(c, c.deudas);
  if ($("#f-recordar")) { $("#f-recordar").onclick = () => modalRecordatorioDeuda(c); mostrarUltimoRecordatorio(c); }
  if ($("#f-recordar-msg")) $("#f-recordar-msg").onclick = () => modalRecordatorioMensaje(c);
  $("#f-vender").onclick = () => modalVenderBono(c.id, () => abrirFicha(c.id));
  $("#f-tarjeta").onclick = accion(async () => { const r = await api("POST", `/api/clientes/${c.id}/tarjeta`); notarImpresion(r); verImpresion(r); });
  if ($("#f-entrada")) $("#f-entrada").onclick = accion(async () => {
    const tk = await api("POST", `/api/clientes/${c.id}/entrada`, {}); toast(tk.mensaje, "ok"); refrescarEstado(); abrirFicha(c.id);
  });
  $$("[data-anular]", m).forEach((b) => (b.onclick = () => modalAnularBono(c, Number(b.dataset.anular))));
});

function modalAnularBono(c, bonoId) {
  const bono = (c.bonos || []).find((x) => x.id === bonoId) || {};
  ventanaForm({ titulo: `Anular bono · ${esc(c.nombre)}`, aceptar: "Anular bono", peligro: true, volver: () => abrirFicha(c.id),
    cuerpo: `<p class="suave" style="margin:10px 0">${bono.plan_nombre ? `<b>${esc(bono.plan_nombre)}</b> · ` : ""}${bono.desde ? `${fechaCorta(bono.desde)} → ${fechaCorta(bono.hasta)}` : ""}<br>
      El bono deja de dar acceso. <b>No se devuelve el dinero</b> y la anulación queda en auditoría.</p>
      <label class="campo">Motivo (obligatorio)<input class="ent" id="ab-motivo" placeholder="p. ej. error al venderlo, el cliente se da de baja" autocomplete="off" autofocus></label>`,
    onOk: async () => {
      const motivo = $("#ab-motivo").value.trim();
      if (!motivo) { $("#ab-motivo").focus(); throw new Error("Indique el motivo de la anulación"); }
      await api("POST", `/api/bonos/${bonoId}/anular`, { motivo });
      toast("Bono anulado", "ok"); refrescarEstado(); abrirFicha(c.id);
    } });
}

// ======================================================================= Bonos

const modalVenderBono = accion(async (clienteId, despues) => {
  const [c, planes] = await Promise.all([api("GET", `/api/clientes/${clienteId}`), api("GET", "/api/planes?activos=1")]);
  if (!planes.length) throw new Error("No hay tipos de bono a la venta. Créelos en Ajustes → Bonos.");
  const st = { plan: planes[0], desde: c.proximo_desde, hasta: null, metodo: "efectivo" };
  const m = modal(`<h2>${c.bonos.length ? "Renovar bono" : "Vender bono"} · ${esc(c.nombre)}</h2>
    <div class="rejilla r2" style="margin-top:14px">
      <label class="campo">Tipo de bono<select class="ent" id="vb-plan">${planes.map((p) => `<option value="${p.id}">${esc(p.nombre)} — ${eur(p.precio_cent)}</option>`).join("")}</select></label>
      <label class="campo">Empieza el<input class="ent" type="date" id="vb-desde" value="${c.proximo_desde}"></label>
    </div>
    <div class="aviso verde" id="vb-periodo" style="margin-top:12px">…</div>
    <label class="fila" style="margin-top:10px;font-weight:600;gap:8px"><input type="checkbox" id="vb-renov" ${c.renovacion_auto === 0 ? "" : "checked"}>
      Renovar automáticamente al caducar <span class="ayuda">(se cobrará al renovar; desmárquelo para que no se renueve)</span></label>
    <div class="total" style="margin-top:14px"><div class="t">Total a cobrar</div><div class="v num" id="vb-total">–</div></div>
    <div id="vb-parcial-caja"></div>
    <div class="metodos">${botonesMetodoBono()}</div>
    ${bloqueTransferencia("vb")}
    <div id="vb-ef"><label class="campo">Entregado<input class="ent grande num" id="vb-ent" inputmode="decimal" placeholder="Cantidad recibida"></label>
      <div class="cambio" id="vb-cambio"><span>Cambio</span><span class="v num">0,00 €</span></div></div>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn ok xl" data-ok>Cobrar</button></div>`, { ancho: true });
  const aCobrar = () => importeParcial("vb", st.plan.precio_cent);
  const actualizarCambio = () => {
    const imp = aCobrar();
    if ($("[data-ok]", m)) $("[data-ok]", m).textContent = Number.isNaN(imp) ? "Cobrar" : "Cobrar " + eur(imp);
    pintarCambio($("#vb-cambio"), $("#vb-ent"), imp, st.plan.precio_cent);
  };
  const periodo = accion(async () => {
    st.plan = planes.find((p) => p.id === Number($("#vb-plan").value));
    st.desde = $("#vb-desde").value;
    const r = await api("GET", `/api/clientes/${clienteId}/periodo?plan_id=${st.plan.id}&desde=${st.desde}`);
    st.hasta = r.hasta;
    $("#vb-periodo").innerHTML = `Válido del <b>${fechaCorta(r.desde)}</b> al <b>${fechaCorta(r.hasta)}</b> (ambos incluidos)`;
    $("#vb-total").textContent = eur(r.precio_cent);
    const antes = $("#vb-parcial-chk") ? { chk: $("#vb-parcial-chk").checked, imp: $("#vb-imp").value } : null;
    $("#vb-parcial-caja").innerHTML = st.plan.precio_cent > 0 ? campoParcial("vb", st.plan.precio_cent) : "";
    if (st.plan.precio_cent > 0) {
      if (antes && antes.chk) { $("#vb-parcial-chk").checked = true; $("#vb-imp").value = antes.imp; $("#vb-parcial").classList.remove("oculto"); }
      montarParcial("vb", st.plan.precio_cent, actualizarCambio);
    }
    actualizarCambio();
  });
  $("#vb-plan").onchange = periodo;
  $("#vb-desde").onchange = periodo;
  $("#vb-ent").oninput = actualizarCambio;
  $$("[data-m]", m).forEach((b) => (b.onclick = () => {
    st.metodo = b.dataset.m;
    $$("[data-m]", m).forEach((x) => x.classList.toggle("sel", x === b));
    $("#vb-ef").classList.toggle("oculto", st.metodo !== "efectivo");
    $("#vb-tr").classList.toggle("oculto", st.metodo !== "transferencia");
    if (st.metodo === "transferencia") $("#vb-ref").focus();
  }));
  $("[data-c]", m).onclick = () => (despues ? despues() : cerrarModal());
  $("[data-ok]", m).onclick = accion(async () => {
    let ent = null;
    const imp = st.plan.precio_cent > 0 ? aCobrar() : 0;
    if (st.plan.precio_cent > 0 && (Number.isNaN(imp) || imp <= 0 || imp > st.plan.precio_cent)) throw new Error(`Indique un importe entre 0,01 € y ${eur(st.plan.precio_cent)}`);
    if (st.metodo === "efectivo") {
      ent = entregadoEfectivo($("#vb-ent").value, imp, "#vb-ent");
    }
    const r = await api("POST", `/api/clientes/${clienteId}/bono`, { plan_id: st.plan.id, desde: st.desde, metodo: st.metodo, entregado_cent: ent,
      renovacion_auto: $("#vb-renov").checked, importe_cent: st.plan.precio_cent > 0 ? imp : null,
      referencia: st.metodo === "transferencia" ? $("#vb-ref").value : null });
    notarImpresion(r.impresion);
    refrescarEstado();
    const ok = modal(`<div class="exito"><div class="icono">✓</div>
        <h2>Bono vendido: ${eur(r.bono.importe_cent)}</h2>
        ${r.pago && r.pago.metodo === "efectivo" ? `<p class="suave" style="margin:14px 0 2px">Cambio a devolver</p><div class="grande num">${eur(r.pago.cambio_cent)}</div>` : ""}
        <div class="aviso verde">${esc(r.bono.plan_nombre)}: del ${fechaCorta(r.bono.desde)} al ${fechaCorta(r.bono.hasta)}</div>
        ${r.saldo && r.saldo.pendiente_cent ? `<div class="aviso" style="margin-top:8px">Pago a cuenta de ${eur(r.pago.importe_cent)} · queda pendiente <b>${eur(r.saldo.pendiente_cent)}</b></div>` : ""}
        ${r.email ? `<div class="aviso ${r.email.estado === "enviado" ? "verde" : r.email.estado === "pendiente" ? "" : "rojo"}" style="margin-top:8px">${
          r.email.estado === "enviado" ? `Factura enviada por email a ${esc(r.email.destino)}` : r.email.estado === "pendiente"
            ? `La factura para ${esc(r.email.destino)} queda pendiente de envío (se reintentará)` : `No se pudo enviar la factura: ${esc(r.email.error || "")}`}</div>` : ""}</div>
      <div class="modal-pie"><button class="btn" id="ok-recibo">Ver factura</button>
        ${r.pago ? '<button class="btn" id="ok-fac">Datos / email</button>' : ""}<button class="btn" id="ok-tarjeta">Imprimir tarjeta</button>
        <button class="btn prim" data-c autofocus>Aceptar</button></div>`);
    $("#ok-recibo").onclick = () => verImpresion(r.impresion);
    if ($("#ok-fac")) $("#ok-fac").onclick = () => modalFactura(r.pago.id);
    $("#ok-tarjeta").onclick = accion(async () => { const t = await api("POST", `/api/clientes/${clienteId}/tarjeta`); notarImpresion(t); toast("Tarjeta impresa", "ok"); });
    $("[data-c]", ok).onclick = () => { recargarClientes(); despues ? despues() : cerrarModal(); };
  });
  periodo();
});

// Cobro en caja de una renovación automática pendiente de pago
function modalCobrarRenovacion(pend, c, despues) {
  const st = { metodo: "efectivo" };
  const m = modal(`<h2>Cobrar bono · ${esc(c.nombre)}</h2>
    <div class="aviso" style="margin-top:12px">Bono ${esc(pend.plan || "")} nº ${esc(pend.numero || "")}: del <b>${fechaCorta(pend.desde)}</b> al <b>${fechaCorta(pend.hasta)}</b>
      ${pend.pagado_cent ? `<br>Importe ${eur(pend.total_cent)} · ya pagado ${eur(pend.pagado_cent)}` : ""}</div>
    <div class="total" style="margin-top:14px"><div class="t">Pendiente</div><div class="v num">${eur(pend.importe_cent)}</div></div>
    ${campoParcial("cr", pend.importe_cent)}
    <div class="metodos">${botonesMetodoBono()}</div>
    ${bloqueTransferencia("cr")}
    <div id="cr-ef"><label class="campo">Entregado<input class="ent grande num" id="cr-ent" inputmode="decimal" placeholder="Cantidad recibida"></label>
      <div class="cambio" id="cr-cambio"><span>Cambio</span><span class="v num">0,00 €</span></div></div>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn ok xl" data-ok>Cobrar ${eur(pend.importe_cent)}</button></div>`, { ancho: true });
  const aCobrar = () => importeParcial("cr", pend.importe_cent);
  const cambio = () => {
    const imp = aCobrar();
    $("[data-ok]", m).textContent = Number.isNaN(imp) ? "Cobrar" : "Cobrar " + eur(imp);
    pintarCambio($("#cr-cambio"), $("#cr-ent"), imp, pend.importe_cent);
  };
  $("#cr-ent").oninput = cambio;
  montarParcial("cr", pend.importe_cent, cambio);
  $$("[data-m]", m).forEach((b) => (b.onclick = () => {
    st.metodo = b.dataset.m; $$("[data-m]", m).forEach((x) => x.classList.toggle("sel", x === b));
    $("#cr-ef").classList.toggle("oculto", st.metodo !== "efectivo");
    $("#cr-tr").classList.toggle("oculto", st.metodo !== "transferencia");
    if (st.metodo === "transferencia") $("#cr-ref").focus();
  }));
  $("[data-c]", m).onclick = () => (despues ? despues() : cerrarModal());
  $("[data-ok]", m).onclick = accion(async () => {
    let ent = null;
    const imp = aCobrar();
    if (Number.isNaN(imp) || imp <= 0 || imp > pend.importe_cent) throw new Error(`Indique un importe entre 0,01 € y ${eur(pend.importe_cent)}`);
    if (st.metodo === "efectivo") {
      ent = entregadoEfectivo($("#cr-ent").value, imp, "#cr-ent");
    }
    const dref = st.metodo === "tarjeta" ? await pasoDatafono(imp, "BONO") : null;
    const r = await api("POST", `/api/bonos/${pend.bono_id}/cobrar`, { metodo: st.metodo, entregado_cent: ent, importe_cent: imp,
      referencia: st.metodo === "transferencia" ? $("#cr-ref").value : null, datafono_ref: dref });
    notarImpresion(r.impresion);
    refrescarEstado();
    const ok = modal(`<div class="exito"><div class="icono">✓</div><h2>${r.saldo && r.saldo.pendiente_cent ? "Pago a cuenta" : "Bono cobrado"}: ${eur(r.pago.importe_cent)}</h2>
      ${r.pago.metodo === "efectivo" ? `<p class="suave" style="margin:14px 0 2px">Cambio a devolver</p><div class="grande num">${eur(r.pago.cambio_cent)}</div>` : ""}
      ${r.saldo && r.saldo.pendiente_cent ? `<div class="aviso">Queda pendiente <b>${eur(r.saldo.pendiente_cent)}</b></div>` : '<div class="aviso verde">Bono pagado por completo</div>'}
      ${r.email ? `<div class="aviso ${r.email.estado === "enviado" ? "verde" : ""}" style="margin-top:8px">${r.email.estado === "enviado" ? "Factura enviada por email a " + esc(r.email.destino) : "Factura pendiente de envío por email"}</div>` : ""}</div>
      <div class="modal-pie"><button class="btn" id="cr-ver">Ver factura</button><button class="btn prim" data-c autofocus>Aceptar</button></div>`);
    $("#cr-ver").onclick = () => verImpresion(r.impresion);
    $("[data-c]", ok).onclick = () => { recargarClientes(); despues ? despues() : cerrarModal(); };
  });
}

function modalCancelarDeuda(c, deudas) {
  if (!deudas.length) return;
  const todas = deudas.length === (c.deudas || []).length;
  const total = deudas.reduce((t, d) => t + d.pendiente_cent, 0);
  ventanaForm({ titulo: `Cancelar deuda · ${esc(c.nombre)}`, aceptar: `Cancelar ${eur(total)}`, peligro: true, ancho: true, volver: () => abrirFicha(c.id),
    cuerpo: `    <table class="tabla" style="margin-top:10px"><thead><tr><th>Bono</th><th>Periodo</th><th class="der">Pagado</th><th class="der">Se cancela</th></tr></thead><tbody>
      ${deudas.map((d) => `<tr><td class="mono" style="font-size:.85rem">${esc(d.numero_txt)}<div class="suave">${esc(d.plan_nombre)}</div></td>
        <td class="num">${fechaCorta(d.desde)} → ${fechaCorta(d.hasta)}</td><td class="der num">${eur(d.pagado_cent)}</td>
        <td class="der num"><b>${eur(d.pendiente_cent)}</b></td></tr>`).join("")}</tbody></table>
    <p class="suave" style="margin:10px 0">Total que se deja de cobrar: <b>${eur(total)}</b>. Los periodos sin ningún pago se <b>anulan</b> (ya no dan acceso);
      los pagados en parte se cierran con lo cobrado. No se emite ninguna factura y queda en auditoría.</p>
    <label class="campo">Motivo<input class="ent" id="cd-motivo" autofocus placeholder="p. ej. se ha dado de baja, acuerdo con el cliente" autocomplete="off"></label>
    ${todas && c.renovacion_auto !== 0 ? `<label class="fila" style="gap:8px;margin-top:10px;font-weight:600"><input type="checkbox" id="cd-renov" checked>
      No renovar más su bono automáticamente</label>` : ""}
`,
    onOk: async () => {
    const motivo = $("#cd-motivo").value.trim();
    if (!motivo) throw new Error("Indique el motivo");
    if (todas) await api("POST", `/api/clientes/${c.id}/cancelar-deudas`, { motivo, quitar_renovacion: !!($("#cd-renov") && $("#cd-renov").checked) });
    else for (const d of deudas) await api("POST", `/api/bonos/${d.id}/cancelar-deuda`, { motivo });
    toast(`Deuda cancelada: ${eur(total)}`, "ok");
    refrescarEstado();
    abrirFicha(c.id);
    } });
}

// ========================================== Suscripciones con tarjeta (Stripe)

const ESTADO_SUS = { activa: ["e-pagado", "Activa"], impagada: ["e-err", "Pago pendiente"], cancelada: ["e-salido", "Cancelada"],
  incompleta: ["e-aviso", "Incompleta"] };

function pintarSuscripcionFicha(c, el) {
  if (!el) return;
  const subs = (c.suscripciones || []).filter((s) => s.estado !== "cancelada");
  const sup = tieneRol("admin", "supervisor");
  if (subs.length) {
    el.innerHTML = `<h3 style="margin:22px 0 8px">Suscripción con cargo automático</h3>
      <table class="tabla"><tbody>${subs.map((s) => `<tr>
        <td><b>${esc(s.plan_nombre)}</b> · ${eur(s.precio_cent)}<div class="suave mono" style="font-size:.78rem">${esc(s.ref_suscripcion)}</div></td>
        <td><span class="etiqueta ${ESTADO_SUS[s.estado][0]}">${ESTADO_SUS[s.estado][1]}</span>
          ${s.cancelar_al_final ? '<span class="etiqueta e-aviso">Se da de baja al final del periodo</span>' : ""}</td>
        <td class="suave">${s.periodo_fin ? `${s.cancelar_al_final ? "Último cargo hecho; termina el" : "Próximo cargo en tarjeta:"} ${fechaHoraCorta(s.periodo_fin)}` : ""}</td>
        <td class="der">${sup && !s.cancelar_al_final ? `<button class="btn peligro" data-baja="${s.id}">Dar de baja…</button>` : ""}</td></tr>`).join("")}</tbody></table>`;
    $$("[data-baja]", el).forEach((b) => (b.onclick = () => modalBajaSuscripcion(Number(b.dataset.baja), c.id)));
    return;
  }
  if (!S.estado.pagos_online) { el.innerHTML = ""; return; }
  el.innerHTML = `<div class="aviso" style="margin-top:18px;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">
    <span>Puede pagar su bono con <b>cargo automático en tarjeta</b>: se renueva solo cada periodo y se le envía la factura.</span>
    <button class="btn prim" id="f-sus">Suscribir con tarjeta…</button></div>`;
  $("#f-sus", el).onclick = () => modalSuscripcion(c);
}

const modalSuscripcion = accion(async (c) => {
  const planes = (await api("GET", "/api/planes")).filter((p) => p.activo && p.precio_cent > 0);
  if (!planes.length) throw new Error("No hay tipos de bono a la venta");
  const ult = (c.bonos || []).find((b) => b.estado === "activo");
  let plan = planes.find((p) => ult && p.id === ult.plan_id) || planes[0];
  const m = modal(`<h2>Suscripción con cargo automático</h2>
    <p class="suave">${esc(c.nombre)} paga con su tarjeta en una página segura de Stripe (desde su móvil). Cada periodo se le cobra solo,
      el bono se renueva y recibe la factura por email.</p>
    <label class="campo" style="margin-top:10px">Tipo de bono<select class="ent" id="sp-plan">${planes.map((p) =>
      `<option value="${p.id}" ${p.id === plan.id ? "selected" : ""}>${esc(p.nombre)} · ${eur(p.precio_cent)} cada ${p.meses > 1 ? p.meses + " meses" : "mes"}</option>`).join("")}</select></label>
    <div id="sp-cuerpo" style="margin-top:14px"><div class="vacio">Preparando el enlace de pago…</div></div>
    <div class="modal-pie"><button class="btn prim" data-c>Cerrar</button></div>`, { ancho: true });
  $("[data-c]", m).onclick = () => { cerrarModal(); abrirFicha(c.id); };
  const cargar = accion(async () => {
    const d = await api("GET", `/api/clientes/${c.id}/suscripcion?plan_id=${$("#sp-plan").value}`);
    $("#sp-cuerpo").innerHTML = `<div class="rejilla" style="grid-template-columns:200px 1fr;align-items:center">
        <div style="background:#fff;padding:8px;border-radius:8px">${d.qr}</div>
        <div><p style="margin-top:0"><b>Escanee el código con el móvil</b> para pagar ahora, o envíele el enlace:</p>
          <div class="serial" style="font-size:.8rem">${esc(d.url)}</div>
          <div class="fila" style="margin-top:10px">
            <button class="btn" id="sp-copiar">Copiar enlace</button>
            ${d.email ? `<button class="btn" id="sp-mail">Enviar por email</button><a class="btn" target="_blank" rel="noopener" href="${urlGmail(d.email, d.asunto, d.texto)}">Enviar con Gmail</a>`
              : '<span class="suave">El cliente no tiene email: añádalo en «Editar datos» para enviárselo.</span>'}</div>
          <p class="ayuda" style="margin-top:10px">Cuando pague, en unos minutos aparecerá aquí la suscripción y el bono renovado (o pulse «Sincronizar ahora» en Ajustes → Pagos online).
            Si ahora tiene un bono en vigor, el primer pago cubre el periodo siguiente.</p></div></div>`;
    $("#sp-copiar").onclick = () => copiarTexto(d.url);
    if ($("#sp-mail")) $("#sp-mail").onclick = accion(async () => {
      const r = await api("POST", `/api/clientes/${c.id}/suscripcion/enviar`, { plan_id: Number($("#sp-plan").value) });
      toast(`Enlace enviado a ${r.email}`, "ok");
    });
  });
  $("#sp-plan").onchange = cargar;
  cargar();
});

function modalBajaSuscripcion(id, clienteId) {
  const m = modal(`<h2>Dar de baja la suscripción</h2>
    <p>Se deja de cobrar en su tarjeta. Elija cuándo:</p>
    <div class="metodos" style="margin:12px 0"><button class="btn sel" data-cuando="final">Al final del periodo pagado</button>
      <button class="btn" data-cuando="ya">Ahora mismo</button></div>
    <p class="suave">El bono que ya tiene pagado sigue valiendo hasta su fecha en los dos casos. No se hace ninguna devolución.</p>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn peligro lleno" data-ok>Dar de baja</button></div>`);
  let inmediato = false;
  $$("[data-cuando]", m).forEach((b) => (b.onclick = () => { inmediato = b.dataset.cuando === "ya"; $$("[data-cuando]", m).forEach((x) => x.classList.toggle("sel", x === b)); }));
  $("[data-c]", m).onclick = () => abrirFicha(clienteId);
  $("[data-ok]", m).onclick = accion(async () => {
    await api("POST", `/api/suscripciones/${id}/cancelar`, { inmediato });
    toast("Suscripción dada de baja", "ok"); abrirFicha(clienteId);
  });
}

// ======================================= Avisos y recordatorios a los abonados

const urlGmail = (para, asunto, texto) => "https://mail.google.com/mail/?view=cm&fs=1&to=" + encodeURIComponent(para || "") +
  "&su=" + encodeURIComponent(asunto) + "&body=" + encodeURIComponent(texto);

const contarAvisos = accion(async () => {
  const b = $("#b-avisos");
  if (!b) return;
  const a = await api("GET", "/api/avisos");
  const sin = a.pendientes.filter((x) => !x.aviso || x.aviso.estado !== "enviado").length;
  b.innerHTML = `Avisos de caducidad${sin ? ` <span class="etiqueta e-aviso">${sin}</span>` : ""}`;
});

const modalAvisos = accion(async () => {
  const [a, renov] = await Promise.all([api("GET", "/api/avisos"), api("GET", "/api/renovaciones")]);
  const pend = a.pendientes;
  const m = modal(`<h2>Avisos de caducidad de bonos</h2>
    <p class="suave">Abonados cuyo bono caduca en ${a.dias} días o menos, sin renovar ni suscripción automática.
      ${a.smtp ? (a.activos ? "Se avisan solos por email una vez al día." : "El envío automático está desactivado (Ajustes → Pagos online y avisos).")
        : "Para avisarles solos configure el «Envío automático (SMTP)» en Ajustes → Email; mientras tanto puede enviarlos con Gmail."}</p>
    ${pend.length ? `<table class="tabla" style="margin-top:10px"><tbody>${pend.map((x) => `<tr>
      <td><b>${esc(x.nombre)}</b><div class="suave" style="font-size:.82rem">${esc(x.email || "sin email")}</div></td>
      <td>${esc(x.plan || "")}<div class="suave" style="font-size:.82rem">caduca el ${fechaCorta(x.hasta)} (${x.dias} día${x.dias === 1 ? "" : "s"})</div></td>
      <td>${x.aviso ? `<span class="etiqueta ${x.aviso.estado === "enviado" ? "e-pagado" : "e-err"}">${x.aviso.estado === "enviado" ? "Avisado" : "Error"}</span>
        <div class="suave" style="font-size:.78rem">${fechaHoraCorta(x.aviso.fecha)}${x.aviso.detalle ? " · " + esc(x.aviso.detalle) : ""}</div>` : '<span class="etiqueta e-aviso">Sin avisar</span>'}</td>
      <td class="der" style="white-space:nowrap">${x.email ? `<button class="btn" data-gm="${esc(x.referencia)}">Gmail</button>` : ""}
        <button class="btn" data-ficha="${x.cliente_id}">Ficha</button></td></tr>`).join("")}</tbody></table>`
      : '<div class="vacio">No hay bonos a punto de caducar.</div>'}
    <h3 style="margin-top:20px">Renovaciones automáticas pendientes de pago</h3>
    ${renov.length ? `<table class="tabla" style="margin-top:8px"><tbody>${renov.map((x) => `<tr>
      <td><b>${esc(x.nombre)}</b><div class="suave" style="font-size:.82rem">${esc(x.email || "sin email")}</div></td>
      <td>${esc(x.plan)} · ${eur(x.importe_cent)}<div class="suave" style="font-size:.82rem">${esc(x.numero_txt)} · ${fechaCorta(x.desde)} → ${fechaCorta(x.hasta)}</div></td>
      <td>${x.aviso ? `<span class="etiqueta e-pagado">Avisado</span><div class="suave" style="font-size:.78rem">${fechaHoraCorta(x.aviso.fecha)}</div>` : '<span class="etiqueta e-aviso">Sin avisar</span>'}</td>
      <td class="der" style="white-space:nowrap">${x.email ? `${a.smtp ? `<button class="btn" data-renv="${x.id}">Enviar</button> ` : ""}<button class="btn" data-rgm="${x.id}">Gmail</button> ` : ""}
        <button class="btn" data-ficha="${x.cliente_id}">Ficha</button></td></tr>`).join("")}</tbody></table>`
      : '<div class="vacio" style="padding:14px">No hay renovaciones pendientes de pago.</div>'}
    <div class="modal-pie">${a.smtp && pend.some((x) => x.email && (!x.aviso || x.aviso.estado !== "enviado")) ? '<button class="btn prim" id="av-enviar">Enviar avisos ahora</button>' : ""}
      <button class="btn" data-c>Cerrar</button></div>`, { ancho: true });
  $("[data-c]", m).onclick = () => { cerrarModal(); contarAvisos(); };
  $$("[data-ficha]", m).forEach((b) => (b.onclick = () => abrirFicha(Number(b.dataset.ficha))));
  $$("[data-gm]", m).forEach((b) => (b.onclick = accion(async () => {
    const ventana = window.open("about:blank", "_blank");
    const t = await api("GET", "/api/avisos/mensaje?ref=" + encodeURIComponent(b.dataset.gm));
    if (ventana) ventana.location = urlGmail(t.email, t.asunto, t.texto); else window.open(urlGmail(t.email, t.asunto, t.texto), "_blank");
    await api("POST", "/api/avisos/marcar", { referencia: b.dataset.gm, medio: "gmail" });
    modalAvisos();
  })));
  $$("[data-rgm]", m).forEach((b) => (b.onclick = accion(async () => {
    const ventana = window.open("about:blank", "_blank");
    const t = await api("GET", `/api/renovaciones/${b.dataset.rgm}/mensaje`);
    if (ventana) ventana.location = urlGmail(t.email, t.asunto, t.texto); else window.open(urlGmail(t.email, t.asunto, t.texto), "_blank");
    modalAvisos();
  })));
  $$("[data-renv]", m).forEach((b) => (b.onclick = accion(async () => {
    const r = await api("POST", `/api/renovaciones/${b.dataset.renv}/enviar`);
    toast(r.estado === "enviado" ? "Aviso enviado" : `No se pudo enviar (${r.estado})`, r.estado === "enviado" ? "ok" : "err");
    modalAvisos();
  })));
  if ($("#av-enviar")) $("#av-enviar").onclick = accion(async () => {
    const r = await api("POST", "/api/avisos/enviar", {});
    toast(`${r.enviado} aviso(s) enviado(s)${r.error ? ` · ${r.error} con error` : ""}${r.sin_email ? ` · ${r.sin_email} sin email` : ""}`, r.error ? "err" : "ok");
    modalAvisos();
  });
});

async function mostrarUltimoRecordatorio(c) {
  try {
    const r = await api("GET", `/api/clientes/${c.id}/recordatorio`);
    const el = $("#f-ult-recordatorio");
    if (el && r.ultimo) el.textContent = `Último recordatorio: ${fechaHora(r.ultimo.fecha)}${r.ultimo.estado === "error" ? " (falló)" : ""}`;
  } catch (e) { /* solo informativo */ }
}

const modalRecordatorioDeuda = accion(async (c) => {
  const r = await api("GET", `/api/clientes/${c.id}/recordatorio`);
  const m = modal(`<h2>Recordar deuda por email · ${esc(c.nombre)}</h2>
    <div class="aviso rojo" style="margin-top:10px">Pendiente de pago: <b>${eur(r.total_cent)}</b>${r.ultimo ? `<br><span style="font-size:.88rem">Último recordatorio: ${fechaHora(r.ultimo.fecha)} a ${esc(r.ultimo.destino || "")}</span>` : ""}</div>
    <label class="campo" style="margin-top:12px">Para<input class="ent" id="rd-email" value="${esc(r.email)}" autocomplete="off"></label>
    <label class="campo" style="margin-top:10px">Asunto<input class="ent" id="rd-asunto" value="${esc(r.asunto)}"></label>
    <label class="campo" style="margin-top:10px">Mensaje <span class="ayuda">puede cambiarlo antes de enviarlo</span>
      <textarea class="ent" id="rd-texto" rows="12" style="font-family:inherit">${esc(r.texto)}</textarea></label>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button>
      <button class="btn" id="rd-gmail">Abrir en Gmail</button>
      ${r.smtp ? '<button class="btn prim" id="rd-enviar">Enviar ahora</button>' : '<span class="ayuda" style="align-self:center">Envío automático no configurado (Ajustes → Conexiones → Email)</span>'}</div>`, { ancho: true });
  const datos = (medio) => ({ email: $("#rd-email").value, asunto: $("#rd-asunto").value, texto: $("#rd-texto").value, medio });
  $("[data-c]", m).onclick = () => abrirFicha(c.id);
  $("#rd-gmail").onclick = accion(async () => {
    const d = datos("gmail");
    if (!d.email.trim()) throw new Error("Indique el email del cliente");
    window.open(urlGmail(d.email, d.asunto, d.texto), "_blank");
    await api("POST", `/api/clientes/${c.id}/recordatorio`, d);
    toast("Recordatorio abierto en Gmail y anotado en la ficha", "ok");
    abrirFicha(c.id);
  });
  if ($("#rd-enviar")) $("#rd-enviar").onclick = accion(async () => {
    const b = $("#rd-enviar"); b.disabled = true; b.textContent = "Enviando…";
    try {
      const res = await api("POST", `/api/clientes/${c.id}/recordatorio`, datos("smtp"));
      toast(`Recordatorio enviado a ${res.destino}`, "ok");
      abrirFicha(c.id);
    } finally { if (b.isConnected) { b.disabled = false; b.textContent = "Enviar ahora"; } }
  });
});

const modalRecordatorioMensaje = accion(async (c) => {
  const r = await api("GET", `/api/clientes/${c.id}/recordatorio-mensaje`);
  const manual = r.modo === "manual";
  const m = modal(`<h2>Recordar deuda por WhatsApp / SMS · ${esc(c.nombre)}</h2>
    <div class="aviso rojo" style="margin-top:10px">Pendiente de pago: <b>${eur(r.total_cent)}</b>${r.ultimo ? `<br><span style="font-size:.88rem">Último mensaje: ${fechaHora(r.ultimo.fecha)} a ${esc(r.ultimo.destino || "")}${r.ultimo.estado === "error" ? " (falló)" : ""}</span>` : ""}</div>
    <div class="rejilla r2" style="margin-top:12px">
      <label class="campo">Móvil<input class="ent mono" id="rm-tel" value="${esc(r.movil || r.telefono)}"></label>
      ${manual ? `<div class="campo">Canal<div style="margin-top:10px"><b>WhatsApp</b> <span class="suave">(se abre WhatsApp para enviarlo)</span></div></div>`
        : `<label class="campo">Canal<select class="ent" id="rm-canal"><option value="whatsapp" ${r.canal === "whatsapp" ? "selected" : ""}>WhatsApp</option><option value="sms" ${r.canal === "sms" ? "selected" : ""}>SMS</option></select></label>`}
    </div>
    ${r.movil ? "" : '<div class="aviso" style="margin-top:8px">El teléfono de la ficha no parece un móvil: escriba uno válido.</div>'}
    <label class="campo" style="margin-top:10px">Mensaje <span class="ayuda" id="rm-cuenta"></span>
      <textarea class="ent" id="rm-texto" rows="5" style="font-family:inherit">${esc(r.texto)}</textarea></label>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" id="rm-enviar">${manual ? "Abrir WhatsApp" : "Enviar"}</button></div>`, { ancho: true });
  const contar = () => { const n = $("#rm-texto").value.length; $("#rm-cuenta").textContent = `${n} caracteres${!manual ? ` · ${Math.max(1, Math.ceil(n / 153))} SMS aprox.` : ""}`; };
  $("#rm-texto").oninput = contar; contar();
  $("[data-c]", m).onclick = () => abrirFicha(c.id);
  $("#rm-enviar").onclick = accion(async () => {
    const ventana = manual ? window.open("about:blank", "_blank") : null;   // se abre ya para que el navegador no la bloquee
    try {
      const res = await api("POST", `/api/clientes/${c.id}/recordatorio-mensaje`, {
        telefono: $("#rm-tel").value, texto: $("#rm-texto").value, canal: manual ? "whatsapp" : $("#rm-canal").value });
      if (res.enlace) { if (ventana) ventana.location = res.enlace; else window.open(res.enlace, "_blank"); }
      toast(manual ? "WhatsApp abierto y anotado en la ficha" : `Enviado por ${res.canal === "sms" ? "SMS" : "WhatsApp"} a ${res.destino}`, "ok");
      abrirFicha(c.id);
    } catch (e) { if (ventana) ventana.close(); throw e; }
  });
});

// ================================================================= Comunicados

const modalComunicado = accion(async () => {
  const st = { filtro: "todos", medio: null };
  const d = await api("GET", "/api/comunicados?filtro=todos");
  st.medio = d.resumen.smtp ? "smtp" : "gmail";
  const m = modal(`<h2>Comunicado a los abonados</h2>
    <p class="suave" style="margin:6px 0 12px">Un mismo email para todos: cambios de horario, obras, cierres, avisos del servicio…
      <b>{nombre}</b> se cambia por el nombre de cada abonado.</p>
    <div class="rejilla r2">
      <label class="campo">Destinatarios<select class="ent" id="cm-filtro">${Object.entries(d.filtros).map(([k, n]) => `<option value="${k}">${n}</option>`).join("")}</select></label>
      <div class="campo">Enviar con<div class="fila" style="gap:6px;margin-top:4px">
        <button type="button" class="btn ${st.medio === "smtp" ? "sel" : ""}" data-medio="smtp" ${d.resumen.smtp ? "" : "disabled title='Configure el envío automático en Ajustes → Conexiones → Email'"}>Envío automático</button>
        <button type="button" class="btn ${st.medio === "gmail" ? "sel" : ""}" data-medio="gmail">Gmail (copia oculta)</button>
        ${S.estado.mensajes && S.estado.mensajes !== "no" ? `<button type="button" class="btn" data-medio="mensaje">${S.estado.mensajes === "manual" ? "WhatsApp" : "WhatsApp / SMS"}</button>` : ""}</div></div>
    </div>
    <div class="aviso" id="cm-resumen" style="margin-top:10px">…</div>
    <label class="campo" style="margin-top:10px">Asunto <span class="ayuda" id="cm-asunto-ayuda"></span><input class="ent" id="cm-asunto" maxlength="150" placeholder="p. ej. Horario especial el 12 de octubre"></label>
    <label class="campo" style="margin-top:10px">Mensaje<textarea class="ent" id="cm-texto" rows="9" style="font-family:inherit"
      placeholder="Hola {nombre}:&#10;&#10;Le informamos de que…&#10;&#10;Un saludo,&#10;${esc(S.estado.nombre_parking || "")}"></textarea></label>
    <p class="ayuda">Úselo para avisos del servicio. Para publicidad u ofertas, la ley exige el consentimiento previo de cada cliente.</p>
    <div class="modal-pie"><button class="btn" data-c>Cerrar</button><button class="btn prim" data-ok>Enviar</button></div>
    <details class="plegable" style="margin-top:16px"><summary><h3>Comunicados enviados</h3><span class="suave">${d.historial.length}</span></summary>
      ${d.historial.length ? `<table class="tabla" style="margin-top:8px"><thead><tr><th>Fecha</th><th>Asunto</th><th>Destinatarios</th><th>Resultado</th></tr></thead><tbody>
        ${d.historial.map((h) => `<tr><td class="num">${fechaHora(h.fecha)}<div class="suave" style="font-size:.8rem">${esc(h.usuario || "")}</div></td>
          <td>${esc(h.asunto)}</td><td style="font-size:.88rem">${esc(d.filtros[h.filtro] || h.filtro)}<div class="suave">${({ gmail: "Gmail", smtp: "Email automático", sms: "SMS", whatsapp: "WhatsApp", whatsapp_manual: "WhatsApp (a mano)" })[h.medio] || h.medio}</div></td>
          <td style="font-size:.88rem">${h.estado === "enviando" ? `<span class="etiqueta e-aviso">Enviando ${h.enviados + h.errores}/${h.total}</span>`
            : `<span class="etiqueta ${h.errores ? "e-err" : "e-pagado"}">${h.enviados} enviado(s)${h.errores ? ` · ${h.errores} error(es)` : ""}</span>`}
            ${h.sin_email ? `<div class="suave">${h.sin_email} sin email</div>` : ""}</td></tr>`).join("")}</tbody></table>` : '<div class="vacio">Todavía no se ha enviado ninguno.</div>'}
    </details>`, { ancho: true });
  const pintarResumen = accion(async () => {
    const r = (await api("GET", "/api/comunicados?filtro=" + st.filtro)).resumen;
    st.resumen = r;
    const msg = st.medio === "mensaje";
    const n = msg ? r.con_movil : r.con_email, sin = msg ? r.sin_movil : r.sin_email;
    const canal = msg ? (r.msg_modo === "manual" ? "el WhatsApp" : r.msg_canal === "sms" ? "el SMS" : "el WhatsApp") : "el email";
    $("#cm-asunto-ayuda").textContent = msg ? "(no se envía por WhatsApp/SMS: sirve para el historial)" : "";
    $("#cm-resumen").innerHTML = r.total ? `<b>${n}</b> de ${r.total} abonado(s) recibirán ${canal}.` +
      (sin.length ? `<br><span style="font-size:.88rem">Sin ${msg ? "móvil" : "email"} (no lo recibirán): ${sin.slice(0, 8).map(esc).join(", ")}${sin.length > 8 ? ` y ${sin.length - 8} más` : ""}</span>` : "")
      : "No hay abonados en ese grupo.";
    st.n = n;
    $("[data-ok]", m).disabled = !n;
    $("[data-ok]", m).textContent = !n ? "Enviar" : st.medio === "smtp" ? `Enviar a ${n}` : st.medio === "gmail" ? `Abrir en Gmail (${n})`
      : r.msg_modo === "manual" ? `Preparar ${n} WhatsApp` : `Enviar ${r.msg_canal === "sms" ? "SMS" : "WhatsApp"} a ${n}`;
  });
  $("#cm-filtro").onchange = (e) => { st.filtro = e.target.value; st.confirmando = false; $("[data-ok]", m).classList.remove("peligro", "lleno"); pintarResumen(); };
  $$("[data-medio]", m).forEach((b) => (b.onclick = () => {
    st.medio = b.dataset.medio; $$("[data-medio]", m).forEach((x) => x.classList.toggle("sel", x === b)); pintarResumen();
  }));
  $("[data-c]", m).onclick = cerrarModal;
  $("[data-ok]", m).onclick = accion(async () => {
    const asunto = $("#cm-asunto").value.trim(), texto = $("#cm-texto").value.trim();
    if (!asunto || !texto) throw new Error("Escriba el asunto y el mensaje");
    const n = st.n || 0;
    const boton = $("[data-ok]", m);
    if (!st.confirmando) {   // primer clic: pide confirmación en el mismo botón (sin perder lo escrito)
      st.confirmando = true;
      boton.classList.add("peligro", "lleno");
      boton.textContent = `Confirmar: enviar a ${n} abonado(s)`;
      setTimeout(() => { if (boton.isConnected && st.confirmando) { st.confirmando = false; boton.classList.remove("peligro", "lleno"); pintarResumen(); } }, 6000);
      return;
    }
    st.confirmando = false;
    if (st.medio === "gmail") {
      const nombre = S.estado.nombre_parking || "";
      const url = "https://mail.google.com/mail/?view=cm&fs=1&bcc=" + encodeURIComponent(st.resumen.emails.join(","))
        + "&su=" + encodeURIComponent(asunto.replaceAll("{parking}", nombre))
        + "&body=" + encodeURIComponent(texto.replaceAll("{nombre}", "").replaceAll("{parking}", nombre).replace(/Hola\s*:/, "Hola:"));
      window.open(url, "_blank");
    }
    const c = await api("POST", "/api/comunicados", { asunto, texto, filtro: st.filtro, medio: st.medio });
    if (st.medio === "gmail") { toast(`Comunicado abierto en Gmail para ${c.total} abonado(s)`, "ok"); return modalComunicado(); }
    if (c.enlaces) return listaWhatsappComunicado(c);
    seguirComunicado(c.id);
  });
  pintarResumen();
});

// Progreso del envío automático (se hace en segundo plano, uno a uno)
function seguirComunicado(id) {
  const m = modal(`<h2>Enviando comunicado…</h2><div class="medidor-envio"><i id="ce-barra"></i></div>
    <p class="num" id="ce-txt" style="margin-top:10px">Preparando…</p><div id="ce-fallos"></div>
    <div class="modal-pie"><button class="btn prim" data-c>Cerrar</button></div>`);
  $("[data-c]", m).onclick = cerrarModal;
  const paso = async () => {
    if (!$("#ce-txt")) return;   // ventana cerrada: el envío sigue en segundo plano
    let c;
    try { c = await api("GET", `/api/comunicados/${id}`); } catch (e) { return; }
    if (!$("#ce-txt")) return;
    const hechos = c.enviados + c.errores;
    $("#ce-barra").style.width = `${c.total ? (hechos / c.total) * 100 : 100}%`;
    $("#ce-txt").innerHTML = `${hechos} de ${c.total} · <b>${c.enviados}</b> enviado(s)${c.errores ? ` · <span style="color:var(--rojo)">${c.errores} error(es)</span>` : ""}`;
    if (c.estado === "terminado") {
      $("h2", m).textContent = c.errores ? "Comunicado enviado con errores" : "Comunicado enviado";
      if (c.fallidos.length) $("#ce-fallos").innerHTML = `<div class="aviso rojo" style="font-size:.88rem">${c.fallidos.slice(0, 10).map((f) => `${esc(f.nombre || "")} (${esc(f.destino)}): ${esc(f.detalle || "")}`).join("<br>")}</div>`;
      return;
    }
    setTimeout(paso, 800);
  };
  paso();
}

function listaWhatsappComunicado(c) {
  const m = modal(`<h2>Comunicado por WhatsApp</h2>
    <p class="suave">Pulse en cada abonado: se abre WhatsApp con su mensaje y queda marcado. ${c.sin_email ? `${c.sin_email} abonado(s) sin móvil no aparecen.` : ""}</p>
    <table class="tabla" style="margin-top:8px"><tbody>${c.enlaces.map((e) => `<tr><td><b>${esc(e.nombre)}</b> <span class="suave mono">${esc(e.movil)}</span></td>
      <td class="der"><a class="btn prim" style="text-decoration:none" href="${esc(e.enlace)}" target="_blank" rel="noopener" data-wa="${e.cliente_id}">Abrir WhatsApp</a></td></tr>`).join("")}</tbody></table>
    <p class="num" id="wa-cuenta" style="margin-top:10px">0 de ${c.enlaces.length} abiertos</p>
    <div class="modal-pie"><button class="btn prim" data-c>Terminar</button></div>`, { ancho: true });
  $("[data-c]", m).onclick = cerrarModal;
  $$("[data-wa]", m).forEach((a) => a.addEventListener("click", accion(async () => {
    const r = await api("POST", `/api/comunicados/${c.id}/whatsapp/${a.dataset.wa}`);
    a.classList.remove("ok"); a.textContent = "✓ Abierto";
    $("#wa-cuenta").textContent = `${r.enviados} de ${r.total} abiertos`;
  })));
}

// ============================================================ al cargar

S.clientes = { filtro: "todos", tipo: "todos", buscar: "" };

// Marcas de coche habituales para el campo «Marca» de los vehículos
(function () {
  const marcas = ["Seat", "Renault", "Peugeot", "Volkswagen", "Toyota", "Citroën", "Dacia", "Kia", "Hyundai", "Ford",
    "Opel", "Fiat", "Nissan", "BMW", "Mercedes-Benz", "Audi", "Skoda", "Cupra", "Mazda", "Volvo", "Tesla", "MG",
    "Honda", "Jeep", "Mini", "Suzuki", "Mitsubishi", "Lexus", "Land Rover", "Porsche", "BYD", "Smart"];
  const dl = document.createElement("datalist");
  dl.id = "marcas-comunes";
  dl.innerHTML = marcas.map((m) => `<option value="${m}">`).join("");
  document.body.appendChild(dl);
})();


// 4.60: ficha del proveedor: sus servicios con precio, sus facturas y el botón de facturar (no hay ticket, bono ni vehículos)
function fichaProveedor(c) {
  const m = modal(`
    <div class="fila" style="justify-content:space-between;align-items:flex-start">
      <div class="abonado-cab" style="margin:0"><div class="avatar">${esc(c.nombre.charAt(0).toUpperCase())}</div>
        <div><h2>${esc(c.nombre)}</h2><div class="suave">${[c.nif, c.telefono, c.email].filter(Boolean).map(esc).join(" · ") || "Sin datos de contacto"}</div>
        <div style="margin-top:6px"><span class="etiqueta e-aviso">Proveedor</span> ${c.activo ? "" : '<span class="etiqueta e-salido">Baja</span>'}</div>
        ${c.direccion ? `<div class="suave" style="font-size:.88rem;margin-top:4px">${esc(c.direccion)}</div>` : ""}</div></div>
      <button class="btn" data-c>Cerrar</button></div>
    <div class="fila" style="margin:16px 0">
      ${c.activo && c.servicios.length ? '<button class="btn prim" id="f-facturar">Nueva factura</button>' : ""}
      <button class="btn" id="f-editar">Editar datos</button></div>
    <div class="fila" style="justify-content:space-between;margin:8px 0"><h3>Servicios y precios</h3><button class="btn prim" id="f-srv-add">+ Añadir servicio</button></div>
    ${c.servicios.length ? `<table class="tabla"><thead><tr><th>Servicio</th><th class="der">Precio (IVA incl.)</th><th class="der">IVA</th><th></th></tr></thead><tbody>
      ${c.servicios.map((s) => `<tr><td>${esc(s.nombre)}</td><td class="der num">${eur(s.precio_cent)}</td><td class="der num">${s.iva_efectivo}%</td>
        <td class="der"><button class="btn mini" data-se="${s.producto_id}">Cambiar</button> <button class="btn mini peligro" data-sq="${s.producto_id}" title="Quitar servicio">✕</button></td></tr>`).join("")}</tbody></table>`
      : '<div class="aviso">Aún no tiene servicios: pulse «Añadir servicio» para indicar qué se le factura y a qué precio.</div>'}
    ${c.notas ? `<div class="aviso" style="margin-top:14px">${esc(c.notas)}</div>` : ""}
    <h3 style="margin:22px 0 8px">Facturas</h3>
    ${c.facturas && c.facturas.length ? `<div style="overflow-x:auto"><table class="tabla"><thead><tr><th>Factura</th><th>Fecha</th><th>Servicio</th><th class="der">Importe</th><th>Estado</th><th></th></tr></thead><tbody>
      ${c.facturas.map((x) => `<tr><td class="mono">${esc(x.serie)}-${String(x.numero).padStart(6, "0")}</td><td class="num">${fechaHora(x.fecha)}</td><td>${esc(x.servicio || "")}</td>
        <td class="der num">${eur(x.importe_cent)}</td>
        <td><select class="ent" data-est="${x.id}" style="width:auto;min-height:34px;padding:2px 8px" aria-label="Estado de la factura">${opcionesEstadoFactura(x.estado_factura)}</select></td>
        <td class="der"><button class="btn" data-fac="${x.id}">Abrir</button></td></tr>`).join("")}</tbody></table></div>`
      : '<div class="suave">Todavía no se le ha emitido ninguna factura.</div>'}
  `, { ancho: true });
  $("[data-c]", m).onclick = () => { cerrarModal(); recargarClientes(); };
  $("#f-editar").onclick = () => formCliente(c);
  $("#f-srv-add").onclick = () => modalServicioProveedor(c, null);
  $$("[data-se]", m).forEach((b) => (b.onclick = () => modalServicioProveedor(c, c.servicios.find((x) => String(x.producto_id) === b.dataset.se))));
  $$("[data-sq]", m).forEach((b) => (b.onclick = accion(async () => {
    const sv = c.servicios.find((x) => String(x.producto_id) === b.dataset.sq);
    if (!(await confirmar("Quitar servicio", `¿Quitar <b>${esc(sv.nombre)}</b> de ${esc(c.nombre)}? Las facturas ya emitidas no cambian.`, { boton: "Quitar", peligro: true }))) return abrirFicha(c.id);
    await api("DELETE", `/api/proveedores/${c.id}/servicios/${sv.producto_id}`);
    abrirFicha(c.id);
  })));
  if ($("#f-facturar")) $("#f-facturar").onclick = () => modalFacturaProveedor(() => abrirFicha(c.id), c.id);
  $$("[data-fac]", m).forEach((b) => (b.onclick = () => modalFactura(Number(b.dataset.fac), () => abrirFicha(c.id))));
  $$("[data-est]", m).forEach((sel) => (sel.onchange = accion(async () => {
    await api("PUT", `/api/facturas/${sel.dataset.est}/estado`, { estado: sel.value });
    toast(`Factura marcada como ${ESTADO_FACTURA[sel.value][1].toLowerCase()}`, "ok");
  })));
}


// 4.63: añadir o cambiar un servicio y su precio desde la ficha del proveedor (como se vende un bono a un abonado)
const modalServicioProveedor = accion(async (c, sv) => {
  const cat = await api("GET", "/api/proveedores").then((x) => x.catalogo || []).catch(() => []);
  const m = modal(`<h2>${sv ? "Cambiar servicio" : "Añadir servicio"} · ${esc(c.nombre)}</h2>
    <p class="ayuda" style="margin:6px 0 12px">Qué se le factura a este proveedor y a qué precio (IVA incluido). Cada proveedor puede tener su propio precio.</p>
    <div class="rejilla r2"><label class="campo" style="grid-column:1/-1">Servicio<input class="ent" id="sp-nom" list="sp-sug" maxlength="80" value="${esc(sv?.nombre || "")}" placeholder="Descarga de mercancía" autofocus></label>
      <datalist id="sp-sug">${cat.map((x) => `<option value="${esc(x.nombre)}">`).join("")}</datalist>
      <label class="campo">Precio (€)<input class="ent num" id="sp-pre" inputmode="decimal" value="${sv ? aEurTxt(sv.precio_cent) : ""}" placeholder="0,00"></label></div>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Guardar</button></div>`);
  $("#sp-nom", m).onchange = () => {   // al elegir uno del catálogo se propone su precio
    const x = cat.find((q) => q.nombre.toLowerCase() === $("#sp-nom", m).value.trim().toLowerCase());
    if (x && !$("#sp-pre", m).value) $("#sp-pre", m).value = aEurTxt(x.precio_cent);
  };
  $("[data-c]", m).onclick = () => abrirFicha(c.id);
  const guardar = accion(async () => {
    const nombre = $("#sp-nom", m).value.trim(), precio = aCent($("#sp-pre", m).value);
    if (!nombre) throw new Error("Escriba el nombre del servicio");
    if (precio === null || Number.isNaN(precio) || precio < 0) throw new Error("Indique el precio del servicio");
    await api("POST", `/api/proveedores/${c.id}/servicios`, { nombre, precio_cent: precio, anterior_id: sv ? sv.producto_id : null });
    toast("Servicio guardado", "ok");
    abrirFicha(c.id);
  });
  $("[data-ok]", m).onclick = guardar;
  m.onkeydown = (e) => { if (e.key === "Enter" && e.target.tagName === "INPUT") { e.preventDefault(); guardar(); } };
});
