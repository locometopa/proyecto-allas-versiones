/* PROYECTO ALLAS · interfaz: arranque, sesión, barra superior, menú, avisos y teclado */
"use strict";

// Color del tipo de licencia (4.10): cada plan tiene el suyo, junto a la versión y en los botones de plan
const estiloTipo = (c) => { c = c === undefined ? (S.estado || {}).licencia_color : c; return /^#[0-9a-fA-F]{6}$/.test(c || "") ? `--tc:${c}` : ""; };

// =========================================================== Arranque y sesión

async function iniciar() {
  try {
    S.estado = await api("GET", "/api/estado");
  } catch (e) {
    $("#app").innerHTML = `<div class="acceso"><div class="panel"><h2>No se puede conectar con el servidor</h2>
      <p class="suave">Compruebe que el programa del parking está en marcha.</p>
      <button class="btn prim" id="b-reintentar">Reintentar</button></div></div>`;
    $("#b-reintentar").onclick = () => location.reload();
    return;
  }
  S.usuario = S.estado.usuario;
  if (!S.usuario) S.token = null;
  aplicarTema(S.estado.tema);
  // Al arrancar (o entrar) se abre la pantalla elegida en Ajustes → General (por defecto, Entrada)
  if (S.usuario && !S.vistaFijada) { S.vista = S.estado.pantalla_inicio || "entrada"; S.vistaFijada = true; }
  render();
}

function render() {
  if (!S.token) return S.estado.primer_arranque ? vistaSetup() : vistaLogin();
  aplicarModulos();
  const visibles = VISTAS.filter(vistaVisible);
  if (!visibles.find((v) => v.id === S.vista)) S.vista = "cobrar";
  $("#app").innerHTML = `
  <div class="marco">
    <a class="saltar" href="#vista" id="saltar">Saltar al contenido</a>
    <header class="barra">
      <div class="marca"><span class="p">P</span><span>${esc(S.estado.nombre_parking)}</span></div>
      <div class="ocupacion" id="ocupacion"></div>
      <div class="esp"></div>
      <button class="luz-m360 oculto" id="luz-m360" title="Madrid 360"></button>
      <span class="chip-turno" id="chip-turno"></span>
      <details class="menu-mas menu-herr" id="menu-herr"><summary class="herr-sum" title="Pantalla del cliente, última impresión…">Herramientas <span aria-hidden="true">▾</span></summary>
        <div class="menu-mas-lista" id="herr-lista"><button class="mi" id="b-imp" title="Ver la última impresión">Última impresión</button></div></details>
      <span class="usuario">${esc(S.usuario.nombre)} · ${esc(S.usuario.rol)}</span>
      <span class="reloj num" id="reloj"></span>
      <button id="b-salir">Salir</button>
    </header>
    <nav class="menu">
      ${visibles.filter((v) => !["informes", "ajustes"].includes(v.id)).map((v) => botonMenu(v)).join("")}
      <div class="nav-apps" id="nav-apps"></div>
      <div class="nav-abajo">${visibles.filter((v) => ["informes", "ajustes"].includes(v.id)).map((v) => botonMenu(v)).join("")}
      <div class="marca-bloque">
        <button type="button" class="marca-software" id="b-acerca" title="Acerca de PROYECTO ALLAS">
          <span class="ms-nombre">${esc(S.estado.software || "PROYECTO ALLAS")}</span>
          <span class="ms-ver">Versión ${esc(S.estado.version || "")}</span>
          ${S.estado.licencia_tipo ? `<b class="tipo-lic ms-tipo" style="${estiloTipo()}">${esc(S.estado.licencia_tipo)}</b>` : ""}
          <span class="lic" id="nav-lic"></span></button>
        <button type="button" class="aviso-act" id="nav-act" hidden></button></div></div>
    </nav>
    <main><div id="aviso-lic"></div><div id="vista" tabindex="-1"></div></main>
  </div>`;
  $$("nav.menu button").forEach((b) => (b.onclick = () => ir(b.dataset.vista)));
  $("#b-salir").onclick = accion(salir);
  $("#saltar").onclick = (e) => { e.preventDefault(); $("#vista").focus(); };
  $("#b-imp").onclick = () => verImpresion();
  pintarAspectoRapido();
  montarMenu();   // Acerca de y aplicaciones externas
  pintarBarra();
  pintarVista();
}

async function refrescarEstado() {
  if (!S.token) return;
  try {
    const antes = JSON.stringify(S.estado && [S.estado.modulos, S.estado.ocultos]);
    const recargarAntes = S.estado ? S.estado.ui_recargar : undefined;
    S.estado = await api("GET", "/api/estado");
    if (recargarAntes !== undefined && S.estado.ui_recargar && S.estado.ui_recargar !== recargarAntes) return location.reload();   // «Aplicar en todos los puestos»
    if (antes !== JSON.stringify([S.estado.modulos, S.estado.ocultos])) return render();   // cambió la licencia o lo oculto
    pintarBarra();
  } catch (_) { /* reintenta */ }
}

function cerrarSesionLocal() {
  S.token = null; S.usuario = null; sessionStorage.removeItem("token"); S.vistaFijada = false;
  S.cobro = { ticket: null, metodo: "efectivo", entregado: "", resultado: null, perdido: false, abonado: null };
  S.login = { usuario: null, pin: "" };
  iniciar();
}

async function salir() {
  try { await api("POST", "/api/logout"); } catch (_) { /* da igual */ }
  cerrarSesionLocal();
}

function exigirTurnoPropio(contenedor) {
  const t = S.estado.turno;
  if (t && t.usuario_id === S.usuario.id) return true;
  contenedor.innerHTML = `<div class="panel" style="max-width:560px">
    <h2>${t ? "La caja está abierta por otro empleado" : "No tiene el turno abierto"}</h2>
    <p class="suave">${t ? `El turno ${t.id} pertenece a <b>${esc(t.usuario_nombre)}</b>. Debe cerrarse antes de operar con su usuario.`
      : "Abra su turno de caja indicando el fondo inicial para empezar a emitir tickets y cobrar. Cada cajero trabaja con su propio turno y su arqueo."}</p>
    <button class="btn prim xl" id="b-ir-caja">Ir a Caja y turno <kbd>F5</kbd></button></div>`;
  $("#b-ir-caja").onclick = () => ir("caja");
  return false;
}

// ============================================================= Primer arranque

// Primero se elige «Empezar de cero» o «Cargar copia de seguridad».
function vistaSetup(paso = "elegir") {
  const sw = esc(S.estado.software || "PROYECTO ALLAS");
  const lado = {
    elegir: `<p style="opacity:.8">Primera puesta en marcha. Puede empezar de cero o recuperar los datos de una copia de seguridad
      (por ejemplo, de otro ordenador o de una instalación anterior).</p>`,
    cero: `<p style="opacity:.8">Cree el usuario administrador y los datos fiscales que aparecerán en las facturas simplificadas.</p>
      <p style="opacity:.6;font-size:.85rem">Se creará una tarifa "General" de ejemplo (0,045 €/min, 5 min de cortesía, máx. 20 €/día) que podrá cambiar en Ajustes.</p>`,
    copia: `<p style="opacity:.8">Se recuperan todos los datos de la copia: tickets, cobros, facturas, clientes, bonos, tarifas, usuarios y ajustes.</p>
      <p style="opacity:.6;font-size:.85rem">Después entrará con los usuarios y PIN que había en la copia.</p>`,
  }[paso];
  $("#app").innerHTML = `<div class="acceso compacto"><div class="caja">
    <div class="lado"><span class="p">A</span><h1>Bienvenido a ${sw}</h1>${lado}</div>
    <div class="form" id="setup-paso"></div></div></div>`;
  const cont = $("#setup-paso");
  if (paso === "elegir") {
    cont.innerHTML = `<h2>¿Cómo quiere empezar?</h2>
      <button class="opcion-inicio" id="b-ini-cero"><b>Empezar de cero</b><span>Crear el administrador y los datos del parking</span></button>
      <button class="opcion-inicio" id="b-ini-copia"><b>Cargar copia de seguridad</b><span>Recuperar los datos de un archivo .db</span></button>
      ${S.estado.demo_disponible ? `<button class="opcion-inicio" id="b-ini-demo"><b>Probar con datos de demostración</b><span>Clientes, bonos, productos y un mes de movimientos de ejemplo. Sale cuando quiera.</span></button>` : ""}`;
    $("#b-ini-cero").onclick = () => vistaSetup("cero");
    $("#b-ini-copia").onclick = () => vistaSetup("copia");
    if ($("#b-ini-demo")) $("#b-ini-demo").onclick = () => activarDemo();
    return;
  }
  if (paso === "copia") return setupDesdeCopia(cont);
  cont.innerHTML = `<form class="form" id="f-setup" style="padding:0">
      <h2>Configuración inicial</h2>
      <div class="setup-rejilla">
        <label class="campo ancho">Nombre del parking<input class="ent" name="nombre_parking" required autocomplete="organization" value="PARKING CENTRO"></label>
        <label class="campo">Razón social<input class="ent" name="razon_social" required autocomplete="organization"></label>
        <label class="campo">NIF<input class="ent" name="nif" required autocomplete="off" spellcheck="false"></label>
        <label class="campo ancho">Dirección<input class="ent" name="direccion"></label>
        <label class="campo">Su nombre<input class="ent" name="nombre" required></label>
        <label class="campo">Usuario<input class="ent" name="usuario" required value="admin" autocomplete="off"></label>
        <label class="campo ancho">PIN (4 o más dígitos)<input class="ent" name="pin" type="password" inputmode="numeric" pattern="\\d{4,}" required></label></div>
      <button class="btn prim xl">Crear y entrar</button>
      <button type="button" class="enlace-btn" id="b-volver">← Volver</button>
    </form>`;
  $("#b-volver").onclick = () => vistaSetup();
  $("#f-setup").onsubmit = accion(async (ev) => {
    ev.preventDefault();
    const d = Object.fromEntries(new FormData(ev.target));
    const r = await api("POST", "/api/setup", d);
    S.token = r.token; sessionStorage.setItem("token", r.token);
    S.vista = "caja"; S.vistaFijada = true;
    await iniciar();
  });
}

async function setupDesdeCopia(cont) {
  let copias = [];
  try { copias = await api("GET", "/api/setup/copias"); } catch (_) { /* sin copias */ }
  const resumen = (c) => `${c.usuarios} usuario(s) · ${c.clientes} cliente(s) · ${c.tickets} ticket(s) · ${c.pagos} cobro(s)`
    + (c.ultimo_cobro ? ` · último cobro ${fechaHora(c.ultimo_cobro)}` : "");
  cont.innerHTML = `<h2>Cargar copia de seguridad</h2>
    <label class="btn prim xl" style="cursor:pointer;text-align:center">Elegir archivo .db…<input type="file" id="ini-archivo" accept=".db" hidden></label>
    <p class="ayuda" style="margin:0">Las copias se llaman <span class="mono">parking-AAAAMMDD-HHMMSS….db</span> y están en la carpeta <span class="mono">datos\\backups</span> del programa anterior, o en su pendrive.</p>
    ${copias.length ? `<div class="campo" style="margin-top:6px">O una copia que ya está en este equipo</div>
      <div class="lista-copias-ini">${copias.slice(0, 8).map((c) => `<button class="opcion-inicio mini" data-archivo="${esc(c.archivo)}">
        <b>${fechaHora(c.fecha)} · ${esc(TIPOS_COPIA[c.tipo] || c.tipo)}</b><span>${resumen(c)}</span></button>`).join("")}</div>` : ""}
    <div id="ini-confirmar"></div>
    <button type="button" class="enlace-btn" id="b-volver">← Volver</button>`;
  $("#b-volver").onclick = () => vistaSetup();
  const confirmarCopia = (c) => {
    $$("[data-archivo]", cont).forEach((b) => b.classList.toggle("sel", b.dataset.archivo === c.archivo));
    $("#ini-confirmar").innerHTML = `<div class="aviso verde" style="margin:0"><b>Copia lista para cargar</b><br>
        <span class="mono" style="font-size:.82rem">${esc(c.archivo)}</span><br>${resumen(c)}</div>
      <button class="btn prim xl" id="b-ini-restaurar" style="width:100%;margin-top:10px">Cargar esta copia y continuar</button>`;
    $("#b-ini-restaurar").onclick = accion(async () => {
      const r = await api("POST", "/api/setup/restaurar", { archivo: c.archivo });
      toast(`Datos recuperados${r.nombre_parking ? " de " + r.nombre_parking : ""}. Entre con su usuario y PIN.`, "ok");
      await iniciar();
    });
  };
  $$("[data-archivo]", cont).forEach((b) => (b.onclick = () => confirmarCopia(copias.find((c) => c.archivo === b.dataset.archivo))));
  $("#ini-archivo").onchange = accion(async (e) => {
    const f = e.target.files[0]; if (!f) return;
    const r = await fetch("/api/setup/subir", { method: "POST", headers: { "Content-Type": "application/octet-stream" }, body: f });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || "No se pudo leer la copia");
    confirmarCopia(j);
  });
}

// ============================================================== Acceso con PIN

async function vistaLogin() {
  let usuarios = [];
  try { usuarios = await api("GET", "/api/usuarios/login"); } catch (_) { /* nada */ }
  if (!S.login.usuario && usuarios.length === 1) S.login.usuario = usuarios[0].usuario;
  $("#app").innerHTML = `<div class="acceso"><div class="caja">
    <div class="lado"><span class="p">P</span><h1>${esc(S.estado.nombre_parking)}</h1>
      <div class="software-login">${esc(S.estado.software || "PROYECTO ALLAS")} · v${esc(S.estado.version || "")}${S.estado.licencia_tipo ? ` · <b class="tipo-lic" style="${estiloTipo()}">${esc(S.estado.licencia_tipo)}</b>` : ""}</div>
      <p style="opacity:.75;margin:0">Seleccione su usuario</p>
      <div class="usuarios-login">${usuarios.map((u) =>
        `<button data-u="${esc(u.usuario)}" class="${S.login.usuario === u.usuario ? "sel" : ""}">${esc(u.nombre)}</button>`).join("")}</div></div>
    <div class="form">
      <h2>Introduzca su PIN</h2>
      <p class="suave" id="l-quien" style="margin:0">${S.login.usuario ? "Usuario: " + esc(S.login.usuario) : "Elija usuario a la izquierda"}</p>
      <div class="pin-puntos" id="l-puntos"></div>
      <div class="teclado ${S.login.usuario ? "" : "sin-usuario"}">${[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => `<button data-n="${n}">${n}</button>`).join("")}
        <button data-n="borrar" title="Borrar" aria-label="Borrar">⌫</button><button data-n="0">0</button><button data-n="ok" style="background:var(--azul);color:#fff">OK</button></div>
    </div></div></div>`;
  const pintarPuntos = () => {
    const n = Math.max(4, S.login.pin.length);
    $("#l-puntos").innerHTML = Array.from({ length: n }, (_, i) => `<i class="${i < S.login.pin.length ? "on" : ""}"></i>`).join("");
  };
  pintarPuntos();
  S.login.pintar = pintarPuntos;
  $$("[data-u]").forEach((b) => (b.onclick = () => { S.login.usuario = b.dataset.u; S.login.pin = ""; vistaLogin(); }));
  $$("[data-n]").forEach((b) => (b.onclick = () => teclaPin(b.dataset.n, pintarPuntos)));
  // en la demo: los usuarios y PIN de prueba, y cómo salir
  if (!(S.estado && S.estado.demo) || $("#login-demo")) return;
  const caja = $(".acceso .caja");
  if (!caja) return;
  const div = document.createElement("div");
  div.id = "login-demo"; div.className = "login-demo";
  div.innerHTML = `<div><b>MODO DEMOSTRACIÓN</b> · usuarios de prueba:
      ${(S.estado.demo_usuarios || []).map((u) => `<span class="mono">${esc(u.usuario)}</span> PIN <span class="mono">${esc(u.pin)}</span> (${esc(u.rol)})`).join(" · ")}</div>
    <button class="btn" id="dm-salir-login">Volver a mis datos</button>`;
  caja.parentElement.insertBefore(div, caja);
  $("#dm-salir-login").onclick = salirDemo;
}

const entrar = accion(async () => {
  if (!S.login.usuario) throw new Error("Elija su usuario");
  try {
    const r = await api("POST", "/api/login", { usuario: S.login.usuario, pin: S.login.pin });
    S.token = r.token; sessionStorage.setItem("token", r.token);
    S.login.pin = "";
    await iniciar();
  } catch (e) {
    S.login.pin = "";
    vistaLogin();
    throw e;
  }
});

function teclaPin(t, pintar) {
  if (!S.login.usuario) {   // sin usuario elegido no se admite el PIN
    const q = $("#l-quien"), pp = $("#l-puntos");
    if (q) { q.textContent = "Elija primero su usuario a la izquierda"; q.classList.add("falta"); }
    if (pp) { pp.classList.remove("sacude"); void pp.offsetWidth; pp.classList.add("sacude"); }
    return;
  }
  if (t === "ok") return entrar();
  if (t === "borrar") S.login.pin = S.login.pin.slice(0, -1);
  else if (S.login.pin.length < 8) S.login.pin += t;
  pintar();
}

// ================================================================== Navegación

const botonMenu = (v) => `<button data-vista="${v.id}" class="${S.vista === v.id ? "activo" : ""}"><span>${nombreVista(v)}</span><kbd>${v.tecla}</kbd></button>`;

function ir(vista) {
  S.vista = vista;
  $$("nav.menu button").forEach((b) => b.classList.toggle("activo", b.dataset.vista === vista));
  pintarVista();
}

function pintarVista() {
  const v = $("#vista");
  if (v) ({ tienda: vistaTienda, cobrar: vistaCobrar, entrada: vistaEntrada, vehiculos: vistaVehiculos, reservas: vistaReservas, clientes: vistaClientes, caja: vistaCaja,
    informes: vistaInformes, ajustes: vistaAjustes })[S.vista](v);
  // lecturas de la cámara de matrículas: solo mientras se está en Entrada o Salida
  S.lpr.ultimo = null;
  clearInterval(S.lpr.timer);
  if (S.estado && S.estado.lpr && ["entrada", "cobrar"].includes(S.vista)) {
    sondearCamara();
    S.lpr.timer = setInterval(sondearCamara, 2000);
  }
  // pantalla de cliente en reposo fuera de Salida y Tienda
  if (!["cobrar", "tienda"].includes(S.vista)) pantallaCliente({ tipo: "libre" });
}

// ============================================================== Barra superior

// Barra superior y menú lateral: se repinta al cambiar el estado (cada 20 s o al guardar ajustes)
function pintarBarra() {
  const e = S.estado;
  aplicarTactil();
  if (e && $("#ocupacion")) pintarOcupacionYTurno(e);
  botonesBarra();
  pintarAppsMenu();
  aplicarOcultos();
  comprobarReservasNuevas();   // 1.11: aviso de reservas nuevas de clientes
}

function pintarOcupacionYTurno(e) {
  pintarLuzM360(e);
  if (e.ocupacion) {
    const { ocupadas, capacidad } = e.ocupacion;
    const pct = capacidad ? Math.min(100, (ocupadas / capacidad) * 100) : 0;
    const o = $("#ocupacion");
    o.className = "ocupacion" + (pct >= 100 ? " lleno" : pct >= 90 ? " casi" : "");
    o.innerHTML = `<div class="medidor"><i style="width:${pct}%"></i></div>
      <span class="num"><b>${ocupadas}</b> / ${capacidad} plazas${pct >= 100 ? " · COMPLETO" : ""}</span>`;
  }
  const ch = $("#chip-turno");
  if (e.turno) {
    ch.className = "chip-turno";
    ch.textContent = `Turno ${e.turno.id} · ${e.turno.usuario_nombre}`;
  } else {
    ch.className = "chip-turno off";
    ch.textContent = "Caja cerrada";
  }
  pintarLicencia();
  // ocupación por zonas y plazas de abonados al pasar el ratón
  const o = $("#ocupacion"), oc = e.ocupacion;
  if (!oc) return;
  const partes = (oc.zonas || []).map((z) => `${z.nombre}: ${z.ocupadas}${z.capacidad ? " de " + z.capacidad : ""}`);
  if (oc.plazas_abonados) partes.push(`Rotación: ${oc.rotacion} (reservadas para abonados: ${oc.plazas_abonados})`);
  o.title = partes.join("\n");
}

// Botones opcionales de la barra: pantalla del cliente, campana de avisos y barrera
function botonesBarra() {
  const barra = $(".barra");
  if (!barra) return;
  const conMonitor = S.estado && S.estado.pantalla_cliente && S.estado.pantalla_cliente_modo !== "visor";
  let b = $("#b-pantalla-cliente");
  if (conMonitor && !b) {
    b = document.createElement("button");
    b.id = "b-pantalla-cliente"; b.className = "mi"; b.title = "Abrir la pantalla del cliente (segundo monitor)"; b.textContent = "🖥 Pantalla del cliente";
    b.onclick = abrirPantallaCliente;
    $("#b-imp").before(b);
  } else if (b && !conMonitor) b.remove();
  const campana = S.estado && S.estado.recordatorios;
  b = $("#b-campana");
  if (campana && !b) {
    b = document.createElement("button");
    b.id = "b-campana"; b.className = "campana";
    b.onclick = () => panelRecordatorios();
    $("#chip-turno").before(b);
    pintarCampana();
    cargarRecordatorios(true);
  } else if (!campana && b) b.remove();
  b = $("#b-barrera");
  if (S.estado && S.estado.barrera && !b) {
    b = document.createElement("button");
    b.id = "b-barrera"; b.title = "Abrir la barrera"; b.textContent = "🚧"; b.className = "campana";
    b.onclick = abrirBarraManual;
    $("#chip-turno").before(b);
  } else if (b && !(S.estado && S.estado.barrera)) b.remove();
}

function pintarLuzM360(e) {
  const b = $("#luz-m360");
  if (!b) return;
  const l = e && e.m360_luz;
  b.classList.toggle("oculto", !l);
  if (!l) return;
  b.className = `luz-m360 ${l.color}`;
  b.innerHTML = `<i></i>Madrid 360`;
  b.title = l.texto + (l.pendientes && l.pendientes.length ? `\nDías: ${l.pendientes.map((d) => fechaCorta(d)).join(", ")}` : "") +
    (tieneRol("admin") ? "\n(pulse para abrir los listados)" : "");
  b.onclick = () => {
    if (tieneRol("admin")) irAjustes("integraciones");
    else toast(l.texto, l.color === "verde" ? "ok" : "err");
  };
}

// ===================================================== Licencia y demostración

// 4.34: el aviso de prueba/caducidad solo sale al final del periodo (prueba ≤ 3 días, licencia ≤ 15) y, si se cierra, no vuelve hasta el día siguiente.
// Durante el resto de la prueba basta la línea «Prueba: N días» del menú lateral.
const AVISO_PRUEBA_DIAS = 3;
const hoyClave = () => new Date().toISOString().slice(0, 10);
function licOcultaHoy() { try { return localStorage.getItem("licOcultaDia") === hoyClave(); } catch (e) { return !!S.licOcultaDia; } }
function ocultarLicHoy() { S.licOcultaDia = true; try { localStorage.setItem("licOcultaDia", hoyClave()); } catch (e) { /* sin almacenamiento */ } }

// 1.9.3: aviso en el menú cuando hay una versión nueva (solo administradores; lo deja la búsqueda automática de actualizaciones)
function pintarAvisoActualizacion() {
  const b = $("#nav-act"), v = S.estado && S.estado.actualizacion_nueva;
  if (!b) return;
  b.hidden = !v;
  if (!v) return;
  b.innerHTML = `<span aria-hidden="true">↑</span> Nueva versión ${esc(v)}`;
  b.title = "Hay una actualización disponible: ver las novedades";
  b.onclick = () => { S.ajustesTab = "actualizaciones"; ir("ajustes"); };
}

// Estado de la licencia: línea en el menú y aviso arriba si queda poca prueba o no se puede operar
function pintarLicencia() {
  pintarAvisoActualizacion();
  if (S.estado && S.estado.demo) return pintarAvisoDemo();
  const l = S.estado && S.estado.licencia, nav = $("#nav-lic"), av = $("#aviso-lic");
  if (!l || !nav || !av) return;
  const ok = l.puede_operar;
  nav.className = "lic " + (!ok ? "mal" : l.estado === "prueba" ? "prueba" : "");
  nav.textContent = l.estado === "activa" ? `Licencia: ${l.titular || ""}` : l.estado === "prueba" ? `Prueba: ${l.dias_restantes} días`
    : "Sin licencia válida";
  const avisar = !ok || (l.estado === "prueba" && l.dias_restantes <= AVISO_PRUEBA_DIAS) || (l.estado === "activa" && l.dias_restantes != null && l.dias_restantes <= 15)
    || l.estado_comprobacion === "pendiente";   // Toca comprobar la licencia
  // El aviso se puede cerrar y no vuelve hasta mañana. Si el programa ya no puede operar, no se puede cerrar.
  const oculto = ok && licOcultaHoy();
  av.innerHTML = avisar && !oculto ? `<div class="aviso-licencia ${ok ? "" : "rojo"} ${l.estado === "prueba" ? "prueba" : ""}"><span>${esc(l.mensaje)}${ok ? "" : " Los vehículos que ya están dentro pueden pagar y salir."}</span>
    <span class="fila" style="gap:8px;flex-wrap:nowrap">${tieneRol("admin") ? '<button class="btn" id="b-ir-lic">Licencia…</button>' : ""}
    ${ok ? '<button class="cerrar-aviso" id="b-cerrar-lic" title="Ocultar hasta mañana" aria-label="Cerrar aviso">✕</button>' : ""}</span></div>` : "";
  if ($("#b-ir-lic")) $("#b-ir-lic").onclick = () => { S.ajustesTab = "licencia"; ir("ajustes"); };
  if ($("#b-cerrar-lic")) $("#b-cerrar-lic").onclick = () => {
    ocultarLicHoy();
    pintarLicencia();
  };
}

// Aviso fijo arriba mientras se está en la demo (sustituye al de la licencia), con los días que le quedan
function pintarAvisoDemo() {
  const nav = $("#nav-lic"), av = $("#aviso-lic");
  if (nav) { nav.className = "lic prueba"; nav.textContent = "Demostración"; }
  if (av && !$(".aviso-demo", av)) {
    av.innerHTML = `<div class="aviso-demo"><span><b>MODO DEMOSTRACIÓN</b> · datos de ejemplo, sin validez. Sus datos reales no se tocan.</span>
      <span class="fila" style="gap:8px;flex-wrap:nowrap">${tieneRol("admin") ? '<button class="btn" id="dm-regenerar">Empezar de cero</button>' : ""}
      <button class="btn" id="dm-salir">Volver a mis datos</button></span></div>`;
    $("#dm-salir", av).onclick = salirDemo;
    if ($("#dm-regenerar", av)) $("#dm-regenerar", av).onclick = regenerarDemo;
  }
  const lic = S.estado.licencia, texto = $("#aviso-lic .aviso-demo span");
  if (!lic || !texto || $("#dm-dias")) return;
  const extra = document.createElement("span");
  extra.id = "dm-dias";
  extra.textContent = !lic.puede_operar ? " · CADUCADA (igual que su licencia)"
    : lic.dias_restantes != null ? ` · quedan ${lic.dias_restantes} día(s)` : "";
  texto.appendChild(extra);
}

// Espera a que el servidor vuelva a arrancar en el modo pedido y recarga la página
function esperarModoDemo(demo, titulo) {
  modal(`<div class="exito"><div class="icono">↻</div><h2>${esc(titulo)}</h2>
    <p class="suave" id="dm-txt">${demo ? "Preparando los datos de ejemplo y reiniciando el programa (unos segundos)…" : "Volviendo a sus datos y reiniciando el programa…"}</p></div>`);
  let intentos = 0;
  const t = setInterval(async () => {
    intentos++;
    try {
      const e = await (await fetch("/api/estado", { cache: "no-store" })).json();
      if (!!e.demo === demo) { clearInterval(t); sessionStorage.removeItem("token"); location.reload(); }
    } catch (_) { /* reiniciando */ }
    if (intentos === 45 && $("#dm-txt")) $("#dm-txt").textContent = "Está tardando más de lo normal. Si no vuelve, abra de nuevo el acceso directo PROYECTO ALLAS.";
  }, 1000);
}

// Cuánto se añade en la demostración: ventana con las cantidades (y el PIN de administrador si hay datos reales)
const DEMO_TAMANOS = { pequena: [8, 5, 3, 7], normal: [15, 12, 5, 28], grande: [100, 60, 50, 28] };
function pedirDatosDemo({ pin, regenerar }) {
  return new Promise((ok) => {
    const campo = (id, texto, v, max, min = 0) => `<label class="campo">${texto}<input class="ent" id="${id}" type="number" inputmode="numeric" min="${min}" max="${max}" value="${v}"></label>`;
    const m = modal(`<h2>${regenerar ? "Empezar la demo de cero" : "Activar la demostración"}</h2>
      <p>El programa se reiniciará con una <b>cuenta de demostración</b>. Elija cuántos datos de ejemplo quiere:</p>
      <div class="fila" style="gap:8px;flex-wrap:wrap;margin-bottom:8px">
        <button class="btn peq" data-t="pequena">Pequeña</button><button class="btn peq" data-t="normal">Normal</button><button class="btn peq" data-t="grande">Grande</button></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        ${campo("dm-n-cli", "Clientes", 15, 500, 1)}${campo("dm-n-bon", "Bonos vendidos", 12, 500)}
        ${campo("dm-n-den", "Vehículos dentro ahora", 5, 120)}${campo("dm-n-dia", "Días de historial", 28, 90, 5)}</div>
      <p class="suave" style="margin:6px 0 0">Los bonos no pueden superar a los clientes. Además hay productos, descuentos y movimientos de ejemplo.</p>
      ${regenerar ? '<div class="aviso">Se borran los cambios hechos en la demostración. Sus datos reales no se tocan.</div>'
        : '<div class="aviso verde">Sus datos reales <b>no se tocan</b>: la demo se guarda aparte. Para volver, pulse <b>Volver a mis datos</b> en el aviso de arriba.</div>'}
      ${pin ? '<label class="campo" style="margin-top:12px">Confirme con su PIN de administrador<input class="ent" id="dm-pin" type="password" inputmode="numeric" autocomplete="off"></label>' : ""}
      <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>${regenerar ? "Crear de nuevo" : "Activar la demostración"}</button></div>`);
    const val = (id) => $(id, m).value;
    m.querySelectorAll("[data-t]").forEach((b) => b.onclick = () => {
      const [c, bo, d, di] = DEMO_TAMANOS[b.dataset.t];
      $("#dm-n-cli", m).value = c; $("#dm-n-bon", m).value = bo; $("#dm-n-den", m).value = d; $("#dm-n-dia", m).value = di;
    });
    $("[data-c]", m).onclick = () => { cerrarModal(); ok(null); };
    const seguir = () => {
      const o = { clientes: +val("#dm-n-cli"), bonos: +val("#dm-n-bon"), dentro: +val("#dm-n-den"), dias: +val("#dm-n-dia") };
      if (!(o.clientes >= 1)) return toast("Ponga al menos 1 cliente", "error");
      o.bonos = Math.min(o.bonos || 0, o.clientes); o.dentro = o.dentro || 0; o.dias = o.dias || 28;
      const p = pin ? val("#dm-pin") : null;
      cerrarModal(); ok({ opciones: o, pin: p || (pin ? "" : null) });
    };
    $("[data-ok]", m).onclick = seguir;
    m.querySelectorAll("input").forEach((i) => i.onkeydown = (e) => { if (e.key === "Enter") seguir(); });
  });
}

const activarDemo = accion(async (regenerar = false) => {
  const conDatos = !S.estado.primer_arranque && !S.estado.demo;
  const r = await pedirDatosDemo({ pin: conDatos, regenerar });
  if (!r) return;
  modal(`<div class="exito"><div class="icono">↻</div><h2>Preparando la demostración…</h2><p class="suave">Creando los datos de ejemplo (unos segundos).</p></div>`);
  try {
    await api("POST", "/api/demo/activar", { pin: r.pin, regenerar, opciones: r.opciones });
  } catch (e) { cerrarModal(); throw e; }
  esperarModoDemo(true, regenerar ? "Creando de nuevo la demostración…" : "Activando la demostración…");
});

const salirDemo = accion(async () => {
  await api("POST", "/api/demo/salir", {});
  esperarModoDemo(false, "Saliendo de la demostración…");
});

const regenerarDemo = () => activarDemo(true);

// ============================================ Avisos y recordatorios (campana)

// Icono de línea (como el resto de la interfaz) en lugar del emoji
const ICONO_CAMPANA = '<svg class="ico-campana" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" '
  + 'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>';

async function cargarRecordatorios(avisarNuevos) {
  if (!S.token || !S.estado || !S.estado.recordatorios) return;
  try {
    const r = await api("GET", "/api/recordatorios");
    S.recordatorios.datos = r;
    S.recordatorios.total = r.total;
    pintarCampana();
    if (avisarNuevos) {
      const nuevos = r.pendientes.filter((x) => !S.recordatorios.vistos.has(x.id));
      if (nuevos.length && S.recordatorios.iniciado) toast(`Aviso: ${nuevos.length === 1 ? nuevos[0].titulo : nuevos.length + " recordatorios nuevos"}`, "ok");
      r.pendientes.forEach((x) => S.recordatorios.vistos.add(x.id));
      S.recordatorios.iniciado = true;
    }
  } catch (_) { /* sin conexión: se reintenta */ }
}

function pintarCampana() {
  const b = $("#b-campana");
  if (!b) return;
  const n = S.recordatorios.total || 0;
  b.innerHTML = `${ICONO_CAMPANA}${n ? `<span class="globo">${n > 99 ? "99+" : n}</span>` : ""}`;
  b.title = n ? `${n} aviso(s) o recordatorio(s)` : "Avisos y recordatorios";
  b.classList.toggle("con-avisos", !!n);
}

const NIVEL_AVISO = { rojo: "rojo", aviso: "" };

function paraTexto(para, usuarios) {
  if (!para || para === "todos") return "Todos";
  if (para.startsWith("rol:")) return { admin: "Administradores", supervisor: "Supervisores", cajero: "Cajeros" }[para.slice(4)] || para;
  const u = (usuarios || []).find((x) => "usuario:" + x.id === para);
  return u ? u.nombre : "Un usuario";
}

const panelRecordatorios = accion(async (pestana = "pendientes") => {
  const [r, todos] = await Promise.all([api("GET", "/api/recordatorios"), api("GET", "/api/recordatorios/todos")]);
  S.recordatorios.total = r.total; pintarCampana();
  const ahora = new Date();
  const proximos = todos.recordatorios.filter((x) => !x.hecho && new Date(x.fecha) > ahora);
  const hechos = todos.recordatorios.filter((x) => x.hecho);
  const leidos = todos.recordatorios.filter((x) => !x.hecho && new Date(x.fecha) <= ahora && x.leido);
  const tarjeta = (x, tipo) => `<div class="recordatorio ${tipo}">
      <div class="r-cab"><b>${esc(x.titulo)}</b><span class="suave">${fechaHora(x.fecha)} · para ${esc(paraTexto(x.para, todos.usuarios))}${x.creado_por_nombre ? " · de " + esc(x.creado_por_nombre) : ""}</span></div>
      ${x.texto ? `<div class="r-texto">${esc(x.texto)}</div>` : ""}
      ${x.hecho ? `<div class="suave" style="font-size:.82rem">Hecho ${fechaHora(x.hecho)}${x.hecho_por_nombre ? " por " + esc(x.hecho_por_nombre) : ""}</div>` : ""}
      <div class="fila r-acc">
        ${tipo === "pendiente" ? `<button class="btn mini" data-leido="${x.id}">Visto</button><button class="btn mini ok" data-hecho="${x.id}">✓ Hecho</button>` : ""}
        ${tipo === "leido" ? `<button class="btn mini ok" data-hecho="${x.id}">✓ Hecho</button>` : ""}
        ${tipo === "hecho" ? `<button class="btn mini" data-reabrir="${x.id}">Volver a abrir</button>` : ""}
        ${tipo !== "hecho" && (x.creado_por === S.usuario.id || tieneRol("admin", "supervisor")) ? `<button class="btn mini" data-editar="${x.id}">Editar</button>` : ""}
        ${x.creado_por === S.usuario.id || tieneRol("admin", "supervisor") ? `<button class="btn mini peligro" data-borrar="${x.id}">Borrar</button>` : ""}</div></div>`;
  const tabs = [["pendientes", `Ahora (${r.total})`], ["proximos", `Programados (${proximos.length})`], ["vistos", `Vistos (${leidos.length})`], ["hechos", `Hechos (${hechos.length})`]];
  const contenido = {
    pendientes: (r.sistema.length ? `<h3 class="r-titulo">Avisos del programa</h3>${r.sistema.map((a) => `<div class="recordatorio sistema ${NIVEL_AVISO[a.nivel] || ""}">
          <div class="r-cab"><b>${esc(a.titulo)}</b></div><div class="r-texto">${esc(a.texto || "")}</div>
          ${a.ir && tieneRol("admin", "supervisor") ? `<div class="fila r-acc"><button class="btn mini" data-ir="${esc(a.ir)}">Ver</button></div>` : ""}</div>`).join("")}` : "")
      + (r.pendientes.length ? `<h3 class="r-titulo">Recordatorios y mensajes</h3>${r.pendientes.map((x) => tarjeta(x, "pendiente")).join("")}` : "")
      + (!r.total ? `<div class="vacio">No hay nada pendiente. 👍</div>` : ""),
    proximos: proximos.length ? proximos.map((x) => tarjeta(x, "proximo")).join("") : `<div class="vacio">No hay recordatorios programados.</div>`,
    vistos: leidos.length ? leidos.map((x) => tarjeta(x, "leido")).join("") : `<div class="vacio">Nada por aquí.</div>`,
    hechos: hechos.length ? hechos.map((x) => tarjeta(x, "hecho")).join("") : `<div class="vacio">Aún no se ha marcado nada como hecho (se guardan 60 días).</div>`,
  };
  const m = modal(`<div class="fila" style="justify-content:space-between"><h2 class="titulo-icono">${ICONO_CAMPANA}Avisos y recordatorios</h2>
      <span class="fila" style="gap:8px"><button class="btn prim" id="r-nuevo">+ Nuevo recordatorio</button><button class="btn" data-c>Cerrar</button></span></div>
    <div class="pestanas" style="margin:12px 0">${tabs.map(([id, n]) => `<button data-rt="${id}" class="${pestana === id ? "activo" : ""}">${n}</button>`).join("")}</div>
    <div class="lista-recordatorios">${contenido[pestana]}</div>`, { ancho: true });
  const volver = () => panelRecordatorios(pestana);
  $("[data-c]", m).onclick = cerrarModal;
  $("#r-nuevo", m).onclick = () => modalRecordatorio(null, todos.usuarios, volver);
  $$("[data-rt]", m).forEach((b) => (b.onclick = () => panelRecordatorios(b.dataset.rt)));
  $$("[data-leido]", m).forEach((b) => (b.onclick = accion(async () => { await api("POST", `/api/recordatorios/${b.dataset.leido}/leido`); volver(); })));
  $$("[data-hecho]", m).forEach((b) => (b.onclick = accion(async () => { await api("POST", `/api/recordatorios/${b.dataset.hecho}/hecho`, { hecho: true }); toast("Marcado como hecho", "ok"); volver(); })));
  $$("[data-reabrir]", m).forEach((b) => (b.onclick = accion(async () => { await api("POST", `/api/recordatorios/${b.dataset.reabrir}/hecho`, { hecho: false }); volver(); })));
  $$("[data-borrar]", m).forEach((b) => (b.onclick = accion(async () => {
    if (!(await confirmar("Borrar recordatorio", "Se borra para todos.", { boton: "Borrar", peligro: true }))) return volver();
    await api("DELETE", `/api/recordatorios/${b.dataset.borrar}`); volver();
  })));
  $$("[data-editar]", m).forEach((b) => (b.onclick = () => modalRecordatorio(todos.recordatorios.find((x) => x.id === Number(b.dataset.editar)), todos.usuarios, volver)));
  $$("[data-ir]", m).forEach((b) => (b.onclick = () => { cerrarModal(); b.dataset.ir === "abonados" ? ir("clientes") : irAjustes(b.dataset.ir); }));
});

function modalRecordatorio(x, usuarios, despues) {
  const sup = tieneRol("admin", "supervisor");
  const yo = "usuario:" + S.usuario.id;
  const para = x ? x.para : sup ? "todos" : yo;
  const opciones = sup ? [["todos", "Todos"], ["rol:cajero", "Cajeros"], ["rol:supervisor", "Supervisores"], ["rol:admin", "Administradores"],
    ...usuarios.map((u) => ["usuario:" + u.id, u.nombre + (u.id === S.usuario.id ? " (yo)" : "")])] : [[yo, "Solo para mí"]];
  const m = modal(`<h2>${x ? "Editar recordatorio" : "Nuevo recordatorio"}</h2>
    <form id="f-rec" class="rejilla" style="margin-top:12px">
      <label class="campo">Título<input class="ent" name="titulo" maxlength="120" required autofocus value="${esc(x ? x.titulo : "")}" placeholder="Revisar la barrera de salida"></label>
      <label class="campo">Mensaje <span class="ayuda">(opcional)</span><textarea class="ent" name="texto" rows="3" maxlength="2000">${esc(x && x.texto || "")}</textarea></label>
      <div class="rejilla r2">
        <label class="campo">Mostrar a partir de<input class="ent" type="datetime-local" name="fecha" value="${aLocalInput(x ? x.fecha : new Date())}"></label>
        <label class="campo">Para<select class="ent" name="para">${opciones.map(([v, n]) => `<option value="${v}" ${v === para ? "selected" : ""}>${esc(n)}</option>`).join("")}</select></label>
      </div>
      <div class="fila" style="gap:6px"><span class="suave">Rápido:</span>
        <button type="button" class="btn mini" data-mas="0">Ahora</button><button type="button" class="btn mini" data-mas="60">En 1 hora</button>
        <button type="button" class="btn mini" data-manana="1">Mañana 9:00</button><button type="button" class="btn mini" data-manana="7">En una semana</button></div>
    </form>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>${x ? "Guardar" : "Crear"}</button></div>`);
  const f = $("#f-rec", m);
  $$("[data-mas]", m).forEach((b) => (b.onclick = () => { f.fecha.value = aLocalInput(new Date(Date.now() + Number(b.dataset.mas) * 60000).toISOString()); }));
  $$("[data-manana]", m).forEach((b) => (b.onclick = () => { const d = new Date(); d.setDate(d.getDate() + Number(b.dataset.manana)); d.setHours(9, 0, 0, 0); f.fecha.value = aLocalInput(d.toISOString()); }));
  $("[data-c]", m).onclick = despues;
  const guardar = accion(async () => {
    if (!f.titulo.value.trim()) throw new Error("Escriba el título");
    const d = { titulo: f.titulo.value, texto: f.texto.value, fecha: f.fecha.value, para: f.para.value };
    await api(x ? "PUT" : "POST", x ? `/api/recordatorios/${x.id}` : "/api/recordatorios", d);
    toast(x ? "Recordatorio guardado" : "Recordatorio creado", "ok");
    await cargarRecordatorios(false);
    despues();
  });
  $("[data-ok]", m).onclick = guardar;
  f.onsubmit = (e) => { e.preventDefault(); guardar(); };
}

// =========================== Menú lateral: aplicaciones externas y «Acerca de»

function montarMenu() {
  const b = $("#b-acerca");
  if (b) {
    b.onclick = () => modalAcercaDe();
  }
  pintarAppsMenu();
}

function appsPlegadas() { try { return localStorage.getItem("allas_apps_plegadas") === "1"; } catch (_) { return false; } }

function pintarAppsMenu() {
  const caja = $("#nav-apps");
  if (!caja) return;
  const apps = (S.estado && S.estado.apps_externas) || [];
  const firma = JSON.stringify(apps) + appsPlegadas();
  if (caja.dataset.firma === firma) return;
  caja.dataset.firma = firma;
  if (!apps.length) { caja.innerHTML = ""; caja.classList.add("oculto"); return; }
  caja.classList.remove("oculto");
  const plegada = appsPlegadas();
  caja.innerHTML = `<button type="button" class="nav-apps-cab" aria-expanded="${plegada ? "false" : "true"}" title="Mostrar u ocultar">Aplicaciones externas <span aria-hidden="true">${plegada ? "▸" : "▾"}</span></button>
    ${plegada ? "" : apps.map((a) => `<button type="button" class="app-ext" data-app="${a.id}" title="${a.tipo === "web" ? esc(a.url || "") : "Programa del PC principal"}">
      <i class="app-ico" style="${a.color ? `background:${esc(a.color)};color:#fff` : ""}">${esc(a.icono || a.nombre.slice(0, 1).toUpperCase())}</i>
      <span class="app-nom">${esc(a.nombre)}</span><span class="app-tipo">${a.tipo === "web" ? "↗" : "⧉"}</span></button>`).join("")}`;
  const cab = $(".nav-apps-cab", caja);
  cab.onclick = () => { try { localStorage.setItem("allas_apps_plegadas", appsPlegadas() ? "0" : "1"); } catch (_) { /* sin almacenamiento */ } pintarAppsMenu(); };
  $$("[data-app]", caja).forEach((x) => (x.onclick = (ev) => { ev.stopPropagation(); abrirAppExterna(apps.find((a) => String(a.id) === x.dataset.app)); }));
}

const abrirAppExterna = accion(async (a) => {
  if (!a) return;
  if (a.tipo === "web") {
    const w = window.open(a.url, "_blank", "noopener");
    if (!w) toast("El navegador ha bloqueado la ventana: permita las ventanas emergentes para este programa", "err");
    return;
  }
  toast(`Abriendo «${a.nombre}»…`);
  await api("POST", `/api/apps/${a.id}/abrir`);
  toast(`«${a.nombre}» abierto en el ordenador principal`, "ok");
});

const modalAcercaDe = accion(async () => {
  const a = await api("GET", "/api/acerca");
  const f = a.fabricante || {}, l = a.licencia || {};
  const web = f.web || "";
  const lineaContacto = [f.direccion, f.telefono ? `Tel. ${f.telefono}` : ""].filter(Boolean).map(esc).join(" · ");
  const estadoLic = { activa: ["e-pagado", "Activa"], prueba: ["e-aviso", "Prueba"], demo: ["e-aviso", "Demostración"] }[l.estado] || ["e-err", l.estado || "—"];
  const fila = (k, v) => (v ? `<dt>${k}</dt><dd>${v}</dd>` : "");
  const m = modal(`<div class="acerca">
    <div class="acerca-cab">
      ${f.logo ? `<img class="acerca-logo" src="${f.logo}" alt="${esc(f.nombre || "")}">` : '<span class="acerca-p">P</span>'}
      <div><div class="acerca-nombre">${esc(a.software)}</div>
        <div class="suave">Versión ${esc(a.version)} · ${fechaCorta2(a.fecha_version)}</div></div></div>
    <p class="acerca-copy">${esc((f.copyright || `© ${new Date().getFullYear()} ${f.nombre || a.software}`).replace(/\.?$/, "."))} ${esc(f.derechos || "Todos los derechos reservados.")}</p>
    <div class="acerca-bloques">
      <div class="panel acerca-bloque"><h3>Creador del software</h3>
        <div style="font-weight:700">${esc(f.nombre || a.software)}</div>
        ${f.nif ? `<div class="suave">NIF ${esc(f.nif)}</div>` : ""}
        ${lineaContacto ? `<div class="suave">${lineaContacto}</div>` : ""}
        ${f.email ? `<div><a href="mailto:${esc(f.email)}">${esc(f.email)}</a></div>` : ""}
        ${web ? `<div><a href="${esc(web)}" target="_blank" rel="noopener" class="acerca-web">${esc(web.replace(/^https?:\/\//, "").replace(/\/$/, ""))} ↗</a></div>` : ""}
        ${f.origen === "predeterminado" ? '<div class="ayuda" style="margin-top:6px">Su distribuidor aún no ha enviado sus datos de contacto.</div>' : ""}</div>
      <div class="panel acerca-bloque"><div class="fila" style="justify-content:space-between"><h3>Licencia</h3><span class="etiqueta ${estadoLic[0]}">${esc(estadoLic[1])}</span></div>
        <dl class="datos-ticket acerca-dl">
          ${fila("Titular", esc(l.titular || ""))}${fila("Nº de licencia", l.numero ? esc(String(l.numero)) : "")}
          ${fila("Tipo", esc({ perpetua: "Perpetua", suscripcion: "Suscripción", prueba: "Prueba ampliada" }[l.tipo] || l.tipo || ""))}
          ${fila("Plan", esc(l.plan_nombre || ""))}
          ${fila("Válida hasta", l.caduca ? fechaCorta2(l.caduca) : (l.numero ? "Sin caducidad" : ""))}
          ${fila("Actualizaciones hasta", l.actualizaciones_hasta ? fechaCorta2(l.actualizaciones_hasta) : (l.numero ? "Todas" : ""))}
          ${fila("Puestos", l.puestos ? esc(String(l.puestos)) : "")}
          ${fila("Última comprobación", l.ultima_comprobacion ? fechaCorta2(l.ultima_comprobacion) : "")}
          ${fila("ID de este equipo", l.id_equipo ? `<span class="mono">${esc(l.id_equipo)}</span>` : "")}
          ${fila("Instalado en", esc(a.parking || ""))}</dl>
        ${l.estado !== "activa" && l.mensaje ? `<div class="suave" style="font-size:.88rem;margin-top:6px">${esc(l.mensaje)}</div>` : ""}
        ${l.modulos && l.modulos.length ? `<details style="margin-top:8px"><summary class="suave">Módulos incluidos (${l.modulos.length})</summary>
          <div class="acerca-mods">${l.modulos.map((x) => `<span class="etiqueta e-pagado">${esc(x)}</span>`).join(" ")}</div></details>` : ""}</div></div>
    ${f.texto ? `<p class="suave acerca-texto">${esc(f.texto)}</p>` : ""}
    <div class="modal-pie">${tieneRol("admin") ? `<button class="btn" id="ac-act">Actualizaciones</button><button class="btn" id="ac-lic">Licencia…</button>` : ""}<span style="flex:1"></span><button class="btn prim" data-c>Cerrar</button></div></div>`, { ancho: true });
  $("[data-c]", m).onclick = cerrarModal;
  if ($("#ac-lic", m)) $("#ac-lic", m).onclick = () => { cerrarModal(); irAjustes("licencia"); };
  if ($("#ac-act", m)) $("#ac-act", m).onclick = () => { cerrarModal(); irAjustes("actualizaciones"); };
});

// ====================================== Aspecto: tema, color y pantalla táctil

// Tema claro / oscuro / automático (según el sistema)
// 4.40: cada puesto puede fijar su tema y su densidad desde «Herramientas» (se guarda en este equipo, sin tocar Ajustes)
const prefLocal = (k) => { try { return localStorage.getItem(k) || ""; } catch (_) { return ""; } };
const guardarPrefLocal = (k, v) => { try { v ? localStorage.setItem(k, v) : localStorage.removeItem(k); } catch (_) { /* sin almacenamiento */ } };

function aplicarDensidad(diseno) {
  const d = diseno || (S.estado && S.estado.diseno) || "clasico";
  let dens = prefLocal("allas_densidad");
  if (dens !== "compacto" && dens !== "comodo") {
    const tactil = document.body.classList.contains("tactil");
    const pequena = Math.min(window.innerWidth, window.innerHeight * 1.6) <= 1280;
    dens = d === "compacto" || (!tactil && pequena) ? "compacto" : "comodo";   // compacto en monitores pequeños, cómodo en táctil
  }
  document.documentElement.dataset.densidad = dens;
  return dens;
}

function aplicarTema(tema, ignorarLocal) {
  if (!ignorarLocal && prefLocal("allas_tema")) tema = prefLocal("allas_tema");
  const oscuro = tema === "oscuro" || (tema === "sistema" && window.matchMedia && matchMedia("(prefers-color-scheme: dark)").matches);
  document.documentElement.dataset.tema = oscuro ? "oscuro" : "claro";
  if (S.estado) {   // Color de acento y diseño: solo en el programa; el acceso y la pantalla de carga llevan siempre el azul original
    document.documentElement.dataset.color = S.usuario ? (S.estado.color_acento || "azul") : "azul";
    document.documentElement.dataset.diseno = S.usuario ? (S.estado.diseno || "clasico") : "clasico";
  }
  aplicarDensidad();
  try { localStorage.setItem("tema", document.documentElement.dataset.tema); } catch (_) { /* sin almacenamiento */ }
  const meta = document.querySelector('meta[name="theme-color"]');   // 4.37: la barra del navegador sigue al tema
  if (meta) meta.content = oscuro ? "#0b1220" : "#1747c9";
}

// Interruptores rápidos de tema y densidad en «Herramientas»
function pintarAspectoRapido() {
  const lista = $("#herr-lista");
  if (!lista) return;
  $$(".mi-aspecto", lista).forEach((x) => x.remove());
  const actual = document.documentElement.dataset.tema === "oscuro" ? "oscuro" : "claro";
  const siguiente = actual === "oscuro" ? "claro" : "oscuro";
  const comodo = document.documentElement.dataset.densidad === "comodo";
  const hr = document.createElement("hr"); hr.className = "mi-aspecto";
  lista.append(hr);
  const mk = (id, txt, fn) => { const b = document.createElement("button"); b.type = "button"; b.className = "mi mi-aspecto"; b.id = id; b.textContent = txt; b.onclick = fn; lista.append(b); };
  mk("b-tema-rapido", actual === "oscuro" ? "☀ Cambiar a tema claro" : "☾ Cambiar a tema oscuro", () => {
    guardarPrefLocal("allas_tema", siguiente); aplicarTema(S.estado && S.estado.tema); pintarAspectoRapido();
  });
  mk("b-dens-rapido", comodo ? "Densidad: cómoda → pasar a compacta" : "Densidad: compacta → pasar a cómoda", () => {
    guardarPrefLocal("allas_densidad", comodo ? "compacto" : "comodo"); aplicarDensidad(); pintarAspectoRapido();
  });
}

function prefTactil() { try { return localStorage.getItem("allas_tactil") || ""; } catch (_) { return ""; } }

function aplicarTactil() {
  const pref = prefTactil() || (S.estado && S.estado.modo_tactil) || "auto";
  const tactil = pref === "si" || (pref === "auto" && window.matchMedia && matchMedia("(pointer: coarse)").matches);
  document.body.classList.toggle("tactil", !!tactil);
  aplicarDensidad();
}
window.addEventListener("resize", () => { try { aplicarDensidad(); } catch (_) { /* aún sin estado */ } });

// ======================================= Supervisión: menús y opciones ocultos

// CSS: se oculta con una regla; js: lo resuelve la propia pantalla.
const OCULTABLES = [
  { id: "actualizaciones_online", nombre: "Buscar actualizaciones online", donde: "Sistema → Actualizaciones", js: true },
  { id: "licencia_online", nombre: "Comprobación online de la licencia", donde: "Sistema → Licencia (aparece solo si hay que comprobarla)", js: true, defecto: true },
  { id: "ticket_manual_entrada", nombre: "Ticket manual en Entrada", donde: "Entrada (sigue en Salida)", css: "#vista:has(#f-entrada) #b-manual" },
  { id: "salida_facturas", nombre: "Botón «Facturas…» en Salida", donde: "Salida (siguen en Informes → Facturas)", css: "#b-facturas" },
  { id: "exportar_sueltos", nombre: "Importar / exportar en Tarifas y en Servicios", donde: "Precios (siguen en Sistema → Importar y exportar)", css: "#b-exp-t, #b-prod-exp" },
  { id: "camara_simular", nombre: "Botones «Simular lectura» de la cámara", donde: "Conexiones → cámaras", css: "[data-sim]" },
  { id: "borrar_datos", nombre: "Borrar todos los datos", donde: "Sistema → Copias de seguridad", css: "#pleg-peligro" },
  { id: "borrar_no_abonados", nombre: "Borrar los clientes sin abono", donde: "Sistema → Importar y exportar", css: "#ie-borrar" },
  { id: "campana", nombre: "Campana de avisos", donde: "Barra superior", css: "#b-campana" },
];

const NOMBRE_MENU = { vehiculos: "Vehículos", reservas: "Reservas", clientes: "Clientes y bonos", caja: "Caja y turno", tienda: "Tienda", informes: "Informes" };

function aplicarOcultos() {
  let st = $("#ocultos44");
  if (!st) { st = document.createElement("style"); st.id = "ocultos44"; document.head.appendChild(st); }
  const reglas = OCULTABLES.filter((o) => o.css && oculto(o.id)).map((o) => o.css);
  if (oculto("menu:apps")) reglas.push("#nav-apps");
  st.textContent = reglas.length ? reglas.join(",\n") + " { display: none !important; }" : "";
}

// ================================================= Teclado y lector de códigos

// El lector QR USB funciona como un teclado: "escribe" el código muy rápido y pulsa Intro.
// Capturamos esas ráfagas aunque el foco no esté en un campo, para poder escanear desde cualquier pantalla.
let rafaga = "", ultimaTecla = 0;

const PATRON_QR = /^[A-Z]{1,3}\d{7}[0-9A-F]{5}$/i;   // tickets (prefijo configurable) y tarjetas CL

// ============================================================ al cargar

if (window.matchMedia) matchMedia("(prefers-color-scheme: dark)").addEventListener?.("change", () => S.estado && aplicarTema(S.estado.tema));

// Estado (ocupación, turno, licencia…) cada 20 s y reloj de la barra
setInterval(refrescarEstado, 20000);

setInterval(() => { const r = $("#reloj"); if (r) r.textContent = new Date().toLocaleTimeString("es-ES"); }, 1000);

S.recordatorios = { total: 0, vistos: new Set() };

setInterval(() => cargarRecordatorios(true), 60000);

window.addEventListener("load", () => { try { aplicarTactil(); } catch (_) { /* aún sin estado */ } });

// Atajos de teclado (F1…F8, Esc, Intro) y lector de códigos sin foco en ningún campo
document.addEventListener("keydown", (e) => {
  if (!S.token) {
    const pintar = S.login.pintar || (() => {});
    if (e.target && e.target.tagName === "INPUT") return;   // formulario de primer arranque
    if (/^\d$/.test(e.key)) teclaPin(e.key, pintar);
    else if (e.key === "Backspace") teclaPin("borrar", pintar);
    else if (e.key === "Enter") { e.preventDefault(); teclaPin("ok"); }
    return;
  }
  const modalAbierto = !$("#modal").classList.contains("oculto");
  if (modalAbierto && e.key === "Escape") { cerrarModal(); return; }
  if (!modalAbierto) {
    const atajo = { F1: "entrada", F2: "cobrar", F3: "vehiculos", F4: "clientes", F5: "caja", F6: "informes", F7: "ajustes", F8: "tienda", F9: "reservas" }[e.key];
    if (atajo) {
      e.preventDefault();
      const v = VISTAS.find((x) => x.id === atajo);
      if (vistaVisible(v)) ir(atajo);
      return;
    }
    if (e.key === "Escape" && S.vista === "cobrar") { limpiarCobro(); return; }
    if (e.key === "Enter" && S.vista === "cobrar" && S.cobro.resultado && document.activeElement?.id !== "b-siguiente") { limpiarCobro(); return; }
  }
  const t = e.target;
  const enCampo = t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT");
  if (enCampo || modalAbierto) return;
  const ahora = performance.now();
  if (ahora - ultimaTecla > 120) rafaga = "";
  ultimaTecla = ahora;
  if (e.key === "Enter") {
    if (PATRON_QR.test(rafaga)) { e.preventDefault(); buscarTicket(rafaga); }
    else if (esCodigoReserva(rafaga)) { e.preventDefault(); leerCodigoReserva(rafaga); }   // 1.11: QR de la reserva del cliente
    else if (esFichaje(rafaga)) { e.preventDefault(); fichajeLeido(rafaga).then(() => { if (S.vista === "caja") vistaCaja($("#vista")); }); }   // QR de fichaje sin foco en ningún campo
    rafaga = "";
  } else if (e.key.length === 1) {
    rafaga += e.key;
  }
});

// Si se escanea con el foco en el campo de "entregado", detectamos el código y lo redirigimos.
document.addEventListener("input", (e) => {
  if (e.target.id === "entregado" && /(PK|CL)\d{7}[0-9A-F]{5}/i.test(e.target.value)) {
    const cod = e.target.value.match(/(PK|CL)\d{7}[0-9A-F]{5}/i)[0];
    e.target.value = "";
    buscarTicket(cod);
  }
});

window.addEventListener("beforeunload", (e) => {
  if (window.__salirSinPreguntar) return undefined;
  let tok = null;
  try { tok = sessionStorage.getItem("token"); } catch (_) { /* sin almacenamiento */ }
  if (!tok || !S.estado || !S.estado.usuario || S.estado.confirmar_cierre === false) return undefined;
  e.preventDefault();
  e.returnValue = "¿Cerrar PROYECTO ALLAS?";   // el navegador muestra su propio aviso
  return e.returnValue;
});

(function () {
  let enviados = 0, desde = Date.now();
  const enviar = (mensaje, origen, linea, pila) => {
    try {
      if (!S.token || !mensaje) return;
      if (Date.now() - desde > 60000) { enviados = 0; desde = Date.now(); }
      if (++enviados > 10) return;
      if (origen && !String(origen).startsWith(location.origin)) return;   // extensiones del navegador
      fetch("/api/registro-error", { method: "POST", headers: { "Content-Type": "application/json", "X-Token": S.token },
        body: JSON.stringify({ mensaje: String(mensaje).slice(0, 500), origen: String(origen || "").replace(location.origin, ""), linea: linea || null,
          pantalla: [S.vista, S.vista === "ajustes" ? S.ajustesTab : ""].filter(Boolean).join("/"), pila: String(pila || "").slice(0, 1500) }) }).catch(() => {});
    } catch (_) { /* nunca debe fallar */ }
  };
  window.addEventListener("error", (e) => enviar(e.message, e.filename, e.lineno, e.error && e.error.stack));
  window.addEventListener("unhandledrejection", (e) => {
    const r = e.reason || {};
    if (r && /^(Error \d+|Sin conexión|Failed to fetch)/.test(r.message || "")) return;   // errores de red: ya se avisan
    enviar(r.message || String(r), "", null, r.stack);
  });
})();
