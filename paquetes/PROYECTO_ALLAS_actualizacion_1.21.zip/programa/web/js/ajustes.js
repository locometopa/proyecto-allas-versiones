/* PROYECTO ALLAS · Ajustes: apartados, pestañas y formularios */
"use strict";

// ======================================================== Apartados y pestañas

// Ajustes agrupados: 7 apartados y, dentro, sus pestañas (1.0: los equipos físicos van juntos en «Equipos»)
const GRUPOS_AJUSTES = [
  { id: "empresa", nombre: "Empresa", ayuda: "Datos, numeración, caja, usuarios, plazas", tabs: [["empresa", "Datos y cobro"], ["general", "Preferencias y numeración"], ["horario", "Horario del parking"], ["caja", "Caja y arqueo"], ["usuarios", "Usuarios"], ["zonas", "Plazas y zonas", "gestion"]] },
  { id: "precios", nombre: "Precios", ayuda: "Tarifas, productos, descuentos", tabs: [["tarifas", "Tarifas", "rotacion"], ["productos", "Servicios y productos", "gestion"], ["descuentos", "Descuentos", "descuentos"]] },
  { id: "abonados", nombre: "Abonados", ayuda: "Bonos y avisos", tabs: [["bonos", "Tipos de bono", "abonados"], ["avisos", "Avisos y facturas por email", "abonados"]] },
  { id: "tickets", nombre: "Documentos", ayuda: "Ticket y factura", tabs: [["ticket", "Ticket"], ["factura", "Factura (PDF)", "gestion"]] },
  { id: "equipos", nombre: "Equipos", ayuda: "Impresoras, barrera, pantalla, datáfono, caja móvil", tabs: [["impresora", "Impresoras y cajón"], ["pantalla", "Pantalla de cliente", "pantalla_cliente"], ["perifericos", "Barrera", "perifericos"], ["semaforo", "Semáforo y cartel", "gestion"], ["datafono", "Datáfono", "perifericos"], ["movil", "Caja móvil", "movil"]] },
  { id: "conexiones", nombre: "Conexiones", ayuda: "Email, WhatsApp/SMS, cobro online, integraciones", tabs: [["email", "Email", "gestion"], ["mensajes", "WhatsApp / SMS", "mensajeria"], ["pagos", "Cobro online de bonos", "pagos_online"], ["pagomovil", "Pago con el móvil", "pagos_online"], ["reservasonline", "Reservas online", "gestion"], ["integraciones", "Madrid 360, cámaras, VERI*FACTU", ["madrid360", "verifactu"]], ["apps", "Aplicaciones externas", "gestion"]] },
  { id: "sistema", nombre: "Sistema", ayuda: "Copias, importar, versión, licencia", tabs: [["copias", "Copias de seguridad"], ["importar", "Importar y exportar", "gestion"], ["actualizaciones", "Actualizaciones"], ["licencia", "Licencia"], ["servidor", "Servidor"], ["demo", "Demostración", "gestion"], ["supervision", "Supervisión"]] },
];

const PANTALLAS_AJUSTES = () => ({ integraciones: ajIntegraciones, pagos: ajStripe, avisos: ajAvisos, general: ajGeneral, licencia: ajLicencia,
  actualizaciones: ajActualizaciones, servidor: ajServidor, empresa: ajEmpresa, ticket: ajTicket, impresora: ajImpresora, tarifas: ajTarifas, bonos: ajBonos,
  productos: ajProductos, email: ajEmail, usuarios: ajUsuarios, copias: ajCopias, importar: ajImportar, mensajes: ajMensajes, descuentos: ajDescuentos,
  pantalla: ajPantallaCliente, demo: ajDemo, caja: ajCaja, movil: ajMovil, perifericos: ajBarrera, datafono: ajDatafono, apps: ajApps,
  factura: ajFactura, zonas: ajZonas, pagomovil: ajPagoMovil, reservasonline: ajReservasOnline, horario: ajHorario, semaforo: ajSemaforo, supervision: ajSupervision });

// 4.35: buscador de ajustes. Palabras que llevan a cada pestaña (además de su nombre y el del apartado).
const PALABRAS_AJUSTES = {
  empresa: "nif cif razon social direccion telefono iva moneda datos de la empresa metodos de pago efectivo tarjeta cobro recargo",
  general: "preferencias numeracion serie prefijo codigo ticket qr capacidad plazas salida minutos idioma tema color diseno tactil",
  caja: "caja arqueo turno fondo billetes monedas cierre apertura descuadre",
  usuarios: "usuarios pin cajeros supervisores permisos roles contrasena acceso intentos bloqueo",
  movil: "movil telefono caja movil turno compartido red",
  zonas: "plazas zonas plantas capacidad exterior",
  apps: "aplicaciones externas botones programas menu",
  tarifas: "tarifas precios tramos gracia maximo diario fraccion hotel reserva",
  productos: "servicios productos lavado cafe catalogo iva venta tienda",
  descuentos: "descuentos vales codigos promociones cupones",
  bonos: "bonos tipos planes mensual abono renovacion",
  avisos: "avisos facturas email caducidad renovacion recordatorios",
  ticket: "ticket entrada salida recibo qr logo lineas corte imprimir cajero matricula grande",
  factura: "factura pdf logo pie notas titulo color simplificada",
  impresora: "impresora impresoras cajon termica ancho copias abrir cajon windows detectar",
  pantalla: "pantalla cliente segundo monitor visor rotulo escena",
  perifericos: "barrera automatica apertura relé pulso lpr camara",
  semaforo: "semaforo cartel libre completo ocupacion indicador",
  email: "email correo smtp gmail servidor envio",
  mensajes: "whatsapp sms twilio mensajes",
  pagos: "stripe cobro online pago online tarjeta bonos",
  pagomovil: "pago movil qr bizum enlace pagar con el movil",
  horario: "horario apertura cierre abierto cerrado festivos dias cerrados entradas salidas 24 horas",
  reservasonline: "reservas online reservar plaza cupo cancelacion antelacion web internet cliente codigo",
  datafono: "datafono tpv tarjeta terminal",
  integraciones: "madrid 360 camaras verifactu hacienda lpr integraciones",
  copias: "copias de seguridad backup restaurar datos borrar",
  importar: "importar exportar csv excel tarifas clientes",
  actualizaciones: "actualizaciones version novedades instalar paquete drive online",
  licencia: "licencia serial activar prueba caducidad",
  servidor: "servidor puerto red apagar reiniciar acceso otros equipos",
  demo: "demostracion demo datos de ejemplo",
  supervision: "supervision ocultar mostrar opciones permisos pestañas",
};
const normAj = (t) => String(t || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

function buscarAjustes(grupos, q) {
  const ts = normAj(q).split(/\s+/).filter(Boolean);
  if (!ts.length) return [];
  return grupos.flatMap((g) => g.tabs.map(([id, n]) => ({ id, nombre: n, grupo: g.nombre, gid: g.id,
    texto: normAj(`${n} ${g.nombre} ${PALABRAS_AJUSTES[id] || ""}`), titulo: normAj(n) })))
    .filter((x) => ts.every((t) => x.texto.includes(t)))
    .sort((a, b) => ts.filter((t) => b.titulo.includes(t)).length - ts.filter((t) => a.titulo.includes(t)).length)
    .slice(0, 8);
}

function vistaAjustes(v) {
  const admin = tieneRol("admin");
  const permitidas = admin ? null : ["impresora", "copias"];   // supervisor
  const conModulo = (mod) => !mod || [].concat(mod).some(tieneModulo);   // Pestañas de módulos no contratados fuera
  const grupos = GRUPOS_AJUSTES.map((g) => ({ ...g, tabs: g.tabs.filter(([id, , mod]) => (!permitidas || permitidas.includes(id)) && conModulo(mod)
      && (id === "supervision" ? admin : !oculto("aj:" + id))) }))
    .filter((g) => g.tabs.length)
    .map((g) => g.id === "conexiones" ? { ...g, ayuda: g.tabs.map(([id]) => ({ email: "Email", mensajes: "WhatsApp/SMS", pagos: "Stripe", integraciones: "integraciones", datafono: "datáfono", pagomovil: "pago móvil", reservasonline: "reservas", apps: "aplicaciones" })[id]).join(", ") }
      // si la licencia deja menos pestañas, la ayuda del apartado dice solo las que hay
      : g.tabs.length < GRUPOS_AJUSTES.find((x) => x.id === g.id).tabs.length ? { ...g, ayuda: g.tabs.map(([, n]) => n).join(", ") } : g);
  let grupo = grupos.find((g) => g.tabs.some(([id]) => id === S.ajustesTab));
  if (!grupo) { grupo = grupos[0]; S.ajustesTab = grupo.tabs[0][0]; }
  v.innerHTML = `<div class="cab"><h2>Ajustes</h2>
      <div class="aj-buscar"><input class="ent" id="aj-q" type="search" placeholder="Buscar un ajuste… (tarifa, impresora, IVA)" autocomplete="off" aria-label="Buscar un ajuste">
        <div class="aj-res oculto" id="aj-res" role="listbox"></div></div></div>
    <div class="grupos-ajustes">${grupos.map((g) => `<button data-g="${g.id}" class="${g === grupo ? "activo" : ""}"><b>${g.nombre}</b><span>${g.ayuda}</span></button>`).join("")}</div>
    ${grupo.tabs.length > 1 ? `<div class="pestanas">${grupo.tabs.map(([id, n]) => `<button data-t="${id}" class="${S.ajustesTab === id ? "activo" : ""}">${n}</button>`).join("")}</div>` : ""}
    <div id="aj"></div>`;
  S.ajustesUltima = S.ajustesUltima || {};
  S.ajustesUltima[grupo.id] = S.ajustesTab;
  $$("[data-g]", v).forEach((b) => (b.onclick = () => {
    const g = grupos.find((x) => x.id === b.dataset.g);
    S.ajustesTab = (S.ajustesUltima[g.id] && g.tabs.some(([id]) => id === S.ajustesUltima[g.id])) ? S.ajustesUltima[g.id] : g.tabs[0][0];
    vistaAjustes(v);
  }));
  $$("[data-t]", v).forEach((b) => (b.onclick = () => { S.ajustesTab = b.dataset.t; vistaAjustes(v); }));
  const q = $("#aj-q", v), res = $("#aj-res", v);
  const ir = (x) => { S.ajustesTab = x.id; vistaAjustes(v); };
  const pintarRes = () => {
    const r = buscarAjustes(grupos, q.value);
    res.classList.toggle("oculto", !q.value.trim());
    res.innerHTML = r.length ? r.map((x, i) => `<button class="aj-r${i ? "" : " sel"}" data-i="${i}" role="option"><b>${esc(x.nombre)}</b><span>${esc(x.grupo)}</span></button>`).join("")
      : '<div class="aj-vacio">Ningún ajuste coincide</div>';
    $$("[data-i]", res).forEach((b) => (b.onmousedown = (e) => { e.preventDefault(); ir(r[Number(b.dataset.i)]); }));
    return r;
  };
  q.oninput = pintarRes;
  q.onkeydown = (e) => {
    if (e.key === "Escape") { q.value = ""; pintarRes(); }
    else if (e.key === "Enter") { const r = buscarAjustes(grupos, q.value); if (r.length) ir(r[0]); }
  };
  q.onblur = () => setTimeout(() => res.classList.add("oculto"), 150);
  q.onfocus = () => { if (q.value.trim()) pintarRes(); };
  PANTALLAS_AJUSTES()[S.ajustesTab]($("#aj"));
  aplicarOcultos();
}

// Abre Ajustes en una pestaña concreta (también desde las pruebas y otros botones)
function irAjustes(tab) { S.ajustesTab = tab; ir("ajustes"); }

// ================================================ Formularios de configuración

function campoCfg(cfg, k, etiqueta, { tipo = "text", ayuda = "", opciones = null, eurField = false } = {}) {
  const val = eurField ? aEurTxt(Number(cfg[k] || 0)) : (cfg[k] ?? "");
  const ctrl = opciones
    ? `<select class="ent" name="${k}">${opciones.map(([v, n]) => `<option value="${v}" ${String(val) === v ? "selected" : ""}>${n}</option>`).join("")}</select>`
    : `<input class="ent" name="${k}" type="${tipo}" value="${esc(val)}" ${eurField ? 'data-eur="1" inputmode="decimal"' : ""}>`;
  return `<label class="campo">${etiqueta}${ayuda ? ` <span class="ayuda">${ayuda}</span>` : ""}${ctrl}</label>`;
}

async function formCfg(el, html, despues) {
  const cfg = await api("GET", "/api/config");
  el.innerHTML = `<form class="panel" id="f-cfg" style="max-width:820px"><div class="rejilla r2">${html(cfg)}</div>
    <div class="fila" style="margin-top:18px"><button class="btn prim">Guardar cambios</button><span id="cfg-extra"></span></div></form>`;
  $("#f-cfg").onsubmit = accion(async (e) => {
    e.preventDefault();
    const d = {};
    $$("[name]", e.target).forEach((i) => {
      if (i.dataset.eur) { const c = aCent(i.value); if (Number.isNaN(c)) throw new Error("Importe no válido en " + i.name); d[i.name] = c ?? 0; }
      else d[i.name] = i.value;
    });
    await api("PUT", "/api/config", d);
    toast("Configuración guardada", "ok");
    S.estado = await api("GET", "/api/estado");
    render();
  });
  despues && despues(cfg);
}

// Datos de la empresa y forma de cobrar, por bloques; los campos que dependen de otro solo se ven cuando aplican
const seccionCfg = (titulo) => `<h3 class="seccion-cfg">${titulo}</h3>`;

// Muestra u oculta los bloques data-si="campo=valor" según el valor elegido
function camposCondicionales(form) {
  if (!form) return;
  const aplicar = () => $$("[data-si]", form).forEach((d) => {
    const [k, v] = d.dataset.si.split("=");
    const ctrl = form.querySelector(`[name="${k}"]`);
    d.classList.toggle("oculto", !!ctrl && ctrl.value !== v);
  });
  $$("select[name]", form).forEach((s) => s.addEventListener("change", aplicar));
  aplicar();
}
