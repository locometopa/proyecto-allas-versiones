/* PROYECTO ALLAS · Ajustes → Conexiones */
"use strict";

// ======================================================================= Email

// --- Ajustes · Email
const ajEmail = accion(async (el) => {
  const c = await api("GET", "/api/config");
  const campo = (k, et, extra = "") => `<label class="campo">${et}<input class="ent" name="${k}" value="${esc(c[k] || "")}" ${extra}></label>`;
  const met = c.email_metodo || "gmail_web";
  el.innerHTML = `<form class="panel" id="f-mail" style="max-width:860px">
    <h3>Cómo se envían las facturas por email</h3>
    <div class="metodos-email">
      ${[["gmail_web", "Gmail en el navegador", "Recomendado si usa Gmail. No hay que configurar nada: se abre Gmail con el mensaje escrito y se descarga el PDF para adjuntarlo."],
         ["outlook", "Programa de correo del PC", "Se descarga un borrador (.eml) con la factura adjunta; al abrirlo, Outlook lo muestra listo para enviar."],
         ["smtp", "Envío automático (SMTP)", "El programa envía el correo solo. Hay que configurar el servidor; en Gmail requiere «contraseña de aplicación»."]]
        .map(([v, t, d]) => `<label class="metodo-email ${met === v ? "sel" : ""}"><input type="radio" name="email_metodo" value="${v}" ${met === v ? "checked" : ""}>
          <b>${t}</b><span class="suave">${d}</span></label>`).join("")}
    </div>
    <div id="smtp-bloque" class="${met === "smtp" ? "" : "oculto"}">
    <div class="aviso" style="margin-top:16px">El envío automático necesita <b>conexión a Internet</b> al enviar. Si no la hay, la factura queda pendiente y se reintenta sola cada 15 minutos.</div>
    <div class="fila" style="margin-top:16px;justify-content:space-between"><h3>Servidor de correo (SMTP)</h3>
      <button type="button" class="btn" id="b-gmail">Rellenar para Gmail</button></div>
    <div class="rejilla r2" style="margin-top:10px">
      ${campo("smtp_servidor", "Servidor", 'placeholder="smtp.gmail.com"')}
      ${campo("smtp_puerto", "Puerto", 'type="number"')}
      <label class="campo">Seguridad<select class="ent" name="smtp_seguridad">${[["starttls", "STARTTLS (puerto 587)"], ["ssl", "SSL/TLS (puerto 465)"], ["ninguna", "Ninguna (no recomendado)"]]
        .map(([v, n]) => `<option value="${v}" ${c.smtp_seguridad === v ? "selected" : ""}>${n}</option>`).join("")}</select></label>
      ${campo("smtp_remitente", "Email del remitente", 'type="email" placeholder="facturas@miparking.es"')}
      ${campo("smtp_usuario", "Usuario", 'autocomplete="off"')}
      ${campo("smtp_clave", "Contraseña", 'type="password" autocomplete="new-password"')}
    </div>
    <p class="ayuda">Gmail exige una <b>contraseña de aplicación</b>, no la contraseña normal: active la verificación en 2 pasos en su cuenta de Google y cree la contraseña en myaccount.google.com → Seguridad → Contraseñas de aplicación. La contraseña se guarda en el PC de caja y nunca se muestra.</p>
    </div>
    <h3 style="margin-top:16px">Mensaje</h3>
    <div class="rejilla" style="margin-top:10px;gap:10px">
      ${campo("email_asunto", "Asunto")}
      <label class="campo">Texto <span class="ayuda">{nombre}, {numero} y {parking} se sustituyen</span><textarea class="ent" name="email_texto" rows="4">${esc(c.email_texto || "")}</textarea></label>
      ${campo("factura_titulo_completa", "Título de la factura con datos del cliente")}
    </div>
    <div class="fila" style="margin-top:16px"><button class="btn prim">Guardar</button>
      <input class="ent" id="mail-prueba" type="email" placeholder="email para la prueba" style="max-width:260px">
      <button type="button" class="btn" id="b-mail-prueba">Enviar prueba</button></div>
  </form>`;
  $$("[name=email_metodo]").forEach((r) => (r.onchange = () => {
    $$(".metodo-email").forEach((l) => l.classList.toggle("sel", l.contains(r) && r.checked));
    $("#smtp-bloque").classList.toggle("oculto", r.value !== "smtp" || !r.checked);
  }));
  $("#b-gmail").onclick = () => {
    const f = $("#f-mail");
    f.smtp_servidor.value = "smtp.gmail.com"; f.smtp_puerto.value = "587"; f.smtp_seguridad.value = "starttls";
    if (!f.smtp_usuario.value && f.smtp_remitente.value) f.smtp_usuario.value = f.smtp_remitente.value;
    if (!f.smtp_remitente.value && f.smtp_usuario.value) f.smtp_remitente.value = f.smtp_usuario.value;
    toast("Escriba su dirección de Gmail en Usuario y la contraseña de aplicación", "ok");
  };
  $("#f-mail").onsubmit = accion(async (e) => {
    e.preventDefault();
    await api("PUT", "/api/config", Object.fromEntries(new FormData(e.target)));
    toast("Configuración de correo guardada", "ok");
    S.estado = await api("GET", "/api/estado");
  });
  $("#b-mail-prueba").onclick = accion(async () => {
    await api("PUT", "/api/config", Object.fromEntries(new FormData($("#f-mail"))));
    await api("POST", "/api/email/prueba", { email: $("#mail-prueba").value });
    toast("Email de prueba enviado", "ok");
  });
});

// ============================================================== WhatsApp / SMS

const MODOS_MSG = [
  ["no", "Desactivado", "No se usan WhatsApp ni SMS."],
  ["manual", "WhatsApp manual", "Sin coste ni cuentas: el programa abre WhatsApp (Web o aplicación) con el número y el mensaje escritos; usted pulsa Enviar."],
  ["twilio", "Automático (Twilio)", "SMS o WhatsApp enviados por el programa con una cuenta de Twilio (de pago, por mensaje). Necesita Internet."],
];

const ajMensajes = accion(async (el) => {
  const c = await api("GET", "/api/config");
  const modo = c.msg_modo || "no";
  el.innerHTML = `<form class="panel" id="f-msg" style="max-width:900px">
    <h3>Avisos por WhatsApp / SMS</h3>
    <div class="modos-msg">${MODOS_MSG.map(([k, n, d]) => `<label class="opcion-copia"><input type="radio" name="msg_modo" value="${k}" ${modo === k ? "checked" : ""}>
      <span><b>${n}</b><span class="suave">${d}</span></span></label>`).join("")}</div>
    <div id="msg-twilio" class="${modo === "twilio" ? "" : "oculto"}">
      <h3 class="seccion-cfg" style="margin-top:16px">Cuenta de Twilio</h3>
      <div class="rejilla r2" style="margin-top:8px">
        <label class="campo">Account SID<input class="ent mono" name="twilio_sid" value="${esc(c.twilio_sid || "")}" placeholder="AC…" autocomplete="off"></label>
        <label class="campo">Auth Token<input class="ent mono" name="twilio_token" type="password" value="${esc(c.twilio_token || "")}" autocomplete="new-password"></label>
        <label class="campo">Remitente SMS <span class="ayuda">número de Twilio, p. ej. +34…</span><input class="ent mono" name="twilio_desde_sms" value="${esc(c.twilio_desde_sms || "")}"></label>
        <label class="campo">Remitente WhatsApp <span class="ayuda">número aprobado en WhatsApp Business</span><input class="ent mono" name="twilio_desde_whatsapp" value="${esc(c.twilio_desde_whatsapp || "")}"></label>
        <label class="campo">Canal por defecto<select class="ent" name="msg_canal">
          <option value="whatsapp" ${c.msg_canal !== "sms" ? "selected" : ""}>WhatsApp</option><option value="sms" ${c.msg_canal === "sms" ? "selected" : ""}>SMS</option></select></label>
        <label class="fila" style="gap:8px;grid-column:1/-1;font-weight:600"><input type="checkbox" id="msg-auto" ${c.msg_avisos_auto === "1" ? "checked" : ""}>
          Enviar también por aquí los avisos automáticos (renovación, caducidad, pago pendiente)</label>
      </div>
      <p class="ayuda">WhatsApp solo deja iniciar conversación con plantillas aprobadas por Meta: si el cliente no le ha escrito en las últimas 24 h,
        un mensaje libre puede no llegar. El SMS no tiene esa limitación.</p>
    </div>
    <div id="msg-texto" class="${modo === "no" ? "oculto" : ""}">
      <h3 class="seccion-cfg" style="margin-top:16px">Texto del recordatorio de deuda</h3>
      <label class="campo" style="margin-top:8px"><span class="ayuda">{nombre}, {importe}, {parking}, {texto_transferencia}. Vacío = texto por defecto. Corto: un SMS son 160 caracteres.</span>
        <textarea class="ent" name="msg_deuda_texto" rows="3" style="font-family:inherit" placeholder="{parking}: Hola {nombre}, le recordamos que tiene {importe} pendiente de pago de su bono. Puede pagarlo en caja.{texto_transferencia}">${esc(c.msg_deuda_texto || "")}</textarea></label>
    </div>
    <p class="ayuda">Se usa el <b>Teléfono</b> de la ficha de cada cliente (móvil español 6xx/7xx, o con prefijo internacional +…).
      Para avisos del servicio; para publicidad hace falta el consentimiento de cada cliente.</p>
    <div class="fila" style="margin-top:14px"><button class="btn prim">Guardar</button></div>
  </form>
  <div class="panel ${modo === "twilio" ? "" : "oculto"}" id="msg-prueba" style="max-width:900px;margin-top:16px"><h3>Probar el envío</h3>
    <div class="fila" style="margin-top:10px"><input class="ent" id="mp-tel" placeholder="Su móvil, p. ej. 612 345 678" style="max-width:260px">
      <select class="ent" id="mp-canal" style="width:auto"><option value="whatsapp">WhatsApp</option><option value="sms">SMS</option></select>
      <button class="btn" id="mp-enviar">Enviar mensaje de prueba</button></div></div>`;
  const f = $("#f-msg");
  const pintar = () => {
    const m = $('[name="msg_modo"]:checked', f).value;
    $("#msg-twilio").classList.toggle("oculto", m !== "twilio");
    $("#msg-texto").classList.toggle("oculto", m === "no");
    $("#msg-prueba").classList.toggle("oculto", m !== "twilio");
  };
  $$('[name="msg_modo"]', f).forEach((r) => (r.onchange = pintar));
  f.onsubmit = accion(async (e) => {
    e.preventDefault();
    const d = { msg_modo: $('[name="msg_modo"]:checked', f).value, msg_avisos_auto: $("#msg-auto").checked ? "1" : "0" };
    $$("input[name], select[name], textarea[name]", f).forEach((i) => { if (i.name !== "msg_modo") d[i.name] = i.value; });
    await api("PUT", "/api/config", d);
    S.estado = await api("GET", "/api/estado");
    toast("Ajustes de WhatsApp / SMS guardados", "ok");
    ajMensajes(el);
  });
  $("#mp-enviar").onclick = accion(async () => {
    const r = await api("POST", "/api/mensajes/prueba", { telefono: $("#mp-tel").value, canal: $("#mp-canal").value });
    toast(`Mensaje de prueba enviado por ${r.canal === "sms" ? "SMS" : "WhatsApp"} a ${r.destino}`, "ok");
  });
});

// ============================================== Cobro online de bonos (Stripe)

// Los abonados se suscriben con su tarjeta y el programa consulta Stripe cada 10 minutos (renueva, factura y avisa)
const ajStripe = accion(async (el) => {
  if (!tieneModulo("pagos_online")) { el.innerHTML = '<div class="vacio">El cobro online no está incluido en su licencia.</div>'; return; }
  const e = await api("GET", "/api/pagos-online");
  el.innerHTML = `<div style="max-width:1080px">
    <div class="panel mod-pagos_online">
      <div class="fila" style="justify-content:space-between"><h3>Cobro online de suscripciones (Stripe)</h3>
        ${e.activo ? `<span class="etiqueta e-pagado">Activado${e.prueba ? " · modo prueba" : ""}</span>` : '<span class="etiqueta e-salido">Desactivado</span>'}</div>
      <p class="suave" style="margin:8px 0 12px">Los abonados se suscriben con su tarjeta desde el móvil y se les cobra solo cada periodo. El programa consulta Stripe cada 10 minutos
        (no hace falta abrir puertos ni tener web): renueva el bono, emite la factura y se la envía, y avisa si un cobro falla. Necesita Internet en este ordenador.</p>
      ${e.activo ? `<table class="tabla" style="margin-bottom:12px"><tbody>
          <tr><td class="suave">Cuenta</td><td><b>${esc(e.cuenta?.nombre || "")}</b> ${e.prueba ? '<span class="etiqueta e-aviso">Prueba: no se cobra dinero real</span>' : '<span class="etiqueta e-pagado">Real</span>'}</td></tr>
          <tr><td class="suave">Clave</td><td class="mono">${esc(e.clave)}</td></tr>
          <tr><td class="suave">Última comprobación</td><td>${e.ultimo_sync ? new Date(e.ultimo_sync).toLocaleString("es-ES") : "—"}
            ${e.ultimo_error ? `<div class="aviso rojo" style="margin-top:6px">${esc(e.ultimo_error)}</div>` : ""}</td></tr></tbody></table>` : ""}
      <form class="fila" id="po-form">
        <input class="ent mono" id="po-clave" style="flex:1;min-width:320px" placeholder="${e.activo ? "Nueva clave secreta (déjelo vacío para mantener la actual)" : "Clave secreta de Stripe: sk_live_… o sk_test_…"}" autocomplete="off">
        <button class="btn prim">${e.activo ? "Cambiar clave" : "Activar pagos online"}</button>
        ${e.activo ? '<button type="button" class="btn" id="po-sync">Sincronizar ahora</button><button type="button" class="btn peligro" id="po-off">Desactivar</button>' : ""}
      </form>
      <details style="margin-top:12px"><summary class="suave" style="cursor:pointer">¿Cómo consigo la clave de Stripe?</summary>
        <ol class="suave"><li>Cree su cuenta en stripe.com (empresa, CIF y la cuenta bancaria donde recibir el dinero).</li>
        <li>En el panel de Stripe: <b>Desarrolladores → Claves de API</b>. Copie la <b>clave secreta</b> (empieza por <span class="mono">sk_live_</span>).</li>
        <li>Para probar antes sin cobrar de verdad, active el «modo de prueba» en Stripe y use la clave <span class="mono">sk_test_</span> (tarjeta de prueba 4242 4242 4242 4242).</li>
        <li>Recomendado en Stripe: <b>Configuración → Facturación → Suscripciones y emails</b>: active los reintentos de cobro y el email de tarjeta caducada.</li></ol></details>
    </div>
    ${e.activo ? `<div class="panel mod-pagos_online" style="margin-top:16px">
      <div class="fila" style="justify-content:space-between"><h3>Enlaces de pago por tipo de bono</h3><button class="btn" id="po-planes">Actualizar enlaces</button></div>
      <table class="tabla" style="margin-top:8px"><tbody>${e.planes.map((p) => `<tr><td><b>${esc(p.nombre)}</b> <span class="suave">${eur(p.precio_cent)} cada ${p.meses > 1 ? p.meses + " meses" : "mes"}</span></td>
        <td>${!p.activo ? '<span class="etiqueta e-salido">No está a la venta</span>' : p.al_dia ? '<span class="etiqueta e-pagado">Enlace listo</span>' : '<span class="etiqueta e-aviso">Pendiente (cambió el precio)</span>'}</td>
        <td class="suave mono" style="font-size:.78rem">${esc(p.url_enlace || "")}</td></tr>`).join("")}</tbody></table>
      <p class="ayuda">Si cambia el precio de un bono se crea un enlace nuevo; las suscripciones ya hechas siguen con su precio hasta que se den de baja y vuelvan a suscribirse.</p></div>
    <div class="panel" style="margin-top:16px"><h3>Suscripciones</h3>
      ${e.suscripciones.length ? `<table class="tabla" style="margin-top:8px"><tbody>${e.suscripciones.map((s) => `<tr>
        <td><b>${esc(s.cliente_nombre)}</b><div class="suave" style="font-size:.82rem">${esc(s.email || "")}</div></td><td>${esc(s.plan_nombre)}</td>
        <td><span class="etiqueta ${ESTADO_SUS[s.estado][0]}">${ESTADO_SUS[s.estado][1]}</span>${s.cancelar_al_final ? ' <span class="etiqueta e-aviso">Baja al final</span>' : ""}</td>
        <td class="suave">${s.periodo_fin ? "próximo cargo " + fechaHoraCorta(s.periodo_fin) : ""}</td>
        <td class="der"><button class="btn" data-cli="${s.cliente_id}">Ficha</button></td></tr>`).join("")}</tbody></table>`
        : '<div class="vacio" style="padding:16px">Aún no hay suscripciones. Ofrézcalas desde la ficha del abonado («Suscribir con tarjeta…»).</div>'}</div>` : ""}</div>`;
  $("#po-form").onsubmit = accion(async (ev) => {
    ev.preventDefault();
    const r = await api("POST", "/api/pagos-online/activar", { clave: $("#po-clave").value });
    toast(`Pagos online activados con la cuenta «${r.cuenta.nombre}»${r.prueba ? " (modo prueba)" : ""}`, "ok");
    S.estado = await api("GET", "/api/estado");
    ajStripe(el);
  });
  if ($("#po-sync")) $("#po-sync").onclick = accion(async () => {
    const r = await api("POST", "/api/pagos-online/sincronizar");
    toast(`Sincronizado: ${r.nuevas} suscripción(es) nueva(s), ${r.cobros} cobro(s), ${r.avisos} aviso(s)`, "ok");
    ajStripe(el);
  });
  if ($("#po-planes")) $("#po-planes").onclick = accion(async () => {
    const r = await api("POST", "/api/pagos-online/planes");
    toast(r.rehechos.length ? `Enlaces actualizados: ${r.rehechos.join(", ")}` : "Los enlaces ya estaban al día", "ok");
    ajStripe(el);
  });
  if ($("#po-off")) $("#po-off").onclick = accion(async () => {
    if (!(await confirmar("Desactivar pagos online", "El programa dejará de consultar Stripe: los cobros que se hagan no renovarán bonos hasta que lo vuelva a activar. Las suscripciones siguen activas en Stripe (cobrando). ¿Desactivar?", { boton: "Desactivar", peligro: true }))) return vistaAjustes($("#vista"));
    await api("POST", "/api/pagos-online/desactivar");
    S.estado = await api("GET", "/api/estado");
    vistaAjustes($("#vista"));
  });
  $$("[data-cli]", el).forEach((b) => (b.onclick = () => abrirFicha(Number(b.dataset.cli))));
});

// =========================================================== Pago con el móvil

const ajPagoMovil = accion(async (el) => {
  const [c, po] = await Promise.all([api("GET", "/api/config"), api("GET", "/api/pagos-online").catch(() => null)]);
  const stripe = po && po.activo && po.clave;
  el.innerHTML = `<div class="rejilla r2" style="max-width:1150px;align-items:start">
    <form class="panel" id="f-pm"><div class="fila" style="justify-content:space-between"><h3 class="titulo-icono">${icono("movil", 22)}Pago con el móvil</h3>
        <span class="etiqueta ${c.pago_movil_activo === "1" && stripe && c.pago_movil_url ? "e-pagado" : "e-salido"}">${c.pago_movil_activo === "1" && stripe && c.pago_movil_url ? "Activado" : "Desactivado"}</span></div>
      <p class="suave" style="margin:8px 0">El ticket lleva un segundo código QR: el cliente lo escanea con la cámara de su móvil, ve el importe, paga con tarjeta
        (Apple Pay y Google Pay incluidos, a través de Stripe) y sale sin pasar por la caja dentro del tiempo indicado.</p>
      ${stripe ? `<div class="aviso verde" style="margin:8px 0">Stripe conectado (${esc(po.clave)}${po.prueba ? ", modo de PRUEBA" : ""}).</div>`
        : `<div class="aviso" style="margin:8px 0">Conecte antes su cuenta de Stripe en <a href="#" id="pm-ir-stripe">Ajustes → Abonados → Pagos online</a>.</div>`}
      <label class="fila" style="gap:10px;font-weight:600;margin-top:10px"><input type="checkbox" name="pago_movil_activo" ${c.pago_movil_activo === "1" ? "checked" : ""}> Activar el pago con el móvil</label>
      <div class="rejilla r2" style="margin-top:12px">
        <label class="campo" style="grid-column:1/-1">Dirección pública del parking <span class="ayuda">por la que se llega a este PC desde Internet</span>
          <input class="ent mono" name="pago_movil_url" value="${esc(c.pago_movil_url || "")}" placeholder="https://pagos.miparking.es"></label>
        <label class="campo">Minutos para salir después de pagar<input class="ent num" type="number" min="5" max="120" name="pago_movil_minutos" value="${esc(c.pago_movil_minutos || "15")}"></label>
        <label class="fila" style="gap:8px;align-self:end;flex-wrap:nowrap;padding-bottom:12px"><input type="checkbox" name="ticket_qr_pago" ${c.ticket_qr_pago !== "0" ? "checked" : ""}> Imprimir el QR de pago en el ticket</label></div>
      <div class="fila" style="margin-top:14px"><button class="btn prim">Guardar</button><button type="button" class="btn" id="pm-probar">Abrir la página de pago de un ticket</button></div></form>
    <div class="panel"><h3>Cómo publicar la página de pago</h3>
      <ol style="padding-left:20px;line-height:1.6;margin:8px 0">
        <li>La página de pago la sirve este mismo PC. Para que el móvil del cliente llegue a ella desde Internet hace falta una <b>dirección pública con HTTPS</b>.</li>
        <li>Lo más sencillo: un <b>túnel</b> (por ejemplo Cloudflare Tunnel, gratuito) que apunte a <span class="mono">http://localhost:${esc(location.port || "8080")}</span> con un nombre como <span class="mono">pagos.miparking.es</span>.
          También vale abrir un puerto en el router con un nombre DDNS y un certificado.</li>
        <li>Escriba esa dirección arriba y pruebe con «Abrir la página de pago».</li></ol>
      <div class="aviso" style="margin-top:8px">${icono("candado", 16)} <b>Seguridad:</b> desde Internet solo responde la página de pago y sus datos (importe, hora de entrada y una matrícula parcial).
        El resto del programa contesta «No disponible», aunque alguien conozca la dirección.</div>
      <p class="suave" style="font-size:.88rem;margin:10px 0 0">Los pagos llegan como cobros «online» con su factura simplificada; si el cliente sale antes de que el programa los vea, se recogen solos en unos minutos.
        Si un pago no cuadra (ticket ya salido o importe distinto), aparece un aviso en la campana para devolverlo desde Stripe.</p></div></div>`;
  if ($("#pm-ir-stripe", el)) $("#pm-ir-stripe", el).onclick = (e) => { e.preventDefault(); irAjustes("pagos"); };
  const f = $("#f-pm", el);
  f.onsubmit = accion(async (e) => {
    e.preventDefault();
    await api("PUT", "/api/config", { pago_movil_activo: f.pago_movil_activo.checked ? "1" : "0", pago_movil_url: f.pago_movil_url.value.trim(),
      pago_movil_minutos: f.pago_movil_minutos.value || "15", ticket_qr_pago: f.ticket_qr_pago.checked ? "1" : "0" });
    S.estado = await api("GET", "/api/estado");
    toast("Guardado", "ok"); ajPagoMovil(el);
  });
  $("#pm-probar", el).onclick = accion(async () => {
    const dentro = await api("GET", "/api/dentro");
    const t = dentro.find((x) => !x.cliente_id);
    if (!t) throw new Error("No hay ningún vehículo dentro para probar");
    const base = (f.pago_movil_url.value.trim() || location.origin).replace(/\/$/, "");
    window.open(`${/^https?:/.test(base) ? base : "https://" + base}/pagar?c=${encodeURIComponent(t.codigo)}`, "_blank");
  });
});

// ==================================================================== Datáfono

// Al cobrar con tarjeta, el importe se manda solo al datáfono y el cobro se registra cuando lo aprueba
const ajDatafono = accion(async (el) => {
  const c = await api("GET", "/api/config");
  const sel = (k, ops, def) => `<select class="ent" name="${k}">${ops.map(([v, n]) => `<option value="${v}" ${(c[k] || def) === v ? "selected" : ""}>${n}</option>`).join("")}</select>`;
  el.innerHTML = `<div class="rejilla" style="max-width: 760px; align-items: start;">
    <form class="panel" id="f-datafono">
      <div class="fila" style="justify-content:space-between"><h3>Datáfono integrado</h3>
        <span class="etiqueta ${c.datafono_activo === "1" ? "e-pagado" : "e-salido"}">${c.datafono_activo === "1" ? "Activado" : "Desactivado"}</span></div>
      <p class="suave" style="margin:8px 0">Al cobrar con <b>tarjeta</b>, el importe se manda solo al datáfono y el cobro se registra cuando lo aprueba (con su nº de autorización). Sin esto, el importe se teclea en el datáfono como siempre.</p>
      <label class="fila" style="gap:10px;font-weight:600"><input type="checkbox" name="datafono_activo" ${c.datafono_activo === "1" ? "checked" : ""}> Usar datáfono integrado</label>
      <div class="rejilla r2" style="margin-top:12px">
        <label class="campo">Conexión${sel("datafono_modo", [["simulado", "Simulado (para probar)"], ["http", "Pasarela por red (HTTP)"], ["programa", "Programa del banco / TPV-PC"]], "simulado")}</label>
        <label class="campo">Espera máxima (s)<input class="ent num" type="number" min="10" max="300" name="datafono_timeout" value="${esc(c.datafono_timeout || "90")}"></label>
        <label class="campo" style="grid-column:1/-1"><span id="df-dest-l">Dirección</span><input class="ent mono" name="datafono_destino" value="${esc(c.datafono_destino || "")}" autocomplete="off"></label></div>
      <p class="ayuda" id="df-ayuda" style="margin:8px 0 0"></p>
      <div class="aviso" style="margin-top:10px">Cada banco usa su propio sistema (TPV-PC, Redsys, Paycomet…). Pida a su banco la <b>pasarela o el programa</b> de su datáfono y la forma de llamarlo; esta conexión se adapta a casi todos. Pruébelo antes en «Simulado».</div>
      <div class="fila" style="margin-top:12px"><button class="btn prim">Guardar</button><button type="button" class="btn" id="df-probar">Probar cobro de 0,01 €</button></div>
    </form></div>`;
  const fd = $("#f-datafono", el);
  const pintar = () => {
    const md = fd.datafono_modo.value;
    $("#df-dest-l", el).textContent = { simulado: "Dirección (no se usa en simulado)", http: "URL de la pasarela", programa: "Programa y parámetros" }[md];
    $("#df-ayuda", el).innerHTML = {
      simulado: "Aprueba todos los cobros al momento: sirve para probar el funcionamiento sin datáfono.",
      http: "Se envía <span class='mono'>POST {importe_cent, importe, referencia}</span> y se espera <span class='mono'>{\"ok\": true, \"autorizacion\": \"…\"}</span>.",
      programa: "Use <span class='mono'>{importe}</span> (12.34), <span class='mono'>{importe_cent}</span> y <span class='mono'>{referencia}</span>. Código de salida 0 = aprobada; la primera línea que escriba es la autorización.",
    }[md];
  };
  fd.datafono_modo.onchange = pintar; pintar();
  const guardarD = async () => api("PUT", "/api/config", {
    datafono_activo: fd.datafono_activo.checked ? "1" : "0", datafono_modo: fd.datafono_modo.value,
    datafono_destino: fd.datafono_destino.value.trim(), datafono_timeout: fd.datafono_timeout.value });
  fd.onsubmit = accion(async (e) => { e.preventDefault(); await guardarD(); toast("Datáfono guardado", "ok"); S.estado = await api("GET", "/api/estado"); pintarBarra(); ajDatafono(el); });
  $("#df-probar", el).onclick = accion(async () => {
    await guardarD();
    if (!fd.datafono_activo.checked) throw new Error("Marque «Usar datáfono integrado» para probarlo");
    S.estado = await api("GET", "/api/estado");
    const ref = await pasoDatafono(1, "PRUEBA");
    toast(ref ? `Prueba aprobada (${ref})` : "Prueba terminada", "ok");
  });
});

// ============================================ Madrid 360, cámaras y VERI*FACTU

const ajIntegraciones = accion(async (el) => {
  // Solo se consulta lo de los módulos contratados; el resto queda con valores vacíos y oculto
  const mm = tieneModulo("madrid360"), mv = tieneModulo("verifactu");
  const [c, m3, vf, lpr] = await Promise.all([api("GET", "/api/config"),
    mm ? api("GET", "/api/m360") : { activo: false, dias: [] },
    mv ? api("GET", "/api/verifactu") : { activo: false, registros: [], total: 0, pendientes: 0 },
    mm ? api("GET", "/api/lpr/config") : { activo: false, token: "" }]);
  if (!el.isConnected) return;   // se cambió de pantalla mientras cargaba
  const sel = (k, ops) => `<select class="ent" name="${k}">${ops.map(([v, n]) => `<option value="${v}" ${String(c[k] || "") === v ? "selected" : ""}>${n}</option>`).join("")}</select>`;
  const chk = (k, txt) => `<label class="fila" style="gap:8px;font-weight:600"><input type="checkbox" name="${k}" ${c[k] === "1" ? "checked" : ""}> ${txt}</label>`;
  const urlLpr = `${location.origin}/api/lpr/lectura`;
  el.innerHTML = `<div style="max-width:1080px" class="rejilla">
    <form class="panel mod-madrid360" id="f-m360">
      <div class="fila" style="justify-content:space-between"><h3>Madrid 360 · ZBE Distrito Centro</h3>
        <span class="etiqueta ${m3.activo ? "e-pagado" : "e-salido"}">${m3.activo ? "Activado" : "Desactivado"}</span></div>
      <p class="suave" style="margin:8px 0">Los aparcamientos autorizados dentro de la Zona de Bajas Emisiones de Especial Protección Distrito Centro comunican al Ayuntamiento cada día
        las matrículas de los vehículos que han entrado, para que no les llegue multa. Aquí se prepara ese listado (<span class="mono">matrícula;día;hora</span>).
        El envío automático queda preparado a la espera de que el Ayuntamiento facilite el formato y la dirección oficiales; mientras, descárguelo y súbalo a su portal.</p>
      ${chk("m360_activo", "Activar Madrid 360")}
      <div class="rejilla r2" style="gap:10px;margin-top:10px">
        <label class="campo">Código de aparcamiento autorizado<input class="ent" name="m360_codigo" value="${esc(c.m360_codigo || "")}"></label>
        <label class="campo">Envío${sel("m360_modo", [["manual", "Manual (descargar y subir al portal)"], ["automatico", "Automático (cuando esté disponible)"]])}</label>
        <label class="campo">Dirección de envío (automático)<input class="ent mono" name="m360_url" value="${esc(c.m360_url || "")}" placeholder="https://…"></label>
        <label class="campo">Hora del envío diario<input class="ent" type="time" name="m360_hora_envio" value="${esc(c.m360_hora_envio || "23:30")}"></label>
        <label class="campo">Usuario<input class="ent" name="m360_usuario" value="${esc(c.m360_usuario || "")}" autocomplete="off"></label>
        <label class="campo">Contraseña<input class="ent" type="password" name="m360_clave" value="${esc(c.m360_clave || "")}" autocomplete="new-password"></label>
      </div>
      <div class="fila" style="margin-top:12px"><button class="btn prim">Guardar</button></div>
      <h4 style="margin:18px 0 6px">Listados de los últimos días</h4>
      <table class="tabla"><tbody>${m3.dias.map((d) => `<tr><td class="num">${fechaCorta(d.dia)}</td><td class="num">${d.matriculas} matrícula(s)</td>
        <td>${d.envio ? `<span class="etiqueta ${d.envio.estado === "enviado" ? "e-pagado" : d.envio.estado === "error" ? "e-err" : "e-aviso"}">${{ enviado: "Comunicado", generado: "Descargado", error: "Error" }[d.envio.estado] || d.envio.estado}</span>` : '<span class="suave">—</span>'}</td>
        <td class="der" style="white-space:nowrap"><button type="button" class="btn" data-m3csv="${d.dia}" ${d.matriculas ? "" : "disabled"}>Descargar</button>
          ${d.envio && d.envio.estado === "enviado" ? "" : `<button type="button" class="btn" data-m3ok="${d.dia}" ${d.matriculas ? "" : "disabled"}>Marcar comunicado</button>`}</td></tr>`).join("")}</tbody></table>
    </form>

    <form class="panel mod-madrid360" id="f-lpr">
      <div class="fila" style="justify-content:space-between"><h3>Lector de matrículas por cámara</h3>
        <span class="etiqueta ${lpr.activo ? "e-pagado" : "e-salido"}">${lpr.activo ? "Activado" : "Desactivado"}</span></div>
      <p class="suave" style="margin:8px 0">Para cámaras con reconocimiento de matrículas (LPR/ANPR) o su software: cada lectura se envía por HTTP a este programa.
        En Entrada la matrícula aparece sola (o se emite el ticket); en Salida se busca el vehículo.</p>
      ${chk("lpr_activo", "Activar lector de matrículas")}
      <div class="rejilla r3" style="gap:10px;margin-top:10px">
        <label class="campo">Al leer en la entrada${sel("lpr_entrada_accion", [["sugerir", "Escribir la matrícula (el cajero confirma)"], ["emitir", "Emitir el ticket automáticamente"]])}</label>
        <label class="campo">Al leer en la salida${sel("lpr_salida_accion", [["sugerir", "Mostrar la matrícula"], ["buscar", "Buscar el vehículo automáticamente"]])}</label>
        <label class="campo">Confianza mínima (%)<input class="ent num" type="number" min="0" max="100" name="lpr_confianza_min" value="${esc(c.lpr_confianza_min || "80")}"></label>
      </div>
      <details style="margin-top:10px"><summary style="cursor:pointer;font-weight:600">Datos para configurar la cámara</summary>
        <p class="suave">Petición <b>POST</b> a <span class="mono">${esc(urlLpr)}</span> con la cabecera <span class="mono">X-Token-Camara: ${esc(lpr.token)}</span> y este cuerpo JSON:</p>
        <div class="serial">{"camara": "entrada", "matricula": "1234ABC", "confianza": 96}</div>
        <p class="ayuda">«camara» es entrada o salida. Para que la cámara llegue a este ordenador, arranque el programa permitiendo la red local (ver HARDWARE.md).</p></details>
      <div class="fila" style="margin-top:12px"><button class="btn prim">Guardar</button>
        <input class="ent mono" id="lpr-prueba" placeholder="1234ABC" style="width:140px;text-transform:uppercase">
        <button type="button" class="btn" data-sim="entrada">Simular lectura en entrada</button><button type="button" class="btn" data-sim="salida">… en salida</button></div>
    </form>

    <form class="panel mod-verifactu" id="f-vf">
      <div class="fila" style="justify-content:space-between"><h3>VERI*FACTU (AEAT)</h3>
        <span class="etiqueta ${vf.activo ? "e-aviso" : "e-salido"}">${vf.activo ? "Activado · sin envío a la AEAT" : "Desactivado"}</span></div>
      <p class="suave" style="margin:8px 0">Sistema de facturación verificable del Real Decreto 1007/2023: obligatorio desde el <b>1 de enero de 2027</b> para sociedades y desde el
        <b>1 de julio de 2027</b> para el resto (RDL 15/2025). Preparado: registro de cada factura con su huella encadenada según la Orden HAC/1177/2024 (comprobada con el ejemplo de la AEAT),
        código QR y leyenda «VERI*FACTU» en tickets y PDF, y XML del registro. <b>Pendiente</b>: el envío a la AEAT con el certificado electrónico de la empresa, las pruebas en el entorno
        de la AEAT y la declaración responsable. Actívelo solo cuando su asesoría lo indique.</p>
      ${chk("verifactu_activo", "Activar VERI*FACTU (registros, QR y leyenda en las facturas)")}
      <div class="rejilla r2" style="gap:10px;margin-top:10px">
        <label class="campo">Entorno del QR${sel("verifactu_entorno", [["pruebas", "Pruebas (preproducción AEAT)"], ["produccion", "Producción"]])}</label>
        <div class="campo">Emisor<div style="padding-top:10px"><b>${esc(vf.razon_social || "")}</b> · NIF ${esc(vf.nif || "")}</div></div>
      </div>
      <div class="fila" style="margin-top:12px"><button class="btn prim">Guardar</button>
        <span class="suave">${vf.total} registro(s) · ${vf.pendientes} pendiente(s) de enviar</span></div>
      ${vf.registros.length ? `<table class="tabla" style="margin-top:12px"><tbody>${vf.registros.slice(0, 10).map((r) => `<tr>
        <td class="mono">${esc(r.num_serie)}</td><td>${esc(r.fecha_expedicion)} · ${esc(r.tipo_factura)}</td><td class="der num">${eur(r.importe_cent)}</td>
        <td class="mono" style="font-size:.75rem">${esc(r.huella.slice(0, 16))}…</td><td><span class="etiqueta e-aviso">${esc(r.estado)}</span></td>
        <td class="der"><button type="button" class="btn" data-xml="${r.id}">XML</button></td></tr>`).join("")}</tbody></table>` : ""}
    </form></div>`;
  const guardar = (f, claves, despues) => (f.onsubmit = accion(async (e) => {
    e.preventDefault();
    const d = {};
    claves.forEach((k) => { const i = f.elements[k]; d[k] = i.type === "checkbox" ? (i.checked ? "1" : "0") : i.value; });
    if (d.verifactu_activo === "1" && c.verifactu_activo !== "1" &&
      !(await confirmar("Activar VERI*FACTU", "Las facturas llevarán el QR y la leyenda VERI*FACTU y se generarán sus registros. El envío a la AEAT todavía no está disponible. ¿Activar?", { boton: "Activar" }))) return vistaAjustes($("#vista"));
    await api("PUT", "/api/config", d);
    S.estado = await api("GET", "/api/estado");
    toast("Guardado", "ok");
    despues ? despues() : ajIntegraciones(el);
  }));
  guardar($("#f-m360"), ["m360_activo", "m360_codigo", "m360_modo", "m360_url", "m360_hora_envio", "m360_usuario", "m360_clave"]);
  guardar($("#f-lpr"), ["lpr_activo", "lpr_entrada_accion", "lpr_salida_accion", "lpr_confianza_min"]);
  guardar($("#f-vf"), ["verifactu_activo", "verifactu_entorno"], () => vistaAjustes($("#vista")));
  $$("[data-m3csv]", el).forEach((b) => (b.onclick = () => { descargarUrl("/api/m360/listado.csv", { dia: b.dataset.m3csv }); setTimeout(() => ajIntegraciones(el), 800); }));
  $$("[data-m3ok]", el).forEach((b) => (b.onclick = accion(async () => { await api("POST", "/api/m360/marcar", { dia: b.dataset.m3ok }); toast("Marcado como comunicado", "ok"); ajIntegraciones(el); })));
  $$("[data-xml]", el).forEach((b) => (b.onclick = () => descargarUrl(`/api/verifactu/${b.dataset.xml}.xml`, {})));
  $$("[data-sim]", el).forEach((b) => (b.onclick = accion(async () => {
    const mat = $("#lpr-prueba").value.trim() || "1234ABC";
    const r = await api("POST", "/api/lpr/lectura", { camara: b.dataset.sim, matricula: mat, confianza: 99 });
    toast(`Lectura ${r.camara}: ${r.matricula} → ${r.resultado}`, "ok");
  })));
});

// 1.8: Reservas online. 1.16: reorganizado en pestañas (General, Cupos y reglas, Cobro, Web de clientes, Probar en local).
// Es un solo formulario: «Guardar» guarda todas las pestañas; «Probar en local» actúa al momento.
const RO_PESTANAS = [["general", "General"], ["cupos", "Cupos y reglas"], ["cobro", "Cobro"], ["web", "Web de clientes"], ["prueba", "Probar en local"]];

const ajReservasOnline = accion(async (el) => {
  const [c, wp0] = await Promise.all([api("GET", "/api/reservas-online/config"), api("GET", "/api/reservas-online/web-pruebas").catch(() => ({ activa: false }))]);
  if (!el.isConnected) return;
  let wp = wp0;
  if (!RO_PESTANAS.some(([k]) => k === S.roTab)) S.roTab = "general";
  const num = (k, etq, ayuda, min, max) => `<label class="campo">${etq}<input class="ent num" type="number" name="${k}" min="${min}" max="${max}" value="${c[k]}">${ayuda ? `<span class="ayuda">${ayuda}</span>` : ""}</label>`;
  const hayCupo = c.zonas.length ? c.zonas.some((z) => z.cupo_online > 0) : Number(c.reservas_cupo) > 0;
  const punto = (ok, txt, donde) => `<li class="${ok ? "ok" : "falta"}"><span aria-hidden="true">${ok ? "✓" : "○"}</span> ${txt}${!ok && donde ? ` <button type="button" class="enlace" data-ir="${donde}">Configurar</button>` : ""}</li>`;
  el.innerHTML = `<form class="panel" id="f-ro" style="max-width:860px">
    <div class="fila" style="justify-content:space-between"><h3>Reservas online</h3>
      <span class="etiqueta ${c.activas ? "e-pagado" : "e-salido"}" id="ro-estado">${c.activas ? "Activadas" : "Desactivadas"}</span></div>
    <div id="ro-banner"></div>
    <div class="pestanas" id="ro-tabs" role="tablist" style="margin-top:12px">${RO_PESTANAS.map(([k, n]) => `<button type="button" role="tab" data-tab="${k}" class="${S.roTab === k ? "activo" : ""}">${n}</button>`).join("")}</div>

    <section data-sec="general" ${S.roTab === "general" ? "" : "hidden"}>
      <p class="suave" style="margin:0 0 10px">Permite reservar una plaza en una zona entre dos fechas, con antelación. Cada reserva queda con un código y, al entrar la matrícula, se enlaza sola con el ticket.
        El personal las crea en <b>Reservas</b> (teléfono o mostrador) y los clientes <b>solo online, desde la web del aparcamiento</b>. Apagado, el programa funciona como siempre y las reservas ya hechas se conservan.</p>
      <label class="fila" style="gap:10px;font-weight:600"><input type="checkbox" name="activas" ${c.activas ? "checked" : ""}> Activar las reservas online</label>
      <h4 style="margin:18px 0 6px">Qué falta para que funcione</h4>
      <ul class="ro-lista">${punto(c.activas, "Reservas online activadas", "")}${punto(hayCupo, "Alguna zona con plazas reservables", "cupos")}
        ${punto(c.publicas, "Reservas desde la web de clientes activadas", "web")}${punto(!!c.api_url, "Dirección del programa para la web escrita (solo al publicar la web)", "web")}</ul>
      <p class="ayuda">Guarda los cambios de cada pestaña con el botón Guardar de abajo.</p>
    </section>

    <section data-sec="cupos" ${S.roTab === "cupos" ? "" : "hidden"}>
      <h4 style="margin:0 0 6px">Plazas que se pueden reservar</h4>
      <p class="suave" style="margin:0 0 8px">Máximo de coches con reserva a la vez en cada zona: si pones 5, nunca habrá más de 5 coches con reserva en esa zona (cuentan los pendientes de llegar y los que ya han entrado y siguen dentro). El resto de plazas queda para quien llegue sin reserva. 0 = esa zona no admite reservas.</p>
      ${c.zonas.length ? `<div class="rejilla r3" style="gap:10px">${c.zonas.map((z) => `<label class="campo">${esc(z.nombre)} <span class="suave">(de ${z.capacidad || "?"} plazas)</span>
        <input class="ent num" type="number" min="0" data-zona="${z.id}" value="${z.cupo_online}"></label>`).join("")}</div>`
        : `<div class="rejilla r3">${num("reservas_cupo", "Plazas reservables", "El parking no tiene zonas: se usa un único cupo.", 0, 100000)}</div>`}
      <h4 style="margin:18px 0 6px">Reglas</h4>
      <div class="rejilla r3" style="gap:10px">
        ${num("reservas_antelacion_min_min", "Antelación mínima (minutos)", "Para reservas de clientes; el personal puede reservar para ya.", 0, 10080)}
        ${num("reservas_antelacion_max_dias", "Reservar con hasta (días)", "", 1, 730)}
        ${num("reservas_min_minutos", "Duración mínima de la reserva (minutos)", "Para reservas de clientes (0 = sin mínimo): una reserva más corta no se admite. El personal puede crearlas más cortas.", 0, 1440)}
        ${num("reservas_max_dias", "Duración máxima (días)", "", 1, 90)}
        ${num("reservas_cancel_horas", "Cancelación gratuita hasta (horas antes)", "Se aplica a las cancelaciones del cliente.", 0, 720)}
        ${num("reservas_noshow_min", "Liberar la plaza si no llega (minutos tras la entrada)", "0 = no se libera. Si el cliente no ha llegado pasado este tiempo, la reserva se cancela y la plaza queda libre. La señal pagada no se devuelve.", 0, 10080)}
        ${num("reservas_recordatorio_horas", "Recordatorio por email (horas antes de la entrada)", "0 = no se envía. Necesita el correo configurado. Lleva el código y el QR de la reserva.", 0, 168)}
        ${num("reservas_max_plazas", "Plazas por reserva (máximo)", "1 = cada reserva es de una plaza. Si es más, una reserva cuenta tantas plazas del cupo como pida.", 1, 50)}
      </div>
      <p class="ayuda" style="margin-top:8px">Solo se puede reservar con el parking abierto (Ajustes → Empresa → Horario del parking).</p>
    </section>

    <section data-sec="cobro" ${S.roTab === "cobro" ? "" : "hidden"}>
      <p class="suave" style="margin:0 0 8px">Cuándo paga el cliente su reserva.</p>
      <div class="metodos-cobro" role="radiogroup" aria-label="Cuándo se paga">${[
        ["parking", "Se paga en el parking", "No se cobra nada al reservar: se paga la tarifa al salir."],
        ["senal", "Pagar una señal", "Para mantener la reserva hay que pagar una parte; se descuenta del importe final."],
        ["total", "Pago anticipado", "Hay que pagar todo el importe de la reserva por adelantado."]]
        .map(([k, n, t]) => `<label class="opcion-cobro ${c.pago_modo === k ? "sel" : ""}"><input type="radio" name="pago_modo" value="${k}" ${c.pago_modo === k ? "checked" : ""}><span><b>${n}</b><small>${t}</small></span></label>`).join("")}</div>
      <div id="ro-senal" class="rejilla r3" style="gap:10px;margin-top:10px" ${c.pago_modo === "senal" ? "" : "hidden"}>
        <label class="campo">Señal<select class="ent" name="senal_tipo"><option value="fijo" ${c.senal_tipo === "fijo" ? "selected" : ""}>Importe fijo (€)</option><option value="porcentaje" ${c.senal_tipo === "porcentaje" ? "selected" : ""}>Porcentaje del importe (%)</option></select></label>
        <label class="campo">Cuánto<input class="ent num" name="senal_valor" inputmode="decimal" value="${c.senal_tipo === "porcentaje" ? c.senal_valor : (c.senal_valor / 100).toString().replace(".", ",")}"></label></div>
      <div id="ro-pago" style="margin-top:10px" ${c.pago_modo === "parking" ? "hidden" : ""}>
        <div class="rejilla r3" style="gap:10px">${num("reservas_pago_horas", "Plazo para pagar (horas)", "Si no se paga a tiempo, la reserva se cancela sola y la plaza queda libre.", 1, 720)}</div>
        <label class="campo" style="margin-top:10px">Cómo pagar (se enseña al cliente y va en el email)<textarea class="ent" name="pago_instrucciones" rows="2" maxlength="500"
          placeholder="Por ejemplo: Bizum al 600 111 222 o transferencia a ES00 0000 0000 0000 0000 0000, indicando el código de la reserva.">${esc(c.pago_instrucciones)}</textarea></label>
        <label class="fila" style="gap:10px;font-weight:600;margin-top:12px"><input type="checkbox" name="pago_online" ${c.pago_online ? "checked" : ""}> Cobrar con tarjeta en la propia página (Stripe)</label>
        <p class="ayuda" style="margin-top:4px">El cliente paga la señal con tarjeta al reservar: la reserva se confirma sola y, si la cancela, la señal se devuelve sola. ${c.stripe_listo ? "" : '<b style="color:var(--rojo)">Primero active los pagos online con Stripe en Ajustes → Pagos online.</b> '}Necesita la «Página de reservas en su web» (pestaña Web de clientes), a la que vuelve el cliente tras pagar.</p>
        <p class="ayuda">Si no usa la tarjeta, el personal anota el cobro en <b>Reservas</b> con «Señal cobrada» (Bizum, transferencia, en mostrador…). Sea como sea, al entrar el vehículo la señal pagada se anota como <b>pago anticipado del ticket</b> y se descuenta sola al cobrar la salida. Si se cancela una reserva con la señal pagada, se devuelve sola (tarjeta) o queda marcada «Devolver señal».</p></div>
    </section>

    <section data-sec="web" ${S.roTab === "web" ? "" : "hidden"}>
      <p class="suave" style="margin:0 0 8px">Los clientes reservan <b>con antelación y solo online</b>, desde la web del aparcamiento. Esa web habla con el programa por una API pública, sin contraseña: pide nombre, email y matrícula,
        envía la confirmación por email (si hay servidor de correo en Ajustes → Email) y permite cancelar con el código y la matrícula. Está limitada por IP y protegida contra robots.</p>
      <label class="fila" style="gap:10px;font-weight:600"><input type="checkbox" name="publicas" ${c.publicas ? "checked" : ""}> Aceptar reservas desde la web</label>
      <div class="rejilla r2" style="gap:10px;margin-top:10px">
        <label class="campo">Página de reservas en su web<input class="ent mono" name="web_url" value="${esc(c.web_url)}" placeholder="https://www.mi-parking.es/reservas" maxlength="200" autocomplete="off" spellcheck="false">
          <span class="ayuda">El email de confirmación enlaza aquí para ver o cancelar la reserva (se añade <span class="mono">?c=CÓDIGO</span>). Vacía = el email no lleva enlace.</span></label>
        <label class="campo">Dirección del programa visible desde la web (API)<input class="ent mono" name="api_url" value="${esc(c.api_url)}" placeholder="https://reservas.mi-parking.es" maxlength="200" autocomplete="off" spellcheck="false">
          <span class="ayuda">Con la que se llega a este programa desde Internet. Va dentro del kit para la web.</span></label></div>
      <label class="campo" style="margin-top:10px">Condiciones que acepta el cliente (opcional)<textarea class="ent" name="condiciones" rows="4" maxlength="2000"
        placeholder="Si se deja vacío se usa un texto estándar: pago en el parking, cancelación gratuita y uso de los datos solo para la reserva.">${esc(c.condiciones)}</textarea></label>
      <details class="plegable" style="margin-top:12px"${c.origenes || c.proxies || c.internet ? " open" : ""}><summary><b>Opciones avanzadas para publicar la web en Internet</b></summary>
        <div class="rejilla r2" style="gap:10px;margin-top:10px">
          <label class="campo">Webs autorizadas<input class="ent mono" name="origenes" value="${esc(c.origenes)}" placeholder="https://www.mi-parking.es" maxlength="500" autocomplete="off" spellcheck="false">
            <span class="ayuda">Dominios desde los que la web puede reservar (separados por comas). Sin esto, el navegador bloquea la reserva. «*» las permite desde cualquier web.</span></label>
          <label class="campo">Proxy de confianza (opcional)<input class="ent mono" name="proxies" value="${esc(c.proxies)}" placeholder="192.168.1.5" maxlength="200" autocomplete="off" spellcheck="false">
            <span class="ayuda">IP del proxy o servidor web que reenvía las peticiones. Así el límite de peticiones se aplica a cada cliente y no al proxy.</span></label></div>
        <label class="fila" style="gap:10px;margin-top:10px"><input type="checkbox" name="internet" ${c.internet ? "checked" : ""}> Aceptar peticiones que llegan desde Internet (solo con HTTPS y detrás de un proxy)</label>
        <p class="ayuda" style="margin-top:4px">Desmarcado, la API solo responde dentro de la red local. Solo se abre <span class="mono">/api/publico/reservas</span>; el resto del programa nunca se sirve desde Internet.</p></details>
      <details class="plegable" style="margin-top:12px"${c.relay_activo ? " open" : ""}><summary><b>Servidor en la nube (recomendado para publicar en Internet)</b></summary>
        <p class="suave" style="margin:8px 0">En vez de abrir este equipo a Internet, ponga el pequeño servidor de reservas en un hosting o servidor: <b>este programa llama a ese servidor</b> (conexión saliente)
          y atiende las reservas. Los clientes nunca llegan a este PC, y si está apagado ven «servicio no disponible». Las instrucciones vienen en el paquete.</p>
        <label class="fila" style="gap:10px;font-weight:600"><input type="checkbox" name="relay_activo" ${c.relay_activo ? "checked" : ""}> Usar el servidor en la nube</label>
        <div class="rejilla r2" style="gap:10px;margin-top:10px">
          <label class="campo">Dirección del servidor<input class="ent mono" name="relay_url" value="${esc(c.relay_url)}" placeholder="https://reservas.mi-parking.es" maxlength="200" autocomplete="off" spellcheck="false"></label>
          <label class="campo">Clave compartida<input class="ent mono" name="relay_token" type="password" value="" placeholder="${c.relay_token_puesto ? "•••••••• guardada (vacío = no cambiar)" : "mínimo 24 caracteres"}" maxlength="100" autocomplete="new-password" spellcheck="false">
            <span class="ayuda">La misma que se pone en el servidor (variable ALLAS_RELAY_TOKEN). <button type="button" class="enlace" id="ro-gen-clave">Generar una nueva</button></span></label></div>
        <div class="fila" style="margin-top:10px;gap:10px;flex-wrap:wrap;align-items:center"><button type="button" class="btn" id="ro-relay-probar">Guardar y probar conexión</button>
          <button type="button" class="btn" id="ro-relay-zip">Descargar el servidor (zip)</button><span id="ro-relay-estado" class="suave"></span></div></details>
      <div class="fila" style="margin-top:12px;gap:10px;flex-wrap:wrap"><button type="button" class="btn" id="ro-kit">Descargar kit para la web</button>
        <span class="suave">Guarda antes los cambios: la dirección de la API se escribe en el kit. Dentro vienen las instrucciones (LEEME).</span></div>
    </section>

    <section data-sec="prueba" ${S.roTab === "prueba" ? "" : "hidden"}>
      <div id="ro-prueba"></div>
    </section>

    <div class="fila" style="margin-top:16px;gap:12px;flex-wrap:wrap;align-items:center"><button class="btn prim">Guardar</button>
      <span class="suave">Guarda las cuatro primeras pestañas. «Probar en local» actúa al momento.</span></div>
  </form>`;

  // --- web local de pruebas: botón, dirección y QR (también un aviso arriba, visible desde cualquier pestaña)
  const pintarPrueba = () => {
    $("#ro-banner", el).innerHTML = wp.activa ? `<div class="aviso ro-banner">Web de pruebas activa: <a class="mono" href="${esc(wp.url)}" target="_blank" rel="noopener">${esc(wp.url)}</a>
      <button type="button" class="enlace" data-ir="prueba">Ver código QR</button></div>` : "";
    $("#ro-prueba", el).innerHTML = `<div class="fila" style="justify-content:space-between;gap:10px;flex-wrap:wrap"><h4 style="margin:0">Web local de pruebas</h4>
        <span class="etiqueta ${wp.activa ? "e-pagado" : "e-salido"}">${wp.activa ? "Activa" : "Desactivada"}</span></div>
      <p class="suave" style="margin:6px 0 10px">Levanta en este equipo una web que se comporta como la web del aparcamiento, para probar todo el recorrido del cliente (reservar, ver el código, consultar y cancelar) sin publicar nada en Internet
        y sin configurar «Webs autorizadas». Las reservas que se hagan aquí son reales: aparecen en Reservas (cancélalas después). Se apaga sola al cerrar el programa.</p>
      ${wp.reservas_listas ? "" : '<div class="aviso" style="margin-bottom:10px">Para poder reservar desde la web de pruebas hay que <b>activar las reservas online</b> y <b>aceptar reservas desde la web</b> (y guardar), y tener al menos una zona con plazas reservables.</div>'}
      <label class="fila" style="gap:10px"><input type="checkbox" id="ro-wp-red" ${wp.red ? "checked" : ""}> También desde otros dispositivos de la red (por ejemplo, el móvil)</label>
      <div class="fila" style="margin-top:10px"><button type="button" class="btn ${wp.activa ? "" : "prim"}" id="ro-wp-btn">${wp.activa ? "Desactivar la web de pruebas" : "Activar la web de pruebas"}</button></div>
      ${wp.activa ? `<div class="web-pruebas"><div class="qr-img" id="ro-wp-qr" role="img" aria-label="Código QR de la dirección de la web de pruebas">${wp.qr}</div>
        <div><b>Dirección de la web de pruebas</b>
          <p style="margin:6px 0"><a class="mono ro-dir" href="${esc(wp.url)}" target="_blank" rel="noopener">${esc(wp.url)}</a></p>
          <div class="fila" style="gap:8px;flex-wrap:wrap"><button type="button" class="btn" id="ro-wp-copiar">Copiar dirección</button><a class="btn" href="${esc(wp.url)}" target="_blank" rel="noopener">Abrir</a></div>
          ${wp.red ? `<p class="ayuda" style="margin-top:8px">Escanea el QR con el móvil (en la misma red Wi-Fi que este equipo).${wp.urls.length > 1 ? " Otras direcciones de este equipo: " + wp.urls.slice(1).map((u) => `<span class="mono">${esc(u)}</span>`).join(", ") : ""}</p>`
            : '<p class="ayuda" style="margin-top:8px">Ahora solo se abre en este equipo. Marca «También desde otros dispositivos de la red» para probarla con el móvil.</p>'}</div></div>` : ""}`;
    const cambiar = (activa) => accion(async () => {
      wp = await api("POST", "/api/reservas-online/web-pruebas", { activa, red: $("#ro-wp-red", el).checked });
      toast(activa ? "Web de pruebas activada" : "Web de pruebas desactivada", "ok");
      pintarPrueba();
    });
    $("#ro-wp-btn", el).onclick = cambiar(!wp.activa);
    $("#ro-wp-red", el).onchange = () => { if (wp.activa) cambiar(true)(); };
    if ($("#ro-wp-copiar", el)) $("#ro-wp-copiar", el).onclick = async () => { await copiarTexto(wp.url); toast("Dirección copiada", "ok"); };
  };
  const irA = (k) => { S.roTab = k; $$("[data-tab]", el).forEach((b) => b.classList.toggle("activo", b.dataset.tab === k)); $$("[data-sec]", el).forEach((s) => (s.hidden = s.dataset.sec !== k)); };
  el.addEventListener("click", (e) => {
    const b = e.target.closest("[data-tab],[data-ir]");
    if (b) irA(b.dataset.tab || b.dataset.ir);
  });
  pintarPrueba();

  $("#f-ro", el).onsubmit = accion(async (e) => {
    e.preventDefault();
    const f = e.target;
    const modo = f.pago_modo.value, tipo = f.senal_tipo.value;
    const valor = tipo === "porcentaje" ? Math.round(Number(String(f.senal_valor.value).replace(",", ".")) || 0) : aCent(f.senal_valor.value || "0");
    if (Number.isNaN(valor)) throw new Error("Importe de la señal no válido");
    const d = { activas: f.activas.checked, publicas: f.publicas.checked, api_url: f.api_url.value, web_url: f.web_url.value, origenes: f.origenes.value, proxies: f.proxies.value, internet: f.internet.checked, condiciones: f.condiciones.value, pago_online: f.pago_online ? f.pago_online.checked : false,
      relay_activo: f.relay_activo.checked, relay_url: f.relay_url.value, relay_token: f.relay_token.value,
      pago_modo: modo, senal_tipo: tipo, senal_valor: valor, pago_instrucciones: f.pago_instrucciones.value, zonas: $$("[data-zona]", f).map((i) => ({ id: Number(i.dataset.zona), cupo_online: Number(i.value || 0) })) };
    ["reservas_cupo", "reservas_antelacion_min_min", "reservas_antelacion_max_dias", "reservas_min_minutos", "reservas_max_dias", "reservas_cancel_horas", "reservas_max_plazas", "reservas_pago_horas", "reservas_noshow_min", "reservas_recordatorio_horas"].forEach((k) => { if (f[k]) d[k] = f[k].value; });
    await api("PUT", "/api/reservas-online/config", d);
    S.reservasOnline = d.activas;
    toast(d.activas ? "Reservas online activadas" : "Reservas online desactivadas", "ok");
    ajReservasOnline(el);
  });
  $$("[name=pago_modo]", el).forEach((r) => (r.onchange = () => {
    $("#ro-senal", el).hidden = r.value !== "senal"; $("#ro-pago", el).hidden = r.value === "parking";
    $$(".opcion-cobro", el).forEach((o) => o.classList.toggle("sel", o.querySelector("input").checked));
  }));
  $("#ro-kit", el).onclick = () => descargarUrl("/api/reservas-online/kit.zip", {});
  // --- servidor en la nube: estado, clave, prueba y descarga
  const pintarRelay = (e) => {
    const t = $("#ro-relay-estado", el);
    if (!t || !e) return;
    t.innerHTML = !e.activo ? "Desactivado" : e.conectado ? '<b style="color:var(--verde)">Conectado</b> con el servidor' : e.error ? `<b style="color:var(--rojo)">${esc(e.error)}</b>` : "Conectando…";
  };
  api("GET", "/api/reservas-online/relay").then(pintarRelay).catch(() => {});
  $("#ro-gen-clave", el).onclick = () => {
    const b = new Uint8Array(32); crypto.getRandomValues(b);
    const clave = btoa(String.fromCharCode(...b)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
    const campo = $("[name=relay_token]", el); campo.type = "text"; campo.value = clave;
    toast("Clave generada: cópiela ahora al servidor (después ya no se muestra)", "ok");
  };
  $("#ro-relay-zip", el).onclick = () => descargarUrl("/api/reservas-online/servidor.zip", {});
  $("#ro-relay-probar", el).onclick = accion(async () => {
    const f = $("#f-ro", el);
    const c0 = await api("GET", "/api/reservas-online/config");
    await api("PUT", "/api/reservas-online/config", { ...c0, relay_activo: f.relay_activo.checked, relay_url: f.relay_url.value, relay_token: f.relay_token.value });
    f.relay_token.value = ""; f.relay_token.type = "password";
    f.relay_token.placeholder = "•••••••• guardada (vacío = no cambiar)";
    const e = await api("POST", "/api/reservas-online/relay", { probar: true });
    pintarRelay(e);
    toast(e.prueba.ok ? e.prueba.mensaje : e.prueba.mensaje, e.prueba.ok ? "ok" : "err");
  });
});

// 1.9: horario del parking. Con el horario activado no se dan entradas ni salidas fuera de él (los supervisores sí pueden, para urgencias).
const ajHorario = accion(async (el) => {
  const h = await api("GET", "/api/horario");
  if (!el.isConnected) return;
  el.innerHTML = `<form class="panel" id="f-hr" style="max-width:760px">
    <div class="fila" style="justify-content:space-between"><h3>Horario del parking</h3>
      <span class="etiqueta ${h.activo ? (h.abierto_ahora ? "e-pagado" : "e-err") : "e-salido"}">${h.activo ? (h.abierto_ahora ? "Abierto ahora" : "Cerrado ahora") : "Sin horario (siempre abierto)"}</span></div>
    <p class="suave" style="margin:8px 0">Con el horario activado, <b>no se dan entradas ni salidas</b> con el parking cerrado (caja, lector de matrículas y abonados) y tampoco se aceptan reservas
      cuya entrada o salida caiga fuera de horario. Los supervisores y administradores pueden operar igualmente, por si hay una urgencia.</p>
    <label class="fila" style="gap:10px;font-weight:600;margin-top:10px"><input type="checkbox" name="activo" ${h.activo ? "checked" : ""}> Activar el horario</label>
    <table class="tabla" style="margin-top:12px"><thead><tr><th>Día</th><th>Abierto</th><th>24 h</th><th>Abre</th><th>Cierra</th></tr></thead><tbody>
    ${h.dias.map((n, i) => { const d = h.semana[String(i + 1)]; return `<tr data-dia="${i + 1}"><td style="text-transform:capitalize">${esc(n)}</td>
      <td><input type="checkbox" data-k="abierto" ${d.abierto ? "checked" : ""}></td><td><input type="checkbox" data-k="24h" ${d["24h"] ? "checked" : ""}></td>
      <td><input class="ent" type="time" data-k="desde" value="${esc(d.desde)}"></td><td><input class="ent" type="time" data-k="hasta" value="${esc(d.hasta)}"></td></tr>`; }).join("")}
    </tbody></table>
    <p class="ayuda">Para cerrar a medianoche pon «Cierra» 00:00. Si «Cierra» es anterior a «Abre» la franja pasa de medianoche (por ejemplo 20:00 a 06:00).</p>
    <label class="campo" style="margin-top:12px">Festivos: uno por línea, AAAA-MM-DD. Tienen el mismo horario que los domingos.
      <textarea class="ent" name="cerrados" rows="4" placeholder="2026-12-25">${esc(h.cerrados.join("\n"))}</textarea></label>
    <div class="fila" style="margin-top:14px"><button class="btn prim">Guardar</button></div>
  </form>`;
  $("#f-hr", el).onsubmit = accion(async (e) => {
    e.preventDefault();
    const f = e.target, semana = {};
    $$("[data-dia]", f).forEach((tr) => { const g = (k) => $(`[data-k="${k}"]`, tr); semana[tr.dataset.dia] = { abierto: g("abierto").checked, "24h": g("24h").checked, desde: g("desde").value, hasta: g("hasta").value }; });
    await api("PUT", "/api/horario", { activo: f.activo.checked, semana, cerrados: f.cerrados.value.split(/\s+/).filter(Boolean) });
    toast("Horario guardado", "ok");
    ajHorario(el);
  });
});
