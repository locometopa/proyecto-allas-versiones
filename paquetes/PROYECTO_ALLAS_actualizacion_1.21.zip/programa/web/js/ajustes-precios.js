/* PROYECTO ALLAS · Ajustes → Precios */
"use strict";

// ===================================================================== Tarifas

// --- tarifas
const ajTarifas = accion(async (el) => {
  await cargarTarifas();
  el.innerHTML = `<div class="fila" style="margin-bottom:14px"><button class="btn prim" id="b-nueva-t">Nueva tarifa</button>
    <button class="btn" id="b-exp-t" title="Exportar o importar tarifas, servicios y clientes">Importar / exportar…</button>
    <span class="suave">Al editar una tarifa ya usada se crea una versión nueva: los vehículos que ya están dentro pagan con la tarifa con la que entraron.</span></div>
    <div class="rejilla r2">${S.tarifas.map((t) => `<div class="panel">
      <div class="fila" style="justify-content:space-between"><h3>${esc(t.nombre)}</h3>
        <div>${t.por_defecto ? '<span class="etiqueta e-dentro">Por defecto</span>' : ""} ${t.activa ? "" : '<span class="etiqueta e-salido">Inactiva</span>'}</div></div>
      ${t.modo === "reserva" ? `<p style="margin:6px 0"><span class="etiqueta e-abonado">Reserva / hotel</span>
        ${t.reserva_modo === "fecha" || t.reserva_modo === "horas" ? "por fecha: entrada y salida reservadas" : `${t.reserva_noches} noche${t.reserva_noches > 1 ? "s" : ""} · salida a las ${esc(t.reserva_hora || "12:00")}`}
        · después: <b>${esc((S.tarifas.find((x) => x.id === t.tarifa_despues_id) || {}).nombre || "la tarifa por defecto")}</b></p>`
      : `<p class="suave" style="margin:6px 0">${t.evento_desde ? `<span class="etiqueta e-aviso">Evento ${fechaCorta2(t.evento_desde)}${t.evento_hasta && t.evento_hasta !== t.evento_desde ? "–" + fechaCorta2(t.evento_hasta) : ""}</span> ` : ""}${t.tipo_vehiculo ? `<span class="etiqueta e-abonado">${esc(t.tipo_vehiculo)}</span> ` : ""}${t.modo === "hibrida" ? '<span class="etiqueta e-factura">Precio fijo + después</span> ' : ""}Cortesía ${t.gracia_min} min · Máximo diario ${t.maximo_diario_cent == null ? "sin tope" : eur(t.maximo_diario_cent)}${t.redondeo && t.redondeo !== "ninguno" ? ` · Redondeo a 0,05 € (${({ cercano: "al más cercano", arriba: "hacia arriba", abajo: "hacia abajo" })[t.redondeo]})` : ""}</p>`}
      ${t.texto_ticket ? `<div class="aviso" style="margin:6px 0;font-weight:500">En el ticket: «${esc(t.texto_ticket)}»</div>` : ""}
      ${t.modo === "reserva" ? `<p class="suave" style="margin:6px 0;font-size:.88rem">El tiempo de la reserva no se cobra (está pagado en el hotel o en la web de reservas); al terminar se cobra con la tarifa de después, contando desde el fin de la reserva.</p>` : `<table class="tabla"><thead><tr><th>Desde</th><th>Hasta</th><th class="der">Precio</th></tr></thead><tbody>
      ${t.tramos.map((r) => `<tr><td>${r.desde_min} min</td><td>${r.hasta_min == null ? "en adelante" : r.hasta_min + " min"}</td>
        <td class="der num">${(r.precio_mil / 1000).toFixed(3).replace(".", ",")} € / ${r.fraccion_min} min</td></tr>`).join("")}</tbody></table>`}
      <div class="fila" style="margin-top:12px">${t.activa ? `<button class="btn" data-edit="${t.id}">Editar</button>
          <button class="btn" data-sube="${t.id}" aria-label="Subir ${esc(t.nombre)} en el selector" title="Subir en el selector de Entrada"><span aria-hidden="true">↑</span></button>
          <button class="btn" data-baja="${t.id}" aria-label="Bajar ${esc(t.nombre)} en el selector" title="Bajar en el selector de Entrada"><span aria-hidden="true">↓</span></button>` : '<span class="suave" style="font-size:.85rem">Versión anterior (la usan tickets ya emitidos)</span>'}
        ${t.activa && t.por_defecto ? "" : menuAcciones([{ attr: `data-borrar-t="${t.id}"`, texto: "Eliminar tarifa", peligro: true }])}</div></div>`).join("")}</div>`;
  $("#b-nueva-t").onclick = () => modalTarifa(null, el);
  $("#b-exp-t").onclick = () => irImportarExportar();
  // 4.43: orden de las tarifas en el selector de Entrada
  const mover = (id, dir) => accion(async () => {
    const ids = S.tarifas.map((x) => x.id);
    const i = ids.indexOf(id);
    let j = i + dir;
    while (j >= 0 && j < ids.length && !S.tarifas.find((x) => x.id === ids[j]).activa) j += dir;   // salta las versiones antiguas
    if (j < 0 || j >= ids.length) return;
    [ids[i], ids[j]] = [ids[j], ids[i]];
    await api("POST", "/api/tarifas/orden", { ids });
    ajTarifas(el);
  })();
  $$("[data-sube]").forEach((b) => (b.onclick = () => mover(Number(b.dataset.sube), -1)));
  $$("[data-baja]").forEach((b) => (b.onclick = () => mover(Number(b.dataset.baja), 1)));
  $$("[data-edit]").forEach((b) => (b.onclick = () => modalTarifa(S.tarifas.find((t) => t.id === Number(b.dataset.edit)), el)));
  $$("[data-borrar-t]").forEach((b) => (b.onclick = accion(async () => {
    const t = S.tarifas.find((x) => x.id === Number(b.dataset.borrarT));
    if (!(await confirmar("Eliminar tarifa", `¿Eliminar la tarifa <b>${esc(t.nombre)}</b>?<br><span class="suave">Si ya hay tickets con ella se oculta (los vehículos que estén dentro la siguen pagando igual); si no, se borra.</span>`,
      { boton: "Eliminar", peligro: true }))) return;
    const r = await api("DELETE", `/api/tarifas/${t.id}`);
    toast(`Tarifa «${t.nombre}» eliminada.${r.aviso || ""}`, "ok");
    ajTarifas(el);
  })));
});

function modalTarifa(t, el) {
  const tramos = t && t.tramos.length ? t.tramos.map((x) => ({ ...x })) : [{ desde_min: 0, hasta_min: null, fraccion_min: 1, precio_mil: 45 }];
  const modoIni = (t && t.modo) || "tramos";
  const hib = modoIni === "hibrida" && tramos.length === 2 ? tramos : [{ hasta_min: 120, precio_mil: 3000 }, { fraccion_min: 60, precio_mil: 1500 }];
  const otras = (S.tarifas || []).filter((x) => x.activa && x.modo !== "reserva" && (!t || x.id !== t.id));
  const c = modal(`<h2>${t ? "Editar" : "Nueva"} tarifa</h2>
    <div class="tipos-tarifa" style="margin-top:12px">${[["tramos", "Por tiempo", "Tramos y fracciones (por minuto, por hora…)"],
      ["hibrida", "Precio fijo + después", "Un precio cerrado durante un tiempo y, pasado, por tiempo"],
      ["reserva", "Reserva / hotel", "El tiempo reservado no se cobra; después, la tarifa del parking"]]
      .map(([v, n, d]) => `<label><input type="radio" name="t-modo" value="${v}" ${modoIni === v ? "checked" : ""}><b>${n}</b><span class="suave">${d}</span></label>`).join("")}</div>
    <div class="rejilla r3" style="margin-top:12px">
      <label class="campo">Nombre<input class="ent" id="t-nom" value="${esc(t ? t.nombre : "")}" autofocus></label>
      <label class="campo">Cortesía (min)<input class="ent" id="t-gra" type="number" min="0" value="${t ? t.gracia_min : 0}"></label>
      <label class="campo">Máximo por 24 h (€) <span class="ayuda">vacío = sin tope</span><input class="ent" id="t-max" inputmode="decimal" value="${t && t.maximo_diario_cent != null ? aEurTxt(t.maximo_diario_cent) : ""}"></label>
    </div>
    <div class="rejilla r2" style="margin-top:12px">
      <label class="campo">Redondeo del importe <span class="ayuda">a importes acabados en 0 o 5 céntimos</span>
        <select class="ent" id="t-red">${[["ninguno", "Sin redondeo (al céntimo)"], ["cercano", "Al 0,05 € más cercano"], ["arriba", "Al 0,05 € hacia arriba"], ["abajo", "Al 0,05 € hacia abajo"]]
          .map(([v, n]) => `<option value="${v}" ${(t?.redondeo || "ninguno") === v ? "selected" : ""}>${n}</option>`).join("")}</select></label>
      <label class="campo">Texto en el ticket de entrada <span class="ayuda">opcional</span>
        <textarea class="ent" id="t-txt" rows="2" maxlength="300" placeholder="Ej.: Tarifa válida de 8 a 22 h">${esc(t?.texto_ticket || "")}</textarea></label>
    </div>
    <label class="fila t-no-res" style="margin-top:12px;font-weight:600"><input type="checkbox" id="t-def" ${!t || t.por_defecto ? "checked" : ""}> Tarifa por defecto para nuevas entradas</label>
    <div class="panel t-sec" id="t-sec-res" style="margin-top:14px;background:var(--fondo)"><h3>Tiempo incluido en la reserva</h3>
      <div class="rejilla r3" style="margin-top:10px">
        <label class="campo">Reserva por<select class="ent" id="t-rmodo"><option value="noches" ${(t?.reserva_modo || "noches") === "noches" ? "selected" : ""}>Noches (hotel)</option>
          <option value="fecha" ${["fecha", "horas"].includes(t?.reserva_modo) ? "selected" : ""}>Por fecha (entrada y salida)</option></select></label>
        <label class="campo t-r-noches">Noches por defecto<input class="ent num" id="t-rnoches" type="number" min="1" max="60" value="${t?.reserva_noches || 1}"></label>
        <label class="campo">Hora de salida <span class="ayuda">check-out (se propone al escribir la fecha de salida)</span><input class="ent" id="t-rhora" type="time" value="${esc(t?.reserva_hora || "12:00")}"></label>
        <label class="campo">Después se cobra con<select class="ent" id="t-rdesp"><option value="">La tarifa por defecto</option>
          ${otras.map((x) => `<option value="${x.id}" ${t?.tarifa_despues_id === x.id ? "selected" : ""}>${esc(x.nombre)}</option>`).join("")}</select></label></div>
      <p class="ayuda" style="margin:8px 0 0">Al registrar la entrada con esta tarifa se puede cambiar el nº de noches u horas y anotar el nº de reserva o la habitación. Pasado el tiempo reservado, se cobra desde el fin de la reserva con la tarifa elegida (con su cortesía y su máximo diario).</p></div>
    <div class="panel t-sec" id="t-sec-hib" style="margin-top:14px;background:var(--fondo)"><h3>Precio fijo y después</h3>
      <div class="rejilla r2" style="margin-top:10px">
        <label class="campo">Tiempo del precio fijo (min)<input class="ent num" id="t-h-min" type="number" min="1" value="${hib[0].hasta_min}"></label>
        <label class="campo">Precio fijo (€)<input class="ent num" id="t-h-pre" inputmode="decimal" value="${aEurTxt(Math.round(hib[0].precio_mil / 10))}"></label>
        <label class="campo">Después, cada (min)<input class="ent num" id="t-h-fr" type="number" min="1" value="${hib[1].fraccion_min}"></label>
        <label class="campo">Precio por fracción (€)<input class="ent num" id="t-h-p2" inputmode="decimal" value="${String(hib[1].precio_mil / 1000).replace(".", ",")}"></label></div>
      <p class="ayuda" style="margin:8px 0 0">Ejemplo: 3,00 € las 2 primeras horas y después 1,50 € cada hora.</p></div>
    <details class="plegable t-no-res ${tieneModulo("tarifas_avanzadas") ? "" : "oculto"}" style="margin-top:12px" ${t && (t.horario_dias || t.horario_desde) ? "open" : ""}><summary><h3>Horario (tarifa automática)</h3>
      <span class="suave">nocturna, fin de semana… se aplica sola a las entradas en ese horario</span></summary>
      <div class="campo" style="margin-top:10px">Días <span class="ayuda">ninguno marcado = todos</span>
        <div class="dias-semana">${[["1", "L"], ["2", "M"], ["3", "X"], ["4", "J"], ["5", "V"], ["6", "S"], ["7", "D"]].map(([d, n]) => `<label class="dia ${(t?.horario_dias || "").includes(d) ? "on" : ""}"><input type="checkbox" class="t-dia" value="${d}" ${(t?.horario_dias || "").includes(d) ? "checked" : ""}>${n}</label>`).join("")}</div></div>
      <div class="rejilla r3" style="margin-top:10px">
        <label class="campo">Desde <span class="ayuda">vacío = todo el día</span><input class="ent" type="time" id="t-hd" value="${esc(t?.horario_desde || "")}"></label>
        <label class="campo">Hasta<input class="ent" type="time" id="t-hh" value="${esc(t?.horario_hasta || "")}"></label>
        <p class="ayuda" style="align-self:end;margin:0">Puede cruzar la medianoche (22:00 → 08:00): cuenta para el día en que empieza.</p></div>
      <p class="ayuda" style="margin:8px 0 0">Al registrar una entrada con «Tarifa: automática» se usa la tarifa cuyo horario coincide con la hora de entrada (la más concreta si hay varias); si ninguna coincide, la de por defecto.</p></details>
    <details class="plegable t-no-res ${tieneModulo("tarifas_avanzadas") ? "" : "oculto"}" style="margin-top:12px" ${t && (t.evento_desde || t.tipo_vehiculo) ? "open" : ""}><summary><h3>Evento o tipo de vehículo</h3>
      <span class="suave">partido, concierto, feria… o solo para motos, furgonetas, autocaravanas</span></summary>
      <div class="rejilla r3" style="margin-top:10px">
        <label class="campo">Evento: desde<input class="ent" type="date" id="t-evd" value="${esc(t?.evento_desde || "")}"></label>
        <label class="campo">hasta<input class="ent" type="date" id="t-evh" value="${esc(t?.evento_hasta || "")}"></label>
        <label class="campo">Tipo de vehículo<select class="ent" id="t-tveh"><option value="">Todos</option>
          ${[...new Set([...((S.estado && S.estado.tipos_vehiculo) || ["Coche", "Moto", "Furgoneta", "Autocaravana"]), ...(t?.tipo_vehiculo ? [t.tipo_vehiculo] : [])])]
            .map((x) => `<option ${t?.tipo_vehiculo === x ? "selected" : ""}>${esc(x)}</option>`).join("")}</select></label></div>
      <div class="fila" style="margin-top:10px;align-items:flex-end">
        <label class="campo">Precio cerrado por día (€) <span class="ayuda">opcional</span><input class="ent num" id="t-pcerr" inputmode="decimal" style="width:140px"></label>
        <button type="button" class="btn" id="t-pcerr-ok">Aplicar a los tramos</button></div>
      <p class="ayuda" style="margin:8px 0 0">En las fechas del evento, las entradas con «Tarifa: automática» usan esta tarifa (gana a las de horario). Con un tipo de vehículo,
        se usa cuando en Entrada se elige ese tipo. El «precio cerrado» deja un único tramo: el mismo precio por cada día o fracción.</p></details>
    <div class="t-sec" id="t-sec-tramos"><h3 style="margin-top:18px">Tramos</h3>
    <p class="suave" style="margin:4px 0 8px">La ley española exige cobrar por minuto efectivo (fracción 1 min) salvo excepciones.</p>
    <table class="tabla"><thead><tr><th>Desde (min)</th><th>Hasta (min)</th><th>Fracción (min)</th><th>Precio por fracción (€)</th><th></th></tr></thead><tbody id="t-tramos"></tbody></table>
    <button class="btn" id="t-add" style="margin-top:8px">Añadir tramo</button></div>
    <div class="panel t-no-res" style="margin-top:16px;background:var(--fondo)"><div class="fila">
      <b>Simulador</b><input class="ent" id="t-sim" type="number" min="0" value="90" style="width:110px"> minutos →
      <span class="num" style="font-size:1.3rem;font-weight:800" id="t-simr">–</span></div></div>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Guardar tarifa</button></div>`, { ancho: true });

  const modoT = () => (c.querySelector("[name=t-modo]:checked") || {}).value || "tramos";
  const tramosHib = () => {
    const x = parseInt($("#t-h-min").value, 10) || 1;
    return [{ desde_min: 0, hasta_min: x, fraccion_min: x, precio_mil: (aCent($("#t-h-pre").value) || 0) * 10 },
      { desde_min: x, hasta_min: null, fraccion_min: parseInt($("#t-h-fr").value, 10) || 1, precio_mil: Math.round(Number(String($("#t-h-p2").value).replace(",", ".")) * 1000) || 0 }];
  };
  const pintarModo = () => {
    const m = modoT();
    $("#t-sec-tramos").classList.toggle("oculto", m !== "tramos");
    $("#t-sec-hib").classList.toggle("oculto", m !== "hibrida");
    $("#t-sec-res").classList.toggle("oculto", m !== "reserva");
    $$(".t-no-res", c).forEach((x) => x.classList.toggle("oculto", m === "reserva" || (x.tagName === "DETAILS" && !tieneModulo("tarifas_avanzadas"))));
    $$("#t-gra, #t-max", c).forEach((x) => (x.closest("label").style.visibility = m === "reserva" ? "hidden" : ""));
    if (m === "reserva") $("#t-def").checked = false;
    const porFecha = $("#t-rmodo").value === "fecha";
    $$(".t-r-noches", c).forEach((x) => x.classList.toggle("oculto", porFecha));
    simular();
  };
  const leer = () => {
    if (modoT() === "hibrida") { tramos.splice(0, tramos.length, ...tramosHib()); return; }
    const filas = $$("#t-tramos tr");
    filas.forEach((f, i) => {
      tramos[i].desde_min = parseInt($(".d", f).value, 10) || 0;
      tramos[i].hasta_min = $(".h", f).value === "" ? null : parseInt($(".h", f).value, 10);
      tramos[i].fraccion_min = parseInt($(".f", f).value, 10) || 1;
      tramos[i].precio_mil = Math.round(Number(String($(".p", f).value).replace(",", ".")) * 1000) || 0;
    });
  };
  const simular = () => {   // misma fórmula que el servidor, para respuesta instantánea
    leer();
    const min = parseInt($("#t-sim").value, 10) || 0;
    const gra = parseInt($("#t-gra").value, 10) || 0;
    const max = $("#t-max").value.trim() === "" ? null : aCent($("#t-max").value);
    const costeDia = (m) => {
      let mil = 0;
      [...tramos].sort((a, b) => a.desde_min - b.desde_min).forEach((t) => {
        const hasta = t.hasta_min == null ? Infinity : t.hasta_min;
        if (m <= t.desde_min) return;
        mil += Math.ceil((Math.min(m, hasta) - t.desde_min) / t.fraccion_min) * t.precio_mil;
      });
      const c = Math.floor((mil + 5) / 10);
      return max == null ? c : Math.min(c, max);
    };
    if (modoT() === "reserva") { $("#t-simr").textContent = "—"; return; }
    const r0 = min <= 0 || min <= gra ? 0 : Math.floor(min / 1440) * costeDia(1440) + costeDia(min % 1440);
    const r = redondear5(r0, $("#t-red").value);
    $("#t-simr").textContent = eur(r);
  };
  const pintar = () => {
    $("#t-tramos").innerHTML = tramos.map((r, i) => `<tr>
      <td><input class="ent d" type="number" min="0" value="${r.desde_min}" style="width:90px" ${i === 0 ? "readonly" : ""}></td>
      <td><input class="ent h" type="number" min="1" value="${r.hasta_min ?? ""}" placeholder="∞" style="width:90px"></td>
      <td><input class="ent f" type="number" min="1" value="${r.fraccion_min}" style="width:90px"></td>
      <td><input class="ent p" inputmode="decimal" value="${(r.precio_mil / 1000).toFixed(3).replace(".", ",")}" style="width:110px"></td>
      <td>${i > 0 ? `<button class="btn peligro" data-del="${i}">Quitar</button>` : ""}</td></tr>`).join("");
    $$("[data-del]", c).forEach((b) => (b.onclick = () => { leer(); tramos.splice(Number(b.dataset.del), 1); pintar(); }));
    $$("#t-tramos input").forEach((i) => (i.oninput = simular));
    simular();
  };
  pintar();
  ["#t-sim", "#t-gra", "#t-max", "#t-red", "#t-h-min", "#t-h-pre", "#t-h-fr", "#t-h-p2"].forEach((s) => ($(s).oninput = simular));
  $$("[name=t-modo]", c).forEach((r) => (r.onchange = pintarModo));
  $("#t-pcerr-ok").onclick = () => {   // Precio cerrado por día (eventos)
    const cent = aCent($("#t-pcerr").value);
    if (!cent || Number.isNaN(cent)) return toast("Indique el precio cerrado", "err");
    c.querySelector('[name=t-modo][value="tramos"]').checked = true; pintarModo();
    tramos.splice(0, tramos.length, { desde_min: 0, hasta_min: null, fraccion_min: 1440, precio_mil: cent * 10 });
    $("#t-gra").value = 0; $("#t-max").value = "";
    pintar(); toast("Tramo de precio cerrado aplicado", "ok");
  };
  $("#t-rmodo").onchange = pintarModo;
  pintarModo();
  $$(".t-dia", c).forEach((i) => (i.onchange = () => i.parentElement.classList.toggle("on", i.checked)));
  $("#t-add").onclick = () => {
    leer();
    const ult = tramos[tramos.length - 1];
    if (ult.hasta_min == null) ult.hasta_min = ult.desde_min + 60;
    tramos.push({ desde_min: ult.hasta_min, hasta_min: null, fraccion_min: 1, precio_mil: ult.precio_mil });
    pintar();
  };
  $("[data-c]", c).onclick = cerrarModal;
  $("[data-ok]", c).onclick = accion(async () => {
    leer();
    const max = $("#t-max").value.trim() === "" ? null : aCent($("#t-max").value);
    if (Number.isNaN(max)) throw new Error("Máximo diario no válido");
    const modo = modoT();
    const cuerpo = { nombre: $("#t-nom").value, gracia_min: parseInt($("#t-gra").value, 10) || 0, maximo_diario_cent: max,
      por_defecto: modo !== "reserva" && $("#t-def").checked, tramos: modo === "reserva" ? [] : tramos, redondeo: $("#t-red").value, texto_ticket: $("#t-txt").value,
      horario_dias: $$(".t-dia", c).filter((x) => x.checked).map((x) => x.value).join(""), horario_desde: $("#t-hd").value, horario_hasta: $("#t-hh").value, modo,
      evento_desde: $("#t-evd").value, evento_hasta: $("#t-evh").value, tipo_vehiculo: $("#t-tveh").value };
    if (modo === "reserva") Object.assign(cuerpo, { reserva_modo: $("#t-rmodo").value, reserva_noches: Number($("#t-rnoches").value) || 1,
      reserva_hora: $("#t-rhora").value || "12:00",
      tarifa_despues_id: Number($("#t-rdesp").value) || null, gracia_min: 0, maximo_diario_cent: null });
    await api(t ? "PUT" : "POST", t ? `/api/tarifas/${t.id}` : "/api/tarifas", cuerpo);
    cerrarModal(); toast("Tarifa guardada", "ok"); ajTarifas(el);
  });
}

// ======================================================= Servicios y productos

const ajProductos = accion(async (el) => {
  const [ps, cfg] = await Promise.all([api("GET", "/api/productos"), api("GET", "/api/config")]);
  const ivaGen = cfg.iva_pct || "21";
  el.innerHTML = `<div class="fila" style="margin-bottom:14px"><button class="btn prim" id="b-prod-nuevo">Nuevo servicio o producto</button>
    <button class="btn" id="b-prod-exp" title="Exportar o importar tarifas, servicios y clientes">Importar / exportar…</button>
    <span class="suave">Se añaden a la estancia desde la pantalla de cobro o desde Vehículos, y se cobran juntos en la misma factura.</span></div>
    <div class="panel">${ps.length ? `<table class="tabla"><thead><tr><th>Nombre</th><th>Tipo</th><th class="der">Precio (IVA incl.)</th><th class="der">IVA</th><th>Parking incluido</th><th>Estado</th><th></th></tr></thead><tbody>
      ${ps.map((p) => `<tr><td><div class="fila" style="gap:10px;flex-wrap:nowrap">${p.foto ? `<img class="mini-foto" src="${urlFotoProducto(p)}" alt="">` : '<span class="mini-foto vacia">📷</span>'}<div><b>${esc(p.nombre)}</b>${p.descripcion ? `<div class="suave" style="font-size:.82rem;max-width:340px">${esc(p.descripcion)}</div>` : ""}</div></div></td><td>${TIPO_PROD[p.tipo]}</td><td class="der num">${p.solo_proveedor ? '<span class="suave">Según proveedor</span>' : p.precio_variable ? '<span class="suave">Al vender</span>' : eur(p.precio_cent)}</td>
        <td class="der num">${p.iva_efectivo}%${p.iva_pct == null ? ' <span class="suave">(general)</span>' : ""}</td>
        <td>${p.minutos_incluidos ? duracion(p.minutos_incluidos) : "—"}</td>
        <td>${p.activo ? '<span class="etiqueta e-pagado">A la venta</span>' : '<span class="etiqueta e-salido">Inactivo</span>'}${p.solo_proveedor ? ' <span class="etiqueta e-aviso">Proveedores</span>' : ""}</td>
        <td class="der" style="white-space:nowrap"><button class="btn" data-p="${p.id}">Editar</button>
          ${menuAcciones([{ attr: `data-borrar="${p.id}"`, texto: "Eliminar", peligro: true }])}</td></tr>`).join("")}</tbody></table>`
      : '<div class="vacio">No hay servicios ni productos.</div>'}</div>`;
  const editar = (p) => {
    // 4.61: el tiempo incluido se guarda en minutos, pero se escribe en la unidad más cómoda (minutos, horas o días)
    const minIncl = p?.minutos_incluidos || 0, tiempoIncl = minIncl && minIncl % 1440 === 0 ? { valor: minIncl / 1440, unidad: 1440 }
      : minIncl && minIncl % 60 === 0 ? { valor: minIncl / 60, unidad: 60 } : { valor: minIncl, unidad: 1 };
    const ivaSel = p && p.iva_pct != null ? String(p.iva_pct) : "";
    const opIva = [["", `General de la empresa (${ivaGen}%)`], ["21", "21 %"], ["10", "10 %"], ["4", "4 %"], ["0", "0 % (exento)"]];
    if (ivaSel && !opIva.some(([v]) => Number(v) === Number(ivaSel))) opIva.push([ivaSel, ivaSel + " %"]);
    const m = modal(`<h2>${p ? "Editar" : "Nuevo"} servicio o producto</h2>
      <div class="rejilla r2" style="margin-top:14px">
        <label class="campo" style="grid-column:1/-1">Nombre <span class="ayuda">aparece así en la factura</span><input class="ent" id="pr-n" value="${esc(p?.nombre || "")}" autofocus placeholder="Lavado exterior"></label>
        <label class="campo">Tipo<select class="ent" id="pr-t"><option value="servicio" ${p?.tipo !== "producto" ? "selected" : ""}>Servicio</option><option value="producto" ${p?.tipo === "producto" ? "selected" : ""}>Producto</option></select></label>
        <label class="campo" id="pr-p-c">Precio (€, IVA incluido) <span class="ayuda">vacío = se pide al vender</span><input class="ent num" id="pr-p" inputmode="decimal" placeholder="Precio variable" value="${p && !p.precio_variable ? aEurTxt(p.precio_cent) : ""}"></label>
        <label class="campo">IVA<select class="ent" id="pr-i">${opIva.map(([v, n]) => `<option value="${v}" ${(v === "" ? ivaSel === "" : ivaSel !== "" && Number(v) === Number(ivaSel)) ? "selected" : ""}>${n}</option>`).join("")}</select></label>
        <label class="campo">Orden en la lista<input class="ent num" id="pr-o" type="number" value="${p?.orden ?? 0}"></label>
        <label class="campo" style="grid-column:1/-1">Descripción <span class="ayuda">opcional · aparece debajo del nombre en la factura y el ticket</span>
          <textarea class="ent" id="pr-d" rows="2" maxlength="300" placeholder="Ej.: Lavado a mano exterior con secado">${esc(p?.descripcion || "")}</textarea></label>
        <div class="campo" style="grid-column:1/-1">Parking incluido <span class="ayuda">0 = ninguno · ese tiempo no se cobra de la estancia (p. ej. 1 hora gratis con el lavado)</span>
          <div class="fila" style="gap:8px"><input class="ent num" id="pr-m" type="number" min="0" step="1" value="${tiempoIncl.valor}" style="width:120px" aria-label="Tiempo de parking incluido">
            <select class="ent" id="pr-mu" style="width:auto" aria-label="Unidad"><option value="1" ${tiempoIncl.unidad === 1 ? "selected" : ""}>minutos</option>
              <option value="60" ${tiempoIncl.unidad === 60 ? "selected" : ""}>horas</option><option value="1440" ${tiempoIncl.unidad === 1440 ? "selected" : ""}>días</option></select></div></div>
      </div>
      <div class="campo" style="margin-top:12px">Foto <span class="ayuda">opcional · se ve en la Tienda · se reduce sola a un tamaño pequeño</span>
        <div class="foto-editor"><div class="foto-previa" id="pr-foto-ver">${p && p.foto ? `<img src="${urlFotoProducto(p)}" alt="">` : "<span>Sin foto</span>"}</div>
          <div class="fila" style="gap:8px"><label class="btn">${p && p.foto ? "Cambiar foto…" : "Elegir foto…"}<input type="file" id="pr-foto" accept="image/*" hidden></label>
            <button type="button" class="btn peligro ${p && p.foto ? "" : "oculto"}" id="pr-foto-quitar">Quitar foto</button></div></div></div>
      <label class="fila" style="margin-top:12px;font-weight:600"><input type="checkbox" id="pr-a" ${!p || p.activo ? "checked" : ""}> A la venta</label>
      <label class="fila" style="margin-top:8px;font-weight:600"><input type="checkbox" id="pr-sp" ${p && p.solo_proveedor ? "checked" : ""}> Solo para proveedores
        <span class="ayuda" style="font-weight:400">no sale en Entrada, Salida ni Tienda: se cobra con «Factura a proveedor»</span></label>
      <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Guardar</button></div>`);
    $("[data-c]", m).onclick = cerrarModal;
    // foto: null = sin cambios · Blob = nueva · "quitar" = borrarla
    let foto = null;
    $("#pr-foto", m).onchange = accion(async (e) => {
      const f = e.target.files[0]; if (!f) return;
      foto = await reducirFoto(f);
      $("#pr-foto-ver", m).innerHTML = `<img src="${URL.createObjectURL(foto)}" alt="">`;
      $("#pr-foto-quitar", m).classList.remove("oculto");
    });
    $("#pr-foto-quitar", m).onclick = () => { foto = "quitar"; $("#pr-foto-ver", m).innerHTML = "<span>Sin foto</span>"; $("#pr-foto-quitar", m).classList.add("oculto"); };
    const ajustarProv = () => { $("#pr-p-c", m).classList.toggle("oculto", $("#pr-sp", m).checked); };   // 1.1: el precio de un servicio de proveedor lo pone cada proveedor
    $("#pr-sp", m).onchange = ajustarProv; ajustarProv();
    $("[data-ok]", m).onclick = accion(async () => {
      const precio = $("#pr-sp").checked ? 0 : aCent($("#pr-p").value);
      if (Number.isNaN(precio)) throw new Error("Precio no válido");   // vacío = precio variable
      const d = { nombre: $("#pr-n").value, tipo: $("#pr-t").value, precio_cent: precio, precio_variable: precio === null, iva_pct: $("#pr-i").value,
        orden: Number($("#pr-o").value) || 0, activo: $("#pr-a").checked, minutos_incluidos: Math.round((Number(String($("#pr-m").value).replace(",", ".")) || 0) * Number($("#pr-mu").value)),
        descripcion: $("#pr-d").value, solo_proveedor: $("#pr-sp").checked };
      const r = await api(p ? "PUT" : "POST", p ? `/api/productos/${p.id}` : "/api/productos", d);
      if (foto === "quitar" && p && p.foto) await api("DELETE", `/api/productos/${r.id}/foto`);
      else if (foto instanceof Blob) {
        const rs = await fetch(`/api/productos/${r.id}/foto`, { method: "POST", headers: { "X-Token": S.token, "Content-Type": "application/octet-stream" }, body: foto });
        if (!rs.ok) throw new Error((await rs.json()).error || "No se pudo guardar la foto");
      }
      cerrarModal(); toast("Guardado", "ok"); ajProductos(el);
    });
  };
  $("#b-prod-nuevo").onclick = () => editar(null);
  $("#b-prod-exp").onclick = () => irImportarExportar();
  $$("[data-borrar]", el).forEach((b) => (b.onclick = accion(async () => {
    const p = ps.find((x) => x.id === Number(b.dataset.borrar));
    if (!(await confirmar("Eliminar servicio o producto", `¿Eliminar <b>${esc(p.nombre)}</b> (${p.precio_variable ? "precio variable" : eur(p.precio_cent)})?<br>
      <span class="suave">Las facturas ya emitidas y las estancias que lo tengan añadido no cambian. Si solo quiere dejar de venderlo un tiempo, desmarque «A la venta» al editarlo.</span>`,
      { boton: "Eliminar", peligro: true }))) return ajProductos(el);
    await api("DELETE", `/api/productos/${p.id}`);
    toast(`«${p.nombre}» eliminado`, "ok");
    ajProductos(el);
  })));
  $$("[data-p]", el).forEach((b) => (b.onclick = () => editar(ps.find((x) => x.id === Number(b.dataset.p)))));
});

// ========================================================== Descuentos y vales

const TIPO_DTO = { porcentaje: "Porcentaje", importe: "Importe fijo", minutos: "Minutos gratis" };

const AMBITO_DTO = { estancia: "Estancia (Salida)", tienda: "Tienda", todo: "Estancia y tienda" };

const ajDescuentos = accion(async (el) => {
  const d = await api("GET", "/api/descuentos");
  if (!el.isConnected) return;
  const ds = d.descuentos;
  el.innerHTML = `<div style="max-width:1080px">
    <div class="panel">
      <div class="fila" style="justify-content:space-between"><h3>Servicio de descuentos</h3>
        <span class="etiqueta ${d.activo ? "e-pagado" : "e-salido"}">${d.activo ? "Activado" : "Desactivado"}</span></div>
      <p class="suave" style="margin:8px 0 12px">Con los descuentos activados, en <b>Salida</b> y en la <b>Tienda</b> aparece un desplegable para aplicar uno al cobrar
        (también se puede escanear o teclear su código). El descuento sale en el ticket, en la factura y en Informes.</p>
      <label class="fila" style="gap:10px;font-weight:600"><input type="checkbox" id="dto-activo" ${d.activo ? "checked" : ""}> Activar los descuentos al cobrar</label>
    </div>
    <div class="panel" style="margin-top:16px">
      <div class="fila" style="justify-content:space-between"><h3>Tipos de descuento</h3><button class="btn prim" id="dto-nuevo">Nuevo descuento</button></div>
      ${ds.length ? `<table class="tabla" style="margin-top:8px"><thead><tr><th>Nombre</th><th>Descuento</th><th>Se aplica en</th><th>Código</th><th>Estado</th><th></th></tr></thead><tbody>
        ${ds.map((x) => `<tr><td><b>${esc(x.nombre)}</b></td><td>${esc(x.texto)} <span class="suave" style="font-size:.82rem">(${TIPO_DTO[x.tipo].toLowerCase()})</span></td>
          <td>${AMBITO_DTO[x.ambito]}</td><td class="mono">${esc(x.codigo || "—")}</td>
          <td>${x.activo ? '<span class="etiqueta e-pagado">Activo</span>' : '<span class="etiqueta e-salido">Inactivo</span>'}</td>
          <td class="der" style="white-space:nowrap"><button class="btn" data-dto="${x.id}">Editar</button> ${menuAcciones([{ attr: `data-dto-del="${x.id}"`, texto: "Eliminar descuento", peligro: true }])}</td></tr>`).join("")}
        </tbody></table>`
      : `<div class="vacio">Aún no hay descuentos. Ejemplos: «Cliente del cine −10 %», «Vale de 2 €», «1 hora gratis con compra».</div>`}
    </div></div>`;
  $("#dto-activo", el).onchange = accion(async (e) => {
    await api("PUT", "/api/config", { descuentos_activo: e.target.checked ? "1" : "0" });
    S.estado = await api("GET", "/api/estado");
    toast(e.target.checked ? "Descuentos activados" : "Descuentos desactivados", "ok");
    ajDescuentos(el);
  });
  $("#dto-nuevo", el).onclick = () => modalDescuento(null, () => ajDescuentos(el));
  $$("[data-dto]", el).forEach((b) => (b.onclick = () => modalDescuento(ds.find((x) => x.id === Number(b.dataset.dto)), () => ajDescuentos(el))));
  $$("[data-dto-del]", el).forEach((b) => (b.onclick = accion(async () => {
    const x = ds.find((y) => y.id === Number(b.dataset.dtoDel));
    if (!(await confirmar("Eliminar descuento", `¿Eliminar <b>${esc(x.nombre)}</b>?<br><span class="suave">Las facturas en las que se aplicó no cambian.</span>`,
      { boton: "Eliminar", peligro: true }))) return ajDescuentos(el);
    await api("DELETE", `/api/descuentos/${x.id}`);
    toast("Descuento eliminado", "ok");
    ajDescuentos(el);
  })));
  montarVales(el, d);   // vales de descuento
});

function modalDescuento(x, alGuardar) {
  const valorTxt = (t, v) => (v == null ? "" : t === "importe" ? aEurTxt(v) : String(v));
  const m = modal(`<h2>${x ? "Editar" : "Nuevo"} descuento</h2>
    <div class="rejilla r2" style="margin-top:14px">
      <label class="campo" style="grid-column:1/-1">Nombre <span class="ayuda">aparece así en el ticket y la factura</span>
        <input class="ent" id="dt-n" value="${esc(x?.nombre || "")}" placeholder="Cliente del cine" autofocus></label>
      <label class="campo">Tipo<select class="ent" id="dt-t">${Object.entries(TIPO_DTO).map(([v, n]) => `<option value="${v}" ${(x?.tipo || "porcentaje") === v ? "selected" : ""}>${n}</option>`).join("")}</select></label>
      <label class="campo"><span id="dt-vl">Valor</span><input class="ent num" id="dt-v" inputmode="decimal" value="${esc(valorTxt(x?.tipo, x?.valor))}"></label>
      <label class="campo">Se aplica en<select class="ent" id="dt-a">${Object.entries(AMBITO_DTO).map(([v, n]) => `<option value="${v}" ${(x?.ambito || "estancia") === v ? "selected" : ""}>${n}</option>`).join("")}</select></label>
      <label class="campo">Código <span class="ayuda">opcional · para escanearlo o teclearlo</span>
        <input class="ent mono" id="dt-c" value="${esc(x?.codigo || "")}" placeholder="CINE10" style="text-transform:uppercase" autocomplete="off"></label>
      <label class="campo" style="grid-column:1/-1">Comercio que valida <span class="ayuda">opcional · p. ej. la tienda o el cine que sella el ticket; en Informes se ve cuánto ha validado cada uno</span>
        <input class="ent" id="dt-com" value="${esc(x?.comercio || "")}" placeholder="Cines Avenida" maxlength="60"></label>
    </div>
    <p class="ayuda" id="dt-ayuda" style="margin:10px 0 0"></p>
    <label class="fila" style="margin-top:12px;font-weight:600"><input type="checkbox" id="dt-act" ${!x || x.activo ? "checked" : ""}> Activo</label>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Guardar</button></div>`);
  const tipo = () => $("#dt-t", m).value;
  const pintar = () => {
    $("#dt-vl", m).textContent = { porcentaje: "Porcentaje (%)", importe: "Importe (€)", minutos: "Minutos gratis" }[tipo()];
    $("#dt-ayuda", m).textContent = {
      porcentaje: "Se descuenta ese porcentaje del importe (de la estancia en Salida, o del total en la Tienda).",
      importe: "Se descuenta esa cantidad, como máximo lo que se debe.",
      minutos: "Se cobra como si el vehículo hubiera entrado esos minutos más tarde. Solo para la estancia.",
    }[tipo()];
    const amb = $("#dt-a", m);
    if (tipo() === "minutos") amb.value = "estancia";
    [...amb.options].forEach((o) => (o.disabled = tipo() === "minutos" && o.value !== "estancia"));
  };
  $("#dt-t", m).onchange = pintar;
  pintar();
  $("[data-c]", m).onclick = cerrarModal;
  $("[data-ok]", m).onclick = accion(async () => {
    const t = tipo(), bruto = $("#dt-v", m).value.trim();
    const valor = t === "importe" ? aCent(bruto) : Number(bruto.replace(",", "."));
    if (!bruto || Number.isNaN(valor) || valor <= 0) throw new Error("Indique el valor del descuento");
    if (t !== "importe" && !Number.isInteger(valor)) throw new Error(t === "porcentaje" ? "El porcentaje debe ser un número entero" : "Indique los minutos en número entero");
    const d = { nombre: $("#dt-n", m).value, tipo: t, valor, ambito: $("#dt-a", m).value, codigo: $("#dt-c", m).value, activo: $("#dt-act", m).checked,
      comercio: $("#dt-com", m).value };
    await api(x ? "PUT" : "POST", x ? `/api/descuentos/${x.id}` : "/api/descuentos", d);
    cerrarModal(); toast("Descuento guardado", "ok"); alGuardar && alGuardar();
  });
}

const ESTADO_VALE = { valido: ["e-pagado", "Válido"], agotado: ["e-salido", "Usado"], caducado: ["e-aviso", "Caducado"], anulado: ["e-err", "Anulado"] };

async function montarVales(el, d) {
  if (!tieneRol("admin", "supervisor") || !el.isConnected) return;
  const caja = document.createElement("div");
  caja.className = "panel"; caja.id = "panel-vales"; caja.style.marginTop = "16px"; caja.style.maxWidth = "1080px";
  $$("#panel-vales", el).forEach((x) => x.remove());
  el.appendChild(caja);
  const usosTxt = (v) => (v.usos_max == null ? `${v.usos} (ilimitado)` : `${v.usos} de ${v.usos_max}`);
  const cargar = accion(async () => {
    const vs = await api("GET", "/api/vales?" + new URLSearchParams({ buscar: S.vales.buscar, estado: S.vales.estado }));
    if (!caja.isConnected) return;
    $("#vl-lista", caja).innerHTML = vs.length ? `<table class="tabla"><thead><tr><th>Código</th><th>Descuento</th><th>Usos</th><th>Válido hasta</th><th>Estado</th><th></th></tr></thead><tbody>
      ${vs.map((v) => `<tr><td class="mono"><b>${esc(v.codigo)}</b>${v.nota ? `<div class="suave" style="font-size:.8rem;font-family:inherit">${esc(v.nota)}</div>` : ""}</td>
        <td>${esc(v.descuento_nombre)} <span class="suave">· ${esc(v.texto)}</span></td><td class="num">${usosTxt(v)}</td>
        <td>${v.caduca ? fechaCorta(v.caduca) : "Sin caducidad"}</td>
        <td><span class="etiqueta ${ESTADO_VALE[v.estado][0]}">${ESTADO_VALE[v.estado][1]}</span></td>
        <td class="der" style="white-space:nowrap"><button class="btn mini" data-vl-imp="${v.id}">Imprimir</button>
          ${v.estado === "valido" ? menuAcciones([{ attr: `data-vl-anular="${v.id}"`, texto: "Anular vale", peligro: true }]) : ""}</td></tr>`).join("")}</tbody></table>`
      : `<div class="vacio">${S.vales.buscar || S.vales.estado ? "Ningún vale con ese filtro." : "Aún no se han generado vales."}</div>`;
    $$("[data-vl-imp]", caja).forEach((b) => (b.onclick = accion(async () => {
      const r = await api("POST", "/api/vales/imprimir", { ids: [Number(b.dataset.vlImp)] });
      notarImpresion(r); verImpresion(r);
    })));
    $$("[data-vl-anular]", caja).forEach((b) => (b.onclick = accion(async () => {
      const v = vs.find((x) => x.id === Number(b.dataset.vlAnular));
      if (!(await confirmar("Anular vale", `¿Anular el vale <b class="mono">${esc(v.codigo)}</b>? Ya no se podrá usar.`, { boton: "Anular", peligro: true }))) return;
      await api("POST", `/api/vales/${v.id}/anular`, {});
      toast("Vale anulado", "ok"); cargar();
    })));
  });
  caja.innerHTML = `<div class="fila" style="justify-content:space-between"><h3>Vales de descuento</h3>
      <button class="btn prim" id="vl-generar" ${d.activo && d.descuentos.some((x) => !x.eliminado) ? "" : "disabled"}>Generar vales…</button></div>
    <p class="suave" style="margin:8px 0 12px">Tickets impresos con un código (QR y barras) que da uno de los descuentos de arriba: de <b>un solo uso</b>, de <b>varios usos</b>
      o ilimitados, con caducidad opcional. Se canjean escaneándolos en <b>Salida</b> o en la <b>Tienda</b>.${d.activo ? "" : " <b>Active antes los descuentos.</b>"}</p>
    <div class="fila" style="margin-bottom:10px"><input class="ent" id="vl-buscar" placeholder="Código, descuento o nota" value="${esc(S.vales.buscar)}" style="min-width:240px">
      <select class="ent" id="vl-estado"><option value="">Todos</option>${Object.entries(ESTADO_VALE).map(([k, [, n]]) => `<option value="${k}" ${S.vales.estado === k ? "selected" : ""}>${n}</option>`).join("")}</select></div>
    <div id="vl-lista"><div class="vacio">Cargando…</div></div>`;
  let tm;
  $("#vl-buscar", caja).oninput = (e) => { S.vales.buscar = e.target.value; clearTimeout(tm); tm = setTimeout(cargar, 250); };
  $("#vl-estado", caja).onchange = (e) => { S.vales.estado = e.target.value; cargar(); };
  $("#vl-generar", caja).onclick = () => modalGenerarVales(d.descuentos.filter((x) => !x.eliminado), cargar);
  cargar();
}

function modalGenerarVales(descuentos, alTerminar) {
  const m = modal(`<h2>Generar vales de descuento</h2>
    <div class="rejilla r2" style="margin-top:14px">
      <label class="campo" style="grid-column:1/-1">Descuento que dan<select class="ent" id="gv-d">${descuentos.map((x) => `<option value="${x.id}">${esc(x.nombre)} · ${esc(x.texto)} · ${esc(AMBITO_DTO[x.ambito])}</option>`).join("")}</select></label>
      <label class="campo">Cuántos vales<input class="ent num" id="gv-n" type="number" min="1" max="200" value="1"></label>
      <label class="campo">Válidos hasta <span class="ayuda">vacío = sin caducidad</span><input class="ent" id="gv-cad" type="date" min="${hoyISO()}"></label>
      <div class="campo" style="grid-column:1/-1">Usos de cada vale
        <div class="metodos" style="grid-template-columns:repeat(3,1fr);margin:6px 0 0">
          <button type="button" class="btn sel" data-usos="1">Un solo uso</button>
          <button type="button" class="btn" data-usos="varios">Varios usos</button>
          <button type="button" class="btn" data-usos="0">Ilimitados</button></div>
        <label class="fila oculto" id="gv-varios" style="gap:8px;margin-top:8px">Hasta <input class="ent num" id="gv-u" type="number" min="2" max="9999" value="5" style="width:90px"> usos por vale</label></div>
      <label class="campo" style="grid-column:1/-1">Nota <span class="ayuda">opcional · sale en el vale (p. ej. «Promoción feria»)</span><input class="ent" id="gv-nota" maxlength="80"></label>
    </div>
    <label class="fila" style="margin-top:12px;font-weight:600;gap:8px"><input type="checkbox" id="gv-imp" checked> Imprimirlos ahora</label>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Generar</button></div>`);
  let usos = "1";
  $$("[data-usos]", m).forEach((b) => (b.onclick = () => {
    usos = b.dataset.usos;
    $$("[data-usos]", m).forEach((x) => x.classList.toggle("sel", x === b));
    $("#gv-varios", m).classList.toggle("oculto", usos !== "varios");
  }));
  $("[data-c]", m).onclick = cerrarModal;
  $("[data-ok]", m).onclick = accion(async () => {
    const r = await api("POST", "/api/vales", {
      descuento_id: Number($("#gv-d", m).value), cantidad: Number($("#gv-n", m).value) || 1,
      usos_max: usos === "varios" ? Number($("#gv-u", m).value) : Number(usos), caduca: $("#gv-cad", m).value || null,
      nota: $("#gv-nota", m).value, imprimir: $("#gv-imp", m).checked });
    cerrarModal();
    if (r.impresion) { notarImpresion(r.impresion); verImpresion(r.impresion); }
    toast(`${r.vales.length} vale(s) generado(s)${r.impresion ? " e impresos" : ""}`, "ok");
    alTerminar && alTerminar();
  });
}

// ============================================================ al cargar

S.vales = S.vales || { buscar: "", estado: "" };
