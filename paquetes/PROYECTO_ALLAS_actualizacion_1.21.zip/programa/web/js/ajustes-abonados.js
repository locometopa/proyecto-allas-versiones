/* PROYECTO ALLAS · Ajustes → Bonos y avisos */
"use strict";

// =============================================================== Tipos de bono

const ajBonos = accion(async (el) => {
  const ps = await api("GET", "/api/planes");
  el.innerHTML = `<div class="fila" style="margin-bottom:14px"><button class="btn prim" id="b-plan-nuevo">Nuevo tipo de bono</button>
    <span class="suave">Los tipos inactivos dejan de venderse, pero los bonos ya vendidos siguen siendo válidos.</span></div>
    <div class="panel">${ps.length ? `<table class="tabla"><thead><tr><th>Bono</th><th>Duración</th><th class="der">Precio</th><th>Estado</th><th></th></tr></thead><tbody>
      ${ps.map((p) => `<tr><td><b>${esc(p.nombre)}</b><div class="suave" style="font-size:.85rem">${esc(p.descripcion || "")}</div></td>
        <td>${p.meses} mes${p.meses > 1 ? "es" : ""}</td><td class="der num">${eur(p.precio_cent)}</td>
        <td>${p.activo ? '<span class="etiqueta e-pagado">A la venta</span>' : '<span class="etiqueta e-salido">Inactivo</span>'}</td>
        <td class="der"><button class="btn" data-p="${p.id}">Editar</button></td></tr>`).join("")}</tbody></table>`
      : '<div class="vacio">No hay tipos de bono.</div>'}</div>`;
  const editar = (p) => {
    const m = modal(`<h2>${p ? "Editar" : "Nuevo"} tipo de bono</h2>
      <div class="rejilla r2" style="margin-top:14px">
        <label class="campo" style="grid-column:1/-1">Nombre<input class="ent" id="pl-n" value="${esc(p?.nombre || "")}" placeholder="Mensual 24 horas" autofocus></label>
        <label class="campo" style="grid-column:1/-1">Descripción<input class="ent" id="pl-d" value="${esc(p?.descripcion || "")}"></label>
        <label class="campo">Precio (€, IVA incluido)<input class="ent num" id="pl-p" inputmode="decimal" value="${p ? aEurTxt(p.precio_cent) : ""}"></label>
        <label class="campo">Duración<select class="ent" id="pl-m">${[1, 2, 3, 6, 12].map((n) => `<option value="${n}" ${p?.meses === n ? "selected" : ""}>${n} mes${n > 1 ? "es" : ""}</option>`).join("")}</select></label>
      </div>
      <label class="fila" style="margin-top:12px;font-weight:600"><input type="checkbox" id="pl-a" ${!p || p.activo ? "checked" : ""}> A la venta</label>
      <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Guardar</button></div>`);
    $("[data-c]", m).onclick = cerrarModal;
    $("[data-ok]", m).onclick = accion(async () => {
      const precio = aCent($("#pl-p").value);
      if (precio === null || Number.isNaN(precio)) throw new Error("Precio no válido");
      const d = { nombre: $("#pl-n").value, descripcion: $("#pl-d").value, precio_cent: precio, meses: Number($("#pl-m").value), activo: $("#pl-a").checked };
      await api(p ? "PUT" : "POST", p ? `/api/planes/${p.id}` : "/api/planes", d);
      cerrarModal(); toast("Tipo de bono guardado", "ok"); ajBonos(el);
    });
  };
  $("#b-plan-nuevo").onclick = () => editar(null);
  $$("[data-p]").forEach((b) => (b.onclick = () => editar(ps.find((x) => x.id === Number(b.dataset.p)))));
});

// ================================================= Avisos y facturas por email

const ajAvisos = accion(async (el) => {
  const [a, c] = await Promise.all([api("GET", "/api/avisos"), api("GET", "/api/config")]);
  const e = { smtp: a.smtp };
  const area = (k, def, filas = 2) => `<textarea class="ent" name="${k}" rows="${filas}" placeholder="${esc(def)}">${esc(c[k] || "")}</textarea>`;
  el.innerHTML = `${tieneModulo("pagos_online") ? `<p id="av44-nota" class="suave" style="margin: 0px 0px 12px;">El cobro de las suscripciones con tarjeta (Stripe) está en <a href="#" id="av44-ir">Ajustes → Conexiones → Cobro online de bonos</a>.</p>` : ""}<div style="max-width:1080px">
    <form class="panel" id="po-avisos">
      <h3>Facturas y avisos por email a los abonados</h3>
      ${e.smtp ? "" : '<div class="aviso" style="margin:10px 0">Los envíos automáticos necesitan el <b>Envío automático (SMTP)</b> configurado en Ajustes → Email. Sin él, los avisos se pueden mandar a mano con Gmail desde Clientes → Avisos de caducidad.</div>'}
      <div class="rejilla" style="gap:10px;margin:12px 0">
        <label class="fila" style="font-weight:600;gap:8px"><input type="checkbox" name="facturas_bono_email" ${c.facturas_bono_email !== "0" ? "checked" : ""}> Enviar la factura por email al vender o renovar un bono (a los abonados con email que lo tengan activado en su ficha)</label>
        <label class="fila" style="font-weight:600;gap:8px"><input type="checkbox" name="avisos_activos" ${c.avisos_activos !== "0" ? "checked" : ""}> Avisar por email cuando el bono vaya a caducar y cuando no se pueda cobrar una renovación</label>
        <div class="rejilla r2" style="gap:10px">
          <label class="campo">Avisar de la caducidad con cuántos días de antelación <span class="ayuda">(abonados sin renovación automática)</span><input class="ent" type="number" min="1" max="30" name="avisos_caducidad_dias" value="${esc(c.avisos_caducidad_dias || "5")}"></label>
          <label class="campo">Días para pagar una renovación automática <span class="ayuda">(mientras tanto el bono vale; 0 = hay que pagarla antes de entrar)</span><input class="ent" type="number" min="0" max="60" name="renovacion_dias_gracia" value="${esc(c.renovacion_dias_gracia ?? "7")}"></label>
        </div>
      </div>
      <details><summary style="cursor:pointer;font-weight:600">Textos de los avisos</summary>
        <p class="ayuda">Se pueden usar {nombre}, {plan}, {hasta}, {parking}, {enlace}, {texto_enlace} (frase con el enlace de suscripción, si hay) e {importe}. Vacío = texto por defecto.</p>
        <div class="rejilla r2" style="gap:10px">
          <label class="campo">Caducidad · asunto<input class="ent" name="aviso_caducidad_asunto" value="${esc(c.aviso_caducidad_asunto || "")}" placeholder="Su bono de {parking} caduca el {hasta}"></label>
          <label class="campo">Renovación pendiente de pago · asunto<input class="ent" name="aviso_renovacion_asunto" value="${esc(c.aviso_renovacion_asunto || "")}" placeholder="Su bono de {parking} se ha renovado: pago pendiente"></label>
          <label class="campo">Renovación pendiente de pago · texto <span class="ayuda">{desde} {hasta} {numero} {pagar_antes}</span>${area("aviso_renovacion_texto", "Hola {nombre}: Su bono {plan} se ha renovado del {desde} al {hasta}. Importe pendiente: {importe}…", 5)}</label>
          <label class="campo">Pago pendiente · asunto<input class="ent" name="aviso_pago_pendiente_asunto" value="${esc(c.aviso_pago_pendiente_asunto || "")}" placeholder="Tiene una factura pendiente de pago en {parking}"></label>
          <label class="campo">Caducidad · texto${area("aviso_caducidad_texto", "Hola {nombre}: Le recordamos que su bono {plan} de {parking} caduca el {hasta}…", 5)}</label>
          <label class="campo">Pago pendiente · texto${area("aviso_pago_pendiente_texto", "Hola {nombre}: No hemos podido cobrar la renovación de su bono {plan} ({importe}). Puede pagar la factura pendiente aquí: {enlace}", 5)}</label>
          <label class="campo">Recordatorio de deuda (botón de la ficha) · asunto<input class="ent" name="aviso_deuda_asunto" value="${esc(c.aviso_deuda_asunto || "")}" placeholder="Recordatorio: tiene {importe} pendiente de pago en {parking}"></label>
          <label class="campo">Recordatorio de deuda · texto <span class="ayuda">{importe} total, {detalle} lista de bonos</span>${area("aviso_deuda_texto", "Hola {nombre}: Le recordamos que tiene pendiente de pago {importe}… {detalle} {texto_enlace}", 5)}</label>
        </div></details>
      <div class="fila" style="margin-top:14px"><button class="btn prim">Guardar</button></div>
    </form></div>`;

  if ($("#av44-ir", el)) $("#av44-ir", el).onclick = (ev) => { ev.preventDefault(); irAjustes("pagos"); };
  $("#po-avisos").onsubmit = accion(async (ev) => {
    ev.preventDefault();
    const f = ev.target, d = {};
    $$("[name]", f).forEach((i) => (d[i.name] = i.type === "checkbox" ? (i.checked ? "1" : "0") : i.value));
    await api("PUT", "/api/config", d);
    toast("Guardado", "ok");
  });
});

// ============================================================ al cargar

