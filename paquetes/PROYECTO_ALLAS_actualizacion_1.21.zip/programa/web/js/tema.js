// Aplica el tema guardado antes de pintar (evita el parpadeo). Va fuera del HTML para poder usar una política CSP sin scripts en línea.
try { var t = localStorage.getItem("tema"); if (t) document.documentElement.dataset.tema = t; } catch (e) {}
