/* PROYECTO ALLAS · Entrada: tickets de entrada, reservas, lista negra y ticket manual */
"use strict";

// ===================================================================== Entrada

function vistaEntrada(v) {
  if (!exigirTurnoPropio(v)) return;
  const soloAbonados = !tieneModulo("rotacion");   // licencia «Solo abonados»: no se emiten tickets por horas
  v.innerHTML = `<div class="cab"><h2>${soloAbonados ? "Entrada de abonados" : "Emitir ticket de entrada"}</h2><div class="fila"><button class="btn" id="b-manual">Ticket manual…</button></div></div>
  <div class="cobro entrada-rejilla">
    <form class="panel" id="f-entrada" autocomplete="off">${soloAbonados ? `<div id="solo-ab45" class="aviso" style="margin: 0px 0px 14px;"><b>Licencia «Solo abonados»</b>: entran los abonados con el bono vigente, por su matrícula o su tarjeta. No se emiten tickets por horas.</div>` : ""}
      <div id="lpr-entrada"></div>
      <label class="campo">Matrícula <span class="ayuda">(opcional, recomendable para localizar tickets perdidos)</span>
        <input class="ent grande mono" name="matricula" id="e-mat" placeholder="1234 ABC" style="text-transform:uppercase"></label>
      <label class="campo" style="margin-top:14px">Tarifa<select class="ent" name="tarifa_id" id="e-tarifa"></select></label>
      ${S.estado.llaves_mostrar ? `<label class="fila" style="gap:8px;margin-top:14px;font-weight:600"><input type="checkbox" name="llaves" id="e-llaves" ${S.estado.llaves_defecto ? "checked" : ""}> Deja las llaves <span class="ayuda">(el ticket indicará que ${esc(S.estado.nombre_parking || "el parking")} se queda con las llaves)</span></label>` : ""}
      ${S.estado.entrada_ajuste_max_min ? `<div class="campo" style="margin-top:14px">Hora de entrada <span class="ayuda">sume o reste minutos si el vehículo entró antes · teclas <kbd>−</kbd> <kbd>+</kbd> en el teclado numérico</span>
        <div class="ajuste-hora">
          <button type="button" class="btn" data-aj="-15">−15</button><button type="button" class="btn" data-aj="-5">−5</button><button type="button" class="btn" data-aj="-1">−1</button>
          <div class="ajuste-hora-v"><b id="e-hora" class="num">--:--</b><span id="e-aj" class="suave">ahora</span></div>
          <button type="button" class="btn" data-aj="1">+1</button><button type="button" class="btn" data-aj="5">+5</button><button type="button" class="btn" data-aj="15">+15</button>
          <button type="button" class="btn" id="e-aj0" title="Volver a la hora actual">Ahora</button></div></div>` : ""}
      <button class="btn prim xl bloque" style="margin-top:20px">${soloAbonados ? "Registrar entrada del abonado" : "Emitir e imprimir ticket"} <kbd>Intro</kbd></button>
    </form>
    <div><div class="panel" id="e-llegadas" style="margin-bottom:14px" hidden></div>
      <div class="panel" id="e-ultimo"><div class="vacio">El último ticket emitido aparecerá aquí.</div></div></div>
  </div>`;
  cargarLlegadas();
  cargarTarifas().then(() => {
    const sel = $("#e-tarifa");
    if (!sel) return;
    const activas = S.tarifas.filter((t) => t.activa);
    const auto = activas.some((t) => t.horario_dias || t.horario_desde || t.evento_desde || t.tipo_vehiculo);   // tarifas automáticas (por horario, evento o tipo)
    sel.innerHTML = (auto ? `<option value="" selected>Automática (según el horario)</option>` : "")
      + activas.map((t) => `<option value="${t.id}" ${!auto && t.por_defecto ? "selected" : ""}>${esc(t.nombre)}${t.horario_dias || t.horario_desde ? " · horario" : ""}</option>`).join("");
    if (auto) api("GET", "/api/tarifas/actual").then((a) => { const o = sel.querySelector('option[value=""]'); if (o && a.nombre) o.textContent = `Automática · ahora: ${a.nombre}`; }).catch(() => {});
    montarReservaEntrada(sel);   // reserva / hotel
    montarOpcionesEntrada(sel);   // tipo de vehículo, zona, ticket digital, reservas de plataformas
    const pre = S.entrada.prefill; S.entrada.prefill = null;
    if (pre && $("#e-mat")) { $("#e-mat").value = pre.matricula; $("#f-entrada").requestSubmit(); }   // 1.11: entrada confirmada desde el aviso de una reserva
  });
  $("#e-mat").focus();
  avisoListaNegra($("#e-mat"));
  avisoNotaVehiculo($("#e-mat"));
  $("#b-manual").onclick = () => modalTicketManual("entrada");
  // Ajuste de la hora de entrada (minutos a sumar o restar a la hora actual)
  const maxAj = S.estado.entrada_ajuste_max_min || 0;
  S.entrada.ajuste = 0;
  const pintarHora = () => {
    if (!$("#e-hora")) return;
    const a = S.entrada.ajuste, d = new Date(Date.now() + a * 60e3);
    $("#e-hora").textContent = d.toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
    $("#e-aj").textContent = a ? `${a > 0 ? "+" : "−"}${Math.abs(a)} min sobre la hora actual` : "ahora";
    $(".ajuste-hora").classList.toggle("ajustada", a !== 0);
  };
  const ajustar = (n) => { S.entrada.ajuste = n === 0 ? 0 : Math.max(-maxAj, Math.min(maxAj, S.entrada.ajuste + n)); pintarHora(); };
  $$("[data-aj]").forEach((b) => (b.onclick = () => { ajustar(Number(b.dataset.aj)); $("#e-mat").focus(); }));
  if ($("#e-aj0")) $("#e-aj0").onclick = () => { ajustar(0); $("#e-mat").focus(); };
  if (maxAj) {
    $("#f-entrada").onkeydown = (e) => {
      if (e.code === "NumpadSubtract" || e.code === "NumpadAdd") { e.preventDefault(); ajustar(e.code === "NumpadAdd" ? 1 : -1); }
    };
    const reloj = setInterval(() => (document.body.contains($("#e-hora") || document.createElement("i")) ? pintarHora() : clearInterval(reloj)), 5000);
    pintarHora();
  }
  $("#f-entrada").onsubmit = accion(async (ev) => {
    ev.preventDefault();
    const d = Object.fromEntries(new FormData(ev.target));
    if (esFichaje(d.matricula)) { $("#e-mat").value = ""; $("#e-mat").focus(); return fichajeLeido(d.matricula); }   // QR de fichaje en el lector
    if (esCodigoReserva(d.matricula)) { $("#e-mat").value = ""; $("#e-mat").focus(); return leerCodigoReserva(d.matricula); }   // 1.11: QR de la reserva del cliente en el lector
    const dentro = await buscarYaDentro(d.matricula);   // 4.54: si ya está dentro, se pregunta qué hacer
    if (dentro) return modalYaDentro(dentro);
    if (await avisarReservaEnEntrada(d.matricula, ev.target)) return;   // 1.11: tiene reserva: ventana para confirmar o cancelar
    const cuerpo = { matricula: d.matricula, tarifa_id: Number(d.tarifa_id) || null, ajuste_min: S.entrada.ajuste || 0, llaves: d.llaves === "on" };
    cuerpo.reserva = datosReservaEntrada();   // reserva / hotel
    const dec = S.avisosReserva.decidida;
    if (dec && dec.usar && dec.mat === normMat(d.matricula)) cuerpo.tarifa_id = null;   // 1.11: confirmada una reserva de plataforma: manda su tarifa
    Object.assign(cuerpo, datosOpcionesEntrada());   // tipo de vehículo, zona, ticket digital
    const t = await emitirConListaNegra(cuerpo);
    if (!t) return;   // no se deja entrar (lista negra)
    trasEmitirEntrada(t);
    notarImpresion(t.impresion);
    S.entrada.ultimo = t;
    pantallaCliente({ tipo: "entrada", matricula: t.matricula, hora: hora(t.entrada) });
    S.avisosReserva.decidida = null; S.avisosReserva.avisada = null;
    cargarLlegadas();
    ev.target.reset();
    ajustar(0);
    $("#e-tarifa").value = S.tarifas.some((x) => x.activa && (x.horario_dias || x.horario_desde || x.evento_desde || x.tipo_vehiculo)) ? "" : (S.tarifas.find((x) => x.por_defecto) || {}).id || "";
    $("#e-mat").focus();
    toast(`Ticket ${t.codigo} emitido${t.impresion && t.impresion.copias > 1 ? ` (${t.impresion.copias} copias)` : ""}${t.ajuste_min ? ` · hora ajustada ${t.ajuste_min > 0 ? "+" : "−"}${Math.abs(t.ajuste_min)} min` : ""}`, "ok");
    pintarUltimo();
    refrescarEstado();
  });
  pintarUltimo();
}

function ultimoOculto() {
  try { return localStorage.getItem("allas_ultimo_oculto") === "1"; } catch (e) { return false; }
}
function ponerUltimoOculto(v) {
  try { localStorage.setItem("allas_ultimo_oculto", v ? "1" : "0"); } catch (e) { /* sin almacenamiento: solo vale hasta recargar */ }
  S.ultimoOculto = v;
}

function pintarUltimo() {
  const t = S.entrada.ultimo, u = $("#e-ultimo");
  if (!t || !u) return;
  if (S.ultimoOculto === undefined) S.ultimoOculto = ultimoOculto();
  if (S.ultimoOculto) {   // 1.19: se puede esconder para dejar sitio a los avisos de reserva
    u.innerHTML = `<div class="fila" style="justify-content:space-between"><span class="suave">Último ticket: <b class="mono">${esc(t.codigo)}</b> ${esc(t.matricula || "")}</span>
      <button class="btn" id="b-ult-ver">Mostrar</button></div>`;
    $("#b-ult-ver").onclick = () => { ponerUltimoOculto(false); pintarUltimo(); };
    return;
  }
  u.innerHTML = `<div class="fila" style="justify-content:space-between"><h3>Último ticket</h3>
    <div class="fila" style="gap:8px"><button class="btn" id="b-reimp2">Reimprimir</button><button class="btn" id="b-ult-ocultar" title="Esconder el último ticket">Ocultar</button></div></div>
    <dl class="datos-ticket"><dt>Código</dt><dd class="mono">${esc(t.codigo)}</dd><dt>Matrícula</dt><dd>${esc(t.matricula || "—")}</dd>
    <dt>Entrada</dt><dd>${fechaHora(t.entrada)}${t.ajuste_min ? ` <span class="etiqueta e-aviso">${t.ajuste_min > 0 ? "+" : "−"}${Math.abs(t.ajuste_min)} min</span>` : ""}</dd><dt>Tarifa</dt><dd>${esc(t.tarifa_nombre)}</dd></dl>${t.id && !t.abonado && S.estado.estado_vehiculo ? `<button class="btn" id="b-estado43" style="margin-top: 12px;">${icono("camara")} Estado del vehículo</button>` : ""}
    ${t.impresion ? `<div style="margin-top:14px">${renderTicket(t.impresion)}</div>` : ""}
    ${t.abonado ? `<div class="aviso verde" style="margin-top:14px">${esc(t.mensaje)}<br><span style="font-weight:400">No se imprime ticket: el abonado entra y sale con su tarjeta o matrícula.</span></div>` : ""}`;
  $("#b-reimp2").onclick = accion(async () => { notarImpresion(await api("POST", `/api/tickets/${t.id}/reimprimir`)); toast("Reimpreso", "ok"); });
  $("#b-ult-ocultar").onclick = () => { ponerUltimoOculto(true); pintarUltimo(); };
  if ($("#b-estado43", u)) $("#b-estado43", u).onclick = () => modalEstadoVehiculo(t);
}

async function cargarTarifas() {
  try { S.tarifas = await api("GET", "/api/tarifas"); } catch (e) { toast(e.message, "err"); }
}

function montarOpcionesEntrada(sel) {
  const f = $("#f-entrada");
  if (!f || $("#e43", f)) return;
  const e = S.estado || {};
  const tipos = e.tipos_vehiculo || [];
  const zonas = e.zonas || [];
  if (tipos.length && !tipos.includes(S.entrada43.tipo)) S.entrada43.tipo = tipos[0];
  const caja = document.createElement("div");
  caja.id = "e43";
  const oc = (e.ocupacion && e.ocupacion.zonas) || [];
  caja.innerHTML = `${tipos.length ? `<div class="campo" style="margin-top:14px">Vehículo
      <div class="chips-veh">${tipos.map((t) => `<button type="button" class="chip-veh ${t === S.entrada43.tipo ? "activo" : ""}" data-tveh="${esc(t)}">${esc(t)}</button>`).join("")}</div></div>` : ""}
    ${zonas.length > 1 ? `<div class="campo" style="margin-top:14px">Zona<div class="chips-zona">${zonas.map((z) => {
      const o = oc.find((x) => x.id === z.id) || {};
      const llena = z.capacidad && o.ocupadas >= z.capacidad;
      return `<button type="button" class="chip-zona" data-zona="${z.id}" style="--zc:${esc(z.color || "#64748b")}" ${llena ? "disabled" : ""}>
        <i></i>${esc(z.nombre)}${z.capacidad ? `<span>${o.ocupadas || 0}/${z.capacidad}${llena ? " · completa" : ""}</span>` : ""}</button>`;
    }).join("")}</div><input type="hidden" id="e-zona"></div>` : ""}
    <div id="e-prevista"></div>
    ${e.ticket_digital ? `<details class="digital-caja" id="e-digital"><summary>${icono("movil")} Enviar el ticket al móvil <span class="suave">(sin papel)</span></summary>
      <div class="rejilla" style="grid-template-columns:minmax(0,1.4fr) minmax(0,1fr);gap:10px;margin-top:10px">
        <label class="campo">Teléfono del cliente<input class="ent" id="e-tel" type="tel" inputmode="tel" placeholder="600 000 000" autocomplete="off"></label>
        <label class="campo">Por<select class="ent" id="e-canal"><option value="whatsapp">WhatsApp</option><option value="sms">SMS</option></select></label></div>
      <label class="fila" style="gap:8px;margin-top:8px"><input type="checkbox" id="e-imp"> Imprimir también el ticket en papel</label></details>` : ""}`;
  const ref = $("#e-reserva") || sel.closest("label");
  ref.after(caja);
  const zSel = $("#e-zona", caja);
  if (zSel) {   // Zonas como botones con su color; de entrada, la que se usó la última vez (o la primera con sitio)
    const marcar = (b) => { zSel.value = b.dataset.zona; S.entrada43.zona = b.dataset.zona; $$("[data-zona]", caja).forEach((x) => x.classList.toggle("activo", x === b)); };
    const bs = $$("[data-zona]", caja).filter((b) => !b.disabled);
    marcar(bs.find((b) => b.dataset.zona === String(S.entrada43.zona)) || bs[0] || $("[data-zona]", caja));
    $$("[data-zona]", caja).forEach((b) => (b.onclick = () => { marcar(b); $("#e-mat").focus(); }));
  }
  const actualizarAuto = () => {
    const o = sel.querySelector('option[value=""]');
    if (!o) return;
    api("GET", "/api/tarifas/actual" + (S.entrada43.tipo ? "?tipo=" + encodeURIComponent(S.entrada43.tipo) : ""))
      .then((a) => { if (a.nombre) o.textContent = `Automática · ahora: ${a.nombre}`; }).catch(() => {});
  };
  $$("[data-tveh]", caja).forEach((b) => (b.onclick = () => {
    S.entrada43.tipo = b.dataset.tveh;
    $$("[data-tveh]", caja).forEach((x) => x.classList.toggle("activo", x === b));
    actualizarAuto();
    $("#e-mat").focus();
  }));
  if (tipos.length) actualizarAuto();
  // reserva de plataforma (Parclick, hotel…) para la matrícula que se escribe
  const mat = $("#e-mat");
  let tm, ultima = "";
  const buscar = async () => {
    const m = normMat(mat.value);
    const box = $("#e-prevista");
    if (!box || m === ultima) return;
    ultima = m;
    if (m.length < 4) { box.innerHTML = ""; return; }
    try {
      const av = await consultarAvisoReserva(m);
      const r = av.reserva && av.reserva.estado === "pendiente" ? av.reserva : null;
      if (normMat(mat.value) !== m) return;
      const propia = r && (r.origen === "web" || r.origen === "mostrador");
      if (r) avisoPorDeteccion(av, m);   // 1.12: ventana en cuanto se detecta la matrícula de una reserva
      box.innerHTML = r ? `<div class="prevista-caja ${av.aplica ? "" : "aun-no"}">${icono("calendario")}<div><b>${esc(nombreOrigenReserva(r))}${r.codigo ? ` · ${esc(r.codigo)}` : ""}</b>
          ${r.cliente ? ` · ${esc(r.cliente)}` : ""}<div class="suave">${!av.aplica ? `Aún no es la hora: empieza el ${fechaHora(r.desde)} (se admite desde las ${hora(av.ventana_desde)}).`
            : propia ? `Plaza guardada${r.zona_nombre ? ` en ${esc(r.zona_nombre)}` : ""} hasta el ${fechaHora(r.hasta)}. Al emitir el ticket se pedirá confirmar la reserva; se cobra la tarifa normal.`
            : `Sin cargo hasta el ${fechaHora(r.hasta)}. Se aplica al confirmar la entrada.`}</div></div></div>` : "";
    } catch (_) { /* sin permiso o sin conexión: se aplica igual en el servidor */ }
  };
  mat.addEventListener("input", () => { clearTimeout(tm); tm = setTimeout(buscar, 300); });
  f.addEventListener("reset", () => setTimeout(() => { ultima = ""; const b = $("#e-prevista"); if (b) b.innerHTML = ""; const d = $("#e-digital"); if (d) d.open = false; }, 0));
}

function datosOpcionesEntrada() {
  const d = {};
  if ((S.estado.tipos_vehiculo || []).length && S.entrada43.tipo) d.tipo_vehiculo = S.entrada43.tipo;
  const z = $("#e-zona");
  if (z) d.zona_id = Number(z.value);
  const tel = $("#e-tel");
  if (tel && tel.value.trim()) d.digital = { telefono: tel.value.trim(), canal: $("#e-canal").value, imprimir: $("#e-imp").checked };
  return d;
}

function trasEmitirEntrada(t) {
  if (t.reserva_prevista) toast(`Reserva aplicada (${[t.reserva_prevista.plataforma, t.reserva_prevista.ref].filter(Boolean).join(" ")}): sin cargo hasta ${fechaHora(t.reserva_hasta)}`, "ok");
  const dg = t.digital;
  if (!dg) return;
  if (dg.enviado) { toast(`Ticket enviado por ${dg.canal === "whatsapp" ? "WhatsApp" : "SMS"} al ${dg.telefono}`, "ok"); return; }
  const m = modal(`<h2 class="titulo-icono">${icono("movil", 24)}Enviar el ticket al móvil</h2>
    <p>${dg.error ? `No se pudo enviar automáticamente (${esc(dg.error)}). ` : ""}Pulse el botón para abrir WhatsApp con el mensaje ya escrito para el <b>${esc(dg.telefono)}</b>.</p>
    ${dg.texto ? `<pre class="msg-previo">${esc(dg.texto)}</pre>` : ""}
    <div class="modal-pie"><button class="btn" data-c>Cerrar</button><a class="btn prim" href="${esc(dg.enlace)}" target="_blank" rel="noopener" id="dg-abrir">Abrir WhatsApp</a></div>`);
  $("[data-c]", m).onclick = cerrarModal;
  $("#dg-abrir", m).onclick = () => setTimeout(cerrarModal, 300);
}

async function sondearCamara() {
  const vista = S.vista === "entrada" ? "entrada" : S.vista === "cobrar" ? "salida" : null;
  const caja = vista && $(`#lpr-${vista}`);
  if (!caja || !S.estado || !S.estado.lpr) return;
  try {
    const ls = await api("GET", `/api/lpr/ultimas?camara=${vista}&desde=${S.lpr.ultimo || 0}`);
    if (S.lpr.ultimo === null) { S.lpr.ultimo = ls.length ? ls[0].id : 0; return; }   // al abrir: no repetir lecturas antiguas
    if (!ls.length) return;
    const l = ls[0];
    S.lpr.ultimo = l.id;
    caja.innerHTML = `<div class="lectura-camara"><span>📷</span><div style="flex:1"><div class="suave" style="font-size:.8rem">Cámara de ${vista} · ${hora(l.fecha)}${l.confianza != null ? ` · ${Math.round(l.confianza)}%` : ""}</div>
      <span class="mono">${esc(l.matricula)}</span>${l.resultado && l.resultado !== "registrada" ? ` <span class="suave" style="font-size:.85rem">${esc(l.resultado)}</span>` : ""}</div>
      <button type="button" class="btn prim" id="lpr-usar">${vista === "entrada" ? "Usar" : "Buscar"}</button></div>`;
    const usar = () => {
      if (vista === "entrada") { const i = $("#e-mat"); if (i) { i.value = l.matricula; i.dispatchEvent(new Event("input", { bubbles: true })); i.focus(); } }
      else { const i = $("#escaner"); if (i) i.value = l.matricula; buscarPorMatricula(l.matricula); }
    };
    $("#lpr-usar").onclick = usar;
    if (vista === "entrada" && l.resultado === "registrada" && $("#e-mat") && !$("#e-mat").value) usar();
    if (vista === "entrada" && String(l.resultado || "").startsWith("ticket ")) avisarEntradaCamara(l);   // 1.11: entró solo por la cámara
    if (vista === "salida" && S.estado.lpr_salida_accion === "buscar" && l.resultado === "registrada" && !S.cobro.ticket) usar();
    if (vista === "entrada" && /^ticket /.test(l.resultado || "")) refrescarEstado();
  } catch (_) { /* sin conexión: se reintenta */ }
}

// ============================== Reserva (hotel o parking pagado en otro sitio)

function tarifaReserva(id) { return (S.tarifas || []).find((t) => t.id === Number(id) && t.modo === "reserva"); }

// datetime-local con hora local: 2026-10-15T08:49
function fechaLocalInput(d) {
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
}

function htmlCamposReserva(t, pref = "rs", hastaIni = "", entrada = null) {
  if (t.reserva_modo === "fecha") {   // 4.43: reserva por fecha: entrada (la actual, con botón para cambiarla) y salida reservadas
    const ini = entrada ? new Date(entrada) : new Date();
    const [h, m] = (t.reserva_hora || "12:00").split(":").map(Number);
    const sal = new Date(ini); sal.setDate(sal.getDate() + 1); sal.setHours(h, m, 0, 0);
    return `<div class="reserva-campos reserva-fecha">
      <div class="rf-bloque"><span class="rf-et">Fecha de entrada <small>${entrada ? "entrada del vehículo" : "hoy, ahora"}</small></span>
        <b class="rf-valor" id="${pref}-desde-txt">${esc(ini.toLocaleString("es-ES", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }))}</b>
        <input class="ent" id="${pref}-desde" type="datetime-local" value="${fechaLocalInput(ini)}" hidden>
        <button type="button" class="rf-cambiar" id="${pref}-desde-btn">Cambiar fecha de entrada</button></div>
      <span class="rf-flecha" aria-hidden="true">→</span>
      <label class="rf-bloque"><span class="rf-et">Fecha de salida reservada</span>
        <input class="ent rf-in" id="${pref}-hasta" type="datetime-local" value="${esc(hastaIni || fechaLocalInput(sal))}"></label>
      <label class="campo reserva-ref">Nº de reserva / habitación (opcional)<input class="ent" id="${pref}-ref" maxlength="60" placeholder="Hab. 204, BK-12345…"></label></div>
      <p class="reserva-fin" id="${pref}-fin"></p>`;
  }
  return `<div class="reserva-campos">
    <label class="campo">Noches<input class="ent num" id="${pref}-noches" type="number" min="1" max="60" value="${t.reserva_noches || 1}"></label>
    <span class="reserva-o">o</span>
    <label class="campo">Hasta (fecha y hora)<input class="ent" id="${pref}-hasta" type="datetime-local" value="${esc(hastaIni)}"></label>
    <label class="campo reserva-ref">Nº de reserva / habitación<input class="ent" id="${pref}-ref" maxlength="60" placeholder="Hab. 204, BK-12345…"></label></div>
    <p class="reserva-fin" id="${pref}-fin"></p>`;
}

// Muestra al momento hasta cuándo dura la reserva con lo que se ha escrito
function vigilarReserva(t, pref, raiz, entrada) {
  const fmt = (f) => `${f.toLocaleDateString("es-ES", { weekday: "long", day: "numeric", month: "long" })} a las ${f.toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" })}`;
  const btn = $(`#${pref}-desde-btn`, raiz);
  if (btn) btn.onclick = () => {   // permite escribir otra fecha de entrada de la reserva
    const i = $(`#${pref}-desde`, raiz);
    i.hidden = !i.hidden;
    $(`#${pref}-desde-txt`, raiz).style.display = i.hidden ? "" : "none";
    btn.textContent = i.hidden ? "Cambiar fecha de entrada" : "Usar la fecha actual";
    if (i.hidden) i.value = fechaLocalInput(entrada ? new Date(entrada) : new Date());
    if (!i.hidden) i.focus();
    pintar();
  };
  const pintar = () => {
    const p = $(`#${pref}-fin`, raiz);
    if (!p) return;
    const base = entrada ? new Date(entrada) : new Date();
    const d = leerCamposReserva(pref, raiz);
    let fin = null;
    if (d.hasta) fin = new Date(d.hasta);
    else if (d.noches) {
      const [h, m] = (t.reserva_hora || "12:00").split(":").map(Number);
      fin = new Date(base); fin.setDate(fin.getDate() + d.noches); fin.setHours(h, m, 0, 0);
    }
    const ini = d.desde ? new Date(d.desde) : null;
    if (!fin || Number.isNaN(fin.getTime()) || fin <= base) p.innerHTML = '<span style="color:var(--rojo)">La reserva debe terminar después de la entrada</span>';
    else if (ini && !Number.isNaN(ini.getTime()) && fin <= ini) p.innerHTML = '<span style="color:var(--rojo)">La salida debe ser posterior a la entrada de la reserva</span>';
    else if (ini && ini > base) p.innerHTML = `Sin cargo desde el <b>${fmt(ini)}</b> hasta el <b>${fmt(fin)}</b>. Fuera de esas fechas se cobra con la tarifa de después.`;
    else p.innerHTML = `Sin cargo hasta el <b>${fmt(fin)}</b>`;
  };
  $$(`#${pref}-noches, #${pref}-hasta, #${pref}-desde`, raiz).forEach((i) => i.addEventListener("input", pintar));
  pintar();
}

function leerCamposReserva(pref = "rs", raiz = document) {
  const v = (s) => { const x = $(`#${pref}-${s}`, raiz); return x ? x.value.trim() : ""; };
  const d = { ref: v("ref") };
  const desde = $(`#${pref}-desde`, raiz);
  if (desde && !desde.hidden && desde.value) d.desde = desde.value;   // solo si se ha elegido otra fecha de entrada
  if (v("hasta")) d.hasta = v("hasta");
  else d.noches = Number(v("noches")) || 1;
  return d;
}

function montarReservaEntrada(sel) {
  if (!sel) return;
  let caja = $("#e-reserva");
  if (!caja) { caja = document.createElement("div"); caja.id = "e-reserva"; sel.closest("label").after(caja); }
  const pintar = () => {
    const t = tarifaReserva(sel.value);
    if (!t) { caja.innerHTML = ""; return; }
    if (caja.dataset.t === String(t.id) && caja.innerHTML) return;
    caja.dataset.t = String(t.id);
    caja.innerHTML = `<div class="reserva-caja reserva-entrada">
      <div class="reserva-cab"><span class="reserva-ico">🏨</span><div><b>Reserva / hotel</b>
        <div class="suave">El tiempo reservado no se cobra. Después, tarifa <b>${esc((S.tarifas.find((x) => x.id === t.tarifa_despues_id) || {}).nombre || "por defecto")}</b>.</div></div></div>
      ${htmlCamposReserva(t, "er")}</div>`;
    vigilarReserva(t, "er", caja);
  };
  sel.addEventListener("change", () => { caja.dataset.t = ""; pintar(); });
  const f = sel.form;
  if (f) f.addEventListener("reset", () => setTimeout(() => { caja.dataset.t = ""; pintar(); }, 0));
  pintar();
}

function datosReservaEntrada() {
  const sel = $("#e-tarifa");
  return sel && tarifaReserva(sel.value) && $("#e-reserva") ? leerCamposReserva("er", $("#e-reserva")) : null;
}

function modalReservaTicket(t) {
  const reservas = (S.tarifas || []).filter((x) => x.activa && x.modo === "reserva");
  if (!reservas.length) return toast("Cree antes una tarifa de tipo «Reserva / hotel» (Ajustes → Precios → Tarifas)", "err");
  const m = modal(`<h2>Reserva del vehículo ${esc(t.matricula || t.codigo)}</h2>
    <p class="suave">Entró el ${fechaHora(t.entrada)}. El tiempo reservado no se cobra; pasado, se cobra con la tarifa del parking desde el fin de la reserva.</p>
    <label class="campo" style="margin-top:10px">Tarifa de reserva<select class="ent" id="mr-tar">${reservas.map((x) => `<option value="${x.id}" ${x.id === t.tarifa_id ? "selected" : ""}>${esc(x.nombre)}</option>`).join("")}</select></label>
    <div id="mr-campos"></div>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Aplicar reserva</button></div>`);
  const pintar = () => {
    const tr = tarifaReserva($("#mr-tar", m).value);
    $("#mr-campos", m).innerHTML = htmlCamposReserva(tr, "mr", "", t.entrada);
    vigilarReserva(tr, "mr", m, t.entrada);
  };
  $("#mr-tar", m).onchange = pintar; pintar();
  $("[data-c]", m).onclick = cerrarModal;
  $("[data-ok]", m).onclick = accion(async () => {
    const d = { tarifa_id: Number($("#mr-tar", m).value), ...leerCamposReserva("mr", m) };
    await api("POST", `/api/tickets/${t.id}/reserva`, d);
    cerrarModal(); toast("Reserva aplicada", "ok"); buscarTicket("", { id: t.id });
  });
}

// ================================================================= Lista negra

function htmlListaNegra(ln) {
  return `<div class="aviso-ln"><b>⛔ LISTA NEGRA · ${esc(ln.matricula)}</b><div>${esc(ln.motivo)}</div>
    ${ln.nota ? `<div class="suave" style="font-size:.85rem">${esc(ln.nota)}</div>` : ""}
    <div class="suave" style="font-size:.8rem">Añadida el ${fechaHora(ln.creada)}${ln.creada_por ? ` por ${esc(ln.creada_por)}` : ""}</div></div>`;
}

// Entrada: aviso al escribir la matrícula
function avisoListaNegra(input) {
  if (!input || !tieneModulo("gestion")) return;
  let caja = $("#e-ln");
  if (!caja) { caja = document.createElement("div"); caja.id = "e-ln"; input.closest("label").after(caja); }
  let tm, ultima = "";
  const comprobar = async () => {
    const m = input.value.replace(/[^0-9a-z]/gi, "").toUpperCase();
    if (m === ultima) return;
    ultima = m;
    if (m.length < 4) { caja.innerHTML = ""; return; }
    try {
      const r = await api("GET", "/api/lista-negra/comprobar?matricula=" + encodeURIComponent(m));
      if (input.value.replace(/[^0-9a-z]/gi, "").toUpperCase() === m) caja.innerHTML = r.lista_negra ? htmlListaNegra(r.lista_negra) : "";
    } catch (_) { /* sin conexión: se avisa al emitir */ }
  };
  input.addEventListener("input", () => { clearTimeout(tm); tm = setTimeout(comprobar, 250); });
  input.form && input.form.addEventListener("reset", () => { caja.innerHTML = ""; ultima = ""; });
}

// 4.50: Entrada: comentario interno del vehículo al escribir la matrícula (y botón para ver su historial)
function avisoNotaVehiculo(input) {
  if (!input) return;
  let caja = $("#e-nota");
  if (!caja) { caja = document.createElement("div"); caja.id = "e-nota"; (($("#e-ln") || input.closest("label"))).after(caja); }
  let tm, ultima = "";
  const comprobar = async () => {
    const m = input.value.replace(/[^0-9a-z]/gi, "").toUpperCase();
    if (m === ultima) return;
    ultima = m;
    if (m.length < 4) { caja.innerHTML = ""; return; }
    try {
      const r = await api("GET", "/api/vehiculo/nota?matricula=" + encodeURIComponent(m));
      if (input.value.replace(/[^0-9a-z]/gi, "").toUpperCase() !== m) return;
      caja.innerHTML = htmlNotaVehiculo(r.nota, false);
    } catch (_) { /* sin conexión: no se avisa */ }
  };
  input.addEventListener("input", () => { clearTimeout(tm); tm = setTimeout(comprobar, 250); });
  input.form && input.form.addEventListener("reset", () => { caja.innerHTML = ""; ultima = ""; });
}

// ===================================================== 4.54: matrícula o ticket que ya está dentro

// Devuelve el ticket si lo escrito (matrícula o código de ticket) corresponde a un vehículo que ya está dentro; si no, null
async function buscarYaDentro(texto) {
  const t = (texto || "").trim();
  if (!t) return null;
  const limpio = t.replace(/[^A-Za-z0-9]/g, "");
  try {
    if (/^[A-Z]{1,3}\d{7}[0-9A-F]{5}$/i.test(limpio)) {   // código de ticket (o tarjeta de abonado)
      const r = await api("GET", `/api/tickets/consultar?codigo=${encodeURIComponent(limpio)}`);
      const tk = r.tipo === "abonado" ? r.dentro : r;
      if (!tk || !["dentro", "pagado"].includes(tk.estado || "dentro")) return null;
      return r.tipo === "abonado" ? await api("GET", `/api/tickets/consultar?id=${tk.id}`) : r;
    }
    const mat = normMat(t);
    if (mat.length < 2) return null;
    const filas = await api("GET", "/api/dentro?buscar=" + encodeURIComponent(mat));
    const f = filas.find((x) => normMat(x.matricula) === mat);
    return f ? await api("GET", `/api/tickets/consultar?id=${f.id}`) : null;
  } catch (_) { return null; }   // si falla la consulta, se sigue el camino normal (el servidor también lo comprueba)
}

function modalYaDentro(t) {
  const limpiar = () => { const e = $("#e-mat"); if (e) { e.value = ""; e.focus(); } };
  const puedeAnular = t.estado === "dentro" && !t.cliente_id;
  const m = modal(`<h2>Este vehículo ya está dentro</h2>
    <dl class="datos-ticket"><dt>Ticket</dt><dd class="mono">${esc(t.codigo)}</dd><dt>Matrícula</dt><dd><b>${esc(t.matricula || "—")}</b></dd>
      <dt>Entrada</dt><dd>${fechaHora(t.entrada)}</dd><dt>Tarifa</dt><dd>${esc(t.tarifa_nombre || "—")}</dd></dl>
    <p class="suave">¿Qué quiere hacer?</p>
    <div class="ya-dentro-acciones">
      <button class="btn prim" data-a="reimp">Reimprimir ticket</button>
      <button class="btn" data-a="mod">Modificar matrícula o tarifa…</button>
      ${puedeAnular ? '<button class="btn peligro" data-a="anular">Anular ticket…</button>' : ""}
      <button class="btn" data-a="cancelar">Cancelar</button></div>`);
  const cerrar = () => { cerrarModal(); limpiar(); };
  $('[data-a="cancelar"]', m).onclick = () => { cerrarModal(); const e = $("#e-mat"); if (e) e.focus(); };
  $('[data-a="reimp"]', m).onclick = accion(async () => {
    notarImpresion(await api("POST", `/api/tickets/${t.id}/reimprimir`));
    toast("Ticket reimpreso", "ok"); cerrar();
  });
  $('[data-a="mod"]', m).onclick = () => { cerrarModal(); modalModificarEntrada(t, limpiar, { tarifa: t.estado === "dentro" && !t.cliente_id }); };
  if (puedeAnular) $('[data-a="anular"]', m).onclick = () => { cerrarModal(); modalAnular(t.id, t.codigo, () => { limpiar(); pintarUltimo(); }); };
}

// Cambia a la vez la matrícula y la tarifa de un vehículo que está dentro
const modalModificarEntrada = accion(async (t, despues, { tarifa = true } = {}) => {
  const tarifas = tarifa ? (await api("GET", "/api/tarifas")).filter((x) => x.activa) : [];
  const m = modal(`<h2>Modificar entrada</h2>
    <p class="suave">Ticket <span class="mono">${esc(t.codigo)}</span> · entrada ${fechaHora(t.entrada)}</p>
    <form id="f-mod-ent"><label class="campo">Matrícula<input class="ent grande mono" id="me-mat" value="${esc(t.matricula || "")}" style="text-transform:uppercase" autocomplete="off" spellcheck="false" placeholder="Vacío = sin matrícula…"></label>
      ${tarifas.length ? `<label class="campo">Tarifa<select class="ent" id="me-tar">${tarifas.map((x) => `<option value="${x.id}" ${x.id === t.tarifa_id ? "selected" : ""}>${esc(x.nombre)}${x.por_defecto ? " (por defecto)" : ""}</option>`).join("")}</select></label>
      <p class="ayuda">El importe se recalcula con la tarifa nueva desde la hora de entrada. Queda registrado en auditoría.</p>` : '<p class="ayuda">La tarifa no se puede cambiar en este ticket (abonado o ya tiene pagos). Queda registrado en auditoría.</p>'}
      <div class="modal-pie"><button type="button" class="btn" data-c>Cancelar</button><button class="btn prim">Guardar cambios</button></div></form>`);
  $("#me-mat", m).focus(); $("#me-mat", m).select();
  $("[data-c]", m).onclick = () => { cerrarModal(); const e = $("#e-mat"); if (e) e.focus(); };
  $("#f-mod-ent", m).onsubmit = accion(async (e) => {
    e.preventDefault();
    const mat = $("#me-mat", m).value, tar = $("#me-tar", m) ? Number($("#me-tar", m).value) : 0;
    let cambios = [];
    if (normMat(mat) !== normMat(t.matricula || "")) { await api("POST", `/api/tickets/${t.id}/matricula`, { matricula: mat }); cambios.push("matrícula"); }
    if (tar && tar !== t.tarifa_id) { await api("POST", `/api/tickets/${t.id}/tarifa`, { tarifa_id: tar }); cambios.push("tarifa"); }
    cerrarModal();
    toast(cambios.length ? `Cambiado: ${cambios.join(" y ")}` : "Sin cambios", cambios.length ? "ok" : "");
    despues && despues();
  });
});

// Emitir el ticket: si la matrícula está en la lista negra, se pregunta (o se pide un supervisor)
async function emitirConListaNegra(cuerpo) {
  try {
    return await api("POST", "/api/tickets", cuerpo);
  } catch (e) {
    if (e.status !== 423 || !e.datos || !e.datos.lista_negra) throw e;
    const extra = await preguntarListaNegra(e.datos.lista_negra);
    if (!extra) { toast("No se ha emitido el ticket", ""); return null; }
    return api("POST", "/api/tickets", { ...cuerpo, ...extra });
  }
}

function preguntarListaNegra(ln) {
  return new Promise((ok) => {
    const sup = tieneRol("admin", "supervisor");
    const pideSup = ln.modo === "bloquear" && !sup;
    const m = modal(`<h2 style="color:var(--rojo)">Matrícula en la lista negra</h2>
      ${htmlListaNegra(ln)}
      <p style="margin-top:12px">${pideSup ? "Para dejarla entrar hace falta la <b>autorización de un supervisor</b>." : "¿Dejar entrar al vehículo igualmente? Quedará anotado."}</p>
      ${pideSup ? `<div class="rejilla r2"><label class="campo">Usuario del supervisor<input class="ent" id="ln-au" autocomplete="off" autofocus></label>
        <label class="campo">PIN<input class="ent" id="ln-ap" type="password" inputmode="numeric"></label></div>` : ""}
      <div class="modal-pie"><button class="btn prim" data-no>No dejar entrar</button><button class="btn peligro" data-si>Dejar entrar igualmente</button></div>`);
    $("[data-no]", m).onclick = () => { cerrarModal(); ok(null); };
    $("[data-si]", m).onclick = () => {
      const r = { lista_negra_ok: true };
      if (pideSup) r.autorizacion = { usuario: $("#ln-au", m).value, pin: $("#ln-ap", m).value };
      cerrarModal(); ok(r);
    };
    if (!pideSup) setTimeout(() => $("[data-no]", m).focus(), 40);
  });
}

// =============================================================== Ticket manual

const modalTicketManual = accion(async (modoInicial = "salida") => {
  if (!S.estado.turno || S.estado.turno.usuario_id !== S.usuario.id) throw new Error("Abra su turno de caja primero (F5)");
  await cargarTarifas();
  const prods = await api("GET", "/api/productos?activos=1");
  const ahora = new Date();
  const st = { modo: modoInicial, metodo: "efectivo", importe: null, calc: null, extras: [] };
  const m = modal(`<div class="mn-cab"><div><h2>Ticket manual</h2>
      <p class="suave">Para vehículos sin ticket del sistema (corte de luz, impresora averiada, entrada en papel…). Queda marcado como manual y en auditoría.</p></div>
      <div class="mn-modo" role="group" aria-label="Tipo de ticket manual">
        <button class="btn ${st.modo === "salida" ? "sel" : ""}" data-modo="salida">Entrada y salida · cobrar</button>
        <button class="btn ${st.modo === "entrada" ? "sel" : ""}" data-modo="entrada">Solo entrada</button></div></div>
    <div class="mn-grid"><div class="mn-datos">
      <div class="mn-campos">
        <label class="campo">Matrícula<input class="ent mono" id="mn-mat" style="text-transform:uppercase" placeholder="1234 ABC" autofocus></label>
        <label class="campo">Tarifa<select class="ent" id="mn-tar">${S.tarifas.filter((t) => t.activa).map((t) => `<option value="${t.id}" ${t.por_defecto ? "selected" : ""}>${esc(t.nombre)}</option>`).join("")}</select></label>
        <label class="campo">Entrada<input class="ent" type="datetime-local" id="mn-ent" value="${aLocalInput(ahora.getTime() - 3600e3)}" max="${aLocalInput(ahora)}"></label>
        <label class="campo" id="mn-sal-l">Salida <span class="ayuda">puede ser futura (se cobra por adelantado)</span>
          <input class="ent" type="datetime-local" id="mn-sal" value="${aLocalInput(ahora)}"></label>
        <label class="campo mn-motivo">Motivo <span class="ayuda">opcional</span>
          <input class="ent" id="mn-mot" list="motivos-manual" placeholder="Corte de luz, impresora averiada…">
          <datalist id="motivos-manual"><option value="Corte de luz"><option value="Impresora averiada"><option value="Ordenador apagado o reiniciado">
            <option value="Entrada anotada en papel"><option value="Cliente sin ticket del sistema"></datalist></label>
      </div>
      ${prods.length ? `<div class="extras-caja">
        <div class="fila"><b>Servicios</b>
          <select class="ent" id="mn-prod" style="flex:1;min-width:150px">${prods.map((p) => `<option value="${p.id}">${esc(p.nombre)} · ${p.precio_variable ? "precio al añadir" : eur(p.precio_cent)}${p.minutos_incluidos ? ` (+${duracion(p.minutos_incluidos)} parking)` : ""}</option>`).join("")}</select>
          <input class="ent num" id="mn-cant" type="number" min="1" max="99" value="1" style="width:64px" aria-label="Cantidad">
          <button type="button" class="btn" id="mn-add">+ Añadir</button></div>
        <div id="mn-extras"></div></div>` : ""}
    </div>
    <div class="mn-cobro"><div id="mn-calc"></div><div id="mn-pago"></div></div></div>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn ok xl" data-ok>…</button></div>`, { ancho: true });

  const pintarPago = () => {
    const pagoEl = $("#mn-pago");
    if (st.modo !== "salida" || !st.importe) { pagoEl.innerHTML = ""; return; }
    pagoEl.innerHTML = `<div class="metodos mn-metodos"><button class="btn ${st.metodo === "efectivo" ? "sel" : ""}" data-m="efectivo">Efectivo</button>
      <button class="btn ${st.metodo === "tarjeta" ? "sel" : ""}" data-m="tarjeta">Tarjeta</button></div>
      ${st.metodo === "efectivo" ? `<div class="mn-entregado"><label class="campo">Entregado<input class="ent num" id="mn-entr" inputmode="decimal" placeholder="Cantidad recibida"></label>
      <div class="cambio" id="mn-cambio"><span>Cambio</span><span class="v num">0,00 €</span></div></div>` : ""}`;
    $$("[data-m]", pagoEl).forEach((b) => (b.onclick = () => { st.metodo = b.dataset.m; pintarPago(); }));
    const inp = $("#mn-entr");
    if (inp) inp.oninput = () => {
      const cc = $("#mn-cambio");
      if (pintarSinEntregado(inp, cc)) return;
      const e = aCent(inp.value), dif = e - st.importe;
      cc.className = "cambio" + (Number.isNaN(dif) || dif < 0 ? " falta" : "");
      cc.innerHTML = Number.isNaN(dif) ? "<span>Importe no válido</span>" : `<span>${dif < 0 ? "Faltan" : "Cambio"}</span><span class="v num">${eur(Math.abs(dif))}</span>`;
    };
  };
  const boton = () => {
    const b = $("[data-ok]", m);
    b.textContent = st.modo === "entrada" ? "Registrar entrada e imprimir ticket"
      : st.importe ? `Cobrar ${eur(st.importe)} y registrar` : "Registrar entrada y salida";
  };
  let tm;
  const calcular = async () => {
    const c = $("#mn-calc");
    if (st.modo === "entrada") {
      st.importe = null;
      c.innerHTML = `<div class="aviso">Se imprimirá un ticket con la hora de entrada indicada, marcado como «ENTRADA MANUAL». Se cobrará al salir como cualquier otro.</div>`;
      pintarPago(); boton(); return;
    }
    try {
      const r = await api("POST", "/api/tickets/manual/calcular", { entrada: $("#mn-ent").value, salida: $("#mn-sal").value, tarifa_id: Number($("#mn-tar").value), extras: st.extras });
      st.importe = r.importe_cent;
      const futura = new Date(r.salida).getTime() > Date.now() + 60e3;
      c.innerHTML = `<div class="total ${r.importe_cent ? "" : "cero"}"><div class="t">Estancia de ${duracion(r.minutos)} · ${esc(r.tarifa_nombre)}</div>
        <div class="v num">${eur(r.importe_cent)}</div>
        ${r.extras_cent ? `<div class="desglose"><div><span>Estancia${r.minutos_incluidos ? ` (${duracion(r.minutos_incluidos)} incluidos en servicios)` : ""}</span><span class="num">${eur(r.importe_estancia_cent)}</span></div>
          <div><span>Servicios y productos</span><span class="num">${eur(r.extras_cent)}</span></div></div>` : ""}</div>
        ${futura ? `<div class="aviso" style="margin-top:10px">Salida futura: se cobra ahora por adelantado. El vehículo queda <b>dentro</b> y puede salir hasta las ${hora(r.salida)} (más el margen de salida); si se pasa, paga la diferencia.</div>` : ""}`;
    } catch (e) {
      st.importe = null;
      c.innerHTML = `<div class="aviso rojo">${esc(e.message)}</div>`;
    }
    pintarPago(); boton();
  };
  const recalc = () => { clearTimeout(tm); tm = setTimeout(calcular, 250); };
  const pintarExtras = () => {
    const el = $("#mn-extras");
    if (!el) return;
    el.innerHTML = st.extras.length ? `<table class="tabla extras-tabla"><tbody>${st.extras.map((x, i) => {
      const p = prods.find((q) => q.id === x.producto_id);
      return `<tr><td>${esc(p.nombre)}${p.minutos_incluidos ? `<div class="suave" style="font-size:.8rem">incluye ${duracion(p.minutos_incluidos * x.cantidad)} de parking</div>` : ""}</td>
        <td class="der num">${x.cantidad} ×</td><td class="der num">${eur((x.precio_cent ?? p.precio_cent) * x.cantidad)}</td>
        <td class="der"><button type="button" class="btn mini peligro" data-qx="${i}" title="Quitar">✕</button></td></tr>`;
    }).join("")}</tbody></table>`
      : `<div class="suave" style="font-size:.88rem;margin-top:6px">${st.modo === "entrada" ? "Quedarán pendientes y se cobrarán a la salida." : "Se cobran junto con la estancia en la misma factura."}</div>`;
    $$("[data-qx]", el).forEach((b) => (b.onclick = () => { st.extras.splice(Number(b.dataset.qx), 1); pintarExtras(); calcular(); }));
  };
  if ($("#mn-add")) $("#mn-add").onclick = async () => {
    const pid = Number($("#mn-prod").value), cant = Math.max(1, Math.min(99, Number($("#mn-cant").value) || 1));
    const prod = prods.find((q) => q.id === pid);
    let precio;   // 4.62: servicio sin precio fijo → se pregunta ahora
    if (prod && prod.precio_variable) { precio = await pedirPrecio(prod.nombre); if (precio === null) return; }
    const ya = st.extras.find((x) => x.producto_id === pid && x.precio_cent === precio);
    if (ya) ya.cantidad = Math.min(99, ya.cantidad + cant); else st.extras.push(precio === undefined ? { producto_id: pid, cantidad: cant } : { producto_id: pid, cantidad: cant, precio_cent: precio });
    $("#mn-cant").value = 1;
    pintarExtras(); calcular();
  };
  pintarExtras();
  ["#mn-ent", "#mn-sal", "#mn-tar"].forEach((s) => ($(s).oninput = recalc));
  $$("[data-modo]", m).forEach((b) => (b.onclick = () => {
    st.modo = b.dataset.modo;
    pintarExtras();
    $$("[data-modo]", m).forEach((x) => x.classList.toggle("sel", x === b));
    $("#mn-sal-l").classList.toggle("oculto", st.modo === "entrada");
    calcular();
  }));
  $("#mn-sal-l").classList.toggle("oculto", st.modo === "entrada");
  $("[data-c]", m).onclick = cerrarModal;
  $("[data-ok]", m).onclick = accion(async () => {
    const motivo = $("#mn-mot").value.trim();
    const datos = { matricula: $("#mn-mat").value, tarifa_id: Number($("#mn-tar").value), entrada: $("#mn-ent").value,
      salida: st.modo === "salida" ? $("#mn-sal").value : null, motivo, metodo: st.metodo, extras: st.extras };
    if (st.modo === "salida" && st.importe && st.metodo === "efectivo") {
      const v = ($("#mn-entr") || {}).value || "";
      datos.entregado_cent = entregadoEfectivo(v, st.importe, "#mn-entr");
    }
    const r = await api("POST", "/api/tickets/manual", datos);
    notarImpresion(r.impresion);
    refrescarEstado();
    const ok = modal(`<div class="exito"><div class="icono">✓</div>
      <h2>${datos.salida ? (r.pago ? `Cobrado ${eur(r.pago.importe_cent)}` : "Registrado sin cargo") : "Entrada manual registrada"}</h2>
      ${r.salida_futura ? `<div class="aviso verde">Pagado por adelantado: puede salir hasta las ${hora(r.salida_limite)}</div>` : ""}
      ${r.pago && r.pago.metodo === "efectivo" ? `<p class="suave" style="margin:14px 0 2px">Cambio a devolver</p><div class="grande num">${eur(r.pago.cambio_cent)}</div>` : ""}
      <p class="suave">Ticket <span class="mono">${esc(r.ticket.codigo)}</span>${r.ticket.matricula ? " · " + esc(r.ticket.matricula) : ""} · marcado como manual</p></div>
      <div class="modal-pie">${r.impresion ? '<button class="btn" id="mn-ver">Ver ticket impreso</button>' : ""}
        ${r.pago ? '<button class="btn" id="mn-fac">Factura con datos / email</button>' : ""}<button class="btn prim" data-c autofocus>Aceptar</button></div>`);
    if ($("#mn-ver")) $("#mn-ver").onclick = () => verImpresion(r.impresion);
    if ($("#mn-fac")) $("#mn-fac").onclick = () => modalFactura(r.pago.id);
    $("[data-c]", ok).onclick = () => { cerrarModal(); if (S.vista === "vehiculos") pintarVista(); };
  });
  calcular();
});

// ============================================================ al cargar

S.lpr = S.lpr || { ultimo: null, timer: null };

S.entrada43 = S.entrada43 || { tipo: null };

// 1.11: la cámara de entrada emitió el ticket sola: si el vehículo tenía reserva, se avisa al personal
async function avisarEntradaCamara(l) {
  const av = await consultarAvisoReserva(l.matricula);
  if (av.reserva && av.reserva.estado === "usada") toast(`${l.matricula} ha entrado con la reserva ${av.reserva.codigo || av.reserva.ref || ""}`, "ok");
}
