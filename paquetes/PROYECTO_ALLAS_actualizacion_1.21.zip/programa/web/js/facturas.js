/* PROYECTO ALLAS · facturas: datos del cliente, email, búsqueda, devoluciones y rectificación */
"use strict";

// ============================= Factura con datos del cliente y envío por email

const ESTADO_EMAIL = { enviado: ["e-pagado", "Enviado"], pendiente: ["e-aviso", "Pendiente"], error: ["e-err", "Error"] };

// 4.64: estado de la factura (se cambia a mano; al enviarla pasa sola a «Enviada»)
const ESTADO_FACTURA = { generada: ["e-aviso", "Generada"], enviada: ["e-dentro", "Enviada"], cobrada: ["e-pagado", "Cobrada"] };
// 1.2: piezas comunes del estado de factura (etiqueta de color y opciones del desplegable)
const chipEstadoFactura = (est) => (ESTADO_FACTURA[est] ? `<span class="etiqueta ${ESTADO_FACTURA[est][0]}">${ESTADO_FACTURA[est][1]}</span>` : "");
const opcionesEstadoFactura = (actual) => Object.entries(ESTADO_FACTURA).map(([k, v]) => `<option value="${k}" ${actual === k ? "selected" : ""}>${v[1]}</option>`).join("");

const METODOS_EMAIL = {
  gmail_web: "Gmail en el navegador",
  outlook: "Programa de correo del PC (Outlook)",
  smtp: "Envío automático (servidor SMTP)",
};

const clienteTxt = (c) => c
  ? `Enlazada a <b>${esc(c.nombre)}</b> (${c.tipo === "facturacion" ? "cliente sin abono" : "abonado"}): se actualizan sus datos.`
  : "Se crea como <b>cliente sin abono</b> (aparte de los abonados) con la matrícula de esta estancia; si ya existe uno con el mismo NIF, se actualiza.";

const modalFactura = accion(async (pagoId, alCerrar) => {
  const f = await api("GET", `/api/facturas/${pagoId}`);
  const guardado = f.destinatario || {};
  // Si aún no tiene datos y es un cliente conocido, se rellenan (se guardan al usar cualquier botón)
  const ini = f.destinatario ? guardado : (f.sugerencia || {});
  const num = `${f.serie}-${String(f.numero).padStart(6, "0")}`;
  const prov = !!f.proveedor;   // 1.1: la factura a proveedor tiene su propia ventana: sin datos que reescribir ni vista de ticket
  const metodo = S.estado.email_metodo || "gmail_web";
  const m = modal(`<div class="fila" style="justify-content:space-between"><h2>Factura ${esc(num)}</h2>
      <span class="etiqueta ${f.proveedor ? "e-aviso" : f.destinatario ? "e-pagado" : "e-salido"}" id="fx-chip">${f.proveedor ? "Proveedor" : f.destinatario ? "Con datos del cliente" : "Simplificada"}</span></div>
    <div class="fila" style="margin:6px 0 10px;gap:8px"><label for="fx-estado" class="suave">Estado de la factura</label>
      <select class="ent" id="fx-estado" style="width:auto;min-height:36px;padding:4px 10px">${opcionesEstadoFactura(f.estado_factura)}</select></div>
    <div class="factura-modal">
      <form id="fx-form" class="rejilla" style="gap:10px;align-content:start" autocomplete="off">
        <p class="suave" style="margin:0">${eur(f.importe_cent)} · ${fechaHora(f.fecha)} · ${esc(f.metodo)}</p>
        ${f.sugerencia && !f.destinatario ? `<div class="aviso">Datos de <b>${esc(f.sugerencia.nombre)}</b> (${f.sugerencia.tipo === "facturacion" ? "cliente sin abono" : "abonado"}). Revíselos: se guardan al imprimir o enviar.</div>` : ""}
        <div class="buscador-cli ${prov ? "oculto" : ""}">
          <input class="ent" id="fx-cli" placeholder="🔍 Buscar cliente guardado (nombre, NIF o matrícula)" autocomplete="off">
          <div id="fx-cli-res" class="resultados-cli oculto"></div></div>
        <label class="campo ${prov ? "oculto" : ""}">Nombre o razón social<input class="ent" name="nombre" value="${esc(ini.nombre || "")}" autofocus></label>
        <label class="campo ${prov ? "oculto" : ""}">NIF / CIF<input class="ent" name="nif" value="${esc(ini.nif || "")}" style="text-transform:uppercase"></label>
        <label class="campo ${prov ? "oculto" : ""}">Dirección<textarea class="ent" name="direccion" rows="2">${esc(ini.direccion || "")}</textarea></label>
        <label class="campo">Email ${prov ? "del proveedor" : "del cliente"}<input class="ent" name="email" type="email" value="${esc(ini.email || "")}"></label>
        <label class="campo ${prov ? "oculto" : ""}">Observaciones <span class="ayuda">opcional · salen en la factura (p. ej. nº de pedido, centro de coste)</span>
          <textarea class="ent" name="observaciones" rows="2" maxlength="300">${esc(guardado.observaciones || "")}</textarea></label>
        <label class="opcion-turno ${prov ? "oculto" : ""}" style="margin:0"><input type="checkbox" id="fx-guardar-cli">
          <span><b>Guardar en Clientes</b> para próximas facturas<br><span class="suave" id="fx-cli-info">${clienteTxt(f.cliente_guardado || (f.destinatario ? null : f.sugerencia))}</span></span></label>
        <button class="btn prim xl bloque ${prov ? "oculto" : ""}">Guardar datos</button>
        <div class="fila">
          ${f.proveedor ? "" : '<button type="button" class="btn" id="fx-imp">Imprimir</button>'}
          ${f.proveedor || (S.estado && S.estado.a4) ? '<button type="button" class="btn" id="fx-a4">Imprimir en A4</button>' : ""}
          <button type="button" class="btn" id="fx-pdf">Descargar PDF</button>
          <button type="button" class="btn" id="fx-mail">Enviar por email</button>
        </div>
        <div class="envio-caja">
          <div class="suave" style="font-size:.85rem">Email: <b>${esc(METODOS_EMAIL[metodo])}</b> · también:
            ${Object.keys(METODOS_EMAIL).filter((k) => k !== metodo).map((k) => `<a href="#" data-metodo="${k}">${esc(METODOS_EMAIL[k])}</a>`).join(" · ")}</div>
        </div>
        <div id="fx-emails">${f.emails.length ? `<table class="tabla" style="font-size:.88rem"><tbody>${f.emails.map((e) => `<tr>
          <td>${fechaHora(e.creado)}</td><td>${esc(e.destino)}</td><td><span class="etiqueta ${ESTADO_EMAIL[e.estado][0]}">${ESTADO_EMAIL[e.estado][1]}</span></td>
          <td style="color:var(--rojo);font-size:.8rem">${e.estado !== "enviado" ? esc(e.ultimo_error || "") : ""}</td></tr>`).join("")}</tbody></table>` : ""}</div>
      </form>
      <div id="fx-vista">${prov ? resumenFacturaProveedor(f) : renderTicket(f.vista)}</div>
    </div>
    ${f.concepto === "rectificativa" ? `<div class="aviso" style="margin-top:10px">Factura rectificativa (devolución) de <b>${esc(f.original.serie)}-${String(f.original.numero).padStart(6, "0")}</b>${f.motivo ? ` · ${esc(f.motivo)}` : ""}.</div>`
      : f.devoluciones && f.devoluciones.length ? `<div class="aviso" style="margin-top:10px">Devuelto <b>${eur(f.devuelto_cent)}</b> de ${eur(f.importe_cent)}: ${f.devoluciones.map((d) => `${esc(d.serie)}-${String(d.numero).padStart(6, "0")} (${eur(d.importe_cent)}, ${fechaHora(d.fecha)})`).join(" · ")}</div>` : ""}
    <div class="modal-pie">${(S.estado.devoluciones || S.estado.rectificacion) && f.concepto !== "rectificativa" && !f.sustituida_por ? `${S.estado.rectificacion ? '<button class="btn" id="fx-rectificar">Rectificar…</button>' : ""}${S.estado.devoluciones && f.importe_cent > (f.devuelto_cent || 0) ? '<button class="btn peligro" id="fx-devolver">Devolución…</button>' : ""}<span style="flex:1"></span>` : ""}<button class="btn" data-c>Cerrar</button></div>`, { ancho: true });
  $("#modal-caja").classList.add("muy-ancho");
  if ($("#fx-devolver")) $("#fx-devolver").onclick = () => modalDevolucion(f, () => modalFactura(pagoId, alCerrar));
  if ($("#fx-rectificar")) $("#fx-rectificar").onclick = () => modalRectificar(f, (nuevo) => modalFactura(nuevo || pagoId, alCerrar));
  const form = $("#fx-form");
  const leer = () => {
    const d = Object.fromEntries(new FormData(form));
    Object.keys(d).forEach((k) => (d[k] = d[k].trim()));
    return d;
  };
  let ultimoGuardado = JSON.stringify({ nombre: guardado.nombre || "", nif: guardado.nif || "", direccion: guardado.direccion || "", email: guardado.email || "",
    observaciones: guardado.observaciones || "" });
  // Cliente al que se enlaza la factura: el elegido en el buscador, el ya guardado o el sugerido
  let clienteId = (f.cliente_guardado && f.cliente_guardado.id) || (f.sugerencia && !f.destinatario ? f.sugerencia.id : null);
  let clienteRef = clienteId ? (f.destinatario && f.cliente_guardado ? { nombre: guardado.nombre, nif: guardado.nif } : f.sugerencia) : null;
  // Si se escriben los datos de otra persona o empresa (otro nombre y otro NIF), no se pisa el cliente enlazado
  const normTxt = (x) => (x || "").toUpperCase().replace(/[^A-Z0-9Ñ]/g, "");
  const mismoCliente = (d) => !clienteRef || (d.nif && normTxt(d.nif) === normTxt(clienteRef.nif)) || normTxt(d.nombre) === normTxt(clienteRef.nombre);

  // Guarda si hay cambios. Se llama antes de imprimir, descargar o enviar.
  const asegurarGuardado = async (forzar = false) => {
    const d = leer();
    const tieneAlgo = d.nif || d.direccion;
    if (!d.nombre && tieneAlgo) { form.nombre.focus(); throw new Error("Falta el nombre o razón social del cliente"); }
    if (!d.nombre || (!forzar && JSON.stringify(d) === ultimoGuardado)) return;
    const cuerpo = { ...d, cliente_id: (mismoCliente(d) && clienteId) || undefined, guardar_cliente: $("#fx-guardar-cli").checked };
    const r = await api("PUT", `/api/facturas/${pagoId}/destinatario`, cuerpo);
    if (r.aviso) toast(r.aviso, "aviso");   // NIF/CIF que no parece válido: se avisa pero se guarda
    ultimoGuardado = JSON.stringify(d);
    if ($("#fx-chip")) { $("#fx-chip").className = "etiqueta e-pagado"; $("#fx-chip").textContent = "Con datos del cliente"; }
  };
  let reabrir = false;
  const despues = () => { if (reabrir) { reabrir = false; modalFactura(pagoId, alCerrar); } };

  // Buscador de clientes guardados (abonados y sin abono)
  let tmc;
  const res = $("#fx-cli-res");
  $("#fx-cli").oninput = (e) => {
    e.stopPropagation();
    clearTimeout(tmc);
    const q = e.target.value.trim();
    if (q.length < 2) { res.classList.add("oculto"); return; }
    tmc = setTimeout(accion(async () => {
      const cs = (await api("GET", "/api/clientes?buscar=" + encodeURIComponent(q))).slice(0, 8);
      res.classList.remove("oculto");
      res.innerHTML = cs.length ? cs.map((c) => `<button type="button" data-cli="${c.id}">
          <b>${esc(c.nombre)}</b> <span class="etiqueta ${c.tipo === "facturacion" ? "e-factura" : "e-abonado"}">${c.tipo === "facturacion" ? "Facturación" : "Abonado"}</span>
          <span class="suave">${esc([c.nif, c.matriculas].filter(Boolean).join(" · "))}</span></button>`).join("")
        : `<div class="suave" style="padding:8px 10px">Ningún cliente coincide. Escriba los datos abajo y se guardará como cliente nuevo.</div>`;
      $$("[data-cli]", res).forEach((b) => (b.onclick = () => {
        const c = cs.find((x) => x.id === Number(b.dataset.cli));
        form.nombre.value = c.nombre || ""; form.nif.value = c.nif || ""; form.direccion.value = c.direccion || ""; form.email.value = c.email || "";
        clienteId = c.id; clienteRef = c;
        $("#fx-cli-info").innerHTML = clienteTxt(c);
        $("#fx-cli").value = ""; res.classList.add("oculto");
        form.oninput();
      }));
    }), 250);
  };

  // Vista previa en vivo mientras se escribe (sin guardar)
  let tm;
  form.oninput = (e) => {
    if (prov || (e && e.target && e.target.id === "fx-cli")) return;
    clearTimeout(tm);
    tm = setTimeout(accion(async () => {
      const v = await api("POST", `/api/facturas/${pagoId}/vista`, leer());
      if ($("#fx-vista")) $("#fx-vista").innerHTML = renderTicket(v);
    }), 300);
  };
  if (ini.nombre && !f.destinatario) form.oninput();

  const descargar = (url) => {
    const a = document.createElement("a");
    a.href = url; a.download = ""; document.body.appendChild(a); a.click(); a.remove();
  };
  const pdfUrl = (desc) => `/api/facturas/${pagoId}/pdf?token=${encodeURIComponent(S.token)}${desc ? "&descargar=1" : ""}`;

  const enviar = async (como, ventana) => {
    const email = form.email.value.trim();
    if (!email) { if (ventana) ventana.close(); form.email.focus(); throw new Error("Escriba el email del cliente"); }
    try { await asegurarGuardado(); } catch (e) { if (ventana) ventana.close(); throw e; }
    if (como === "smtp") {
      const r = await api("POST", `/api/facturas/${pagoId}/email`, { email });
      if (r.estado === "enviado") toast("Factura enviada a " + email, "ok");
      else toast("No se pudo enviar: " + (r.ultimo_error || "error desconocido") + " — Queda pendiente; también puede usar «Gmail en el navegador».", "err");
      modalFactura(pagoId, alCerrar);
      return;
    }
    if (como === "outlook") {
      descargar(`/api/facturas/${pagoId}/eml?email=${encodeURIComponent(email)}&token=${encodeURIComponent(S.token)}`);
      toast("Se ha descargado un borrador de correo con la factura adjunta: ábralo (doble clic) y pulse Enviar.", "ok");
      despues();
      return;
    }
    // Gmail en el navegador: se descarga el PDF y se abre Gmail con todo escrito; solo falta adjuntar.
    const msg = await api("GET", `/api/facturas/${pagoId}/mensaje?email=${encodeURIComponent(email)}&medio=gmail`);
    descargar(pdfUrl(true));
    const url = "https://mail.google.com/mail/?view=cm&fs=1&to=" + encodeURIComponent(email) +
      "&su=" + encodeURIComponent(msg.asunto) + "&body=" + encodeURIComponent(msg.texto + "\n\n(Se adjunta la factura " + msg.pdf + ")");
    if (ventana) ventana.location = url; else window.open(url, "_blank");
    modal(`<h2>Enviar con Gmail</h2>
      <ol class="pasos">
        <li>Se ha abierto Gmail con el destinatario, el asunto y el texto ya escritos.</li>
        <li>Se ha descargado <b class="mono">${esc(msg.pdf)}</b>: arrástrelo desde la barra de descargas al mensaje (o pulse el clip 📎 y elíjalo en «Descargas»).</li>
        <li>Pulse <b>Enviar</b> en Gmail.</li></ol>
      <p class="suave">Si no se abrió Gmail, compruebe que el navegador permite ventanas emergentes para esta página.</p>
      <div class="modal-pie"><button class="btn" id="gm-volver">Volver a la factura</button><button class="btn prim" data-c autofocus>Hecho</button></div>`);
    $("#gm-volver").onclick = () => modalFactura(pagoId, alCerrar);
    $("[data-c]", $("#modal-caja")).onclick = () => { cerrarModal(); alCerrar && alCerrar(); };
  };

  form.onsubmit = accion(async (e) => {
    e.preventDefault();
    if (!leer().nombre) { form.nombre.focus(); throw new Error("Escriba el nombre o razón social"); }
    await asegurarGuardado(true);
    toast($("#fx-guardar-cli").checked ? "Datos guardados en la factura y en Clientes" : "Datos de factura guardados", "ok");
    modalFactura(pagoId, alCerrar);
  });
  const resultadoA4 = (r) => {
    if (r.modo === "navegador") { const w = window.open(pdfUrl(false), "_blank"); if (w) w.addEventListener("load", () => setTimeout(() => w.print(), 600)); }
    else toast(r.modo === "archivo" ? `Factura guardada (${r.archivo})` : "Factura enviada a la impresora A4", "ok");
  };
  $("#fx-estado").onchange = accion(async (e) => {
    await api("PUT", `/api/facturas/${pagoId}/estado`, { estado: e.target.value });
    toast(`Factura marcada como ${ESTADO_FACTURA[e.target.value][1].toLowerCase()}`, "ok");
    if (alCerrar) alCerrar();
  });
  if ($("#fx-imp")) $("#fx-imp").onclick = accion(async () => {
    await asegurarGuardado();
    const r = await api("POST", `/api/facturas/${pagoId}/imprimir`);
    if (r && r.modo) resultadoA4(r);   // Las facturas con datos del cliente pueden ir a la impresora A4
    else { notarImpresion(r); toast("Factura impresa", "ok"); }
    despues();
  });
  if ($("#fx-a4")) $("#fx-a4").onclick = accion(async () => {
    await asegurarGuardado();
    resultadoA4(await api("POST", `/api/facturas/${pagoId}/imprimir-a4`));
    despues();
  });
  $("#fx-pdf").onclick = accion(async () => {
    await asegurarGuardado();
    descargar(pdfUrl(true));
    toast("PDF descargado", "ok");
    despues();
  });
  // La ventana de Gmail se abre en el mismo clic (si no, el navegador la bloquea como emergente)
  const lanzar = (como) => {
    const ventana = como === "gmail_web" ? window.open("about:blank", "_blank") : null;
    accion(() => enviar(como, ventana))();
  };
  $("#fx-mail").onclick = () => lanzar(metodo);
  $$("[data-metodo]", m).forEach((a) => (a.onclick = (e) => { e.preventDefault(); lanzar(a.dataset.metodo); }));
  $("[data-c]", m).onclick = () => { cerrarModal(); alCerrar && alCerrar(); };
});

// 1.1: resumen de una factura a proveedor (proveedor, servicio, importes), en lugar de la vista en formato ticket
function resumenFacturaProveedor(f) {
  const d = f.destinatario || {};
  const lineas = f.lineas_extra || [];
  return `<div class="panel resumen-prov">
    <div class="fila" style="justify-content:space-between"><b>Factura ${esc(f.serie)}-${String(f.numero).padStart(6, "0")}</b><span class="suave">${fechaHora(f.fecha)}</span></div>
    <div style="margin:10px 0"><b>${esc(d.nombre || "")}</b>${d.nif ? `<div class="suave">${esc(d.nif)}</div>` : ""}${d.direccion ? `<div class="suave">${esc(d.direccion)}</div>` : ""}</div>
    <table class="tabla"><thead><tr><th>Servicio</th><th class="der">Cant.</th><th class="der">Precio</th><th class="der">Importe</th></tr></thead><tbody>
      ${lineas.map((l) => `<tr><td>${esc(l.nombre)}</td><td class="der num">${l.cantidad}</td><td class="der num">${eur(l.precio_cent)}</td><td class="der num">${eur(l.precio_cent * l.cantidad)}</td></tr>`).join("")}</tbody></table>
    <div class="suave" style="margin-top:8px;font-size:.88rem">${(f.desglose_iva || []).map((x) => `Base ${eur(x.base)} · IVA ${x.pct}% ${eur(x.cuota)}`).join("<br>")}</div>
    <div class="fila" style="justify-content:space-between;margin-top:10px;font-size:1.2rem"><b>Total</b><b class="num">${eur(f.importe_cent)}</b></div>
    <div class="suave" style="margin-top:6px">Pago por transferencia${f.referencia ? ` · ref. ${esc(f.referencia)}` : ""}</div>
    ${d.observaciones ? `<div class="aviso" style="margin-top:10px">${esc(d.observaciones)}</div>` : ""}</div>`;
}

// ============================================================= Buscar facturas

// Lista de facturas (buscar por número, matrícula, cliente o NIF)
async function listaFacturas(el) {
  el.innerHTML = `<div class="fila" style="margin-bottom:12px">
      <input class="ent" id="fx-buscar" placeholder="Nº de factura, matrícula, cliente o NIF" style="min-width:320px" autocomplete="off">
      <select class="ent" id="fx-tipo" style="width:auto" aria-label="Tipo de factura"><option value="">Todas las facturas</option><option value="prov">Solo proveedores</option><option value="no">Sin proveedores</option></select>
      <button class="btn" id="fx-reint">Reintentar emails pendientes</button>
      <button class="btn prim" id="fx-prov">Factura a proveedor…</button></div>
    <div class="panel" id="fx-lista"><div class="vacio">Cargando…</div></div>`;
  let tm;
  const cargar = accion(async () => {
    if (!$("#fx-lista")) return;
    const tipo = $("#fx-tipo").value;
    const fs = (await api("GET", "/api/facturas?buscar=" + encodeURIComponent($("#fx-buscar").value))).filter((x) => !tipo || (tipo === "prov") === !!x.proveedor);
    $("#fx-lista").innerHTML = fs.length ? `<div style="overflow-x:auto"><table class="tabla"><thead><tr><th>Factura</th><th>Fecha</th><th>Concepto</th><th>Cliente</th><th class="der">Importe</th><th>Estado</th><th>Email</th><th></th></tr></thead><tbody>
      ${fs.map((x) => `<tr><td class="mono">${esc(x.serie)}-${String(x.numero).padStart(6, "0")}</td><td class="num">${fechaHora(x.fecha)}</td>
        <td>${x.concepto === "rectificativa" ? '<span class="etiqueta e-err">Rectificativa</span>' : x.concepto === "bono" ? "Bono" : x.proveedor ? '<span class="etiqueta e-aviso">Proveedor</span>' : x.concepto === "venta" ? "Tienda" : "Estancia"}${x.matricula ? ` · <span class="mono">${esc(x.matricula)}</span>` : ""}
          ${x.devuelto_cent ? `<div class="suave" style="font-size:.8rem">devuelto ${eur(x.devuelto_cent)}</div>` : ""}</td>
        <td>${esc(x.cliente || "—")}${x.dest_nif ? `<div class="suave" style="font-size:.8rem">${esc(x.dest_nif)}</div>` : ""}</td>
        <td class="der num">${eur(x.importe_cent)}</td>
        <td>${chipEstadoFactura(x.estado_factura)}</td>
        <td>${x.email_estado ? `<span class="etiqueta ${ESTADO_EMAIL[x.email_estado][0]}">${ESTADO_EMAIL[x.email_estado][1]}</span>` : ""}</td>
        <td class="der"><button class="btn" data-fx="${x.id}">Datos y envío</button></td></tr>`).join("")}</tbody></table></div>`
      : '<div class="vacio">No hay facturas que coincidan.</div>';
    $$("[data-fx]", $("#fx-lista")).forEach((b) => (b.onclick = () => modalFactura(Number(b.dataset.fx), cargar)));
  });
  $("#fx-buscar").oninput = () => { clearTimeout(tm); tm = setTimeout(cargar, 250); };
  $("#fx-tipo").onchange = cargar;
  $("#fx-prov").onclick = () => modalFacturaProveedor(cargar);
  $("#fx-reint").onclick = accion(async () => {
    const r = await api("POST", "/api/emails/reintentar");
    const ok = r.filter((x) => x.estado === "enviado").length;
    toast(r.length ? `${ok} de ${r.length} email(s) enviados` : "No hay emails pendientes", ok === r.length ? "ok" : "err");
    cargar();
  });
  cargar();
}

function modalBuscarFactura() {
  modal(`<h2>Facturas</h2><div id="fx-cont" style="margin-top:10px"></div>
    <div class="modal-pie"><button class="btn" data-c>Cerrar</button></div>`, { ancho: true });
  $("#modal-caja").classList.add("muy-ancho");
  $("[data-c]", $("#modal-caja")).onclick = cerrarModal;
  listaFacturas($("#fx-cont"));
  setTimeout(() => $("#fx-buscar") && $("#fx-buscar").focus(), 50);
}

// ================================================ Devoluciones y rectificación

function modalDevolucion(f, despues) {
  const disponible = f.importe_cent - (f.devuelto_cent || 0);
  const sup = tieneRol("admin", "supervisor");
  const metodoDef = f.metodo === "online" ? "tarjeta" : f.metodo;
  const m = modal(`<h2>Devolución · factura ${esc(f.serie)}-${String(f.numero).padStart(6, "0")}</h2>
    <p class="suave">Se emite una <b>factura rectificativa</b> (serie aparte) por el importe devuelto, que se resta de la caja y de los informes. Se imprime para que firme el cliente.</p>
    <div class="rejilla r2" style="margin-top:12px">
      <label class="campo">Importe a devolver (€) <span class="ayuda">máximo ${eur(disponible)}</span><input class="ent grande num" id="dv-imp" inputmode="decimal" value="${aEurTxt(disponible)}" autofocus></label>
      <label class="campo">Forma de devolución<select class="ent" id="dv-met">${[["efectivo", "Efectivo (sale de su caja)"], ["tarjeta", "Tarjeta (abono en el datáfono)"], ["transferencia", "Transferencia bancaria"]]
        .map(([v, n]) => `<option value="${v}" ${metodoDef === v ? "selected" : ""}>${n}</option>`).join("")}</select></label>
      <label class="campo" style="grid-column:1/-1">Motivo<input class="ent" id="dv-mot" maxlength="300" placeholder="Cobro de más, servicio no prestado…"></label></div>
    ${sup ? "" : `<div class="panel" style="margin-top:12px;background:var(--fondo)"><b>Autorización de un supervisor</b>
      <div class="rejilla r2" style="margin-top:8px"><label class="campo">Usuario<input class="ent" id="dv-au" autocomplete="off"></label>
      <label class="campo">PIN<input class="ent" id="dv-ap" type="password" inputmode="numeric"></label></div></div>`}
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn peligro" data-ok>Devolver</button></div>`);
  $("[data-c]", m).onclick = () => (despues ? despues() : cerrarModal());
  $("[data-ok]", m).onclick = accion(async () => {
    const imp = aCent($("#dv-imp", m).value);
    if (!imp || Number.isNaN(imp) || imp <= 0 || imp > disponible) throw new Error(`Indique un importe entre 0,01 € y ${eur(disponible)}`);
    const motivo = $("#dv-mot", m).value.trim();
    if (motivo.length < 3) throw new Error("Indique el motivo de la devolución");
    // se leen todos los datos antes de la confirmación (que sustituye el contenido de la ventana)
    const cuerpo = { importe_cent: imp, metodo: $("#dv-met", m).value, motivo };
    const forma = $("#dv-met", m).selectedOptions[0].textContent;
    if (!sup) cuerpo.autorizacion = { usuario: $("#dv-au", m).value, pin: $("#dv-ap", m).value };
    if (!(await confirmar("¿Hacer la devolución?", `Se devolverán <b>${eur(imp)}</b> (${esc(forma)}).`, { boton: "Devolver", peligro: true }))) return modalDevolucion(f, despues);
    const r = await api("POST", `/api/pagos/${f.id}/devolver`, cuerpo);
    notarImpresion(r.impresion);
    refrescarEstado();
    const ok = modal(`<h2>Devolución hecha: ${eur(imp)}</h2>
      <p class="suave">Factura rectificativa <b>${esc(r.pago.serie)}-${String(r.pago.numero).padStart(6, "0")}</b>.${r.disponible_cent ? ` Aún se podrían devolver ${eur(r.disponible_cent)}.` : ""}</p>
      <div style="margin-top:12px">${renderTicket(r.impresion)}</div>
      <div class="modal-pie"><button class="btn" id="dv-pdf">PDF</button><button class="btn prim" data-c>Aceptar</button></div>`, { ancho: true });
    $("#dv-pdf", ok).onclick = () => window.open(`/api/facturas/${r.pago.id}/pdf?token=${encodeURIComponent(S.token)}`, "_blank");
    $("[data-c]", ok).onclick = () => (despues ? despues() : cerrarModal());
  });
}

function modalRectificar(f, despues) {
  const d = f.destinatario || {};
  const sup = tieneRol("admin", "supervisor");
  const num = `${esc(f.serie)}-${String(f.numero).padStart(6, "0")}`;
  const volver = () => (despues ? despues() : cerrarModal());
  const m = modal(`<h2>Rectificar la factura ${num}</h2>
    <p class="suave">Para corregir los datos del cliente (nombre, NIF, dirección…) de una factura ya emitida. Se emiten dos documentos:
      una <b>factura rectificativa</b> que anula la original y una <b>factura nueva</b> con los datos correctos que la sustituye.
      El importe (${eur(f.importe_cent)}) no cambia y la caja no se mueve. Para devolver dinero use <i>Devolución</i>.</p>
    <div class="rejilla r2" style="margin-top:12px">
      <label class="campo">Nombre o razón social<input class="ent" id="rf-nombre" maxlength="120" value="${esc(d.nombre || "")}" autofocus></label>
      <label class="campo">NIF / CIF<input class="ent mono" id="rf-nif" maxlength="20" value="${esc(d.nif || "")}"></label>
      <label class="campo" style="grid-column:1/-1">Dirección<input class="ent" id="rf-dir" maxlength="200" value="${esc(d.direccion || "")}"></label>
      <label class="campo">Email<input class="ent" id="rf-email" type="email" maxlength="120" value="${esc(d.email || "")}"></label>
      <label class="campo">Observaciones<input class="ent" id="rf-obs" maxlength="300" value="${esc(d.observaciones || "")}"></label>
      <label class="campo" style="grid-column:1/-1">Motivo de la rectificación<input class="ent" id="rf-mot" maxlength="300" placeholder="NIF equivocado, factura a nombre de la empresa…"></label></div>
    ${sup ? "" : `<div class="panel" style="margin-top:12px;background:var(--fondo)"><b>Autorización de un supervisor</b>
      <div class="rejilla r2" style="margin-top:8px"><label class="campo">Usuario<input class="ent" id="rf-au" autocomplete="off"></label>
      <label class="campo">PIN<input class="ent" id="rf-ap" type="password" inputmode="numeric"></label></div></div>`}
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Rectificar</button></div>`);
  $("[data-c]", m).onclick = volver;
  $("[data-ok]", m).onclick = accion(async () => {
    const motivo = $("#rf-mot", m).value.trim();
    if (motivo.length < 3) throw new Error("Indique el motivo de la rectificación");
    // se lee todo antes de la confirmación (que sustituye el contenido de la ventana)
    const cuerpo = { motivo, datos: { nombre: $("#rf-nombre", m).value.trim(), nif: $("#rf-nif", m).value.trim(),
      direccion: $("#rf-dir", m).value.trim(), email: $("#rf-email", m).value.trim(), observaciones: $("#rf-obs", m).value.trim() } };
    if (!sup) cuerpo.autorizacion = { usuario: $("#rf-au", m).value, pin: $("#rf-ap", m).value };
    if (!(await confirmar("¿Rectificar la factura?", `Se anulará la ${num} con una factura rectificativa y se emitirá otra nueva
      ${cuerpo.datos.nombre ? `a nombre de <b>${esc(cuerpo.datos.nombre)}</b>` : "simplificada (sin datos del cliente)"}. Esto no se puede deshacer.`, { boton: "Rectificar" }))) return modalRectificar(f, despues);
    const r = await api("POST", `/api/pagos/${f.id}/rectificar`, cuerpo);
    notarImpresion(r.impresion_rectificativa);
    notarImpresion(r.impresion);
    const nr = (p) => `${esc(p.serie)}-${String(p.numero).padStart(6, "0")}`;
    const pdf = (id) => window.open(`/api/facturas/${id}/pdf?token=${encodeURIComponent(S.token)}`, "_blank");
    const ok = modal(`<h2>Factura rectificada</h2>
      <p class="suave">Rectificativa <b>${nr(r.rectificativa)}</b> (anula la ${num}) y factura nueva <b>${nr(r.nueva)}</b>.</p>
      ${r.aviso_nif ? `<div class="aviso">${esc(r.aviso_nif)}</div>` : ""}
      <div style="margin-top:12px">${renderTicket(r.impresion)}</div>
      <div class="modal-pie"><button class="btn" id="rf-pdf-r">PDF rectificativa</button><button class="btn" id="rf-pdf-n">PDF factura nueva</button>
        <span style="flex:1"></span><button class="btn" data-c>Cerrar</button><button class="btn prim" id="rf-ver">Ver factura nueva</button></div>`, { ancho: true });
    $("#rf-pdf-r", ok).onclick = () => pdf(r.rectificativa.id);
    $("#rf-pdf-n", ok).onclick = () => pdf(r.nueva.id);
    $("[data-c]", ok).onclick = cerrarModal;
    $("#rf-ver", ok).onclick = () => (despues ? despues(r.nueva.id) : cerrarModal());
  });
}


// ================================================ 4.58 · Factura a proveedor (serie y numeración propias, sin bonos)

const modalFacturaProveedor = accion(async (alTerminar, clienteId) => {
  const d = await api("GET", "/api/proveedores");
  const con = d.proveedores.filter((x) => x.servicios.length);
  if (!d.proveedores.length) return toast("Aún no hay proveedores: créelos en Clientes → «Nuevo cliente» → Tipo «Proveedor»", "err");
  if (!con.length) return toast("Ningún proveedor tiene servicios: añádalos en su ficha (botón «Añadir servicio»)", "err");
  const fijo = con.find((x) => x.id === clienteId);
  const m = modal(`<h2>Nueva factura a proveedor</h2>
    <p class="suave" style="margin:4px 0 0">Serie <b class="mono">${esc(d.serie)}</b> · numeración propia · se paga por transferencia. Cada factura lleva un servicio.</p>
    <div class="rejilla r2" style="margin-top:14px">
      <label class="campo" style="grid-column:1/-1">Proveedor${fijo ? `<input class="ent" value="${esc(fijo.nombre)}${fijo.nif ? " · " + esc(fijo.nif) : ""}" disabled><input type="hidden" id="fp-cli" value="${fijo.id}">`
        : `<select class="ent" id="fp-cli">${con.map((x) => `<option value="${x.id}">${esc(x.nombre)}${x.nif ? " · " + esc(x.nif) : ""}</option>`).join("")}</select>`}</label>
      <label class="campo" style="grid-column:1/-1">Servicio<select class="ent" id="fp-srv"></select></label>
      <label class="campo">Cantidad<input class="ent num" id="fp-cant" type="number" min="1" max="99" value="1"></label>
      <label class="campo">Referencia <span class="ayuda">de la transferencia · opcional</span><input class="ent" id="fp-ref" maxlength="60"></label>
      <label class="campo" style="grid-column:1/-1">Observaciones <span class="ayuda">salen en la factura</span><input class="ent" id="fp-obs" maxlength="300"></label>
    </div>
    <p class="suave" id="fp-tot" style="margin:10px 0 0;font-weight:600"></p>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Emitir factura</button></div>`);
  const servicios = () => (con.find((x) => x.id === Number($("#fp-cli", m).value)) || con[0]).servicios;
  const pintarServicios = () => {
    $("#fp-srv", m).innerHTML = servicios().map((x) => `<option value="${x.producto_id}" data-p="${x.precio_cent}">${esc(x.nombre)} · ${eur(x.precio_cent)}</option>`).join("");
    total();
  };
  const total = () => {
    const op = $("#fp-srv", m).selectedOptions[0], n = Math.max(1, Number($("#fp-cant", m).value) || 1);
    $("#fp-tot", m).textContent = op ? "Total (IVA incluido): " + eur(Number(op.dataset.p) * n) : "";
  };
  $("#fp-cli", m).onchange = pintarServicios; $("#fp-srv", m).onchange = total; $("#fp-cant", m).oninput = total;
  pintarServicios();
  $("[data-c]", m).onclick = cerrarModal;
  $("[data-ok]", m).onclick = accion(async () => {
    const f = await api("POST", "/api/proveedores/factura", {
      cliente_id: Number($("#fp-cli", m).value), lineas: [{ producto_id: Number($("#fp-srv", m).value), cantidad: Number($("#fp-cant", m).value) || 1 }],
      referencia: $("#fp-ref", m).value, observaciones: $("#fp-obs", m).value });
    cerrarModal();
    toast(`Factura ${f.serie}-${String(f.numero).padStart(6, "0")} emitida`, "ok");
    if (alTerminar) alTerminar();
    modalFactura(f.id, alTerminar);
  });
});
