/* PROYECTO ALLAS · núcleo: estado, utilidades, ventanas, impresión y cobros comunes */
"use strict";

// ===================================================== Estado de la aplicación

const S = {
  token: sessionStorage.getItem("token") || null,
  usuario: null,
  estado: null,
  vista: "cobrar",
  ultimaImp: null,
  cobro: { ticket: null, metodo: "efectivo", entregado: "", resultado: null, perdido: false, abonado: null },
  entrada: { ultimo: null },
  tarifas: [],
  ajustesTab: "empresa",
  informeTab: "resumen",
  login: { usuario: null, pin: "" },
};

const VISTAS = [
  { id: "entrada", nombre: "Entrada", tecla: "F1" },
  { id: "cobrar", nombre: "Salida", tecla: "F2" },
  { id: "vehiculos", nombre: "Vehículos", tecla: "F3" },
  { id: "reservas", nombre: "Reservas", tecla: "F9", modulo: "gestion" },
  { id: "clientes", nombre: "Clientes y bonos", tecla: "F4", modulo: ["gestion", "abonados"] },
  { id: "caja", nombre: "Caja y turno", tecla: "F5" },
  { id: "tienda", nombre: "Tienda", tecla: "F8", modulo: "tienda" },
  { id: "informes", nombre: "Informes", tecla: "F6", roles: ["admin", "supervisor"], permiso: "ver_informes" },
  { id: "ajustes", nombre: "Ajustes", tecla: "F7", roles: ["admin", "supervisor"] },
];

// ========================= Módulos de la licencia, permisos y opciones ocultas

// La licencia dice qué módulos están contratados. Sin datos (aún sin entrar) se considera que sí.
const tieneModulo = (m) => !S.estado || !Array.isArray(S.estado.modulos) || S.estado.modulos.includes(m);

const MODULOS_UI = ["abonados", "tienda", "pagos_online", "mensajeria", "madrid360", "verifactu", "rotacion", "gestion"];

// Los elementos de un módulo llevan la clase «mod-<id>»; el body lleva «sin-mod-<id>» si no está contratado.
function aplicarModulos() {
  MODULOS_UI.forEach((m) => document.body.classList.toggle("sin-mod-" + m, !tieneModulo(m)));
}

// Permisos por usuario (los de su rol, más o menos los que haya cambiado el administrador)
const permitido = (p) => !S.estado || !Array.isArray(S.estado.permisos) || S.estado.permisos.includes(p);

// Lo que el fabricante ha ocultado desde Sistema → Supervisión
const oculto = (id) => !!(S.estado && Array.isArray(S.estado.ocultos) && S.estado.ocultos.includes(id));

const tieneRol = (...r) => S.usuario && r.includes(S.usuario.rol);

const vistaVisible = (v) => !(v.id === "reservas" && oculto("veh:reservas")) && !(v.id !== "ajustes" && v.id !== "entrada" && v.id !== "cobrar" && oculto("menu:" + v.id)) && (v.permiso && S.estado && Array.isArray(S.estado.permisos) ? permitido(v.permiso) : (!v.roles || tieneRol(...v.roles)))
  && (!v.modulo || [].concat(v.modulo).some(tieneModulo));

const nombreVista = (v) => (v.id === "clientes" && !tieneModulo("abonados") ? "Clientes" : v.nombre);

// ============================= Formato: importes, fechas, tamaños y matrículas

// Igual que tarifas.redondear_5 en el servidor
function redondear5(c, modo) {
  if (!modo || modo === "ninguno" || c % 5 === 0) return c;
  if (modo === "arriba") return c + (5 - (c % 5));
  if (modo === "abajo") return c - (c % 5);
  return Math.floor((c + 2) / 5) * 5;
}

function eur(c) {
  if (c === null || c === undefined || c === "") return "–";
  const neg = c < 0; c = Math.abs(c);
  const e = Math.floor(c / 100).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  return (neg ? "−" : "") + e + "," + String(c % 100).padStart(2, "0") + " €";
}

function aCent(txt) {
  if (txt === null || txt === undefined) return null;
  const s = String(txt).trim().replace(/\s|€/g, "").replace(/\.(?=\d{3}(\D|$))/g, "").replace(",", ".");
  if (s === "") return null;
  const n = Number(s);
  return Number.isFinite(n) ? Math.round(n * 100) : NaN;
}

const aEurTxt = (c) => (c === null || c === undefined ? "" : (c / 100).toFixed(2).replace(".", ","));

const fecha = (iso) => iso ? new Date(iso).toLocaleDateString("es-ES") : "–";

const hora = (iso) => iso ? new Date(iso).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" }) : "–";

const fechaHora = (iso) => iso ? fecha(iso) + " " + hora(iso) : "–";

const fechaCorta = (d) => d ? `${d.slice(8, 10)}/${d.slice(5, 7)}/${d.slice(0, 4)}` : "–";

const fechaCorta2 = (iso) => (iso ? new Date(iso + "T12:00:00").toLocaleDateString("es-ES") : "—");

const fechaHoraCorta = (iso) => (iso ? new Date(iso).toLocaleDateString("es-ES") : "—");

function duracion(min) {
  if (min == null) return "–";
  const d = Math.floor(min / 1440), h = Math.floor((min % 1440) / 60), m = min % 60;
  return (d ? d + " d " : "") + (d || h ? h + " h " : "") + String(m).padStart(d || h ? 2 : 1, "0") + " min";
}

const hoyISO = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); };

const diaISO = (dias = 0) => { const d = new Date(); d.setDate(d.getDate() + dias); return d.toLocaleDateString("sv-SE"); };

// Para vehículos sin ticket del sistema: se introducen a mano la entrada (y la salida).
const aLocalInput = (d) => { if (d == null || d === "") return ""; const x = new Date(d); x.setMinutes(x.getMinutes() - x.getTimezoneOffset()); return x.toISOString().slice(0, 16); };

function haceCuanto(iso) {
  const min = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
  if (min < 1) return "hace un momento";
  if (min < 60) return `hace ${min} min`;
  const h = Math.round(min / 60);
  if (h < 48) return `hace ${h} h`;
  return `hace ${Math.round(h / 24)} días`;
}

const tamano = (b) => b == null ? "–" : b < 1024 ? b + " B" : b < 1048576 ? (b / 1024).toFixed(0) + " KB" : (b / 1048576).toFixed(1) + " MB";

const tamanoTxt = (n) => (n == null ? "" : n > 1048576 ? `${(n / 1048576).toFixed(1).replace(".", ",")} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);

// Salida por matrícula (sin ticket a mano): busca entre los vehículos que están dentro
const normMat = (m) => String(m || "").toUpperCase().replace(/[^A-Z0-9]/g, "");

// Matrícula + marca/modelo en una línea: "1234ABC · Seat Ibiza"
function descVehiculo(v, html = true) {
  const extra = [v.marca, v.modelo].filter(Boolean).join(" ");
  if (!html) return v.matricula + (extra ? " · " + extra : "");
  return `<span class="mono">${esc(v.matricula)}</span>${extra ? ` <span class="suave">${esc(extra)}</span>` : ""}`;
}

const ESTADOS = { dentro: "Dentro", pagado: "Pagado", salido: "Salido", anulado: "Anulado" };

const etiquetaEstado = (e) => `<span class="etiqueta e-${e}">${ESTADOS[e] || e}</span>`;

// ========================================== Página: elementos, avisos e iconos

const $ = (sel, raiz = document) => raiz.querySelector(sel);

const $$ = (sel, raiz = document) => [...raiz.querySelectorAll(sel)];

const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

// 4.37: toast con acción opcional (p. ej. «Deshacer»): toast("Quitado", "", { accion: { texto: "Deshacer", fn } })
function toast(msg, tipo = "", { accion = null } = {}) {
  const t = document.createElement("div");
  t.className = "toast " + tipo;
  const s = document.createElement("span"); s.textContent = msg; t.appendChild(s);
  if (accion) {
    const b = document.createElement("button");
    b.type = "button"; b.className = "toast-accion"; b.textContent = accion.texto;
    b.onclick = () => { t.remove(); accion.fn(); };
    t.appendChild(b);
  }
  const cont = $("#toasts");
  cont.appendChild(t);
  while (cont.children.length > 3) cont.firstChild.remove();
  setTimeout(() => t.remove(), accion ? 9000 : tipo === "err" ? 6000 : 3500);
}

async function copiarTexto(t) {
  try { await navigator.clipboard.writeText(t); toast("Copiado", "ok"); }
  catch (_) { toast("Selecciónelo y pulse Ctrl+C para copiarlo", "err"); }
}

// 4.62: servicios sin precio fijo: el precio se pregunta al seleccionarlos. Devuelve céntimos o null si se cancela.
function pedirPrecio(nombre) {
  return new Promise((ok) => {
    const f = document.createElement("div");
    f.className = "pp-fondo";
    f.innerHTML = `<form class="pp-caja" role="dialog" aria-modal="true" aria-label="Precio del servicio"><h3>${esc(nombre)}</h3>
      <p class="suave" style="margin:4px 0 10px">Este servicio no tiene precio fijo: indique el precio (IVA incluido).</p>
      <label class="campo">Precio (€)<input class="ent grande num" id="pp-v" inputmode="decimal" autocomplete="off" placeholder="0,00" autofocus></label>
      <div class="modal-pie"><button type="button" class="btn" data-no>Cancelar</button><button class="btn prim" type="submit">Aceptar</button></div></form>`;
    document.body.appendChild(f);
    const campo = f.querySelector("#pp-v");
    setTimeout(() => campo.focus(), 30);
    const cerrar = (v) => { f.remove(); ok(v); };
    f.querySelector("[data-no]").onclick = () => cerrar(null);
    f.addEventListener("keydown", (e) => { if (e.key === "Escape") { e.stopPropagation(); cerrar(null); } });
    f.querySelector("form").onsubmit = (e) => {
      e.preventDefault();
      const c = aCent(campo.value);
      if (c === null || Number.isNaN(c) || c <= 0) { campo.classList.add("error"); campo.focus(); return toast("Indique un precio mayor que 0", "err"); }
      cerrar(c);
    };
  });
}
const textoPrecio = (p) => (p.precio_variable ? "Precio al vender" : eur(p.precio_cent));

function descargarUrl(ruta, params) {
  const q = new URLSearchParams({ ...params, token: S.token });
  const a = document.createElement("a");
  a.href = ruta + "?" + q.toString(); a.download = "";
  document.body.appendChild(a); a.click(); a.remove();
}

const ICONOS = {
  camara: '<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/>',
  movil: '<rect x="5" y="2" width="14" height="20" rx="2"/><path d="M12 18h.01"/>',
  calendario: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  subir: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5"/><path d="M12 3v12"/>',
  nube: '<path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"/>',
  candado: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  escudo: '<path d="M12 22s8-4 8-10V5l-8-3-4 1.5"/><path d="M4 5v7c0 6 8 10 8 10"/>',
  nota: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h5"/>',
};

const icono = (n, t = 18) => `<svg class="ico" viewBox="0 0 24 24" width="${t}" height="${t}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONOS[n] || ""}</svg>`;

// ==================================================================== Servidor

async function api(metodo, ruta, cuerpo) {
  const r = await fetch(ruta, {
    method: metodo,
    headers: { "Content-Type": "application/json", "X-Token": S.token || "" },
    body: cuerpo !== undefined ? JSON.stringify(cuerpo) : undefined,
  });
  let datos = {};
  try { datos = await r.json(); } catch (_) { /* sin cuerpo */ }
  if (r.status === 401 && S.token && !ruta.includes("/login")) {
    cerrarSesionLocal();
    toast(datos.error || "Sesión caducada", "err");
    throw new Error(datos.error);
  }
  if (!r.ok) {
    const err = new Error(datos.error || "Error " + r.status);
    err.status = r.status; err.datos = datos;   // P. ej. matrícula en lista negra
    throw err;
  }
  vistaTicketPantalla(datos);
  return datos;
}

// Impresión «en pantalla»: si la respuesta trae un ticket marcado como pantalla, se enseña en un panel flotante
function vistaTicketPantalla(d, nivel = 0) {
  if (!d || typeof d !== "object" || nivel > 2) return;
  if (d.pantalla === true && d.elementos) return mostrarTicketPantalla(d);
  if (Array.isArray(d)) return;
  for (const k of Object.keys(d)) if (d[k] && typeof d[k] === "object") vistaTicketPantalla(d[k], nivel + 1);
}

function mostrarTicketPantalla(imp) {
  S.ultimaImp = imp;
  let p = document.getElementById("vista-ticket");
  if (!p) {
    p = document.createElement("div"); p.id = "vista-ticket"; p.className = "vista-ticket";
    p.setAttribute("role", "dialog"); p.setAttribute("aria-label", "Ticket en pantalla");
    document.body.appendChild(p);
  }
  p.innerHTML = `<div class="vt-cab"><b>Ticket en pantalla</b><span class="suave">no se imprime</span>
    <button class="btn peq" type="button" aria-label="Cerrar la vista del ticket">✕</button></div><div class="vt-cuerpo">${renderTicket(imp)}</div>`;
  p.querySelector("button").onclick = () => p.remove();
}

// Atrapa errores de una acción y los muestra
const accion = (fn) => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message, "err"); } };

async function subirBinario(ruta, datos, tipo, extra = {}) {
  const r = await fetch(ruta, { method: "POST", headers: { "X-Token": S.token, "Content-Type": tipo, ...extra }, body: datos });
  let d = {};
  try { d = await r.json(); } catch (_) { /* sin cuerpo */ }
  if (!r.ok) throw new Error(d.error || "Error " + r.status);
  return d;
}

// ==================================================================== Ventanas

function modal(html, { ancho = false } = {}) {
  const m = $("#modal"), c = $("#modal-caja");
  if (m.classList.contains("oculto")) S.modalOrigen = document.activeElement;   // 4.37: al cerrar, el foco vuelve al botón que abrió la ventana
  c.className = "modal-caja" + (ancho ? " ancho" : "");
  c.innerHTML = html;
  c.scrollTop = 0;
  const h = c.querySelector("h1, h2, h3");
  if (h) { h.id = "modal-titulo"; m.setAttribute("aria-labelledby", "modal-titulo"); } else m.removeAttribute("aria-labelledby");
  m.classList.remove("oculto");
  ampliarModal(c);
  const f = c.querySelector("[autofocus]") || c.querySelector("input,select,button");
  c.tabIndex = -1;
  // En pantallas táctiles no se abre el teclado solo: el foco va a la ventana, salvo que el foco inicial sea un botón
  const teclado = f && /^(INPUT|TEXTAREA|SELECT)$/.test(f.tagName) && document.body.classList.contains("tactil");
  setTimeout(() => (f && !teclado ? f : c).focus({ preventScroll: true }), 30);
  return c;
}

// 1.2: ventana de formulario común (título, cuerpo, pie «Cancelar/Volver + Aceptar»). `onOk(m)` se ejecuta con `accion`
// (los errores salen como aviso y la ventana sigue abierta). `peligro` pone el botón rojo; `volver` es lo que hace «Volver».
function ventanaForm({ titulo, cuerpo, aceptar = "Guardar", peligro = false, ancho = false, volver = null, onOk }) {
  const m = modal(`<h2>${titulo}</h2>${cuerpo}<div class="modal-pie"><button class="btn" data-c>${volver ? "Volver" : "Cancelar"}</button>
    <button class="btn ${peligro ? "peligro lleno" : "prim"}" data-ok>${aceptar}</button></div>`, { ancho });
  $("[data-c]", m).onclick = volver || cerrarModal;
  $("[data-ok]", m).onclick = accion(async () => { await onOk(m); });
  return m;
}

// 4.65: si la ventana no cabe en alto, se ensancha (hasta el ancho de la pantalla) para evitar la barra de desplazamiento vertical
const ANCHOS_MODAL = [560, 760, 940, 1080, 1240, 1400];
function ampliarModal(c) {
  c.style.width = "";
  const reajustar = () => {
    if (!c.isConnected || $("#modal").classList.contains("oculto")) return;
    const ya = c.classList.contains("muy-ancho") ? 1080 : c.classList.contains("ancho") ? 940 : 560;
    c.style.width = "";
    let alto = c.scrollHeight, previo = "";
    for (const w of ANCHOS_MODAL.filter((x) => x > ya)) {
      if (alto <= c.clientHeight + 1 || w > window.innerWidth - 24) break;
      c.style.width = `min(${w}px, 100%)`;
      if (c.scrollHeight >= alto - 4) { c.style.width = previo; break; }   // ensanchar no ayuda: se deja como estaba
      alto = c.scrollHeight; previo = c.style.width;
    }
  };
  reajustar();
  setTimeout(reajustar, 120);   // el contenido que llega después (listas, imágenes) también cuenta
}

function cerrarModal() {
  $("#modal").classList.add("oculto"); $("#modal-caja").innerHTML = "";
  const o = S.modalOrigen; S.modalOrigen = null;
  if (o && o !== document.body && document.contains(o) && o.offsetParent !== null && o.id !== "escaner") o.focus({ preventScroll: true });
  else enfocarEscaner();
}

// 4.37: con una ventana abierta, Tab no sale de ella
document.addEventListener("keydown", (e) => {
  if (e.key !== "Tab" || $("#modal").classList.contains("oculto")) return;
  const c = $("#modal-caja");
  const f = [...c.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), summary, [tabindex]:not([tabindex="-1"])')]
    .filter((x) => x.offsetParent !== null);
  if (!f.length) { e.preventDefault(); c.focus(); return; }
  const a = document.activeElement, primero = f[0], ultimo = f[f.length - 1];
  if (e.shiftKey && (a === primero || a === c)) { e.preventDefault(); ultimo.focus(); }
  else if (!e.shiftKey && (a === ultimo || !c.contains(a))) { e.preventDefault(); primero.focus(); }
});

function confirmar(titulo, texto, { boton = "Aceptar", peligro = false } = {}) {
  return new Promise((ok) => {
    const env = /<(div|ul|p)[\s>]/.test(texto) ? "div" : "p";   // 4.27: el texto puede llevar bloques (p. ej. las novedades de una actualización)
    const c = modal(`<h2>${esc(titulo)}</h2><${env}>${texto}</${env}>
      <div class="modal-pie"><button class="btn" data-no>Cancelar</button>
      <button class="btn ${peligro ? "peligro lleno" : "prim"}" data-si autofocus>${esc(boton)}</button></div>`);
    $("[data-no]", c).onclick = () => { cerrarModal(); ok(false); };
    $("[data-si]", c).onclick = () => { cerrarModal(); ok(true); };
  });
}

// =================================================================== Impresión

function notarImpresion(imp) {
  if (!imp) return;
  S.ultimaImp = imp;
  if (!imp.ok) toast(imp.error + " — la operación SÍ quedó guardada. Puede reimprimir.", "err");
}

function verImpresion(imp = S.ultimaImp, { pagoId = null } = {}) {
  if (!imp) return toast("Aún no se ha impreso nada en esta sesión");
  modal(`<h2>${pagoId ? "Recibo" : "Última impresión"}</h2>
    <p class="suave">${imp.omitida ? "Solo en pantalla: no se ha enviado a la impresora." : imp.ok ? "Enviada a: " + esc(imp.destino) : `<span class="etiqueta e-err">No impresa</span> ${esc(imp.error)}`}</p>
    ${renderTicket(imp)}
    <div class="modal-pie"><button class="btn" data-c>Cerrar</button>${pagoId ? '<button class="btn prim" data-imp>Imprimir</button>' : ""}</div>`);
  $("[data-c]", $("#modal-caja")).onclick = cerrarModal;
  if (pagoId) $("[data-imp]", $("#modal-caja")).onclick = accion(async () => {
    const r = await api("POST", `/api/facturas/${pagoId}/imprimir`);
    notarImpresion(r); toast(r.ok ? "Recibo enviado a la impresora" : "No se pudo imprimir", r.ok ? "ok" : "err");
  });
}

// Dibuja el ticket tal como sale de la impresora: mismo ancho de línea, negritas,
// Doble tamaño, banda invertida, QR y código de barras reales.
const PUNTOS_PAPEL = 512; // anchura imprimible típica de 80 mm a 203 ppp (puntos)

function renderTicket(imp) {
  if (!imp) return "";
  if (!imp.elementos) return `<div class="recibo">${esc(imp.vista_previa || "")}</div>`;
  const filas = imp.elementos.map((e) => {
    switch (e.t) {
      case "txt": {
        const cls = ["tl", "a-" + e.a, e.b ? "b" : "", e.g ? "g" : "", e.h && !e.g ? "h" : "", e.i ? "i" : ""].join(" ");
        return `<div class="${cls}">${esc(e.s) || "&nbsp;"}</div>`;
      }
      case "esp": return `<div class="tl">&nbsp;</div>`;
      case "sep": return `<div class="tsep ${e.c === "=" ? "doble" : ""}"></div>`;
      case "qr":
      case "barras": {
        const w = Number((e.svg.match(/width="(\d+)"/) || [])[1] || 200);
        const pct = Math.min(100, (w / PUNTOS_PAPEL) * 100);
        return `<div class="tcod"><div style="width:${pct}%">${e.svg}</div>
          ${e.t === "barras" && e.texto ? `<div class="hri">${esc(e.d)}</div>` : ""}</div>`;
      }
      case "logo": return `<div class="tlogo"><img src="/api/${e.img === "sello" ? "sello" : "logo"}/ticket.png?v=${e.v}" alt="${e.img === "sello" ? "Sello" : "Logo"}" style="width:${Math.min(100, (e.w / PUNTOS_PAPEL) * 100)}%"></div>`;
      case "cajon": return `<div class="tmeta">⇣ abre el cajón</div>`;
      case "corte": return `<div class="tcorte"><span>✂</span></div>`;
      default: return "";
    }
  }).join("");
  return `<div class="papel-marco"><div class="papel" style="--cols:${imp.ancho || 42}">${filas}</div></div>`;
}

// ======================================================================= Fotos

// --- Ajustes · catálogo
// Reduce una foto en el navegador (máx. 480 px, JPEG) para que ocupe pocos KB en la base de datos y las copias.
async function reducirFoto(archivo, lado = 480, maxBytes = 0) {
  const url = URL.createObjectURL(archivo);
  try {
    const img = await new Promise((ok, mal) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => mal(new Error("No se puede leer esa imagen")); i.src = url; });
    const k = Math.min(1, lado / Math.max(img.width, img.height));
    const c = document.createElement("canvas");
    c.width = Math.max(1, Math.round(img.width * k)); c.height = Math.max(1, Math.round(img.height * k));
    const g = c.getContext("2d");
    g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height);   // fondo blanco para PNG con transparencia
    g.drawImage(img, 0, 0, c.width, c.height);
    let calidad = 0.82, blob = await new Promise((ok) => c.toBlob(ok, "image/jpeg", calidad));
    while (maxBytes && blob && blob.size > maxBytes && calidad > 0.35) {   // con límite de tamaño: se baja la calidad hasta que quepa
      calidad -= 0.1; blob = await new Promise((ok) => c.toBlob(ok, "image/jpeg", calidad));
    }
    return blob;
  } finally { URL.revokeObjectURL(url); }
}

async function aJpeg(fuente, max = 1600) {
  const img = await new Promise((ok, mal) => {
    if (fuente instanceof HTMLCanvasElement) return ok(fuente);
    const i = new Image();
    i.onload = () => ok(i);
    i.onerror = () => mal(new Error("No se puede leer la imagen"));
    i.src = URL.createObjectURL(fuente);
  });
  const w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
  const k = Math.min(1, max / Math.max(w, h));
  const c = document.createElement("canvas");
  c.width = Math.round(w * k); c.height = Math.round(h * k);
  c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
  return new Promise((ok) => c.toBlob(ok, "image/jpeg", 0.82));
}

async function aJpegFondoBlanco(archivo, max = 1200) {
  const url = URL.createObjectURL(archivo);
  const img = await new Promise((ok, mal) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => mal(new Error("No se puede leer la imagen")); i.src = url; });
  const k = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
  const c = document.createElement("canvas");
  c.width = Math.max(1, Math.round(img.naturalWidth * k)); c.height = Math.max(1, Math.round(img.naturalHeight * k));
  const g = c.getContext("2d");
  g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height);   // los PNG transparentes, sobre blanco
  g.drawImage(img, 0, 0, c.width, c.height);
  URL.revokeObjectURL(url);
  return c.toDataURL("image/jpeg", 0.9).split(",")[1];
}

// =========================================================== Exportar listados

// Tipo: "vehiculos" | "abonados"; params: filtros de la lista que se está viendo
function modalExportar(tipo, params, titulo) {
  const veh = tipo === "vehiculos";
  const hoy = new Date().toLocaleDateString("sv-SE");
  const m = modal(`<h2>Exportar · ${esc(titulo)}</h2>
    <div class="metodos" style="margin:14px 0"><button class="btn xl sel" data-fmt="csv">CSV</button><button class="btn xl" data-fmt="pdf">PDF</button></div>
    <div id="ex-csv">
      <p class="suave" style="margin:0 0 10px">Una línea por matrícula, en este orden: <span class="mono">matrícula;día;hora</span> — por ejemplo <span class="mono">9999ZZZ;20261009;23:59</span>.</p>
      <div class="rejilla" style="gap:8px">
        ${veh ? `<label class="fila" style="gap:8px"><input type="radio" name="ex-f" value="entrada" checked> Fecha y hora de <b>entrada</b> de cada vehículo</label>
          <label class="fila" style="gap:8px"><input type="radio" name="ex-f" value="salida"> Fecha y hora de <b>salida</b> (si aún está dentro, la de entrada)</label>`
          : `<label class="fila" style="gap:8px"><input type="radio" name="ex-f" value="bono" checked> Día en que <b>caduca el bono</b> de cada abonado, a las
              <input class="ent" type="time" id="ex-hora-bono" value="23:59" style="width:auto;min-height:36px;padding:4px 8px"></label>`}
        <label class="fila" style="gap:8px"><input type="radio" name="ex-f" value="fija"> La misma fecha y hora para todos:
          <input class="ent" type="date" id="ex-dia" value="${hoy}" style="width:auto;min-height:36px;padding:4px 8px">
          <input class="ent" type="time" id="ex-hora" value="23:59" style="width:auto;min-height:36px;padding:4px 8px"></label>
      </div>
      ${veh ? '<p class="ayuda" style="margin-top:10px">Los vehículos sin matrícula no se incluyen.</p>' : '<p class="ayuda" style="margin-top:10px">Los abonados sin bono solo se incluyen con «la misma fecha y hora para todos».</p>'}
    </div>
    <div id="ex-pdf" class="oculto"><p class="suave">Listado en PDF con todos los datos de la lista, listo para imprimir o archivar.</p></div>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Descargar</button></div>`);
  let fmt = "csv";
  $$("[data-fmt]", m).forEach((b) => (b.onclick = () => {
    fmt = b.dataset.fmt;
    $$("[data-fmt]", m).forEach((x) => x.classList.toggle("sel", x === b));
    $("#ex-csv").classList.toggle("oculto", fmt !== "csv");
    $("#ex-pdf").classList.toggle("oculto", fmt !== "pdf");
  }));
  ["#ex-dia", "#ex-hora"].forEach((s) => ($(s).onfocus = () => { $('[name="ex-f"][value="fija"]').checked = true; }));
  $("[data-c]", m).onclick = cerrarModal;
  $("[data-ok]", m).onclick = () => {
    const ruta = `/api/export/${tipo}.${fmt}`;
    const p = { ...params };
    if (fmt === "csv") {
      const modo = $('[name="ex-f"]:checked').value;
      if (modo === "fija") {
        if (!$("#ex-dia").value || !$("#ex-hora").value) return toast("Indique la fecha y la hora", "err");
        Object.assign(p, { fecha: "fija", dia: $("#ex-dia").value, hora: $("#ex-hora").value });
      } else if (veh) {
        Object.assign(p, { fecha: "registro", hora_de: modo });
      } else {
        Object.assign(p, { fecha: "bono", hora: $("#ex-hora-bono").value || "23:59" });
      }
    }
    descargarUrl(ruta, p);
    cerrarModal();
    toast(fmt === "csv" ? "CSV descargado" : "PDF descargado", "ok");
  };
}

// ========== Cobros comunes: efectivo, pagos parciales y forma de pago de los bonos

// Devuelve lo entregado en céntimos o lanza un error (y pone el foco en el campo).
function entregadoEfectivo(valor, importe, selector) {
  if (importe <= 0) return null;
  const foco = () => { const i = selector && $(selector); if (i) { i.focus(); i.classList.add("falta-dato"); setTimeout(() => i.classList.remove("falta-dato"), 1500); } };
  const v = String(valor ?? "").trim();
  if (v === "") { foco(); throw new Error("Indique la cantidad recibida en efectivo"); }
  const c = aCent(v);
  if (Number.isNaN(c)) { foco(); throw new Error("Cantidad recibida no válida"); }
  if (c < importe) { foco(); throw new Error(`La cantidad recibida no cubre el total: faltan ${eur(importe - c)}`); }
  return c;
}

// Mientras el campo está vacío, el recuadro del cambio lo pide. Devuelve true si estaba vacío.
function pintarSinEntregado(inp, cc) {
  if (!inp || !cc || inp.value.trim() !== "") return false;
  cc.className = "cambio falta";
  cc.innerHTML = "<span>Escriba la cantidad recibida</span>";
  return true;
}

// Recuadro del cambio de un bono: compara lo entregado con lo que se cobra AHORA (todo o la parte elegida).
function pintarCambio(cc, inpEnt, imp, maximo) {
  if (!cc) return;
  const falta = (txt) => { cc.className = "cambio falta"; cc.innerHTML = `<span>${txt}</span>`; };
  if (Number.isNaN(imp) || imp === null || imp <= 0) return falta("Escriba primero el importe a cobrar ahora");
  if (imp > maximo) return falta(`El importe a cobrar no puede pasar de ${eur(maximo)}`);
  if (pintarSinEntregado(inpEnt, cc)) return;
  const ent = aCent(inpEnt.value);
  if (Number.isNaN(ent)) return falta("Cantidad recibida no válida");
  const dif = ent - imp;
  cc.className = "cambio" + (dif < 0 ? " falta" : "");
  cc.innerHTML = `<span>${dif < 0 ? "Faltan" : "Cambio"}</span><span class="v num">${eur(Math.abs(dif))}</span>`;
}

// Casilla «Cobrar solo una parte» + importe; el resto queda pendiente en el bono.
function campoParcial(pre, total) {
  return `<label class="fila" style="gap:8px;margin-top:12px;font-weight:600"><input type="checkbox" id="${pre}-parcial-chk">
      Cobrar solo una parte ahora <span class="ayuda">(el resto queda pendiente)</span></label>
    <div id="${pre}-parcial" class="oculto"><label class="campo">Importe a cobrar ahora
      <input class="ent grande num" id="${pre}-imp" inputmode="decimal" placeholder="${aEurTxt(total)}" autocomplete="off"></label>
      <div class="ayuda" id="${pre}-queda"></div></div>`;
}

function importeParcial(pre, total) {
  const chk = $(`#${pre}-parcial-chk`);
  if (!chk || !chk.checked) return total;
  const v = $(`#${pre}-imp`).value.trim();
  return v === "" ? NaN : aCent(v);
}

function montarParcial(pre, total, alCambiar) {
  const chk = $(`#${pre}-parcial-chk`), inp = $(`#${pre}-imp`);
  if (!chk) return;
  const queda = () => {
    const imp = importeParcial(pre, total);
    $(`#${pre}-queda`).innerHTML = !chk.checked ? "" : Number.isNaN(imp) || imp <= 0 ? "Escriba lo que paga ahora."
      : imp > total ? `<span style="color:var(--rojo)">No puede ser mayor que ${eur(total)}</span>` : `Quedará pendiente <b>${eur(total - imp)}</b>.`;
    alCambiar && alCambiar();
  };
  chk.onchange = () => { $(`#${pre}-parcial`).classList.toggle("oculto", !chk.checked); if (chk.checked) inp.focus(); queda(); };
  inp.oninput = queda;
}

// Botones de forma de pago de un bono: efectivo, tarjeta y (si está activado) transferencia
function botonesMetodoBono() {
  return `<button class="btn xl sel" data-m="efectivo">Efectivo</button><button class="btn xl" data-m="tarjeta">Tarjeta</button>`
    + (S.estado && S.estado.transferencia !== false ? `<button class="btn xl" data-m="transferencia">Transferencia</button>` : "");
}

// Datos de la transferencia: referencia (opcional) y aviso de que debe estar recibida
function bloqueTransferencia(pre) {
  return `<div id="${pre}-tr" class="oculto caja-transferencia">
    <label class="campo">Referencia de la transferencia <span class="ayuda">opcional: nº de operación, fecha u ordenante</span>
      <input class="ent" id="${pre}-ref" maxlength="60" autocomplete="off" placeholder="p. ej. 0049-1234 · 09/10"></label>
    <p class="ayuda" style="margin:6px 0 0">Regístrela cuando el dinero ya esté en la cuenta. No abre el cajón ni cuenta en el efectivo del turno.</p></div>`;
}

// ============================================================ al cargar

// Clic fuera de la ventana: se cierra
$("#modal").addEventListener("mousedown", (e) => { if (e.target.id === "modal") cerrarModal(); });


/* 4.30: la ventana de aplicación (Edge --app) se abre maximizada; si el navegador no respeta el parámetro se ajusta aquí */
(function () {
  try {
    if (window.opener || !window.matchMedia("(display-mode: standalone), (display-mode: minimal-ui), (display-mode: window-controls-overlay)").matches && history.length > 1) return;
    var w = screen.availWidth, h = screen.availHeight;
    if (window.outerWidth < w - 24 || window.outerHeight < h - 24) { window.moveTo(screen.availLeft || 0, screen.availTop || 0); window.resizeTo(w, h); }
  } catch (e) {}
})();

// 4.34: menú «⋯» de acciones de fila. Regla de la interfaz: una acción principal visible y el resto dentro del menú;
// lo que borra o anula va siempre al final, en rojo y separado. Los botones del menú conservan sus data-* (los manejadores no cambian).
function menuAcciones(items) {
  items = items.filter(Boolean);
  if (!items.length) return "";
  let sep = false;
  const filas = items.map((i, n) => {
    const pre = i.peligro && n > 0 && !sep ? (sep = true, "<hr>") : "";
    return pre + `<button class="mi${i.peligro ? " peligro" : ""}" ${i.attr}${i.titulo ? ` title="${esc(i.titulo)}"` : ""}>${i.texto}</button>`;
  }).join("");
  return `<details class="menu-mas"><summary class="btn" aria-label="Más acciones" title="Más acciones">⋯</summary><div class="menu-mas-lista">${filas}</div></details>`;
}
document.addEventListener("click", (e) => {
  const mi = e.target.closest && e.target.closest(".menu-mas .mi");
  if (mi) { mi.closest("details").removeAttribute("open"); return; }
  document.querySelectorAll("details.menu-mas[open]").forEach((d) => { if (!d.contains(e.target)) d.removeAttribute("open"); });
});
document.addEventListener("keydown", (e) => { if (e.key === "Escape") document.querySelectorAll("details.menu-mas[open]").forEach((d) => d.removeAttribute("open")); });
document.addEventListener("toggle", (e) => {
  const d = e.target;
  if (!d.classList || !d.classList.contains("menu-mas") || !d.open) return;
  const l = d.querySelector(".menu-mas-lista"), r = d.querySelector("summary").getBoundingClientRect();
  l.style.position = "fixed"; l.style.left = "auto"; l.style.right = Math.max(8, innerWidth - r.right) + "px";
  const alto = l.offsetHeight;
  if (r.bottom + 4 + alto > innerHeight - 8 && r.top - 4 - alto > 8) { l.style.top = "auto"; l.style.bottom = (innerHeight - r.top + 4) + "px"; }
  else { l.style.bottom = "auto"; l.style.top = (r.bottom + 4) + "px"; }
}, true);
window.addEventListener("scroll", () => document.querySelectorAll("details.menu-mas[open]").forEach((d) => d.removeAttribute("open")), true);
