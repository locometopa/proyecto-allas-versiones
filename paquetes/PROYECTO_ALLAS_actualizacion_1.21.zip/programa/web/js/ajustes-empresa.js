/* PROYECTO ALLAS · Ajustes → Empresa */
"use strict";

// =============================================================== Datos y cobro

const ajEmpresa = accion((el) => formCfg(el, (c) => `
  ${seccionCfg("Datos de la empresa")}
  ${campoCfg(c, "nombre_parking", "Nombre del parking")}
  ${campoCfg(c, "razon_social", "Razón social")}
  ${campoCfg(c, "nif", "NIF")}
  ${campoCfg(c, "telefono", "Teléfono")}
  <div style="grid-column:1/-1">${campoCfg(c, "direccion", "Dirección")}</div>
  ${campoCfg(c, "empresa_email", "Email", { ayuda: "en la factura y, si se elige, en el ticket" })}
  ${campoCfg(c, "empresa_web", "Página web", { ayuda: "www.miparking.es" })}
  ${seccionCfg("Cobro")}
  ${campoCfg(c, "iva_pct", "IVA (%)", { tipo: "number" })}
  ${campoCfg(c, "capacidad", "Plazas totales", { tipo: "number", ayuda: "0 = sin control" })}
  ${campoCfg(c, "salida_al_cobrar", "Al cobrar", { opciones: [["1", "El vehículo sale en ese momento"], ["0", "Tiene unos minutos para salir"]] })}
  <div data-si="salida_al_cobrar=0">${campoCfg(c, "minutos_salida", "Minutos para salir tras pagar", { tipo: "number" })}</div>
  ${seccionCfg("Bonos por transferencia bancaria")}
  ${campoCfg(c, "transferencia_activa", "Botón «Transferencia» al cobrar bonos", { opciones: [["1", "Activado"], ["0", "Desactivado"]] })}
  <div></div>
  <div data-si="transferencia_activa=1">${campoCfg(c, "transferencia_iban", "IBAN", { ayuda: "sale en el aviso de pago pendiente" })}</div>
  <div data-si="transferencia_activa=1">${campoCfg(c, "transferencia_titular", "Titular de la cuenta", { ayuda: "vacío = razón social" })}</div>`,
  () => { camposCondicionales($("#f-cfg")); montarSello(el); }));

// 4.58: sello del garaje (imagen que sale al final del ticket de cobro y en la factura PDF)
const montarSello = accion(async (el) => {
  const [info, c] = await Promise.all([api("GET", "/api/sello"), api("GET", "/api/config")]);
  if (!el.isConnected) return;
  let caja = $("#sello-caja", el);
  if (!caja) { caja = document.createElement("div"); caja.id = "sello-caja"; caja.className = "panel"; caja.style.cssText = "max-width:820px;margin-top:16px"; el.appendChild(caja); }
  const hay = !!(info && info.version);
  caja.innerHTML = `<h3>Sello del garaje</h3>
    <p class="suave" style="margin:6px 0 10px">Imagen del sello de la empresa. Sale al final del <b>ticket de cobro</b> y en la <b>factura</b> (abajo a la derecha).
      Mejor un sello en negro sobre fondo blanco.</p>
    <div class="logo-caja">
      <div><div class="ayuda">En la factura (color)</div><div class="logo-prev">${hay ? `<img src="/api/sello/sello.jpg?v=${info.version}" alt="Sello">` : '<span class="suave">Sin sello</span>'}</div></div>
      <div><div class="ayuda">En el ticket (blanco y negro)</div><div class="logo-prev">${hay ? `<img src="/api/sello/ticket.png?v=${info.version}" alt="Sello en el ticket" style="image-rendering:pixelated">` : '<span class="suave">Sin sello</span>'}</div></div>
    </div>
    <div class="fila" style="margin-top:10px;gap:10px;flex-wrap:wrap">
      <label class="btn">${hay ? "Cambiar sello…" : "Subir sello…"}<input type="file" id="sl-arch" accept="image/png,image/jpeg,image/webp,image/gif,image/bmp" hidden></label>
      <select class="ent" id="sl-ancho" title="Tamaño en el ticket" style="width:auto">${[[160, "Pequeño"], [240, "Mediano"], [320, "Grande"]]
        .map(([v, n]) => `<option value="${v}" ${(hay ? Math.abs(v - info.ticket_ancho) < 40 : v === 240) ? "selected" : ""}>${n}</option>`).join("")}</select>
      <label class="fila" style="gap:6px;font-weight:500"><input type="checkbox" id="sl-tram"> Tramado (fotos)</label>
      ${hay ? '<button type="button" class="btn peligro" id="sl-quitar">Quitar sello</button>' : ""}</div>
    ${hay ? `<div class="fila" style="margin-top:12px;gap:18px;flex-wrap:wrap">
      <label class="fila" style="gap:8px;font-weight:600"><input type="checkbox" id="sl-tk" ${c.sello_ticket !== "0" ? "checked" : ""}> Ponerlo en el ticket de cobro</label>
      <label class="fila" style="gap:8px;font-weight:600"><input type="checkbox" id="sl-fa" ${c.sello_factura !== "0" ? "checked" : ""}> Ponerlo en la factura</label></div>` : ""}`;
  const subir = accion(async (img) => {
    const d = prepararLogo(img, Number($("#sl-ancho", caja).value), $("#sl-tram", caja).checked);
    await api("POST", "/api/sello", d);
    toast("Sello guardado", "ok"); montarSello(el);
  });
  let imagen = null;
  $("#sl-arch", caja).onchange = accion(async (e) => {
    const f = e.target.files[0]; if (!f) return;
    if (f.size > 8 * 1024 * 1024) throw new Error("La imagen es demasiado grande (máximo 8 MB)");
    const url = URL.createObjectURL(f);
    try { imagen = await cargarImagen(url); } finally { URL.revokeObjectURL(url); }
    await subir(imagen);
  });
  const rehacer = accion(async () => { if (hay) { if (!imagen) imagen = await cargarImagen(`/api/sello/sello.jpg?v=${info.version}`); await subir(imagen); } });
  $("#sl-ancho", caja).onchange = rehacer; $("#sl-tram", caja).onchange = rehacer;
  if ($("#sl-quitar", caja)) $("#sl-quitar", caja).onclick = accion(async () => { await api("DELETE", "/api/sello"); toast("Sello quitado", "ok"); montarSello(el); });
  if ($("#sl-tk", caja)) {
    const guardar = accion(async () => { await api("PUT", "/api/config", { sello_ticket: $("#sl-tk", caja).checked ? "1" : "0", sello_factura: $("#sl-fa", caja).checked ? "1" : "0" }); toast("Guardado", "ok"); });
    $("#sl-tk", caja).onchange = guardar; $("#sl-fa", caja).onchange = guardar;
  }
});

// =================================================== Preferencias y numeración

// Aspecto (tema, color y diseño) y pantalla de inicio · numeración de documentos · opciones · funciones de caja y alertas
const COLORES_ACENTO = [["azul", "Azul", "#1747c9"], ["verde", "Verde", "#0f7a43"], ["turquesa", "Turquesa", "#0e7490"], ["violeta", "Violeta", "#6d28d9"],
  ["granate", "Granate", "#9f1239"], ["naranja", "Naranja", "#c2410c"], ["amarillo", "Amarillo", "#f5c400"], ["grafito", "Grafito", "#334155"], ["blancoynegro", "Blanco y negro", "linear-gradient(90deg,#fff 50%,#111 50%)"]];

const DISENOS = [["clasico", "Clásico", "Menú claro con degradado y paneles con borde"], ["moderno", "Moderno", "Menú oscuro, esquinas redondeadas y tarjetas sin borde"],
  ["compacto", "Compacto", "Menos espacio entre elementos: cabe más en pantallas pequeñas"], ["contraste", "Alto contraste", "Bordes y textos más marcados para ver bien de lejos"]];

const ajGeneral = accion(async (el) => {
  const [c, n] = await Promise.all([api("GET", "/api/config"), api("GET", "/api/numeracion")]);
  if (!el.isConnected) return;
  el.innerHTML = htmlAspecto(c) + `<form class="panel" id="f-num" style="max-width: 820px; margin-top: 18px;">${htmlNumeracion(n)}</form>`
    + htmlOpciones(c) + (tieneModulo("gestion") ? htmlFuncionesCaja(c) : "");
  // aspecto y pantalla de inicio (vista previa al momento)
  const f = $("#f-gen", el);
  $$("[name=tema]", f).forEach((r) => (r.onchange = () => aplicarTema(r.value, true)));
  $$("[name=color_acento]", f).forEach((r) => (r.onchange = () => { document.documentElement.dataset.color = r.value; }));
  $$("[name=diseno]", f).forEach((r) => (r.onchange = () => { document.documentElement.dataset.diseno = r.value; aplicarDensidad(r.value); }));
  f.onsubmit = accion(async (e) => {
    e.preventDefault();
    await api("PUT", "/api/config", Object.fromEntries(new FormData(f)));
    S.estado = await api("GET", "/api/estado");
    guardarPrefLocal("allas_tema", "");   // 4.44: lo elegido y guardado aquí manda sobre el cambio rápido de Herramientas
    aplicarTema(S.estado.tema);
    toast("Ajustes generales guardados", "ok");
  });
  // numeración
  const fn = $("#f-num", el);
  vigilarSeries(fn);
  fn.onsubmit = accion(async (e) => {
    e.preventDefault();
    const d = Object.fromEntries(new FormData(fn));
    d.registro_integridad = fn.registro_integridad.checked;
    await api("PUT", "/api/numeracion", d);
    S.estado = await api("GET", "/api/estado");
    toast("Numeración guardada", "ok");
    fn.innerHTML = htmlNumeracion(await api("GET", "/api/numeracion"));
    vigilarSeries(fn);
  });
  // opciones (avisos, fotos, devoluciones, rectificación, confirmar cierre, pantalla táctil)
  const fo = $("#f-opc35", el);
  fo.onsubmit = accion(async (e) => {
    e.preventDefault();
    const d = { modo_tactil: (fo.querySelector("[name=modo_tactil]:checked") || {}).value || "auto" };
    ["devoluciones_activo", "rectificacion_activo", "vehiculo_fotos_activo"].forEach((k) => { if (fo[k]) d[k] = fo[k].checked ? "1" : "0"; });
    d.confirmar_cierre = fo.confirmar_cierre.checked ? "1" : "0";
    d.recordatorios_activo = fo.recordatorios_activo.checked ? "1" : "0";
    await api("PUT", "/api/config", d);
    try {
      if ($("#tactil-local", fo).checked) localStorage.setItem("allas_tactil", $("#tactil-local-v", fo).value);
      else localStorage.removeItem("allas_tactil");
    } catch (_) { /* sin almacenamiento: se usa la opción general */ }
    S.estado = await api("GET", "/api/estado");
    pintarBarra();
    toast("Opciones guardadas", "ok");
  });
  // funciones de caja y alertas
  const p = $("#opc43", el);
  if (p) p.onsubmit = accion(async (e) => {
    e.preventDefault();
    const d = {};
    ["ticket_digital_activo", "estado_vehiculo_activo", "tipos_vehiculo_activo", "alertas_activas"].forEach((k) => { if (p[k]) d[k] = p[k].checked ? "1" : "0"; });
    if (p.tipos_vehiculo) d.tipos_vehiculo = p.tipos_vehiculo.value.split(",").map((x) => x.trim()).filter(Boolean).join(",");
    d.alerta_ocupacion_pct = p.alerta_ocupacion_pct.value || "0";
    d.alerta_dias_dentro = p.alerta_dias_dentro.value || "0";
    const ef = aCent(p.alerta_efectivo.value || "0");
    if (Number.isNaN(ef)) throw new Error("Importe de efectivo no válido");
    d.alerta_efectivo_cent = String(ef || 0);
    await api("PUT", "/api/config", d);
    S.estado = await api("GET", "/api/estado"); pintarBarra();
    toast("Guardado", "ok");
  });
});

function htmlAspecto(c) {
  const tema = c.tema || "claro", inicio = c.pantalla_inicio || "entrada";
  const e = S.estado || {};
  const color = e.color_acento || "azul", dis = e.diseno || "clasico";
  const muestra = (fondo, panel, barra) => `<span class="muestra"><i style="background:${barra}"></i><i style="background:${fondo};flex:3"></i><i style="background:${panel};flex:2"></i></span>`;
  return `<form class="panel" id="f-gen" style="max-width:820px">
    <h3>Aspecto</h3>
    <div class="tema-opciones" style="margin:12px 0 22px">
      <label><input type="radio" name="tema" value="claro" ${tema === "claro" ? "checked" : ""}> Claro ${muestra("#eef1f5", "#ffffff", "#0f1724")}</label>
      <label><input type="radio" name="tema" value="oscuro" ${tema === "oscuro" ? "checked" : ""}> Oscuro ${muestra("#0d121b", "#161d29", "#070b12")}</label>
      <label><input type="radio" name="tema" value="sistema" ${tema === "sistema" ? "checked" : ""}> Automático <span class="ayuda">igual que Windows</span></label>
    </div><div id="asp41" style="margin-bottom: 22px;"><h3>Color</h3>
    <div class="colores-acento">${COLORES_ACENTO.map(([v, n, c]) => `<label title="${n}"><input type="radio" name="color_acento" value="${v}" ${color === v ? "checked" : ""}>
      <span class="punto" style="background:${c}"></span>${n}</label>`).join("")}</div>
    <h3 style="margin-top:18px">Diseño</h3>
    <div class="disenos">${DISENOS.map(([v, n, d]) => `<label><input type="radio" name="diseno" value="${v}" ${dis === v ? "checked" : ""}>
      <span class="mini-diseno d-${v}"><i></i><b></b></span><span><b>${n}</b><span class="suave">${d}</span></span></label>`).join("")}</div></div>
    <h3>Al arrancar el programa</h3>
    <label class="campo" style="margin:12px 0 4px;max-width:420px">Pantalla que se abre al entrar
      <select class="ent" name="pantalla_inicio">${[["entrada", "Entrada (F1)"], ["cobrar", "Salida (F2)"], ["vehiculos", "Vehículos (F3)"], ["caja", "Caja y turno (F5)"]]
        .map(([v, n]) => `<option value="${v}" ${inicio === v ? "selected" : ""}>${n}</option>`).join("")}</select></label>
    <p class="ayuda">Si el cajero aún no ha abierto su turno, se le pedirá que lo abra.</p>
    <div class="fila" style="margin-top:18px"><button class="btn prim">Guardar</button></div></form>`;
}

// 1.2: avisa al momento si dos series de factura coinciden (el servidor tampoco lo permite)
function vigilarSeries(form) {
  const av = $("#num-aviso", form);
  if (!av) return;
  const rect = (av.dataset.rect || "R").toUpperCase();
  const rev = () => {
    const f = (form.factura_serie.value || "").trim().toUpperCase(), p = form.proveedor_serie ? (form.proveedor_serie.value || "").trim().toUpperCase() : "";
    const msg = f && f === rect ? `La serie de las facturas (${f}) es la misma que la de las rectificativas. Cámbiela.`
      : p && p === f ? `La serie de proveedores (${p}) es la misma que la de las facturas normales. Cámbiela.`
      : p && p === rect ? `La serie de proveedores (${p}) es la misma que la de las rectificativas. Cámbiela.` : "";
    av.textContent = msg; av.classList.toggle("oculto", !msg);
    return !msg;
  };
  ["factura_serie", "proveedor_serie"].forEach((k) => { if (form[k]) form[k].addEventListener("input", rev); });
  form.addEventListener("submit", (e) => { if (!rev()) { e.stopImmediatePropagation(); e.preventDefault(); } }, true);
  rev();
}

function htmlNumeracion(n) {
  const fila = (titulo, kPre, pre, kNum, d, ayuda) => `<tr><td><b>${titulo}</b><div class="suave" style="font-size:.8rem">${ayuda}</div></td>
    <td><input class="ent mono" name="${kPre}" value="${esc(pre)}" style="width:110px;text-transform:uppercase"></td>
    <td><input class="ent num" type="number" min="1" name="${kNum}" value="${d.siguiente}" style="width:150px"></td>
    <td class="suave" style="font-size:.85rem">${d.ultimo ? "último: " + d.ultimo : "aún ninguno"}</td></tr>`;
  return `<h3>Numeración de documentos</h3>
    <p class="suave" style="margin:6px 0 10px">Letra o serie y número por el que empieza cada tipo de documento. El número no puede ser menor que el último ya emitido.</p>
    <table class="tabla"><thead><tr><th></th><th>Letra / serie</th><th>Siguiente número</th><th></th></tr></thead><tbody>
      ${fila("Facturas", "factura_serie", n.factura.serie, "factura_siguiente", n.factura, "Serie: 1 a 5 letras o números (p. ej. A, T, 2026). Al cambiar de serie, la numeración de esa serie empieza en el número indicado.")}
      ${n.proveedor ? fila("Facturas a proveedores", "proveedor_serie", n.proveedor.serie, "proveedor_siguiente", n.proveedor, "Serie y numeración propias, distintas de las facturas normales. Nunca llevan bonos.") : ""}
      ${fila("Tickets", "ticket_prefijo", n.ticket.prefijo, "ticket_siguiente", n.ticket, "1 a 3 letras (no CL). Los tickets ya impresos con la letra anterior se siguen leyendo.")}
      ${fila("Bonos", "bono_prefijo", n.bono.prefijo, "bono_siguiente", n.bono, "Aparece en el recibo y la factura del bono.")}
    </tbody></table>
    <div class="aviso oculto" id="num-aviso" role="alert" data-rect="${esc((n.rectificativa || {}).serie || "R")}"></div>
    <p class="ayuda">Las series de las facturas normales, las de proveedores y las rectificativas (${esc((n.rectificativa || {}).serie || "R")}) deben ser distintas entre sí.</p>
    <h3 style="margin-top:18px">Registro encadenado de facturación</h3>
    <label class="fila" style="gap:8px;font-weight:600;margin-top:8px"><input type="checkbox" name="registro_integridad" ${n.registro_integridad ? "checked" : ""}>
      Guardar cada factura encadenada con la huella de la anterior (integridad del registro)</label>
    <p class="ayuda">Desactivado no se generan ni se comprueban los registros. Será obligatorio con VERI*FACTU: actívelo cuando su asesoría lo indique.</p>
    <div class="fila" style="margin-top:14px"><button class="btn prim">Guardar numeración</button></div>`;
}

function htmlOpciones(cfg) {
  return `<form class="panel" id="f-opc35" style="max-width: 820px; margin-top: 16px;"><h3>Opciones</h3>
      <label class="fila" style="gap:10px;font-weight:600;margin-top:12px"><input type="checkbox" name="recordatorios_activo" ${cfg.recordatorios_activo !== "0" ? "checked" : ""}>
        Avisos y recordatorios (campana de la barra superior)</label>
      <p class="ayuda" style="margin:2px 0 0 28px">Notas para el equipo («revisar la barrera», «llamar al proveedor»…) y avisos del programa: licencia, copias, pagos pendientes.</p>
      ${tieneModulo("abonados") ? `<label class="fila" style="gap:10px;font-weight:600;margin-top:12px"><input type="checkbox" name="vehiculo_fotos_activo" ${cfg.vehiculo_fotos_activo !== "0" ? "checked" : ""}>
        Fotos de los vehículos de los abonados</label>
      <p class="ayuda" style="margin:2px 0 0 28px">En la ficha del abonado se puede poner una foto de cada vehículo (opcional); se ve al cobrar y al dar salida.</p>` : ""}
      <div id="opc40">${tieneModulo("facturacion") ? `<label class="fila" style="gap:10px;font-weight:600;margin-top:12px"><input type="checkbox" name="devoluciones_activo" ${cfg.devoluciones_activo === "1" ? "checked" : ""}>
      Devoluciones</label>
    <p class="ayuda" style="margin:2px 0 0 28px">Botón <i>Devolución…</i> en las facturas: devuelve todo o parte del importe con una factura rectificativa (serie aparte).</p>
    <label class="fila" style="gap:10px;font-weight:600;margin-top:12px"><input type="checkbox" name="rectificacion_activo" ${cfg.rectificacion_activo === "1" ? "checked" : ""}>
      Rectificación de facturas</label>
    <p class="ayuda" style="margin:2px 0 0 28px">Botón <i>Rectificar…</i>: corrige los datos del cliente de una factura emitida (rectificativa + factura nueva, sin mover la caja).
      Con esta opción, los datos de una factura ya emitida no se pueden sobrescribir.</p>` : ""}
    <label class="fila" style="gap:10px;font-weight:600;margin-top:12px"><input type="checkbox" name="confirmar_cierre" ${cfg.confirmar_cierre !== "0" ? "checked" : ""}>
      Pedir confirmación al cerrar la ventana del programa</label>
    <p class="ayuda" style="margin:2px 0 0 28px">Evita cerrar el programa por accidente con la <b>X</b> (o Alt+F4): el navegador pregunta antes de salir.</p>
    <div style="margin-top:14px"><b>Pantalla táctil</b>
      <div class="fila" style="gap:16px;margin-top:6px">${[["auto", "Automático (según la pantalla)"], ["si", "Sí: botones y campos más grandes"], ["no", "No"]]
        .map(([v, n]) => `<label class="fila" style="gap:6px"><input type="radio" name="modo_tactil" value="${v}" ${(cfg.modo_tactil || "auto") === v ? "checked" : ""}> ${n}</label>`).join("")}</div>
      <label class="fila" style="gap:8px;margin-top:8px"><input type="checkbox" id="tactil-local" ${prefTactil() ? "checked" : ""}>
        Solo en este equipo: <select class="ent" id="tactil-local-v" style="width:auto;padding:4px 8px">${[["si", "táctil"], ["no", "normal"]]
          .map(([v, n]) => `<option value="${v}" ${prefTactil() === v ? "selected" : ""}>${n}</option>`).join("")}</select></label>
      <p class="ayuda" style="margin:2px 0 0">Para un TPV con pantalla táctil junto a otros puestos con ratón.</p></div></div>
      <div class="fila" style="margin-top:14px"><button class="btn prim">Guardar opciones</button></div></form>`;
}

function htmlFuncionesCaja(c) {
  const chk = (k, txt, ayuda, def = "0") => `<label class="fila" style="gap:10px;font-weight:600;margin-top:12px"><input type="checkbox" name="${k}" ${(c[k] ?? def) === "1" ? "checked" : ""}> ${txt}</label>
    <p class="ayuda" style="margin:2px 0 0 28px">${ayuda}</p>`;
  return `<form class="panel" id="opc43" style="max-width: 820px; margin-top: 16px;"><h3>Funciones de caja</h3>
    ${chk("ticket_digital_activo", "Ticket digital (SMS o WhatsApp)", "En Entrada aparece «Enviar el ticket al móvil»: el cliente recibe su código (y el enlace para pagar con el móvil, si está activado) en lugar del papel.")}
    ${chk("estado_vehiculo_activo", "Estado del vehículo al entrar (notas y fotos)", "Botón «Estado del vehículo» en el último ticket y en la Salida: daños que ya traía, con fotos del móvil, la tablet o la cámara del PC.")}
    ${tieneModulo("tarifas_avanzadas") ? `${chk("tipos_vehiculo_activo", "Tipo de vehículo en Entrada", "Botones Coche / Moto / Furgoneta… en Entrada; cada tipo puede tener su tarifa (Tarifas → Evento o tipo de vehículo).")}
      <label class="campo" style="margin:8px 0 0 28px">Tipos (separados por comas)<input class="ent" name="tipos_vehiculo" value="${esc(c.tipos_vehiculo || "Coche, Moto, Furgoneta, Autocaravana")}"></label>` : ""}
    <h3 style="margin-top:20px">Alertas en la campana</h3>
    ${chk("alertas_activas", "Avisar de situaciones de la explotación", "Parking casi lleno, vehículos muchos días dentro, demasiado efectivo en una caja, abonados con el bono caducado que entran y matrículas de la lista negra leídas por la cámara.", "1")}
    <div class="rejilla r3" style="margin:10px 0 0 28px">
      <label class="campo">Casi lleno a partir del (%)<input class="ent num" type="number" min="0" max="100" name="alerta_ocupacion_pct" value="${esc(c.alerta_ocupacion_pct || "90")}"></label>
      <label class="campo">Vehículos dentro más de (días)<input class="ent num" type="number" min="0" max="365" name="alerta_dias_dentro" value="${esc(c.alerta_dias_dentro || "7")}"></label>
      <label class="campo">Efectivo en una caja más de (€)<input class="ent num" inputmode="decimal" name="alerta_efectivo" value="${aEurTxt(Number(c.alerta_efectivo_cent || 50000))}"></label></div>
    <p class="ayuda" style="margin:4px 0 0 28px">0 = sin ese aviso.</p>
    <div class="fila" style="margin-top:14px"><button class="btn prim">Guardar</button></div></form>`;
}

// =============================================================== Caja y arqueo

const ajCaja = accion(async (el) => {
  const c = await api("GET", "/api/config");
  const activas = new Set((c.arqueo_denominaciones || DENOM.join(",")).split(",").map(Number).filter(Boolean));
  let fondo = {};
  try { fondo = JSON.parse(c.arqueo_fondo_predefinido || "{}") || {}; } catch (_) { fondo = {}; }
  el.innerHTML = `<form class="panel" id="f-caja" style="max-width:980px">
    <h3>Arqueo de caja</h3>
    <label class="fila" style="gap:10px;font-weight:600;margin-top:12px"><input type="checkbox" name="arqueo_desglose_cierre" ${c.arqueo_desglose_cierre !== "0" ? "checked" : ""}>
      Al cerrar el turno, contar por billetes y monedas</label>
    <p class="ayuda" style="margin:2px 0 0 28px">Desmarcado: se escribe solo el total del efectivo contado.</p>
    <label class="fila" style="gap:10px;font-weight:600;margin-top:12px"><input type="checkbox" name="arqueo_desglose_apertura" ${c.arqueo_desglose_apertura === "1" ? "checked" : ""}>
      Al abrir el turno, contar el fondo por billetes y monedas</label>
    <h3 style="margin-top:22px">Billetes y monedas que se usan</h3>
    <p class="suave" style="margin:6px 0 10px">Quite los que no maneja (por ejemplo, billetes de 500 € o monedas de 1 y 2 céntimos) para que el recuento sea más rápido.</p>
    <div class="chips-den">${DENOM.map((d) => `<label class="chip-den ${activas.has(d) ? "sel" : ""}"><input type="checkbox" data-den="${d}" ${activas.has(d) ? "checked" : ""}>${nombreDen(d)}</label>`).join("")}</div>
    <h3 style="margin-top:22px">Fondo de caja predefinido</h3>
    <p class="suave" style="margin:6px 0 10px">Lo que se deja en la caja al empezar. Aparece ya rellenado al abrir el turno (se puede cambiar en ese momento).</p>
    <div id="cj-fondo"></div>
    <div class="fila" style="margin-top:8px"><span class="suave">Total del fondo:</span> <b class="num" id="cj-total"></b>
      <button type="button" class="btn mini" id="cj-vaciar">Vaciar</button></div>
    <div class="fila" style="margin-top:18px"><button class="btn prim">Guardar</button></div></form>`;
  const f = $("#f-caja", el);
  const pintarFondo = () => {
    const dens = DENOM.filter((d) => $(`[data-den="${d}"]`, f).checked);
    $("#cj-fondo", el).innerHTML = gridDenominaciones(dens, fondo);
    const total = () => { fondo = leerDenominaciones($("#cj-fondo", el)).desglose; $("#cj-total", el).textContent = eur(leerDenominaciones($("#cj-fondo", el)).total); };
    $$("[data-d]", $("#cj-fondo", el)).forEach((i) => (i.oninput = total));
    total();
  };
  $$("[data-den]", f).forEach((i) => (i.onchange = () => { i.parentElement.classList.toggle("sel", i.checked); pintarFondo(); }));
  $("#cj-vaciar", el).onclick = () => { fondo = {}; pintarFondo(); };
  pintarFondo();
  f.onsubmit = accion(async (e) => {
    e.preventDefault();
    const dens = DENOM.filter((d) => $(`[data-den="${d}"]`, f).checked);
    if (!dens.length) throw new Error("Deje al menos un billete o moneda");
    const { desglose } = leerDenominaciones($("#cj-fondo", el));
    await api("PUT", "/api/config", {
      arqueo_desglose_cierre: f.arqueo_desglose_cierre.checked ? "1" : "0",
      arqueo_desglose_apertura: f.arqueo_desglose_apertura.checked ? "1" : "0",
      arqueo_denominaciones: dens.join(","),
      arqueo_fondo_predefinido: JSON.stringify(desglose),
    });
    S.estado = await api("GET", "/api/estado");
    toast("Ajustes de caja guardados", "ok");
    ajCaja(el);
  });
});

// ========================================================= Usuarios y permisos

// --- usuarios
const ajUsuarios = accion(async (el) => {
  const [us, cfg, fich] = await Promise.all([api("GET", "/api/usuarios"), api("GET", "/api/config").catch(() => ({})),
    api("GET", "/api/fichajes").catch(() => ({ activo: false, filas: [], resumen: [] }))]);
  const fq = cfg.fichaje_qr_activo === "1";
  const dentro = new Map((fich.filas || []).filter((f) => f.abierto).map((f) => [f.usuario_id, f]));
  el.innerHTML = `<div class="fila" style="margin-bottom:14px"><button class="btn prim" id="b-nuevo-u">Nuevo usuario</button>
    <span class="suave">Cajero: cobra, emite y gestiona su turno. Supervisor: además anula tickets, ve informes y cierra turnos ajenos. Admin: todo.</span></div>
    <div class="panel" style="margin-bottom:14px"><label class="fila" style="font-weight:700;gap:10px"><input type="checkbox" id="fq-act" ${fq ? "checked" : ""}>
      Control de turnos del personal por QR (fichaje de entrada y salida)</label>
      <p class="ayuda" style="margin:6px 0 0">Cada usuario tiene un QR personal (botón «QR»). Se lee con el lector de códigos del equipo, el mismo de los tickets: al pasarlo se registra
        el comienzo o el fin de su jornada. Funciona en cualquier pantalla (el lector «escribe» el código) y en el panel «Jornada y turno» de Caja y turno.
        ${fq ? "" : "Desactivado: no se registra nada."}</p>
      ${fq ? `<label class="fila" style="gap:8px;margin-top:10px;font-weight:600"><input type="checkbox" id="fq-conf" ${cfg.fichaje_confirmar_salida !== "0" ? "checked" : ""}>
        Pedir confirmación al fichar la salida, con el resumen de la jornada y del turno</label>` : ""}
      ${fq ? `<label class="campo" style="margin:10px 0 0;max-width:520px">Relación con el turno de caja
        <select class="ent" id="fq-modo"><option value="no" ${cfg.fichaje_auto_turno !== "abrir" && cfg.fichaje_auto_turno !== "ambos" ? "selected" : ""}>Independientes (se ficha solo con el QR)</option>
          <option value="abrir" ${cfg.fichaje_auto_turno === "abrir" ? "selected" : ""}>Al abrir el turno de caja se ficha la entrada</option>
          <option value="ambos" ${cfg.fichaje_auto_turno === "ambos" ? "selected" : ""}>Al abrir el turno se ficha la entrada y al cerrarlo, la salida</option></select></label>` : ""}</div>
    <div class="panel"><table class="tabla"><thead><tr><th>Nombre</th><th>Usuario</th><th>Rol</th><th>Estado</th>${fq ? "<th>Jornada</th>" : ""}<th></th></tr></thead><tbody>
    ${us.map((u) => `<tr><td><b>${esc(u.nombre)}</b></td><td class="mono">${esc(u.usuario)}</td><td>${esc(u.rol)}</td>
      <td>${u.activo ? '<span class="etiqueta e-pagado">Activo</span>' : '<span class="etiqueta e-salido">Inactivo</span>'}</td>
      ${fq ? `<td>${dentro.has(u.id) ? `<span class="etiqueta e-dentro">Dentro desde las ${esc(new Date(dentro.get(u.id).entrada).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" }))}</span>` : '<span class="suave">Fuera</span>'}</td>` : ""}
      <td class="der"><button class="btn" data-u="${u.id}">Editar</button>${fq ? `<button class="btn" data-qr="${u.id}" style="margin-left: 6px;">QR</button>` : ""}${u.rol !== "admin" ? `<button class="btn" data-perm="${u.id}" style="margin-left: 6px;">${icono("escudo", 16)} Permisos</button>` : ""}${u.id !== S.usuario.id ? `<button class="btn peligro" data-del="${u.id}" style="margin-left: 6px;" title="Eliminar usuario">Eliminar</button>` : ""}</td></tr>`).join("")}</tbody></table></div>
    ${fq ? '<div id="u-fichajes"></div>' : ""}`;
  el.insertAdjacentHTML("beforeend", '<div id="u-bloqueos"></div>');
  pintarBloqueos($("#u-bloqueos"), () => ajUsuarios(el));
  $("#b-nuevo-u").onclick = () => modalUsuario(null, el);
  $("#fq-act").onchange = accion(async (e) => {
    await api("PUT", "/api/config", { fichaje_qr_activo: e.target.checked ? "1" : "0" });
    toast(e.target.checked ? "Control de turnos por QR activado" : "Control de turnos por QR desactivado", "ok");
    ajUsuarios(el);
  });
  if ($("#fq-conf")) $("#fq-conf").onchange = accion(async (e) => { await api("PUT", "/api/config", { fichaje_confirmar_salida: e.target.checked ? "1" : "0" }); toast("Guardado", "ok"); });
  if ($("#fq-modo")) $("#fq-modo").onchange = accion(async (e) => { await api("PUT", "/api/config", { fichaje_auto_turno: e.target.value }); toast("Guardado", "ok"); });
  $$("[data-u]").forEach((b) => (b.onclick = () => modalUsuario(us.find((u) => u.id === Number(b.dataset.u)), el)));
  $$("[data-perm]", el).forEach((b) => (b.onclick = () => modalPermisos(Number(b.dataset.perm))));   // permisos a medida
  $$("[data-qr]", el).forEach((b) => (b.onclick = () => modalQrUsuario(Number(b.dataset.qr))));
  $$("[data-del]", el).forEach((b) => (b.onclick = accion(async () => {
    const u = us.find((x) => x.id === Number(b.dataset.del));
    if (!(await confirmar(`Eliminar a ${u.nombre}`, `<p>El usuario <b>${esc(u.usuario)}</b> dejará de aparecer y no podrá entrar. Sus tickets, turnos y cobros anteriores se conservan con su nombre.</p>
      <p class="suave">Si solo quiere que no entre por ahora, use «Editar» y desmarque «Usuario activo».</p>`, { boton: "Eliminar", peligro: true }))) return;
    await api("DELETE", `/api/usuarios/${u.id}`);
    toast("Usuario eliminado", "ok"); ajUsuarios(el);
  })));
  if (fq) pintarFichajes($("#u-fichajes"), () => ajUsuarios(el));
});

const modalQrUsuario = accion(async (uid, regenerar = false) => {
  const q = regenerar ? await api("POST", `/api/usuarios/${uid}/qr/regenerar`) : await api("GET", `/api/usuarios/${uid}/qr`);
  const cfg = await api("GET", "/api/config").catch(() => ({}));
  const o = q.opciones || {};
  const corte = cfg.ticket_lineas_corte || "2";
  const m = modal(`<h2>QR de ${esc(q.nombre)}</h2>
    <div class="qr-ficha" id="qr-ficha"><div class="qr-sup suave"></div><div class="qr-parking"></div><div class="qr-img">${q.svg}</div>
      <div class="qr-nombre"></div><div class="qr-sub qr-inf"></div><div class="qr-sub qr-pie"></div></div>
    <p class="ayuda">Es personal: no lo comparta. Si se pierde o se lo han fotografiado, genere uno nuevo y el anterior deja de valer.</p>
    <div class="qr-opciones">
      <label class="fila" style="gap:8px"><input type="checkbox" id="qr-o-parking" ${o.parking ? "checked" : ""}> Nombre del parking</label>
      <label class="fila" style="gap:8px"><input type="checkbox" id="qr-o-nombre" ${o.nombre ? "checked" : ""}> Nombre del empleado</label>
      <label class="campo ancho2" style="margin:0">Texto superior <span class="ayuda">opcional</span><input class="ent" id="qr-o-sup" maxlength="120" value="${esc(o.sup || "")}" placeholder="Ej.: Personal del parking"></label>
      <label class="campo ancho2" style="margin:0">Texto bajo el QR <span class="ayuda">opcional</span><input class="ent" id="qr-o-inf" maxlength="160" value="${esc(o.inf || "")}"></label>
      <label class="campo ancho2" style="margin:0">Texto final <span class="ayuda">opcional</span><input class="ent" id="qr-o-pie" maxlength="160" value="${esc(o.pie || "")}" placeholder="Ej.: Si lo pierde, avise al responsable"></label>
      <label class="campo" style="margin:0">Tamaño del QR en ticket <span class="ayuda">4 a 15 · 80 mm admite hasta 15, 58 mm hasta 11</span><input class="ent num" type="number" min="4" max="15" id="qr-o-tam" value="${esc(o.tam || 10)}"></label>
      <label class="campo" style="margin:0">Papel antes del corte <span class="ayuda">líneas</span><input class="ent num" type="number" min="0" max="15" id="qr-corte" value="${esc(corte)}"></label></div>
    <div class="fila" style="gap:8px;flex-wrap:wrap;margin-top:12px">
      <button class="btn prim" id="qr-imp">Imprimir en ticket</button><button type="button" class="btn" id="qr-pdf">Guardar PDF</button></div>
    <div class="fila" style="gap:8px;margin-top:10px"><input class="ent" type="email" id="qr-dest" placeholder="Correo para enviar el QR en PDF" aria-label="Correo de destino" style="flex:1">
      <button class="btn" id="qr-mail">Enviar PDF</button></div>
    <div class="modal-pie"><button class="btn peligro" id="qr-reg">Generar uno nuevo</button><span style="flex:1"></span><button class="btn" data-c>Cerrar</button></div>`);
  const v = (id) => $(id, m);
  const pintar = () => {
    const f = $("#qr-ficha", m);
    $(".qr-sup", f).textContent = v("#qr-o-sup").value; $(".qr-sup", f).style.display = v("#qr-o-sup").value.trim() ? "" : "none";
    $(".qr-parking", f).textContent = q.nombre_parking || "PROYECTO ALLAS"; $(".qr-parking", f).style.display = v("#qr-o-parking").checked ? "" : "none";
    $(".qr-nombre", f).textContent = q.nombre; $(".qr-nombre", f).style.display = v("#qr-o-nombre").checked ? "" : "none";
    $(".qr-inf", f).textContent = v("#qr-o-inf").value; $(".qr-inf", f).style.display = v("#qr-o-inf").value.trim() ? "" : "none";
    $(".qr-pie", f).textContent = v("#qr-o-pie").value; $(".qr-pie", f).style.display = v("#qr-o-pie").value.trim() ? "" : "none";
  };
  ["#qr-o-parking", "#qr-o-nombre"].forEach((i) => (v(i).onchange = pintar));
  ["#qr-o-sup", "#qr-o-inf", "#qr-o-pie"].forEach((i) => (v(i).oninput = pintar));
  pintar();
  // los textos se guardan al imprimir, guardar o enviar: así el ticket, el PDF y el correo salen igual que la vista previa
  const guardarOpciones = () => api("PUT", "/api/config", { fichaje_qr_mostrar_parking: v("#qr-o-parking").checked ? "1" : "0",
    fichaje_qr_mostrar_nombre: v("#qr-o-nombre").checked ? "1" : "0", fichaje_qr_texto_sup: v("#qr-o-sup").value.trim(),
    fichaje_qr_texto_inf: v("#qr-o-inf").value.trim(), fichaje_qr_texto_pie: v("#qr-o-pie").value.trim(), fichaje_qr_tam: v("#qr-o-tam").value || "10" });
  $("[data-c]", m).onclick = cerrarModal;
  v("#qr-reg").onclick = accion(async () => {
    if (!(await confirmar("Generar un QR nuevo", "<p>El QR actual dejará de funcionar. ¿Continuar?</p>", { boton: "Generar", peligro: true }))) return;
    cerrarModal(); modalQrUsuario(uid, true);
  });
  v("#qr-imp").onclick = accion(async () => {
    await guardarOpciones();
    const r = await api("POST", `/api/usuarios/${uid}/qr/imprimir`, { lineas_corte: v("#qr-corte").value });
    if (r.ok) toast("QR enviado a la impresora de tickets", "ok"); else toast(r.error || "No se pudo imprimir", "err");
  });
  v("#qr-pdf").onclick = accion(async () => { await guardarOpciones(); descargarUrl(`/api/usuarios/${uid}/qr.pdf`, {}); });
  v("#qr-mail").onclick = accion(async () => {
    const d = v("#qr-dest").value.trim();
    if (!d) throw new Error("Escriba el correo de destino");
    await guardarOpciones();
    await api("POST", `/api/usuarios/${uid}/qr/email`, { destino: d });
    toast("QR enviado por correo", "ok");
  });
});

const pintarFichajes = accion(async (el, recargar) => {
  if (!el) return;
  const hoy = new Date(), hace = new Date(Date.now() - 13 * 86400e3);
  const f = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const est = el._f || { desde: f(hace), hasta: f(hoy) };
  const r = await api("GET", `/api/fichajes?desde=${est.desde}&hasta=${est.hasta}`);
  const h = (m) => `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, "0")} min`;
  const hm = (iso) => new Date(iso).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
  el.innerHTML = `<div class="panel" style="margin-top:14px"><div class="fila" style="justify-content:space-between;flex-wrap:wrap;gap:10px"><h3 style="margin:0">Fichajes del personal</h3>
      <div class="fila" style="gap:8px;flex-wrap:wrap"><label class="fila" style="gap:6px">Del <input class="ent" type="date" id="fi-d" value="${est.desde}"></label>
        <label class="fila" style="gap:6px">al <input class="ent" type="date" id="fi-h" value="${est.hasta}"></label>
        <button class="btn" id="fi-ver">Ver</button><button class="btn" id="fi-csv">Exportar CSV</button></div></div>
    ${r.resumen.length ? `<div class="fila" style="gap:8px;flex-wrap:wrap;margin:12px 0">${r.resumen.map((x) => `<span class="etiqueta ${x.dentro ? "e-dentro" : "e-salido"}">${esc(x.usuario_nombre)} · ${h(x.minutos)} · ${x.jornadas} jornada${x.jornadas === 1 ? "" : "s"}</span>`).join("")}</div>` : ""}
    ${r.filas.length ? `<table class="tabla"><thead><tr><th>Fecha</th><th>Usuario</th><th>Entrada</th><th>Salida</th><th>Duración</th><th>Turno</th><th></th></tr></thead><tbody>
      ${r.filas.slice(0, 200).map((x) => `<tr><td>${new Date(x.entrada).toLocaleDateString("es-ES")}</td><td>${esc(x.usuario_nombre)}</td><td>${hm(x.entrada)}</td>
        <td>${x.salida ? hm(x.salida) : '<span class="etiqueta e-dentro">Dentro</span>'}</td><td class="num">${h(x.minutos)}</td><td class="suave">${x.turno_id ? "Caja " + x.turno_id : "—"}</td>
        <td class="der">${x.abierto ? `<button class="btn mini" data-cerrar="${x.id}" title="Registrar la salida ahora (se olvidó de fichar)">Cerrar</button>` : ""}</td></tr>`).join("")}</tbody></table>`
      : '<p class="suave" style="margin:12px 0 0">Aún no hay fichajes en estas fechas.</p>'}</div>`;
  el._f = est;
  $("#fi-ver", el).onclick = () => { el._f = { desde: $("#fi-d", el).value, hasta: $("#fi-h", el).value }; pintarFichajes(el, recargar); };
  $("#fi-csv", el).onclick = () => descargarUrl("/api/fichajes.csv", { desde: $("#fi-d", el).value, hasta: $("#fi-h", el).value });
  $$("[data-cerrar]", el).forEach((b) => (b.onclick = accion(async () => {
    await api("POST", `/api/fichajes/${b.dataset.cerrar}/cerrar`); toast("Jornada cerrada", "ok"); recargar();
  })));
});

function modalUsuario(u, el) {
  const roles = [["cajero", "Cajero"], ["supervisor", "Supervisor"], ["admin", "Administrador"]];
  const c = modal(`<h2>${u ? "Editar usuario" : "Nuevo usuario"}</h2>
    <div class="rejilla r2" style="margin-top:12px">
      <label class="campo">Nombre<input class="ent" id="u-nom" value="${esc(u ? u.nombre : "")}" autofocus></label>
      <label class="campo">Usuario<input class="ent" id="u-usu" value="${esc(u ? u.usuario : "")}" ${u ? "readonly" : ""} autocomplete="off"></label>
      <label class="campo">Rol<select class="ent" id="u-rol">${roles.map(([v, n]) => `<option value="${v}" ${u && u.rol === v ? "selected" : ""}>${n}</option>`).join("")}</select></label>
      <label class="campo">${u ? "Nuevo PIN (vacío = no cambiar)" : "PIN"}<input class="ent" id="u-pin" type="password" inputmode="numeric" autocomplete="new-password"></label>
    </div>
    ${u ? `<label class="fila" style="margin-top:12px;font-weight:600"><input type="checkbox" id="u-act" ${u.activo ? "checked" : ""}> Usuario activo</label>` : ""}
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Guardar</button></div>`);
  $("[data-c]", c).onclick = cerrarModal;
  $("[data-ok]", c).onclick = accion(async () => {
    const d = { nombre: $("#u-nom").value, rol: $("#u-rol").value, pin: $("#u-pin").value || null };
    if (u) { d.activo = $("#u-act").checked; await api("PUT", `/api/usuarios/${u.id}`, d); }
    else { d.usuario = $("#u-usu").value; await api("POST", "/api/usuarios", d); }
    cerrarModal(); toast("Usuario guardado", "ok"); ajUsuarios(el);
  });
}

const modalPermisos = accion(async (uid) => {
  const r = await api("GET", `/api/usuarios/${uid}/permisos`);
  const m = modal(`<h2 class="titulo-icono">${icono("escudo", 24)}Permisos de ${esc(r.usuario.nombre)}</h2>
    <p class="suave">Marcados de serie los de su rol (<b>${esc(r.usuario.rol)}</b>). Puede quitarle o darle permisos sueltos; el resto de lo que hace un ${esc(r.usuario.rol)} no cambia.</p>
    <div class="permisos43">${r.permisos.map((p) => `<label class="${p.activo !== p.de_serie ? "cambiado" : ""}"><input type="checkbox" value="${p.id}" ${p.activo ? "checked" : ""}>
      <span>${esc(p.nombre)}${p.activo !== p.de_serie ? ` <span class="etiqueta e-aviso">${p.activo ? "añadido" : "quitado"}</span>` : ""}</span></label>`).join("")}</div>
    <div class="modal-pie"><button class="btn" id="pm-serie">Volver a los de su rol</button><span style="flex:1"></span><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Guardar</button></div>`);
  $("[data-c]", m).onclick = cerrarModal;
  $("#pm-serie", m).onclick = () => $$("input[type=checkbox]", m).forEach((c, i) => (c.checked = r.permisos[i].de_serie));
  $("[data-ok]", m).onclick = accion(async () => {
    await api("PUT", `/api/usuarios/${uid}/permisos`, { permisos: $$("input[type=checkbox]:checked", m).map((c) => c.value) });
    cerrarModal(); toast("Permisos guardados (se aplican al momento)", "ok");
  });
});

const pintarBloqueos = accion(async (el, recargar) => {
  if (!el || !tieneRol("admin")) return;
  const b = await api("GET", "/api/usuarios/bloqueos");
  el.innerHTML = `<div class="panel" style="margin-top:16px">
    <div class="fila" style="justify-content:space-between"><h3>Protección contra PIN incorrectos</h3>
      ${b.bloqueos.length ? `<span class="etiqueta e-err">${b.bloqueos.length} bloqueado(s)</span>` : '<span class="etiqueta e-pagado">Sin bloqueos</span>'}</div>
    <p class="suave" style="margin:8px 0">Tras <b>${b.intentos}</b> PIN incorrectos seguidos, ese usuario queda bloqueado <b>${b.minutos} minutos</b>
      (y también el equipo desde el que se intenta, si insiste con varios usuarios). Así nadie puede ir probando PIN, tampoco desde un móvil de la red.</p>
    ${b.bloqueos.length ? `<table class="tabla"><tbody>${b.bloqueos.map((x) => `<tr><td class="mono">${esc(x.clave.replace("usuario:", "usuario ").replace("ip:", "equipo "))}</td>
      <td class="suave">hasta las ${hora(x.hasta)}</td><td class="der"><button class="btn" data-desb="${esc(x.clave)}">Desbloquear</button></td></tr>`).join("")}</tbody></table>` : ""}
    <div class="fila" style="margin-top:10px">
      <label class="campo">Intentos<input class="ent num" id="bl-int" type="number" min="3" max="20" value="${b.intentos}" style="width:90px"></label>
      <label class="campo">Minutos de bloqueo<input class="ent num" id="bl-min" type="number" min="1" max="1440" value="${b.minutos}" style="width:110px"></label>
      <button class="btn" id="bl-guardar" style="align-self:flex-end">Guardar</button></div></div>`;
  $$("[data-desb]", el).forEach((x) => (x.onclick = accion(async () => {
    await api("POST", "/api/usuarios/desbloquear", { clave: x.dataset.desb }); toast("Desbloqueado", "ok"); pintarBloqueos(el, recargar);
  })));
  $("#bl-guardar", el).onclick = accion(async () => {
    await api("PUT", "/api/config", { acceso_intentos: $("#bl-int", el).value, acceso_bloqueo_min: $("#bl-min", el).value });
    toast("Guardado", "ok"); pintarBloqueos(el, recargar);
  });
});

// ================================================================== Caja móvil

const ajMovil = accion(async (el) => {
  const i = await api("GET", "/api/movil/info");
  el.innerHTML = `<div class="rejilla r2" style="max-width:1050px;align-items:start">
    <div class="panel">
      <h3>Caja desde el móvil o la tablet</h3>
      <p style="margin:10px 0">Registre entradas, cobre y dé salida a los vehículos desde un móvil o una tablet conectados <b>a la misma red WiFi</b> que este PC.
        Cada persona entra con su usuario y PIN. Los tickets se imprimen en la impresora de este PC.</p>
      <label class="fila" style="gap:10px;font-weight:600"><input type="checkbox" id="mv-activo" ${i.activo ? "checked" : ""}> Permitir el acceso desde la red local</label>
      <label class="fila" style="gap:10px;font-weight:600;margin-top:10px"><input type="checkbox" id="mv-compartido" ${i.turno_compartido ? "checked" : ""}> Cobrar desde el móvil en el turno abierto en el PC</label>
      <p class="ayuda" style="margin:2px 0 0 28px">Así el cajero del PC y el del móvil trabajan a la vez: los cobros del móvil se suman a ese turno
        (con el nombre de quien cobra) y el efectivo se entrega luego en esa caja. Desmarcado: solo puede cobrar desde el móvil quien tenga el turno abierto.</p>
      <ul class="suave" style="margin:12px 0 0 18px">
        <li>La primera vez, Windows puede preguntar si permite a Python el acceso a la red: pulse <b>Permitir</b> (redes privadas).</li>
        <li>Solo funciona dentro de su red: desde Internet no se puede entrar.</li>
        <li>Para escribir la matrícula o el código del ticket se usa el teclado (o se elige de la lista de vehículos dentro).</li>
      </ul>
      ${i.reiniciar ? `<div class="aviso" style="margin-top:12px">Para aplicar el cambio hay que reiniciar el programa.
        <button class="btn prim" id="mv-reiniciar" style="margin-left:8px">Reiniciar ahora…</button></div>` : ""}
    </div>
    <div class="panel" style="text-align:center">
      ${i.activo && i.escuchando_red && i.urls.length ? `<h3>Escanee con el móvil</h3>
        <div class="qr-movil">${i.qr}</div>
        <p class="mono" style="font-size:1.05rem;margin-top:8px">${esc(i.urls[0])}</p>
        ${i.urls.length > 1 ? `<p class="suave" style="font-size:.85rem">Otras direcciones: ${i.urls.slice(1).map(esc).join(" · ")}</p>` : ""}
        <p class="suave" style="font-size:.85rem;margin-top:8px">Consejo: en el móvil, «Añadir a pantalla de inicio» para abrirla como una app.</p>`
      : i.activo ? `<div class="vacio">Reinicie el programa para ver aquí el código QR.</div>`
      : !i.ips.length ? `<div class="vacio">Este PC no parece estar conectado a ninguna red.</div>`
      : `<div class="vacio">Active el acceso desde la red local para ver aquí el código QR.</div>`}
    </div></div>`;
  $("#mv-activo", el).onchange = accion(async (e) => {
    await api("PUT", "/api/config", { movil_red: e.target.checked ? "1" : "0" });
    S.estado = await api("GET", "/api/estado");
    ajMovil(el);
  });
  $("#mv-compartido", el).onchange = accion(async (e) => {
    await api("PUT", "/api/config", { movil_turno_compartido: e.target.checked ? "1" : "0" });
    toast("Guardado", "ok");
  });
  if ($("#mv-reiniciar", el)) $("#mv-reiniciar", el).onclick = () => reiniciarConPin();
});

// ============================================================== Plazas y zonas

const ajZonas = accion(async (el) => {
  const r = await api("GET", "/api/zonas");
  const oc = Object.fromEntries(r.ocupacion.map((z) => [z.id, z.ocupadas]));
  el.innerHTML = `<div class="rejilla r2" style="max-width:1150px;align-items:start">
    <div class="panel"><div class="fila" style="justify-content:space-between"><h3>Zonas</h3><button class="btn prim" id="zn-nueva">Añadir zona…</button></div>
      <p class="suave" style="margin:6px 0 12px">Plantas, sectores o aparcamientos con su propia capacidad. En Entrada se elige la zona (o la primera con sitio)
        y cuando una se llena no admite más entradas. Sin zonas, todo el parking cuenta como una sola.</p>
      ${r.zonas.length ? `<table class="tabla"><thead><tr><th>Zona</th><th class="der">Ocupadas</th><th class="der">Capacidad</th><th></th></tr></thead><tbody>
        ${r.zonas.map((z) => `<tr class="${z.activa ? "" : "inactiva"}"><td><span class="punto-zona" style="--zc:${esc(z.color || "#64748b")}"></span><b>${esc(z.nombre)}</b>${z.activa ? "" : ' <span class="etiqueta e-salido">Oculta</span>'}</td>
          <td class="der num">${oc[z.id] || 0}</td><td class="der num">${z.capacidad || "sin límite"}</td>
          <td class="der" style="white-space:nowrap"><button class="btn mini" data-ed="${z.id}">Editar</button> ${menuAcciones([{ attr: `data-bo="${z.id}"`, texto: "Quitar zona", peligro: true }])}</td></tr>`).join("")}</tbody></table>`
        : '<div class="vacio" style="padding:14px">Sin zonas.</div>'}</div>
    <form class="panel" id="f-plazas"><h3>Plazas reservadas para abonados</h3>
      <p class="suave" style="margin:6px 0 12px">Las plazas reservadas solo las pueden ocupar abonados: cuando los vehículos de rotación llegan a <i>capacidad − reservadas</i>, Entrada avisa de COMPLETO para rotación, aunque haya sitio para abonados.</p>
      <div class="rejilla r2"><label class="campo">Capacidad total del parking<input class="ent num" type="number" min="0" name="capacidad" value="${r.capacidad || ""}"></label>
        <label class="campo">Plazas reservadas para abonados<input class="ent num" type="number" min="0" name="plazas_abonados" value="${r.plazas_abonados || ""}" placeholder="0 = ninguna"></label></div>
      <div class="fila" style="margin-top:12px"><button class="btn prim">Guardar</button></div></form></div>`;
  const recargar = async () => { S.estado = await api("GET", "/api/estado"); pintarBarra(); ajZonas(el); };
  $("#f-plazas", el).onsubmit = accion(async (e) => {
    e.preventDefault();
    const f = e.target;
    if (Number(f.plazas_abonados.value || 0) > Number(f.capacidad.value || 0) && Number(f.plazas_abonados.value || 0)) throw new Error("Las plazas reservadas no pueden superar la capacidad");
    await api("PUT", "/api/config", { capacidad: f.capacidad.value || "0", plazas_abonados: f.plazas_abonados.value || "0" });
    toast("Guardado", "ok"); recargar();
  });
  const editar = (z) => {
    const m = modal(`<h2>${z ? "Editar zona" : "Nueva zona"}</h2>
      <div class="rejilla r3" style="margin-top:12px">
        <label class="campo">Nombre<input class="ent" id="zn-n" maxlength="40" value="${esc(z ? z.nombre : "")}" placeholder="Planta -1" autofocus></label>
        <label class="campo">Capacidad <span class="ayuda">0 = sin límite</span><input class="ent num" type="number" min="0" id="zn-c" value="${z ? z.capacidad : ""}"></label>
        <label class="campo">Orden<input class="ent num" type="number" id="zn-o" value="${z ? z.orden : r.zonas.length + 1}"></label></div>
      <div class="campo" style="margin-top:12px">Color <span class="ayuda">para reconocerla en Entrada, Salida y Vehículos</span>
        <div class="fila colores-zona" style="margin-top:6px">${COLORES_ZONA.map((c) => `<button type="button" class="col-zona ${((z && z.color) || COLORES_ZONA[r.zonas.length % COLORES_ZONA.length]) === c ? "activo" : ""}" data-col="${c}" style="background:${c}" title="${c}"></button>`).join("")}
          <input type="color" id="zn-col" value="${esc((z && z.color) || COLORES_ZONA[r.zonas.length % COLORES_ZONA.length])}" title="Otro color"></div></div>
      ${z ? `<label class="fila" style="gap:8px;margin-top:10px"><input type="checkbox" id="zn-a" ${z.activa ? "checked" : ""}> Activa</label>` : ""}
      <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Guardar</button></div>`);
    $("[data-c]", m).onclick = cerrarModal;
    $$(".col-zona", m).forEach((b) => (b.onclick = () => { $("#zn-col", m).value = b.dataset.col; $$(".col-zona", m).forEach((x) => x.classList.toggle("activo", x === b)); }));
    $("#zn-col", m).oninput = () => $$(".col-zona", m).forEach((x) => x.classList.remove("activo"));
    $("[data-ok]", m).onclick = accion(async () => {
      const d = { nombre: $("#zn-n", m).value, capacidad: Number($("#zn-c", m).value) || 0, orden: Number($("#zn-o", m).value) || 0, color: $("#zn-col", m).value };
      if (z) d.activa = $("#zn-a", m).checked;
      await api(z ? "PUT" : "POST", z ? `/api/zonas/${z.id}` : "/api/zonas", d);
      cerrarModal(); toast("Zona guardada", "ok"); recargar();
    });
  };
  $("#zn-nueva", el).onclick = () => editar(null);
  $$("[data-ed]", el).forEach((b) => (b.onclick = () => editar(r.zonas.find((z) => String(z.id) === b.dataset.ed))));
  $$("[data-bo]", el).forEach((b) => (b.onclick = accion(async () => {
    const z = r.zonas.find((x) => String(x.id) === b.dataset.bo);
    if (!(await confirmar("Quitar zona", `¿Quitar la zona <b>${esc(z.nombre)}</b>? Si ya tiene tickets, se oculta.`, { boton: "Quitar", peligro: true }))) return ajZonas(el);
    await api("DELETE", `/api/zonas/${z.id}`); recargar();
  })));
});

// ======================================================= Aplicaciones externas

const COLORES_APP = ["", "#1747c9", "#0f7a43", "#c2272d", "#a35a00", "#7c3aed", "#0e7490", "#be185d", "#334155"];

const ROLES_TXT = { admin: "Administrador", supervisor: "Supervisor", cajero: "Cajero" };

const ajApps = accion(async (el) => {
  const apps = await api("GET", "/api/apps/todas");
  el.innerHTML = `<div style="max-width:1000px">
    <div class="panel"><div class="fila" style="justify-content:space-between"><h3>Aplicaciones externas</h3><button class="btn prim" id="ap-nueva">Añadir botón…</button></div>
      <p class="suave" style="margin:6px 0 12px">Botones en el menú lateral, en el apartado <b>Aplicaciones externas</b>, que abren una <b>página web</b>
        (banco, TPV virtual, cámaras, correo…) o un <b>programa, documento o carpeta</b> del ordenador. Puede elegir qué usuarios ven cada botón.</p>
      <div class="aviso" style="margin-bottom:12px">Los <b>programas</b> se abren en el ordenador donde funciona el servidor de PROYECTO ALLAS (la caja principal).
        Desde otro puesto, la caja móvil o una tablet, use mejor botones web.</div>
      ${apps.length ? `<table class="tabla"><thead><tr><th></th><th>Botón</th><th>Abre</th><th>Quién lo ve</th><th></th></tr></thead><tbody>
        ${apps.map((a) => `<tr class="${a.activa ? "" : "inactiva"}"><td style="width:44px"><i class="app-ico" style="${a.color ? `background:${esc(a.color)};color:#fff` : ""}">${esc(a.icono || a.nombre.slice(0, 1).toUpperCase())}</i></td>
          <td><b>${esc(a.nombre)}</b>${a.activa ? "" : ' <span class="etiqueta e-salido">Oculto</span>'}</td>
          <td><span class="etiqueta ${a.tipo === "web" ? "e-factura" : "e-abonado"}">${a.tipo === "web" ? "Web" : "Programa"}</span>
            <div class="mono suave" style="font-size:.8rem;word-break:break-all">${esc(a.destino)}${a.argumentos ? " " + esc(a.argumentos) : ""}</div></td>
          <td class="suave" style="font-size:.88rem">${(a.roles || "").split(",").map((r) => ROLES_TXT[r] || r).join(", ")}</td>
          <td class="der" style="white-space:nowrap"><button class="btn mini" data-ed="${a.id}">Editar</button>
            ${menuAcciones([a.tipo === "programa" ? { attr: `data-prob="${a.id}"`, texto: "Probar el programa" } : null, { attr: `data-bo="${a.id}"`, texto: "Quitar botón", peligro: true }])}</td></tr>`).join("")}</tbody></table>`
        : '<div class="vacio" style="padding:18px">Aún no hay ningún botón. Pulse «Añadir botón…».</div>'}</div></div>`;
  const recargar = async () => { S.estado = await api("GET", "/api/estado"); pintarAppsMenu(); ajApps(el); };
  $("#ap-nueva").onclick = () => modalAppExterna(null, recargar);
  $$("[data-ed]", el).forEach((b) => (b.onclick = () => modalAppExterna(apps.find((a) => String(a.id) === b.dataset.ed), recargar)));
  $$("[data-prob]", el).forEach((b) => (b.onclick = accion(async () => { await api("POST", `/api/apps/${b.dataset.prob}/abrir`); toast("Abierto en el ordenador principal", "ok"); })));
  $$("[data-bo]", el).forEach((b) => (b.onclick = accion(async () => {
    const a = apps.find((x) => String(x.id) === b.dataset.bo);
    if (!(await confirmar("Quitar botón", `¿Quitar «${esc(a.nombre)}» del menú?`, { boton: "Quitar", peligro: true }))) return ajApps(el);
    await api("DELETE", `/api/apps/${a.id}`); await recargar();
  })));
});

function modalAppExterna(a, despues) {
  a = a || { tipo: "web", roles: "admin,supervisor,cajero", activa: 1, orden: 0 };
  const roles = (a.roles || "").split(",");
  const m = modal(`<h2>${a.id ? "Editar botón" : "Nuevo botón"}</h2>
    <form id="f-app" class="rejilla r2" style="margin-top:10px">
      <label class="campo">Nombre del botón<input class="ent" name="nombre" maxlength="40" value="${esc(a.nombre || "")}" placeholder="Banca online" autofocus></label>
      <label class="campo">Icono <span class="ayuda">1-2 letras o un emoji</span><input class="ent" name="icono" maxlength="4" value="${esc(a.icono || "")}" placeholder="🏦"></label>
      <div class="campo" style="grid-column:1/-1">Color<div class="fila colores-app">${COLORES_APP.map((c) => `<label class="color-app" title="${c || "Sin color"}" style="${c ? `background:${c}` : ""}">
        <input type="radio" name="color" value="${c}" ${(a.color || "") === c ? "checked" : ""}>${c ? "" : "—"}</label>`).join("")}</div></div>
      <div class="campo" style="grid-column:1/-1">Abre<div class="fila" style="gap:18px;margin-top:4px">
        <label class="fila" style="gap:6px"><input type="radio" name="tipo" value="web" ${a.tipo === "web" ? "checked" : ""}> Una página web</label>
        <label class="fila" style="gap:6px"><input type="radio" name="tipo" value="programa" ${a.tipo === "programa" ? "checked" : ""}> Un programa, documento o carpeta del PC</label></div></div>
      <label class="campo" style="grid-column:1/-1"><span id="ap-dest-t"></span><input class="ent mono" name="destino" maxlength="500" value="${esc(a.destino || "")}"></label>
      <label class="campo" style="grid-column:1/-1" id="ap-args">Argumentos <span class="ayuda">opcional (p. ej. un archivo que debe abrir el programa)</span><input class="ent mono" name="argumentos" maxlength="500" value="${esc(a.argumentos || "")}"></label>
      <div class="campo">Quién lo ve<div class="fila" style="gap:14px;margin-top:4px">${Object.entries(ROLES_TXT).map(([r, n]) => `<label class="fila" style="gap:6px"><input type="checkbox" name="roles" value="${r}" ${roles.includes(r) ? "checked" : ""}> ${n}</label>`).join("")}</div></div>
      <label class="campo">Orden<input class="ent num" type="number" name="orden" value="${Number(a.orden) || 0}" style="max-width:110px"></label>
      <label class="fila" style="gap:8px;grid-column:1/-1"><input type="checkbox" name="activa" ${a.activa ? "checked" : ""}> Visible en el menú</label>
    </form>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Guardar</button></div>`);
  const f = $("#f-app", m);
  const tipo = () => (f.querySelector("[name=tipo]:checked") || {}).value;
  const pintarTipo = () => {
    const web = tipo() === "web";
    $("#ap-dest-t", m).innerHTML = web ? "Dirección web" : 'Ruta <span class="ayuda">p. ej. C:\\Program Files\\Banco\\tpv.exe, un .pdf o una carpeta</span>';
    f.destino.placeholder = web ? "https://www.mibanco.es" : "C:\\Programas\\programa.exe";
    $("#ap-args", m).classList.toggle("oculto", web);
  };
  $$("[name=tipo]", f).forEach((r) => (r.onchange = pintarTipo)); pintarTipo();
  $("[data-c]", m).onclick = cerrarModal;
  $("[data-ok]", m).onclick = accion(async () => {
    const d = { nombre: f.nombre.value, icono: f.icono.value, color: (f.querySelector("[name=color]:checked") || {}).value || "",
      tipo: tipo(), destino: f.destino.value, argumentos: f.argumentos.value, orden: Number(f.orden.value) || 0,
      roles: $$("[name=roles]:checked", f).map((x) => x.value), activa: f.activa.checked };
    await api(a.id ? "PUT" : "POST", a.id ? `/api/apps/${a.id}` : "/api/apps", d);
    cerrarModal(); toast("Guardado", "ok"); despues && despues();
  });
}
