/* PROYECTO ALLAS · pantalla de cliente (segundo monitor y visor TPV) */
"use strict";

// ========================================================= Pantalla de cliente

// La ventana /cliente.html (segundo monitor) escucha este canal. Solo se envía si está activada en Ajustes.
const canalCliente = "BroadcastChannel" in window ? new BroadcastChannel("proyecto-allas-cliente") : null;

let ultimoCliente = null;

function pantallaCliente(d) {
  if (!S.estado || !S.estado.pantalla_cliente) return;
  if (JSON.stringify(d) === JSON.stringify(ultimoCliente) && d.tipo !== "gracias" && d.tipo !== "entrada") return;
  ultimoCliente = d;
  const modo = S.estado.pantalla_cliente_modo || "monitor";
  if (modo !== "visor") {   // segundo monitor
    if (canalCliente) canalCliente.postMessage(d);
    else { try { localStorage.setItem("allas_pantalla_cliente", JSON.stringify({ d, t: Date.now() })); } catch (_) { /* sin almacenamiento */ } }
  }
  if (modo !== "monitor") enviarVisor(d);   // visor TPV de texto
}

// El visor TPV lo maneja el servidor (está conectado al PC). Se agrupan los cambios rápidos (al teclear lo entregado)
// Y, tras la despedida o la bienvenida, el visor vuelve solo al mensaje de reposo.
let visorTimer = null, visorVolver = null;

function enviarVisor(d) {
  clearTimeout(visorTimer); clearTimeout(visorVolver);
  visorTimer = setTimeout(() => {
    fetch("/api/visor", { method: "POST", headers: { "Content-Type": "application/json", "X-Token": S.token }, body: JSON.stringify({ d }) })
      .catch(() => { /* sin servidor: se ignora */ });
  }, 150);
  if (d.tipo === "gracias" || d.tipo === "entrada") {
    visorVolver = setTimeout(() => { ultimoCliente = { tipo: "libre" }; enviarVisor({ tipo: "libre" }); }, d.tipo === "gracias" ? 8000 : 7000);
  }
}

// Lo que se ve en Salida, traducido a la pantalla del cliente
function informarCobroCliente() {
  const c = S.cobro || {}, t = c.ticket, r = c.resultado;
  if (S.vista !== "cobrar") return;
  if (r) {
    const p = r.pago;
    return pantallaCliente({ tipo: "gracias", total_cent: p ? p.importe_cent : 0, cambio_cent: p ? p.cambio_cent || 0 : 0,
      salida: r.salida ? "Salida registrada · buen viaje" : r.salida_limite ? `Puede salir hasta las ${hora(r.salida_limite)}` : "" });
  }
  if (!t || !t.liquidacion) return pantallaCliente({ tipo: "libre" });
  const l = t.liquidacion;
  const dSel = (l.descuentos || []).find((o) => o.id === c.descuento);
  const dto = dSel ? dSel.descuento_cent : 0;
  const lineas = [];
  if (l.pendiente_estancia_cent) lineas.push({ concepto: `Estancia (${duracion(l.minutos)})`, importe_cent: l.pendiente_estancia_cent });
  if (l.extras_pendientes_cent) lineas.push({ concepto: "Servicios y productos", importe_cent: l.extras_pendientes_cent });
  if (dto) lineas.push({ concepto: dSel.nombre, importe_cent: dto, dto: true });
  const ent = (c.entregado || "").trim() ? aCent(c.entregado) : null;
  pantallaCliente({ tipo: "cobro", matricula: t.matricula, entrada: fechaHora(t.entrada), tiempo: duracion(l.minutos), tarifa: t.tarifa_nombre,
    total_cent: Math.max(0, l.pendiente_cent - dto), lineas: lineas.length > 1 || dto ? lineas : [],
    metodo: c.metodo, entregado_cent: ent != null && !Number.isNaN(ent) ? ent : null });
}

// Abre la ventana del cliente; si el navegador lo permite, directamente en el otro monitor
async function abrirPantallaCliente() {
  let opciones = "popup,width=1280,height=800";
  try {
    if ("getScreenDetails" in window) {
      const pantallas = await window.getScreenDetails();
      const otra = pantallas.screens.find((x) => x !== pantallas.currentScreen);
      if (otra) opciones = `popup,left=${otra.availLeft},top=${otra.availTop},width=${otra.availWidth},height=${otra.availHeight}`;
    }
  } catch (_) { /* sin permiso: se abre normal y se arrastra al otro monitor */ }
  const w = window.open("/cliente.html", "proyecto_allas_cliente", opciones);
  if (!w) return toast("El navegador ha bloqueado la ventana. Permita las ventanas emergentes para este programa.", "error");
  S.ventanaCliente = w;
  toast("Pantalla de cliente abierta. Llévela al segundo monitor y pulse en ella para verla a pantalla completa.", "ok");
}

const avisarPantallaCliente = () => { try { if (canalCliente) canalCliente.postMessage({ tipo: "config" }); } catch (_) { /* nada */ } };

// ============================================================ al cargar

if (canalCliente) canalCliente.onmessage = (e) => { if (e.data && e.data.tipo === "hola") canalCliente.postMessage(ultimoCliente); };
