/* PROYECTO ALLAS · Ajustes → Documentos y Equipos */
"use strict";

// ====================================================================== Plantillas (4.9)
// Plantillas hechas con el Editor de plantillas (programa aparte): se cargan aquí y sustituyen el diseño de serie de ese documento.

async function montarPlantillas(el, tipos, alCambiar) {
  const est = await api("GET", "/api/plantillas");
  el.innerHTML = `<h3>Plantillas del Editor de plantillas</h3>
    <p class="suave" style="margin:6px 0 10px">Si ha diseñado una plantilla con el <b>Editor de plantillas</b>, cárguela aquí (archivo <span class="mono">.json</span>).
      Con una plantilla cargada, ese documento se imprime con ella en lugar del diseño de serie. Para modificar la actual, descárguela y ábrala en el editor.</p>
    ${tipos.map((t) => `<div class="plt-fila" data-t="${t}"><b>${esc(est[t].nombre_tipo)}</b>
        <span class="etiqueta ${est[t].activa ? "e-pagado" : "e-salido"}">${est[t].activa ? esc(est[t].nombre) : "Diseño de serie"}</span>
        <span class="fila" style="gap:6px"><label class="btn mini">Cargar plantilla…<input type="file" accept=".json,application/json" hidden></label>
        <button type="button" class="btn mini" data-d>Descargar${est[t].activa ? " la actual" : " la de serie"}</button>
        ${est[t].activa ? '<button type="button" class="btn mini" data-q>Volver al diseño de serie</button>' : ""}</span></div>`).join("")}`;
  $$(".plt-fila", el).forEach((f) => {
    const t = f.dataset.t;
    $("input[type=file]", f).onchange = accion(async (e) => {
      const arch = e.target.files[0];
      if (!arch) return;
      let obj;
      try { obj = JSON.parse(await arch.text()); } catch (_) { throw new Error("Ese archivo no es una plantilla (JSON no válido)"); }
      if (obj.tipo && obj.tipo !== t) throw new Error(`Esa plantilla es de «${NOMBRES_PLANTILLA[obj.tipo] || obj.tipo}», no de «${NOMBRES_PLANTILLA[t]}»`);
      const r = await api("PUT", "/api/plantillas", obj);
      toast(r.campos_desconocidos.length ? `Plantilla cargada. Campos desconocidos (salen vacíos): ${r.campos_desconocidos.join(", ")}` : "Plantilla cargada", r.campos_desconocidos.length ? "err" : "ok");
      await montarPlantillas(el, tipos, alCambiar);
      alCambiar();
    });
    $("[data-d]", f).onclick = () => descargarUrl("/api/plantillas/" + t, {});
    if ($("[data-q]", f)) $("[data-q]", f).onclick = accion(async () => {
      if (!(await confirmar("Volver al diseño de serie", `¿Dejar de usar la plantilla de «${est[t].nombre_tipo}»? El archivo del editor no se borra.`, { boton: "Volver" }))) return;
      await api("DELETE", "/api/plantillas/" + t);
      toast("Se usa el diseño de serie", "ok");
      await montarPlantillas(el, tipos, alCambiar);
      alCambiar();
    });
  });
}

const NOMBRES_PLANTILLA = { entrada: "Ticket de entrada", recibo: "Factura / recibo (ticket)", bono: "Recibo de bono", tarjeta: "Tarjeta de abonado", factura: "Factura A4 (PDF)" };

// ====================================================================== Ticket

const TICKET_CAMPOS = ["logo_ticket", "ticket_entrada_copias", "entrada_ajuste_max_min", "ticket_codigo", "ticket_qr_tam", "ticket_cabecera_invertida", "ticket_cabecera_extra",
  "ticket_mostrar_direccion", "ticket_mostrar_precio", "ticket_tarifas_url_activo", "ticket_tarifas_url", "ticket_entrada_titulo", "ticket_entrada_pie",
  "recibo_titulo", "recibo_salida_texto", "recibo_pie", "tarjeta_titulo", "tarjeta_pie",
  "ticket_nombre_tam", "ticket_mostrar_razon", "ticket_mostrar_nif", "ticket_mostrar_telefono", "ticket_mostrar_web",
  "ticket_separador", "ticket_llaves_mostrar", "ticket_llaves_defecto", "ticket_mostrar_cajero", "ticket_salida_imprimir", "recibo_mostrar_cambio", "ticket_lineas_corte"];

const ajTicket = accion(async (el) => {
  const c = await api("GET", "/api/config");
  const chk = (k, txt, def = "0") => `<label class="fila" style="font-weight:600;gap:8px"><input type="checkbox" name="${k}" ${(c[k] ?? def) === "1" ? "checked" : ""}> ${txt}</label>`;
  const txt = (k, et, ayuda = "") => `<label class="campo">${et}${ayuda ? ` <span class="ayuda">${ayuda}</span>` : ""}<input class="ent" name="${k}" value="${esc(c[k] || "")}"></label>`;
  const area = (k, et, ayuda = "") => `<label class="campo">${et}${ayuda ? ` <span class="ayuda">${ayuda}</span>` : ""}<textarea class="ent" name="${k}" rows="3">${esc(c[k] || "")}</textarea></label>`;
  const sel = (k, et, ops, def) => `<label class="campo">${et}<select class="ent" name="${k}">${ops.map(([v, n]) => `<option value="${v}" ${(c[k] || def) === v ? "selected" : ""}>${n}</option>`).join("")}</select></label>`;
  S.muestraTipo = S.muestraTipo || "entrada";
  el.innerHTML = `<div class="ajuste-ticket">
    <form id="f-tk" class="panel">
      <h3>Logo del ticket <span class="ayuda">opcional · el de la factura PDF se cambia en Documentos → Factura</span></h3>
      <div id="logo-aj" style="margin:10px 0"></div>
      <div class="rejilla" style="margin:0 0 18px;gap:8px">
        ${chk("logo_ticket", "Imprimir el logo en los tickets (entrada, factura, bono, tarjeta)")}
      </div>
      <h3>Código para el lector</h3>
      <div class="rejilla r2" style="margin:10px 0 18px">
        <label class="campo">Tipo de código<select class="ent" name="ticket_codigo">
          ${[["ambos", "QR + código de barras"], ["barras", "Solo código de barras"], ["qr", "Solo QR"]]
            .map(([v, n]) => `<option value="${v}" ${c.ticket_codigo === v ? "selected" : ""}>${n}</option>`).join("")}</select></label>
        <label class="campo">Tamaño del QR <span class="ayuda" id="qr-tam-v">${c.ticket_qr_tam}</span><input type="range" min="3" max="8" name="ticket_qr_tam" value="${c.ticket_qr_tam || 6}"></label>
      </div>
      <p class="ayuda" style="margin:-8px 0 16px">Los lectores láser e infrarrojos (1D) solo leen código de barras; los lectores de imagen (2D) leen ambos.</p>
      <h3>Cabecera</h3>
      <div class="rejilla" style="margin:10px 0 18px;gap:10px">
        ${chk("ticket_cabecera_invertida", "Nombre del parking en banda negra")}
        ${chk("ticket_mostrar_direccion", "Mostrar dirección")}
        ${area("ticket_cabecera_extra", "Texto bajo la cabecera", "horario, web, teléfono de incidencias…")}
        <p class="ayuda" style="margin:0">Nombre, razón social, NIF y dirección se cambian en «Empresa y cobro».</p>
      </div>
      <div id="tk42"><h3>Diseño del ticket</h3>
    <div class="rejilla r2" style="margin:10px 0 10px;gap:10px">
      ${sel("ticket_nombre_tam", "Nombre del parking", [["grande", "Grande (doble alto y ancho)"], ["alto", "Alto"], ["normal", "Normal"]], "grande")}
      ${sel("ticket_separador", "Líneas separadoras", [["-", "– – – (guiones)"], ["=", "= = = (dobles)"], ["*", "* * * (asteriscos)"], ["_", "___ (subrayado)"], [".", "· · · (puntos)"], [" ", "Sin líneas"]], "-")}
      <label class="campo">Papel antes del corte <span class="ayuda">líneas en blanco</span><input class="ent num" type="number" min="1" max="10" name="ticket_lineas_corte" value="${esc(c.ticket_lineas_corte || "2")}"></label></div>
    <div class="rejilla" style="margin:0 0 18px;gap:8px">
      ${chk("ticket_mostrar_razon", "Mostrar la razón social", "1")}
      ${chk("ticket_mostrar_nif", "Mostrar el NIF", "1")}
      ${chk("ticket_mostrar_telefono", "Mostrar el teléfono", "1")}
      ${chk("ticket_mostrar_web", "Mostrar web y email <span class=\"ayuda\">(se escriben en Empresa → Datos)</span>")}
      ${chk("ticket_mostrar_cajero", "Nombre del cajero que atiende")}
      ${chk("ticket_salida_imprimir", "Marcar «Imprimir ticket de salida» por defecto al cobrar <span class=\"ayuda\">(normalmente desmarcado: el cajón se abre igual y el recibo se puede ver o imprimir desde «Ver recibo»)</span>")}
      ${chk("ticket_llaves_mostrar", "Ofrecer «Deja las llaves» en Entrada <span class=\"ayuda\">(el ticket dice que el parking se queda con las llaves)</span>", "1")}
      ${chk("ticket_llaves_defecto", "«Deja las llaves» marcada por defecto", "1")}
      ${chk("recibo_mostrar_cambio", "Entregado y cambio en la factura del ticket", "1")}</div></div><h3>Ticket de entrada</h3>
      <div class="rejilla" style="margin:10px 0 18px;gap:10px">
        ${txt("ticket_entrada_titulo", "Título")}
        <div class="rejilla r2" style="gap:10px">
          <label class="campo">Copias al imprimir <span class="ayuda">al emitir cada ticket (la reimpresión es siempre 1)</span>
            <select class="ent" name="ticket_entrada_copias">${[1, 2, 3, 4, 5].map((n) => `<option value="${n}" ${String(c.ticket_entrada_copias || "1") === String(n) ? "selected" : ""}>${n} ${n === 1 ? "copia" : "copias"}</option>`).join("")}</select></label>
          <label class="campo">Ajuste máximo de la hora en Entrada <span class="ayuda">minutos que se pueden sumar o restar · 0 = desactivado</span>
            <input class="ent num" type="number" min="0" max="1440" step="5" name="entrada_ajuste_max_min" value="${esc(c.entrada_ajuste_max_min ?? "120")}"></label>
        </div>
        ${chk("ticket_mostrar_precio", "Mostrar precio, cortesía y máximo diario (desactivado: el ticket no lleva precios)")}
        ${chk("ticket_tarifas_url_activo", "Imprimir una dirección para consultar las tarifas")}
        ${txt("ticket_tarifas_url", "Dirección de las tarifas (por ejemplo, la web del parking)")}
        ${area("ticket_entrada_pie", "Texto del pie")}
      </div>
      <h3>Factura / recibo de pago</h3>
      <div class="rejilla" style="margin:10px 0 18px;gap:10px">
        ${txt("recibo_titulo", "Título")}
        ${txt("recibo_salida_texto", "Aviso de salida", "{hora} se sustituye por la hora límite")}
        ${area("recibo_pie", "Texto del pie")}
      </div>
      <h3>Tarjeta de abonado</h3>
      <div class="rejilla" style="margin:10px 0 18px;gap:10px">
        ${txt("tarjeta_titulo", "Título")}
        ${area("tarjeta_pie", "Texto del pie")}
      </div>
      <div class="fila"><button class="btn prim">Guardar cambios</button><button type="button" class="btn" id="b-tk-prueba">Imprimir esta muestra</button></div>
    </form>
    <div class="vista-ticket">
      <div class="pestanas" style="margin-bottom:12px">${[["entrada", "Entrada"], ["recibo", "Factura"], ["bono", "Bono"], ["tarjeta", "Tarjeta"]]
        .map(([id, n]) => `<button type="button" data-mt="${id}" class="${S.muestraTipo === id ? "activo" : ""}">${n}</button>`).join("")}</div>
      <div id="tk-muestra"></div>
      <p class="ayuda" style="text-align:center">Vista previa en vivo con datos de ejemplo.</p>
    </div></div>
    <div class="panel" id="plt-tk" style="margin-top:18px"></div>`;
  const leer = () => {
    const d = {};
    TICKET_CAMPOS.forEach((k) => {
      const i = $(`[name="${k}"]`, $("#f-tk"));
      if (i) d[k] = i.type === "checkbox" ? (i.checked ? "1" : "0") : i.value;
    });
    return d;
  };
  let tm, ultima;
  const refrescar = accion(async () => {
    const r = await api("POST", "/api/ticket/muestra", { tipo: S.muestraTipo, cambios: leer() });
    ultima = r;
    if ($("#tk-muestra")) $("#tk-muestra").innerHTML = renderTicket(r);
  });
  $("#f-tk").oninput = () => { $("#qr-tam-v").textContent = $('[name="ticket_qr_tam"]').value; clearTimeout(tm); tm = setTimeout(refrescar, 250); };
  $("#f-tk").onchange = $("#f-tk").oninput;
  $$("[data-mt]").forEach((b) => (b.onclick = () => { S.muestraTipo = b.dataset.mt; $$("[data-mt]").forEach((x) => x.classList.toggle("activo", x === b)); refrescar(); }));
  $("#f-tk").onsubmit = accion(async (e) => { e.preventDefault(); await api("PUT", "/api/config", leer()); toast("Ajustes del ticket guardados", "ok"); S.estado = await api("GET", "/api/estado"); });
  $("#b-tk-prueba").onclick = accion(async () => {
    await api("PUT", "/api/config", leer());
    const r = await api("POST", "/api/impresora/prueba");
    notarImpresion(r);
    toast("Guardado. Se ha enviado una prueba a la impresora", "ok");
  });
  montarLogo($("#logo-aj"), refrescar);
  montarPlantillas($("#plt-tk"), ["entrada", "recibo", "bono", "tarjeta"], refrescar);
  refrescar();
});

const ANCHOS_LOGO = [[192, "Pequeño"], [288, "Mediano"], [384, "Grande (58 y 80 mm)"], [512, "Todo el ancho (solo 80 mm)"]];

let logoImagen = null;   // última imagen cargada (para cambiar el tamaño sin volver a subirla)

function cargarImagen(src) {
  return new Promise((ok, mal) => {
    const i = new Image();
    i.onload = () => ok(i);
    i.onerror = () => mal(new Error("No se puede leer la imagen. Use PNG o JPG."));
    i.src = src;
  });
}

// Prepara las dos versiones: JPEG en color para el PDF y 1 bit por punto para la impresora térmica
function prepararLogo(img, ancho, tramado) {
  const lado = Math.max(img.naturalWidth, img.naturalHeight), esc = Math.min(1, 1200 / lado);
  const c1 = document.createElement("canvas");
  c1.width = Math.round(img.naturalWidth * esc); c1.height = Math.round(img.naturalHeight * esc);
  const x1 = c1.getContext("2d");
  x1.fillStyle = "#fff"; x1.fillRect(0, 0, c1.width, c1.height); x1.drawImage(img, 0, 0, c1.width, c1.height);
  const jpeg = c1.toDataURL("image/jpeg", 0.9).split(",")[1];

  let w = ancho, h = Math.round((ancho * img.naturalHeight) / img.naturalWidth);
  if (h > 400) { w = Math.floor((400 * img.naturalWidth) / img.naturalHeight / 8) * 8; h = Math.round((w * img.naturalHeight) / img.naturalWidth); }
  w = Math.max(8, w); h = Math.max(1, h);
  const c2 = document.createElement("canvas");
  c2.width = w; c2.height = h;
  const x2 = c2.getContext("2d");
  x2.fillStyle = "#fff"; x2.fillRect(0, 0, w, h); x2.drawImage(img, 0, 0, w, h);
  const px = x2.getImageData(0, 0, w, h).data;
  const gris = new Float32Array(w * h);
  for (let i = 0; i < w * h; i++) gris[i] = 0.299 * px[i * 4] + 0.587 * px[i * 4 + 1] + 0.114 * px[i * 4 + 2];
  const bits = new Uint8Array((w / 8) * h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = y * w + x, negro = gris[i] < 140;
      if (negro) bits[y * (w / 8) + (x >> 3)] |= 0x80 >> (x & 7);
      if (tramado) {   // Floyd–Steinberg: mejor para fotos y degradados
        const err = gris[i] - (negro ? 0 : 255);
        if (x + 1 < w) gris[i + 1] += (err * 7) / 16;
        if (y + 1 < h) {
          if (x > 0) gris[i + w - 1] += (err * 3) / 16;
          gris[i + w] += (err * 5) / 16;
          if (x + 1 < w) gris[i + w + 1] += err / 16;
        }
      }
    }
  }
  let bin = ""; bits.forEach((b) => (bin += String.fromCharCode(b)));
  return { jpeg, ancho: w, alto: h, bits: btoa(bin) };
}

const montarLogo = accion(async (el, alCambiar) => {
  if (!el) return;
  const info = await api("GET", "/api/logo");
  const hay = info && info.version;
  const anchoActual = hay ? info.ticket_ancho : 288;
  el.innerHTML = `<div class="logo-caja">
      <div><div class="ayuda">En la factura PDF (color)</div><div class="logo-prev">${hay ? `<img src="/api/logo/logo.jpg?v=${info.version}" alt="Logo">` : '<span class="suave">Sin logo</span>'}</div></div>
      <div><div class="ayuda">En el ticket (blanco y negro)</div><div class="logo-prev">${hay ? `<img src="/api/logo/ticket.png?v=${info.version}" alt="Logo en el ticket" style="image-rendering:pixelated">` : '<span class="suave">Sin logo</span>'}</div></div>
    </div>
    <div class="fila" style="margin-top:10px">
      <label class="btn">${hay ? "Cambiar logo…" : "Subir logo…"}<input type="file" id="lg-arch" accept="image/png,image/jpeg,image/webp,image/gif,image/bmp" hidden></label>
      <select class="ent" id="lg-ancho" title="Tamaño en el ticket" style="width:auto">${ANCHOS_LOGO.map(([v, n]) =>
        `<option value="${v}" ${Math.abs(v - anchoActual) < 40 ? "selected" : ""}>${n}</option>`).join("")}</select>
      <label class="fila" style="gap:6px;font-weight:500"><input type="checkbox" id="lg-tram"> Tramado (fotos)</label>
      ${hay ? '<button type="button" class="btn peligro" id="lg-quitar">Quitar logo</button>' : ""}
    </div>
    <p class="ayuda" style="margin:6px 0 0">PNG o JPG. Mejor con fondo blanco o transparente y buen contraste: la impresora térmica solo imprime en negro.</p>`;
  const subir = async (img, primera) => {
    const d = prepararLogo(img, Number($("#lg-ancho").value), $("#lg-tram").checked);
    await api("POST", "/api/logo", d);
    if (primera) {
      // la primera vez se activa en ticket y factura (se puede desmarcar después)
      await api("PUT", "/api/config", { logo_ticket: "1" });
      $$('[name="logo_ticket"]').forEach((c) => (c.checked = true));
    }
    toast(primera ? "Logo guardado y activado en los tickets" : "Logo actualizado", "ok");
    await montarLogo(el, alCambiar);
    alCambiar && alCambiar();
  };
  ["#lg-arch", "#lg-ancho", "#lg-tram"].forEach((s) => $(s).addEventListener("input", (e) => e.stopPropagation()));
  $("#lg-arch").onchange = accion(async (e) => {
    e.stopPropagation();
    const f = e.target.files[0]; if (!f) return;
    if (f.size > 8 * 1024 * 1024) throw new Error("La imagen es demasiado grande (máximo 8 MB)");
    const url = URL.createObjectURL(f);
    try { logoImagen = await cargarImagen(url); } finally { URL.revokeObjectURL(url); }
    await subir(logoImagen, !hay);
  });
  const rehacer = accion(async (e) => {
    e.stopPropagation();
    if (!hay) return;
    if (!logoImagen) logoImagen = await cargarImagen(`/api/logo/logo.jpg?v=${info.version}`);
    await subir(logoImagen, false);
  });
  $("#lg-ancho").onchange = rehacer;
  $("#lg-tram").onchange = rehacer;
  if ($("#lg-quitar")) $("#lg-quitar").onclick = accion(async () => {
    if (!(await confirmar("Quitar logo", "¿Quitar el logo de los tickets y de la factura?", { boton: "Quitar", peligro: true }))) return vistaAjustes($("#vista"));
    await api("DELETE", "/api/logo");
    logoImagen = null;
    toast("Logo quitado", "ok");
    vistaAjustes($("#vista"));
  });
});

// =============================================================== Factura (PDF)

const COLORES_FACTURA = ["#1747c9", "#0f7a43", "#0e7490", "#6d28d9", "#9f1239", "#c2410c", "#334155", "#111827"];

const ajFactura = accion(async (el) => {
  const c = await api("GET", "/api/config");
  const color = c.factura_color || "#1747c9", cab = c.factura_cabecera_tabla || "#141b26";
  el.innerHTML = `<div class="ajuste-factura">
    <form class="panel" id="f-fac">
      <h3>Colores</h3>
      <div class="campo" style="margin-top:10px">Color principal <span class="ayuda">título, línea y total</span>
        <div class="fila colores-app" style="margin-top:6px">${COLORES_FACTURA.map((x) => `<label class="color-app" style="background:${x}"><input type="radio" name="fc" value="${x}" ${color.toLowerCase() === x ? "checked" : ""}></label>`).join("")}
          <input type="color" name="factura_color" value="${esc(color)}" title="Otro color"></div></div>
      <div class="campo" style="margin-top:10px">Cabecera de la tabla
        <div class="fila colores-app" style="margin-top:6px">${["#141b26", ...COLORES_FACTURA.slice(0, 6)].map((x) => `<label class="color-app" style="background:${x}"><input type="radio" name="fct" value="${x}" ${cab.toLowerCase() === x ? "checked" : ""}></label>`).join("")}
          <input type="color" name="factura_cabecera_tabla" value="${esc(cab)}" title="Otro color"></div></div>
      <div class="rejilla r2" style="margin:12px 0 18px;gap:10px">
        <div id="fac-logo44" style="grid-column:1/-1"></div>
        <label class="fila" style="font-weight:600;gap:8px;align-self:end"><input type="checkbox" name="logo_factura" ${c.logo_factura === "1" ? "checked" : ""}> Poner el logo en la factura</label>
        <label class="campo">Tamaño del logo<select class="ent" name="factura_logo_tam">${[["pequeno", "Pequeño"], ["mediano", "Mediano"], ["grande", "Grande"]]
          .map(([v, n]) => `<option value="${v}" ${(c.factura_logo_tam || "mediano") === v ? "selected" : ""}>${n}</option>`).join("")}</select></label></div>
      <h3>Textos</h3>
      <div class="rejilla r2" style="margin:10px 0 10px;gap:10px">
        <label class="campo">Título con datos del cliente<input class="ent" name="factura_titulo_completa" value="${esc(c.factura_titulo_completa || "FACTURA")}"></label>
        <label class="campo">Título sin datos del cliente <span class="ayuda">factura simplificada en PDF</span><input class="ent" name="factura_titulo_simplificada" value="${esc(c.factura_titulo_simplificada || c.recibo_titulo || "FACTURA SIMPLIFICADA")}"></label></div>
      <label class="campo">Notas bajo el total <span class="ayuda">forma de pago, IBAN, condiciones…</span><textarea class="ent" name="factura_notas" rows="3">${esc(c.factura_notas || "")}</textarea></label>
      <label class="campo" style="margin-top:10px">Pie de página <span class="ayuda">vacío = el mismo texto que el pie del ticket</span><textarea class="ent" name="factura_pie" rows="2">${esc(c.factura_pie || "")}</textarea></label>
      <label class="fila" style="font-weight:600;gap:8px;margin:12px 0 16px"><input type="checkbox" name="factura_mostrar_detalle" ${c.factura_mostrar_detalle !== "0" ? "checked" : ""}> Recuadro de detalle (matrícula, ticket, entrada, salida, tiempo)</label>
      <div class="fila"><button class="btn prim">Guardar</button><span class="suave" style="font-size:.85rem">Razón social, NIF, dirección y teléfono se cambian en <i>Empresa → Datos y cobro</i>.</span></div>
    </form>
    <div class="vista-factura"><div class="fila" style="justify-content:space-between;margin-bottom:8px"><b>Vista previa</b>
        <span class="fila" style="gap:8px"><span class="suave" style="font-size:.85rem">con datos de ejemplo</span><button type="button" class="btn mini" id="fac-abrir">Abrir en grande</button></span></div>
      <iframe id="fac-prev" title="Vista previa de la factura"></iframe></div></div>
    <div class="panel" id="plt-fac" style="margin-top:18px"></div>`;
  const f = $("#f-fac", el);
  const leer = () => {
    const d = {};
    ["factura_color", "factura_cabecera_tabla", "factura_logo_tam", "factura_titulo_completa", "factura_titulo_simplificada",
      "factura_notas", "factura_pie"].forEach((k) => (d[k] = f[k].value));
    d.logo_factura = f.logo_factura.checked ? "1" : "0";
    d.factura_mostrar_detalle = f.factura_mostrar_detalle.checked ? "1" : "0";
    return d;
  };
  let tm, url;
  const vista = async () => {
    try {
      const r = await fetch("/api/factura/muestra", { method: "POST", headers: { "Content-Type": "application/json", "X-Token": S.token }, body: JSON.stringify({ cambios: leer() }) });
      if (!r.ok) return;
      const b = await r.blob();
      if (url) URL.revokeObjectURL(url);
      url = URL.createObjectURL(b);
      const fr = $("#fac-prev", el);
      if (fr) fr.src = url + "#toolbar=0&navpanes=0&view=FitH";
    } catch (_) { /* sin vista previa */ }
  };
  $$("[name=fc]", f).forEach((r) => (r.onchange = () => { f.factura_color.value = r.value; f.oninput(); }));
  $$("[name=fct]", f).forEach((r) => (r.onchange = () => { f.factura_cabecera_tabla.value = r.value; f.oninput(); }));
  f.oninput = () => { clearTimeout(tm); tm = setTimeout(vista, 400); };
  $("#fac-abrir", el).onclick = () => { if (url) window.open(url, "_blank"); };
  f.onchange = f.oninput;
  f.onsubmit = accion(async (e) => { e.preventDefault(); await api("PUT", "/api/config", leer()); toast("Ajustes de la factura guardados", "ok"); });
  vista();
  montarLogoFactura(el);
  montarPlantillas($("#plt-fac", el), ["factura"], vista);
});

// Logo propio de la factura (en color); si no hay, se usa el del ticket
function montarLogoFactura(el) {
  const caja = $("#fac-logo44", el);
  const pintar = accion(async () => {
    const [propio, ticket] = await Promise.all([api("GET", "/api/logo/factura"), api("GET", "/api/logo")]);
    const hay = propio && propio.ancho, delTicket = !hay && ticket && ticket.jpeg_ancho;
    caja.innerHTML = `<div class="logo-fac44">
        <div class="logo-prev">${hay || delTicket ? `<img src="/api/logo/factura.jpg?token=${encodeURIComponent(S.token)}&v=${(propio && propio.version) || (ticket && ticket.version) || 0}" alt="Logo de la factura">`
          : '<span class="suave">Sin logo</span>'}</div>
        <div><b>Logo de la factura</b><div class="suave" style="font-size:.88rem;margin:2px 0 8px">${hay ? `En color, ${propio.ancho}×${propio.alto} px.`
          : delTicket ? "Usa el del ticket. Puede subir uno propio para la factura (en color)." : "PNG o JPG; mejor ancho y con fondo blanco."}</div>
          <div class="fila"><label class="btn">${hay ? "Cambiar…" : "Subir logo…"}<input type="file" id="fl44-arch" accept="image/png,image/jpeg,image/webp" hidden></label>
            ${hay ? '<button type="button" class="btn peligro" id="fl44-quitar">Quitar</button>' : ""}</div></div></div>`;
    $("#fl44-arch", caja).onchange = accion(async (e) => {
      const a = e.target.files[0]; if (!a) return;
      await api("POST", "/api/logo/factura", { jpeg: await aJpegFondoBlanco(a) });
      const f = $("#f-fac", el); if (f && f.logo_factura) f.logo_factura.checked = true;
      toast("Logo de la factura guardado", "ok"); pintar(); if (f) f.oninput();
    });
    if ($("#fl44-quitar", caja)) $("#fl44-quitar", caja).onclick = accion(async () => {
      await api("DELETE", "/api/logo/factura"); toast("Logo de la factura quitado", "ok"); pintar(); const f = $("#f-fac", el); if (f) f.oninput();
    });
  });
  pintar();
}

// ========================================================== Impresoras y cajón

// ---- 4.26 · impresoras instaladas en Windows: se detectan solas y se eligen de una lista
// opciones.vacio: texto de la opción «sin nombre» (p. ej. la predeterminada); opciones.auto: rellenar sola la mejor candidata si el campo está vacío
async function selectorImpresoras(input, { vacio = "", auto = false, al_elegir = null, valores_por_defecto = [] } = {}) {
  const caja = document.createElement("span");
  caja.className = "fila sel-imp"; caja.style.cssText = "gap:6px;flex-wrap:nowrap";
  caja.innerHTML = '<select class="ent" aria-label="Impresoras instaladas" style="flex:1"></select><button type="button" class="btn mini" title="Volver a buscar las impresoras del equipo">↻ Buscar</button>';
  const sel = $("select", caja), nota = document.createElement("span");
  nota.className = "ayuda"; nota.style.display = "block";
  input.parentNode.insertBefore(caja, input); input.parentNode.appendChild(nota);
  let lista = [];
  const pintar = () => {
    const actual = input.value.trim();
    const op = lista.map((i) => `<option value="${esc(i.nombre)}">${esc(i.nombre)}${i.ticket ? " · térmica de tickets" : ""}${i.predeterminada ? " · predeterminada" : ""}${i.virtual ? " · virtual" : ""}</option>`);
    sel.innerHTML = (vacio ? `<option value="">${esc(vacio)}</option>` : "") + op.join("") + '<option value="__otro">Otra (escribir el nombre)…</option>';
    sel.value = actual && lista.some((i) => i.nombre === actual) ? actual : !actual && vacio ? "" : actual ? "__otro" : "__otro";
    input.classList.toggle("oculto", sel.value !== "__otro");
  };
  const buscar = accion(async () => {
    nota.textContent = "Buscando impresoras…";
    const r = await api("GET", "/api/impresoras");
    lista = r.impresoras || [];
    if (auto && (!input.value.trim() || valores_por_defecto.includes(input.value.trim())) && lista.length) {
      const mejor = lista.find((i) => i.ticket) || (lista.filter((i) => !i.virtual).length === 1 ? lista.find((i) => !i.virtual) : null);
      if (mejor) { input.value = mejor.nombre; nota.textContent = `Detectada: ${mejor.nombre}. Pulse Guardar para usarla.`; pintar(); if (al_elegir) al_elegir(mejor); return; }
    }
    pintar();
    nota.textContent = lista.length ? `${lista.length} impresora${lista.length === 1 ? "" : "s"} detectada${lista.length === 1 ? "" : "s"}.`
      : r.error ? `No se pudieron leer las impresoras: ${r.error}` : "No se detectó ninguna impresora instalada. Instálela en Windows o escriba el nombre.";
  });
  sel.onchange = () => { if (sel.value !== "__otro") { input.value = sel.value; } else { input.value = ""; input.focus(); } input.classList.toggle("oculto", sel.value !== "__otro"); input.dispatchEvent(new Event("input", { bubbles: true })); };
  $("button", caja).onclick = buscar;
  await buscar();
  return { mostrar: (v) => { caja.classList.toggle("oculto", !v); nota.classList.toggle("oculto", !v); input.classList.toggle("oculto", v && sel.value !== "__otro"); } };
}


const ajImpresora = accion(async (el) => {
  if (!tieneRol("admin")) {
    el.innerHTML = `<div class="panel fila"><button class="btn prim" id="b-prueba">Imprimir prueba</button></div>`;
    $("#b-prueba").onclick = accion(async () => { const r = await api("POST", "/api/impresora/prueba"); notarImpresion(r); verImpresion(r); });
    return;
  }
  await formCfg(el, (c) => `
    ${campoCfg(c, "impresora_modo", "Conexión", { opciones: [["pantalla", "Solo en pantalla (sin impresora, no gasta papel)"], ["windows", "Impresora instalada en Windows (USB)"], ["dispositivo", "Dispositivo Linux (/dev/usb/lp0)"], ["red", "Red / Ethernet (IP:9100)"], ["archivo", "Archivo (pruebas sin impresora)"]] })}
    ${campoCfg(c, "impresora_destino", "Destino", { ayuda: "nombre en Windows, ruta, IP:puerto o carpeta. Vacío = se ve en pantalla" })}
    ${campoCfg(c, "impresora_ancho", "Caracteres por línea", { opciones: [["42", "42 (80 mm, fuente A)"], ["48", "48 (80 mm, fuente B)"], ["32", "32 (58 mm)"]] })}
    ${campoCfg(c, "cajon_pin", "Pin del cajón", { opciones: [["0", "Pin 2 (habitual)"], ["1", "Pin 5"]] })}`,
  async (c) => {
    // 4.26: con «Impresora instalada en Windows» se detectan solas las impresoras y se elige de una lista
    const fm = $("#f-cfg"), modoSel = fm.impresora_modo, dest = fm.impresora_destino;
    const selImp = await selectorImpresoras(dest, { auto: modoSel.value === "windows" || modoSel.value === "archivo", valores_por_defecto: modoSel.value === "archivo" ? ["salida_impresora"] : [],
      al_elegir: () => { if (modoSel.value !== "windows") { modoSel.value = "windows"; modoSel.dispatchEvent(new Event("change")); } } });
    const ajustar = () => selImp.mostrar(modoSel.value === "windows");
    modoSel.addEventListener("change", ajustar); ajustar();
    $("#cfg-extra").innerHTML = `<button type="button" class="btn" id="b-prueba">Imprimir prueba</button> <button type="button" class="btn" id="b-cajon2">Probar cajón</button>`;
    $("#b-prueba").onclick = accion(async () => { const r = await api("POST", "/api/impresora/prueba"); notarImpresion(r); verImpresion(r); });
    $("#b-cajon2").onclick = accion(async () => { notarImpresion(await api("POST", "/api/caja/abrir", { motivo: "Prueba de cajón" })); toast("Pulso de apertura enviado", "ok"); });
    montarImpresoraA4(el, c);
  });
});

// Impresora A4 para las facturas en PDF (además del ticket)
function montarImpresoraA4(el, c) {
  const modo = c.a4_modo || "";
  el.insertAdjacentHTML("beforeend", `<form class="panel" id="f-a4" style="margin-top: 16px; max-width: 900px;"><h3>Impresora A4 para las facturas</h3>
    <p class="suave" style="margin:6px 0 12px">Para imprimir en papel A4 las facturas en PDF (con los datos del cliente), además del ticket. En la ventana de la factura aparece
      <b>Imprimir en A4</b>.</p>
    <div class="rejilla r2">
      <label class="campo">Cómo se imprime<select class="ent" name="a4_modo">${[["", "Sin impresora A4"], ["navegador", "Abrir el PDF e imprimir desde la ventana (elige la impresora cada vez)"],
        ["windows", "Directamente en una impresora de Windows"], ["programa", "Con un programa (p. ej. SumatraPDF, silencioso)"], ["archivo", "Guardar el PDF en una carpeta (pruebas)"]]
        .map(([v, n]) => `<option value="${v}" ${modo === v ? "selected" : ""}>${n}</option>`).join("")}</select></label>
      <label class="campo a4-imp">Impresora <span class="ayuda" id="a4-ayuda-imp">nombre en Windows · vacío = la predeterminada</span>
        <input class="ent" name="a4_impresora" value="${esc(c.a4_impresora || "")}" placeholder="HP LaserJet de la oficina"></label>
      <label class="campo a4-prog" style="grid-column:1/-1">Orden <span class="ayuda">{archivo} = el PDF · {impresora} = la impresora</span>
        <input class="ent mono" name="a4_programa" value="${esc(c.a4_programa || "")}" placeholder='"C:\\Program Files\\SumatraPDF\\SumatraPDF.exe" -print-to "{impresora}" -silent "{archivo}"'></label></div>
    <label class="fila a4-auto" style="gap:8px;margin-top:10px;font-weight:600"><input type="checkbox" name="a4_completas" ${c.a4_completas === "1" ? "checked" : ""}>
      El botón «Imprimir» de una factura con datos del cliente la imprime en A4 (en vez del ticket)</label>
    <p class="ayuda a4-win" style="margin:6px 0 0">Necesita un lector de PDF que sepa imprimir solo (Adobe Reader o SumatraPDF). Si no imprime, use el modo «Con un programa» con SumatraPDF.</p>
    <div class="fila" style="margin-top:12px"><button class="btn prim">Guardar</button></div></form>`);
  const f = $("#f-a4", el);
  const pintar = () => {
    const m = f.a4_modo.value;
    $$(".a4-imp", f).forEach((x) => x.classList.toggle("oculto", !["windows", "programa", "archivo"].includes(m)));
    $$(".a4-prog", f).forEach((x) => x.classList.toggle("oculto", m !== "programa"));
    $$(".a4-auto", f).forEach((x) => x.classList.toggle("oculto", !m || m === "navegador"));
    $$(".a4-win", f).forEach((x) => x.classList.toggle("oculto", m !== "windows"));
    $("#a4-ayuda-imp", f).textContent = m === "archivo" ? "carpeta donde se guardan" : "nombre en Windows · vacío = la predeterminada";
  };
  f.a4_modo.onchange = pintar; pintar();
  // 4.26: en modo «Directamente en una impresora de Windows» se elige de la lista de impresoras detectadas
  selectorImpresoras(f.a4_impresora, { vacio: "La predeterminada de Windows" }).then((si) => {
    const aj = () => si.mostrar(f.a4_modo.value === "windows");
    f.a4_modo.addEventListener("change", aj); aj();
  });
  f.onsubmit = accion(async (e) => {
    e.preventDefault();
    await api("PUT", "/api/config", { a4_modo: f.a4_modo.value, a4_impresora: f.a4_impresora.value.trim(), a4_programa: f.a4_programa.value.trim(),
      a4_completas: f.a4_completas.checked ? "1" : "0" });
    S.estado = await api("GET", "/api/estado");
    toast("Impresora A4 guardada", "ok");
  });
}

// ========================================================= Pantalla de cliente

const PRESENTACION = ["pantalla_cliente_transicion", "pantalla_cliente_transicion_ms", "pantalla_cliente_segundos", "pantalla_cliente_orden",
  "pantalla_cliente_ajuste", "pantalla_cliente_rotulo", "pantalla_cliente_tema", "pantalla_cliente_color", "pantalla_cliente_movimiento",
  "pantalla_cliente_progreso", "pantalla_cliente_pie"];

// Efectos del visor (4.11): se hacen reenviando el texto cuadro a cuadro, así que valen para cualquier visor de texto
const EFECTOS_VISOR = [["ninguno", "Sin efecto"], ["desplazar", "Desplazar el texto"], ["parpadear", "Parpadear"], ["escribir", "Escribir letra a letra"], ["entrar", "Entrar por la derecha"]];

// ---- miniaturas de las fotos: se descargan con fetch (así se puede explicar por qué falla una) y se guardan para no repetir
const MINIS = new Map();   // "id:actualizado" → URL local de la foto
const claveMini = (a) => `${a.id}:${a.actualizado}`;
async function cargarMiniatura(tarjeta, a) {
  const caja = $(".pc45-mini", tarjeta), img = $("img", caja), msg = $(".pc45-cargando", caja);
  if (!a) return;
  const ok = (url) => { img.src = url; img.hidden = false; msg.hidden = true; };
  const mal = (motivo) => {
    img.hidden = true; msg.hidden = false;
    msg.innerHTML = `<b>No se pudo cargar</b><span>${esc(motivo)}</span><button type="button" class="reintentar">Reintentar</button>`;
    $("button", msg).onclick = (e) => { e.stopPropagation(); msg.textContent = "Cargando…"; cargarMiniatura(tarjeta, a); };
  };
  if (MINIS.has(claveMini(a))) return ok(MINIS.get(claveMini(a)));
  try {
    const r = await fetch(`/api/pantalla-cliente/foto/${a.id}?v=${encodeURIComponent(a.actualizado)}`, { cache: "reload" });
    if (!r.ok) throw new Error(`el servidor respondió ${r.status}`);
    const b = await r.blob();
    if (!b.size) throw new Error("la foto está vacía");
    const url = URL.createObjectURL(b);
    await new Promise((res, rej) => { const t = new Image(); t.onload = res; t.onerror = () => rej(new Error("el navegador no puede dibujar esta imagen")); t.src = url; });
    MINIS.set(claveMini(a), url); ok(url);
  } catch (e) {
    mal(e instanceof TypeError ? "la petición fue bloqueada (¿un bloqueador de anuncios del navegador?)" : e.message);
  }
}

// Visor grande: flechas del teclado o de pantalla para pasar de una foto a otra, Esc o clic fuera para cerrar
function verFotoGrande(lista, actual) {
  if (!lista.length || !actual) return;
  let i = Math.max(0, lista.findIndex((x) => x.id === actual.id));
  const cap = document.createElement("div"); cap.className = "pc45-grande";
  cap.innerHTML = `<button type="button" class="btn" data-d="-1" aria-label="Anterior">←</button><figure><img alt=""><figcaption></figcaption></figure>
    <button type="button" class="btn" data-d="1" aria-label="Siguiente">→</button><button type="button" class="btn cerrar" aria-label="Cerrar">✕</button>`;
  const pintar = () => { const x = lista[i]; $("img", cap).src = MINIS.get(claveMini(x)); $("figcaption", cap).textContent = `${i + 1} de ${lista.length}${x.titulo ? " · " + x.titulo : ""}${x.activo ? "" : " · oculta"}`; };
  const cerrar = () => { cap.remove(); document.removeEventListener("keydown", tecla); };
  const mover = (d) => { i = (i + d + lista.length) % lista.length; pintar(); };
  const tecla = (e) => { if (e.key === "Escape") cerrar(); else if (e.key === "ArrowLeft") mover(-1); else if (e.key === "ArrowRight") mover(1); };
  cap.onclick = (e) => { if (e.target === cap) cerrar(); };
  $$("[data-d]", cap).forEach((b) => (b.onclick = () => mover(+b.dataset.d)));
  $(".cerrar", cap).onclick = cerrar;
  document.addEventListener("keydown", tecla);
  document.body.appendChild(cap); pintar();
}

const ajPantallaCliente = accion(async (el) => {
  const [cfg, anuncios] = await Promise.all([api("GET", "/api/config"), api("GET", "/api/publicidad")]);
  if (!el.isConnected) return;
  const g = (k, d = "") => cfg[k] || d;
  const activa = cfg.pantalla_cliente_activa === "1";
  const modo = ["monitor", "visor", "ambos"].includes(cfg.pantalla_cliente_modo) ? cfg.pantalla_cliente_modo : "monitor";
  const sel = (k, ops, d) => `<select class="ent" name="${k}">${ops.map(([v, n]) => `<option value="${v}" ${g(k, d) === v ? "selected" : ""}>${n}</option>`).join("")}</select>`;
  const visibles = anuncios.filter((a) => a.activo).length;
  const hayEjemplos = anuncios.some((a) => /^(Bienvenido · abierto 24 horas|Abono mensual|Lavado mientras aparca|Pague con su móvil)$/.test(a.titulo || ""));
  const carpetaEj = await api("GET", "/api/publicidad/carpeta-ejemplos").catch(() => null);
  el.innerHTML = `<div class="pc45">
    <nav class="pc45-nav" aria-label="Secciones de la pantalla de cliente">
      <button type="button" class="chip" data-ir="f-pc">General</button>
      <button type="button" class="chip" data-ir="pc-visor" id="nav-visor">Visor TPV</button>
      <button type="button" class="chip" data-ir="pc-aspecto" id="nav-aspecto">Aspecto del monitor</button>
      <button type="button" class="chip" data-ir="pc-fotos" id="nav-fotos">Fotos</button></nav>
    <form class="panel pc45-gen" id="f-pc">
      <div class="fila" style="justify-content:space-between"><h3>Pantalla de cliente</h3>
        <span class="fila" style="gap:10px"><span class="suave" id="pc-guardado" style="font-size:.85rem">Los cambios se guardan solos</span>
          <span class="etiqueta ${activa ? "e-pagado" : "e-salido"}" id="pc-estado">${activa ? "Activada" : "Desactivada"}</span></span></div>
      <p class="suave" style="margin:6px 0 12px">Lo que ve el cliente mientras se le cobra (matrícula, importe, entregado y cambio) y, cuando no hay nadie, la publicidad.</p>
      <label class="fila" style="gap:10px;font-weight:600"><input type="checkbox" name="pantalla_cliente_activa" ${activa ? "checked" : ""}> Activar la pantalla de cliente</label>
      <div class="tipos-pantalla pc45-tipos">
        ${[["monitor", "Segundo monitor", "Pantalla grande con la publicidad"], ["visor", "Visor TPV de texto", "Visor de 2 líneas, solo texto"], ["ambos", "Los dos", "Monitor y visor a la vez"]]
          .map(([v, n, d]) => `<label class="tipo-pantalla"><input type="radio" name="pantalla_cliente_modo" value="${v}" ${modo === v ? "checked" : ""}><b>${n}</b><span>${d}</span></label>`).join("")}</div>
      <div class="rejilla r2" style="margin-top:12px">
        <label class="campo">Texto de bienvenida<input class="ent" name="pantalla_cliente_bienvenida" value="${esc(g("pantalla_cliente_bienvenida"))}" placeholder="Bienvenido"></label>
        <label class="campo">Texto tras pagar<input class="ent" name="pantalla_cliente_gracias" value="${esc(g("pantalla_cliente_gracias"))}" placeholder="¡Gracias por su visita!"></label></div>
      <div id="pc-visor" class="pc45-visor ${modo === "monitor" ? "oculto" : ""}">
        <h3>Visor TPV</h3>
        <div class="rejilla r2" style="margin-top:8px">
          <label class="campo">Conexión${sel("visor_conexion", [["serie", "Puerto serie / USB (COM)"], ["windows", "Impresora de Windows"], ["red", "Red (IP:puerto)"], ["programa", "Programa del fabricante"], ["archivo", "Archivo (prueba sin visor)"]], "archivo")}</label>
          <div class="campo"><span id="pc-dest-l">Puerto</span>
            <span class="fila" id="pc-puerto-fila" style="gap:6px;flex-wrap:nowrap"><select class="ent" id="pc-puerto" aria-label="Puertos COM disponibles" style="flex:1"></select>
              <button type="button" class="btn mini" id="pc-buscar" title="Volver a buscar los puertos del equipo">↻ Buscar</button></span>
            <input class="ent mono" name="visor_destino" value="${esc(g("visor_destino"))}" autocomplete="off">
            <span class="ayuda" id="pc-puerto-ayuda"></span></div>
          <label class="campo">En reposo · línea 1<input class="ent" name="visor_reposo1" value="${esc(g("visor_reposo1"))}" placeholder="${esc(cfg.nombre_parking || "Nombre del parking")}" maxlength="40"></label>
          <label class="campo">En reposo · línea 2<input class="ent" name="visor_reposo2" value="${esc(g("visor_reposo2"))}" placeholder="Bienvenido" maxlength="40"></label>
          <label class="campo">Efecto en los mensajes de texto${sel("visor_efecto", EFECTOS_VISOR, "ninguno")}<span class="ayuda" id="pc-ef-ayuda"></span></label>
          <label class="campo" id="pc-vel">Velocidad del efecto${sel("visor_velocidad", [["lenta", "Lenta"], ["normal", "Normal"], ["rapida", "Rápida"]], "normal")}</label></div>
        <details class="pc45-avanzado"><summary>Ajustes avanzados del visor</summary>
          <p class="ayuda" style="margin:6px 0 8px">Los de serie (ESC/POS, 9600 baudios, 20 caracteres) valen para casi todos los visores. Si las letras salen raras o cambiadas, use <b>Ajustar las letras del visor</b>: prueba las combinaciones y usted dice cuál se lee bien.</p>
          <div class="rejilla r2">
            <label class="campo" id="pc-bd">Velocidad (baudios)${sel("visor_baudios", [["9600", "9600"], ["19200", "19200"], ["4800", "4800"], ["2400", "2400"], ["38400", "38400"]], "9600")}</label>
            <label class="campo">Protocolo${sel("visor_protocolo", [["epson", "ESC/POS · Epson (el más común)"], ["aedex", "AEDEX (Posiflex, Aures…)"], ["cd5220", "CD5220"], ["texto", "Texto simple"]], "epson")}</label>
            <label class="campo" id="pc-fm">Bits y paridad${sel("visor_formato", [["8N1", "8 bits, sin paridad (8N1)"], ["7E1", "7 bits, paridad par (7E1)"], ["7O1", "7 bits, paridad impar (7O1)"], ["8E1", "8 bits, paridad par (8E1)"], ["8O1", "8 bits, paridad impar (8O1)"], ["7N1", "7 bits, sin paridad (7N1)"], ["8N2", "8 bits, 2 de stop (8N2)"]], "8N1")}</label>
            <label class="campo">Caracteres por línea${sel("visor_columnas", [["20", "20"], ["16", "16"], ["24", "24"], ["40", "40"]], "20")}</label></div></details>
        <p class="ayuda oculto" id="pc-prog-ayuda" style="margin:8px 0 0">Ruta del programa entre comillas y sus parámetros: <span class="mono">{l1}</span> y <span class="mono">{l2}</span> son las dos líneas.
          Ejemplo: <span class="mono">"C:\\Program Files\\Posiflex\\customerdisplay.exe" "{l1}" "{l2}"</span></p>
        <div class="fila" style="margin-top:12px;align-items:center;gap:12px;flex-wrap:wrap">
          <div class="visor-emulado" id="pc-emu" aria-label="Lo que muestra el visor"><div></div><div></div></div>
          <div class="pc-visor-btns"><button type="button" class="btn" id="pc-probar">Probar el visor</button>
            <button type="button" class="btn" id="pc-asistente" title="Prueba velocidades y protocolos hasta que las letras se lean bien">Ajustar las letras del visor…</button></div>
          <span class="ayuda" id="pc-visor-estado"></span></div>
        <div class="pc-asist oculto" id="pc-asist" aria-live="polite"></div></div>
    </form>
    <div class="panel suave ${modo === "visor" ? "" : "oculto"}" id="pc-sin-monitor">Con <b>Visor TPV de texto</b> no se usa el segundo monitor, así que no hay fotos que mostrar.
      Elija <b>Segundo monitor</b> o <b>Los dos</b> arriba para poner publicidad con fotos.</div>
    <div class="panel pc45-publi ${modo === "visor" ? "oculto" : ""}" id="pc-publi">
      <div class="fila" style="justify-content:space-between;gap:10px;flex-wrap:wrap"><h3>Segundo monitor · publicidad</h3>
        <span class="fila" style="gap:10px"><span class="suave" id="pc45-guardado" style="font-size:.85rem">Los cambios se guardan y se ven al momento</span>
          <button type="button" class="btn" id="pc-abrir" ${activa ? "" : "disabled"} title="Abre la ventana del cliente para llevarla al segundo monitor">🖥 Abrir en el segundo monitor</button></span></div>
      <div class="pc45-arriba" id="pc-aspecto">
        <div><div class="pc45-marco"><iframe id="pc45-previa" title="Vista previa de la pantalla de cliente" src="/cliente.html?vista=1" tabindex="-1"></iframe></div>
          <p class="ayuda" style="margin:6px 0 0;text-align:center">Así se ve ahora en el segundo monitor${visibles ? ` · ${visibles} foto${visibles === 1 ? "" : "s"}` : " · sin fotos: nombre y bienvenida"}</p></div>
        <form class="pc45-ajustes" id="f-pc45">
          <label class="campo">Cada foto se ve<span class="pc45-rango"><input type="range" name="pantalla_cliente_segundos" min="3" max="60" value="${esc(g("pantalla_cliente_segundos", "8"))}"><b id="pc45-seg"></b></span></label>
          <label class="campo">Cambio de foto${sel("pantalla_cliente_transicion", [["fundido", "Fundido"], ["deslizar", "Deslizar"], ["zoom", "Acercar"], ["ninguna", "Corte (sin efecto)"]], "fundido")}</label>
          <label class="campo">Velocidad del cambio${sel("pantalla_cliente_transicion_ms", [["400", "Rápido"], ["1000", "Normal"], ["2000", "Lento"]], "1000")}</label>
          <label class="campo">Orden${sel("pantalla_cliente_orden", [["secuencial", "Como en la lista"], ["aleatorio", "Aleatorio"]], "secuencial")}</label>
          <label class="campo">Foto${sel("pantalla_cliente_ajuste", [["cubrir", "Llenar la pantalla"], ["completa", "Entera (con bandas)"]], "cubrir")}</label>
          <label class="campo">Título y texto${sel("pantalla_cliente_rotulo", [["abajo", "Abajo"], ["arriba", "Arriba"], ["oculto", "No mostrar"]], "abajo")}</label>
          <label class="campo">Colores${sel("pantalla_cliente_tema", [["oscuro", "Oscuro"], ["claro", "Claro"]], "oscuro")}</label>
          <label class="campo">Color de acento<span class="fila" style="gap:6px;flex-wrap:nowrap">${["#2f6bff", "#0f7a43", "#0e7490", "#6d28d9", "#c2410c", "#9f1239"].map((c) =>
            `<button type="button" class="pc45-color" data-color="${c}" style="background:${c}" title="${c}"></button>`).join("")}<input type="hidden" name="pantalla_cliente_color" value="${esc(g("pantalla_cliente_color"))}"></span></label>
          <div class="pc45-checks">
            <label class="fila"><input type="checkbox" name="pantalla_cliente_movimiento" ${cfg.pantalla_cliente_movimiento === "1" ? "checked" : ""}> Movimiento lento</label>
            <label class="fila"><input type="checkbox" name="pantalla_cliente_progreso" ${cfg.pantalla_cliente_progreso === "1" ? "checked" : ""}> Barra de tiempo</label>
            <label class="fila"><input type="checkbox" name="pantalla_cliente_pie" ${cfg.pantalla_cliente_pie !== "0" ? "checked" : ""}> Pie con fecha y hora</label></div></form></div>
      <div class="fila pc45-cab-fotos" id="pc-fotos"><h3>Fotos <span class="suave" style="font-weight:400">(${anuncios.length})</span></h3><span style="flex:1"></span>
        <button type="button" class="btn" id="pc44-ej" data-quitar="${hayEjemplos ? "1" : ""}">${hayEjemplos ? "Quitar las fotos de ejemplo" : "Poner fotos de ejemplo"}</button>
        <label class="btn prim">Añadir fotos…<input type="file" id="pc-nueva" accept="image/*" multiple hidden></label></div>
      <p class="ayuda" style="margin:0 0 10px">Mejor fotos horizontales (16:9), JPG, PNG o WEBP. El título y el texto salen encima de la foto. Marque <i>Ocultar</i> para guardarla sin mostrarla en el monitor.
        ${carpetaEj && carpetaEj.archivos ? `Hay ${carpetaEj.archivos} fotos de ejemplo para elegir en <span class="mono">${esc(carpetaEj.ruta)}</span>.` : ""}</p>
      ${anuncios.length ? `<div class="pc45-fotos">${anuncios.map((a, i) => `<div class="pc45-foto ${a.activo ? "" : "apagada"}" data-id="${a.id}">
          <div class="pc45-mini" role="button" tabindex="0" title="Pulse para ver la foto grande">
            <img alt="" hidden><div class="pc45-cargando">Cargando…</div><span class="pc45-num">${i + 1}</span>
            ${a.activo ? "" : '<span class="pc45-estado no">Oculta</span>'}</div>
          <input class="ent" data-campo="titulo" value="${esc(a.titulo || "")}" placeholder="Título (opcional)" maxlength="80">
          <input class="ent" data-campo="texto" value="${esc(a.texto || "")}" placeholder="Texto (opcional)" maxlength="200">
          <div class="fila pc45-acc"><label class="fila" style="gap:6px;font-weight:600"><input type="checkbox" data-campo="oculta" ${a.activo ? "" : "checked"}> Ocultar</label>
            <span style="flex:1"></span>
            <button type="button" class="btn mini" data-mover="arriba" ${i === 0 ? "disabled" : ""} title="Antes">←</button>
            <button type="button" class="btn mini" data-mover="abajo" ${i === anuncios.length - 1 ? "disabled" : ""} title="Después">→</button>
            <button type="button" class="btn mini peligro" data-quitar title="Quitar la foto">Quitar</button></div></div>`).join("")}</div>`
        : '<div class="vacio">Sin fotos. Pulse «Añadir fotos…» o «Poner fotos de ejemplo».</div>'}
    </div></div>`;

  const recargar = () => ajPantallaCliente(el);
  const f0 = $("#f-pc", el), f = $("#f-pc45", el), previa = $("#pc45-previa", el);
  // ---- 1 · general y visor
  const dest = f0.visor_destino, selPuerto = $("#pc-puerto", el);
  const rellenarPuertos = (puertos) => {
    const actual = dest.value.trim();
    const ops = puertos.map((p) => `<option value="${esc(p.puerto)}">${esc(p.puerto + (p.nombre ? " · " + p.nombre : "") + (p.libre ? "" : " (en uso)"))}</option>`);
    if (actual && !puertos.some((p) => p.puerto === actual)) ops.unshift(`<option value="${esc(actual)}">${esc(actual)} (no detectado)</option>`);
    if (!ops.length) ops.push('<option value="">No se detecta ningún puerto COM</option>');
    ops.push('<option value="__otro">Escribir otro…</option>');
    selPuerto.innerHTML = ops.join("");
    if (actual) selPuerto.value = actual;
    else if (puertos.length) { const p0 = puertos.find((p) => p.libre) || puertos[0]; selPuerto.value = p0.puerto; dest.value = p0.puerto; }   // sin puerto elegido: el primero libre
    $("#pc-puerto-ayuda", el).textContent = puertos.length ? `${puertos.length} puerto${puertos.length === 1 ? "" : "s"} detectado${puertos.length === 1 ? "" : "s"}.` : "Conecte el visor y pulse «Buscar».";
    pintarModo();
  };
  const buscarPuertos = accion(async () => rellenarPuertos((await api("GET", "/api/visor/puertos")).puertos));
  $$("[data-ir]", el).forEach((b) => (b.onclick = () => { const d = document.getElementById(b.dataset.ir); if (d) d.scrollIntoView({ behavior: "smooth", block: "start" }); }));
  const pintarModo = () => {
    const m = f0.pantalla_cliente_modo.value, con = f0.visor_conexion.value, serie = con === "serie";
    $("#pc-visor", el).classList.toggle("oculto", m === "monitor");
    $("#pc-publi", el).classList.toggle("oculto", m === "visor");
    $("#pc-sin-monitor", el).classList.toggle("oculto", m !== "visor");
    $("#nav-visor", el).classList.toggle("oculto", m === "monitor");
    ["#nav-aspecto", "#nav-fotos"].forEach((q) => $(q, el).classList.toggle("oculto", m === "visor"));
    $("#pc-dest-l", el).textContent = { serie: "Puerto COM", windows: "Nombre de la impresora del visor", red: "IP:puerto", archivo: "Carpeta (vacío = salida_visor)", programa: "Programa y parámetros" }[con];
    $("#pc-prog-ayuda", el).classList.toggle("oculto", con !== "programa");
    $("#pc-bd", el).classList.toggle("oculto", !serie);
    $("#pc-fm", el).classList.toggle("oculto", !serie);
    $("#pc-asistente", el).disabled = con === "archivo" || con === "programa";
    $("#pc-asistente", el).title = con === "archivo" || con === "programa" ? "Elija antes el puerto COM, la impresora de Windows o la red" : "Prueba velocidades y protocolos hasta que las letras se lean bien";
    $("#pc-puerto-fila", el).classList.toggle("oculto", !serie);
    $("#pc-puerto-ayuda", el).classList.toggle("oculto", !serie);
    dest.classList.toggle("oculto", serie && selPuerto.value !== "__otro");
    const sinEf = con === "programa";   // con el programa del fabricante cada cuadro abriría el programa: no hay efectos
    f0.visor_efecto.disabled = sinEf;
    $("#pc-ef-ayuda", el).textContent = sinEf ? "No disponible con el programa del fabricante." : "Solo en los textos (reposo, bienvenida y despedida); los importes salen siempre fijos.";
    $("#pc-vel", el).style.visibility = sinEf || f0.visor_efecto.value === "ninguno" ? "hidden" : "visible";   // sin quitarlo del sitio: la rejilla no salta
  };
  $$('[name="pantalla_cliente_modo"]', f0).forEach((r) => (r.onchange = pintarModo));
  f0.visor_conexion.onchange = () => { pintarModo(); if (f0.visor_conexion.value === "serie" && !selPuerto.options.length) buscarPuertos(); };
  f0.visor_efecto.onchange = pintarModo;
  selPuerto.onchange = () => { if (selPuerto.value !== "__otro") dest.value = selPuerto.value; else { dest.value = ""; dest.focus(); } pintarModo(); };
  $("#pc-buscar", el).onclick = buscarPuertos;
  pintarModo();
  if (modo !== "monitor" && f0.visor_conexion.value === "serie") buscarPuertos();
  const pintarEmu = (ls, cols) => {   // una celda por carácter (como un visor de 20x2): las letras no se pisan ni se cortan
    const emu = $("#pc-emu", el); if (!emu) return;
    const n = Math.max(8, Math.min(40, +cols || 20)); emu.style.setProperty("--cols", n);
    [0, 1].forEach((i) => { const t = String((ls && ls[i]) || "").padEnd(n, " ").slice(0, n);
      emu.children[i].innerHTML = [...t].map((c) => `<i>${c === " " ? "&nbsp;" : esc(c)}</i>`).join(""); });
  };
  const leerVisor = async () => {
    try {
      const v = await api("GET", "/api/visor");
      pintarEmu(v.lineas, v.columnas);
      $("#pc-visor-estado", el).innerHTML = v.error ? `<span style="color:var(--rojo)">Último envío fallido: ${esc(v.error)}</span>` : "";
    } catch (_) { /* nada */ }
  };
  if (modo !== "monitor") leerVisor();
  // El visor de muestra reproduce el efecto con los cuadros que calcula el servidor (los mismos que recibe el visor real)
  let anim = null;
  const reproducir = (r) => {
    clearInterval(anim); anim = null;
    const cuadros = r.cuadros && r.cuadros.length ? r.cuadros : [r.lineas];
    let i = 0;
    const paso = () => { if (!el.isConnected) return clearInterval(anim); pintarEmu(cuadros[i], r.columnas); i++; if (i >= cuadros.length) { if (r.repetir) i = 0; else clearInterval(anim); } };
    paso();
    if (cuadros.length > 1) anim = setInterval(paso, r.ritmo_ms || 280);
  };
  const ajustesVisor = () => ({ conexion: f0.visor_conexion.value, destino: f0.visor_destino.value, baudios: f0.visor_baudios.value, protocolo: f0.visor_protocolo.value, formato: f0.visor_formato.value,
    columnas: f0.visor_columnas.value, efecto: f0.visor_efecto.value, velocidad: f0.visor_velocidad.value, reposo1: f0.visor_reposo1.value, reposo2: f0.visor_reposo2.value });
  $("#pc-probar", el).onclick = accion(async () => {
    try {
      const r = await api("POST", "/api/visor/prueba", ajustesVisor()); reproducir(r); toast(`Enviado al visor (${r.destino})`, "ok");
    } catch (e) {   // sin visor conectado (o mal el puerto): se enseña igualmente en el visor de muestra, con el motivo
      reproducir(await api("POST", "/api/visor/prueba", { ...ajustesVisor(), solo_ver: true }));
      $("#pc-visor-estado", el).innerHTML = `<span style="color:var(--rojo)">${esc(e.message || "No se pudo escribir en el visor")}</span> · se muestra aquí cómo quedaría`;
    }
  });
  // ---- Asistente: prueba combinaciones de velocidad y protocolo; el usuario dice cuál se lee bien y se guarda
  const PROTOS = [["epson", "ESC/POS Epson"], ["cd5220", "CD5220"], ["aedex", "AEDEX"], ["texto", "Texto simple"]];
  const asist = $("#pc-asist", el);
  const abrirAsistente = () => {
    const serie = f0.visor_conexion.value === "serie";
    const bauds = serie ? [...new Set([+f0.visor_baudios.value || 9600, 9600, 2400, 4800, 19200, 38400, 115200])] : [0];
    const p0 = f0.visor_protocolo.value;
    const protos = [p0, ...PROTOS.map((x) => x[0]).filter((x) => x !== p0)];
    const combos = protos.flatMap((pr) => bauds.map((bd) => ({ pr, bd })));
    let i = 0, enCurso = 0;
    const nombre = (pr) => (PROTOS.find((x) => x[0] === pr) || [0, pr])[1];
    const probar = async () => {
      const c = combos[i], mi = ++enCurso;
      const fmt = f0.visor_formato.value;
      $("#pc-as-info", asist).textContent = "Enviando al visor…";
      try {
        const r = await api("POST", "/api/visor/prueba", { ...ajustesVisor(), baudios: c.bd || f0.visor_baudios.value, protocolo: c.pr, formato: fmt, efecto: "ninguno",
          lineas: ["ABCDEFGHIJKLMNOPQRST", `${c.bd ? c.bd + " " : ""}${nombre(c.pr)}`] });
        if (mi !== enCurso) return;
        reproducir(r); $("#pc-as-info", asist).textContent = "";
      } catch (e) { if (mi === enCurso) $("#pc-as-info", asist).innerHTML = `<span style="color:var(--rojo)">${esc(e.message || "No se pudo escribir en el visor")}</span>`; }
    };
    const pintar = () => {
      const c = combos[i];
      asist.innerHTML = `<div class="fila" style="justify-content:space-between"><b>Ajustar las letras del visor</b><button type="button" class="btn mini" id="pc-as-x">✕ Cerrar</button></div>
        <p style="margin:6px 0">Mire el visor. Debe leerse <b class="mono">ABCDEFGHIJKLMNOPQRST</b> en la primera línea y <b class="mono">${c.bd ? c.bd + " " : ""}${esc(nombre(c.pr))}</b> en la segunda.</p>
        <div class="fila" style="gap:8px;flex-wrap:wrap"><button type="button" class="btn prim" id="pc-as-si">✓ Se lee bien: usar este ajuste</button>
          <button type="button" class="btn" id="pc-as-no">No, probar otro →</button><button type="button" class="btn" id="pc-as-ant" ${i === 0 ? "disabled" : ""}>← Anterior</button>
          <span class="ayuda">Prueba ${i + 1} de ${combos.length}</span></div><div class="ayuda" id="pc-as-info" style="margin-top:6px"></div>`;
      $("#pc-as-x", asist).onclick = () => { enCurso++; asist.classList.add("oculto"); };
      $("#pc-as-no", asist).onclick = () => { i = (i + 1) % combos.length; pintar(); probar(); };
      $("#pc-as-ant", asist).onclick = () => { i = Math.max(0, i - 1); pintar(); probar(); };
      $("#pc-as-si", asist).onclick = () => {
        if (c.bd) f0.visor_baudios.value = String(c.bd);
        f0.visor_protocolo.value = c.pr; guardarGeneral(); enCurso++; asist.classList.add("oculto");
        toast(`Visor ajustado: ${c.bd ? c.bd + " baudios · " : ""}${nombre(c.pr)}`, "ok");
      };
    };
    asist.classList.remove("oculto"); pintar(); probar();
  };
  $("#pc-asistente", el).onclick = abrirAsistente;

  // Todo se guarda solo (sin botón «Guardar»): un instante después de tocar algo
  let tmGen;
  const guardarGeneral = () => {
    clearTimeout(tmGen);
    $("#pc-guardado", el).textContent = "Guardando…";
    tmGen = setTimeout(accion(async () => {
      await api("PUT", "/api/config", { pantalla_cliente_activa: f0.pantalla_cliente_activa.checked ? "1" : "0", pantalla_cliente_modo: f0.pantalla_cliente_modo.value,
        pantalla_cliente_bienvenida: f0.pantalla_cliente_bienvenida.value, pantalla_cliente_gracias: f0.pantalla_cliente_gracias.value,
        visor_efecto: f0.visor_efecto.value, visor_velocidad: f0.visor_velocidad.value, visor_conexion: f0.visor_conexion.value, visor_destino: f0.visor_destino.value, visor_baudios: f0.visor_baudios.value,
        visor_protocolo: f0.visor_protocolo.value, visor_formato: f0.visor_formato.value, visor_columnas: f0.visor_columnas.value, visor_reposo1: f0.visor_reposo1.value, visor_reposo2: f0.visor_reposo2.value });
      if (f0.pantalla_cliente_activa.checked && f0.pantalla_cliente_modo.value !== "monitor")
        fetch("/api/visor", { method: "POST", headers: { "Content-Type": "application/json", "X-Token": S.token }, body: JSON.stringify({ d: { tipo: "libre" } }) }).catch(() => {});
      S.estado = await api("GET", "/api/estado"); pintarBarra();
      avisarPantallaCliente();
      if (!el.isConnected) return;
      const act = f0.pantalla_cliente_activa.checked;
      $("#pc-estado", el).textContent = act ? "Activada" : "Desactivada";
      $("#pc-estado", el).className = "etiqueta " + (act ? "e-pagado" : "e-salido");
      $("#pc-abrir", el).disabled = !act;
      $("#pc-guardado", el).textContent = "Guardado ✓";
      leerVisor();
    }), 600);
  };
  f0.addEventListener("input", guardarGeneral);
  f0.addEventListener("change", guardarGeneral);
  f0.onsubmit = (e) => e.preventDefault();
  $("#pc-abrir", el).onclick = abrirPantallaCliente;

  // ---- 2 · presentación: vista previa al momento y guardado automático
  const leer = () => {
    const d = {};
    PRESENTACION.forEach((k) => { const x = f[k]; if (x) d[k] = x.type === "checkbox" ? (x.checked ? "1" : "0") : x.value; });
    return d;
  };
  const estiloPrevia = (d) => ({ transicion: d.pantalla_cliente_transicion, transicion_ms: Number(d.pantalla_cliente_transicion_ms), segundos: Number(d.pantalla_cliente_segundos),
    aleatorio: d.pantalla_cliente_orden === "aleatorio", ajuste: d.pantalla_cliente_ajuste, rotulo: d.pantalla_cliente_rotulo, tema: d.pantalla_cliente_tema,
    color: d.pantalla_cliente_color, movimiento: d.pantalla_cliente_movimiento === "1", progreso: d.pantalla_cliente_progreso === "1", pie: d.pantalla_cliente_pie === "1" });
  const marcarColor = () => $$(".pc45-color", f).forEach((b) => b.classList.toggle("activo", (f.pantalla_cliente_color.value || "#2f6bff").toLowerCase() === b.dataset.color));
  const verPrevia = () => {
    const d = leer();
    $("#pc45-seg", f).textContent = `${d.pantalla_cliente_segundos} s`;
    marcarColor();
    try { previa.contentWindow.postMessage({ tipo: "previa", estilo: estiloPrevia(d) }, location.origin); } catch (_) { /* aún cargando */ }
  };
  let tm;
  const guardar = () => {
    clearTimeout(tm);
    $("#pc45-guardado", el).textContent = "Guardando…";
    tm = setTimeout(accion(async () => {
      await api("PUT", "/api/config", leer());
      avisarPantallaCliente();
      if ($("#pc45-guardado", el)) $("#pc45-guardado", el).textContent = "Guardado ✓ · ya se ve en el segundo monitor";
    }), 500);
  };
  f.addEventListener("input", () => { verPrevia(); guardar(); });
  f.addEventListener("change", () => { verPrevia(); guardar(); });
  $$(".pc45-color", f).forEach((b) => (b.onclick = () => { f.pantalla_cliente_color.value = b.dataset.color === "#2f6bff" ? "" : b.dataset.color; verPrevia(); guardar(); }));
  previa.addEventListener("load", () => setTimeout(verPrevia, 300));
  verPrevia();
  // escala del iframe (1280×720) al ancho del marco
  const escalar = () => { const m = previa.parentElement; if (m && m.isConnected) previa.style.transform = `scale(${m.clientWidth / 1280})`; };
  escalar(); window.addEventListener("resize", escalar, { passive: true });

  // ---- fotos
  const tras = () => { avisarPantallaCliente(); recargar(); };
  $("#pc-nueva", el).onchange = accion(async (e) => {
    const malas = []; let bien = 0;
    for (const a of [...e.target.files]) {
      try {
        const img = await reducirFoto(a, 1920, 1_200_000);   // se baja la calidad hasta que quepa (el servidor admite 1,5 MB)
        const r = await fetch("/api/publicidad", { method: "POST", headers: { "X-Token": S.token, "Content-Type": "application/octet-stream" }, body: img });
        if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || "No se pudo subir la foto");
        bien++;
      } catch (err) { malas.push(`${a.name}: ${err.message}`); }
    }
    e.target.value = "";
    if (bien) toast(bien === 1 ? "Foto añadida" : `${bien} fotos añadidas`, "ok");
    if (malas.length) toast(`No se pudo añadir: ${malas.join(" · ")}`, "err");
    tras();
  });
  $("#pc44-ej", el).onclick = accion(async () => {
    if ($("#pc44-ej", el).dataset.quitar) { const r = await api("DELETE", "/api/publicidad/ejemplos"); toast(`${r.quitados} foto(s) de ejemplo quitadas`, "ok"); }
    else { const r = await api("POST", "/api/publicidad/ejemplos"); toast(r.anadidos ? `${r.anadidos} foto(s) de ejemplo añadidas` : "Ya estaban", "ok"); }
    tras();
  });
  $$(".pc45-foto", el).forEach((c) => {
    const id = c.dataset.id;
    const ficha = anuncios.find((x) => String(x.id) === id);
    cargarMiniatura(c, ficha);
    const ver = () => verFotoGrande(anuncios.filter((x) => MINIS.has(claveMini(x))), ficha);
    $(".pc45-mini", c).onclick = ver;
    $(".pc45-mini", c).onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); ver(); } };
    const guardarFoto = accion(async () => {
      await api("PUT", `/api/publicidad/${id}`, { titulo: $('[data-campo="titulo"]', c).value, texto: $('[data-campo="texto"]', c).value, activo: !$('[data-campo="oculta"]', c).checked });
      avisarPantallaCliente();
      try { previa.contentWindow.postMessage({ tipo: "previa", estilo: estiloPrevia(leer()) }, location.origin); } catch (_) { /* nada */ }
      $("#pc45-guardado", el).textContent = "Guardado ✓ · ya se ve en el segundo monitor";
    });
    $$('input.ent[data-campo]', c).forEach((i) => (i.onchange = guardarFoto));
    $('[data-campo="oculta"]', c).onchange = async () => { await guardarFoto(); recargar(); };
    $$("[data-mover]", c).forEach((b) => (b.onclick = accion(async () => { await api("POST", `/api/publicidad/${id}/mover`, { sentido: b.dataset.mover }); tras(); })));
    $("[data-quitar]", c).onclick = accion(async () => {
      if (!(await confirmar("Quitar foto", "¿Quitar esta foto de la publicidad?", { boton: "Quitar", peligro: true }))) return;
      await api("DELETE", `/api/publicidad/${id}`); toast("Foto quitada", "ok"); tras();
    });
  });
});

// ===================================================================== Barrera

// Abre la barrera con un relé (de red, USB o el programa del fabricante) al cobrar, al entrar un abonado o con el botón 🚧
const ajBarrera = accion(async (el) => {
  const c = await api("GET", "/api/config");
  const sel = (k, ops, def) => `<select class="ent" name="${k}">${ops.map(([v, n]) => `<option value="${v}" ${(c[k] || def) === v ? "selected" : ""}>${n}</option>`).join("")}</select>`;
  const ev = (c.barrera_eventos || "abonado,salida").split(",");
  el.innerHTML = `<div class="rejilla" style="max-width: 760px; align-items: start;">
    <form class="panel" id="f-barrera">
      <div class="fila" style="justify-content:space-between"><h3>Barrera</h3>
        <span class="etiqueta ${c.barrera_activa === "1" ? "e-pagado" : "e-salido"}">${c.barrera_activa === "1" ? "Activada" : "Desactivada"}</span></div>
      <p class="suave" style="margin:8px 0">Abre la barrera con un <b>relé</b> (de red, USB o el programa del fabricante) al cobrar o al entrar un abonado, y con el botón 🚧 de la barra superior.</p>
      <label class="fila" style="gap:10px;font-weight:600"><input type="checkbox" name="barrera_activa" ${c.barrera_activa === "1" ? "checked" : ""}> Usar barrera</label>
      <div class="rejilla r2" style="margin-top:12px">
        <label class="campo">Conexión${sel("barrera_conexion", [["http", "Relé de red (URL)"], ["tcp", "Relé de red (IP:puerto + bytes)"], ["serie", "Relé USB / puerto serie"], ["programa", "Programa del fabricante"]], "http")}</label>
        <label class="campo"><span id="br-dest-l">Dirección</span><input class="ent mono" name="barrera_destino" value="${esc(c.barrera_destino || "")}" autocomplete="off"></label>
        <label class="campo br-bytes">Bytes para abrir <span class="ayuda">hex, p. ej. A0 01 01 A2</span><input class="ent mono" name="barrera_abrir" value="${esc(c.barrera_abrir || "")}"></label>
        <label class="campo br-cerrar"><span id="br-cerrar-l">Bytes para soltar</span> <span class="ayuda">opcional</span><input class="ent mono" name="barrera_cerrar" value="${esc(c.barrera_cerrar || "")}"></label>
        <label class="campo br-cerrar">Pulso (ms) <span class="ayuda">tiempo entre abrir y soltar</span><input class="ent num" type="number" min="0" max="10000" name="barrera_pulso_ms" value="${esc(c.barrera_pulso_ms || "1000")}"></label>
        <label class="campo br-serie">Velocidad${sel("barrera_baudios", [["9600", "9600"], ["19200", "19200"], ["4800", "4800"], ["115200", "115200"]], "9600")}</label>
      </div>
      <div class="campo" style="margin-top:12px">Abrir automáticamente
        <label class="fila" style="gap:8px;font-weight:500"><input type="checkbox" name="ev" value="salida" ${ev.includes("salida") ? "checked" : ""}> Al dar la salida (al cobrar o pulsar «Registrar salida»)</label>
        <label class="fila" style="gap:8px;font-weight:500"><input type="checkbox" name="ev" value="abonado" ${ev.includes("abonado") ? "checked" : ""}> Al entrar un abonado</label>
        <label class="fila" style="gap:8px;font-weight:500"><input type="checkbox" name="ev" value="entrada" ${ev.includes("entrada") ? "checked" : ""}> Al emitir un ticket de entrada</label></div>
      <p class="ayuda" id="br-ayuda" style="margin:8px 0 0"></p>
      ${c.barrera_ultimo_error ? `<div class="aviso rojo" style="margin-top:10px">Último error: ${esc(c.barrera_ultimo_error)}</div>` : c.barrera_ultimo ? `<p class="suave" style="font-size:.85rem">Última apertura: ${esc(c.barrera_ultimo)}</p>` : ""}
      <div class="fila" style="margin-top:12px"><button class="btn prim">Guardar</button><button type="button" class="btn" id="br-probar">Probar (abrir ahora)</button></div>
    </form></div>`;
  const fb = $("#f-barrera", el);
  const pintar = () => {
    const con = fb.barrera_conexion.value;
    $("#br-dest-l", el).textContent = { http: "URL que abre el relé", tcp: "IP:puerto", serie: "Puerto (p. ej. COM4)", programa: "Programa y parámetros" }[con];
    $$(".br-bytes", el).forEach((x) => x.classList.toggle("oculto", !["tcp", "serie"].includes(con)));
    $$(".br-cerrar", el).forEach((x) => x.classList.toggle("oculto", con === "programa"));
    $("#br-cerrar-l", el).textContent = con === "http" ? "URL para soltar" : "Bytes para soltar";
    $$(".br-serie", el).forEach((x) => x.classList.toggle("oculto", con !== "serie"));
    $("#br-ayuda", el).innerHTML = {
      http: "Ejemplos: Shelly <span class='mono'>http://192.168.1.50/relay/0?turn=on&timer=1</span>. Si el relé necesita otra URL para soltar, póngala en «URL para soltar».",
      tcp: "Relés Ethernet que reciben comandos por socket: indique los bytes que abren y, si hace falta, los que sueltan.",
      serie: "Relés USB (tipo LCUS-1): abrir <span class='mono'>A0 01 01 A2</span>, soltar <span class='mono'>A0 01 00 A1</span>, pulso 1000 ms.",
      programa: "La utilidad de su barrera o controladora de accesos, con sus parámetros.",
    }[con];
  };
  fb.barrera_conexion.onchange = pintar; pintar();
  const guardarB = async () => api("PUT", "/api/config", {
    barrera_activa: fb.barrera_activa.checked ? "1" : "0", barrera_conexion: fb.barrera_conexion.value, barrera_destino: fb.barrera_destino.value.trim(),
    barrera_abrir: fb.barrera_abrir.value.trim(), barrera_cerrar: fb.barrera_cerrar.value.trim(), barrera_pulso_ms: fb.barrera_pulso_ms.value,
    barrera_baudios: fb.barrera_baudios.value, barrera_eventos: $$('[name="ev"]', fb).filter((x) => x.checked).map((x) => x.value).join(",") });
  fb.onsubmit = accion(async (e) => { e.preventDefault(); await guardarB(); toast("Barrera guardada", "ok"); S.estado = await api("GET", "/api/estado"); pintarBarra(); ajBarrera(el); });
  $("#br-probar", el).onclick = accion(async () => {
    await guardarB();
    if (!fb.barrera_activa.checked) throw new Error("Marque «Usar barrera» para probarla");
    const r = await api("POST", "/api/barrera/abrir", { motivo: "prueba desde Ajustes" });
    toast("Barrera: " + (r.resultado || "orden enviada"), "ok");
  });
});

// =========================================================== Semáforo y cartel

const SENALES = [["semaforo", "Semáforo", "Luz verde (libre) o roja (completo) a la entrada."], ["cartel", "Cartel LIBRE / COMPLETO", "Cartel luminoso o pantalla en la calle."]];

const ajSemaforo = accion(async (el) => {
  const [c, st] = await Promise.all([api("GET", "/api/config"), api("GET", "/api/senales")]);
  const zonas = (S.estado && S.estado.zonas) || [];
  const panel = ([p, nombre, desc]) => {
    const g = (k, d = "") => c[`${p}_${k}`] ?? d;
    const e = st[p] || {};
    const con = g("conexion", "http");
    return `<form class="panel senal44" data-p="${p}">
      <div class="fila" style="justify-content:space-between"><h3>${nombre}</h3>
        <span class="fila" style="gap:6px">${e.activo ? `<span class="luz44 ${e.estado_real}" title="Estado ahora"></span><b>${e.estado_real === "completo" ? "COMPLETO" : "LIBRE"}</b>
          ${e.libres != null ? `<span class="suave">(${e.libres} libres)</span>` : ""}` : '<span class="etiqueta e-salido">Desactivado</span>'}</span></div>
      <p class="suave" style="margin:6px 0 10px">${desc} Cambia solo según la ocupación; cada 10 minutos se vuelve a mandar por si se ha reiniciado.</p>
      <label class="fila" style="gap:10px;font-weight:600"><input type="checkbox" name="activo" ${g("activo") === "1" ? "checked" : ""}> Usar ${nombre.toLowerCase()}</label>
      <div class="rejilla r2" style="margin-top:12px">
        <label class="campo">Conexión<select class="ent" name="conexion">${[["http", "Relé o controlador de red (URL)"], ["tcp", "Relé de red (IP:puerto y bytes)"], ["serie", "Relé USB / puerto serie (COM)"], ["programa", "Programa del fabricante"]]
          .map(([v, n]) => `<option value="${v}" ${con === v ? "selected" : ""}>${n}</option>`).join("")}</select></label>
        <label class="campo"><span class="sn-dest">Dirección</span><input class="ent mono" name="destino" value="${esc(g("destino"))}"></label>
        <label class="campo sn-cmd"><span class="sn-libre">Orden para LIBRE</span><input class="ent mono" name="libre" value="${esc(g("libre"))}"></label>
        <label class="campo sn-cmd"><span class="sn-comp">Orden para COMPLETO</span><input class="ent mono" name="completo" value="${esc(g("completo"))}"></label>
        <label class="campo sn-bd">Velocidad (baudios)<select class="ent" name="baudios">${["9600", "19200", "4800", "38400", "115200"].map((b) => `<option ${g("baudios", "9600") === b ? "selected" : ""}>${b}</option>`).join("")}</select></label>
        <label class="campo">Se pone COMPLETO cuando quedan<select class="ent" name="margen">${[0, 1, 2, 3, 5, 10].map((n) => `<option value="${n}" ${String(g("margen", "0")) === String(n) ? "selected" : ""}>${n ? `${n} plaza(s) libre(s) o menos` : "0 plazas libres"}</option>`).join("")}</select></label>
        <label class="campo">Cuenta<select class="ent" name="ambito"><option value="total" ${g("ambito", "total") === "total" ? "selected" : ""}>Todo el parking</option>
          <option value="rotacion" ${g("ambito") === "rotacion" ? "selected" : ""}>Solo plazas de rotación (sin las reservadas a abonados)</option>
          ${zonas.map((z) => `<option value="zona:${z.id}" ${g("ambito") === "zona:" + z.id ? "selected" : ""}>Zona ${esc(z.nombre)}</option>`).join("")}</select></label></div>
      <p class="ayuda sn-ayuda" style="margin:8px 0 0"></p>
      ${e.ultimo ? `<p class="suave" style="font-size:.85rem;margin:8px 0 0">Último envío: ${esc(e.ultimo)}</p>` : ""}
      ${e.error ? `<div class="aviso rojo" style="margin-top:8px">${esc(e.error)}</div>` : ""}
      <div class="fila" style="margin-top:12px"><button class="btn prim">Guardar</button>
        <button type="button" class="btn" data-probar="libre"><span class="luz44 libre"></span> Probar LIBRE</button>
        <button type="button" class="btn" data-probar="completo"><span class="luz44 completo"></span> Probar COMPLETO</button></div></form>`;
  };
  el.innerHTML = `<p class="suave" style="margin:0 0 12px;max-width:1000px">Opcional: el programa sabe cuántas plazas quedan (capacidad en <i>Empresa → Plazas y zonas</i>) y enciende el semáforo o el cartel.
      Se conectan con un relé (como la barrera): de red, USB o el programa del fabricante. Guarde antes de probar.</p>
    <div class="rejilla r2" style="align-items:start;max-width:1250px">${SENALES.map(panel).join("")}</div>`;
  $$(".senal44", el).forEach((f) => {
    const p = f.dataset.p;
    const pintar = () => {
      const con = f.conexion.value;
      $(".sn-dest", f).textContent = { http: "URL base (opcional)", tcp: "IP:puerto", serie: "Puerto (COM3)", programa: "Orden ({estado} = libre o completo)" }[con];
      $(".sn-libre", f).textContent = con === "http" ? "URL para LIBRE" : "Bytes o texto para LIBRE";
      $(".sn-comp", f).textContent = con === "http" ? "URL para COMPLETO" : "Bytes o texto para COMPLETO";
      $$(".sn-cmd", f).forEach((x) => x.classList.toggle("oculto", con === "programa"));
      $(".sn-bd", f).classList.toggle("oculto", con !== "serie");
      $(".sn-ayuda", f).innerHTML = { http: "Ejemplo Shelly: <span class='mono'>http://192.168.1.80/relay/0?turn=on</span> para COMPLETO y <span class='mono'>…turn=off</span> para LIBRE. Si solo pone la URL base, se llama con <span class='mono'>?estado=libre</span> o <span class='mono'>completo</span>.",
        tcp: "Bytes en hexadecimal (<span class='mono'>A0 01 01 A2</span>) o texto. Vacío = se envía LIBRE o COMPLETO.",
        serie: "Relé USB tipo LCUS: <span class='mono'>A0 01 01 A2</span> enciende, <span class='mono'>A0 01 00 A1</span> apaga.",
        programa: "Ejemplo: <span class='mono'>\"C:\\Cartel\\cartel.exe\" {estado}</span>" }[con];
    };
    f.conexion.onchange = pintar; pintar();
    f.onsubmit = accion(async (e) => {
      e.preventDefault();
      const d = {};
      ["conexion", "destino", "libre", "completo", "baudios", "margen", "ambito"].forEach((k) => (d[`${p}_${k}`] = f[k].value.trim()));
      d[`${p}_activo`] = f.activo.checked ? "1" : "0";
      await api("PUT", "/api/config", d);
      toast("Guardado", "ok"); ajSemaforo(el);
    });
    $$("[data-probar]", f).forEach((b) => (b.onclick = accion(async () => {
      const r = await api("POST", `/api/senales/${p}/probar`, { estado: b.dataset.probar });
      toast(`Enviado: ${b.dataset.probar.toUpperCase()} (${r.respuesta})`, "ok");
    })));
  });
});
