"use strict";
const q = new URLSearchParams(location.search);
const codigo = q.get("c") || "", sesion = q.get("s") || "";
const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const eur = (c) => (c / 100).toLocaleString("es-ES", { style: "currency", currency: "EUR" });
const hora = (iso) => new Date(iso).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
const fecha = (iso) => new Date(iso).toLocaleString("es-ES", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
const dur = (m) => (m >= 60 ? `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, "0")} min` : `${m} min`);
async function api(metodo, ruta, cuerpo) {
  const r = await fetch(ruta, { method: metodo, headers: { "Content-Type": "application/json" }, body: cuerpo ? JSON.stringify(cuerpo) : undefined });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || "No disponible");
  return d;
}
function pintar(t, extra = "") {
  $("#nombre").textContent = t.parking || "Parking";
  document.title = `Ticket · ${t.parking || "Parking"}`;
  const qr = `<div class="qr">${t.qr || ""}<span class="cod">${esc(t.codigo)}</span><span style="color:var(--suave);font-size:.85rem">Muestre este código en la salida si se lo piden</span></div>`;
  let cuerpo;
  if (t.pagado || t.mensaje) {
    cuerpo = `<div class="aviso ${t.pagado ? "ok" : "info"}" style="font-weight:700;text-align:center">${esc(t.mensaje || "Pagado")}</div>`;
  } else {
    cuerpo = `<div class="importe"><div class="t">A pagar ahora</div><div class="v">${eur(t.pendiente_cent)}</div></div>
      ${t.puede_pagar ? `<button class="btn" id="pagar">Pagar con tarjeta</button>
        <p style="color:var(--suave);font-size:.88rem;text-align:center;margin:10px 0 0">Después tendrá ${t.minutos_salida} minutos para salir.</p>`
        : '<div class="aviso info">Pague en la caja del parking.</div>'}`;
  }
  $("#contenido").innerHTML = `${extra}<dl>${t.matricula ? `<dt>Matrícula</dt><dd>${esc(t.matricula)}</dd>` : ""}
      <dt>Entrada</dt><dd>${fecha(t.entrada)}</dd>${t.minutos != null ? `<dt>Tiempo</dt><dd>${dur(t.minutos)}</dd>` : ""}
      ${t.reserva_hasta ? `<dt>Reserva hasta</dt><dd>${fecha(t.reserva_hasta)}</dd>` : ""}</dl>${cuerpo}${qr}`;
  const b = $("#pagar");
  if (b) b.onclick = async () => {
    b.disabled = true; b.textContent = "Abriendo el pago seguro…";
    try { const r = await api("POST", "/api/publico/pagar", { c: codigo }); location.href = r.url; }
    catch (e) { b.disabled = false; b.textContent = "Pagar con tarjeta"; alertar(e.message); }
  };
}
function alertar(m) { const d = document.createElement("div"); d.className = "aviso err"; d.textContent = m; $("#contenido").prepend(d); }
async function cargar(extra) {
  try { pintar(await api("GET", "/api/publico/ticket?c=" + encodeURIComponent(codigo)), extra); }
  catch (e) { $("#contenido").innerHTML = `<div class="aviso err">${esc(e.message === "No disponible" ? "Este servicio no está disponible." : e.message)}</div>`; }
}
async function confirmar(intento = 0) {
  try {
    const r = await api("POST", "/api/publico/confirmar", { s: sesion });
    if (r.estado === "pagado") return cargar(`<div class="aviso ok" style="font-weight:700;text-align:center">¡Pago recibido! Puede salir hasta las ${r.salida_limite ? hora(r.salida_limite) : "—"}.</div>`);
    if (r.estado === "pendiente" && intento < 8) return setTimeout(() => confirmar(intento + 1), 1500);
    cargar(r.estado === "error" ? '<div class="aviso err">Hubo un problema con el pago: diríjase a la caja.</div>' : "");
  } catch (e) { cargar(`<div class="aviso err">${esc(e.message)}</div>`); }
}
if (!codigo) $("#contenido").innerHTML = '<div class="aviso err">Escanee el código del ticket.</div>';
else if (sesion) confirmar();
else cargar();
