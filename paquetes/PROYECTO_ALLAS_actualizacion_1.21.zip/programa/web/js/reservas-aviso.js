/* PROYECTO ALLAS 1.11 · avisos de reservas: vehículo que llega con reserva, código QR de la reserva y reservas nuevas de clientes */
"use strict";

// Código de reserva que recibe el cliente (R-XXXXXX, sin 0/O/1/I). También es el texto del QR.
const PATRON_RESERVA = /^R-[A-HJ-NP-Z2-9]{6}$/i;
const esCodigoReserva = (t) => PATRON_RESERVA.test(String(t || "").trim());

S.avisosReserva = { vistas: new Set(), decidida: null, comprobando: false };

const ORIGEN_RESERVA = { web: "Reserva de cliente (web)", mostrador: "Reserva de mostrador" };
const nombreOrigenReserva = (r) => ORIGEN_RESERVA[r.origen] || `Reserva ${[r.plataforma, r.ref].filter(Boolean).join(" · ") || "de plataforma"}`;

// Busca la reserva de una matrícula o de un código R-XXXXXX. Si falla (sin permiso, sin módulo…), se sigue como siempre.
async function consultarAvisoReserva(texto) {
  try { return await api("GET", "/api/reservas-online/aviso?q=" + encodeURIComponent(String(texto || "").trim())); }
  catch (_) { return { reserva: null }; }
}

async function cancelarReservaApi(r) {
  const online = r.origen === "web" || r.origen === "mostrador";
  await api("DELETE", online ? `/api/reservas-online/${r.id}` : `/api/reservas-previstas/${r.id}`);
}

// Botón de cancelar con doble pulsación (no hay ventana sobre la ventana): la primera pide confirmar, la segunda cancela.
function botonCancelarDoble(b, hacer) {
  let listo = false;
  b.onclick = accion(async () => {
    if (!listo) {
      listo = true; b.textContent = "Pulse otra vez para cancelar"; b.classList.add("lleno");
      setTimeout(() => { if (b.isConnected) { listo = false; b.textContent = b.dataset.texto; b.classList.remove("lleno"); } }, 5000);
      return;
    }
    await hacer();
  });
}

function filasReserva(r) {
  const plazas = Number(r.plazas) || 1;
  return `<dl class="datos-ticket">
    <dt>Matrícula</dt><dd><b class="mono">${esc(r.matricula)}</b></dd>
    <dt>Reserva</dt><dd>${esc(nombreOrigenReserva(r))}${r.codigo ? ` · <span class="mono">${esc(r.codigo)}</span>` : ""}</dd>
    ${r.cliente ? `<dt>Cliente</dt><dd>${esc(r.cliente)}</dd>` : ""}
    <dt>Fechas</dt><dd>${fechaHora(r.desde)} → ${fechaHora(r.hasta)}</dd>
    ${r.zona_nombre ? `<dt>Zona</dt><dd>${esc(r.zona_nombre)}${plazas > 1 ? ` · ${plazas} plazas` : ""}</dd>` : ""}
    ${r.importe_cent ? `<dt>Precio estimado</dt><dd>${eur(r.importe_cent)} <span class="suave">${r.senal_cent && r.origen !== "plataforma" ? "en total" : "a pagar en el parking"}</span></dd>` : ""}
    ${r.senal_cent && r.origen !== "plataforma" ? `<dt>Señal</dt><dd>${etiquetaPagoReserva(r) || eur(r.senal_cent)}</dd>` : ""}
  </dl>`;
}

// Ventana «Este vehículo tiene una reserva». opciones:
//   entrar(): se pulsa «Confirmar entrada» (aplica la reserva y sigue con la entrada)
//   sinReserva(): «Entrar sin usar la reserva» (solo si llega antes de hora)
//   cancelada(): se canceló la reserva desde la ventana
function modalReservaVehiculo(av, { entrar = null, sinReserva = null, cancelada = null } = {}) {
  const r = av.reserva, puede = permitido("reservas");
  const mensajes = {
    ok: r.origen === "web" || r.origen === "mostrador"
      ? `Confirme la entrada para unirla a esta reserva: se le guarda la plaza${r.zona_nombre ? ` en <b>${esc(r.zona_nombre)}</b>` : ""} y se cobra la tarifa normal al salir.`
      : (r.tarifa_id ? `Confirme la entrada: el tiempo reservado no se cobra (hasta el ${fechaHora(r.hasta)}).` : "Confirme la entrada para aplicarle esta reserva."),
    antes: `Todavía no es la hora: la reserva empieza el ${fechaHora(r.desde)} y se admite la llegada desde las ${hora(av.ventana_desde)}. Si entra ahora, el ticket <b>no</b> usará la reserva.`,
    caducada: `La reserva terminó el ${fechaHora(r.hasta)}.`,
    usada: `Esta reserva ya se usó${r.ticket_codigo ? ` con el ticket <span class="mono">${esc(r.ticket_codigo)}</span>` : ""}.`,
    cancelada: "Esta reserva está cancelada.",
  };
  const aplica = av.aplica && !!entrar, antes = av.motivo === "antes" && !!sinReserva;
  const pendiente = r.estado === "pendiente";
  const sinCobrar = pendiente && r.pago === "pendiente_pago";
  const notaPago = sinCobrar ? `<br><b>La señal de ${eur(r.senal_cent)} está sin cobrar</b>${r.pago_limite ? ` (la reserva se cancela sola el ${fechaHora(r.pago_limite)})` : ""}: cóbrela ahora o deje que caduque.`
    : pendiente && r.pago === "pagada" ? `<br>La señal de <b>${eur(r.senal_cent)}</b> ya está pagada: descuéntela al cobrar la salida.` : "";
  const m = modal(`<h2 class="titulo-icono">${icono("calendario", 24)}${aplica ? "Este vehículo tiene una reserva" : pendiente ? "Reserva encontrada" : "Reserva " + esc(r.estado)}</h2>
    ${filasReserva(r)}
    <div class="aviso ${aplica && !sinCobrar ? "verde" : ""}" style="margin-top:12px">${mensajes[av.motivo] || ""}${notaPago}</div>
    <div class="modal-pie">
      <button class="btn" data-c>${aplica || antes ? "Ahora no" : "Cerrar"}</button>
      ${pendiente && puede ? `<button class="btn peligro" data-cancelar data-texto="Cancelar reserva">Cancelar reserva</button>` : ""}
      ${sinCobrar && puede ? `<button class="btn" data-senal>Señal cobrada</button>` : ""}
      ${antes ? `<button class="btn" data-sin>Entrar sin la reserva</button>` : ""}
      ${r.ticket_codigo && av.motivo === "usada" ? `<button class="btn prim" data-ticket>Abrir el ticket</button>` : ""}
      ${aplica ? `<button class="btn prim" data-ok autofocus>Confirmar entrada</button>` : ""}
    </div>`);
  $("[data-c]", m).onclick = cerrarModal;
  if ($("[data-senal]", m)) $("[data-senal]", m).onclick = () => modalSenalCobrada(r, async () => {
    const nuevo = await consultarAvisoReserva(r.codigo || r.matricula);
    if (nuevo.reserva) modalReservaVehiculo(nuevo, { entrar, sinReserva, cancelada });
  }, () => modalReservaVehiculo(av, { entrar, sinReserva, cancelada }));
  if ($("[data-sin]", m)) $("[data-sin]", m).onclick = () => { cerrarModal(); sinReserva(); };
  if ($("[data-ok]", m)) $("[data-ok]", m).onclick = () => { cerrarModal(); entrar(); };
  if ($("[data-ticket]", m)) $("[data-ticket]", m).onclick = () => { cerrarModal(); buscarTicket(r.ticket_codigo); };
  if ($("[data-cancelar]", m)) botonCancelarDoble($("[data-cancelar]", m), async () => {
    await cancelarReservaApi(r);
    cerrarModal(); toast("Reserva cancelada", "ok");
    if (S.vista === "reservas") pintarVista();
    refrescarEstado();
    if (cancelada) cancelada();
  });
  return m;
}

// Entrada: antes de emitir el ticket se comprueba si la matrícula tiene reserva. Devuelve true si hay que parar y esperar
// la decisión del personal en la ventana (que vuelve a enviar el formulario al confirmar).
function ventanaReservaEntrada(av, mat, form) {
  const decidir = (usar) => { S.avisosReserva.decidida = { mat, usar }; };
  modalReservaVehiculo(av, {
    entrar: () => { decidir(true); form.requestSubmit(); },
    sinReserva: () => { decidir(false); form.requestSubmit(); },
    cancelada: () => { decidir(false); const b = $("#e-prevista"); if (b) b.innerHTML = ""; const i = $("#e-mat"); if (i) i.focus(); },
  });
}

async function avisarReservaEnEntrada(matricula, form) {
  const mat = normMat(matricula);
  if (!mat || mat.length < 3 || (S.avisosReserva.decidida || {}).mat === mat) return false;
  const av = await consultarAvisoReserva(mat);
  if (!av.reserva || av.reserva.estado !== "pendiente") return false;
  ventanaReservaEntrada(av, mat, form);
  return true;
}

// 1.12: en cuanto se detecta la matrícula de una reserva (escrita o leída por la cámara) se avisa, sin esperar a emitir el ticket
function avisoPorDeteccion(av, mat) {
  const s = S.avisosReserva, form = $("#f-entrada");
  if (!form || !av.reserva || av.reserva.estado !== "pendiente" || !av.aplica) return;
  if (s.avisada === mat || (s.decidida || {}).mat === mat || !$("#modal").classList.contains("oculto")) return;
  s.avisada = mat;
  ventanaReservaEntrada(av, mat, form);
}

// Panel de Entrada con las reservas que llegan hoy: un clic abre su aviso
async function cargarLlegadas() {
  const caja = $("#e-llegadas");
  if (!caja) return;
  let lista = [];
  try { lista = await api("GET", "/api/reservas-online/llegadas"); } catch (_) { /* sin módulo o sin permiso: no se enseña */ }
  if (!caja.isConnected) return;
  caja.hidden = !lista.length;
  if (!lista.length) return;
  caja.innerHTML = `<div class="fila" style="justify-content:space-between"><h3>Reservas que llegan hoy</h3><span class="etiqueta e-aviso">${lista.length}</span></div>
    <div class="llegadas">${lista.map((r) => `<button type="button" class="llegada ${r.aplica ? "ahora" : ""}" data-mat="${esc(r.matricula)}">
      <span class="placa-mini">${esc(r.matricula)}</span><span class="llegada-info"><b>${hora(r.desde)}</b>${r.zona_nombre ? " · " + esc(r.zona_nombre) : ""}${r.cliente ? " · " + esc(r.cliente) : ""}
      <small>${esc(nombreOrigenReserva(r))}${r.codigo ? " · " + esc(r.codigo) : ""}${r.pago === "pendiente_pago" ? " · señal sin cobrar" : ""}</small></span>
      <span class="etiqueta ${r.aplica ? "e-pagado" : "e-salido"}">${r.aplica ? "Ya puede entrar" : "Más tarde"}</span></button>`).join("")}</div>`;
  $$("[data-mat]", caja).forEach((b) => (b.onclick = async () => {
    const i = $("#e-mat"); if (!i) return;
    i.value = b.dataset.mat; i.dispatchEvent(new Event("input", { bubbles: true }));
    S.avisosReserva.avisada = null;
    const av = await consultarAvisoReserva(b.dataset.mat);
    if (av.reserva) ventanaReservaEntrada(av, normMat(b.dataset.mat), $("#f-entrada"));
  }));
  if (!caja.dataset.reloj) { caja.dataset.reloj = "1"; const t = setInterval(() => (document.body.contains(caja) ? cargarLlegadas() : clearInterval(t)), 60000); }
}

// Lectura de un código de reserva (QR del cliente) con el lector, escrito a mano o desde la cámara del móvil
const leerCodigoReserva = accion(async (codigo) => {
  codigo = String(codigo || "").trim().toUpperCase();
  const av = await api("GET", "/api/reservas-online/aviso?q=" + encodeURIComponent(codigo));
  if (!av.reserva) return toast(`No existe ninguna reserva con el código ${codigo}`, "err");
  modalReservaVehiculo(av, { entrar: () => entrarConReserva(av.reserva) });
});

// Pasa a Entrada con la matrícula de la reserva y emite el ticket (el personal ya ha confirmado en la ventana)
function entrarConReserva(r) {
  S.avisosReserva.decidida = { mat: normMat(r.matricula), usar: true };
  S.entrada.prefill = { matricula: r.matricula };
  if (S.vista === "entrada") vistaEntrada($("#vista")); else ir("entrada");
}

// ====================================================== reservas nuevas de clientes
function pitidoAviso() {
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    const a = new Ctx(), o = a.createOscillator(), g = a.createGain();
    o.type = "sine"; o.frequency.value = 880; g.gain.value = 0.06;
    o.connect(g); g.connect(a.destination);
    o.start(); o.stop(a.currentTime + 0.18);
    setTimeout(() => a.close().catch(() => {}), 400);
  } catch (_) { /* el navegador puede bloquear el sonido hasta la primera pulsación */ }
}

function pintarInsigniaReservas() {
  const b = document.querySelector('nav.menu button[data-vista="reservas"]');
  if (!b) return;
  const n = (S.estado && S.estado.reservas_nuevas) || 0;
  let i = b.querySelector(".insignia");
  if (!n) { if (i) i.remove(); return; }
  if (!i) { i = document.createElement("b"); i.className = "insignia"; i.setAttribute("aria-label", "reservas nuevas sin revisar"); b.insertBefore(i, b.querySelector("kbd")); }
  i.textContent = n > 9 ? "9+" : String(n);
}

// Cada vez que se actualiza el estado: si hay reservas de clientes sin revisar que aún no se han enseñado, aviso con ventana.
async function comprobarReservasNuevas() {
  pintarInsigniaReservas();
  const e = S.estado, av = S.avisosReserva;
  if (!e || !e.reservas_nuevas || av.comprobando || !$("#modal").classList.contains("oculto")) return;
  av.comprobando = true;
  try {
    const lista = (await api("GET", "/api/reservas-online/por-revisar")).filter((r) => !av.vistas.has(r.id));
    if (lista.length) { lista.forEach((r) => av.vistas.add(r.id)); pitidoAviso(); modalReservasNuevas(lista.map((r) => r.id)); }
  } catch (_) { /* sin permiso o sin conexión: se intentará en la próxima actualización */ }
  finally { av.comprobando = false; }
}

async function modalReservasNuevas(ids) {
  let todas;
  try { todas = await api("GET", "/api/reservas-online/por-revisar"); } catch (_) { return; }
  const lista = todas.filter((r) => ids.includes(r.id));
  const puede = permitido("reservas");
  if (!lista.length) { cerrarModal(); return refrescarEstado(); }
  const m = modal(`<h2 class="titulo-icono">${icono("calendario", 24)}${lista.length === 1 ? "Nueva reserva de un cliente" : `${lista.length} reservas nuevas de clientes`}</h2>
    <p class="suave" style="margin-top:0">Ya tienen la plaza guardada y han recibido su código. Confirme que las ha visto o cancele las que no pueda atender.</p>
    <div class="res-nuevas">${lista.map((r) => `<div class="res-nueva" data-r="${r.id}">${filasReserva(r)}
      ${puede ? `<div class="fila" style="justify-content:flex-end;gap:8px"><button class="btn peligro" data-cancelar="${r.id}" data-texto="Cancelar reserva">Cancelar reserva</button>
        ${r.pago === "pendiente_pago" ? `<button class="btn" data-senal="${r.id}">Señal cobrada</button>` : ""}
        <button class="btn prim" data-confirmar="${r.id}" autofocus>Confirmar</button></div>` : ""}</div>`).join("")}</div>
    <div class="modal-pie"><button class="btn" data-c>Más tarde</button><button class="btn" data-ver>Ver reservas</button></div>`, { ancho: true });
  $("[data-c]", m).onclick = cerrarModal;
  $("[data-ver]", m).onclick = () => { cerrarModal(); ir("reservas"); };
  $$("[data-senal]", m).forEach((b) => (b.onclick = () => modalSenalCobrada(lista.find((r) => r.id === Number(b.dataset.senal)), () => modalReservasNuevas(ids), () => modalReservasNuevas(ids))));
  $$("[data-confirmar]", m).forEach((b) => (b.onclick = accion(async () => {
    await api("POST", `/api/reservas-online/${b.dataset.confirmar}/confirmar`, {});
    toast("Reserva confirmada", "ok"); await refrescarEstado(); modalReservasNuevas(ids.filter((x) => x !== Number(b.dataset.confirmar)));
  })));
  $$("[data-cancelar]", m).forEach((b) => botonCancelarDoble(b, async () => {
    await cancelarReservaApi(lista.find((r) => r.id === Number(b.dataset.cancelar)));
    toast("Reserva cancelada", "ok"); await refrescarEstado(); modalReservasNuevas(ids.filter((x) => x !== Number(b.dataset.cancelar)));
  }));
}

// Aviso en Salida y en la ficha de un ticket: el vehículo entró con reserva, o tiene una pendiente que no se aplicó
function htmlAvisoReservaTicket(t) {
  const r = t && t.reserva_info, p = t && t.reserva_pendiente;
  if (r) return `<div class="aviso verde" style="margin-bottom:10px">${icono("calendario")} <b>Entró con una reserva</b> · ${esc(nombreOrigenReserva(r))}${r.codigo ? ` <span class="mono">${esc(r.codigo)}</span>` : ""}
    <div class="suave" style="font-size:.85rem">${r.zona_nombre ? esc(r.zona_nombre) + " · " : ""}${fechaHora(r.desde)} → ${fechaHora(r.hasta)}${r.origen === "web" || r.origen === "mostrador" ? " · se cobra la tarifa normal" : ""}</div>
    ${r.pago === "pagada" && r.senal_cent ? (r.senal_pago_id ? `<div><b>Señal pagada: ${eur(r.senal_cent)}</b> · ya descontada del importe a cobrar</div>${t.liquidacion && t.liquidacion.a_favor_cent ? `<div class="suave"><b>Pagó ${eur(t.liquidacion.a_favor_cent)} más de lo que debe</b>: esa diferencia no se devuelve sola.</div>` : ""}` : `<div><b>Señal ya pagada: ${eur(r.senal_cent)}</b> · descuéntela del importe a cobrar</div>`) : r.pago === "pendiente_pago" && r.senal_cent ? `<div><b>Señal de ${eur(r.senal_cent)} sin cobrar</b></div>` : ""}</div>`;
  if (p) return `<div class="aviso" style="margin-bottom:10px">${icono("calendario")} <b>Tiene una reserva ${p.motivo === "antes" ? "para más tarde" : "pendiente"}</b> · ${esc(nombreOrigenReserva(p))}${p.codigo ? ` <span class="mono">${esc(p.codigo)}</span>` : ""}
    <div class="suave" style="font-size:.85rem">${fechaHora(p.desde)} → ${fechaHora(p.hasta)}. Este ticket no la usa.</div></div>`;
  return "";
}
