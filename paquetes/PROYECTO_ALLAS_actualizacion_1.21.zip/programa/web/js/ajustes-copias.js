/* PROYECTO ALLAS · Ajustes → Sistema → Copias de seguridad */
"use strict";

// ========================================================= Copias de seguridad

const TIPOS_COPIA = {
  arranque: "Al arrancar", automatica: "Automática", cierre_turno: "Cierre de turno", manual: "Manual", parcial: "Manual parcial",
  antes_de_restaurar: "Antes de restaurar", antes_de_restablecer: "Antes de borrar todo", restablecimiento: "Borrado total", antes_de_actualizar: "Antes de actualizar", antes_de_importar: "Antes de importar tarifas", subida: "Subida", restauracion: "Restauración", eliminacion: "Eliminación",
};

// Pantalla simplificada: un resumen con dos botones, la programación en una ventana
// Aparte, un único botón «Opciones…» por copia y el borrado total plegado al final.
const COPIAS_VISIBLES = 6;

const NOMBRE_GRUPO = { configuracion: "Configuración", clientes: "Clientes y bonos", movimientos: "Tickets y cobros", auditoria: "Auditoría" };

// Ajustes → Sistema → Copias de seguridad: copias (hechas, programadas, restaurar), copia en el NAS y copia cifrada en la nube
const ajCopias = accion(async (el) => {
  const admin = tieneRol("admin");
  const [d, c, nube] = await Promise.all([api("GET", "/api/backups"), admin ? api("GET", "/api/config") : null, admin ? api("GET", "/api/nube/estado") : null]);
  if (!el.isConnected) return;
  el.innerHTML = `<div class="copias-y-datos"><div id="cd-copias"></div>${admin ? htmlCopiaNas(c) + htmlCopiaNube(c, nube) : ""}</div>`;
  montarCopias($("#cd-copias", el), d, admin, el);
  if (admin) { montarCopiaNas(el); montarCopiaNube(el); }
});

function montarCopias(el, d, admin, tab) {
  const u = d.ultima, uok = d.ultima_ok, pr = d.programa || {};
  const viejo = uok && (Date.now() - new Date(uok.fecha).getTime()) > 24 * 3600 * 1000;
  let estado;
  if (!u) estado = `<div class="aviso rojo">Aún no se ha hecho ninguna copia de seguridad.</div>`;
  else if (!u.ok) estado = `<div class="aviso rojo"><b>La última copia FALLÓ</b> (${fechaHora(u.fecha)}): ${esc(u.error || "")}</div>`;
  else if (viejo) estado = `<div class="aviso">La última copia correcta es de ${haceCuanto(uok.fecha)}. Haga una ahora.</div>`;
  else estado = "";
  const extraTxt = u && u.extra ? (u.extra === "ok" ? " · también en la carpeta adicional"
    : ` · <span style="color:var(--rojo)" title="${esc(u.extra)}">carpeta adicional: error</span>`) : "";
  const auto = pr.backup_auto_modo === "no" ? "<b>desactivadas</b>"
    : `<b>${esc(textoPrograma(pr))}</b>${pr.proxima ? ` · próxima ${fechaHora(pr.proxima)}` : ""}`;
  const fila = (c, i) => `<tr class="${i >= COPIAS_VISIBLES ? "oculto mas-copias" : ""}">
      <td class="num">${fechaHora(c.fecha)}<div class="suave" style="font-size:.8rem">${haceCuanto(c.fecha)}</div></td>
      <td><span class="etiqueta ${c.tipo === "antes_de_restaurar" ? "e-aviso" : c.tipo === "parcial" ? "e-dentro" : "e-salido"}">${esc(TIPOS_COPIA[c.tipo] || c.tipo)}</span>
        ${c.contenido && c.contenido.length < 4 ? `<div class="suave" style="font-size:.8rem;margin-top:3px">${c.contenido.map((g) => NOMBRE_GRUPO[g] || g).join(", ")}</div>` : ""}</td>
      <td class="der num">${tamano(c.tamano)}</td>
      <td class="der"><button class="btn mini" data-op="${esc(c.archivo)}">Opciones…</button></td></tr>`;

  el.innerHTML = `
  <div class="panel copias-resumen">
    <div class="fila" style="justify-content:space-between"><h3>Copias de seguridad</h3>
      ${u && u.ok && !viejo ? '<span class="etiqueta e-pagado">Al día</span>' : ""}</div>
    ${u ? `<div class="ultima-copia">
        <div class="icono-copia ${u.ok ? "ok" : "mal"}">${u.ok ? "✓" : "!"}</div>
        <div><div class="grande-copia">Última: ${haceCuanto(u.fecha)}</div>
          <div class="suave">${fechaHora(u.fecha)} · ${esc(TIPOS_COPIA[u.tipo] || u.tipo)}${u.usuario ? " · " + esc(u.usuario) : ""} · ${tamano(u.tamano)}${extraTxt}</div></div></div>` : ""}
    ${estado}
    <p style="margin:10px 0 14px">Automáticas: ${auto}. Además, siempre al arrancar y al cerrar cada turno.</p>
    <div class="fila">
      <button class="btn prim" id="b-backup">Hacer copia ahora</button>
      ${admin ? `<button class="btn" id="b-programar">Programar copias…</button>` : ""}
    </div>
  </div>

  <div class="panel" style="margin-top:16px">
    <div class="fila" style="justify-content:space-between"><h3>Copias guardadas <span class="suave" style="font-weight:400">(${d.copias.length})</span></h3>
      ${admin ? `<label class="btn">Subir una copia (.db)…<input type="file" id="b-subir" accept=".db" hidden></label>` : ""}</div>
    ${d.copias.length ? `<div style="overflow-x:auto;margin-top:8px"><table class="tabla"><thead><tr><th>Fecha</th><th>Tipo</th><th class="der">Tamaño</th><th></th></tr></thead><tbody>
      ${d.copias.map(fila).join("")}</tbody></table></div>
      ${d.copias.length > COPIAS_VISIBLES ? `<button class="enlace-btn" id="b-mas-copias" style="margin-top:8px">Ver las ${d.copias.length} copias</button>` : ""}`
      : '<div class="vacio">No hay copias todavía.</div>'}
    <p class="ayuda" style="margin:10px 0 0">Carpeta: <span class="mono">${esc(d.carpeta)}</span></p>
  </div>

  <details class="panel plegable" style="margin-top:16px"><summary><h3>Registro de copias</h3><span class="suave">${d.registro.length} operación(es)</span></summary>
    ${d.registro.length ? `<div style="overflow-x:auto;margin-top:8px"><table class="tabla"><thead><tr><th>Fecha</th><th>Operación</th><th>Resultado</th><th>Usuario</th><th>Detalle</th></tr></thead><tbody>
      ${d.registro.map((r) => `<tr><td class="num">${fechaHora(r.fecha)}</td><td>${esc(TIPOS_COPIA[r.tipo] || r.tipo)}</td>
        <td>${r.ok ? '<span class="etiqueta e-pagado">Correcta</span>' : '<span class="etiqueta e-err">Error</span>'}</td>
        <td>${esc(r.usuario || "—")}</td>
        <td style="font-size:.85rem"><span class="mono">${esc(r.archivo || "")}</span>${r.tamano ? " · " + tamano(r.tamano) : ""}${r.segundos != null ? ` · ${r.segundos} s` : ""}
          ${r.copia_previa ? `<div class="suave">Copia previa: <span class="mono">${esc(r.copia_previa)}</span></div>` : ""}
          ${r.extra && r.extra !== "ok" ? `<div style="color:var(--rojo)">Carpeta adicional: ${esc(r.extra)}</div>` : ""}
          ${r.error ? `<div style="color:var(--rojo)">${esc(r.error)}</div>` : ""}</td></tr>`).join("")}
      </tbody></table></div>` : '<div class="vacio">Sin registros.</div>'}
  </details>
  ${admin ? `<details class="panel plegable" id="pleg-peligro" style="margin-top:16px"><summary><h3 style="color:var(--rojo)">Borrar todos los datos</h3>
    <span class="suave">dejar el programa como recién instalado</span></summary><div id="sitio-peligro"></div></details>` : ""}`;

  $("#b-backup").onclick = () => modalCopiaManual(() => ajCopias(tab));   // pregunta qué guardar
  if ($("#b-programar")) $("#b-programar").onclick = () => modalProgramacion(pr, () => ajCopias(tab));
  if ($("#b-mas-copias")) $("#b-mas-copias").onclick = (e) => { $$(".mas-copias", el).forEach((t) => t.classList.remove("oculto")); e.target.remove(); };
  if ($("#b-subir")) $("#b-subir").onchange = accion(async (e) => {
    const f = e.target.files[0]; if (!f) return;
    const r = await fetch("/api/backups/subir", { method: "POST", headers: { "X-Token": S.token, "Content-Type": "application/octet-stream" }, body: f });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || "No se pudo subir");
    toast(`Copia subida (${j.tickets} tickets, ${j.pagos} cobros). Ya puede restaurarla.`, "ok");
    ajCopias(tab);
  });
  $$("[data-op]", el).forEach((b) => (b.onclick = () => modalOpcionesCopia(d.copias.find((c) => c.archivo === b.dataset.op), d.copias.length, admin, tab)));
  if (admin) montarZonaPeligro($("#sitio-peligro", el));
}

// Una sola ventana por copia con lo que se puede hacer con ella.
function modalOpcionesCopia(c, total, admin, el) {
  const m = modal(`<h2>Copia de seguridad</h2>
    <p class="mono" style="margin:4px 0">${esc(c.archivo)}</p>
    <p class="suave">${fechaHora(c.fecha)} · ${esc(TIPOS_COPIA[c.tipo] || c.tipo)} · ${tamano(c.tamano)}</p>
    <div class="opciones-copia">
      <a class="btn" href="/api/backups/${encodeURIComponent(c.archivo)}/descargar?token=${encodeURIComponent(S.token)}" style="text-decoration:none">Descargar<span>Guardar el archivo .db en este equipo o en un pendrive</span></a>
      ${admin ? `<button class="btn" data-rest>Restaurar…<span>Volver a los datos de esta copia (antes se guarda el estado actual)</span></button>
      <button class="btn peligro" data-del>Eliminar<span>Borrar este archivo de copia</span></button>` : ""}
    </div>
    <div class="modal-pie"><button class="btn" data-c>Cerrar</button></div>`);
  $("[data-c]", m).onclick = cerrarModal;
  if (!admin) return;
  $("[data-rest]", m).onclick = () => { cerrarModal(); modalRestaurar(c.archivo, el); };
  $("[data-del]", m).onclick = accion(async () => {
    cerrarModal();
    const quedan = total - 1;
    const aviso = quedan === 0
      ? "<div class='aviso rojo'><b>Es la única copia que queda.</b> Si la elimina no tendrá ninguna copia de seguridad hasta la próxima.</div>"
      : `<p class="suave">Quedarán ${quedan} copia(s).</p>`;
    if (!(await confirmar("¿Eliminar esta copia?", `<span class="mono">${esc(c.archivo)}</span><br>No se puede deshacer.${aviso}`,
      { boton: "Eliminar", peligro: true }))) return;
    await api("POST", `/api/backups/${encodeURIComponent(c.archivo)}/eliminar`);
    toast("Copia eliminada", "ok");
    ajCopias(el);
  });
}

const modalRestaurar = accion(async (archivo, el) => {
  const info = await api("GET", `/api/backups/${encodeURIComponent(archivo)}/info`);
  const m = modal(`<h2>Restaurar copia de seguridad</h2>
    <p class="mono">${esc(archivo)}</p>
    <div class="rejilla r4" style="margin:12px 0">
      <div class="panel kpi"><div class="t">Tickets</div><div class="v num">${info.tickets}</div></div>
      <div class="panel kpi"><div class="t">Cobros</div><div class="v num">${info.pagos}</div></div>
      <div class="panel kpi"><div class="t">Clientes</div><div class="v num">${info.clientes}</div></div>
      <div class="panel kpi"><div class="t">Usuarios</div><div class="v num">${info.usuarios}</div></div></div>
    ${info.parcial ? `<div class="aviso">Copia <b>parcial</b>: contiene ${info.grupos.map((g) => `<b>${esc(g.nombre)}</b>`).join(", ")}${info.logo ? " (con el logo)" : ""}.<br>
        Al restaurarla se <b>añaden o actualizan</b> solo esos datos; el resto de datos actuales no se toca.
        Antes se guardará automáticamente una copia del estado actual, para poder deshacerlo.</div>`
      : `<p class="suave">Último cobro en la copia: <b>${info.ultimo_cobro ? fechaHora(info.ultimo_cobro) : "ninguno"}</b></p>
    <div class="aviso rojo">Se sustituirán <b>todos los datos actuales</b> por los de esta copia. Los cobros posteriores a la copia desaparecerán.
      Antes se guardará automáticamente una copia del estado actual, para poder deshacerlo.</div>`}
    <label class="campo" style="margin-top:14px">Confirme con su PIN<input class="ent" id="rs-pin" type="password" inputmode="numeric" autofocus></label>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn peligro lleno" data-ok>Restaurar esta copia</button></div>`, { ancho: true });
  $("[data-c]", m).onclick = cerrarModal;
  const hacer = accion(async () => {
    const r = await api("POST", "/api/backups/restaurar", { archivo, pin: $("#rs-pin").value });
    const ok = modal(`<div class="exito"><div class="icono">✓</div><h2>Copia restaurada</h2>
      <p>${r.parcial ? `Se han restaurado ${r.grupos.map((g) => esc(g.nombre)).join(", ")} de <span class="mono">${esc(r.restaurada)}</span>.` : `Datos de <span class="mono">${esc(r.restaurada)}</span>: ${r.tickets} tickets, ${r.pagos} cobros.`}</p>
      <div class="aviso">El estado anterior quedó guardado como <span class="mono">${esc(r.copia_previa)}</span>.</div>
      <p class="suave">Por seguridad, todos los usuarios deben volver a entrar.</p></div>
      <div class="modal-pie"><button class="btn prim" data-c autofocus>Entrar de nuevo</button></div>`);
    $("[data-c]", ok).onclick = () => { cerrarModal(); cerrarSesionLocal(); };
  });
  $("[data-ok]", m).onclick = hacer;
  $("#rs-pin").onkeydown = (e) => { if (e.key === "Enter") hacer(); };
});

async function modalCopiaManual(alTerminar) {
  const grupos = await api("GET", "/api/backups/grupos");
  const m = modal(`<h2>Hacer copia de seguridad</h2>
    <p class="suave" style="margin:6px 0 12px">¿Qué quiere guardar?</p>
    <label class="opcion-copia todo"><input type="checkbox" id="cp-todo" checked><span><b>Todo</b>
      <span class="suave">Copia completa: se puede restaurar tal cual para volver exactamente a este momento.</span></span></label>
    <div class="grupos-copia">${grupos.map((g) => `<label class="opcion-copia"><input type="checkbox" name="cp-g" value="${g.id}" checked>
      <span><b>${esc(g.nombre)}</b><span class="suave">${esc(g.detalle)}</span></span></label>`).join("")}</div>
    <div class="aviso oculto" id="cp-aviso" style="margin-top:10px">Copia <b>parcial</b>: al restaurarla se añaden o actualizan solo esos datos, sin borrar el resto.</div>
    <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Hacer copia</button></div>`, { ancho: true });
  const marcas = $$('[name="cp-g"]', m);
  const sync = () => {
    const n = marcas.filter((x) => x.checked).length;
    $("#cp-todo").checked = n === marcas.length;
    $("#cp-todo").indeterminate = n > 0 && n < marcas.length;
    $("#cp-aviso").classList.toggle("oculto", n === marcas.length || n === 0);
    $("[data-ok]", m).disabled = n === 0;
    $("[data-ok]", m).textContent = n === marcas.length ? "Hacer copia completa" : n ? "Hacer copia parcial" : "Elija qué guardar";
  };
  $("#cp-todo").onchange = (e) => { marcas.forEach((x) => (x.checked = e.target.checked)); sync(); };
  marcas.forEach((x) => (x.onchange = sync));
  $("[data-c]", m).onclick = cerrarModal;
  $("[data-ok]", m).onclick = accion(async () => {
    const contenido = marcas.filter((x) => x.checked).map((x) => x.value);
    const b = $("[data-ok]", m); b.disabled = true; b.textContent = "Copiando…";
    try {
      const r = await api("POST", "/api/backup", { contenido });
      cerrarModal();
      toast("Copia creada: " + r.archivo, "ok");
    } finally { alTerminar && alTerminar(); }
  });
  sync();
}

// ================================================================ Programación

const DIAS_SEMANA = [["1", "L"], ["2", "M"], ["3", "X"], ["4", "J"], ["5", "V"], ["6", "S"], ["7", "D"]];

const NOMBRE_DIA = { 1: "lunes", 2: "martes", 3: "miércoles", 4: "jueves", 5: "viernes", 6: "sábado", 7: "domingo" };

function textoPrograma(p) {
  if (!p) return "cada 6 horas";
  if (p.backup_auto_modo === "no") return "sin copias programadas";
  if (p.backup_auto_modo === "intervalo") return `cada ${p.backup_auto_cada_h} hora${p.backup_auto_cada_h === "1" ? "" : "s"}`;
  const dias = p.backup_auto_dias === "1234567" ? "todos los días" : p.backup_auto_dias === "12345" ? "de lunes a viernes"
    : p.backup_auto_dias.split("").map((d) => NOMBRE_DIA[d]).join(", ");
  return `${dias} a las ${p.backup_auto_horas.split(",").join(", ")}`;
}

// Programación de copias en una ventana aparte: frecuencia en un desplegable y
// «qué guardar» y la carpeta adicional plegados en «Más opciones».
const modalProgramacion = accion(async (p, alGuardar) => {
  const grupos = await api("GET", "/api/backups/grupos");
  const cont = p.backup_auto_contenido ? p.backup_auto_contenido.split(",") : grupos.map((g) => g.id);
  const m = modal(`<form id="f-prog"><h2>Programar copias automáticas</h2>
    <label class="campo" style="margin-top:12px">Frecuencia
      <select class="ent" id="pr-modo">
        <option value="intervalo" ${p.backup_auto_modo === "intervalo" ? "selected" : ""}>Cada cierto número de horas</option>
        <option value="horas" ${p.backup_auto_modo === "horas" ? "selected" : ""}>A horas fijas</option>
        <option value="no" ${p.backup_auto_modo === "no" ? "selected" : ""}>Desactivadas</option></select></label>
    <div id="pr-intervalo" class="fila" style="gap:10px;margin-top:12px">Una copia cada
      <input class="ent num" type="number" min="1" max="168" id="pr-cada" value="${esc(p.backup_auto_cada_h)}" style="width:90px"> horas</div>
    <div id="pr-horas" style="margin-top:12px">
      <label class="campo">Horas <span class="ayuda">una o varias, separadas por comas (p. ej. 14:00, 23:30)</span>
        <input class="ent mono" id="pr-h" value="${esc(p.backup_auto_horas.split(",").join(", "))}" autocomplete="off"></label>
      <div class="campo" style="margin-top:10px">Días
        <div class="dias-semana">${DIAS_SEMANA.map(([d, n]) => `<label class="dia ${p.backup_auto_dias.includes(d) ? "on" : ""}"><input type="checkbox" value="${d}" ${p.backup_auto_dias.includes(d) ? "checked" : ""}>${n}</label>`).join("")}</div></div>
      <p class="ayuda" style="margin:6px 0 0">Si el equipo está apagado a esa hora, la copia se hace al encenderlo.</p></div>
    <details class="plegable" style="margin-top:14px"><summary><h3>Más opciones</h3><span class="suave">qué guardar, carpeta adicional, copias a conservar</span></summary>
      <div id="pr-que" style="margin-top:10px"><div class="campo">Qué guardar en las copias programadas</div>
        <div class="grupos-copia">${grupos.map((g) => `<label class="opcion-copia"><input type="checkbox" name="pr-g" value="${g.id}" ${cont.includes(g.id) ? "checked" : ""}>
          <span><b>${esc(g.nombre)}</b><span class="suave">${esc(g.detalle)}</span></span></label>`).join("")}</div></div>
      <div class="rejilla r2" style="margin-top:12px">
        <label class="campo">Carpeta adicional <span class="ayuda">pendrive, disco externo o red, p. ej. E:\\copias_parking</span>
          <input class="ent" id="pr-extra" value="${esc(p.backup_destino_extra || "")}" autocomplete="off"></label>
        <label class="campo">Copias a conservar<input class="ent num" id="pr-mantener" type="number" min="5" value="${esc(p.backups_mantener || 30)}"></label></div></details>
    <p class="ayuda">Además se hace siempre una copia completa al arrancar el programa y al cerrar cada turno.</p>
    <div class="modal-pie"><button type="button" class="btn" data-c>Cancelar</button><button class="btn prim">Guardar</button></div></form>`, { ancho: true });
  const caja = $("#f-prog", m), modo = () => $("#pr-modo", caja).value;
  const pintar = () => {
    $("#pr-intervalo", caja).classList.toggle("oculto", modo() !== "intervalo");
    $("#pr-horas", caja).classList.toggle("oculto", modo() !== "horas");
    $("#pr-que", caja).classList.toggle("oculto", modo() === "no");
  };
  $("#pr-modo", caja).onchange = pintar;
  $$(".dia input", caja).forEach((i) => (i.onchange = () => i.parentElement.classList.toggle("on", i.checked)));
  $("[data-c]", caja).onclick = cerrarModal;
  caja.onsubmit = accion(async (e) => {
    e.preventDefault();
    await api("PUT", "/api/backups/programa", {
      backup_auto_modo: modo(), backup_auto_cada_h: $("#pr-cada", caja).value, backup_auto_horas: $("#pr-h", caja).value,
      backup_auto_dias: $$(".dia input", caja).filter((i) => i.checked).map((i) => i.value).join(""),
      backup_auto_contenido: $$('[name="pr-g"]', caja).filter((i) => i.checked).map((i) => i.value),
      backup_destino_extra: $("#pr-extra", caja).value, backups_mantener: $("#pr-mantener", caja).value });
    cerrarModal();
    toast("Programación de copias guardada", "ok");
    alGuardar();
  });
  pintar();
});

// ======================================== Copia en el NAS y cifrada en la nube

// Copia también en el NAS o en otra carpeta
function htmlCopiaNas(c) {
  const ruta = c.backup_destino_extra || "";
  return `<div id="cd-nas" class="panel"><div class="fila" style="justify-content:space-between"><h3>Copia también en el NAS o en otra carpeta</h3>
      <span class="etiqueta ${ruta ? "e-pagado" : "e-salido"}">${ruta ? "Activada" : "Opcional"}</span></div>
    <p class="suave" style="margin:8px 0">Cada copia (las programadas, al arrancar y al cerrar turno) se guarda además en otra carpeta: un NAS (Synology, QNAP…),
      otro PC de la red o un disco externo. Si el PC del parking se estropea, las copias siguen a salvo.</p>
    <div class="fila"><input class="ent mono" id="nas-ruta" style="flex:1;min-width:280px" value="${esc(ruta)}" placeholder="\\\\NAS\\copias_parking   o   Z:\\copias_parking">
      <button class="btn" id="nas-probar">Probar</button><button class="btn prim" id="nas-guardar">Guardar</button>
      ${ruta ? '<button class="btn" id="nas-quitar">Desactivar</button>' : ""}</div>
    <p class="ayuda" style="margin:8px 0 0">En el NAS, cree una carpeta compartida y dé permiso de escritura al usuario de Windows que usa el parking. Use la ruta de red
      (<span class="mono">\\\\NAS\\carpeta</span>) mejor que una letra de unidad. Si un día no se puede copiar, aparece un aviso en la campana.</p></div>`;
}

function montarCopiaNas(el) {
  const nas = $("#cd-nas", el);
  const probar = async () => { await api("POST", "/api/backups/probar-destino", { ruta: $("#nas-ruta", nas).value.trim() }); };
  $("#nas-probar", nas).onclick = accion(async () => { await probar(); toast("La carpeta funciona: se puede escribir en ella", "ok"); });
  $("#nas-guardar", nas).onclick = accion(async () => {
    const r = $("#nas-ruta", nas).value.trim();
    if (r) await probar();
    await api("PUT", "/api/config", { backup_destino_extra: r });
    toast(r ? "Guardado: las próximas copias irán también ahí" : "Copia adicional desactivada", "ok");
    ajCopias(el);
  });
  if ($("#nas-quitar", nas)) $("#nas-quitar", nas).onclick = accion(async () => {
    await api("PUT", "/api/config", { backup_destino_extra: "" }); toast("Copia adicional desactivada", "ok"); ajCopias(el);
  });
}

// Copia cifrada en la nube (carpeta de OneDrive/Google Drive/Dropbox o WebDAV)
function htmlCopiaNube(c, st) {
  const activo = c.nube_activo === "1";
  return `<form id="cd-nube" class="panel"><div class="fila" style="justify-content:space-between"><h3 class="titulo-icono">${icono("nube", 22)}Copia cifrada en la nube</h3>
      <span class="etiqueta ${activo ? (st.error ? "e-err" : "e-pagado") : "e-salido"}">${activo ? (st.error ? "Con error" : "Activada") : "Opcional"}</span></div>
    <p class="suave" style="margin:8px 0">Cada copia de seguridad se sube además a la nube, <b>cifrada con su contraseña</b> antes de salir de este PC: ni el proveedor ni nadie sin la contraseña puede leerla.
      Sin la contraseña tampoco se puede recuperar: guárdela en un sitio seguro.</p>
    <label class="fila" style="gap:10px;font-weight:600"><input type="checkbox" name="nube_activo" ${activo ? "checked" : ""}> Subir las copias a la nube</label>
    <div class="rejilla r2" style="margin-top:12px">
      <label class="campo">Destino<select class="ent" name="nube_destino"><option value="carpeta" ${c.nube_destino !== "webdav" ? "selected" : ""}>Carpeta de OneDrive, Google Drive o Dropbox en este PC</option>
        <option value="webdav" ${c.nube_destino === "webdav" ? "selected" : ""}>Servidor WebDAV (Nextcloud, NAS, pCloud, Koofr…)</option></select></label>
      <label class="campo">Copias que se guardan en la nube<input class="ent num" type="number" min="1" max="365" name="nube_mantener" value="${esc(c.nube_mantener || "10")}"></label>
      <label class="campo nb-carpeta" style="grid-column:1/-1">Carpeta sincronizada<input class="ent mono" name="nube_carpeta" value="${esc(c.nube_carpeta || "")}" placeholder="C:\\Users\\parking\\OneDrive\\Copias PROYECTO ALLAS"></label>
      <label class="campo nb-webdav" style="grid-column:1/-1">Dirección WebDAV<input class="ent mono" name="nube_webdav_url" value="${esc(c.nube_webdav_url || "")}" placeholder="https://micloud.es/remote.php/dav/files/usuario/Copias"></label>
      <label class="campo nb-webdav">Usuario<input class="ent" name="nube_webdav_usuario" value="${esc(c.nube_webdav_usuario || "")}" autocomplete="off"></label>
      <label class="campo nb-webdav">Contraseña del WebDAV<input class="ent" type="password" name="nube_webdav_clave" value="${esc(c.nube_webdav_clave || "")}" autocomplete="new-password"></label>
      <label class="campo">Contraseña de cifrado <span class="ayuda">mínimo 8 caracteres</span><input class="ent" type="password" name="nube_clave" value="${esc(c.nube_clave || "")}" autocomplete="new-password"></label>
      <label class="campo">Repita la contraseña<input class="ent" type="password" name="nube_clave2" value="${esc(c.nube_clave || "")}" autocomplete="new-password"></label></div>
    ${st.ultimo ? `<p class="suave" style="font-size:.85rem;margin:10px 0 0">Última subida: ${fechaHora(st.ultimo.split(" ")[0])} · ${esc(st.ultimo.split(" ").slice(1).join(" "))}</p>` : ""}
    ${st.error ? `<div class="aviso rojo" style="margin-top:8px">Último error: ${esc(st.error)}</div>` : ""}
    <div class="fila" style="margin-top:12px"><button class="btn prim">Guardar</button><button type="button" class="btn" id="nb-probar">Hacer una copia y subirla ahora</button>
      <label class="btn">Recuperar una copia cifrada…<input type="file" id="nb-rec" accept=".allas-cifrada" hidden></label></div></form>`;
}

function montarCopiaNube(el) {
  const p = $("#cd-nube", el);
  const pintar = () => {
    const wd = p.nube_destino.value === "webdav";
    $$(".nb-webdav", p).forEach((x) => x.classList.toggle("oculto", !wd));
    $$(".nb-carpeta", p).forEach((x) => x.classList.toggle("oculto", wd));
  };
  p.nube_destino.onchange = pintar; pintar();
  const guardar = async () => {
    if (p.nube_clave.value !== p.nube_clave2.value) throw new Error("Las contraseñas de cifrado no coinciden");
    if (p.nube_activo.checked && p.nube_clave.value.length < 8) throw new Error("La contraseña de cifrado debe tener al menos 8 caracteres");
    const d = {};
    ["nube_destino", "nube_mantener", "nube_carpeta", "nube_webdav_url", "nube_webdav_usuario", "nube_webdav_clave", "nube_clave"].forEach((k) => (d[k] = p[k].value.trim()));
    d.nube_activo = p.nube_activo.checked ? "1" : "0";
    await api("PUT", "/api/config", d);
  };
  p.onsubmit = accion(async (e) => { e.preventDefault(); await guardar(); toast("Guardado", "ok"); ajCopias(el); });
  $("#nb-probar", p).onclick = accion(async () => {
    await guardar();
    $("#nb-probar", p).disabled = true; $("#nb-probar", p).textContent = "Subiendo…";
    try {
      const r = await api("POST", "/api/nube/probar");
      toast("Copia cifrada subida: " + r.hecho, "ok");
    } finally { if ($("#cd-nube", el)) ajCopias(el); }
  });
  $("#nb-rec", p).onchange = accion(async (e) => {
    const a = e.target.files[0]; if (!a) return;
    const m = modal(`<h2 class="titulo-icono">${icono("candado", 24)}Recuperar copia cifrada</h2>
      <p>${esc(a.name)}</p><label class="campo">Contraseña de cifrado<input class="ent" type="password" id="nb-pw" autofocus></label>
      <p class="suave" style="margin-top:8px">Se descifra y queda en la lista de copias; después puede restaurarla desde esa lista.</p>
      <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn prim" data-ok>Descifrar</button></div>`);
    $("[data-c]", m).onclick = cerrarModal;
    $("[data-ok]", m).onclick = accion(async () => {
      await subirBinario("/api/nube/descifrar", a, "application/octet-stream", { "X-Clave": encodeURIComponent($("#nb-pw", m).value) });
      cerrarModal(); toast("Copia descifrada: ya está en la lista de copias", "ok"); vistaAjustes($("#vista"));
    });
  });
}

// ====================================================== Borrar todos los datos

function montarZonaPeligro(el) {
  if (!el) return;
  const caja = document.createElement("div");
  caja.className = "zona-peligro";
  caja.innerHTML = `<p class="suave" style="margin:10px 0">Elimina todos los datos (tickets, facturas, clientes, bonos, tarifas, usuarios, ajustes y logo) y el programa vuelve a la pantalla de primera instalación.
      Antes se guarda automáticamente una copia de seguridad «Antes de borrar todo», que puede restaurar desde esta misma pantalla. La licencia se conserva.</p>
    <button class="btn peligro lleno" id="b-restablecer">Borrar todos los datos…</button>`;
  $$(".zona-peligro", el).forEach((x) => x.remove());
  el.appendChild(caja);
  $("#b-restablecer", caja).onclick = () => {
    const m = modal(`<h2 style="color:var(--rojo)">Borrar todos los datos</h2>
      <p>Se borrará <b>todo</b> y el programa quedará como recién instalado. Se guardará antes una copia de seguridad.</p>
      <label class="campo">PIN del administrador (${esc(S.usuario.usuario)})<input class="ent" type="password" id="rs-pin" inputmode="numeric" autocomplete="off" autofocus></label>
      <label class="campo" style="margin-top:10px">Escriba <b>BORRAR TODO</b> para confirmar<input class="ent" id="rs-conf" autocomplete="off"></label>
      <div class="modal-pie"><button class="btn" data-c>Cancelar</button><button class="btn peligro lleno" data-ok>Borrar todo</button></div>`);
    $("[data-c]", m).onclick = cerrarModal;
    $("[data-ok]", m).onclick = accion(async () => {
      const r = await api("POST", "/api/sistema/restablecer", { pin: $("#rs-pin", m).value, confirmacion: $("#rs-conf", m).value });
      cerrarModal();
      toast(`Datos borrados. Copia previa: ${r.copia_previa}`, "ok");
      sessionStorage.removeItem("token");
      window.__salirSinPreguntar = true;
      setTimeout(() => location.reload(), 900);
    });
  };
}
