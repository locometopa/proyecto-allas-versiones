/* PROYECTO ALLAS · Tienda */
"use strict";

// ====================================================================== Tienda

// URL de la foto de un producto (la fecha de cambio evita que el navegador muestre una foto antigua)
const urlFotoProducto = (p) => `/api/productos/${p.id}/foto?token=${encodeURIComponent(S.token)}&v=${encodeURIComponent(p.foto || "")}`;

async function vistaTienda(v) {
  if (!exigirTurnoPropio(v)) return;
  const [prods, ds] = await Promise.all([api("GET", "/api/productos?activos=1"),
    S.estado.descuentos ? api("GET", "/api/descuentos?activos=1&ambito=tienda") : { descuentos: [] }]);
  const descuentos = ds.descuentos || [];
  const st = S.tienda;
  if (st.descuento && !descuentos.some((d) => d.id === st.descuento)) st.descuento = null;
  if (st.vale) descuentos.push(st.vale);   // vale tecleado antes de cambiar de pantalla
  v.innerHTML = `<div class="cab"><div class="titulo-pantalla"><span class="pastilla tienda">🛒 Tienda</span><h2>Venta de productos y servicios</h2></div>
      <div class="fila" style="gap:8px"><input class="ent" id="t-buscar" placeholder="Buscar producto o servicio" style="min-width:260px" value="${esc(st.buscar)}" autocomplete="off">
        <button class="btn" id="t-historial">Historial de ventas</button></div></div>
    <div class="tienda">
      <div><div class="catalogo-tienda" id="t-cat"></div>
        <p class="ayuda" style="margin-top:12px">Sin matrícula ni tiempo de estancia. Los productos se crean en Ajustes → Servicios y productos.</p></div>
      <div class="panel carrito" id="t-carrito"></div>
    </div>`;
  const pintarCatalogo = () => {
    const q = st.buscar.trim().toLowerCase();
    const lista = prods.filter((p) => !q || p.nombre.toLowerCase().includes(q) || (p.descripcion || "").toLowerCase().includes(q));
    $("#t-cat").innerHTML = lista.length ? lista.map((p) => `<button class="prod-tienda ${p.foto ? "con-foto" : ""}" data-p="${p.id}">
        ${p.foto ? `<img class="foto-prod" src="${urlFotoProducto(p)}" alt="" loading="lazy">` : ""}
        <span class="etiqueta ${p.tipo === "producto" ? "e-dentro" : "e-abonado"}" style="align-self:flex-start">${TIPO_PROD[p.tipo]}</span>
        <span class="n">${esc(p.nombre)}</span>${p.descripcion ? `<span class="d">${esc(p.descripcion)}</span>` : ""}
        <span class="pr num">${p.precio_variable ? "Precio al vender" : eur(p.precio_cent)}</span></button>`).join("")
      : `<div class="vacio" style="grid-column:1/-1">${prods.length ? "Nada coincide con la búsqueda." : "No hay productos ni servicios a la venta."}</div>`;
    $$("[data-p]", $("#t-cat")).forEach((b) => (b.onclick = async () => {
      const p = prods.find((x) => x.id === Number(b.dataset.p));
      let precio;   // 4.62: sin precio fijo → se pregunta al seleccionarlo
      if (p.precio_variable) { precio = await pedirPrecio(p.nombre); if (precio === null) return; }
      const l = st.carrito.find((x) => x.producto_id === p.id && x.precio_cent === precio);
      if (l) l.cantidad = Math.min(99, l.cantidad + 1); else st.carrito.push(precio === undefined ? { producto_id: p.id, cantidad: 1 } : { producto_id: p.id, cantidad: 1, precio_cent: precio });
      b.classList.add("anadido"); setTimeout(() => b.classList.remove("anadido"), 350);
      pintarCarrito();
    }));
  };
  const total = () => st.carrito.reduce((s, l) => s + (l.precio_cent ?? prods.find((p) => p.id === l.producto_id)?.precio_cent ?? 0) * l.cantidad, 0);
  // Descuento elegido: se calcula aquí solo para mostrarlo; el servidor lo vuelve a calcular
  const descuentoCent = (bruto) => {
    const d = descuentos.find((x) => x.id === st.descuento);
    if (!d || !bruto) return 0;
    return Math.min(bruto, d.tipo === "porcentaje" ? Math.round(bruto * d.valor / 100) : d.valor);
  };
  const pintarCarrito = () => {
    st.carrito = st.carrito.filter((l) => prods.some((p) => p.id === l.producto_id) && l.cantidad > 0);
    const bruto = total(), dto = descuentoCent(bruto), t = bruto - dto;
    $("#t-carrito").innerHTML = `<h3>Venta</h3>
      ${st.carrito.length ? st.carrito.map((l, i) => {
        const p = prods.find((x) => x.id === l.producto_id);
        return `<div class="linea"><div><b>${esc(p.nombre)}</b><div class="suave" style="font-size:.8rem">${eur(l.precio_cent ?? p.precio_cent)} / ud.</div></div>
          <div class="fila" style="gap:4px;flex-wrap:nowrap"><button class="btn mini" data-menos="${i}">−</button><b class="num" style="min-width:1.6em;text-align:center">${l.cantidad}</b>
            <button class="btn mini" data-mas="${i}">+</button></div><b class="num">${eur((l.precio_cent ?? p.precio_cent) * l.cantidad)}</b></div>`;
      }).join("") : '<div class="vacio" style="padding:22px 6px">Toque un producto para añadirlo.</div>'}
      ${S.estado.descuentos ? `<div class="descuento-cobro">${descuentos.length ? `<label class="campo">Descuento
        <select class="ent" id="t-dto"><option value="">Sin descuento</option>${descuentos.map((d) => `<option value="${d.id}" ${st.descuento === d.id ? "selected" : ""}>${esc(d.nombre)} · ${esc(d.texto)}</option>`).join("")}</select></label>` : ""}
        <label class="campo" style="max-width:170px;min-width:140px">Código o vale<input class="ent mono" id="t-dto-cod" placeholder="Escanear" autocomplete="off" style="text-transform:uppercase"></label></div>` : ""}
      <div class="total ${t ? "" : "cero"}" style="margin-top:14px"><div class="t">Total</div><div class="v num">${eur(t)}</div>
        ${dto ? `<div class="desglose num"><div><span>Subtotal</span><span>${eur(bruto)}</span></div><div><span>Descuento</span><span>−${eur(dto)}</span></div></div>` : ""}</div>
      <div class="metodos"><button class="btn xl ${st.metodo === "efectivo" ? "sel" : ""}" data-m="efectivo">Efectivo</button>
        <button class="btn xl ${st.metodo === "tarjeta" ? "sel" : ""}" data-m="tarjeta">Tarjeta</button></div>
      ${st.metodo === "efectivo" ? `<label class="campo">Entregado<input class="ent grande num" id="t-ent" inputmode="decimal" placeholder="Cantidad recibida"></label>
        <div class="cambio" id="t-cambio"><span>Cambio</span><span class="v num">0,00 €</span></div>` : ""}
      <div class="fila" style="margin-top:12px"><button class="btn" id="t-vaciar" ${st.carrito.length ? "" : "disabled"}>Vaciar</button>
        <button class="btn ok xl" id="t-cobrar" style="flex:1" ${bruto ? "" : "disabled"}>${t ? `Cobrar ${eur(t)}` : "Registrar (sin cargo)"}</button></div>`;
    if ($("#t-dto")) $("#t-dto").onchange = (e) => { st.descuento = idDescuento(e.target.value); pintarCarrito(); };
    if ($("#t-dto-cod")) $("#t-dto-cod").onkeydown = accion(async (e) => {
      if (e.key !== "Enter") return;
      e.preventDefault(); e.stopPropagation();
      const cod = e.target.value.trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
      if (!cod) return;
      let d = descuentos.find((x) => (x.codigo || "").toUpperCase() === cod);
      if (!d) {
        d = await api("GET", "/api/descuentos/codigo?ambito=tienda&codigo=" + encodeURIComponent(cod));
        descuentos.push(d);
        if (d.vale) st.vale = d;
      }
      st.descuento = d.id;
      toast(`Descuento aplicado: ${d.nombre}`, "ok");
      pintarCarrito();
    });
    $$("[data-mas]", $("#t-carrito")).forEach((b) => (b.onclick = () => { st.carrito[b.dataset.mas].cantidad = Math.min(99, st.carrito[b.dataset.mas].cantidad + 1); pintarCarrito(); }));
    $$("[data-menos]", $("#t-carrito")).forEach((b) => (b.onclick = () => { st.carrito[b.dataset.menos].cantidad -= 1; pintarCarrito(); }));
    $$("[data-m]", $("#t-carrito")).forEach((b) => (b.onclick = () => { st.metodo = b.dataset.m; pintarCarrito(); }));
    $("#t-vaciar").onclick = () => { st.carrito = []; pintarCarrito(); };
    // Lo mismo en la pantalla de cliente
    const infoCliente = () => {
      if (typeof pantallaCliente !== "function") return;
      if (!st.carrito.length) return pantallaCliente({ tipo: "libre" });
      const e = $("#t-ent"), ec = e && e.value.trim() ? aCent(e.value) : null;
      const dSel = descuentos.find((x) => x.id === st.descuento);
      pantallaCliente({ tipo: "tienda", total_cent: t, descuento_cent: dto, descuento_nombre: dSel ? dSel.nombre : null, metodo: st.metodo,
        entregado_cent: ec != null && !Number.isNaN(ec) ? ec : null,
        lineas: st.carrito.map((l) => { const p = prods.find((x) => x.id === l.producto_id); return { concepto: p.nombre, cantidad: l.cantidad, importe_cent: (l.precio_cent ?? p.precio_cent) * l.cantidad }; }) });
    };
    infoCliente();
    if ($("#t-ent")) $("#t-ent").addEventListener("input", infoCliente);
    const ent = $("#t-ent");
    if (ent) {
      ent.oninput = () => {
        const cc = $("#t-cambio");
        if (pintarSinEntregado(ent, cc)) return;
        const e = aCent(ent.value), dif = e - t;
        cc.className = "cambio" + (Number.isNaN(dif) || dif < 0 ? " falta" : "");
        cc.innerHTML = Number.isNaN(dif) ? "<span>Importe no válido</span>" : `<span>${dif < 0 ? "Faltan" : "Cambio"}</span><span class="v num">${eur(Math.abs(dif))}</span>`;
      };
      ent.onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); $("#t-cobrar").click(); } };
    }
    $("#t-cobrar").onclick = accion(async () => {
      let entregado = null;
      if (st.metodo === "efectivo" && t) {
        entregado = entregadoEfectivo(ent ? ent.value : "", t, "#t-ent");
      }
      const dref = st.metodo === "tarjeta" && t ? await pasoDatafono(t, "TIENDA") : null;
      const r = await api("POST", "/api/tienda/venta", { lineas: st.carrito, metodo: st.metodo, entregado_cent: entregado,
        descuento_id: st.descuento || null, datafono_ref: dref });
      st.descuento = null;
      if (st.vale) { descuentos.splice(descuentos.indexOf(st.vale), 1); st.vale = null; }
      notarImpresion(r.impresion);
      st.carrito = [];
      pintarCarrito();
      pantallaCliente({ tipo: "gracias", total_cent: r.pago.importe_cent, cambio_cent: r.pago.cambio_cent || 0 });
      const ok = modal(`<div class="exito"><div class="icono">✓</div><h2>Cobrado ${eur(r.pago.importe_cent)}</h2>
          ${r.pago.metodo === "efectivo" ? `<p class="suave" style="margin:14px 0 2px">Cambio a devolver</p><div class="grande num">${eur(r.pago.cambio_cent)}</div>` : ""}
          <p class="suave">Factura simplificada ${esc(r.pago.serie)}-${String(r.pago.numero).padStart(6, "0")} · ${esc(r.pago.metodo)}</p></div>
        <div class="modal-pie"><button class="btn" id="t-ver">Ver ticket</button><button class="btn" id="t-fac">Factura con datos / email</button>
          <button class="btn prim" data-c autofocus>Nueva venta</button></div>`);
      $("#t-ver").onclick = () => verImpresion(r.impresion);
      $("#t-fac").onclick = () => modalFactura(r.pago.id);
      $("[data-c]", ok).onclick = cerrarModal;
    });
  };
  $("#t-buscar").oninput = (e) => { st.buscar = e.target.value; pintarCatalogo(); };
  $("#t-historial").onclick = modalHistorialTienda;
  pintarCatalogo();
  pintarCarrito();
}

function modalHistorialTienda() {
  const h = S.tiendaHist, hoy = new Date().toLocaleDateString("sv-SE");
  h.desde = h.desde || hoy; h.hasta = h.hasta || hoy;
  const m = modal(`<h2>Historial de ventas de la tienda</h2>
    <div class="fila" style="margin:12px 0">
      <label class="campo" style="margin:0">Desde<input class="ent" type="date" id="th-desde" value="${h.desde}"></label>
      <label class="campo" style="margin:0">Hasta<input class="ent" type="date" id="th-hasta" value="${h.hasta}"></label>
      <label class="campo" style="margin:0;flex:1">Buscar<input class="ent" id="th-buscar" value="${esc(h.buscar)}" placeholder="Nº de factura, producto o cliente" autocomplete="off"></label>
      <div class="fila" style="gap:6px;align-self:flex-end"><button class="btn" data-rango="hoy">Hoy</button><button class="btn" data-rango="7">7 días</button><button class="btn" data-rango="30">30 días</button></div>
    </div>
    <div id="th-res"><div class="vacio">Cargando…</div></div>
    <div class="modal-pie"><button class="btn" data-c>Cerrar</button></div>`, { ancho: true });
  $("[data-c]", m).onclick = cerrarModal;
  let tm;
  const cargar = accion(async () => {
    if (!$("#th-res")) return;
    h.desde = $("#th-desde").value; h.hasta = $("#th-hasta").value; h.buscar = $("#th-buscar").value;
    const r = await api("GET", "/api/tienda/ventas?" + new URLSearchParams({ desde: h.desde, hasta: h.hasta, buscar: h.buscar }));
    if (!$("#th-res")) return;
    $("#th-res").innerHTML = r.ventas.length ? `<div style="overflow-x:auto;max-height:52vh"><table class="tabla"><thead><tr><th>Fecha</th><th>Factura</th><th>Productos y servicios</th><th>Pago</th><th class="der">Importe</th><th></th></tr></thead><tbody>
      ${r.ventas.map((x) => `<tr><td class="num">${fechaHora(x.fecha)}<div class="suave" style="font-size:.8rem">${esc(x.usuario || "")}</div></td>
        <td class="mono">${esc(x.serie)}-${String(x.numero).padStart(6, "0")}${x.cliente ? `<div class="suave" style="font-size:.8rem;font-family:inherit">${esc(x.cliente)}</div>` : ""}</td>
        <td style="font-size:.9rem">${x.lineas.map((l) => `${l.cantidad > 1 ? `${l.cantidad} × ` : ""}${esc(l.nombre)}`).join("<br>")}</td>
        <td>${esc(x.metodo === "efectivo" ? "Efectivo" : x.metodo === "tarjeta" ? "Tarjeta" : x.metodo)}</td>
        <td class="der num"><b>${eur(x.importe_cent)}</b></td>
        <td class="der" style="white-space:nowrap"><button class="btn" data-reimp="${x.id}" title="Imprimir una copia del ticket">Reimprimir</button>
          <button class="btn" data-fac="${x.id}" title="Ver, factura con datos o enviar por email">Ver / factura</button></td></tr>`).join("")}</tbody></table></div>
      <p class="suave" style="margin:10px 0 0">${r.ventas.length} venta(s) · ${r.unidades} unidad(es) · total <b>${eur(r.total_cent)}</b>${r.ventas.length >= 500 ? " (se muestran las 500 últimas)" : ""}</p>`
      : '<div class="vacio">No hay ventas en esas fechas.</div>';
    $$("[data-fac]", $("#th-res")).forEach((b) => (b.onclick = () => modalFactura(Number(b.dataset.fac), modalHistorialTienda)));
    $$("[data-reimp]", $("#th-res")).forEach((b) => (b.onclick = accion(async () => {
      const r2 = await api("POST", `/api/facturas/${b.dataset.reimp}/imprimir`);
      notarImpresion(r2); toast("Copia del ticket impresa", "ok");
    })));
  });
  ["#th-desde", "#th-hasta"].forEach((s) => ($(s).onchange = cargar));
  $("#th-buscar").oninput = () => { clearTimeout(tm); tm = setTimeout(cargar, 250); };
  $$("[data-rango]", m).forEach((b) => (b.onclick = () => {
    const d = new Date();
    if (b.dataset.rango !== "hoy") d.setDate(d.getDate() - Number(b.dataset.rango) + 1);
    $("#th-desde").value = d.toLocaleDateString("sv-SE"); $("#th-hasta").value = hoy; cargar();
  }));
  cargar();
}

// ============================================================ al cargar

S.tienda = S.tienda || { carrito: [], metodo: "efectivo", buscar: "" };

S.tiendaHist = S.tiendaHist || { desde: null, hasta: null, buscar: "" };
