/* PROYECTO ALLAS · Informes y gráficos */
"use strict";

// ==================================================================== Informes

function vistaInformes(v) {
  const tabs = [["resumen", "Resumen"], ["estadisticas", "Estadísticas"], ["facturas", "Facturas"], ["cierre", "Cierre y gestoría"], ["turnos", "Turnos"], ["auditoria", "Auditoría"]]
    .concat(S.estado.registro_integridad ? [["facturacion", "Registro de facturación"]] : []).filter(([id]) => id === "resumen" || (tieneModulo("gestion") && !oculto("inf:" + id)));   // licencia Lite: solo el resumen
  if (!tabs.find((t) => t[0] === S.informeTab)) S.informeTab = "resumen";
  v.innerHTML = `<div class="cab"><h2>Informes</h2></div>
    <div class="pestanas">${tabs.map(([id, n]) => `<button data-t="${id}" class="${S.informeTab === id ? "activo" : ""}">${n}</button>`).join("")}</div>
    <div id="inf"></div>`;
  $$("[data-t]").forEach((b) => (b.onclick = () => { S.informeTab = b.dataset.t; vistaInformes(v); }));
  ({ resumen: infResumen, estadisticas: infEstadisticas, facturas: listaFacturas, cierre: infCierre, turnos: infTurnos,
    auditoria: infAuditoria, facturacion: infFacturacion })[S.informeTab]($("#inf"));
}

function infResumen(el) {
  const hoy = hoyISO();
  el.innerHTML = `<form class="fila" id="f-inf" style="margin-bottom:16px">
      <label class="campo">Desde<input class="ent" type="date" name="desde" value="${hoy}"></label>
      <label class="campo">Hasta<input class="ent" type="date" name="hasta" value="${hoy}"></label>
      <button class="btn prim" style="align-self:flex-end">Ver</button>
      <a class="btn" id="b-csv" style="align-self:flex-end;text-decoration:none">Exportar cobros (CSV)</a></form>
    <div id="inf-datos"></div>`;
  const cargar = accion(async () => {
    const d = Object.fromEntries(new FormData($("#f-inf")));
    $("#b-csv").href = `/api/informe.csv?desde=${d.desde}&hasta=${d.hasta}&token=${encodeURIComponent(S.token)}`;
    const r = await api("GET", `/api/informe?desde=${d.desde}&hasta=${d.hasta}`);
    const T = r.totales;
    const porHora = Array.from({ length: 24 }, (_, h) => (r.entradas_por_hora.find((x) => x.hora === h) || { n: 0 }).n);
    const max = Math.max(1, ...porHora);
    $("#inf-datos").innerHTML = `
      <div class="rejilla r4">
        <div class="panel kpi"><div class="t">Recaudado total</div><div class="v num">${eur(T.total)}</div>
          <div class="suave num" style="font-size:.85rem">Efectivo ${eur(T.efectivo)} · Tarjeta ${eur(T.tarjeta)}${T.online ? ` · Online ${eur(T.online)}` : ""}${T.transferencia ? ` · Transferencia ${eur(T.transferencia)}` : ""}</div></div>
        <div class="panel kpi"><div class="t">Estancias</div><div class="v num">${eur(T.estancias)}</div>
          <div class="suave num" style="font-size:.85rem">${T.cobros} cobros · medio ${eur(T.ticket_medio)} · servicios ${eur(T.servicios)}${T.descuentos ? ` · descuentos −${eur(T.descuentos)} (${T.num_descuentos})` : ""}</div></div>
        <div class="panel kpi mod-abonados"><div class="t">Bonos vendidos</div><div class="v num">${eur(T.bonos)}</div>
          <div class="suave num" style="font-size:.85rem">${T.num_bonos} bono(s) · ${r.abonados_vigentes} abonados vigentes hoy</div></div>
        <div class="panel kpi"><div class="t">Entradas</div><div class="v num">${T.entradas}</div>
          <div class="suave num" style="font-size:.85rem">${r.entradas_abonados} de abonados · estancia media ${duracion(T.estancia_media_min)}</div></div>
      </div>
      <div class="rejilla" style="margin-top:16px;align-items:start;grid-template-columns:minmax(0,1fr) minmax(0,1.6fr)">
        <div class="panel"><h3>Entradas por hora</h3>
          <div class="barras">${porHora.map((n, h) => `<div style="height:${(n / max) * 100}%" title="${h}:00 · ${n} entradas"></div>`).join("")}</div>
          <div class="barras-eje">${porHora.map((_, h) => `<span>${h % 3 === 0 ? h : ""}</span>`).join("")}</div>
          ${r.productos_vendidos.length ? `<h3 style="margin-top:16px">Servicios y productos vendidos</h3>
            <table class="tabla"><tbody>${r.productos_vendidos.map((v) => `<tr><td>${esc(v.nombre)}</td><td class="der num">${v.unidades} ud.</td><td class="der num">${eur(v.importe)}</td></tr>`).join("")}</tbody></table>` : ""}
          ${r.comercios && r.comercios.length ? `<h3 style="margin-top:16px">Validaciones de comercios</h3>
            <table class="tabla"><tbody>${r.comercios.map((v) => `<tr><td>${esc(v.comercio)}</td><td class="der num">${v.usos} uso(s)</td><td class="der num">−${eur(v.importe)}</td></tr>`).join("")}</tbody></table>` : ""}
          <p class="suave" style="margin-bottom:0">Anulados: ${r.anulados} · Tickets perdidos cobrados: ${r.perdidos} · Tickets manuales: ${r.manuales}${T.num_devoluciones ? ` · <b>Devoluciones: ${T.num_devoluciones} (−${eur(T.devoluciones)})</b>, ya restadas del total` : ""}</p></div>
        <div class="panel"><h3>Por día</h3>
          ${r.dias.length ? `<div style="overflow-x:auto"><table class="tabla"><thead><tr><th>Día</th><th class="der">Entradas</th><th class="der">Estancias</th><th class="der">Servicios</th><th class="der">Bonos</th><th class="der">Efectivo</th><th class="der">Tarjeta</th><th class="der">Online</th><th class="der">Transfer.</th><th class="der">Total</th></tr></thead>
          <tbody>${r.dias.map((d) => `<tr><td>${fecha(d.dia + "T12:00:00")}</td><td class="der num">${d.entradas}</td><td class="der num">${eur(d.estancias)}</td><td class="der num">${eur(d.servicios)}</td><td class="der num">${eur(d.bonos)}</td>
            <td class="der num">${eur(d.efectivo)}</td><td class="der num">${eur(d.tarjeta)}</td><td class="der num">${eur(d.online || 0)}</td><td class="der num">${eur(d.transferencia || 0)}</td><td class="der num"><b>${eur(d.total)}</b></td></tr>`).join("")}</tbody></table></div>`
          : '<div class="vacio">Sin actividad en el periodo.</div>'}</div>
      </div>`;
  });
  $("#f-inf").onsubmit = (e) => { e.preventDefault(); cargar(); };
  cargar();
}

function infEstadisticas(el) {
  const e = S.estad43;
  const hoy = hoyISO(), ini = hoy.slice(0, 8) + "01";
  el.innerHTML = `<form class="fila" id="f-est" style="margin-bottom:16px;align-items:flex-end">
      <label class="campo">Desde<input class="ent" type="date" name="desde" value="${e.desde}"></label>
      <label class="campo">Hasta<input class="ent" type="date" name="hasta" value="${e.hasta}"></label>
      <button class="btn prim">Ver</button>
      ${[["7 días", diaMas(hoy, -6), hoy], ["30 días", diaMas(hoy, -29), hoy], ["Este mes", ini, hoy], ["12 meses", diaMas(hoy, -364), hoy]]
        .map(([n, d, h]) => `<button type="button" class="btn" data-r="${d},${h}">${n}</button>`).join("")}</form>
    <div id="est-datos"><div class="vacio">Calculando…</div></div>`;
  const f = $("#f-est", el);
  const cargar = accion(async () => {
    Object.assign(S.estad43, Object.fromEntries(new FormData(f)));
    const r = await api("GET", `/api/estadisticas?desde=${e.desde}&hasta=${e.hasta}`);
    const caja = $("#est-datos", el); if (!caja) return;
    const var_ = r.variacion_pct;
    caja.innerHTML = `<div class="rejilla r4 kpis43">
        <div class="panel kpi"><div class="t">Ingresos</div><div class="v num">${eur(r.total_cent)}</div>
          <div class="suave num" style="font-size:.85rem">${var_ == null ? "sin datos del periodo anterior" : `<span class="var43 ${var_ >= 0 ? "sube" : "baja"}">${var_ >= 0 ? "▲" : "▼"} ${Math.abs(var_).toLocaleString("es-ES")} %</span> frente a los ${r.dias} días anteriores`}</div></div>
        <div class="panel kpi"><div class="t">Ticket medio</div><div class="v num">${eur(r.ticket_medio_cent)}</div><div class="suave num" style="font-size:.85rem">${r.num_cobros} cobros de estancia</div></div>
        <div class="panel kpi"><div class="t">Estancia media</div><div class="v num">${duracion(r.estancia_media_min)}</div><div class="suave num" style="font-size:.85rem">${r.entradas} entradas</div></div>
        <div class="panel kpi"><div class="t">Rotación</div><div class="v num">${r.rotacion == null ? "—" : r.rotacion.toLocaleString("es-ES")}</div>
          <div class="suave num" style="font-size:.85rem">${r.rotacion == null ? "indique la capacidad en Ajustes" : "vehículos por plaza y día"}</div></div></div>
      <div class="panel" style="margin-top:16px"><div class="fila" style="justify-content:space-between"><h3>Ingresos por día</h3><span class="suave" style="font-size:.85rem">${fechaCorta2(r.desde)} – ${fechaCorta2(r.hasta)}</span></div>
        <div id="g-ingresos"></div>${tablaDatos(["Día", "Este periodo", "Periodo anterior"], r.ingresos.map((x) => [fechaCorta2(x.dia), eur(x.total), eur(x.anterior)]))}</div>
      <div class="rejilla r2" style="margin-top:16px;align-items:start">
        <div class="panel"><h3>Ocupación media por hora</h3><p class="suave" style="margin:2px 0 6px;font-size:.85rem">vehículos dentro a cada hora${r.capacidad ? ` (capacidad ${r.capacidad})` : ""}</p>
          <div id="g-ocupacion"></div>${tablaDatos(["Hora", "Vehículos"], r.ocupacion_hora.map((v, h) => [`${h}:00`, v.toLocaleString("es-ES")]))}</div>
        <div class="panel"><h3>Entradas por día y hora</h3><p class="suave" style="margin:2px 0 6px;font-size:.85rem">cuándo llegan los clientes</p>
          <div id="g-calor"></div></div></div>
      <div class="rejilla r3" style="margin-top:16px;align-items:start">
        <div class="panel"><h3>Tarifas</h3><p class="suave" style="margin:2px 0 8px;font-size:.85rem">entradas en el periodo</p><div id="g-tarifas"></div></div>
        <div class="panel"><h3>Servicios y productos</h3><p class="suave" style="margin:2px 0 8px;font-size:.85rem">importe vendido</p><div id="g-servicios"></div></div>
        <div class="panel"><h3>Tipos de vehículo</h3><p class="suave" style="margin:2px 0 8px;font-size:.85rem">entradas</p><div id="g-tipos"></div></div></div>`;
    const dia = (iso) => new Date(iso + "T12:00:00").toLocaleDateString("es-ES", { day: "numeric", month: "short" });
    graficoLineas($("#g-ingresos", caja), r.ingresos.map((x) => dia(x.dia)),
      [{ nombre: "Este periodo", valores: r.ingresos.map((x) => x.total), clase: "s1" },
        { nombre: "Periodo anterior", valores: r.ingresos.map((x) => x.anterior), clase: "s2",
          etiquetas: r.ingresos.map((x) => `Anterior (${dia(diaMas(x.dia, -r.dias))})`) }], eurCorto);
    graficoColumnas($("#g-ocupacion", caja), r.ocupacion_hora.map((_, h) => (h % 3 === 0 ? String(h) : "")), r.ocupacion_hora,
      (v) => (Math.round(v * 10) / 10).toLocaleString("es-ES"), "Vehículos dentro");
    graficoCalor($("#g-calor", caja), r.entradas_hora);
    graficoBarras($("#g-tarifas", caja), r.tarifas.map((t) => ({ n: t.nombre, v: t.entradas, detalle: `entradas · ${eur(t.importe)} cobrados` })), (v) => v.toLocaleString("es-ES"), "entradas");
    graficoBarras($("#g-servicios", caja), r.servicios.map((s) => ({ n: s.nombre, v: s.importe, detalle: `${s.unidades} unidades` })), eur, "vendido");
    graficoBarras($("#g-tipos", caja), r.tipos_vehiculo.map((t) => ({ n: t.tipo, v: t.n })), (v) => v.toLocaleString("es-ES"), "entradas");
  });
  f.onsubmit = (ev) => { ev.preventDefault(); cargar(); };
  $$("[data-r]", f).forEach((b) => (b.onclick = () => { const [d, h] = b.dataset.r.split(","); f.desde.value = d; f.hasta.value = h; cargar(); }));
  cargar();
}

const infCierre = accion(async (el) => {
  const hoy = hoyISO();
  const mesAnt = (() => { const d = new Date(hoy + "T12:00:00"); d.setDate(0); return [d.toLocaleDateString("sv-SE").slice(0, 8) + "01", d.toLocaleDateString("sv-SE")]; })();
  el.innerHTML = `<div class="rejilla r2" style="align-items:start">
    <div class="panel"><div class="fila" style="justify-content:space-between"><h3>Resumen de cierre del día</h3><input class="ent" type="date" id="ci-dia" value="${hoy}" style="width:auto"></div>
      <pre class="cierre43" id="ci-texto">Cargando…</pre>
      <div id="ci-envio"></div></div>
    <div class="panel"><h3>Libro de facturas para la gestoría</h3>
      <p class="suave" style="margin:6px 0 10px">Facturas emitidas (simplificadas, completas, rectificativas y sustitutivas) con fecha, serie y número, NIF y nombre del cliente,
        base y cuota por tipo de IVA y total. Se abre con Excel y lo puede importar casi cualquier programa de contabilidad.</p>
      <div class="fila" style="align-items:flex-end">
        <label class="campo">Desde<input class="ent" type="date" id="lf-desde" value="${mesAnt[0]}"></label>
        <label class="campo">Hasta<input class="ent" type="date" id="lf-hasta" value="${mesAnt[1]}"></label>
        <button class="btn prim" id="lf-csv">Descargar (CSV)</button></div>
      <div class="fila" style="margin-top:8px;gap:6px">${[["Mes anterior", mesAnt[0], mesAnt[1]], ["Este mes", hoy.slice(0, 8) + "01", hoy],
        ["Trimestre anterior", ...(() => { const d = new Date(hoy + "T12:00:00"); const q = Math.floor(d.getMonth() / 3); const ini = new Date(d.getFullYear(), q * 3 - 3, 1), fin = new Date(d.getFullYear(), q * 3, 0); return [ini.toLocaleDateString("sv-SE"), fin.toLocaleDateString("sv-SE")]; })()]]
        .map(([n, d, h]) => `<button class="btn mini" data-lf="${d},${h}">${n}</button>`).join("")}</div></div></div>`;
  const pintar = accion(async () => {
    const r = await api("GET", "/api/informes/cierre?dia=" + $("#ci-dia", el).value);
    $("#ci-texto", el).textContent = r.texto;
    const admin = tieneRol("admin");
    $("#ci-envio", el).innerHTML = `<h3 style="margin-top:14px">Enviar por email</h3>
      ${r.smtp ? "" : '<div class="aviso" style="margin:8px 0">Configure antes el correo en <i>Ajustes → Conexiones → Email</i>.</div>'}
      <div class="fila" style="align-items:flex-end;margin-top:8px">
        <label class="campo" style="flex:1;min-width:220px">Email(s) que reciben el resumen<input class="ent" id="ci-email" value="${esc(r.email)}" placeholder="dueno@miparking.es; gestor@asesoria.es" ${admin ? "" : "readonly"}></label>
        <button class="btn" id="ci-enviar">Enviar ahora</button></div>
      <label class="fila" style="gap:8px;margin-top:10px"><input type="checkbox" id="ci-auto" ${r.activo ? "checked" : ""} ${admin ? "" : "disabled"}>
        Enviarlo solo al cerrar el último turno del día (con el libro de facturas del día adjunto)</label>
      ${admin ? '<div class="fila" style="margin-top:10px"><button class="btn prim" id="ci-guardar">Guardar</button></div>' : ""}
      ${r.ultimo ? `<p class="suave" style="font-size:.85rem;margin:8px 0 0">Último envío: ${esc(r.ultimo.split(" ")[0])} (${fechaHora(r.ultimo.split(" ")[1])})</p>` : ""}
      ${r.error ? `<div class="aviso rojo" style="margin-top:8px">Último error: ${esc(r.error)}</div>` : ""}`;
    if ($("#ci-guardar", el)) $("#ci-guardar", el).onclick = accion(async () => {
      await api("PUT", "/api/config", { cierre_email: $("#ci-email", el).value.trim(), cierre_email_activo: $("#ci-auto", el).checked ? "1" : "0" });
      toast("Guardado", "ok"); pintar();
    });
    $("#ci-enviar", el).onclick = accion(async () => {
      if (admin) await api("PUT", "/api/config", { cierre_email: $("#ci-email", el).value.trim() });
      const x = await api("POST", "/api/informes/cierre/enviar", { dia: $("#ci-dia", el).value });
      toast(`Resumen enviado a ${x.destino}`, "ok"); pintar();
    });
  });
  $("#ci-dia", el).onchange = pintar;
  $("#lf-csv", el).onclick = () => descargarUrl("/api/informes/libro-facturas.csv", { desde: $("#lf-desde", el).value, hasta: $("#lf-hasta", el).value });
  $$("[data-lf]", el).forEach((b) => (b.onclick = () => { const [d, h] = b.dataset.lf.split(","); $("#lf-desde", el).value = d; $("#lf-hasta", el).value = h; }));
  pintar();
});

const infTurnos = accion(async (el) => {
  const ts = await api("GET", "/api/turnos");
  el.innerHTML = `<div class="panel">${ts.length ? `<table class="tabla"><thead><tr><th>Turno</th><th>Cajero</th><th>Apertura</th><th>Cierre</th>
    <th class="der">Esperado</th><th class="der">Contado</th><th class="der">Diferencia</th></tr></thead><tbody>
    ${ts.map((t) => `<tr><td>${t.id} ${t.estado === "abierto" ? '<span class="etiqueta e-dentro">abierto</span>' : ""}</td><td>${esc(t.usuario_nombre)}</td>
      <td>${fechaHora(t.apertura)}</td><td>${fechaHora(t.cierre)}</td><td class="der num">${eur(t.efectivo_esperado_cent)}</td>
      <td class="der num">${eur(t.efectivo_contado_cent)}</td>
      <td class="der num" style="color:${t.diferencia_cent ? "var(--rojo)" : "inherit"}">${t.estado === "cerrado" && t.arqueo === 0 ? '<span class="suave">sin arqueo</span>' : t.diferencia_cent == null ? "–" : eur(t.diferencia_cent)}</td></tr>`).join("")}
    </tbody></table>` : '<div class="vacio">Sin turnos.</div>'}</div>`;
});

function infAuditoria(el) {
  const a = S.audit43;
  el.innerHTML = `<form class="panel fila" id="f-aud" style="margin-bottom:14px;align-items:flex-end">
      <label class="campo">Desde<input class="ent" type="date" name="desde" value="${a.desde}"></label>
      <label class="campo">Hasta<input class="ent" type="date" name="hasta" value="${a.hasta}"></label>
      <label class="campo">Usuario<select class="ent" name="usuario_id"><option value="">Todos</option></select></label>
      <label class="campo">Acción<select class="ent" name="accion"><option value="">Todas</option></select></label>
      <label class="campo" style="flex:1;min-width:180px">Texto<input class="ent" name="texto" value="${esc(a.texto)}" placeholder="matrícula, nº de ticket, factura…"></label>
      <button class="btn prim">Buscar</button><button type="button" class="btn" id="aud-csv">Exportar (CSV)</button></form>
    <div class="panel" id="aud-tabla"><div class="vacio">Cargando…</div></div>`;
  const f = $("#f-aud", el);
  const cargar = accion(async () => {
    Object.assign(S.audit43, Object.fromEntries(new FormData(f)));
    const r = await api("GET", "/api/auditoria/buscar?" + new URLSearchParams({ ...a, limite: 1000 }));
    const selA = f.accion;
    if (selA.options.length <= 1) selA.innerHTML = '<option value="">Todas</option>' + r.acciones.map((x) => `<option ${a.accion === x ? "selected" : ""}>${esc(x)}</option>`).join("");
    const selU = f.usuario_id;
    if (selU.options.length <= 1) {
      const us = new Map(r.filas.filter((x) => x.usuario_id).map((x) => [x.usuario_id, x.usuario_nombre]));
      try { (await api("GET", "/api/usuarios")).forEach((u) => us.set(u.id, u.nombre)); } catch (_) { /* solo admin */ }
      selU.innerHTML = '<option value="">Todos</option>' + [...us].map(([id, n]) => `<option value="${id}" ${String(a.usuario_id) === String(id) ? "selected" : ""}>${esc(n)}</option>`).join("");
    }
    const grave = (x) => /fallido|anular|borrar|restablecer|restaurar|lista_negra|permisos|devol|rectific/.test(x);
    $("#aud-tabla", el).innerHTML = r.filas.length ? `<p class="suave" style="margin:0 0 8px">${r.filas.length}${r.filas.length >= 1000 ? "+ (afine los filtros)" : ""} registro(s)</p>
      <div style="overflow-x:auto"><table class="tabla"><thead><tr><th>Fecha</th><th>Usuario</th><th>Acción</th><th>Detalle</th></tr></thead><tbody>
      ${r.filas.map((x) => `<tr><td class="num" style="white-space:nowrap">${fechaHora(x.fecha)}</td><td>${esc(x.usuario_nombre || "(sistema)")}</td>
        <td><span class="etiqueta ${grave(x.accion) ? "e-err" : "e-salido"}">${esc(x.accion)}</span></td><td class="mono" style="font-size:.85rem">${esc(x.detalle || "")}</td></tr>`).join("")}
      </tbody></table></div>` : '<div class="vacio" style="padding:18px">Nada con estos filtros.</div>';
  });
  f.onsubmit = (e) => { e.preventDefault(); cargar(); };
  $("#aud-csv", el).onclick = () => { Object.assign(S.audit43, Object.fromEntries(new FormData(f))); descargarUrl("/api/auditoria.csv", a); };
  cargar();
}

const infFacturacion = accion(async (el) => {
  const r = await api("GET", "/api/facturacion/verificar");
  el.innerHTML = `<div class="panel" style="max-width:720px">
    <h3>Integridad del registro de facturación</h3>
    <p>Cada factura simplificada se guarda encadenada con la huella (SHA-256) de la anterior. Si alguien modificara un registro en la base de datos, la cadena se rompería.</p>
    <div class="aviso ${r.ok ? "verde" : "rojo"}">${r.ok ? `Cadena íntegra: ${r.registros} registro(s) verificados.` : `Cadena ROTA en la factura ${esc(r.error_en)}.`}</div>
    <p class="suave">Nota: es la base técnica para VERI*FACTU; la adaptación completa al formato y firma de la AEAT está en el plan de implementación.</p></div>`;
});

// ==================================================================== Gráficos

// Paleta validada (categorías 1-2 y rampa secuencial azul); en oscuro, los mismos tonos ajustados.
function tipGrafico() {
  let t = $("#viz-tip");
  if (!t) { t = document.createElement("div"); t.id = "viz-tip"; t.className = "viz-tip"; document.body.appendChild(t); }
  return t;
}

function mostrarTip(ev, filas, titulo) {
  const t = tipGrafico();
  t.replaceChildren();
  const h = document.createElement("div"); h.className = "viz-tip-t"; h.textContent = titulo; t.appendChild(h);
  filas.forEach(([valor, nombre, clase]) => {
    const r = document.createElement("div"); r.className = "viz-tip-f";
    if (clase) { const k = document.createElement("i"); k.className = "viz-key " + clase; r.appendChild(k); }
    const b = document.createElement("b"); b.textContent = valor; r.appendChild(b);
    if (nombre) { const s = document.createElement("span"); s.textContent = nombre; r.appendChild(s); }
    t.appendChild(r);
  });
  t.style.display = "block";
  const x = Math.min(window.innerWidth - t.offsetWidth - 8, ev.clientX + 14), y = Math.max(8, ev.clientY - t.offsetHeight - 10);
  t.style.left = x + "px"; t.style.top = y + "px";
}

const ocultarTip = () => { const t = $("#viz-tip"); if (t) t.style.display = "none"; };

const redondoEje = (max) => { if (max <= 0) return 1; const p = Math.pow(10, Math.floor(Math.log10(max))); const n = max / p; return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * p; };

const eurCorto = (c) => (Math.abs(c) >= 100000 ? (c / 100000).toLocaleString("es-ES", { maximumFractionDigits: 1 }) + " mil €" : Math.round(c / 100).toLocaleString("es-ES") + " €");

const diaMas = (iso, n) => { const d = new Date(iso + "T12:00:00"); d.setDate(d.getDate() + n); return d.toLocaleDateString("sv-SE"); };

// Línea: varias series sobre el mismo eje X (días). series: [{nombre, valores, clase}]
function graficoLineas(el, etiquetas, series, fmt) {
  const W = Math.max(320, Math.round(el.clientWidth) || 720), H = 260, ml = 58, mr = 16, mt = 14, mb = 28;
  const max = redondoEje(Math.max(1, ...series.flatMap((s) => s.valores)));
  const x = (i) => ml + (etiquetas.length <= 1 ? (W - ml - mr) / 2 : (i * (W - ml - mr)) / (etiquetas.length - 1));
  const y = (v) => mt + (H - mt - mb) * (1 - v / max);
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((k) => k * max);
  const cada = Math.max(1, Math.ceil(etiquetas.length / 8));
  el.innerHTML = `<div class="viz-leyenda">${series.map((s) => `<span><i class="viz-key ${s.clase}"></i>${esc(s.nombre)}</span>`).join("")}</div>
    <svg class="viz" viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(series.map((s) => s.nombre).join(" y "))}">
      ${ticks.map((t) => `<line class="viz-grid" x1="${ml}" x2="${W - mr}" y1="${y(t)}" y2="${y(t)}"/><text class="viz-eje" x="${ml - 8}" y="${y(t) + 4}" text-anchor="end">${esc(fmt(t))}</text>`).join("")}
      ${etiquetas.map((l, i) => ((i % cada === 0 && etiquetas.length - 1 - i >= cada * 0.6) || i === etiquetas.length - 1 ? `<text class="viz-eje" x="${x(i)}" y="${H - 8}" text-anchor="middle">${esc(l)}</text>` : "")).join("")}
      ${series.slice().reverse().map((s) => `<path class="viz-area ${s.clase}" d="M${x(0)},${y(0)} ${s.valores.map((v, i) => `L${x(i)},${y(v)}`).join(" ")} L${x(s.valores.length - 1)},${y(0)}Z"/>
        <polyline class="viz-linea ${s.clase}" points="${s.valores.map((v, i) => `${x(i)},${y(v)}`).join(" ")}"/>`).join("")}
      ${series.map((s) => { const i = s.valores.length - 1; return `<circle class="viz-punto ${s.clase}" cx="${x(i)}" cy="${y(s.valores[i])}" r="4"/>`; }).join("")}
      <line class="viz-cruz" id="cruz" x1="0" x2="0" y1="${mt}" y2="${H - mb}" style="display:none"/>
      <rect class="viz-hit" x="${ml}" y="${mt}" width="${W - ml - mr}" height="${H - mt - mb}"/></svg>`;
  const svg = $("svg", el), cruz = $("#cruz", el), hit = $(".viz-hit", el);
  const mover = (ev) => {
    const r = svg.getBoundingClientRect();
    const px = ((ev.clientX - r.left) / r.width) * W;
    const i = Math.max(0, Math.min(etiquetas.length - 1, Math.round(((px - ml) / (W - ml - mr)) * (etiquetas.length - 1))));
    cruz.setAttribute("x1", x(i)); cruz.setAttribute("x2", x(i)); cruz.style.display = "";
    mostrarTip(ev, series.map((s) => [fmt(s.valores[i]), s.etiquetas ? s.etiquetas[i] : s.nombre, s.clase]), etiquetas[i]);
  };
  hit.addEventListener("pointermove", mover);
  hit.addEventListener("pointerleave", () => { cruz.style.display = "none"; ocultarTip(); });
}

// Columnas (una serie)
function graficoColumnas(el, etiquetas, valores, fmt, titulo) {
  const W = Math.max(280, Math.round(el.clientWidth) || 720), H = 200, ml = 40, mr = 8, mt = 16, mb = 26;
  const max = redondoEje(Math.max(1, ...valores));
  const banda = (W - ml - mr) / valores.length, ancho = Math.min(22, banda - 4);
  const y = (v) => mt + (H - mt - mb) * (1 - v / max);
  const imax = valores.indexOf(Math.max(...valores));
  el.innerHTML = `<svg class="viz" viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(titulo)}">
    ${[0, 0.5, 1].map((k) => `<line class="viz-grid" x1="${ml}" x2="${W - mr}" y1="${y(k * max)}" y2="${y(k * max)}"/><text class="viz-eje" x="${ml - 6}" y="${y(k * max) + 4}" text-anchor="end">${esc(fmt(k * max))}</text>`).join("")}
    ${valores.map((v, i) => {
      const cx = ml + banda * i + banda / 2, top = y(v), h = Math.max(0, H - mb - top);
      const r = Math.min(4, h, ancho / 2);
      const d = h > 0 ? `M${cx - ancho / 2},${H - mb} V${top + r} q0,-${r} ${r},-${r} H${cx + ancho / 2 - r} q${r},0 ${r},${r} V${H - mb} Z` : "";
      return `<g class="viz-barra" data-i="${i}"><rect class="viz-hit" x="${ml + banda * i}" y="${mt}" width="${banda}" height="${H - mt - mb}"/>${d ? `<path class="viz-col s1" d="${d}"/>` : ""}
        ${i === imax && v > 0 ? `<text class="viz-valor" x="${cx}" y="${top - 5}" text-anchor="middle">${esc(fmt(v))}</text>` : ""}</g>`;
    }).join("")}
    ${etiquetas.map((l, i) => (l !== "" ? `<text class="viz-eje" x="${ml + banda * i + banda / 2}" y="${H - 8}" text-anchor="middle">${esc(l)}</text>` : "")).join("")}</svg>`;
  $$(".viz-barra", el).forEach((g) => {
    const i = Number(g.dataset.i);
    g.addEventListener("pointermove", (ev) => mostrarTip(ev, [[fmt(valores[i]), titulo]], g.dataset.t || `${i}:00`));
    g.addEventListener("pointerleave", ocultarTip);
  });
}

// Barras horizontales (ranking)
function graficoBarras(el, filas, fmt, titulo) {
  if (!filas.length) { el.innerHTML = '<div class="vacio" style="padding:14px">Sin datos en el periodo.</div>'; return; }
  const max = Math.max(1, ...filas.map((f) => f.v));
  el.innerHTML = `<div class="barras43" role="img" aria-label="${esc(titulo)}">${filas.map((f, i) => `<div class="b43" data-i="${i}">
      <span class="b43-n">${esc(f.n)}</span><span class="b43-pista"><i style="width:${Math.max(1.5, (f.v / max) * 100)}%"></i></span><span class="b43-v num">${esc(fmt(f.v))}</span></div>`).join("")}</div>`;
  $$(".b43", el).forEach((r) => {
    const f = filas[Number(r.dataset.i)];
    r.addEventListener("pointermove", (ev) => mostrarTip(ev, [[fmt(f.v), f.detalle || titulo]], f.n));
    r.addEventListener("pointerleave", ocultarTip);
  });
}

// Mapa de calor día × hora (rampa secuencial de un solo tono)
function graficoCalor(el, matriz) {
  const dias = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"];
  const max = Math.max(1, ...matriz.flat());
  const paso = (v) => (v <= 0 ? 0 : 1 + Math.min(6, Math.floor((v / max) * 6.999)));
  el.innerHTML = `<div class="calor43" role="img" aria-label="Entradas por día de la semana y hora">
    <span></span>${Array.from({ length: 24 }, (_, h) => `<span class="calor-h">${h % 3 === 0 ? h : ""}</span>`).join("")}
    ${matriz.map((fila, d) => `<span class="calor-d">${dias[d]}</span>${fila.map((v, h) => `<i class="c${paso(v)}" data-d="${d}" data-h="${h}"></i>`).join("")}`).join("")}</div>
    <div class="calor-leyenda"><span>Menos</span>${[0, 1, 2, 3, 4, 5, 6, 7].map((k) => `<i class="c${k}"></i>`).join("")}<span>Más</span></div>`;
  $$(".calor43 i", el).forEach((c) => {
    c.addEventListener("pointermove", (ev) => mostrarTip(ev, [[`${matriz[c.dataset.d][c.dataset.h]} entradas`, ""]], `${dias[c.dataset.d]} · ${c.dataset.h}:00 a ${Number(c.dataset.h) + 1}:00`));
    c.addEventListener("pointerleave", ocultarTip);
  });
}

function tablaDatos(cab, filas) {
  return `<details class="datos43"><summary>Ver los datos</summary><div style="overflow-x:auto"><table class="tabla mini43"><thead><tr>${cab.map((c) => `<th>${esc(c)}</th>`).join("")}</tr></thead>
    <tbody>${filas.map((f) => `<tr>${f.map((c) => `<td>${esc(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div></details>`;
}

// ============================================================ al cargar

S.estad43 = S.estad43 || { desde: diaMas(hoyISO(), -29), hasta: hoyISO() };

S.audit43 = S.audit43 || { desde: diaMas(hoyISO(), -6), hasta: hoyISO(), accion: "", texto: "", usuario_id: "" };
