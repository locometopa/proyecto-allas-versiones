/* PROYECTO ALLAS 4.4 · lector de códigos para la cámara del móvil, sin bibliotecas ni Internet:
   - Code128 (el código de barras de los tickets y las tarjetas)
   - QR (versiones 1 a 10, cualquier nivel de corrección; con corrección de errores Reed-Solomon)
   Recibe una imagen en escala de grises (Uint8Array, ancho, alto). La interfaz está en escaner.js. */
"use strict";

const LectorCodigos = (function () {
  // =========================================================== utilidades de imagen
  function grisDesdeRGBA(rgba, w, h) {
    const g = new Uint8Array(w * h);
    for (let i = 0, j = 0; i < g.length; i++, j += 4) g[i] = (rgba[j] * 77 + rgba[j + 1] * 150 + rgba[j + 2] * 29) >> 8;
    return g;
  }

  // Umbral adaptativo con imagen integral: oscuro si el píxel está por debajo de la media de su entorno
  function binarizar(g, w, h, radio) {
    const r = radio || Math.max(8, Math.round(Math.min(w, h) / 16));
    const I = new Float64Array((w + 1) * (h + 1));
    for (let y = 0; y < h; y++) {
      let fila = 0;
      for (let x = 0; x < w; x++) {
        fila += g[y * w + x];
        I[(y + 1) * (w + 1) + x + 1] = I[y * (w + 1) + x + 1] + fila;
      }
    }
    const b = new Uint8Array(w * h);
    for (let y = 0; y < h; y++) {
      const y0 = Math.max(0, y - r), y1 = Math.min(h, y + r + 1);
      for (let x = 0; x < w; x++) {
        const x0 = Math.max(0, x - r), x1 = Math.min(w, x + r + 1);
        const s = I[y1 * (w + 1) + x1] - I[y0 * (w + 1) + x1] - I[y1 * (w + 1) + x0] + I[y0 * (w + 1) + x0];
        const media = s / ((x1 - x0) * (y1 - y0));
        b[y * w + x] = g[y * w + x] < media * 0.92 - 4 ? 1 : 0;
      }
    }
    return b;
  }

  // =========================================================== Code128
  const C128 = ["212222", "222122", "222221", "121223", "121322", "131222", "122213", "122312", "132212", "221213",
    "221312", "231212", "112232", "122132", "122231", "113222", "123122", "123221", "223211", "221132",
    "221231", "213212", "223112", "312131", "311222", "321122", "321221", "312212", "322112", "322211",
    "212123", "212321", "232121", "111323", "131123", "131321", "112313", "132113", "132311", "211313",
    "231113", "231311", "112133", "112331", "132131", "113123", "113321", "133121", "313121", "211331",
    "231131", "213113", "213311", "213131", "311123", "311321", "331121", "312113", "312311", "332111",
    "314111", "221411", "431111", "111224", "111422", "121124", "121421", "141122", "141221", "112214",
    "112412", "122114", "122411", "142112", "142211", "241211", "221114", "413111", "241112", "134111",
    "111242", "121142", "121241", "114212", "124112", "124211", "411212", "421112", "421211", "212141",
    "214121", "412121", "111143", "111341", "131141", "114113", "114311", "411113", "411311", "113141",
    "114131", "311141", "411131", "211412", "211214", "211232"].map((p) => [...p].map(Number));
  const STOP = [2, 3, 3, 1, 1, 1, 2];

  // Distancia de 6 anchos medidos (en píxeles) a un patrón de 11 módulos
  function distancia(runs, i, patron, modulos) {
    let tot = 0;
    for (let k = 0; k < patron.length; k++) tot += runs[i + k];
    const u = tot / modulos;
    let d = 0;
    for (let k = 0; k < patron.length; k++) { const e = runs[i + k] / u - patron[k]; d += e * e; }
    // también por «distancias entre bordes» (barra+espacio): no les afecta que las barras salgan más gruesas o finas
    let de = 0;
    for (let k = 0; k + 1 < patron.length; k++) { const e = (runs[i + k] + runs[i + k + 1]) / u - (patron[k] + patron[k + 1]); de += e * e; }
    return Math.min(d, de * 0.75);
  }
  function simbolo(runs, i) {
    let mejor = -1, md = 1e9;
    for (let v = 0; v < 106; v++) {
      const d = distancia(runs, i, C128[v], 11);
      if (d < md) { md = d; mejor = v; }
    }
    return md < 1.1 ? mejor : -1;
  }
  // Interpreta los valores (con los juegos A, B y C)
  function textoCode128(vals) {
    let juego = vals[0] === 103 ? "A" : vals[0] === 104 ? "B" : "C", s = "", cambio = null;
    for (let i = 1; i < vals.length; i++) {
      const v = vals[i];
      const j = cambio || juego; cambio = null;
      if (j === "C") {
        if (v < 100) s += String(v).padStart(2, "0");
        else if (v === 100) juego = "B"; else if (v === 101) juego = "A";
        continue;
      }
      if (v === 98) { cambio = j === "A" ? "B" : "A"; continue; }
      if (v === 99) { juego = "C"; continue; }
      if (v === 100) { if (j === "A") juego = "B"; continue; }
      if (v === 101) { if (j === "B") juego = "A"; continue; }
      if (v >= 96) continue;   // FNC
      s += j === "A" ? (v < 64 ? String.fromCharCode(v + 32) : String.fromCharCode(v - 64)) : String.fromCharCode(v + 32);
    }
    return s;
  }
  function leerRuns(runs, margen) {
    // runs empieza en una barra (índice par = barra, impar = espacio)
    for (let i = 0; i + 6 <= runs.length; i += 2) {
      const ini = simbolo(runs, i);
      if (ini < 103 || ini > 105) continue;
      const u = (runs[i] + runs[i + 1] + runs[i + 2] + runs[i + 3] + runs[i + 4] + runs[i + 5]) / 11;
      if ((i === 0 ? margen : runs[i - 1]) < u * 3) continue;   // margen blanco antes del inicio
      const vals = [ini];
      let j = i + 6;
      while (j + 7 <= runs.length + 1) {
        if (j + 7 <= runs.length && distancia(runs, j, STOP, 13) < 1.3) {
          if (vals.length < 3) break;
          let suma = vals[0];
          for (let k = 1; k < vals.length - 1; k++) suma += k * vals[k];
          if (suma % 103 === vals[vals.length - 1]) {
            const t = textoCode128(vals.slice(0, -1));
            if (t.length) return t;
          }
          break;
        }
        if (j + 6 > runs.length) break;
        const v = simbolo(runs, j);
        if (v < 0 || v > 102) break;
        vals.push(v);
        j += 6;
      }
    }
    return null;
  }
  function runsDeLinea(linea) {
    // linea: 0/1 (1 = oscuro). Devuelve el blanco inicial y los anchos desde la primera barra
    let i = 0;
    while (i < linea.length && !linea[i]) i++;
    const margen = i, runs = [];
    let ini = i, actual = 1;
    for (; i <= linea.length; i++) {
      const v = i < linea.length ? linea[i] : actual ^ 1;
      if (v !== actual) { runs.push(i - ini); ini = i; actual = v; }
    }
    return { margen, runs };
  }
  // Umbral por línea: punto medio entre el mínimo y el máximo cercanos (resiste el desenfoque de las barras finas)
  function binarizarLinea(v, k) {
    const n = v.length, out = new Uint8Array(n);
    for (let i = 0; i < n; i++) {
      let mn = 255, mx = 0;
      for (let j = Math.max(0, i - k); j <= Math.min(n - 1, i + k); j++) { const x = v[j]; if (x < mn) mn = x; if (x > mx) mx = x; }
      out[i] = mx - mn > 40 && v[i] < (mn + mx) / 2 ? 1 : 0;
    }
    return out;
  }
  function code128(g, w, h) {
    const lineas = [];
    const pasos = 40;
    for (let q = 1; q < pasos; q++) {
      const y = Math.round((h * q) / pasos), x = Math.round((w * q) / pasos);
      lineas.push(g.subarray(y * w, y * w + w));
      const col = new Uint8Array(h);
      for (let yy = 0; yy < h; yy++) col[yy] = g[yy * w + x];
      lineas.push(col);
    }
    const votos = {};
    for (const gl of lineas) {
      for (const k of [6, 12]) {
        const l = binarizarLinea(gl, k);
        for (const dir of [l, Uint8Array.from(l).reverse()]) {
          const { margen, runs } = runsDeLinea(dir);
          const r = leerRuns(runs, margen);
          if (r) { votos[r] = (votos[r] || 0) + 1; if (votos[r] >= 2) return r; }
        }
      }
    }
    const t = Object.keys(votos);
    return t.length ? t.sort((a, c) => votos[c] - votos[a])[0] : null;
  }

  // =========================================================== QR: Reed-Solomon en GF(256)
  const EXP = new Uint8Array(512), LOG = new Uint8Array(256);
  (function () { let x = 1; for (let i = 0; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 0x100) x ^= 0x11d; } for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255]; })();
  const mul = (a, b) => (a && b ? EXP[LOG[a] + LOG[b]] : 0);
  const div = (a, b) => (a ? EXP[(LOG[a] + 255 - LOG[b]) % 255] : 0);
  function rsCorregir(bloque, nec) {
    const n = bloque.length;
    const S = new Array(nec).fill(0);
    let hay = false;
    for (let i = 0; i < nec; i++) {
      let s = 0;
      for (let j = 0; j < n; j++) s = mul(s, EXP[i]) ^ bloque[j];
      S[i] = s; if (s) hay = true;
    }
    if (!hay) return true;
    // Berlekamp-Massey
    let C = [1], B = [1], L = 0, m = 1, b = 1;
    for (let r = 0; r < nec; r++) {
      let d = S[r];
      for (let i = 1; i <= L; i++) d ^= mul(C[i] || 0, S[r - i]);
      if (d === 0) { m++; continue; }
      const coef = div(d, b);
      const T = C.slice();
      const nuevo = C.slice();
      for (let i = 0; i < B.length; i++) {
        while (nuevo.length <= i + m) nuevo.push(0);
        nuevo[i + m] ^= mul(coef, B[i]);
      }
      if (2 * L <= r) { L = r + 1 - L; B = T; b = d; m = 1; } else m++;
      C = nuevo;
    }
    // Chien: posiciones con error
    const pos = [];
    for (let j = 0; j < n; j++) {
      const xinv = EXP[(255 - (n - 1 - j)) % 255];
      let v = 0;
      for (let i = C.length - 1; i >= 0; i--) v = mul(v, xinv) ^ C[i];
      if (v === 0) pos.push(j);
    }
    if (pos.length !== L || L > nec / 2) return false;
    // Forney
    const omega = new Array(nec).fill(0);
    for (let i = 0; i < nec; i++) for (let k = 0; k < C.length && k <= i; k++) omega[i] ^= mul(C[k], S[i - k]);
    for (const j of pos) {
      const X = EXP[(n - 1 - j) % 255], xinv = EXP[(255 - (n - 1 - j)) % 255];
      let om = 0;
      for (let i = nec - 1; i >= 0; i--) om = mul(om, xinv) ^ omega[i];
      let der = 0;
      for (let i = 1; i < C.length; i += 2) {
        let t = C[i];
        for (let k = 0; k < i - 1; k++) t = mul(t, xinv);
        der ^= t;
      }
      if (!der) return false;
      bloque[j] ^= mul(X, div(om, der));
    }
    for (let i = 0; i < nec; i++) {
      let s = 0;
      for (let j = 0; j < n; j++) s = mul(s, EXP[i]) ^ bloque[j];
      if (s) return false;
    }
    return true;
  }

  // =========================================================== QR: estructura (versiones 1-10)
  const NIVELES = ["M", "L", "H", "Q"];   // bits del formato: 00 M, 01 L, 10 H, 11 Q
  const EC_BLOQUE = { L: [7, 10, 15, 20, 26, 18, 20, 24, 30, 18], M: [10, 16, 26, 18, 24, 16, 18, 22, 22, 26],
    Q: [13, 22, 18, 26, 18, 24, 18, 22, 20, 24], H: [17, 28, 22, 16, 22, 28, 26, 26, 24, 28] };
  const NUM_BLOQUES = { L: [1, 1, 1, 1, 1, 2, 2, 2, 2, 4], M: [1, 1, 1, 2, 2, 4, 4, 4, 5, 5],
    Q: [1, 1, 2, 2, 4, 4, 6, 6, 8, 8], H: [1, 1, 2, 4, 4, 4, 5, 6, 8, 8] };
  function modulosDatos(ver) {
    let r = (16 * ver + 128) * ver + 64;
    if (ver >= 2) { const n = Math.floor(ver / 7) + 2; r -= (25 * n - 10) * n - 55; if (ver >= 7) r -= 36; }
    return r;
  }
  function alineaciones(ver) {
    if (ver === 1) return [];
    const n = Math.floor(ver / 7) + 2;
    const paso = Math.floor((ver * 8 + n * 3 + 5) / (n * 4 - 4)) * 2;
    const r = [];
    for (let i = 0; i < n - 1; i++) r.push(ver * 4 + 10 - i * paso);
    r.push(6);
    return r.reverse();
  }
  function funciones(ver) {
    const n = ver * 4 + 17, f = new Uint8Array(n * n);
    const poner = (x, y) => { if (x >= 0 && y >= 0 && x < n && y < n) f[y * n + x] = 1; };
    for (let i = 0; i < n; i++) { poner(6, i); poner(i, 6); }
    for (const [cx, cy] of [[3, 3], [n - 4, 3], [3, n - 4]]) for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) poner(cx + dx, cy + dy);
    const p = alineaciones(ver), k = p.length;
    for (let i = 0; i < k; i++) for (let j = 0; j < k; j++) {
      if ((i === 0 && j === 0) || (i === 0 && j === k - 1) || (i === k - 1 && j === 0)) continue;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) poner(p[i] + dx, p[j] + dy);
    }
    for (let i = 0; i < 9; i++) { poner(8, i); poner(i, 8); }
    for (let i = 0; i < 8; i++) { poner(n - 1 - i, 8); poner(8, n - 1 - i); }
    if (ver >= 7) for (let i = 0; i < 18; i++) { poner(n - 11 + (i % 3), Math.floor(i / 3)); poner(Math.floor(i / 3), n - 11 + (i % 3)); }
    return f;
  }
  const MASCARAS = [(x, y) => (x + y) % 2 === 0, (x, y) => y % 2 === 0, (x) => x % 3 === 0, (x, y) => (x + y) % 3 === 0,
    (x, y) => (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0, (x, y) => ((x * y) % 2) + ((x * y) % 3) === 0,
    (x, y) => (((x * y) % 2) + ((x * y) % 3)) % 2 === 0, (x, y) => (((x + y) % 2) + ((x * y) % 3)) % 2 === 0];
  function leerFormato(M, n) {
    const bit = (x, y) => M[y * n + x];
    let a = 0, b = 0;
    const p1 = [];
    for (let i = 0; i < 6; i++) p1.push([8, i]);
    p1.push([8, 7], [8, 8], [7, 8]);
    for (let i = 9; i < 15; i++) p1.push([14 - i, 8]);
    const p2 = [];
    for (let i = 0; i < 8; i++) p2.push([n - 1 - i, 8]);
    for (let i = 8; i < 15; i++) p2.push([8, n - 15 + i]);
    p1.forEach(([x, y], i) => { a |= bit(x, y) << i; });
    p2.forEach(([x, y], i) => { b |= bit(x, y) << i; });
    let mejor = null, md = 99;
    for (let d = 0; d < 32; d++) {
      let r = d;
      for (let i = 0; i < 10; i++) r = (r << 1) ^ ((r >> 9) * 0x537);
      const cod = ((d << 10) | r) ^ 0x5412;
      for (const leido of [a, b]) {
        let x = cod ^ leido, c = 0;
        while (x) { c += x & 1; x >>= 1; }
        if (c < md) { md = c; mejor = d; }
      }
    }
    return md <= 3 ? { nivel: NIVELES[mejor >> 3], mascara: mejor & 7 } : null;
  }
  function decodificarMatriz(M, n) {
    const ver = (n - 17) / 4;
    if (ver < 1 || ver > 10 || ver !== Math.floor(ver)) return null;
    const fmt = leerFormato(M, n);
    if (!fmt) return null;
    const F = funciones(ver), masc = MASCARAS[fmt.mascara];
    const total = Math.floor(modulosDatos(ver) / 8);
    const bytes = new Uint8Array(total);
    let i = 0;
    for (let der = n - 1; der >= 1; der -= 2) {
      if (der === 6) der = 5;
      for (let vert = 0; vert < n; vert++) for (let j = 0; j < 2; j++) {
        const x = der - j, subiendo = ((der + 1) & 2) === 0, y = subiendo ? n - 1 - vert : vert;
        if (F[y * n + x] || i >= total * 8) continue;
        const v = M[y * n + x] ^ (masc(x, y) ? 1 : 0);
        if (v) bytes[i >> 3] |= 0x80 >> (i & 7);
        i++;
      }
    }
    // desentrelazado (como al generarlo: los bloques cortos llevan un hueco antes de los de corrección)
    const nec = EC_BLOQUE[fmt.nivel][ver - 1], nb = NUM_BLOQUES[fmt.nivel][ver - 1];
    const cortos = nb - (total % nb), largoCorto = Math.floor(total / nb), L = largoCorto + 1, hueco = largoCorto - nec;
    const bloques = [];
    for (let k = 0; k < nb; k++) bloques.push(new Array(L).fill(0));
    let p = 0;
    for (let col = 0; col < L; col++) for (let k = 0; k < nb; k++) {
      if (col === hueco && k < cortos) continue;
      bloques[k][col] = bytes[p++];
    }
    const datos = [];
    for (let k = 0; k < nb; k++) {
      const bl = k < cortos ? bloques[k].slice(0, hueco).concat(bloques[k].slice(hueco + 1)) : bloques[k];
      if (!rsCorregir(bl, nec)) return null;
      for (let q = 0; q < bl.length - nec; q++) datos.push(bl[q]);
    }
    return segmentos(datos, ver);
  }
  const ALFA = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:";
  function segmentos(datos, ver) {
    let pos = 0;
    const leer = (k) => { let v = 0; for (let i = 0; i < k; i++, pos++) v = (v << 1) | ((datos[pos >> 3] >> (7 - (pos & 7))) & 1); return v; };
    const quedan = () => datos.length * 8 - pos;
    let txt = "", bytes = [];
    const volcar = () => { if (bytes.length) { txt += utf8(bytes); bytes = []; } };
    while (quedan() >= 4) {
      const modo = leer(4);
      if (modo === 0) break;
      if (modo === 1) {
        volcar();
        let c = leer(ver < 10 ? 10 : 12);
        while (c >= 3) { txt += String(leer(10)).padStart(3, "0"); c -= 3; }
        if (c === 2) txt += String(leer(7)).padStart(2, "0"); else if (c === 1) txt += String(leer(4));
      } else if (modo === 2) {
        volcar();
        let c = leer(ver < 10 ? 9 : 11);
        while (c >= 2) { const v = leer(11); txt += ALFA[Math.floor(v / 45)] + ALFA[v % 45]; c -= 2; }
        if (c === 1) txt += ALFA[leer(6)];
      } else if (modo === 4) {
        let c = leer(ver < 10 ? 8 : 16);
        if (c * 8 > quedan()) return null;
        while (c--) bytes.push(leer(8));
      } else if (modo === 7) {
        leer(8);
      } else return null;
    }
    volcar();
    return txt || null;
  }
  function utf8(b) {
    try { return new TextDecoder("utf-8", { fatal: true }).decode(Uint8Array.from(b)); }
    catch (_) { return String.fromCharCode(...b); }
  }

  // =========================================================== QR: localización en la imagen
  function cruce(b, w, h, x, y, dx, dy, max) {
    // cuenta los 5 tramos (oscuro, claro, OSCURO, claro, oscuro) que pasan por (x,y) en la dirección (dx,dy)
    const at = (k) => { const xx = Math.round(x + dx * k), yy = Math.round(y + dy * k); return xx < 0 || yy < 0 || xx >= w || yy >= h ? -1 : b[yy * w + xx]; };
    if (at(0) !== 1) return null;
    const c = [0, 0, 0, 0, 0];
    let k = 0;
    while (at(k) === 1) { c[2]++; k--; }
    while (at(k) === 0 && c[1] <= max) { c[1]++; k--; }
    while (at(k) === 1 && c[0] <= max) { c[0]++; k--; }
    const atras = -k;            // píxeles hacia atrás (más uno)
    k = 1;
    while (at(k) === 1) { c[2]++; k++; }
    while (at(k) === 0 && c[3] <= max) { c[3]++; k++; }
    while (at(k) === 1 && c[4] <= max) { c[4]++; k++; }
    if (!proporcion(c)) return null;
    return { c, centro: (k - atras) / 2, total: c[0] + c[1] + c[2] + c[3] + c[4] };
  }
  function proporcion(c) {
    const tot = c[0] + c[1] + c[2] + c[3] + c[4];
    if (tot < 7 || c.some((v) => v === 0)) return false;
    const m = tot / 7, v = m / 1.6;
    return Math.abs(m - c[0]) < v && Math.abs(m - c[1]) < v && Math.abs(3 * m - c[2]) < 3 * v && Math.abs(m - c[3]) < v && Math.abs(m - c[4]) < v;
  }
  function buscarCentros(b, w, h) {
    const cand = [];
    const paso = Math.max(1, Math.floor(h / 400));
    for (let y = 0; y < h; y += paso) {
      const c = [0, 0, 0, 0, 0];
      let est = 0;
      for (let x = 0; x <= w; x++) {
        const v = x < w ? b[y * w + x] : 0;
        if (v === 1) {
          if (est % 2 === 1) est++;
          c[est]++;
        } else {
          if (est % 2 === 0 && c[est] > 0) {
            if (est === 4) {
              if (proporcion(c)) probar(b, w, h, x - c[4] - c[3] - c[2] / 2, y, c, cand);
              c[0] = c[2]; c[1] = c[3]; c[2] = c[4]; c[3] = 1; c[4] = 0; est = 3;
            } else { est++; c[est]++; }
          } else if (est % 2 === 1) c[est]++;
        }
      }
    }
    return cand;
  }
  function probar(b, w, h, cx, cy, c, cand) {
    const tot = c.reduce((a, z) => a + z, 0), max = tot;
    const v = cruce(b, w, h, cx, cy, 0, 1, max);
    if (!v) return;
    const ny = cy + v.centro;
    const hz = cruce(b, w, h, cx, ny, 1, 0, max);
    if (!hz) return;
    const nx = cx + hz.centro;
    const tam = (v.total + hz.total) / 14;
    const ya = cand.find((p) => Math.abs(p.x - nx) < tam * 3 && Math.abs(p.y - ny) < tam * 3 && Math.abs(p.m - tam) < tam);
    if (ya) { const n = ya.n + 1; ya.x = (ya.x * ya.n + nx) / n; ya.y = (ya.y * ya.n + ny) / n; ya.m = (ya.m * ya.n + tam) / n; ya.n = n; }
    else cand.push({ x: nx, y: ny, m: tam, n: 1 });
  }
  const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
  function elegirTres(cand) {
    const c = cand.filter((p) => p.n >= 2).sort((a, b) => b.n - a.n).slice(0, 10);
    const res = [];
    for (let i = 0; i < c.length; i++) for (let j = i + 1; j < c.length; j++) for (let k = j + 1; k < c.length; k++) {
      const t = [c[i], c[j], c[k]];
      const ms = t.map((p) => p.m), mmin = Math.min(...ms), mmax = Math.max(...ms);
      if (mmax > mmin * 1.6) continue;
      const d = [dist(t[1], t[2]), dist(t[0], t[2]), dist(t[0], t[1])];
      const imax = d.indexOf(Math.max(...d));
      const otros = d.filter((_, q) => q !== imax);
      const hip = d[imax], a = otros[0], bb = otros[1];
      const err = Math.abs(hip * hip - a * a - bb * bb) / (hip * hip) + Math.abs(a - bb) / Math.max(a, bb);
      if (err > 0.5 || a < mmin * 10) continue;
      const tl = t[imax], resto = t.filter((_, q) => q !== imax);
      let [tr, bl] = resto;
      if ((tr.x - tl.x) * (bl.y - tl.y) - (tr.y - tl.y) * (bl.x - tl.x) < 0) [tr, bl] = [bl, tr];
      res.push({ tl, tr, bl, err });
    }
    return res.sort((x, y) => x.err - y.err).slice(0, 4);
  }
  // Transformación de perspectiva (cuadrilátero → cuadrilátero), como en ZXing
  const PT = (a11, a21, a31, a12, a22, a32, a13, a23, a33) => ({ a11, a21, a31, a12, a22, a32, a13, a23, a33 });
  function cuadradoACuad(x0, y0, x1, y1, x2, y2, x3, y3) {
    const dx3 = x0 - x1 + x2 - x3, dy3 = y0 - y1 + y2 - y3;
    if (Math.abs(dx3) < 1e-9 && Math.abs(dy3) < 1e-9) return PT(x1 - x0, x2 - x1, x0, y1 - y0, y2 - y1, y0, 0, 0, 1);
    const dx1 = x1 - x2, dx2 = x3 - x2, dy1 = y1 - y2, dy2 = y3 - y2, den = dx1 * dy2 - dx2 * dy1;
    const a13 = (dx3 * dy2 - dx2 * dy3) / den, a23 = (dx1 * dy3 - dx3 * dy1) / den;
    return PT(x1 - x0 + a13 * x1, x3 - x0 + a23 * x3, x0, y1 - y0 + a13 * y1, y3 - y0 + a23 * y3, y0, a13, a23, 1);
  }
  function adjunta(t) {
    return PT(t.a22 * t.a33 - t.a23 * t.a32, t.a23 * t.a31 - t.a21 * t.a33, t.a21 * t.a32 - t.a22 * t.a31,
      t.a13 * t.a32 - t.a12 * t.a33, t.a11 * t.a33 - t.a13 * t.a31, t.a12 * t.a31 - t.a11 * t.a32,
      t.a12 * t.a23 - t.a13 * t.a22, t.a13 * t.a21 - t.a11 * t.a23, t.a11 * t.a22 - t.a12 * t.a21);
  }
  function por(a, o) {
    return PT(a.a11 * o.a11 + a.a21 * o.a12 + a.a31 * o.a13, a.a11 * o.a21 + a.a21 * o.a22 + a.a31 * o.a23, a.a11 * o.a31 + a.a21 * o.a32 + a.a31 * o.a33,
      a.a12 * o.a11 + a.a22 * o.a12 + a.a32 * o.a13, a.a12 * o.a21 + a.a22 * o.a22 + a.a32 * o.a23, a.a12 * o.a31 + a.a22 * o.a32 + a.a32 * o.a33,
      a.a13 * o.a11 + a.a23 * o.a12 + a.a33 * o.a13, a.a13 * o.a21 + a.a23 * o.a22 + a.a33 * o.a23, a.a13 * o.a31 + a.a23 * o.a32 + a.a33 * o.a33);
  }
  function transformacion(src, dst) {
    // src y dst: [x0,y0,...,x3,y3] (esquinas en el orden del cuadrado unidad 00, 10, 11, 01)
    const t = por(cuadradoACuad(...dst), adjunta(cuadradoACuad(...src)));
    return (x, y) => {
      const d = t.a13 * x + t.a23 * y + t.a33;
      return [(t.a11 * x + t.a21 * y + t.a31) / d, (t.a12 * x + t.a22 * y + t.a32) / d];
    };
  }
  function buscarAlineacion(b, w, h, ex, ey, m) {
    const at = (x, y) => (x < 0 || y < 0 || x >= w || y >= h ? 0 : b[Math.round(y) * w + Math.round(x)]);
    let mejor = null, mp = -1;
    const r = Math.round(m * 5);
    for (let y = ey - r; y <= ey + r; y += Math.max(1, m / 3)) for (let x = ex - r; x <= ex + r; x += Math.max(1, m / 3)) {
      if (!at(x, y)) continue;
      let p = 0;
      for (let a = 0; a < 8; a++) {
        const c = Math.cos((a * Math.PI) / 4), s = Math.sin((a * Math.PI) / 4);
        if (!at(x + c * m, y + s * m)) p++;
        if (at(x + c * m * 2, y + s * m * 2)) p++;
      }
      if (p > mp || (p === mp && Math.hypot(x - ex, y - ey) < Math.hypot(mejor.x - ex, mejor.y - ey))) { mp = p; mejor = { x, y }; }
    }
    return mp >= 14 ? mejor : null;
  }
  function muestrear(b, w, h, f, n) {
    const M = new Uint8Array(n * n);
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      const [px, py] = f(x + 0.5, y + 0.5);
      const xx = Math.round(px), yy = Math.round(py);
      if (xx < 0 || yy < 0 || xx >= w || yy >= h) return null;
      M[y * n + x] = b[yy * w + xx];
    }
    return M;
  }
  function qrDesdeTres(b, w, h, t) {
    const m = (t.tl.m + t.tr.m + t.bl.m) / 3;
    const d = (dist(t.tl, t.tr) + dist(t.tl, t.bl)) / (2 * m);
    let base = Math.round(d) + 7;
    const intentos = [];
    for (const delta of [0, -1, 1, -2, 2, -3, 3]) {
      const n = base + delta;
      if (n % 4 === 1 && n >= 21 && n <= 57 && !intentos.includes(n)) intentos.push(n);
    }
    for (const n of intentos) {
      const ver = (n - 17) / 4;
      const brx = t.tr.x - t.tl.x + t.bl.x, bry = t.tr.y - t.tl.y + t.bl.y;
      let quad = null;
      if (ver >= 2) {
        const corr = 1 - 3 / (n - 7);
        const ex = t.tl.x + corr * (brx - t.tl.x), ey = t.tl.y + corr * (bry - t.tl.y);
        const al = buscarAlineacion(b, w, h, ex, ey, m);
        if (al) quad = [3.5, 3.5, n - 3.5, 3.5, n - 6.5, n - 6.5, 3.5, n - 3.5, al];
      }
      const variantes = quad ? [quad, null] : [null];
      for (const q of variantes) {
        let f;
        if (q) f = transformacion([3.5, 3.5, n - 3.5, 3.5, n - 6.5, n - 6.5, 3.5, n - 3.5], [t.tl.x, t.tl.y, t.tr.x, t.tr.y, q[8].x, q[8].y, t.bl.x, t.bl.y]);
        else f = transformacion([3.5, 3.5, n - 3.5, 3.5, n - 3.5, n - 3.5, 3.5, n - 3.5], [t.tl.x, t.tl.y, t.tr.x, t.tr.y, brx, bry, t.bl.x, t.bl.y]);
        const M = muestrear(b, w, h, f, n);
        if (!M) continue;
        let r = decodificarMatriz(M, n);
        if (!r) {   // imagen en espejo
          const T = new Uint8Array(n * n);
          for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) T[y * n + x] = M[x * n + y];
          r = decodificarMatriz(T, n);
        }
        if (r) return r;
      }
    }
    return null;
  }
  function qr(g, w, h) {
    for (const radio of [Math.max(8, Math.round(Math.min(w, h) / 12)), Math.max(6, Math.round(Math.min(w, h) / 30))]) {
      const b = binarizar(g, w, h, radio);
      for (const t of elegirTres(buscarCentros(b, w, h))) {
        const r = qrDesdeTres(b, w, h, t);
        if (r) return r;
      }
    }
    return null;
  }

  // =========================================================== API
  function leer(g, w, h, tipos) {
    const quiere = tipos || ["qr", "code128"];
    if (quiere.includes("code128")) { const r = code128(g, w, h); if (r) return { tipo: "code128", texto: r }; }
    if (quiere.includes("qr")) { const r = qr(g, w, h); if (r) return { tipo: "qr", texto: r }; }
    return null;
  }
  return { leer, qr, code128, grisDesdeRGBA, _rs: rsCorregir, _matriz: decodificarMatriz, _bin: binarizar, _centros: buscarCentros, _tres: elegirTres, _desdeTres: qrDesdeTres, _linea: binarizarLinea, _runs: runsDeLinea, _leerRuns: leerRuns, _simbolo: simbolo };
})();
if (typeof module !== "undefined") module.exports = LectorCodigos;
