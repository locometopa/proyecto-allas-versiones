/* PROYECTO ALLAS 4.4 · cámara del móvil en la caja móvil: leer el QR o el código de barras del ticket / tarjeta
   y la matrícula. Con conexión segura (https) se usa el vídeo en directo; en la red local (http) el móvil hace una foto.
   Los códigos se leen en el propio móvil (lector.js); la matrícula la lee el PC del parking (OCR de Windows). */
"use strict";

const Escaner = (function () {
  const enVivo = () => !!(window.isSecureContext && navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
  let estado = null;

  function cerrar() {
    if (!estado) return;
    estado.vivo = false;
    if (estado.flujo) estado.flujo.getTracks().forEach((t) => t.stop());
    if (estado.capa) estado.capa.remove();
    estado = null;
  }

  // Imagen (de la cámara o de una foto) → escala de grises reducida
  function gris(fuente, max = 1280) {
    const w0 = fuente.videoWidth || fuente.naturalWidth || fuente.width, h0 = fuente.videoHeight || fuente.naturalHeight || fuente.height;
    const k = Math.min(1, max / Math.max(w0, h0));
    const c = document.createElement("canvas");
    c.width = Math.round(w0 * k); c.height = Math.round(h0 * k);
    const g = c.getContext("2d", { willReadFrequently: true });
    g.drawImage(fuente, 0, 0, c.width, c.height);
    const d = g.getImageData(0, 0, c.width, c.height);
    return { g: LectorCodigos.grisDesdeRGBA(d.data, c.width, c.height), w: c.width, h: c.height, lienzo: c };
  }

  async function detectar(fuente) {
    if ("BarcodeDetector" in window) {   // el del sistema, si lo hay (Android): más rápido
      try {
        const bd = new window.BarcodeDetector({ formats: ["qr_code", "code_128"] });
        const r = await bd.detect(fuente);
        if (r && r.length) return r[0].rawValue;
      } catch (_) { /* se usa el lector propio */ }
    }
    const x = gris(fuente);
    let r = LectorCodigos.leer(x.g, x.w, x.h);
    if (!r && Math.max(x.w, x.h) > 900) {   // segundo intento más pequeño (fotos con mucho detalle o ruido)
      const y = gris(fuente, 800);
      r = LectorCodigos.leer(y.g, y.w, y.h);
    }
    return r ? r.texto : null;
  }

  async function matricula(fuente) {
    const x = gris(fuente, 1600);
    const blob = await new Promise((ok) => x.lienzo.toBlob(ok, "image/jpeg", 0.88));
    const r = await fetch("/api/ocr/matricula", { method: "POST", headers: { "X-Token": S.token, "Content-Type": "image/jpeg" }, body: blob });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || "No se pudo leer la matrícula");
    return d;
  }

  function cargarFoto(archivo) {
    return new Promise((ok, mal) => {
      const i = new Image();
      i.onload = () => ok(i);
      i.onerror = () => mal(new Error("No se puede abrir la foto"));
      i.src = URL.createObjectURL(archivo);
    });
  }

  // modo: «codigo» (QR o código de barras) o «matricula»
  function abrir({ modo = "codigo", alLeer }) {
    cerrar();
    const capa = document.createElement("div");
    capa.className = "escaner";
    const titulo = modo === "matricula" ? "Leer la matrícula" : "Escanear el ticket o la tarjeta";
    const vivo = enVivo();
    capa.innerHTML = `<div class="esc-cab"><b>${titulo}</b><button class="esc-x" aria-label="Cerrar">✕</button></div>
      <div class="esc-zona">${vivo ? '<video playsinline muted autoplay></video>' : '<div class="esc-sin-video"></div>'}
        <div class="esc-marco ${modo === "matricula" ? "ancho" : ""}"></div></div>
      <div class="esc-pie"><p class="esc-msg">${vivo ? (modo === "matricula" ? "Encuadre la matrícula y pulse el botón." : "Apunte al código: se lee solo.")
          : (modo === "matricula" ? "Haga una foto de cerca a la matrícula, recta y con luz." : "Haga una foto de cerca al código (QR o barras), que se vea nítido.")}</p>
        ${vivo && modo === "matricula" ? '<button class="btn prim bloque xl esc-foto">Leer ahora</button>' : ""}
        <label class="btn ${vivo ? "esc-alt" : "prim bloque xl esc-foto"}">${vivo ? "O elegir una foto…" : "Hacer foto"}<input type="file" accept="image/*" capture="environment" hidden></label></div>`;
    document.body.appendChild(capa);
    estado = { capa, vivo: true, flujo: null };
    const st = estado;
    const msg = (t, err) => { const m = $(".esc-msg", capa); m.textContent = t; m.classList.toggle("err", !!err); };
    $(".esc-x", capa).onclick = cerrar;
    const terminar = (texto, extra) => { cerrar(); alLeer && alLeer(texto, extra); };
    const procesar = async (fuente) => {
      if (modo === "matricula") {
        msg("Leyendo la matrícula…");
        try {
          const r = await matricula(fuente);
          if (!r.matricula) return msg("No se ve ninguna matrícula. Pruebe más cerca y más recta." + (r.texto ? ` (leído: ${r.texto.slice(0, 40)})` : ""), true);
          terminar(r.matricula, r);
        } catch (e) { msg(e.message, true); }
        return;
      }
      msg("Buscando el código…");
      const t = await detectar(fuente);
      if (t) terminar(t); else msg("No se ha podido leer. Acerque más el móvil, con luz y sin reflejos, y repita.", true);
    };
    const inp = $("input[type=file]", capa);
    inp.onchange = async () => { const a = inp.files[0]; inp.value = ""; if (a) procesar(await cargarFoto(a)); };
    if (!vivo) {
      setTimeout(() => { try { inp.click(); } catch (_) { /* el botón sigue ahí */ } }, 50);   // abre la cámara directamente
      return;
    }
    const video = $("video", capa);
    navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment", width: { ideal: 1920 }, height: { ideal: 1080 } }, audio: false })
      .then((flujo) => {
        if (!st.vivo) { flujo.getTracks().forEach((t) => t.stop()); return; }
        st.flujo = flujo; video.srcObject = flujo;
        if (modo === "matricula") { $(".esc-foto", capa).onclick = (e) => { e.preventDefault(); procesar(video); }; return; }
        let ocupado = false;
        const bucle = async () => {
          if (!st.vivo) return;
          if (!ocupado && video.readyState >= 2) {
            ocupado = true;
            try { const t = await detectar(video); if (t && st.vivo) return terminar(t); } catch (_) { /* siguiente imagen */ }
            ocupado = false;
          }
          setTimeout(bucle, 250);
        };
        bucle();
      })
      .catch(() => msg("No se puede usar la cámara. Dé permiso en el navegador o escriba el código.", true));
  }

  return { abrir, cerrar, enVivo };
})();
