/* PROYECTO ALLAS 3.5 · Caja móvil / tablet: entradas, cobros y salidas desde la red local. */
"use strict";

const $ = (s, r = document) => r.querySelector(s);
// 4.4: icono de cámara (línea, como el resto)
const ICONO_CAM = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/></svg>';
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
function eur(c) {
  if (c === null || c === undefined) return "–";
  const neg = c < 0; c = Math.abs(c);
  return (neg ? "−" : "") + Math.floor(c / 100).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".") + "," + String(c % 100).padStart(2, "0") + " €";
}
function aCent(t) {
  const s = String(t ?? "").trim().replace(/\s|€/g, "").replace(/\.(?=\d{3}(\D|$))/g, "").replace(",", ".");
  if (!s) return null;
  const n = Number(s);
  return Number.isFinite(n) ? Math.round(n * 100) : NaN;
}
const hora = (iso) => (iso ? new Date(iso).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" }) : "–");
const fechaHora = (iso) => (iso ? new Date(iso).toLocaleDateString("es-ES", { day: "2-digit", month: "2-digit" }) + " " + hora(iso) : "–");
function duracion(min) {
  if (min == null) return "–";
  const d = Math.floor(min / 1440), h = Math.floor((min % 1440) / 60), m = min % 60;
  return (d ? d + " d " : "") + (d || h ? h + " h " : "") + m + " min";
}
const guardar = (k, v) => { try { v == null ? localStorage.removeItem(k) : localStorage.setItem(k, v); } catch (_) { /* privado */ } };
const leer = (k) => { try { return localStorage.getItem(k); } catch (_) { return null; } };

const S = { token: leer("movil_token"), estado: null, tab: "entrada", cobro: null, usuarioSel: leer("movil_usuario") || "" };

function toast(msg, tipo = "") {
  const t = document.createElement("div");
  t.className = "toast " + tipo; t.textContent = msg;
  $("#toasts").appendChild(t);
  while ($("#toasts").children.length > 2) $("#toasts").firstChild.remove();
  setTimeout(() => t.remove(), tipo === "err" ? 5000 : 3000);
  if (navigator.vibrate && tipo) navigator.vibrate(tipo === "err" ? [60, 40, 60] : 40);
}

async function api(metodo, ruta, cuerpo) {
  const r = await fetch(ruta, { method: metodo, headers: { "Content-Type": "application/json", "X-Token": S.token || "", "X-Caja-Movil": "1" },
    body: cuerpo !== undefined ? JSON.stringify(cuerpo) : undefined });
  let d = {};
  try { d = await r.json(); } catch (_) { /* vacío */ }
  if (r.status === 401 && !ruta.includes("/login")) { salir(true); throw new Error(d.error || "Sesión caducada"); }
  if (!r.ok) { const e = new Error(d.error || "Error " + r.status); e.status = r.status; e.datos = d; throw e; }
  return d;
}
const accion = (fn) => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message, "err"); } };

function hoja(html) {
  $("#hoja-caja").innerHTML = html;
  $("#hoja").classList.remove("oculto");
  return $("#hoja-caja");
}
const cerrarHoja = () => { $("#hoja").classList.add("oculto"); $("#hoja-caja").innerHTML = ""; };
$("#hoja").addEventListener("click", (e) => { if (e.target.id === "hoja") cerrarHoja(); });

// ------------------------------------------------------------------ acceso
async function inicio() {
  try { S.estado = await api("GET", "/api/estado"); }
  catch (e) { $("#app").innerHTML = `<div class="acceso"><div class="aviso rojo">${esc(e.message)}</div></div>`; return; }
  if (!S.estado.usuario) return vistaAcceso();
  if (!(S.estado.modulos || []).includes("movil")) {
    $("#app").innerHTML = `<div class="acceso"><div class="aviso rojo">El módulo «Caja móvil / tablet» no está incluido en la licencia de este programa.</div>
      <button class="btn bloque" id="m-salir">Salir</button></div>`;
    $("#m-salir").onclick = () => salir();
    return;
  }
  pintar();
}

async function vistaAcceso() {
  let usuarios = [];
  try { usuarios = await api("GET", "/api/usuarios/login"); } catch (_) { /* sigue */ }
  let pin = "";
  $("#app").innerHTML = `<div class="acceso">
    <div class="logo"><div class="p">P</div><div><h2>${esc(S.estado.nombre_parking || "PROYECTO ALLAS")}</h2><span class="suave">Caja móvil</span></div></div>
    ${S.estado.demo ? `<div class="aviso">MODO DEMOSTRACIÓN · usuarios de prueba: ${(S.estado.demo_usuarios || []).map((u) => `${esc(u.usuario)} (PIN ${esc(u.pin)})`).join(", ")}</div>` : ""}
    <label class="campo">Usuario<select class="ent" id="a-usu">${usuarios.map((u) => `<option value="${esc(u.usuario)}" ${u.usuario === S.usuarioSel ? "selected" : ""}>${esc(u.nombre)}</option>`).join("")}</select></label>
    <div class="campo">PIN</div><div class="puntos" id="a-puntos"></div>
    <div class="teclado">${[1, 2, 3, 4, 5, 6, 7, 8, 9, "⌫", 0, "OK"].map((k) => `<button data-k="${k}">${k}</button>`).join("")}</div>
    <div id="a-error"></div></div>`;
  const pintarPuntos = () => { $("#a-puntos").innerHTML = "<i></i>".repeat(pin.length); };
  const entrar = accion(async () => {
    if (!pin) return;
    try {
      const r = await api("POST", "/api/login", { usuario: $("#a-usu").value, pin });
      S.token = r.token; guardar("movil_token", r.token); guardar("movil_usuario", $("#a-usu").value); S.usuarioSel = $("#a-usu").value;
      S.tab = "entrada";
      inicio();
    } catch (e) { pin = ""; pintarPuntos(); $("#a-error").innerHTML = `<div class="aviso rojo">${esc(e.message)}</div>`; if (navigator.vibrate) navigator.vibrate([60, 40, 60]); }
  });
  $$("[data-k]").forEach((b) => (b.onclick = () => {
    const k = b.dataset.k;
    if (k === "⌫") pin = pin.slice(0, -1);
    else if (k === "OK") return entrar();
    else if (pin.length < 12) pin += k;
    pintarPuntos();
  }));
}

async function salir(caducada) {
  if (!caducada) { try { await api("POST", "/api/logout"); } catch (_) { /* da igual */ } }
  S.token = null; guardar("movil_token", null);
  S.estado = null;
  inicio();
}

// ------------------------------------------------------------------ estructura
function pintar() {
  const e = S.estado;
  const oc = e.ocupacion ? `${e.ocupacion.ocupadas} / ${e.ocupacion.capacidad} plazas` : "";
  $("#app").innerHTML = `<header class="cab"><div class="p">P</div>
      <div class="t"><b>${esc(e.nombre_parking)}</b><span>${esc(e.usuario.nombre)} · ${esc(oc)}${e.turno && e.turno.usuario_id !== e.usuario.id ? ` · turno de ${esc(e.turno.usuario_nombre)}` : ""}</span></div>
      ${e.barrera ? '<button id="m-barrera" title="Abrir la barrera">🚧</button>' : ""}
      <button id="m-salir">Salir</button></header>
    ${e.demo ? '<div class="aviso" style="margin:0;border-radius:0">MODO DEMOSTRACIÓN · datos de ejemplo</div>' : ""}
    ${e.licencia && !e.licencia.puede_operar ? `<div class="aviso rojo" style="margin:0;border-radius:0">${esc(e.licencia.mensaje)}</div>` : ""}
    <main id="vista"></main>
    <nav class="pestanas">
      <button data-tab="entrada" class="${S.tab === "entrada" ? "activo" : ""}"><i>⬇</i>Entrada</button>
      <button data-tab="cobrar" class="${S.tab === "cobrar" ? "activo" : ""}"><i>€</i>Cobrar</button>
      <button data-tab="dentro" class="${S.tab === "dentro" ? "activo" : ""}"><i>🅿</i>Dentro</button></nav>`;
  $("#m-salir").onclick = () => salir();
  if ($("#m-barrera")) $("#m-barrera").onclick = accion(async () => {
    await api("POST", "/api/barrera/abrir", { motivo: "desde la caja móvil" });
    toast("Barrera abierta", "ok");
  });
  $$("[data-tab]").forEach((b) => (b.onclick = () => { S.tab = b.dataset.tab; if (S.tab !== "cobrar") S.cobro = null; pintar(); }));
  if (!e.turno) return vistaSinTurno();
  ({ entrada: vistaEntrada, cobrar: vistaCobrar, dentro: vistaDentro })[S.tab]();
}

async function refrescar() {
  try { S.estado = await api("GET", "/api/estado"); } catch (_) { /* sin conexión */ }
}

function vistaSinTurno() {
  const a = S.estado.arqueo || {};
  $("#vista").innerHTML = `<div class="panel"><h2>Caja cerrada</h2>
    <p class="suave">Para registrar entradas y cobrar hay que abrir el turno de caja.</p>
    <label class="campo">Fondo de caja (efectivo inicial)<input class="ent num" id="t-fondo" inputmode="decimal" value="${((a.fondo_predefinido_cent ?? 10000) / 100).toFixed(2).replace(".", ",")}"></label>
    <button class="btn prim bloque xl" id="t-abrir">Abrir turno</button></div>`;
  $("#t-abrir").onclick = accion(async () => {
    const f = aCent($("#t-fondo").value);
    if (f === null || Number.isNaN(f) || f < 0) throw new Error("Fondo no válido");
    const pred = a.fondo_predefinido && a.fondo_predefinido_cent === f ? a.fondo_predefinido : null;
    await api("POST", "/api/turno/abrir", pred && Object.keys(pred).length ? { fondo_cent: f, fondo_desglose: pred } : { fondo_cent: f });
    toast("Turno abierto", "ok");
    await refrescar(); pintar();
  });
}

// ------------------------------------------------------------------ entrada
async function vistaEntrada() {
  let tarifas = [];
  try { tarifas = (await api("GET", "/api/tarifas")).filter((t) => t.activa); } catch (_) { /* usa la de por defecto */ }
  $("#vista").innerHTML = `<div class="panel"><h2 style="margin-bottom:12px">Registrar entrada</h2>
    <label class="campo">Matrícula<span class="con-cam"><input class="ent grande" id="e-mat" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="1234 ABC">
      <button type="button" class="btn cam" id="e-cam" title="Leer la matrícula con la cámara">${ICONO_CAM}</button></span></label>
    ${tarifas.length > 1 ? `<label class="campo">Tarifa<select class="ent" id="e-tarifa">${tarifas.map((t) => `<option value="${t.id}" ${t.por_defecto ? "selected" : ""}>${esc(t.nombre)}</option>`).join("")}</select></label>` : ""}
    <button class="btn ok bloque xl" id="e-ok">Registrar ENTRADA</button>
    <p class="suave" style="font-size:.85rem;margin:10px 0 0">El ticket se imprime en la impresora del PC. Si es un abonado, se reconoce por la matrícula.</p></div>
    <div id="e-res"></div>`;
  const mat = $("#e-mat");
  const registrar = accion(async () => {
    const m = mat.value.trim();
    const cuerpo = { matricula: m || null };
    if ($("#e-tarifa")) cuerpo.tarifa_id = Number($("#e-tarifa").value);
    let tk;
    try { tk = await api("POST", "/api/tickets", cuerpo); }
    catch (e) {
      if (e.status === 409 && /ya figura dentro/.test(e.message)) {
        $("#e-res").innerHTML = `<div class="aviso rojo">${esc(e.message)}</div>`;
        return;
      }
      if (e.status === 423 && e.datos && e.datos.lista_negra) {   // 4.1: lista negra
        const ln = e.datos.lista_negra;
        const puede = ln.modo !== "bloquear" || ["admin", "supervisor"].includes(((S.estado || {}).usuario || {}).rol);
        $("#e-res").innerHTML = `<div class="aviso rojo"><b>⛔ LISTA NEGRA · ${esc(ln.matricula)}</b><br>${esc(ln.motivo)}
          ${puede ? '<div style="margin-top:10px"><button class="btn peligro bloque" id="e-ln-si">Dejar entrar igualmente</button></div>'
            : '<div style="margin-top:8px">Para dejarla entrar hace falta un supervisor.</div>'}</div>`;
        if ($("#e-ln-si")) $("#e-ln-si").onclick = accion(async () => {
          const tk2 = await api("POST", "/api/tickets", { ...cuerpo, lista_negra_ok: true });
          toast(`Entrada registrada: ${tk2.matricula || tk2.codigo}`, "ok");
          $("#e-res").innerHTML = ""; mat.value = ""; mat.focus(); refrescar();
        });
        return;
      }
      throw e;
    }
    toast(tk.mensaje || `Entrada registrada: ${tk.matricula || tk.codigo}`, "ok");
    $("#e-res").innerHTML = `<div class="panel"><div class="aviso verde">${esc(tk.mensaje || "Entrada registrada")}</div>
      <dl class="datos"><dt>Matrícula</dt><dd class="mono">${esc(tk.matricula || "—")}</dd>
      ${tk.codigo ? `<dt>Ticket</dt><dd class="mono">${esc(tk.codigo)}</dd>` : ""}
      <dt>Hora</dt><dd>${hora(tk.entrada)}</dd></dl>
      ${tk.impresion && !tk.impresion.ok ? `<div class="aviso rojo" style="margin-top:10px">No se imprimió: ${esc(tk.impresion.error || "")}</div>` : ""}</div>`;
    mat.value = ""; mat.focus();
    refrescar();
  });
  $("#e-ok").onclick = registrar;
  $("#e-cam").onclick = () => Escaner.abrir({ modo: "matricula", alLeer: (m) => { mat.value = m; mat.focus(); toast(`Matrícula leída: ${m}. Revísela y pulse Registrar.`, "ok"); } });
  mat.onkeydown = (e) => { if (e.key === "Enter") registrar(); };
  mat.focus();
}

// ------------------------------------------------------------------ cobrar
function vistaCobrar() {
  $("#vista").innerHTML = `<div class="panel">
    <label class="campo">Código del ticket, tarjeta o matrícula<input class="ent grande" id="c-cod" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="Escriba aquí"></label>
    <button class="btn prim bloque" id="c-buscar">Buscar</button>
    <div class="fila-cam"><button class="btn bloque" id="c-cam">${ICONO_CAM} Escanear ticket o tarjeta</button>
      <button class="btn bloque" id="c-cam-mat">${ICONO_CAM} Leer matrícula</button></div></div><div id="c-res"></div>`;
  const cod = $("#c-cod");
  const buscar = accion(async () => {
    const v = cod.value.trim();
    if (!v) return;
    await buscarYMostrar(v);
  });
  $("#c-buscar").onclick = buscar;
  const leido = (t) => { cod.value = t; buscar(); };
  $("#c-cam").onclick = () => Escaner.abrir({ modo: "codigo", alLeer: leido });
  $("#c-cam-mat").onclick = () => Escaner.abrir({ modo: "matricula", alLeer: leido });
  cod.onkeydown = (e) => { if (e.key === "Enter") buscar(); };
  if (S.cobro && S.cobro.id) consultarId(S.cobro.id); else cod.focus();
}

async function buscarYMostrar(texto) {
  try {
    const r = await api("GET", "/api/tickets/consultar?codigo=" + encodeURIComponent(texto));
    return mostrarConsulta(r);
  } catch (e) {
    if (e.status && e.status !== 404 && e.status !== 400) throw e;
  }
  // no es un código: buscar por matrícula entre los vehículos que están dentro
  const lista = await api("GET", "/api/dentro?buscar=" + encodeURIComponent(texto));
  if (lista.length === 1) return consultarId(lista[0].id);
  if (!lista.length) { $("#c-res").innerHTML = `<div class="aviso rojo">No se encuentra «${esc(texto)}» dentro del parking.</div>`; return; }
  $("#c-res").innerHTML = `<div class="lista">${lista.map(itemDentro).join("")}</div>`;
  $$("[data-id]", $("#c-res")).forEach((b) => (b.onclick = accion(() => consultarId(Number(b.dataset.id)))));
}

async function consultarId(id) {
  const r = await api("GET", "/api/tickets/consultar?id=" + id);
  return mostrarConsulta(r);
}

function mostrarConsulta(r) {
  const res = $("#c-res");
  if (!res) return;
  if (r.tipo === "abonado") return mostrarAbonado(r);
  const t = r, l = t.liquidacion;
  S.cobro = { id: t.id };
  const pend = l ? l.pendiente_cent : 0;
  const foto = t.foto_vehiculo && t.foto_cliente_id ? `<img class="foto-veh" src="/api/clientes/${t.foto_cliente_id}/vehiculos/${encodeURIComponent(t.matricula)}/foto?token=${encodeURIComponent(S.token)}&v=${encodeURIComponent(t.foto_vehiculo)}" alt="">` : "";
  res.innerHTML = `<div class="panel">${foto}
    ${t.lista_negra ? `<div class="aviso rojo" style="margin-bottom:10px"><b>⛔ LISTA NEGRA</b><br>${esc(t.lista_negra.motivo)}</div>` : ""}
    <dl class="datos">
      ${t.cliente_nombre ? `<dt>Abonado</dt><dd>${esc(t.cliente_nombre)}</dd>` : ""}
      <dt>Matrícula</dt><dd class="mono">${esc(t.matricula || "—")}</dd>
      <dt>Ticket</dt><dd class="mono">${esc(t.codigo)}</dd>
      <dt>Entrada</dt><dd>${fechaHora(t.entrada)}</dd>
      <dt>Estancia</dt><dd>${l ? duracion(l.minutos) : "—"}</dd>
      <dt>Tarifa</dt><dd>${esc(t.tarifa_nombre || "")}</dd>
      ${l && l.reserva ? `<dt>Reserva hasta</dt><dd>${fechaHora(l.reserva.hasta)}${l.reserva.ref ? ` · ${esc(l.reserva.ref)}` : ""}</dd>` : ""}</dl>
    ${t.mensaje ? `<div class="aviso ${pend === 0 ? "verde" : ""}" style="margin-top:12px">${esc(t.mensaje)}</div>` : ""}
    ${l ? `<div class="total ${pend === 0 ? "cero" : ""}"><div class="t">${pend ? "A pagar" : "Nada que pagar"}</div><div class="v num">${eur(pend)}</div>
      ${l.extras_pendientes_cent ? `<div class="t">incluye ${eur(l.extras_pendientes_cent)} de servicios</div>` : ""}</div>` : ""}
    <div id="c-acc"></div></div>`;
  const acc = $("#c-acc");
  if (!l) { acc.innerHTML = `<button class="btn bloque" id="c-otro">Buscar otro</button>`; $("#c-otro").onclick = nuevoCobro; return; }
  if (pend > 0) {
    acc.innerHTML = `<div class="dos"><button class="btn ok xl" id="c-efe">💶 Efectivo</button><button class="btn prim xl" id="c-tar">💳 Tarjeta</button></div>`;
    $("#c-efe").onclick = () => hojaEfectivo(t, pend);
    $("#c-tar").onclick = accion(() => cobrar(t, "tarjeta", null));
  } else {
    acc.innerHTML = `<button class="btn ok bloque xl" id="c-salida">Dar SALIDA</button>`;
    $("#c-salida").onclick = accion(async () => {
      await api("POST", `/api/tickets/${t.id}/salida`);
      toast("Salida registrada", "ok");
      nuevoCobro(); refrescar();
    });
  }
}

function hojaEfectivo(t, pend) {
  const sugeridos = [...new Set([pend, Math.ceil(pend / 500) * 500, Math.ceil(pend / 1000) * 1000, Math.ceil(pend / 2000) * 2000, 5000])]
    .filter((x) => x >= pend).slice(0, 4);
  const h = hoja(`<h2>Cobro en efectivo · ${eur(pend)}</h2>
    <label class="campo" style="margin-top:12px">Entregado<input class="ent grande num" id="h-ent" inputmode="decimal" placeholder="${(pend / 100).toFixed(2).replace(".", ",")}"></label>
    <div class="importes">${sugeridos.map((x) => `<button class="btn" data-imp="${x}">${x === pend ? "Justo" : eur(x)}</button>`).join("")}</div>
    <div class="cambio" id="h-cambio"></div>
    <div class="dos"><button class="btn" id="h-no">Cancelar</button><button class="btn ok" id="h-ok">Cobrar</button></div>`);
  const ent = $("#h-ent", h);
  const calc = () => {
    const v = ent.value.trim() ? aCent(ent.value) : pend;
    $("#h-cambio", h).innerHTML = Number.isNaN(v) || v === null ? "" : v < pend ? `<span style="color:var(--rojo)">Faltan ${eur(pend - v)}</span>` : `Cambio: ${eur(v - pend)}`;
  };
  ent.oninput = calc; calc();
  $$("[data-imp]", h).forEach((b) => (b.onclick = () => { ent.value = (Number(b.dataset.imp) / 100).toFixed(2).replace(".", ","); calc(); }));
  $("#h-no", h).onclick = cerrarHoja;
  $("#h-ok", h).onclick = accion(async () => {
    const v = ent.value.trim() ? aCent(ent.value) : pend;
    if (v === null || Number.isNaN(v) || v < pend) throw new Error("El importe entregado no llega");
    await cobrar(t, "efectivo", v);
  });
}

async function cobrar(t, metodo, entregado) {
  let dref = null;
  const pend = t.liquidacion ? t.liquidacion.pendiente_cent : 0;
  if (metodo === "tarjeta" && S.estado.datafono && pend > 0) {   // 3.9: datáfono integrado
    hoja(`<div style="text-align:center;padding:20px 0"><div style="font-size:3rem">💳</div><h2>Pase la tarjeta por el datáfono</h2>
      <p class="suave">${eur(pend)} · esperando respuesta…</p></div>`);
    let r;
    try { r = await api("POST", "/api/datafono/cobrar", { importe_cent: pend, referencia: t.codigo }); }
    finally { cerrarHoja(); }
    if (!r.ok) throw new Error("Datáfono: " + (r.mensaje || "operación no aprobada"));
    dref = r.autorizacion || "OK";
  }
  const r = await api("POST", `/api/tickets/${t.id}/cobrar`, { metodo, entregado_cent: entregado, calculo_en: t.calculo_en, datafono_ref: dref });
  cerrarHoja();
  const cambio = r.pago && r.pago.cambio_cent;
  $("#c-res").innerHTML = `<div class="panel"><div class="total cero"><div class="t">Cobrado ${metodo === "efectivo" ? "en efectivo" : "con tarjeta"}</div>
      <div class="v num">${eur(r.pago ? r.pago.importe_cent : 0)}</div>${cambio ? `<div class="t" style="font-size:1.3rem;opacity:1">Cambio: <b>${eur(cambio)}</b></div>` : ""}</div>
    <div class="aviso verde">${r.salida ? "Salida registrada." : r.salida_limite ? "Puede salir hasta las " + hora(r.salida_limite) + "." : ""}</div>
    ${r.impresion && !r.impresion.ok ? `<div class="aviso rojo">El recibo no se imprimió: ${esc(r.impresion.error || "")}</div>` : ""}
    <button class="btn prim bloque" id="c-otro">Siguiente cobro</button></div>`;
  $("#c-otro").onclick = nuevoCobro;
  toast("Cobro registrado", "ok");
  refrescar();
}

function nuevoCobro() { S.cobro = null; S.tab = "cobrar"; pintar(); }

function mostrarAbonado(r) {
  const c = r.cliente, b = r.bono || {};
  S.cobro = null;
  if (r.dentro) return mostrarConsulta(r.dentro);
  $("#c-res").innerHTML = `<div class="panel"><h2>${esc(c.nombre)}</h2>
    <p class="suave">Tarjeta de abonado · <span class="mono">${esc(c.codigo)}</span></p>
    <div class="aviso ${r.vigente ? "verde" : "rojo"}">${r.vigente ? `Bono vigente${b.hasta ? " hasta el " + new Date(b.hasta + "T12:00").toLocaleDateString("es-ES") : ""}` : "Sin bono vigente: renuévelo en la caja del PC."}</div>
    ${r.vigente && c.activo ? `${c.vehiculos.length > 1 ? `<label class="campo">Vehículo<select class="ent" id="ab-mat">${c.vehiculos.map((v) => `<option>${esc(v.matricula)}</option>`).join("")}</select></label>` : ""}
      <button class="btn ok bloque xl" id="ab-ent">Registrar ENTRADA</button>` : ""}</div>`;
  if ($("#ab-ent")) $("#ab-ent").onclick = accion(async () => {
    const tk = await api("POST", `/api/clientes/${c.id}/entrada`, { matricula: $("#ab-mat") ? $("#ab-mat").value : null });
    toast(tk.mensaje || "Entrada registrada", "ok");
    nuevoCobro(); refrescar();
  });
}

// ------------------------------------------------------------------ dentro
const itemDentro = (v) => `<button class="item" data-id="${v.id}"><span class="mat">${esc(v.matricula || "—")}</span>
  <span class="info">${hora(v.entrada)} · ${duracion(v.minutos)}${v.cliente_nombre ? `<br>${esc(v.cliente_nombre)}` : ""}</span>
  ${v.cliente_id ? '<span class="etq">Abonado</span>' : v.estado === "pagado" ? '<span class="etq verde">Pagado</span>' : ""}</button>`;

async function vistaDentro() {
  $("#vista").innerHTML = `<input class="ent" id="d-buscar" placeholder="Buscar matrícula o cliente" autocapitalize="characters" style="margin-bottom:12px"><div id="d-lista" class="lista"><div class="cargando">Cargando…</div></div>`;
  const cargar = accion(async () => {
    const lista = await api("GET", "/api/dentro?buscar=" + encodeURIComponent($("#d-buscar").value.trim()));
    $("#d-lista").innerHTML = lista.length ? lista.map(itemDentro).join("") : `<div class="cargando">No hay vehículos dentro.</div>`;
    $$("[data-id]", $("#d-lista")).forEach((b) => (b.onclick = () => { S.cobro = { id: Number(b.dataset.id) }; S.tab = "cobrar"; pintar(); }));
  });
  let tm;
  $("#d-buscar").oninput = () => { clearTimeout(tm); tm = setTimeout(cargar, 250); };
  cargar();
}

setInterval(async () => {
  if (!S.token || !S.estado || !S.estado.usuario) return;
  const antes = !!S.estado.turno;
  await refrescar();
  if (S.estado && S.estado.usuario && antes !== !!S.estado.turno) pintar();
}, 30000);

inicio();
