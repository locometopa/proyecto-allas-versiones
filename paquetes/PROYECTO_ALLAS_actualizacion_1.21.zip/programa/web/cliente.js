/* PROYECTO ALLAS · pantalla de cliente.
   Recibe de la ventana de caja (mismo navegador) lo que se está cobrando por un BroadcastChannel;
   cuando no hay operación muestra la publicidad del parking. */
"use strict";

const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const eur = (c) => (c / 100).toLocaleString("es-ES", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " €";

const PC = { cfg: null, diapo: 0, timerAnuncio: null, timerVolver: null, ultimo: null, version: null, previa: null };
// 4.5: ?vista=1 → vista previa dentro de Ajustes (con los cambios aún sin guardar que manda la ventana de caja)
const VISTA = new URLSearchParams(location.search).has("vista");
if (VISTA) document.documentElement.classList.add("vista-previa");

// ------------------------------------------------------------------ configuración y publicidad
async function cargarConfig() {
  try {
    const r = await fetch("/api/pantalla-cliente", { cache: "no-store" });
    const cfg = Object.assign(await r.json(), PC.previa || {});
    if (VISTA) cfg.activa = true;
    // tras una actualización del programa, la ventana se recarga sola con la versión nueva
    if (PC.version && cfg.version && cfg.version !== PC.version && !VISTA) return location.reload();
    PC.version = cfg.version;
    const firma = (c) => c && JSON.stringify([c.anuncios, c.segundos, c.transicion, c.transicion_ms, c.aleatorio, c.progreso]);
    const cambian = firma(cfg) !== firma(PC.cfg);
    PC.cfg = cfg;
    aplicarEstilo(cfg);
    document.title = `${cfg.nombre_parking || "Parking"} · pantalla de cliente`;
    $("#pie-nombre").textContent = cfg.nombre_parking || "";
    $("#b-nombre").textContent = cfg.nombre_parking || "";
    $("#b-texto").textContent = cfg.bienvenida || "";
    let des = $("#desactivada");
    if (!cfg.activa && !des) {
      des = document.createElement("div");
      des.id = "desactivada"; des.className = "desactivada";
      des.innerHTML = "La pantalla de cliente está desactivada.<br>Actívela en Ajustes → Equipos → Pantalla de cliente.";
      document.body.appendChild(des);
    } else if (cfg.activa && des) des.remove();
    if (cambian || PC.faltan) pintarAnuncios();   // y si alguna foto falló, se reintenta en cada vuelta
  } catch (_) { /* el servidor no responde: se reintenta */ }
}

// 4.4: transición, duración, orden, encaje, rótulo, tema, color, movimiento, barra de progreso y pie
function aplicarEstilo(c) {
  const b = document.body;
  ["t-fundido", "t-deslizar", "t-zoom", "t-ninguna", "ajuste-completa", "rotulo-arriba", "rotulo-oculto", "tema-claro", "sin-pie", "movimiento", "con-progreso"]
    .forEach((k) => b.classList.remove(k));
  b.classList.add("t-" + (c.transicion || "fundido"));
  if (c.ajuste === "completa") b.classList.add("ajuste-completa");
  if (c.rotulo === "arriba" || c.rotulo === "oculto") b.classList.add("rotulo-" + c.rotulo);
  if (c.tema === "claro") b.classList.add("tema-claro");
  if (c.pie === false) b.classList.add("sin-pie");
  if (c.movimiento) b.classList.add("movimiento");
  if (c.progreso) b.classList.add("con-progreso");
  b.style.setProperty("--ms", (c.transicion_ms || 1000) + "ms");
  b.style.setProperty("--seg", (c.segundos || 8) + "s");
  if (c.color) b.style.setProperty("--azul", c.color); else b.style.removeProperty("--azul");
}

function siguienteAnuncio(n) {
  if (!PC.cfg.aleatorio || n < 3) return (PC.diapo + 1) % n;
  let i;
  do { i = Math.floor(Math.random() * n); } while (i === PC.diapo);
  return i;
}

function reiniciarProgreso() {
  const p = $("#progreso");
  if (!p) return;
  p.classList.remove("corre");
  void p.offsetWidth;   // reinicia la animación
  p.classList.add("corre");
}

// 4.13: las fotos se descargan antes (fetch → blob) y solo se enseñan las que han cargado de verdad;
// si alguna falla se reintenta sola y se muestra el motivo en la pantalla de bienvenida
PC.fotos = PC.fotos || {};     // "id:actualizado" → URL local de la foto ya descargada
PC.errores = PC.errores || {}; // id → motivo del último fallo
const urlFoto = (a) => `/api/pantalla-cliente/foto/${a.id}?v=${encodeURIComponent(a.actualizado)}`;
const claveFoto = (a) => `${a.id}:${a.actualizado}`;

async function descargarFoto(a) {
  const k = claveFoto(a);
  if (PC.fotos[k]) return true;
  try {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 12000);
    const r = await fetch(urlFoto(a), { cache: "reload", signal: ctl.signal }); clearTimeout(t);
    if (!r.ok) throw new Error("el servidor respondió " + r.status);
    const b = await r.blob();
    if (!b.size) throw new Error("la foto llegó vacía");
    // se comprueba que el navegador sabe dibujarla
    const u = URL.createObjectURL(b);
    await new Promise((ok, mal) => { const im = new Image(); im.onload = ok; im.onerror = () => mal(new Error("formato de imagen no válido")); im.src = u; });
    PC.fotos[k] = u; delete PC.errores[a.id];
    return true;
  } catch (e) {
    PC.errores[a.id] = (e && e.name === "AbortError") ? "tardó demasiado" : (e && e.message) || "error";
    return false;
  }
}

function estadoFotos(lista, cargadas) {
  const el = $("#b-fotos"); if (!el) return;
  const fallan = lista.length - cargadas;
  el.textContent = !lista.length ? "No hay fotos de publicidad activas. Se añaden en Ajustes → Equipos → Pantalla de cliente." : fallan > 0 ? `No se han podido cargar ${fallan} de ${lista.length} foto(s): ${Object.values(PC.errores)[0] || "sin respuesta"}. Se reintenta solo.` : "";
}

async function pintarAnuncios() {
  const lista = (PC.cfg && PC.cfg.anuncios) || [];
  const marca = PC.pintando = (PC.pintando || 0) + 1;
  const ok = await Promise.all(lista.map(descargarFoto));
  if (marca !== PC.pintando) return;   // llegó otra configuración mientras se descargaba
  const cargadas = lista.filter((_, i) => ok[i]);
  PC.faltan = cargadas.length < lista.length;
  const vigentes = new Set(lista.map(claveFoto));
  Object.keys(PC.fotos).forEach((k) => { if (!vigentes.has(k)) { URL.revokeObjectURL(PC.fotos[k]); delete PC.fotos[k]; } });
  estadoFotos(lista, cargadas.length);
  $("#diapos").innerHTML = cargadas.map((a, i) => `<div class="diapo ${i === 0 ? "activo" : ""}">
      <img src="${PC.fotos[claveFoto(a)]}" alt="">
      ${a.titulo || a.texto ? `<div class="rotulo">${a.titulo ? `<h2>${esc(a.titulo)}</h2>` : ""}${a.texto ? `<p>${esc(a.texto)}</p>` : ""}</div>` : ""}</div>`).join("")
    + (cargadas.length > 1 ? '<div class="progreso" id="progreso"></div>' : "");
  $("#bienvenida").classList.toggle("oculto", cargadas.length > 0);
  PC.diapo = 0;
  clearInterval(PC.timerAnuncio);
  if (cargadas.length > 1) {
    reiniciarProgreso();
    PC.timerAnuncio = setInterval(() => {
      const els = document.querySelectorAll(".diapo");
      if (!els.length) return;
      const actual = els[PC.diapo % els.length];
      actual.classList.remove("activo");
      actual.classList.add("saliendo");
      const ms = (PC.cfg.transicion_ms || 1000) + 50;
      setTimeout(() => {   // vuelve a su sitio sin animación (para «deslizar»)
        actual.classList.add("sin-trans"); actual.classList.remove("saliendo");
        void actual.offsetWidth; actual.classList.remove("sin-trans");
      }, ms);
      PC.diapo = siguienteAnuncio(els.length);
      els[PC.diapo].classList.add("activo");
      reiniciarProgreso();
    }, (PC.cfg.segundos || 8) * 1000);
  }
}

// ------------------------------------------------------------------ operaciones
const matricula = (m) => (m ? `<div class="matricula"><span class="ue">E</span><span class="txt">${esc(m)}</span></div>` : "");

function bloqueCambio(d) {
  if (d.metodo !== "efectivo" || d.entregado_cent == null) return d.metodo === "tarjeta" ? `<div class="desglose-pc"><div><span>Pago con tarjeta</span><span>💳</span></div></div>` : "";
  const dif = d.entregado_cent - d.total_cent;
  return `<div class="cambio-pc"><div><div class="k">Entregado</div><div class="v num">${eur(d.entregado_cent)}</div></div>
    <div><div class="k">${dif >= 0 ? "Cambio" : "Faltan"}</div><div class="v num ${dif >= 0 ? "verde" : "ambar"}">${eur(Math.abs(dif))}</div></div></div>`;
}

function pintar(d) {
  const op = $("#operacion");
  clearTimeout(PC.timerVolver);
  if (!d || d.tipo === "libre") {
    $("#operacion").classList.remove("visible");
    $("#libre").classList.add("visible");
    return;
  }
  if (d.tipo === "cobro") {
    const datos = [["Entrada", d.entrada], ["Tiempo", d.tiempo], ["Tarifa", d.tarifa]].filter((x) => x[1]);
    op.innerHTML = `<div class="escena">
        <div class="etiqueta">Salida de vehículo</div>
        ${matricula(d.matricula)}
        ${datos.length ? `<div class="fichas">${datos.map((x) => `<div class="ficha"><span class="k">${x[0]}</span><span class="v num">${esc(x[1])}</span></div>`).join("")}</div>` : ""}
        <div class="banda-total">
          <div class="bt-total"><div class="t">${d.total_cent ? "Total a pagar" : "Nada que pagar"}</div><div class="v num">${eur(d.total_cent)}</div></div>
          <div class="bt-resto">
            ${(d.lineas || []).length ? `<div class="desglose-pc">${d.lineas.map((l) => `<div class="${l.dto ? "dto" : ""}"><span>${esc(l.concepto)}</span><span class="num">${l.dto ? "−" : ""}${eur(Math.abs(l.importe_cent))}</span></div>`).join("")}</div>` : ""}
            ${bloqueCambio(d)}
          </div>
        </div></div>`;
  } else if (d.tipo === "tienda") {
    op.innerHTML = `<div class="op-izq"><div class="op-titulo">Su compra</div>
        <div class="lineas-pc">${(d.lineas || []).map((l) => `<div><span><span class="c">${l.cantidad} ×</span>${esc(l.concepto)}</span><span class="num">${eur(l.importe_cent)}</span></div>`).join("")}</div></div>
      <div class="op-der"><div class="total-pc"><div class="t">Total a pagar</div><div class="v num">${eur(d.total_cent)}</div></div>
        ${d.descuento_cent ? `<div class="desglose-pc"><div><span>Subtotal</span><span class="num">${eur(d.total_cent + d.descuento_cent)}</span></div>
          <div class="dto"><span>${esc(d.descuento_nombre || "Descuento")}</span><span class="num">−${eur(d.descuento_cent)}</span></div></div>` : ""}
        ${bloqueCambio(d)}</div>`;
  } else if (d.tipo === "gracias") {
    op.innerHTML = `<div class="centro-pc"><div class="icono-ok">✓</div><h1>${esc((PC.cfg && PC.cfg.gracias) || "¡Gracias!")}</h1>
      ${d.cambio_cent ? `<p>Su cambio</p><div class="grande num">${eur(d.cambio_cent)}</div>` : d.total_cent ? `<p>Pagado ${eur(d.total_cent)}</p>` : ""}
      ${d.salida ? `<p>${esc(d.salida)}</p>` : ""}</div>`;
    PC.timerVolver = setTimeout(() => pintar({ tipo: "libre" }), (d.segundos || 8) * 1000);
  } else if (d.tipo === "entrada") {
    op.innerHTML = `<div class="escena">
        <div class="etiqueta">Entrada de vehículo</div>
        <h1 class="saludo">${esc((PC.cfg && PC.cfg.bienvenida) || "Bienvenido")}</h1>
        ${matricula(d.matricula)}
        <div class="fichas">${d.hora ? `<div class="ficha"><span class="k">Hora de entrada</span><span class="v num">${esc(d.hora)}</span></div>` : ""}</div>
        <div class="pastilla">🎫 Recoja su ticket</div></div>`;
    PC.timerVolver = setTimeout(() => pintar({ tipo: "libre" }), 7000);
  }
  $("#libre").classList.remove("visible");
  op.classList.add("visible");
  // si la caja deja de enviar (p. ej. se cerró), volver a la publicidad pasados 3 minutos
  if (d.tipo === "cobro" || d.tipo === "tienda") PC.timerVolver = setTimeout(() => pintar({ tipo: "libre" }), 180000);
}

// ------------------------------------------------------------------ arranque
const canal = "BroadcastChannel" in window ? new BroadcastChannel("proyecto-allas-cliente") : null;
if (canal) canal.onmessage = (e) => {
  if (e.data && e.data.tipo === "config") return cargarConfig();   // se guardó algo en Ajustes: aplicarlo ya
  if (VISTA || (e.data && e.data.tipo === "hola")) return;
  PC.ultimo = e.data; pintar(e.data);
};
window.addEventListener("message", (e) => {   // vista previa: estilo sin guardar
  if (e.origin !== location.origin || !e.data || e.data.tipo !== "previa") return;
  PC.previa = e.data.estilo || null;
  PC.cfg = null;
  cargarConfig();
});
window.addEventListener("storage", (e) => {   // alternativa si el navegador no tiene BroadcastChannel
  if (e.key === "allas_pantalla_cliente" && e.newValue) { try { pintar(JSON.parse(e.newValue).d); } catch (_) { /* nada */ } }
});

function reloj() {
  const d = new Date();
  $("#pie-reloj").textContent = d.toLocaleDateString("es-ES", { weekday: "long", day: "numeric", month: "long" }) + " · " +
    d.toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
}
reloj(); setInterval(reloj, 15000);
cargarConfig(); setInterval(cargarConfig, 12000);
if (canal && !VISTA) canal.postMessage({ tipo: "hola" });   // pide a la caja el estado actual

document.addEventListener("click", () => {
  if (VISTA) return;
  if (!document.fullscreenElement && document.documentElement.requestFullscreen) document.documentElement.requestFullscreen().catch(() => {});
});
setTimeout(() => $("#aviso-pc").classList.add("fuera"), 7000);
