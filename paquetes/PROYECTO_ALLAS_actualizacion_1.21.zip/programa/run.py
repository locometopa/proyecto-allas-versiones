#!/usr/bin/env python3
"""Arranque del sistema de parking.

    python run.py                 # http://127.0.0.1:8080 (o el puerto libre elegido al instalar)
    python run.py --abrir         # además abre el navegador
    python run.py --host 0.0.0.0  # permitir acceso desde otro PC de la red local
"""
import argparse
import os
import sys
import traceback
import webbrowser

RAIZ = os.path.dirname(os.path.abspath(__file__))
# 3.2: con pythonw.exe (ARRANCAR.bat) no hay ventana: lo que se escribiría en ella va a datos/servidor.log
OCULTO = sys.stdout is None or sys.stderr is None


def registro_a_archivo(carpeta):
    """Sin ventana, los mensajes se guardan en <datos>/servidor.log (se rota al pasar de 2 MB)."""
    os.makedirs(carpeta, exist_ok=True)
    ruta = os.path.join(carpeta, "servidor.log")
    try:
        if os.path.getsize(ruta) > 2_000_000:
            os.replace(ruta, ruta + ".1")
    except OSError:
        pass
    f = open(ruta, "a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stderr = f
    return ruta


def mensaje_windows(texto, titulo="PROYECTO ALLAS"):
    """Sin ventana, un error de arranque se muestra en un cuadro de mensaje de Windows."""
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, texto[:1800], titulo, 0x10)
        except Exception:
            pass


def pausa():
    """En Windows, si se abrió con doble clic, no cerrar la ventana sin dejar leer el error."""
    if os.name == "nt" and not OCULTO:
        try:
            input("\nPulse Intro para cerrar esta ventana...")
        except EOFError:
            pass


def fallo(msg):
    if OCULTO:
        if sys.stdout is None:
            try:
                registro_a_archivo(os.path.join(RAIZ, "datos"))
            except OSError:
                pass
        mensaje_windows("No se ha podido arrancar PROYECTO ALLAS:\n\n" + msg)
    print("\n" + "=" * 60 + "\n  NO SE HA PODIDO ARRANCAR PROYECTO ALLAS\n" + "=" * 60)
    print(msg)
    pausa()
    sys.exit(1)


def comprobaciones_previas():
    if sys.version_info < (3, 9):
        fallo(f"Tiene Python {sys.version.split()[0]} y se necesita 3.9 o superior.\n"
              "Descargue Python 3.11 o superior de python.org.")
    r = RAIZ.lower()
    if ".zip" in r:
        fallo("Parece que está ejecutando el programa DESDE DENTRO DEL ZIP.\n"
              "Haga clic derecho en parking.zip > 'Extraer todo...', y ejecute\n"
              "ARRANCAR.bat desde la carpeta extraída.")
    for necesario in ("app", "web"):
        if not os.path.isdir(os.path.join(RAIZ, necesario)):
            fallo(f"Falta la carpeta '{necesario}' junto a run.py ({RAIZ}).\n"
                  "Extraiga el zip completo, sin mover archivos sueltos.")
    try:
        prueba = os.path.join(RAIZ, ".prueba_escritura")
        with open(prueba, "w") as f:
            f.write("ok")
        os.remove(prueba)
    except OSError:
        fallo(f"No se puede escribir en {RAIZ}.\n"
              "Copie la carpeta a un sitio con permisos, por ejemplo C:\\parking")


def parking_en_marcha(datos, puerto_base):
    """Devuelve el puerto de un parking que ya esté respondiendo, o None."""
    import json
    import urllib.request
    puertos = []
    for nombre in ("puerto.txt", "puerto_preferido.txt"):   # 4.8: y el elegido en la instalación
        try:
            with open(os.path.join(datos, nombre)) as f:
                p = int(f.read().strip())
            if p not in puertos:
                puertos.append(p)
        except (OSError, ValueError):
            pass
    puertos += [p for p in range(puerto_base, puerto_base + 10) if p not in puertos]
    for p in puertos:
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{p}/api/estado", timeout=0.4) as r:
                if "primer_arranque" in json.loads(r.read()):
                    return p
        except Exception:
            continue
    return None


PUERTOS_CANDIDATOS = [8080, 8090, 8765, 18080, 28080, 38080, 47080]


def puerto_libre(puerto, host="127.0.0.1"):
    """4.8: el puerto no lo usa nadie (nadie responde en él y se puede abrir en exclusiva)."""
    import socket
    from app.server import puerto_en_uso
    if puerto_en_uso(puerto):
        return False
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        excl = getattr(socket, "SO_EXCLUSIVEADDRUSE", None)
        if os.name == "nt" and excl is not None:
            s.setsockopt(socket.SOL_SOCKET, excl, 1)
        s.bind((host, puerto))
        return True
    except OSError:
        return False
    finally:
        s.close()


def puerto_preferido(datos, host="127.0.0.1"):
    """4.8: puerto en el que arranca siempre este parking. En la primera instalación se comprueba qué
    puertos están libres (otro programa podría estar usando el 8080) y se guarda el primero que lo esté
    en datos/puerto_preferido.txt. Devuelve (puerto, aviso o None)."""
    ruta = os.path.join(datos, "puerto_preferido.txt")
    try:
        with open(ruta) as f:
            p = int(f.read().strip())
        if 0 < p < 65536:
            return p, None
    except (OSError, ValueError):
        pass
    ocupados = []
    for p in PUERTOS_CANDIDATOS:
        if puerto_libre(p, host):
            break
        ocupados.append(p)
    else:
        return PUERTOS_CANDIDATOS[0], "Ninguno de los puertos habituales está libre: se buscará otro."
    try:
        with open(ruta, "w") as f:
            f.write(str(p))
    except OSError:
        pass
    aviso = f"Primera instalación: se usará el puerto {p}."
    if ocupados:
        aviso += " Ya los usa otro programa: " + ", ".join(map(str, ocupados)) + "."
    return p, aviso


def main():
    ap = argparse.ArgumentParser(description="PROYECTO ALLAS - gestión y cobro de parking")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--puerto", type=int, default=None, help="puerto (por defecto, el elegido en la instalación)")
    ap.add_argument("--datos", default="datos", help="carpeta de base de datos y copias")
    ap.add_argument("--abrir", action="store_true", help="abrir el navegador al arrancar")
    ap.add_argument("--hijo", action="store_true", help=argparse.SUPPRESS)          # 4.4: lo arranca el vigilante
    ap.add_argument("--sin-vigilante", action="store_true", help="no reiniciar solo si se cae")
    a = ap.parse_args()

    os.chdir(RAIZ)
    archivo_log = registro_a_archivo(a.datos) if OCULTO else None
    comprobaciones_previas()
    os.makedirs(a.datos, exist_ok=True)
    if OCULTO:
        from datetime import datetime
        print(f"\n----- {datetime.now():%d/%m/%Y %H:%M:%S} · arranque sin ventana -----")

    # ¿Ya hay un parking en marcha (p. ej. de un intento anterior)? Entonces no arrancamos otro.
    previo = parking_en_marcha(a.datos, a.puerto or PUERTOS_CANDIDATOS[0])
    if previo:
        url = f"http://127.0.0.1:{previo}"
        with open(os.path.join(a.datos, "puerto.txt"), "w") as f:
            f.write(str(previo))
        print(f"El parking YA estaba en marcha en {url} (no se arranca otro).")
        if a.abrir:
            webbrowser.open(url)
        return

    sys.path.insert(0, RAIZ)
    from app.backup import hacer_backup, programar_copias
    from app.db import Database
    from app.server import App, servir
    from app.servicios import Parking

    # 3.4: modo demostración = otra carpeta de datos (<datos>/demo); los datos reales no se abren
    from app import demo as demo_mod
    modo_demo = demo_mod.activa(a.datos)
    carpeta = demo_mod.carpeta_demo(a.datos) if modo_demo else a.datos
    if modo_demo:
        os.makedirs(carpeta, exist_ok=True)
        demo_mod.instalar_nueva(carpeta)
        print("  MODO DEMOSTRACIÓN: se usan los datos de ejemplo de", os.path.abspath(carpeta))
    licencia_real = None
    if modo_demo:
        # 3.5: la demo caduca con la licencia (o la prueba) de los datos reales
        import sqlite3
        try:
            con = sqlite3.connect(f"file:{os.path.abspath(os.path.join(a.datos, 'parking.db'))}?mode=ro", uri=True)
            cfgr = dict(con.execute("SELECT clave, valor FROM config WHERE clave IN "
                                    "('licencia_serial','fecha_instalacion','licencia_comprobante')"))
            con.close()
            licencia_real = (cfgr.get("licencia_serial"), cfgr.get("fecha_instalacion"), cfgr.get("licencia_comprobante"))
        except Exception:
            licencia_real = (None, None)
    db = Database(os.path.join(carpeta, "parking.db"))
    carpeta_backups = os.path.join(carpeta, "backups")
    if os.path.getsize(db.path) > 0:
        try:
            hacer_backup(db, carpeta_backups, int(db.get_cfg("backups_mantener", "30")),
                         db.get_cfg("backup_destino_extra"), tipo="arranque")
        except Exception as e:
            print("Aviso: no se pudo hacer la copia de arranque:", e)
    programar_copias(db, carpeta_backups, os.path.join(carpeta, "logo"))

    # Reintento de facturas por email que quedaron pendientes (p. ej. sin conexión)
    import threading
    import time

    def tareas_periodicas():
        """Cada 10 min: emails pendientes, cobros online (Stripe) y avisos a abonados (una vez al día)."""
        n = 0
        while True:
            time.sleep(60 if n == 0 else 10 * 60)
            n += 1
            try:
                pk = Parking(db, demo=modo_demo, licencia_real=licencia_real)
                pk.reintentar_emails()
                hecho = pk.tarea_periodica()
                if hecho.get("stripe", {}).get("cobros"):
                    print(f"Pagos online: {hecho['stripe']['cobros']} cobro(s) nuevo(s) registrado(s)")
            except Exception as e:
                print("Tarea periódica fallida:", e)
    threading.Thread(target=tareas_periodicas, daemon=True, name="tareas").start()

    # 4.4: comprobación de la base de datos (en segundo plano, solo lectura) y semáforo / cartel LIBRE-COMPLETO
    def integridad():
        time.sleep(5)
        try:
            res = Parking(db, demo=modo_demo, licencia_real=licencia_real).comprobar_integridad()
            print("Base de datos comprobada:", "correcta" if res == "ok" else "¡CON ERRORES! " + res)
        except Exception as e:
            print("No se pudo comprobar la base de datos:", e)
    threading.Thread(target=integridad, daemon=True, name="integridad").start()
    from app.funciones44 import lanzar_vigilancia_senales
    lanzar_vigilancia_senales(lambda: Parking(db, demo=modo_demo, licencia_real=licencia_real))

    # Probar el puerto pedido; si Windows lo tiene ocupado o reservado, otros rangos;
    # y como último recurso, el puerto libre que elija el propio sistema (0).
    app = App(Parking(db, demo=modo_demo, licencia_real=licencia_real), carpeta_backups)
    app.carpeta_base, app.demo = os.path.abspath(a.datos), modo_demo
    # 3.5: caja móvil / tablet → escuchar también en la red local (si no se indicó --host)
    app.red_explicita = a.host not in ("127.0.0.1", "localhost")
    host = a.host
    if not app.red_explicita and db.get_cfg("movil_red") == "1":
        try:
            if app.p.tiene_modulo("movil"):
                host = "0.0.0.0"
                print("  Caja móvil activada: también se puede entrar desde la red local.")
        except Exception as e:
            print("Aviso: no se pudo comprobar el módulo de caja móvil:", e)
    app.host = host
    if not modo_demo:
        # 4.24: al arrancar (tras unos segundos) y luego una vez al día se busca una versión nueva; si la hay, avisa en notificaciones
        def buscar_actualizacion():
            time.sleep(6)
            primera = True
            while True:
                try:
                    f = getattr(app, "comprobar_actualizacion_auto", None)
                    nueva = f(forzar=primera) if f else None   # 4.29: en cada arranque se busca (sin esperar a las 23 h)
                    primera = False
                    if nueva:
                        print(f"Hay una versión nueva disponible: {nueva}")
                except Exception as e:
                    print("No se pudo buscar actualizaciones:", e)
                time.sleep(3600)   # la comprobación se limita sola a una vez cada 23 h
        threading.Thread(target=buscar_actualizacion, daemon=True, name="actualizaciones").start()
    # 4.8: sin --puerto, el puerto elegido (libre) en la primera instalación
    if a.puerto is None:
        a.puerto, aviso = puerto_preferido(a.datos, "127.0.0.1" if host == "0.0.0.0" else host)
        if aviso:
            print(aviso)
    candidatos = [a.puerto] + [p for p in PUERTOS_CANDIDATOS if p != a.puerto] + [0]
    srv, puerto, errores = None, None, []
    for p in candidatos:
        try:
            srv = servir(app, host, p)
            puerto = srv.server_address[1]
            app.puerto = puerto
            break
        except OSError as e:
            errores.append(f"  puerto {p}: {e}")
    if not srv:
        fallo("Windows no deja abrir ningún puerto local:\n" + "\n".join(errores) +
              "\n\nSuele deberse a un antivirus o cortafuegos que bloquea Python.\n"
              "Permita 'python.exe' en el antivirus y vuelva a intentarlo.")
    if errores:
        print("Aviso: algunos puertos no estaban disponibles (otro programa los usa):\n" + "\n".join(errores))

    url = f"http://127.0.0.1:{puerto}"
    with open(os.path.join(a.datos, "puerto.txt"), "w") as f:  # lo lee ARRANCAR.bat
        f.write(str(puerto))
    print("=" * 60)
    from app import VERSION_COMPLETA
    print(f"  {VERSION_COMPLETA} EN MARCHA:  {url}")
    if OCULTO:
        print("  Funcionando sin ventana. Para apagarlo: Ajustes → Sistema → Actualizaciones → Apagar.")
    else:
        print("  Deje esta ventana abierta (puede minimizarla).")
        print("  Para detener el programa, cierre esta ventana o pulse Ctrl+C.")
    print("=" * 60)
    if a.abrir:
        webbrowser.open(url)
    app.srv = srv
    from datetime import datetime as _dt
    app.oculto, app.archivo_log = OCULTO, archivo_log and os.path.abspath(archivo_log)
    app.inicio = _dt.now().astimezone().isoformat(timespec="seconds")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nDeteniendo...")
    finally:
        srv.server_close()
        db.conn.close()
    if app.reiniciar and a.hijo:
        sys.exit(CODIGO_REINICIO)   # 4.4: el vigilante lo vuelve a arrancar (con la versión instalada)
    if app.reiniciar:
        # tras instalar una actualización (o volver a la versión anterior): arrancar el programa nuevo
        print("\nReiniciando PROYECTO ALLAS con la versión instalada...")
        argv, saltar = [], False
        for x in sys.argv:   # sin --abrir ni --puerto anteriores: se vuelve a abrir en el mismo puerto
            if saltar:
                saltar = False
            elif x == "--puerto":
                saltar = True
            elif x != "--abrir" and not x.startswith("--puerto="):
                argv.append(x)
        argv += ["--puerto", str(puerto)]
        if os.name == "nt":
            # en Windows os.execv no admite rutas con espacios: se lanza el nuevo y este termina
            import subprocess
            subprocess.Popen([sys.executable] + argv)
            sys.exit(0)
        os.execv(sys.executable, [sys.executable] + argv)


# ------------------------------------------------------------------ 4.4 · vigilante
# El programa se arranca como un proceso «hijo»; este proceso solo lo vigila: si se cae (error, falta de memoria…)
# o deja de responder, lo vuelve a arrancar en el mismo puerto. Si se apaga desde el programa, termina también.
CODIGO_REINICIO = 75


def _argumento(args, nombre, defecto=None):
    for i, x in enumerate(args):
        if x == nombre and i + 1 < len(args):
            return args[i + 1]
        if x.startswith(nombre + "="):
            return x.split("=", 1)[1]
    return defecto


def _sin(args, nombre, con_valor=True):
    r, saltar = [], False
    for x in args:
        if saltar:
            saltar = False
        elif x == nombre:
            saltar = con_valor
        elif not x.startswith(nombre + "="):
            r.append(x)
    return r


def vigilante():
    import signal
    import subprocess
    import time
    import urllib.request
    args = list(sys.argv[1:])
    datos = os.path.join(RAIZ, _argumento(args, "--datos", "datos")) if not os.path.isabs(_argumento(args, "--datos", "datos")) \
        else _argumento(args, "--datos")
    hijo = None

    def terminar(*_):
        if hijo and hijo.poll() is None:
            hijo.terminate()
            try:
                hijo.wait(10)
            except Exception:
                hijo.kill()
        sys.exit(0)
    for sen in ("SIGTERM", "SIGINT", "SIGBREAK"):
        if hasattr(signal, sen):
            try:
                signal.signal(getattr(signal, sen), terminar)
            except (ValueError, OSError):
                pass
    caidas = []
    while True:
        hijo = subprocess.Popen([sys.executable, os.path.abspath(__file__)] + args + ["--hijo"], cwd=RAIZ)
        rc, fallos_salud, inicio = None, 0, time.time()
        while rc is None:
            try:
                rc = hijo.wait(timeout=30)
                break
            except subprocess.TimeoutExpired:
                pass
            if time.time() - inicio < 90:
                continue   # arrancando (copia de seguridad de arranque, migraciones…)
            try:
                with open(os.path.join(datos, "puerto.txt")) as f:
                    puerto = int(f.read().strip())
                urllib.request.urlopen(f"http://127.0.0.1:{puerto}/api/salud", timeout=20).read()
                fallos_salud = 0
            except Exception:
                fallos_salud += 1
                if fallos_salud >= 4:   # unos 2 minutos sin responder: se reinicia
                    print("El programa no responde: se reinicia.")
                    hijo.kill()
                    rc = hijo.wait()
        if rc == 0:
            return 0
        args = _sin(args, "--abrir", con_valor=False)
        try:
            with open(os.path.join(datos, "puerto.txt")) as f:
                args = _sin(args, "--puerto") + ["--puerto", f.read().strip()]
        except (OSError, ValueError):
            pass
        if rc == CODIGO_REINICIO:
            continue
        try:
            arranco = os.path.getmtime(os.path.join(datos, "puerto.txt")) >= inicio - 1
        except OSError:
            arranco = False
        if not caidas and not arranco:
            return rc   # no ha llegado a arrancar (ya ha explicado el motivo): no se insiste
        ahora = time.time()
        caidas = [t for t in caidas if ahora - t < 600] + [ahora]
        print(f"El programa se ha cerrado inesperadamente (código {rc}). Se vuelve a arrancar ({len(caidas)}/5).")
        if len(caidas) >= 5:
            fallo("PROYECTO ALLAS se ha cerrado 5 veces en 10 minutos y no se vuelve a arrancar.\n"
                  "Mire el archivo datos\\servidor.log o arranque con scripts\\ARRANCAR_CON_VENTANA.bat.")
            return rc
        time.sleep(3)


if __name__ == "__main__":
    if "--hijo" not in sys.argv and "--sin-vigilante" not in sys.argv and os.environ.get("ALLAS_SIN_VIGILANTE") != "1" \
            and not any(x in ("-h", "--help") for x in sys.argv):
        sys.exit(vigilante())
    try:
        main()
    except SystemExit:
        raise
    except Exception:
        fallo(traceback.format_exc())
