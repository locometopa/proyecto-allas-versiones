# PROYECTO ALLAS · gestión y cobro de parking

> **Versiones.** Desde la 1.0 la versión sube según la importancia de los cambios (X.0 cambios grandes, X.Y funciones nuevas, X.Y.Z correcciones). Las referencias «4.xx» de este manual son del desarrollo anterior (ver `docs/HISTORIAL_DESARROLLO_4x.md`).

**Versión 1.0** · historial en [CHANGELOG.md](CHANGELOG.md)

Software de caja para aparcamiento **atendido**, que funciona **en local y sin Internet**, con impresora térmica ESC/POS, lector QR y cajón portamonedas.

![Ticket de entrada](docs/capturas/ticket_entrada.png) ![Factura](docs/capturas/ticket_factura.png)

- Sin dependencias: Python 3.9+ (biblioteca estándar) + navegador. Se instala copiando la carpeta.
- Ticket con **QR y código de barras** (Code128, legible por lectores láser/infrarrojos) · textos del ticket editables con vista previa · **clientes y bonos mensuales** con tarjeta de abonado ·
- Entrada con ticket firmado · cobro por minuto con cortesía y tope diario · efectivo con cálculo de cambio o tarjeta · ticket perdido · turnos con arqueo ciego · factura simplificada con registro encadenado · informes y CSV · copias automáticas · auditoría.

## Puesta en marcha en Windows

1. Instale **Python 3.11 o superior** desde https://www.python.org/downloads/ marcando **"Add python.exe to PATH"**.
2. **Extraiga el zip** (clic derecho > *Extraer todo...*), por ejemplo en `C:\parking`. No lo ejecute desde dentro del zip.
3. Doble clic en **`ARRANCAR.bat`**. Se abre la ventana de la caja; el *servidor* funciona en segundo plano, **sin ventana**.

El servidor se apaga o reinicia desde *Ajustes → Sistema → Actualizaciones → Servidor del programa* (pide el PIN). Sus mensajes se guardan en `datos\servidor.log`, y si no puede arrancar lo avisa con un cuadro de mensaje de Windows. Para verlo en una ventana (diagnóstico) use **`scripts\ARRANCAR_CON_VENTANA.bat`**.
Para tener el icono de PROYECTO ALLAS (la A azul) en el escritorio, ejecute una vez `scripts\CREAR_ACCESO_DIRECTO.bat`.
Para pantalla completa en el puesto de caja use `scripts\ARRANCAR_QUIOSCO.bat` (salir con Alt+F4).

En Linux o Mac: `python3 run.py --abrir`.

La primera vez pregunta **cómo empezar**:

- **Empezar de cero**: pide los datos fiscales y crea el usuario administrador, con una tarifa de ejemplo (0,045 €/min, 5 min de cortesía, máximo 20 €/día).
- **Probar con datos de demostración**: arranca la cuenta de demostración (ver abajo) sin crear nada todavía.
- **Cargar copia de seguridad**: se elige un archivo `.db` (de otro ordenador, de la carpeta `datos\backups` de una instalación anterior o de un pendrive) o una copia que ya esté en este equipo. Se recuperan todos los datos y se entra con los usuarios y PIN de la copia. Solo vale una copia que tenga usuarios (las del programa recién instalado y vacío no aparecen). Esta opción solo existe mientras no hay ningún usuario creado.

 Por defecto la impresora está en modo **archivo** (los tickets se guardan en `salida_impresora/`); cambie a su impresora en *Ajustes → Impresora y cajón*.

Detalles de hardware e instalación en [docs/HARDWARE.md](docs/HARDWARE.md).

## Uso diario

| Tecla | Pantalla | |
|---|---|---|
| F1 | Entrada | Matrícula opcional (+ **sumar/restar minutos** a la hora de entrada) + Intro → imprime ticket (si la matrícula es de un abonado con bono, registra su entrada sin ticket) |
| F2 | Salida | Escanee ticket o tarjeta de abonado (desde cualquier pantalla) **o escriba la matrícula** en el segundo campo (se despliega la **lista de vehículos dentro** que coinciden: elija con el ratón o con ↑ ↓ e Intro); se puede **cambiar la tarifa** del vehículo antes de cobrar; Intro para **cobrar y dar salida** (la plaza queda libre al momento). **Ticket manual…**, **Facturas…** |
| F3 | Vehículos | Quién está dentro, **cambiar matrícula**, **cambiar tarifa**, reimprimir, anular · **historial** de entradas y salidas por fechas · **exportar PDF o CSV** (`matrícula;día;hora`) |
| F4 | Clientes y bonos | **Abonados** y **clientes de facturación** (filtro propio), alta de clientes y matrículas, venta y renovación de bonos, tarjeta de abonado, avisos de caducidad |
| F5 | Caja y turno | Abrir turno (con o sin arqueo de caja), ingresos/retiradas, cierre |
| F6 | Informes | Recaudación (estancias y bonos), turnos, auditoría, CSV (supervisor/admin) |
| F7 | Ajustes | Seis apartados: **Empresa** (datos y cobro, preferencias y numeración, usuarios) · **Precios** (tarifas, servicios y productos) · **Abonados** (listado, tipos de bono, pagos online y avisos) · **Tickets** (textos, impresora y cajón) · **Conexiones** (email; Madrid 360, cámaras y VERI\*FACTU) · **Sistema** (copias de seguridad, licencia, actualizaciones) |
| F8 | Tienda | Venta de productos y servicios sin matrícula ni tiempo: carrito, efectivo o tarjeta, recibo, factura con datos · **historial de ventas** con reimpresión |
| Esc | | Nuevo cobro / cerrar ventana |

Informes y Ajustes están en la parte inferior del menú, encima de la versión del programa.

Al cobrar en **efectivo** es obligatorio escribir la **cantidad recibida** (o pulsar *Exacto* o un billete): sin ella no se puede continuar. Igual en la tienda, los bonos y el ticket manual.

Al cobrar, el vehículo queda registrado como **salido** en ese momento. Si prefiere que el cliente pague y tenga unos minutos para salir, cámbielo en *Ajustes → Empresa y cobro → Al cobrar*.

## Abonados (bonos mensuales)

1. *Ajustes → Bonos*: defina los tipos (vienen de ejemplo «Mensual 24 h» 90 € y «Trimestral» 250 €).
2. *Clientes y bonos → Nuevo cliente*: nombre, NIF, teléfono y vehículos (matrícula, marca y modelo).
3. *Vender bono*: elija tipo y fecha de inicio (al renovar, empieza solo el día siguiente al bono actual); se cobra como cualquier venta y se imprime la factura.
4. *Imprimir tarjeta*: el abonado entra y sale escaneando su tarjeta en caja, o diciendo su matrícula en *Entrada*.
5. Si el bono caduca estando dentro, al salir paga solo el tiempo desde la caducidad.
6. **Pagos parciales**: al vender o cobrar un bono marque *Cobrar solo una parte ahora* y escriba el importe (efectivo o tarjeta). Cada pago lleva su factura simplificada; el resto queda **pendiente** en la ficha y el bono vale durante los días de gracia.
7. **Transferencia bancaria**: al vender o cobrar un bono, botón *Transferencia* (con referencia opcional). Regístrela cuando el dinero ya esté en la cuenta: no abre el cajón ni cuenta en el efectivo del turno; aparece aparte en Caja e Informes. Se activa o desactiva en *Ajustes → Empresa y cobro*, donde también se indica el IBAN que sale en el aviso de pago pendiente.
8. **Recordar la deuda por email**: en la ficha del abonado con algo pendiente, botón *✉ Recordar por email*. Prepara el mensaje con lo que debe (bono por bono, lo pagado y lo pendiente, y el IBAN o el enlace de pago si los hay), que se puede cambiar antes de enviarlo. Se envía al momento si el envío automático (SMTP) está configurado, o se abre en Gmail. Queda anotado en la ficha («Último recordatorio») y en auditoría. El texto por defecto se cambia en *Ajustes → Abonados → Avisos y facturas por email*.
9. **Cancelar deudas** (supervisor o administrador): en la ficha del abonado, *Cancelar deuda* en un bono o *Cancelar deudas…* para todas, con motivo. Los periodos sin ningún pago se anulan; los pagados en parte se cierran con lo cobrado. Opcionalmente deja de renovarse su bono. Queda en auditoría.

## Servicios y productos

Lavados, bebidas, recarga eléctrica… se definen en *Ajustes → Servicios y productos* (nombre, **descripción opcional que aparece en la factura**, precio con IVA incluido y tipo de IVA propio, p. ej. agua al 10 %).

- Cada servicio puede **incluir minutos de parking** (p. ej. «Lavado + 1 h»): ese tiempo se descuenta de la estancia.
- En **Salida**, con el ticket en pantalla: **+ Añadir servicio o producto**, con cantidad. Se suman a la estancia y se cobran juntos, igual que el recargo por ticket perdido.
- También desde **Vehículos → + Servicio** con el coche dentro (p. ej. pide lavado al entrar): queda pendiente y se cobra al salir.
- Las líneas no cobradas se pueden cambiar de cantidad o quitar; las cobradas no.
- La factura detalla cada línea y **desglosa el IVA por tipos**. Informes y cierre de caja muestran lo vendido.
- **Eliminar**: si el servicio ya se vendió alguna vez se oculta (las facturas no cambian); si no, se borra. Para dejar de venderlo un tiempo, desmarque «A la venta».

## Comunicados a los abonados

En *Clientes y bonos*, botón **✉ Comunicado a abonados** (supervisor o administrador): un mismo email a todos los abonados activos, o solo a los que tienen bono vigente, pago pendiente o el bono caducado. `{nombre}` se cambia por el nombre de cada uno. Muestra cuántos lo recibirán y quién no tiene email. Con el envío automático (SMTP) se manda uno a uno en segundo plano con una barra de progreso; si no, se abre Gmail con todos en copia oculta. Pide confirmar antes de enviar y guarda el historial de comunicados. Úselo para avisos del servicio: para publicidad hace falta el consentimiento de cada cliente.

## Avisos por WhatsApp / SMS

Se activan en *Ajustes → Conexiones → WhatsApp / SMS* (desactivados por defecto):

- **WhatsApp manual** (sin coste ni cuentas): el programa abre WhatsApp Web o la aplicación del PC con el número y el mensaje ya escritos; solo hay que pulsar Enviar.
- **Automático con Twilio** (de pago por mensaje, necesita Internet): el programa envía SMS o WhatsApp solo. Se indican el Account SID, el Auth Token y los números remitentes, y hay un botón de mensaje de prueba. Opcionalmente, los avisos automáticos (renovación, caducidad, pago pendiente) también salen por aquí. Por WhatsApp, Meta solo permite iniciar conversación con plantillas aprobadas: si el cliente no ha escrito en 24 h, un mensaje libre puede no llegar; el SMS no tiene esa limitación.

Con esto activado aparecen: en la ficha del abonado con deuda, el botón **💬 WhatsApp / SMS** (recordatorio corto y editable), y en *Comunicado a abonados*, el canal **WhatsApp / SMS** (en modo manual, una lista para abrir el WhatsApp de cada abonado). Se usa el **Teléfono** de la ficha (móvil 6xx/7xx o con prefijo internacional). Todo queda anotado en la ficha y en auditoría.

## Importar / exportar (clientes, tarifas, abonados)

Todo está reunido en *Ajustes → Sistema → Importar y exportar* (pestaña propia, aparte de las copias de seguridad). Los clientes se separan en **abonados** y **clientes sin abono** (los de horas, productos o servicios guardados para hacerles factura): se exportan por separado (*Abonados* en CSV o PDF con su bono, *Abonados para importar*, *Clientes sin abono*, *Todos*). Los botones *Importar / exportar…* de Tarifas y de Servicios llevan aquí.

**Importar clientes** desde **Excel (.xlsx)** o **CSV** (separado por punto y coma, coma o tabulador; UTF-8 o Windows): se elige el archivo, el programa propone qué columna es cada dato (nombre, NIF, teléfono, email, dirección, matrícula(s), marca, modelo, tipo, notas) a partir de los títulos, y se puede cambiar. Antes de importar se ve cuántos clientes **se crean**, cuántos **se actualizan** y qué filas tienen **problemas** (sin nombre, repetidas, matrícula de otro cliente…). Un cliente que ya existe se reconoce por NIF, matrícula o email: se **actualizan** sus datos y se le **añaden** los vehículos (o se deja como está, a elegir). Varias matrículas en la misma celda se separan con comas. La columna *tipo* admite «abonado» o «facturación» (cliente sin abono); si no la hay, se elige para todos. Sin el módulo Abonados se importan como clientes sin abono. Antes de importar se hace una copia de seguridad. Los `.xls` antiguos (Excel 97-2003) hay que guardarlos antes como `.xlsx` o `.csv`. Hay una **plantilla** para descargar, y **Exportar → Todos los clientes (CSV)** saca un archivo con las mismas columnas (se puede volver a importar).

## Exportar e importar tarifas y servicios

En *Ajustes → Sistema → Importar y exportar* se exportan **por separado** las **tarifas**, los **servicios** y los **productos de tienda** (o todo junto) en archivos `.json`. **Importar…** los carga (en este PC o en otro), eligiendo qué partes: muestra qué se añade, actualiza o quita, y permite elegir **Combinar** (añade y actualiza por nombre) o **Reemplazar** (deja solo lo del archivo). Antes de aplicar se hace una copia de seguridad «Antes de importar tarifas». Los vehículos que ya están dentro siguen con la tarifa con la que entraron.

## Facturas con datos del cliente y envío por email

Tras cobrar (o desde **Salida → Facturas…** / *Informes → Facturas*), **Factura con datos / email** permite añadir **nombre o razón social, NIF/CIF y dirección** (comprueba que el NIF/CIF español sea válido; los extranjeros se admiten confirmándolo). Si el vehículo es de un cliente dado de alta, sus datos aparecen ya escritos; también se puede **buscar un cliente guardado**.

Con **Guardar en Clientes** (marcada por defecto) los datos quedan como **cliente de facturación**, con la matrícula de la estancia, y la próxima vez se rellenan solos. Si ya existe un cliente con ese NIF se actualiza en lugar de duplicarse. En *Clientes* aparecen con la etiqueta «Facturación», separados de los abonados, y su ficha lista sus facturas. La vista previa se actualiza mientras se escribe, y **cualquier botón (Imprimir, Descargar PDF, Enviar) guarda los datos antes**.

Formas de enviarla por email (se elige en *Ajustes → Email*; las otras quedan como enlace en la propia factura):

- **Gmail en el navegador** (por defecto, sin configurar nada): se abre Gmail con destinatario, asunto y texto escritos y se descarga el PDF para arrastrarlo al mensaje.
- **Programa de correo del PC**: se descarga un borrador `.eml` con el PDF adjunto; al abrirlo, Outlook lo muestra listo para enviar.
- **Envío automático (SMTP)**: lo envía el programa solo. En Gmail exige verificación en 2 pasos y una «contraseña de aplicación» (botón *Rellenar para Gmail*). Si falla, el error explica qué hacer; sin Internet queda pendiente y se reintenta cada 15 minutos.

## Tarifa de reservas / hotel

Para clientes de un hotel o de una web de reservas que ya han pagado su estancia en otro sitio. En *Ajustes → Precios → Tarifas → Nueva tarifa* elija el tipo **Reserva / hotel** e indique:

- el tiempo incluido: por **noches** (con la **hora de salida**, p. ej. 12:00: 2 noches desde el día 10 = hasta el día 12 a las 12:00) o por **horas**;
- la tarifa con la que se cobra **después** (la normal del parking; si no se elige, la de por defecto).

En **Entrada**, al elegir esa tarifa aparecen las noches u horas (o una fecha y hora exactas) y el **nº de reserva / habitación**; el ticket imprime *Reserva hasta …*, el nº de reserva y el precio de después. Mientras dura la reserva no se cobra nada (sale con *Registrar salida*); pasado el fin, se cobra el tiempo **desde el fin de la reserva** con la tarifa del parking (con su cortesía y su máximo diario). En **Salida** se ve la reserva y el tiempo que queda fuera; si el cliente no lo dijo al entrar, el botón **🏨 Reserva…** se la pone al ticket (o *Quitar reserva*). La factura indica «Reserva hasta …» y que se cobra el tiempo posterior. Si la tarifa del parking se edita, las reservas nuevas usan su versión vigente.

## Tarifa de precio fijo + después

Tipo **Precio fijo + después** (en el mismo formulario de tarifas): un precio cerrado durante un tiempo (p. ej. 3,00 € las 2 primeras horas) y, pasado ese tiempo, un precio por fracción (p. ej. 1,50 € cada hora). El ticket lo muestra en dos líneas.

## Tarifas por horario (nocturna, fin de semana…)

Cada tarifa puede tener un **horario** (al editarla, *Horario (tarifa automática)*): días de la semana y/o una franja de horas, que puede cruzar la medianoche (22:00 → 08:00 cuenta para el día en que empieza). En *Entrada* aparece **«Tarifa: Automática · ahora: …»**: cada vehículo entra con la tarifa cuyo horario coincide con su hora de entrada (si coinciden varias, la más concreta, p. ej. «sábado de 20 a 6» antes que «fin de semana»); si ninguna coincide, la de por defecto. Se puede elegir otra a mano. También funciona en la caja móvil y se exporta con las tarifas.

## Tarifas: redondeo y texto

En cada tarifa: **redondeo** del importe a 0,05 € (al más cercano, hacia arriba o hacia abajo) y un **texto personalizado** que se imprime en el ticket de entrada (p. ej. «Tarifa válida de 8 a 22 h»).

## Devoluciones y rectificación de facturas (opcional)

Desde la 4.2 son **dos opciones separadas** en *Ajustes → Empresa → Preferencias y numeración → Opciones*: **Devoluciones** y **Rectificación de facturas** (desactivadas de serie; módulo **Devoluciones y rectificación**). Quien las tenía activadas juntas las conserva las dos. En la ventana de cualquier factura (Salida → *Facturas…*, Informes → Facturas o la ficha del cliente) aparecen dos botones:

- **Devolución…** (rectificativa *por diferencias*): se indica el importe (total o parcial, varias veces hasta el total), la forma (efectivo, tarjeta o transferencia) y el motivo. Se emite una **factura rectificativa** en serie aparte (`R-000001`, configurable con `serie_rectificativa`) con el IVA repartido como en la original, que se imprime para que la firme el cliente y también sale en PDF. El efectivo devuelto sale de la caja de quien devuelve (no se puede devolver más efectivo del que hay) y los informes muestran el total ya neto y cuántas devoluciones hubo.
- **Rectificar…** (rectificativa *por sustitución*, 4.0): para corregir los **datos del cliente** de una factura ya emitida (razón social, NIF, dirección, observaciones) sin mover dinero. Se emiten dos documentos: una **rectificativa** que anula la original (importe en negativo, serie R) y una **factura nueva** con los datos correctos (serie normal, «Sustituye a la A-000123 del dd/mm/aaaa»). La caja no se mueve y el total de los informes no cambia (Informes cuenta las sustituciones aparte). La factura sustituida queda marcada con el número de la nueva; las devoluciones o nuevas correcciones se hacen sobre la nueva. Una factura con devoluciones no se sustituye.

La casilla *Guardar en Clientes para próximas facturas* aparece desmarcada (4.1): márquela solo si quiere guardar ese cliente.

Con la función activada, los datos del cliente de una factura ya emitida **no se pueden sobrescribir** desde *Guardar datos* (sí añadirlos a una factura simplificada, o cambiar solo el email para enviarla): para cambiarlos, *Rectificar…*. Ambas operaciones son solo para supervisor o administrador; un cajero puede hacerlas con el usuario y PIN de un supervisor. Para VERI\*FACTU se registran como rectificativas (R5) en el mismo registro encadenado.

**Por qué va integrado y no como programa aparte.** Una rectificativa tiene que compartir con las facturas originales la numeración (series correlativas sin huecos), la huella encadenada del registro de facturación y VERI\*FACTU, el IVA y los datos de cada factura, la caja del turno y los informes. Un programa externo tendría que escribir en la misma base de datos (riesgo de romper la cadena o la numeración si los dos escriben a la vez) o llevar una numeración paralela que no cuadraría con los informes ni con Hacienda. Integrado, todo queda en una sola operación atómica y auditada; y como es un módulo con su interruptor, quien no lo necesite no ve ningún botón nuevo.

## Ticket manual

Para un vehículo sin ticket del sistema (corte de luz, impresora averiada, entrada anotada en papel): botón **Ticket manual…** en *Cobrar* o *Entrada*.

- **Entrada y salida · cobrar ahora**: se indican las dos horas, el programa calcula el importe con la tarifa y se cobra con factura. Si la **salida es futura**, se cobra por adelantado: el vehículo queda dentro y puede salir hasta esa hora (más el margen); si se pasa, paga la diferencia.
- **Servicios y productos**: se pueden añadir con su cantidad; se cobran en la misma factura (los minutos de parking incluidos se descuentan) o, si solo se registra la entrada, quedan pendientes para la salida.
- **Solo entrada · queda dentro**: imprime un ticket con la hora indicada, marcado «ENTRADA MANUAL»; al salir se cobra normal.
- El **motivo es opcional** y **no necesita autorización de supervisor**: lo puede hacer cualquier usuario con su turno abierto y queda a su nombre. La entrada no puede ser futura ni de hace más de 31 días, y queda marcado en ticket, factura, *Vehículos*, *Informes* y *Auditoría*.

## Copias de seguridad

**Copia también en el NAS (opcional):** en *Ajustes → Sistema → Copias, importar y exportar*, *Copia también en el NAS o en otra carpeta*: se escribe la carpeta (mejor la ruta de red, `\\NAS\copias_parking`), se pulsa **Probar** y **Guardar**. Desde entonces cada copia (programadas, al arrancar y al cerrar turno) se guarda además allí, con el mismo número de copias a conservar. Si un día no se puede copiar (NAS apagado, sin permisos…) aparece un aviso rojo en la campana.


*Ajustes → Sistema → Copias, importar y exportar* tiene un resumen arriba (**última copia**, si falló, y cuándo toca la próxima automática) con solo dos botones: **Hacer copia ahora** y **Programar copias…**. Debajo, la lista de **copias guardadas** (las 6 más recientes; *Ver las N copias* muestra el resto) con un único botón **Opciones…** por copia. Después, *Importar y exportar* (ver más arriba) y, plegados al final, el **registro** de operaciones y **Borrar todos los datos**.

- **Hacer copia ahora**: pregunta **qué guardar** — todo (copia completa) o solo algunos grupos: *Configuración y ajustes* (con el logo), *Clientes, abonados y bonos*, *Tickets, cobros, caja y facturas*, *Registro de auditoría*. Una copia **parcial** se restaura añadiendo o actualizando solo esos datos, sin borrar el resto; la licencia del equipo nunca se toca.
- **Programar copias…** (solo administrador) abre una ventana con la **frecuencia**: *cada cierto número de horas* (cada N horas, 6 por defecto), *a horas fijas* (una o varias horas, p. ej. 13:00 y 23:30, y los días de la semana que se elijan) o *desactivadas*. En *Más opciones*: qué guardar en ellas (todo o algunos grupos), la carpeta adicional (pendrive, disco externo o red) y cuántas copias conservar. Si el equipo está apagado a la hora prevista, la copia se hace al encenderlo. Siempre se hace además una copia completa al arrancar y al cerrar cada turno.
- **Opciones…** de cada copia: **Descargar**, **Restaurar…** o **Eliminar** (avisa si es la última que queda). Con el enlace **Subir una copia (.db)…** se añade una copia traída de otro equipo o de un pendrive.
- **Restaurar**: muestra lo que contiene la copia, pide el PIN del administrador y **guarda antes una copia del estado actual** (tipo «Antes de restaurar»), así que una restauración equivocada se puede deshacer restaurando esa copia. Tras restaurar, todos los usuarios vuelven a entrar.
- **Borrar todos los datos** (solo administrador, plegado al final): deja el programa como en la primera instalación. Pide el PIN del administrador y escribir «BORRAR TODO». Antes guarda una copia «Antes de restablecer», así que se puede deshacer restaurándola. Se conservan la licencia y la fecha de instalación; se borran tickets, facturas, clientes, tarifas, usuarios, ajustes y logo.

## Tienda

*Tienda (F8)* vende los productos y servicios de *Ajustes → Servicios y productos* sin pedir matrícula ni tiempo: se pulsan para añadirlos al carrito, se ajusta la cantidad y se cobra en efectivo o tarjeta. Emite factura simplificada y recibo (con cajón), y desde la ventana final se puede hacer la factura con datos del cliente o enviarla por email. Hace falta un turno abierto. **Historial de ventas** (botón junto al buscador): ventas por fechas, búsqueda por nº de factura, producto o cliente, **reimprimir** la copia del ticket o hacer la factura con datos / email.

**Fotos de los productos**: en *Ajustes → Precios → Servicios y productos → Editar* se puede poner una foto (*Elegir foto…*, JPG o PNG) o quitarla. El programa la reduce sola (unos KB), se ve en los botones de la Tienda y en la lista de productos, y se guarda en las copias de seguridad junto con la configuración.

## Descuentos (desactivados por defecto)

*Ajustes → Precios → Descuentos*: casilla **Activar los descuentos al cobrar** y lista de tipos de descuento, cada uno con:

- **Tipo**: *porcentaje* (p. ej. 10 %), *importe fijo* (p. ej. 2 €, nunca más de lo que se debe) o *minutos gratis* (se cobra como si el vehículo hubiera entrado esos minutos más tarde).
- **Se aplica en**: la estancia (pantalla *Salida*), la *Tienda* o ambas. Los minutos gratis solo valen para la estancia.
- **Código** opcional (p. ej. el de un vale o un sello de comercio) para escanearlo o teclearlo.

Con los descuentos activados, en *Salida* aparece el desplegable **Descuento** (con lo que descuenta cada uno para ese vehículo) y el campo **o código**; en la *Tienda*, el desplegable bajo la venta. El descuento sale como línea propia en el ticket, la factura y el PDF, el IVA se calcula sobre el importe ya descontado, y *Informes* muestra el total descontado. Si un descuento cubre toda la estancia, el botón pasa a *Aplicar descuento y dar salida*. Eliminar un tipo de descuento no cambia las facturas en las que se aplicó.

## Cuenta de demostración

Para probar el programa o enseñarlo sin tocar los datos reales: *Ajustes → Sistema → Demostración → Activar la demostración…* (PIN del administrador), o la opción *Probar con datos de demostración* del primer arranque. El programa se reinicia con una base de **datos de ejemplo** que se guarda aparte, en `datos\demo`:

- 12 abonados con bonos (vigentes, a punto de caducar, caducados, renovación pendiente y pago parcial con deuda) y 3 clientes de facturación.
- Tarifas (General, Larga estancia, Motos), productos y servicios **con foto**, tipos de bono, descuentos y vales, y publicidad para la pantalla de cliente.
- Unas cuatro semanas de entradas, cobros (efectivo y tarjeta, algunos con servicios o descuento), ventas de la tienda y turnos cerrados con arqueo, para ver los **informes**; y una docena de vehículos dentro para probar la *Salida*.
- Usuarios: `admin` PIN `1234` (administrador), `supervisor` PIN `2222`, `caja` PIN `1111` (cajero). La pantalla de acceso los recuerda.

Mientras está activa, un aviso morado arriba lo indica, con los botones **Volver a mis datos** y **Empezar de cero** (vuelve a crear los datos de ejemplo). Todo lo que se imprime lleva «DEMOSTRACIÓN - SIN VALIDEZ» y en la demo están todos los módulos, tenga la licencia que tenga. Los datos reales no se abren mientras se usa la demo.

La demo **caduca con la licencia** del programa: dura lo mismo que la prueba de 5 días o que la licencia activada (el aviso muestra los días que quedan). Cuando la licencia caduca, la demo deja de registrar entradas igual que el programa real; *Volver a mis datos* sigue funcionando. Las licencias se activan siempre fuera de la demo.

## Vales de descuento

En *Ajustes → Precios → Descuentos → Vales de descuento* (administrador o supervisor), **Generar vales…**: se elige el descuento que dan, cuántos (1 a 200), los **usos** de cada vale (*un solo uso*, *varios usos* —hasta N— o *ilimitados*), la caducidad opcional y una nota. Se imprimen como tickets con **QR y código de barras** y su código (p. ej. `V7K3M9Q2X`).

Para canjearlos: en *Salida* basta con **escanear el vale** con el ticket ya cargado (o teclearlo en *Código o vale*); en la *Tienda*, en *Código o vale*. Al cobrar se gasta un uso; un vale usado, caducado o anulado se rechaza con el motivo. La lista muestra cada vale con sus usos y estado, y permite reimprimirlo o anularlo. Si un vale no llega a descontar nada (p. ej. la estancia era gratis), no se gasta.

## Pantalla de cliente: segundo monitor o visor TPV

*Ajustes → Equipos → Pantalla de cliente*: casilla para activarla y **tipo de pantalla**:

- **Segundo monitor**: ventana a pantalla completa con letras grandes y publicidad con fotos (abajo).
- **Visor TPV de texto**: visor de cliente de 2 líneas (normalmente 20 caracteres), conectado al PC del servidor por **puerto serie / USB (COM3…)**, como **impresora de Windows** (muchos visores USB se instalan así), por **red** (IP:puerto) o con el **programa del fabricante** (p. ej. `customerdisplay.exe` de Posiflex: se indica su ruta y parámetros, con `{l1}` y `{l2}` para las dos líneas); *Archivo* sirve para probar sin visor. (4.11) El **puerto COM** se elige en una lista de los puertos que detecta el equipo (*↻ Buscar* al conectar el visor), sin elegir modelo. Protocolo **ESC/POS Epson** (el más común), **AEDEX**, **CD5220** o texto simple; 16, 20, 24 o 40 caracteres; velocidad del puerto serie. Muestra `matrícula + tiempo` / `TOTAL 4,12 EUR`, al teclear el efectivo `ENTREGADO` / `CAMBIO`, en la tienda el último artículo y el total, la despedida con el cambio y, en reposo, las dos líneas que se elijan. Botón **Probar el visor**, asistente **Ajustar las letras del visor** (prueba velocidades y protocolos hasta que las letras se lean bien) y una imitación del visor en pantalla que muestra lo mismo que el real. Los acentos y el € se sustituyen (EUR), porque muchos visores no los tienen.
- **Los dos** a la vez.

**Efectos del visor** (4.11): *Desplazar el texto*, *Parpadear*, *Escribir letra a letra* y *Entrar por la derecha*, con velocidad lenta, normal o rápida, para los mensajes de texto (reposo, bienvenida y despedida). Los importes, el cambio y la matrícula salen siempre fijos. Valen para cualquier visor de texto salvo con el programa del fabricante. *Probar el visor* lo envía al visor y lo enseña en el visor de muestra de Ajustes.

**Configurador de la pantalla de cliente** (4.12): sin botón *Guardar* (todo se guarda solo), un único botón *Abrir en el segundo monitor*, un único *Probar el visor* y un único *Poner / Quitar las fotos de ejemplo*. En la carpeta `imagenes_ejemplo` hay 17 imágenes 16:9 de diseño plano para cargar con *Añadir fotos…*.

La pestaña tiene dos partes (4.5):

1. **Pantalla de cliente**: activarla, el tipo (segundo monitor, visor TPV o los dos), los textos de bienvenida y de despedida, y **Abrir la pantalla de cliente**.
2. **Publicidad del segundo monitor**: a la izquierda, la **vista previa real** (la misma pantalla que verá el cliente, en pequeño); a la derecha, cuánto se ve cada foto, el cambio de foto (fundido, deslizar, acercar o corte), su velocidad, el orden (lista o aleatorio), cómo se ajusta la foto, dónde va el título, colores claros u oscuros, color de acento, movimiento lento, barra de tiempo y pie con fecha y hora. **Los cambios se guardan y se ven al momento**, en la vista previa y en la pantalla del cliente ya abierta (no hace falta recargarla). Debajo, las **fotos** en miniatura, cada una con su título, texto, *Se ve*, flechas para ordenarlas y *Quitar*. Trae **cuatro fotos de ejemplo** (bienvenida 24 h, abono, lavado y pago con el móvil): *Quitar las de ejemplo* / *Poner fotos de ejemplo*. Mejor fotos horizontales (16:9).

Con la pantalla activada aparece el botón **🖥 Cliente** en la barra superior: abre la ventana del cliente (en Edge o Chrome, directamente en el segundo monitor si se da permiso; si no, se arrastra allí). Pulse en ella para verla a pantalla completa. Si se actualiza el programa, la pantalla del cliente se recarga sola.

- Mientras se cobra en *Salida*: matrícula, entrada, tiempo, **total a pagar**, descuento, lo **entregado y el cambio** (se actualiza al teclear).
- En la *Tienda*: la compra línea a línea y el total. Al registrar una entrada: bienvenida con la matrícula.
- Tras cobrar: mensaje de despedida con el cambio. Sin operación: las fotos de publicidad en bucle (o el nombre del parking y la bienvenida si no hay fotos).

La ventana del cliente se alimenta de la ventana de caja del mismo navegador, así que se abre en el mismo PC que hace los cobros.

## Varios cajeros a la vez

Cada cajero abre **su propio turno** con su fondo y hace **su arqueo**: pueden trabajar a la vez dos o más personas (en dos PCs, o en el PC y en la caja móvil), y cada cobro, entrada y movimiento va a la caja de quien lo hace. En *Caja y turno*, los supervisores ven los **otros turnos abiertos** y pueden revisarlos y cerrarlos (*Ver / cerrar*). La caja móvil, si su usuario no tiene turno, cobra en el turno abierto del PC solo cuando hay uno; si hay varios, hay que abrir uno propio en el móvil.

## Caja y arqueo

*Ajustes → Empresa → Caja y arqueo*:

- **Contar por billetes y monedas** al cerrar el turno (por defecto) y, si se quiere, también el fondo al abrirlo. Desactivado, se escribe solo el total.
- **Qué billetes y monedas se usan**: se quitan los que no se manejan (500 €, 1 y 2 céntimos…) para contar más rápido.
- **Fondo de caja predefinido**: cuántos billetes y monedas de cada se dejan al empezar; aparece ya puesto al abrir el turno.

El desglose contado queda guardado con el turno y sale en el ticket de cierre.

## Caja móvil / tablet (módulo)

Con el módulo **Caja móvil / tablet** (incluido en el plan Completo), en *Ajustes → Equipos → Caja móvil* se activa el **acceso desde la red local** y se reinicia el programa. Aparece un **código QR**: al escanearlo con el móvil o la tablet (conectados al mismo WiFi) se abre la caja móvil, donde cada persona entra con su usuario y PIN y puede:

- **Entrada**: escribir la matrícula (y la tarifa) y registrar la entrada; el ticket se imprime en el PC. Los abonados se reconocen por la matrícula.
- **Cobrar**: buscar por código del ticket, tarjeta de abonado o matrícula; ver tiempo e importe; cobrar en **efectivo** (con importes rápidos y cambio) o **tarjeta**, o dar la salida si no hay nada que pagar.
- **Dentro**: lista de vehículos dentro con búsqueda; al tocar uno se cobra.

Por defecto los cobros del móvil se suman al **turno abierto en el PC** (con el nombre de quien cobra; el efectivo se entrega luego en esa caja); se puede desactivar para que solo cobre desde el móvil quien tenga el turno. Solo funciona en la red local (no desde Internet) y, la primera vez, Windows puede pedir permiso para que Python use la red (*redes privadas*). Las cámaras del móvil no se usan para leer códigos porque el navegador solo las permite en páginas https. Si se arranca con `--host 0.0.0.0` el acceso desde la red funciona como antes, sin el módulo.

## Fotos de los vehículos de los abonados

En la ficha del abonado, junto a cada vehículo, **📷 Foto** (desde el móvil o la tablet se puede hacer con la cámara). Es opcional: se reduce sola y se guarda con las copias de seguridad. La foto se ve en la ficha, al escanear la tarjeta y en *Salida* (también en la caja móvil) cuando entra un vehículo con esa matrícula, para comprobar que es el coche del abonado. Se pueden desactivar en *Ajustes → Empresa → Preferencias → Opciones*.

## Avisos y recordatorios (campana)

Icono de la **campana** en la barra superior con el número de avisos pendientes (se puede desactivar en *Ajustes → Empresa → Preferencias → Opciones*). Al pulsarlo:

- **Recordatorios y mensajes** del equipo: título, texto, desde cuándo se muestran (ahora, en una hora, mañana a las 9…) y para quién (todos, cajeros, supervisores, administradores o una persona). Cada uno se marca como *Visto* (deja de molestar a esa persona) o *Hecho* (desaparece para todos). Un cajero puede dejarse recordatorios a sí mismo; supervisores y administradores, a cualquiera.
- **Avisos del programa** (supervisor y administrador): licencia a punto de caducar o caducada, sin copias de seguridad en 3 días, abonados con pago pendiente y facturas por email con error, con un botón para ir a resolverlo.
- Pestañas con los programados, los vistos y los hechos (60 días). Cuando llega uno nuevo, aparece un aviso en pantalla.

## Supervisión (solo el fabricante o el instalador)

*Ajustes → Sistema → Supervisión*, con una contraseña que **no conoce el cliente**: la **maestra** del fabricante (en el Gestor de licencias, *Fabricante y copyright*; llega con las actualizaciones, la comprobación online o el archivo .lic) o una **propia de cada licencia** (al emitirla o renovarla en el Gestor). Solo se guarda su huella, firmada. 5 intentos fallidos bloquean 15 minutos; se cierra sola a los 30 minutos sin uso. Mientras no haya ninguna de las dos, vale la **contraseña de fábrica 8888** (4.8): el programa avisa de que es la de fábrica y deja de aceptarla en cuanto llega una maestra o una licencia con contraseña propia, así que conviene fijarla en el Gestor antes de entregar el equipo.

**Tipo de licencia** (4.8): dentro de Supervisión se puede usar el programa como un tipo **igual o más reducido** que el contratado (por ejemplo, una licencia Completo o Profesional como **Lite**, para un parking que solo cobra por horas) y volver a **Según la licencia** cuando se quiera. Los tipos que necesitan módulos que la licencia no tiene salen desactivados: para ampliar hace falta una licencia nueva. No se borra nada; el tipo elegido sale junto a la versión, los módulos recortados aparecen como *Desactivado* en *Licencia → Módulos*, los demás puestos se recargan solos y el cambio queda en la auditoría.

Dentro se marca qué se ve: **menú lateral** (Vehículos, Clientes y bonos, Caja, Tienda, Informes, Aplicaciones externas), **pestañas de Informes, Vehículos y Ajustes** y **opciones y botones** (búsqueda de actualizaciones online, comprobación online de la licencia, *Ver Acerca de*, ticket manual en Entrada, *Facturas…* en Salida, importar/exportar en Tarifas y Servicios, simular lecturas de cámara, borrar datos, campana). Lo oculto no se borra y se vuelve a mostrar desde aquí. **Guardar y aplicar** lo aplica al momento en este puesto y hace que **los demás puestos se recarguen solos** en unos segundos; **Marcar todo** vuelve a mostrar todo y **Restablecer valores de fábrica** deja lo de serie (y lo aplica). **De fábrica se ocultan** la búsqueda de actualizaciones online y el panel de comprobación online de la licencia (la licencia se sigue comprobando sola; el panel reaparece si hay que validarla).

## Clientes: abonados y clientes sin abono

En *Clientes y bonos* los **Abonados** y los **Clientes sin abono** (los de horas, productos o servicios, que solo se guardan para hacerles factura) se ven por separado, con su número; los filtros de bono solo salen con los abonados. Se exportan por separado y, en *Sistema → Importar y exportar*, **Borrar los clientes sin abono** elimina de una vez sus datos y vehículos (pide el PIN y escribir BORRAR; antes hace una copia de seguridad). Las facturas ya emitidas no cambian: guardan su propia copia del nombre, NIF y dirección. No se borran los que tienen o tuvieron un bono ni los que tienen un vehículo dentro.

## Semáforo y cartel LIBRE / COMPLETO (opcional)

*Ajustes → Equipos → Semáforo y cartel*, desactivados de inicio. Con la capacidad (*Empresa → Plazas y zonas*), el programa pone en verde/LIBRE o rojo/COMPLETO un semáforo y un cartel, cada uno con su conexión: relé o controlador de red por **URL** (Shelly, ESP…: una URL para LIBRE y otra para COMPLETO), **IP:puerto** con bytes, **relé USB / COM** (tipo LCUS) o **programa** del fabricante (`{estado}`). Se elige cuándo pasa a COMPLETO (0, 1, 2… plazas libres) y qué cuenta: todo el parking, solo rotación (sin las plazas reservadas a abonados) o una zona. Cambia solo, cada 10 minutos se vuelve a mandar, y tiene botones *Probar LIBRE* / *Probar COMPLETO*. Si no responde, aviso en la campana.

## Plantillas de tickets y facturas (4.9)

El diseño de los tickets (entrada, recibo, recibo de bono, tarjeta de abonado) y de la factura A4 se puede cambiar con el **Editor de plantillas**, un programa aparte (carpeta `EDITOR_PLANTILLAS`, con su `LEEME.md`): se abre con `ARRANCAR_EDITOR.bat`, se diseña y se guarda un archivo `.json`. En PROYECTO ALLAS, **Ajustes → Tickets** (los cuatro tickets) y **Ajustes → Factura** (la factura A4) tienen el panel *Plantillas del Editor de plantillas*: **Cargar plantilla…** (solo administrador), **Descargar** la que se usa (o la de serie, para editarla) y **Volver al diseño de serie**. Sin plantilla, todo sale como siempre; si una plantilla se dañase, se imprime con el diseño de serie. El formato es abierto y está descrito en `docs/PLANTILLAS.md`, por lo que también lo pueden usar otros programas. Los datos fiscales, el desglose de IVA y el QR VERI*FACTU de las facturas los pone siempre el programa y no se pueden quitar.

## Impresora A4 para las facturas

*Ajustes → Equipos → Impresoras y cajón → Impresora A4*: **abrir el PDF** e imprimirlo desde la ventana (elige la impresora), **directamente en una impresora de Windows** (necesita Adobe Reader o SumatraPDF), con un **programa** (p. ej. `SumatraPDF.exe -print-to "{impresora}" -silent "{archivo}"`) o guardarlo en una carpeta. En la factura aparece **Imprimir en A4** y, si se marca, el botón *Imprimir* de las facturas con datos del cliente va a la A4 en vez de al ticket.

## Caja móvil: leer con la cámara del teléfono

En la caja móvil, **Escanear ticket o tarjeta** lee el **QR o el código de barras** con la cámara del teléfono (el propio móvil lo descifra, sin Internet) y busca el ticket; **Leer matrícula** (en Entrada y en Cobrar) hace una foto a la matrícula y la lee el **PC del parking con el reconocimiento de texto de Windows 10/11** (se puede corregir antes de registrar). En la red local (http) el móvil hace una foto; con una dirección segura (https) se ve la cámara en directo. Consejo: el código de cerca, con luz y sin reflejos.

## Estabilidad

- **Puerto sin conflictos** (4.8): en la primera instalación el programa comprueba qué puertos están libres (8080, 8090, 8765, 18080…) y guarda el primero libre en `datos\puerto_preferido.txt`; los siguientes arranques usan ese. Si otro programa lo ocupa más tarde, se usa el siguiente libre y se avisa en el registro del servidor. En Windows el puerto se abre en exclusiva (dos programas no pueden compartirlo). El puerto en uso se guarda en `datos\puerto.txt` (lo leen ARRANCAR.bat y los accesos directos). Para fijar otro: `run.py --puerto N`.
- **Vigilante**: el programa se arranca como un proceso vigilado; si se cierra por un error o deja de responder unos 2 minutos, se vuelve a arrancar solo en el mismo puerto (si se cae 5 veces en 10 minutos, se para y lo explica).
- **Base de datos comprobada al arrancar** (solo lectura); si hay errores, aviso rojo en la campana. *Sistema → Servidor → Estabilidad* muestra el resultado y permite comprobarla de nuevo.
- **Errores de las pantallas** guardados en el registro del servidor y listados en *Sistema → Servidor*, para el soporte.
- **Python incluido** (opcional): `scripts\INSTALAR_PYTHON_INCLUIDO.bat` descarga una vez Python portable de python.org en la carpeta `python` del programa; desde entonces ARRANCAR.bat usa siempre ese Python, aunque cambie el del ordenador.

## Reservas de plataformas (Parclick, ElParking, Parkimeter, hotel…)

*Vehículos → Reservas*. Las reservas pagadas en otro sitio se apuntan antes de que llegue el cliente:

- **Importar listado…**: el Excel (.xlsx) o CSV que descarga cada plataforma desde su panel. Las columnas se reconocen solas (localizador, matrícula, fecha y hora de entrada y salida, cliente…) y se pueden corregir; **Comprobar** enseña lo que se haría sin guardar nada. Si se vuelve a importar el mismo listado, las reservas no se repiten (se actualizan si cambió algo). La plataforma se deduce del nombre del archivo si no se escribe.
- **Añadir reserva…** a mano (llamadas, hotel). Editar y cancelar.
- Cuando entra esa matrícula (por la caja o por la cámara) desde 2 horas antes de la hora reservada, el ticket sale **solo** con la tarifa de reserva: no se cobra el tiempo reservado y, pasado, se cobra con la tarifa del parking. En Entrada se ve el aviso verde «Reserva Parclick…» al escribir la matrícula.
- Permiso *Importar y cambiar reservas* (supervisor y administrador de serie; se puede dar a un cajero).

## Tipo de vehículo y tarifas de evento

- *Preferencias → Opciones → Tipo de vehículo en Entrada*: botones Coche / Moto / Furgoneta / Autocaravana (la lista se puede cambiar). Cada tarifa puede ser solo para un tipo (*Tarifas → Evento o tipo de vehículo*): con «Tarifa: automática» se usa la del tipo elegido.
- **Tarifa de evento** (partido, concierto, feria): fechas desde–hasta en las que gana a todas las demás; con **Precio cerrado por día** se queda en un solo precio por día.

## Plazas y zonas

*Ajustes → Empresa → Plazas y zonas*: plantas o sectores con su capacidad. En Entrada se elige la zona (las completas no se pueden elegir; sin elegir, la primera con sitio) y una zona llena no admite más entradas. **Plazas reservadas para abonados**: cuando los vehículos de rotación llegan a *capacidad − reservadas*, Entrada avisa de COMPLETO para rotación aunque quede sitio para los abonados. La ocupación por zonas se ve al pasar el ratón por la barra de plazas.

- **Color de cada zona** (4.5): al crear o editar la zona se elige un color (8 a mano o cualquiera con el selector). En Entrada las zonas son **botones de color** con sus plazas ocupadas (se recuerda la última elegida); el color se ve también en *Vehículos dentro*, en *Salida* y en la ventana de zonas.
- **Cambiar de zona un vehículo que ya está dentro** (4.5): botón **Zona** en *Vehículos → Dentro ahora* o **Cambiar zona** en *Salida*. Las zonas completas no se pueden elegir. Queda en la auditoría.

## Alertas de la explotación (campana)

*Preferencias → Opciones → Alertas en la campana*: parking **casi lleno** (por defecto al 90 %) o zona completa, vehículos **más de X días dentro** (¿abandonado o ticket perdido?), **demasiado efectivo** en una caja (conviene una retirada), **abonado con el bono caducado** que entra y **matrícula de la lista negra leída por la cámara**. 0 = sin ese aviso.

## Estadísticas con gráficos

*Informes → Estadísticas*: ingresos, ticket medio, estancia media y **rotación** (vehículos por plaza y día) con la **comparación con el periodo anterior**; ingresos por día (este periodo y el anterior), ocupación media por hora, mapa de calor de entradas por día y hora, y rankings de tarifas, servicios y productos y tipos de vehículo. 7 días, 30 días, este mes, 12 meses o fechas a elegir. Al pasar el ratón se ven los valores y cada gráfico tiene *Ver los datos* en tabla. Funciona sin Internet.

## Cierre diario por email y libro de facturas para la gestoría

*Informes → Cierre y gestoría*:

- **Resumen de cierre del día** (cobrado por forma de pago, entradas, descuentos, devoluciones, ocupación y turnos con su descuadre) y **Enviar ahora** por email. Con *Enviarlo solo al cerrar el último turno del día* llega automáticamente, con el libro de facturas del día adjunto. Usa el correo de *Conexiones → Email*.
- **Libro de facturas** (CSV que abre Excel): fecha, serie y número, tipo, NIF y nombre del cliente, base y cuota por tipo de IVA y total, de las simplificadas, completas, rectificativas y sustitutivas. Botones *Mes anterior*, *Este mes* y *Trimestre anterior* para mandarlo a la gestoría.

## Ticket digital por SMS o WhatsApp

*Preferencias → Opciones → Ticket digital*. En Entrada, **Enviar el ticket al móvil**: se escribe el teléfono y el cliente recibe el código del ticket (y el enlace para pagar con el móvil si está activado) en lugar del papel (se puede imprimir también). Con Twilio configurado en *Conexiones → WhatsApp / SMS* se envía solo; si no, se abre WhatsApp con el mensaje ya escrito.

## Estado del vehículo al entrar

*Preferencias → Opciones → Estado del vehículo*. Botón **Estado del vehículo** en el último ticket emitido y **Estado y fotos** en Salida: notas (rayones, golpes) y hasta 6 fotos desde el móvil, la tablet o la cámara del PC. Queda con el ticket por si hay una reclamación y la nota se ve al cobrar.

## Pago con el móvil (QR del ticket)

*Ajustes → Conexiones → Pago con el móvil*. El ticket lleva un segundo QR «PAGUE CON SU MÓVIL»: el cliente lo escanea, ve el importe y paga con tarjeta (Apple Pay y Google Pay incluidos) a través de **Stripe** (*Conexiones → Cobro online de bonos*); después tiene unos minutos (15 por defecto) para salir sin pasar por la caja. El pago entra como cobro «online» con su factura simplificada.

- Bizum no está disponible: Stripe no lo ofrece. Haría falta un TPV virtual de un banco español (Redsys), que se podría añadir más adelante.
- **Publicación**: la página de pago la sirve el propio PC del parking, así que necesita una dirección pública con HTTPS. Lo más sencillo es un **túnel de Cloudflare** (gratuito): se instala `cloudflared` en el PC, se crea un túnel con un nombre como `pagos.miparking.es` que apunte a `http://localhost:8080` (el puerto del programa: el de `datos\puerto.txt`) y esa dirección se escribe en *Pago con el móvil*. También vale abrir un puerto en el router con un nombre DDNS y un certificado.
- **Seguridad**: lo que llega desde Internet (por el túnel o por una IP pública) solo puede abrir la página de pago y sus datos (importe, hora de entrada y la matrícula parcial, p. ej. `12•••ABC`); el resto del programa responde «No disponible». Con el pago con el móvil desactivado, nada responde desde Internet. El pago se comprueba en Stripe (ticket e importe) antes de darlo por bueno; si no cuadra, aviso en la campana para devolverlo.

## Permisos a medida por usuario

*Ajustes → Empresa → Usuarios → Permisos*: además del rol (cajero, supervisor, administrador), a cada usuario se le pueden dar o quitar permisos sueltos: anular tickets, tickets manuales y perdidos, cambiar tarifa o matrícula, descuentos y vales, abrir el cajón, ingresos y retiradas, ver informes, turnos de otros cajeros, lista negra, reservas, abonados y exportar. Se aplican al momento y quedan en la auditoría.

## Auditoría con filtros

*Informes → Auditoría*: todo lo que se hace en el programa, filtrable por fechas, usuario, acción y texto (matrícula, nº de ticket, factura…) y exportable a CSV. Las acciones delicadas (anulaciones, borrados, devoluciones, permisos…) se marcan en rojo.

## Copia cifrada en la nube

*Ajustes → Sistema → Copias → Copia cifrada en la nube*: cada copia de seguridad se sube además, **cifrada con una contraseña** antes de salir del PC, a una carpeta de OneDrive, Google Drive o Dropbox del propio PC o a un servidor **WebDAV** (Nextcloud, NAS, pCloud, Koofr…), conservando las últimas N. Ni el proveedor ni nadie sin la contraseña puede leerla, y sin la contraseña tampoco se puede recuperar: hay que guardarla en lugar seguro. *Recuperar una copia cifrada…* la descifra y la deja en la lista de copias para restaurarla. Si una subida falla, aviso en la campana.

## Datos de factura: observaciones

En la ventana de la factura (Salida → *Facturas…*, o desde la ficha del cliente) hay un campo **Observaciones** (nº de pedido, centro de coste, obra…), que sale en la factura impresa y en el PDF.

## Barrera y datáfono (opcionales)

La barrera está en *Ajustes → Equipos → Barrera* y el datáfono en *Ajustes → Equipos → Datáfono*:

- **Barrera:** abre la barrera con un relé al dar la salida (al cobrar), al entrar un abonado y/o al emitir el ticket de entrada (a elegir), y con el botón **🚧** de la barra superior (y de la caja móvil), que pide un motivo y queda anotado. Conexiones: relé de red por URL (Shelly, ESP…), relé de red por IP:puerto con bytes, relé USB/serie (tipo LCUS: `A0 01 01 A2` / `A0 01 00 A1`) con pulso, o el programa del fabricante. Botón **Probar**. Si la barrera no responde, aviso en la campana. La orden se manda en segundo plano: el cobro no espera a la barrera.
- **Datáfono integrado:** al cobrar con tarjeta (Salida, Tienda, bonos y caja móvil) el importe se manda al datáfono y el cobro se registra cuando lo aprueba, con el nº de autorización en la factura («Referencia»). Si se deniega: *Reintentar*, *Ya cobrado aparte* o *Cancelar*. Conexiones: **simulado** (para probar), **pasarela por red** (POST JSON) o **programa** del banco / TPV-PC con `{importe}`, `{importe_cent}` y `{referencia}`. Cada banco tiene su sistema: pida a su banco la pasarela o el programa de su datáfono.

## Acerca de (copyright, licencia y fabricante)

Al pulsar **PROYECTO ALLAS** (abajo en el menú lateral) se abre *Acerca de*: logo, copyright y derechos reservados, datos de contacto del creador del software con enlace a su web, y los datos de la licencia (titular, nº, tipo, plan y módulos, validez, actualizaciones incluidas, puestos, última comprobación e ID del equipo). Los datos del fabricante los escribe el distribuidor en el **Gestor de licencias** (*Fabricante y copyright*) y van **firmados**: no se pueden cambiar en el programa. Llegan con cada paquete de actualización (`app/fabricante.json`), con la comprobación online de la licencia, dentro del archivo **.lic** de la licencia (Gestor 1.6), o a mano con *Cargar datos del fabricante…* (en *Acerca de* o en *Ajustes → Sistema → Licencia*, archivo `fabricante.json` o `.lic`); se usan los más recientes.

## Aplicaciones externas (menú lateral)

*Ajustes → Empresa → Aplicaciones externas*: botones que aparecen en el menú lateral, en el apartado **Aplicaciones externas** (se puede plegar), para abrir una **página web** (banca online, cámaras, correo, proveedor…) o un **programa, documento o carpeta** del ordenador, con argumentos opcionales. Cada botón tiene icono (letras o emoji), color, orden y quién lo ve (administrador, supervisor, cajero). Los programas se abren en el PC donde funciona el servidor de PROYECTO ALLAS; desde otros puestos o la caja móvil, mejor botones web. Cada apertura de programa queda en la auditoría.

## Lista negra de matrículas

*Vehículos → Lista negra*: matrículas con su **motivo** (impago, daños, orden policial…) y una nota interna. Solo supervisores y administrador las añaden, editan o retiran (las retiradas quedan en el historial). Se avisa:

- en **Entrada**, al escribir la matrícula (recuadro rojo con el motivo);
- al **emitir el ticket**: según *Al registrar la entrada…* — **Avisar** (el cajero decide si deja entrar y queda anotado) o **Bloquear** (solo entra con el usuario y PIN de un supervisor);
- en la **Salida** al buscar el ticket, en la **caja móvil** y con el **lector de matrículas** (no emite el ticket automático).

## Aspecto: colores y diseños

*Ajustes → Empresa → Preferencias y numeración → Aspecto*: tema claro, oscuro o automático; **color** (azul, verde, turquesa, violeta, granate, naranja o grafito) y **diseño**: *Clásico*, *Moderno* (menú oscuro y tarjetas redondeadas), *Compacto* (cabe más en pantallas pequeñas) o *Alto contraste*. Se ve al momento al elegirlos.

## Arrancar con Windows (Sistema → Servidor)

*Ajustes → Sistema → Servidor → Arrancar con Windows* (solo administrador): casilla **Abrir PROYECTO ALLAS al iniciar Windows** y el modo: **Normal** (en una ventana, como ARRANCAR.bat) o **Quiosco** (a pantalla completa, sin barras del navegador, para cajas táctiles; se sale con Alt+F4). El programa pone un acceso `PROYECTO ALLAS.cmd` en la carpeta *Inicio* del usuario de Windows y lo quita al desmarcarlo. Solo en Windows.

## Servidor del programa (Sistema → Servidor)

Pestaña propia en *Ajustes → Sistema → Servidor* (solo administrador): estado del servidor y **Reiniciar…** / **Apagar el programa…** (con PIN), en qué dirección escucha y las direcciones de la red local, base de datos y su tamaño, **sesiones abiertas** (quién, desde qué equipo y última actividad) con **Cerrar las de los demás puestos…**, y el **registro del servidor** (últimas líneas de `datos/servidor.log` cuando funciona sin ventana).

## Monitores pequeños y pantallas táctiles

- La pantalla se adapta a monitores de **1024×768** y **1280×1024** (menú más estrecho, barra superior compacta, columnas que se recolocan) y por debajo de 1000 px pasa a menú horizontal. Sin barras de desplazamiento laterales.
- **Modo táctil** (*Preferencias y numeración → Opciones → Pantalla táctil*): *Automático* (se activa en pantallas táctiles), *Sí* o *No*. Botones y campos de al menos 46 px, casillas grandes, filas de tabla más altas. Se puede fijar **solo en este equipo** (p. ej. el TPV táctil de la entrada) sin cambiar los demás puestos.

## Protección del acceso

- **PIN incorrectos:** tras 5 fallos seguidos (configurable) el usuario queda bloqueado 5 minutos; y un equipo que prueba muchos usuarios, también. Aviso rojo en la campana y, en *Ajustes → Empresa → Usuarios*, la lista de bloqueos con **Desbloquear**.
- **Sesiones:** se mantienen al reiniciar el programa (p. ej. tras una actualización); se guardan cifradas (solo un resumen del código de sesión) y caducan como antes.

## Validaciones de comercios

Para que una tienda, cine o restaurante cercano «selle» el ticket: cree un descuento (*Ajustes → Precios → Descuentos*), por ejemplo «1 hora gratis», con un **código** (que el comercio tiene en un QR o en vales impresos) y rellene **Comercio que valida**. En *Informes* aparece **Validaciones de comercios**: cuántas ha hecho cada comercio y cuánto suman, para cobrárselo o liquidarlo.

## Integraciones (desactivadas por defecto)

En *Ajustes → Integraciones*:

- **Madrid 360 · ZBE Distrito Centro.** Los aparcamientos autorizados comunican al Ayuntamiento las matrículas que han entrado cada día. Active la opción con su código de aparcamiento y descargue cada día el listado (`matrícula;AAAAMMDD;HH:MM`) para enviarlo por el canal que le indique el Ayuntamiento; márquelo como enviado. El envío automático está preparado pero no se debe usar hasta disponer de las especificaciones oficiales.
  Con Madrid 360 activado aparece una **luz de estado** en la barra superior: verde (listados al día), ámbar (falta comunicar el de ayer) o roja parpadeando (faltan días anteriores o falló un envío). Al pulsarla, el administrador va directo a los listados.
- **Cámaras lectoras de matrículas (LPR).** La cámara (o su software) hace un `POST` a `http://<equipo>:<puerto>/api/lpr/lectura` (el puerto de `datos\puerto.txt`, normalmente 8080) con la cabecera `X-Token-Camara: <token>` y el cuerpo `{"camara":"entrada"|"salida","matricula":"1234ABC","confianza":95}`. En Entrada se puede sugerir la matrícula o emitir el ticket directamente; en Salida se propone el vehículo para cobrarlo. Para cámaras en red arranque el programa con `--host 0.0.0.0`.
- **VERI\*FACTU.** Genera el registro de facturación con huella encadenada, el QR y la leyenda en tickets y facturas, y el XML de cada registro. **El envío a la AEAT todavía no está implementado** (requiere certificado electrónico y pruebas en el entorno de la AEAT): manténgalo desactivado en producción hasta completarlo con su asesoría. Obligatorio desde el 1-1-2027 para sociedades y el 1-7-2027 para el resto.

## Personalizar el ticket y la factura

- *Ajustes → Documentos → Ticket → Diseño del ticket*: tamaño del nombre del parking, líneas separadoras (guiones, dobles, asteriscos, puntos o ninguna), papel antes del corte, mostrar u ocultar razón social, NIF, teléfono, web y email, matrícula en grande, nombre del cajero que atiende y entregado/cambio. Vista previa en vivo.
- *Ajustes → Documentos → Factura (PDF)*: color principal y de la cabecera de la tabla, **logo propio de la factura** (en color) y su tamaño, títulos (con y sin datos del cliente), **notas bajo el total** (forma de pago, IBAN, condiciones), pie propio y recuadro de detalle opcional. Vista previa del PDF al momento (*Abrir en grande*).

## Confirmación al cerrar

Con *Pedir confirmación al cerrar la ventana del programa* (Opciones, activada de serie), cerrar con la **X**, Alt+F4 o cerrando la pestaña muestra el aviso del navegador antes de salir. Al apagar, reiniciar o actualizar desde el programa no pregunta.

## Facturas en PDF

El PDF es una factura A4 con la tipografía **Poppins** incrustada (licencia SIL Open Font License, ver `app/fuentes/OFL.txt`), que se ve igual en cualquier ordenador o móvil.

## Renovación automática de bonos

Por defecto **todos los bonos se renuevan solos** (se puede quitar por cliente en su ficha o al vender el bono):

1. El último día del bono se crea el periodo siguiente, **pendiente de pago**, y se avisa al abonado por email (con enlace para pagar con tarjeta si los pagos online están activos).
2. Durante los días de gracia (*Ajustes → Abonados → Avisos y facturas por email*, 7 por defecto) el abonado puede seguir entrando; en Salida, al escanear su tarjeta, aparece **Cobrar renovación**.
3. Se cobra en caja en efectivo o con tarjeta (o lo paga él online) y se emite y envía la factura.
4. Si no paga en el plazo, el bono deja de valer hasta que lo pague; si no quiere renovar, se anula esa renovación desde su ficha.

Las pendientes se ven en *Clientes → filtro «Pago pendiente»* y en *Clientes → Avisos de caducidad*. Los abonados con suscripción en tarjeta (Stripe) se renuevan con su cargo automático.

## Exportar vehículos y abonados

- *Vehículos → Exportar…* (lo que hay dentro o el historial filtrado) y *Ajustes → Abonados → Exportar*.
- **PDF**: listado con todos los datos.
- **CSV**: una línea por matrícula, `matrícula;día;hora` (ej. `9999ZZZ;20261009;23:59`). En vehículos se elige la hora de entrada, la de salida o una fecha y hora fijas; en abonados, por defecto el día en que caduca su bono a las 23:59, o una fecha y hora fijas.

## Suscripciones con pago automático (Stripe)

1. Cree una cuenta en [stripe.com](https://stripe.com) y copie la **clave secreta** (*Desarrolladores → Claves de API*, empieza por `sk_live_`; para probar sin cobrar, `sk_test_`).
2. *Ajustes → Conexiones → Cobro online de bonos*: pegue la clave y pulse **Activar pagos online**. Se crea en Stripe un enlace de pago por cada tipo de bono.
3. En la ficha del abonado: **Suscribir con tarjeta…** → el abonado escanea el QR con su móvil (o se le envía el enlace por email) y paga en la página segura de Stripe.
4. Cada periodo Stripe le cobra solo. El programa lo ve (consulta cada 10 minutos, o *Sincronizar ahora*), **renueva el bono**, emite la factura y **se la envía por email**. Si un cobro falla, le avisa por email con el enlace para pagar la factura pendiente.
5. Baja: en la ficha, *Dar de baja…* (al final del periodo pagado o inmediata).

El ordenador del parking necesita Internet para esto; si se corta, se pone al día al volver la conexión. No hay que abrir puertos ni tener página web.

## Facturas y avisos por email a los abonados

Con el **Envío automático (SMTP)** configurado en *Ajustes → Email*:

- Al vender o renovar un bono se envía la factura al abonado (se puede desactivar en general o por cliente).
- Unos días antes de caducar el bono (5 por defecto) se le avisa por email; si hay pagos online, el aviso incluye su enlace para suscribirse.
- En *Clientes → Avisos de caducidad* se ve a quién toca avisar y si ya se le avisó; también se puede enviar a mano con Gmail.

## Logo en tickets y factura

Cada uno se cambia en su menú: el **del ticket** en *Ajustes → Documentos → Ticket* (se ve cómo queda en blanco y negro, que es lo que imprime la térmica) y el **de la factura PDF** en *Ajustes → Documentos → Factura (PDF)* (en color). Si la factura no tiene logo propio, usa el del ticket. El email y la web de la empresa se escriben en *Empresa → Datos y cobro* y cada documento decide si los muestra.

## Módulos y planes

Desde la versión 3.0 el programa se divide en una **base** y unos **módulos** que se activan según la licencia:

| | Qué incluye |
|---|---|
| **Base** (siempre) | Entrada, Salida, Vehículos, Caja y turno, tarifas, servicios y productos en la estancia, ticket manual, facturas y clientes de facturación, informes, copias de seguridad, licencia y actualizaciones |
| **Abonados** | Clientes con bonos, tarjeta de abonado, renovaciones, deudas, recordatorios y avisos por email |
| **Tienda** | Pantalla *Tienda* (F8) e historial de ventas |
| **Pagos online** | Cobro de bonos con Stripe (necesita Abonados) |
| **Mensajería** | WhatsApp / SMS y comunicados a los abonados (necesita Abonados) |
| **Madrid 360 y cámaras** | Listado diario ZBE Distrito Centro y lector de matrículas |
| **VERI\*FACTU** | Registros de facturación para la AEAT |
| **Caja móvil / tablet** | Entradas y cobros desde un móvil o tablet de la red local (3.5) |
| **Descuentos y vales** (4.0) | Descuentos, vales con código y validaciones de comercios |
| **Pantalla de cliente** (4.0) | Segundo monitor y visor TPV |
| **Varios cajeros** (4.0) | Varios turnos abiertos a la vez, uno por cajero. Sin él, un solo turno abierto |
| **Tarifas por horario** (4.0) | Tarifa automática según la hora de entrada |
| **Devoluciones y rectificación** (4.0) | Devoluciones y rectificación de facturas por sustitución |
| **Barrera y datáfono** (4.0) | Relé de la barrera y datáfono integrado |
| **Entradas y salidas por horas** (4.5) | Tickets de rotación, tarifas y cobro por tiempo. Sin él, la licencia es *Abonados* |
| **Gestión ampliada** (4.7) | Clientes y factura con datos, ticket manual, servicios y productos en la estancia, historial, reservas, lista negra, zonas, informes completos (estadísticas, facturas, cierre, turnos, auditoría), aplicaciones externas, semáforo, importar y exportar. Sin él, la licencia es *Lite* |

**Planes**: *Básico* = la base con entradas y salidas por horas · *Profesional* = Básico + Abonados + Tienda + Descuentos + Pantalla de cliente + Tarifas por horario + Devoluciones y rectificación · *Completo* = todo · **Básico plus** (4.5) = todo menos la gestión de abonados (Abonados, Pagos online y Mensajería) · **Abonados** (4.5) = Abonados, Pagos online, Mensajería, Caja móvil, Varios cajeros, Devoluciones, Barrera y datáfono, Madrid 360 y VERI\*FACTU, **sin tickets por horas**. Al emitir la licencia, el distribuidor puede añadir o quitar módulos sueltos (p. ej. *Básico + Tienda*).

Desde la 4.10 los planes salen de menor a mayor —**Lite · Básico · Abonados · Básico plus · Profesional · Completo**— y cada uno tiene su color, que se ve junto a la versión, en *Supervisión* y en el Gestor de licencias. *Abonados* (antes «Solo abonados») y *Básico plus* (antes «Solo entradas y salidas») solo cambian de nombre.

- Lo que no está contratado **no aparece**: ni en el menú, ni en Ajustes, ni en las fichas (si no hay Abonados, *Clientes y bonos* pasa a llamarse *Clientes* y solo guarda datos de facturación). El servidor también lo bloquea.
- *Ajustes → Sistema → Licencia* muestra el plan y la lista de módulos, incluidos y no incluidos. El tipo de licencia (Lite, Básico, Profesional, Completo…, *Prueba* o *Demostración*) se ve también junto a la versión, abajo en el menú lateral y en la pantalla de acceso.
- Para ampliar, basta con activar una licencia nueva: los datos se conservan y lo nuevo aparece al momento.
- Durante la **prueba** y con licencias emitidas antes de la 3.0 están **todos los módulos**.
- Los módulos nuevos que se añadan en versiones posteriores entran solos en las licencias cuyo plan los incluye (p. ej. *Caja móvil* en las licencias *Completo* ya emitidas).
- En la 4.0 seis funciones que iban en la base pasan a ser módulos (las marcadas *4.0* en la tabla). Las licencias emitidas **antes de la 4.0** las conservan todas, sea cual sea su plan: nadie pierde nada al actualizar. Las licencias nuevas las llevan según su plan o los módulos elegidos en el Gestor 1.4.
- **Lite** (4.7): lo mínimo para cobrar por horas. Menú: Entrada, Salida, Vehículos (solo los que están dentro), Caja y turno e Informes (solo el resumen). En Ajustes: datos de la empresa, preferencias, caja, usuarios, tarifas, ticket, impresoras, copias, actualizaciones, licencia, servidor y supervisión. No hay clientes ni factura con datos, ticket manual, servicios y productos, historial, reservas, lista negra, zonas, estadísticas, aplicaciones externas, semáforo, importar ni exportar; el servidor también lo bloquea. Se pueden añadir módulos sueltos a una Lite.
- **Abonados** (4.5): Entrada pasa a ser *Entrada de abonados*: solo entran los abonados con el bono vigente, por matrícula o tarjeta; una matrícula que no es de un abonado al día se rechaza. No hay ticket manual, tarifas por horas ni Tienda (salvo que se añadan). Los vehículos que ya estaban dentro pueden pagar y salir.
- **Básico plus** (4.5): sin abonados (como el *Básico* cuando no se añade Abonados), con el resto de módulos.
- Las licencias emitidas antes de la 4.5 conservan las entradas y salidas por horas, sea cual sea su plan.
- Si se quita un módulo, sus datos no se borran: vuelven a verse al activarlo de nuevo.

## Licencia

- Recién instalado funciona **5 días de prueba**. El menú lateral muestra los días que quedan y arriba aparece un **aviso en rojo**; se puede cerrar con ✕, pero vuelve a aparecer a los 5 minutos (igual que el aviso de licencia a punto de caducar). Si ya no se puede operar, el aviso no se puede cerrar.
- Para activarlo: *Ajustes → Sistema → Licencia*, pegue el serial o cargue el archivo `.lic` que le envía su distribuidor. No hace falta Internet.
- Si la licencia va ligada al ordenador, el distribuidor necesita el **ID de este equipo** que aparece en esa misma pantalla.
- Sin licencia válida **no se registran entradas nuevas ni se venden bonos**; los vehículos que ya están dentro pueden pagar y salir, y se puede consultar todo, hacer copias e informes.

### Comprobación periódica (3.8)

Si su distribuidor emite la licencia con **comprobación periódica**, en *Ajustes → Sistema → Licencia* aparece el panel **Comprobación de la licencia**: cada cuántos días se comprueba, la última y la próxima comprobación y la fecha en que se bloquearía.

- El programa comprueba **solo, por Internet**, con el servidor de su distribuidor: al activar la licencia y luego cada 12 horas (cada hora si ya toca). También hay un botón **Comprobar ahora**.
- Si pasan los días indicados sin comprobar, aparece un **aviso en rojo** con los días de margen que quedan. Acabado el margen, **deja de registrar entradas** (los vehículos que están dentro pueden pagar y salir) hasta que se compruebe.
- **Sin Internet:** dé a su distribuidor el **nº de licencia** y el **ID de este equipo** (botón *Copiar nº de licencia e ID de equipo*); le enviará un **código de validación** (`VAL-…`) que se pega en el mismo panel.
- Si el distribuidor **anula** la licencia, el programa se bloquea en la siguiente comprobación.
- Atrasar la fecha del PC no alarga el plazo. Si su distribuidor cambia de servidor, la nueva dirección se puede poner en *Servidor de comprobación* (en el mismo panel).
- Las licencias sin comprobación funcionan igual que antes, sin Internet.

## Actualizaciones

1. Su distribuidor le envía un paquete `PROYECTO_ALLAS_actualizacion_X.Y.zip`.
2. *Ajustes → Actualizaciones → Subir paquete de actualización* (o copie el zip a la carpeta `actualizaciones` del programa).
3. Pulse **Instalar**: se hace una copia de seguridad, se instala y el programa se reinicia solo (hay que volver a entrar).
4. Si la versión nueva diera problemas: **Volver a esta versión** en *Versiones anteriores guardadas*. Sus datos no se tocan.

Solo se instalan paquetes firmados por el fabricante, con todos sus archivos intactos y que su licencia cubra (fecha de *actualizaciones hasta*). Las notas de cada paquete se muestran con formato (lista de novedades, negritas).

**Buscar online (experimental, 4.0).** Si su distribuidor publica las actualizaciones en su servidor (Gestor de licencias 1.4, *Servicio online → Publicar actualizaciones*), en *Ajustes → Sistema → Actualizaciones → Buscar actualizaciones online* pulse **Buscar ahora**: aparecen las versiones publicadas con sus novedades y **Descargar** baja la nueva. Se comprueba la huella (SHA-256) y la firma del fabricante antes de guardarla; luego se instala con **Instalar**, igual que un paquete subido a mano. La dirección del servidor es la de la licencia (comprobación periódica) o la que se escriba en ese panel.

**Actualizar online (4.16/4.17).** En *Buscar actualizaciones online* basta pulsar el botón: el programa consulta el servicio de actualizaciones (origen configurado internamente por el distribuidor, no visible en pantalla), enseña los paquetes más nuevos y permite *Descargar* o *Descargar e instalar*. Todo paquete debe llevar la firma del fabricante. También se puede usar *Subir paquete…* con un archivo local.

Las licencias y los paquetes se crean con el **Gestor de licencias**, un programa aparte que no se entrega a los clientes (ver su `LEEME.md`).

## Documentación

- [Arquitectura, módulos y base de datos](docs/ARQUITECTURA.md)
- [Plan de implementación (incluye VERI\*FACTU)](docs/PLAN.md)
- [Formato de plantillas de tickets y facturas](docs/PLANTILLAS.md)
- [Hardware e instalación](docs/HARDWARE.md)

## Estructura

```
run.py                 arranque (--host, --puerto, --datos, --abrir)
app/db.py              esquema SQLite y migraciones
app/tarifas.py         motor de cálculo de importes
app/servicios.py       lógica de negocio
app/impresion.py       ESC/POS, QR, cajón, transportes
app/backup.py          copias de seguridad
app/server.py          API HTTP y sesiones
web/                   interfaz de caja (index.html, style.css y js/ por áreas)
tests/                 pruebas automáticas
scripts/               arranque Windows/Linux y servicio systemd
datos/                 (se crea al arrancar) base de datos y copias
```

## Pruebas

```bash
python -m unittest discover -s tests -v
```

## Aviso fiscal

El sistema numera facturas simplificadas y guarda un registro encadenado e inalterable, que es la base técnica del Reglamento de sistemas de facturación (VERI\*FACTU). Desde la 1.6 genera además (si se activa en *Ajustes → Integraciones*) el registro de alta VERI\*FACTU con huella y QR; el envío a la AEAT y la declaración responsable están planificados en la fase 3 de [docs/PLAN.md](docs/PLAN.md) y deben revisarse con su asesoría antes de la fecha obligatoria.

**Arranque con barra de progreso (4.18).** Al abrir `ARRANCAR.bat` se muestra una barra de progreso mientras carga el servidor (sin ventana de comandos). Si algo falla o el servidor se para, se abre automáticamente una ventana de comandos con el diagnóstico. Para ver siempre el servidor en una ventana: `scripts\ARRANCAR_CON_VENTANA.bat`.

**Segunda pantalla (4.19).** En entrada y salida, la matrícula se muestra centrada y estilizada, con los datos en fichas y, al cobrar, una banda con total, desglose y cambio.

**Actualizaciones (4.20).** Buscar online y subir paquete local están en el mismo cuadro, junto a la versión instalada.

**Actualizaciones (4.21–4.23).** La pestaña muestra la versión instalada con sus dos botones, la última actualización lista solo cuando existe y las novedades de las versiones anteriores (solo consulta, sin restaurar).

**Novedades acumuladas (4.22).** Solo se ofrece la última actualización y su desplegable «Novedades» incluye los cambios de todas las versiones desde la instalada.

**Versiones anteriores (4.23).** Solo se consultan sus novedades; no se pueden restaurar desde el programa. La ventana de arranque con barra de progreso usa el mismo estilo que el software.

**Avisos de actualización (4.24).** Al arrancar y cada día el programa busca una versión nueva y, si la hay, lo avisa en notificaciones. La pantalla de cliente tiene una barra de secciones (General, Visor TPV, Aspecto del monitor, Fotos).

**Versiones anteriores (4.25).** Solo salen las que se instalaron como actualización en el equipo; las novedades de cada versión se muestran con un formato de tarjetas.

**Impresoras (4.26).** Las impresoras de Windows se detectan solas y se eligen de una lista; el asistente de primer inicio es compacto y cabe en pantalla.

**Arranque (4.27).** La pantalla de carga usa el diseño del programa y salta sola a la aplicación; si falla, abre el diagnóstico. La búsqueda de actualizaciones online viene activada y las novedades se muestran también al confirmar la instalación.


**4.28:** el ticket de salida se puede imprimir o no (Ajustes → Tickets y casilla en la pantalla de cobro, guardada al pulsar «Siguiente»). Sin imprimir, el cajón se abre igual y el recibo se ve en pantalla.


**4.29:** búsqueda de actualización forzada en cada arranque (aviso en notificaciones), novedades completas desde la versión instalada y pantalla de carga con logo y nombre.


**4.30:** la ventana del programa se abre maximizada (Edge con `--start-maximized` y ajuste de respaldo desde la propia página).


**4.31:** servicio personalizado (descripción + precio) solo para la venta en curso, y «Anular ticket…» en lugar de «Ticket perdido…» en Salida.


**4.32:** en «Vehículos dentro» cada fila tiene el botón Cobrar y un menú ⋯ con el resto de acciones (Anular al final, en rojo).


**4.33:** la sección «Actualización lista para instalar» se rediseña: ruta de versiones (4.25 → 4.33), resumen de novedades, botón principal siempre visible y novedades en una columna con desplazamiento.


**4.34:** menú ⋯ de acciones de fila en todas las tablas (lo destructivo al final, en rojo), aviso de licencia discreto (últimos 3 días, cerrado = hasta mañana) y guía de colores y textos coherente.


**4.35:** menú «Herramientas» en la barra superior (pantalla del cliente, última impresión) y buscador de ajustes con apartados compactos.


**4.36:** los apartados de Ajustes recuperan su aspecto de tarjetas con descripción; el buscador se mantiene.

**4.37:** revisión de accesibilidad: foco visible, ventanas con control de teclado, respeto de «reducir movimiento» y «Deshacer» al quitar un servicio en el cobro.

**4.38:** casilla «Deja las llaves» en Entrada y su texto en el ticket; matrícula arriba en el ticket de entrada; motivo de anulación opcional; imprimir salida desmarcado por defecto; botón Imprimir en «Ver recibo»; reimpresión del ticket de entrada tras cobrar.

**4.39:** se retira el botón «Reimprimir ticket de entrada» tras cobrar.

**4.40:** interruptores rápidos de tema y densidad (compacta/cómoda) en Herramientas, por equipo.

**4.41:** tema «Negro y amarillo» de alto contraste.

**4.42:** se retira el tema negro y amarillo; color de acento «Amarillo»; las novedades de la actualización online se ven antes de descargar.

**4.43:** tickets más cortos; reserva de hotel por fecha (entrada actual con botón para cambiarla, salida reservada); orden de las tarifas en el selector.


**4.45:** el ticket de entrada ya no lleva precios (opción de imprimir una dirección web para consultarlos); color «Blanco y negro»; revisión de contrastes del tema oscuro y de la prioridad Ajustes/Herramientas.

**4.46:** el color de acento y el diseño solo se aplican con sesión iniciada (`aplicarTema`); acceso, carga y logos llevan el azul original; el ticket de reserva dice «Sin cargo hasta».

**4.47:** la ventana de confirmar la instalación de una actualización muestra datos (versión, fecha, tamaño, copia de seguridad) en lugar de repetir las novedades.

**4.48:** ticket manual en dos columnas para que quepa en pantalla; caja de reserva de hotel rediseñada.\n
**4.49:** eliminar usuarios (se archivan, conservando su historial); control de turnos por QR activable (QR personal, pantalla /fichar, listado de fichajes y CSV).

**4.50:** historial del vehículo y comentarios internos por matrícula (visibles en Dentro ahora, Entrada y Salida).

**4.51:** el fichaje del personal se hace con el lector de códigos del equipo (Caja y turno, Entrada y Salida); el QR se imprime en ticket (con corte ajustable), se guarda en PDF o se envía por correo; botón «Actualizaciones» en Acerca de; datos del fabricante junto al serial en Ajustes.

**4.52:** PIN bloqueado hasta elegir usuario en el acceso; comentario interno en tarjeta ordenada y, en la lista de vehículos, solo un icono que se pulsa para leerlo.

**4.53:** QR de fichaje rehecho (FICHA + 12 dígitos, se lee en cualquier pantalla), textos opcionales del QR impreso y fichaje integrado con el turno de caja (panel «Jornada y turno», modos automáticos, turno en el listado).

**4.54:** descuento fijo en % por cliente (se aplica solo al cobrar), «Ver Acerca de» fuera de Licencia y ventana de opciones cuando en Entrada se repite una matrícula o ticket que ya está dentro.

También en 4.54: confirmación opcional al fichar la salida, con resumen de la jornada y del turno de caja.

**4.55:** Salida con un único campo que detecta si es ticket/tarjeta, vale, fichaje o matrícula.

**4.56:** «Modificar matrícula y tarifa» en un solo botón de la lista de vehículos y acceso al estado del vehículo (daños y fotos) desde esa lista.


**4.57:** en el modo demostración se elige cuántos clientes, bonos, vehículos dentro y días de historial se crean.


**4.58:** impresión «solo en pantalla», factura a proveedor (serie propia, sin bonos), sello del garaje en ticket y factura, título centrado y enlace de actualizaciones editable en Supervisión.


**4.59:** QR de turnos más grande y barra superior con logo y nombre a la izquierda, luego la ocupación.


**4.60:** proveedores como apartado propio (servicios y precio por proveedor, solo factura) y formulario de cliente ordenado por bloques.


**4.61:** el parking incluido de un servicio se elige en minutos, horas o días.

**4.62:** historial de actualizaciones en Ajustes (5 últimas, «Mostrar todas» y descarga en .txt vía `GET /api/actualizaciones/historial.txt`); novedades con mayúscula tras los dos puntos (`mayuscula_tras_dos_puntos`); servicios de precio variable (`productos.precio_variable`, migración 34): el precio se pide al seleccionarlos (`pedirPrecio`) y el servidor exige `precio_cent` en `anadir_extra` y `_extras_manual`.

**4.63:** los servicios del proveedor se gestionan en su ficha (`POST /api/proveedores/{id}/servicios`, `DELETE /api/proveedores/{id}/servicios/{producto}`; `guardar_servicio_proveedor`, `quitar_servicio_proveedor`); `guardar_cliente` solo toca los servicios si llega la clave `servicios`; el selector de tipo va sobre el nombre.

**4.64:** estado de factura (`pagos.estado_factura`, migración 35: generada/enviada/cobrada; `PUT /api/facturas/{id}/estado`, `cambiar_estado_factura`, `_marcar_enviada`); las facturas a proveedor (`es_factura_proveedor`) no se imprimen en ticket: `/imprimir` va a A4 y `imprimir_factura` las rechaza.

**4.65:** `ampliarModal` (nucleo.js) ensancha las ventanas hasta que no haya scroll vertical si con ello gana altura; ficha del cliente en `.ficha-grid` (principal + lateral `.ficha-lado`); formulario de cliente con rejilla de 4 columnas en pantallas anchas.

**1.0:** numeración nueva (1.0); el historial de cambios de Ajustes llega solo hasta la versión de la primera instalación (`config.version_inicial`, migración 36); Ajustes reorganizado en siete apartados (nuevo «Equipos» con impresoras, pantalla de cliente, barrera, semáforo, datáfono y caja móvil; «Tickets» pasa a «Documentos»).

**1.1:** `facturar_proveedor` fuerza transferencia y una sola línea por factura; `GET /api/clientes/{id}` devuelve en `facturas` el servicio y `estado_factura`; `modalFactura` tiene modo proveedor (`resumenFacturaProveedor`); productos `solo_proveedor` sin precio de catálogo.

**1.2:** `app/errores.py` (`fallo(donde, exc, grave)`, `recientes`) sustituye a los `except Exception: pass`; los graves salen en `avisos_sistema` (id `errores_internos`, solo admin); `actualizacion.comprobar` distingue igual, anterior, numeración nueva sobre 4.x y puente sobre 1.x; se elimina `ajAbonados` (Ajustes → Abonados → Listado); `numeracion()` devuelve `rectificativa` y `guardar_numeracion` rechaza serie de facturas = rectificativa; helpers `ventanaForm` (nucleo.js), `chipEstadoFactura` y `opcionesEstadoFactura` (facturas.js).

**1.3:** `App._registrar` solo registra `rutas44/50/58` y llama a `registrar(app, r, p)` de `rutas_sistema`, `rutas_acceso`, `rutas_caja`, `rutas_tickets`, `rutas_clientes`, `rutas_facturacion` y `rutas_pantalla` (el cuerpo es el de antes, con `app` en lugar de `self`). Las 302 rutas son las mismas y ninguna patrón se solapa con otro, así que el orden entre módulos no influye. `tests/test_navegador.py` (Playwright + Chromium, se omite si no están) arranca el servidor con la demostración y falla ante cualquier error de JavaScript. Para `leer("app", "server.py")` las pruebas de texto incluyen los `rutas_*.py`.

**1.4:** la clase `Parking` (6.356 líneas en `servicios.py`) se reparte en las mezclas `SvcSistema`, `SvcLicencia`, `SvcUsuarios`, `SvcTarifas`, `SvcCaja`, `SvcTickets`, `SvcCatalogo`, `SvcEquipos`, `SvcFacturas`, `SvcIntegraciones`, `SvcClientes`, `SvcAvisos`, `SvcOnline` y `SvcDocumentos` (`app/svc_*.py`); en `servicios.py` quedan `__init__`, `ahora`, `auditar`, `cfg` y la unión de todas (van antes que `Funciones43…50`, igual que antes mandaban los métodos propios sobre los de esas). Las funciones y errores comunes (`ErrorNegocio`, `eur`, `iso`…) pasan a `app/utiles.py` y `servicios.py` las vuelve a exportar. Los 485 métodos y atributos de `Parking` conservan su código idéntico; solo se retiró un `_tipo_imagen` duplicado que el posterior ya pisaba. Para las pruebas de texto, `leer("app", "servicios.py")` incluye `svc_*.py` y `utiles.py`.

**1.5:** `server.CABECERAS_SEGURIDAD` y `server.CSP` (esta solo en `text/html`; `style-src` admite `'unsafe-inline'` porque la interfaz genera `style="…"`, los scripts no); scripts en línea movidos a `web/js/tema.js` y `web/js/pagar.js` (`cargando.html` se abre como archivo y no la sirve el servidor); `server.dentro_de(base, ruta)` sustituye al `startswith(WEB)`. `tests/test_seguridad.py` recorre todas las rutas (sin sesión, cajero, supervisor), fija el conjunto `PUBLICAS` (una ruta pública nueva obliga a editar la prueba) y comprueba escapes de carpeta y ausencia de manejadores en línea. Riesgos conocidos sin cambiar: PIN de 4 dígitos, HTTP sin cifrar en la red local de la caja móvil y `/api/demo/salir` público (solo actúa si está en modo demostración).

**1.6:** módulo `app/tablas.py` (sin librerías): `Tabla` (título, columnas, filas) y los escritores `a_csv`, `a_xlsx` (zip de XML), `a_xls` (libro BIFF8 dentro de un archivo compuesto OLE2, máximo 65 535 filas) y `a_pdf` (sobre `pdf.listado_a_pdf`), más `leer_xls` (OLE2 + BIFF8: cadenas compartidas con continuaciones, números RK, fechas y fórmulas con resultado en caché), que `importar.leer` usa al ver la firma `D0CF11E0`. Mezcla `svc_tablas.py` (`SvcTablas`): `tabla_exportable(conjunto)` (los 7 de `CONJUNTOS`), `tabla_plantilla`, `config_desde_tabla` (servicios y productos desde una tabla, al mismo formato que `exportar_config`, para reutilizar la vista previa y el aplicar de `importar_config`) y `resumen_borrar_clientes` / `borrar_clientes` (ámbito `no_abonados` o `todos`; protege clientes con bono, suscripción o ticket dentro/pagado). Rutas en `rutas_tablas.py`, todas de administrador: `GET /api/exportar/tabla/<conjunto>.<csv|xlsx|xls|pdf>`, `GET /api/plantilla/<clientes|servicios|productos>.<csv|xlsx|xls>`, `POST /api/config/importar/leer`, `GET|POST /api/clientes/borrar-todos` (PIN, «BORRAR» y copia previa). La pantalla es `ajImportar` en `web/js/ajustes-sistema.js`. El .xls se ha validado con LibreOffice y con nuestro propio lector, no con Excel.

**1.7:** solo interfaz. `menuFormatos` / `enlazarMenu` en `web/js/ajustes-sistema.js` (menús `<details class="menu-fmt">` que se cierran al elegir, al pulsar fuera o con Escape) sustituyen a las filas de botones de Importar y exportar; los chips de zona (`.chip-zona`) pasan a una barra segmentada neutra sin color por zona.

**1.8:** reservas online (motor y pantallas del personal; la página pública llega en la 1.9). `app/svc_reservas.py` (`SvcReservas`, mezclado en `Parking`) guarda las reservas en `reservas_previstas` con `origen` `mostrador`/`web` (las de plataformas son `plataforma`), zona, tipo de vehículo, contacto, `codigo` único (R-XXXXXX), `importe_cent` y `pago`; la migración v37 añade esas columnas y `zonas.cupo_online`. El interruptor es la clave `reservas_online_activas` (apagado por defecto): todas las operaciones de reserva online lo exigen (409 si está apagado). La disponibilidad cuenta el máximo de reservas simultáneas dentro del intervalo contra el cupo de la zona (o `reservas_cupo` sin zonas), y la comprobación y el INSERT van en la misma transacción. El precio usa `tarifa_para` + `calcular_importe` (tarifa normal). `emitir_ticket` enlaza la reserva online con el ticket pero **no** aplica tarifa de reserva (no descuenta tiempo). Rutas en `app/rutas_reservas.py` (`/api/reservas-online/…`, todas con sesión; configuración solo admin; dentro del módulo `gestion`). Interfaz: `ajReservasOnline` (`ajustes-conexiones.js`) y `modalReservaOnline` (`vehiculos.js`). La 1.9 debe añadir la capa pública (API con límite de peticiones, email de confirmación, pago opcional) sin duplicar esta lógica.

**1.9:** horario del parking y plazas por reserva. `app/svc_horario.py` (`SvcHorario`): claves `horario_activo`, `horario_semana` (JSON por día ISO: abierto, desde, hasta, 24h; si hasta < desde cruza la medianoche) y `horario_cerrados` (JSON de fechas). `parking_abierto(momento)` devuelve (abierto, texto); `_exigir_abierto(usuario)` se llama al principio de `emitir_ticket`, `entrada_abonado`, `cobrar` y `registrar_salida` y no bloquea a los roles admin y supervisor. `abierto_en_momentos` valida entrada y salida de las reservas online. Rutas `GET/PUT /api/horario` (la escritura, solo admin). Migración v38: `reservas_previstas.plazas`; el cupo suma plazas (barrido de intervalos con peso) y el máximo por reserva es `reservas_max_plazas`. Interfaz: `ajHorario` en `ajustes-conexiones.js`.

**1.9.1:** `_ocupacion_maxima` (`svc_reservas.py`) cuenta también las reservas online `usada` cuyo ticket sigue `dentro`/`pagado` (hasta la salida; si ya pasó su `hasta`, durante toda la ventana consultada), además de las pendientes: el cupo de la zona es el máximo de coches con reserva a la vez.

**1.9.3:** en `svc_horario.py` los festivos (`horario_cerrados`, nombre conservado por compatibilidad) usan la franja del domingo (`_franja_dia`); las reservas validan su salida un minuto antes para poder salir justo al cierre. `/api/estado` incluye `actualizacion_nueva` (solo admin, a partir de `actualizacion_aviso`); `pintarAvisoActualizacion` (`interfaz.js`) y el bloque `.marca-bloque` del menú.

**1.10:** página pública de reservas. `app/svc_reservas_publicas.py` (`SvcReservasPublicas`): activa si `reservas_online_activas` y `reservas_publicas_activas` (apagadas por defecto); `limpiar_publico` reduce lo que llega a campos conocidos de texto o número; `_limitar` es un límite de peticiones en memoria por clave (IP o email); campo trampa `web`; `pub_crear` llama a `crear_reserva_online(None, …, origen="web")`, así que cupo, horario y antelación son los mismos que en el programa; `pub_ver`/`pub_cancelar` buscan con código + matrícula; el email se envía en un hilo (`enviar_email_reserva`; estados `enviado`, `pendiente`, `sin_correo`, `error`) y `reintentar_emails` también reintenta los de reservas. Rutas `/api/publico/reservas/…` (publica=True) y página `web/reservar.html` + `web/js/reservar.js`. En `server.py`, `RUTAS_RESERVAS` / `_ruta_reservas` se sirven solo si están activadas y la petición no viene de Internet (`_es_publico`), con independencia de `pago_movil_activo`. Para publicarla fuera de la red local faltan HTTPS, un proxy que fije la IP real del cliente (el límite usa la IP de la conexión) y revisar el reparto del límite de peticiones.

**1.11:** avisos de reservas. Migración 40: `reservas_previstas.revisada` (0 = reserva de un cliente aún sin confirmar; el resto 1). `SvcReservas.aviso_reserva(texto)` busca por matrícula (solo pendientes con `hasta` futuro) o por código `R-XXXXXX` y devuelve `{reserva, aplica, motivo (ok|antes|caducada|usada|cancelada), ventana_desde}` sin datos personales; `reservas_por_revisar`, `n_reservas_por_revisar` y `confirmar_reserva_online` alimentan el aviso de reservas nuevas (`/api/estado.reservas_nuevas`, solo con permiso `reservas`). `emitir_ticket` enlaza ahora las reservas online (`origen` mostrador/web) con cualquier `tarifa_id` y fuerza su zona; las de plataforma siguen necesitando tarifa automática o de reserva (la interfaz manda `tarifa_id=null` al confirmar la ventana). `ticket()` añade `reserva_info` (enlazada) o `reserva_pendiente`; `vehiculos_dentro` añade `reserva_codigo`. Interfaz: `web/js/reservas-aviso.js` (ventanas, lectura de `R-XXXXXX` con el lector, insignia y sondeo en `pintarBarra`), vista `reservas` en `VISTAS` (F9, módulo `gestion`; `veh:reservas` sigue ocultándola). Página pública: `reservar.html` con rejilla de dos columnas desde 900 px (resumen fijo) y una columna por debajo.

**1.12:** cobro de la reserva. Migración 41 en `reservas_previstas`: `senal_cent`, `pago_limite`, `pago_fecha`, `pago_metodo`; `pago` pasa a valer `en_parking | pendiente_pago | pagada | a_devolver | devuelta`. Config: `reservas_pago_modo` (`parking|senal|total`), `reservas_senal_tipo` (`fijo|porcentaje`), `reservas_senal_valor` (céntimos o %), `reservas_pago_horas`, `reservas_pago_instrucciones`. `senal_para(importe)` calcula la señal; `crear_reserva_online` la fija (plazo = mín(ahora + horas, entrada)) y el personal puede crearla ya cobrada (`senal_cobrada`); `caducar_reservas_sin_pago` cancela las vencidas y se llama al crear, consultar disponibilidad, `aviso_reserva`, `reserva_para`, `reservas_llegadas` y en `reintentar_emails_reservas`. `marcar_senal_cobrada` / `marcar_senal_devuelta` solo anotan (no tocan caja, pagos ni facturas: no hay pasarela en línea); cancelar con señal cobrada pone `a_devolver`. `reservas_llegadas()` alimenta el panel de Entrada. `POST /api/reservas-online/qr` genera el SVG del QR de la página (`codigos.qr_svg`, URL validada, máx. 150 caracteres). Interfaz: `montarQrReservas`/`cartelQrReservas` (impresión con `body.imprimiendo-cartel`), `avisoPorDeteccion` y `cargarLlegadas` en `reservas-aviso.js`.

**1.13:** limpieza de actualizaciones. `POST /api/actualizaciones/limpiar` (admin): `paquetes` = `inutiles` (los de `motivo_limpieza` no nulo: `no_valido|instalada|anterior|incompatible`), `todos` o lista de nombres (se pasan por `basename` y solo se borran los que `paquetes_en_carpeta` ya lista); `copias` borra `datos/versiones/*` válidas; `historial` = `limpiar|restaurar` fija `actualizaciones_historial_desde` (`desde_historial()` toma el mayor entre ésta y `version_inicial`; no toca `auditoria`). `paquetes_estado()` reúne el cálculo de estado/instalable que antes estaba en `GET /api/actualizaciones`. Interfaz: `montarLimpiezaActualizaciones` en `ajustes-sistema.js`.

**1.14:** la página pública de reservas sale del programa. `server.py` ya no sirve `/reservar` ni `reservar.js` (`PREFIJO_RESERVAS` = `/api/publico/reservas`); la página vive en `integracion_web/` (con `window.ALLAS_API` como base de la API; `kit_web_reservas()` la empaqueta con la dirección guardada en `reservas_url_publica`). La API pública de reservas solo se sirve con `reservas_publicas_activas` y, si la petición llega de Internet, con `reservas_internet=1`. CORS (`_cabeceras_cors`, `do_OPTIONS`): lista `reservas_origenes` separada por comas o `*`, solo en rutas de reservas. `_ip_cliente()` toma la última IP de `X-Forwarded-For` que no sea un proxy de `reservas_proxies` para el límite por IP. El email enlaza a `reservas_web_url` (`?c=` o `&c=`). Se retiran el QR/cartel (`/api/reservas-online/qr`, `montarQrReservas`) y los estilos asociados. 

**1.15:** `scripts/web_pruebas.py`: servidor `http.server` de pruebas que sirve `integracion_web/` (salvo `.md`) y reenvía solo `/api/publico/reservas*` al programa (`crear_handler(programa)`; devuelve 502 si no responde); `buscar_programa()` sondea `/api/ping` en `datos/puerto.txt` y 8080-8099. Mismo origen, así que no necesita CORS. `scripts/ARRANCAR_WEB_PRUEBAS.bat` lo lanza. Todo vive bajo `scripts/` (también `integracion_web/`) porque las versiones ya instaladas solo aceptan en un paquete de actualización las carpetas `app`, `web`, `scripts` y `docs`: un archivo nuevo en la raíz hace que el paquete se rechace.

**1.16:** web de pruebas integrada. `app/web_pruebas.py`: `crear_handler(programa, web)` (sirve `scripts/integracion_web` salvo `.md` y reenvía solo `/api/publico/reservas*`), `WebPruebas(app)` (`activar(red)`, `parar()`, `estado()` con `url`, `urls`, `qr`, `puerto`, `reservas_listas`; prueba los puertos 8090-8099 sin usar el del programa; escucha en `0.0.0.0` solo con `red`). `App.web_pruebas` se crea en `App.__init__`, se para en `programar_reinicio()` y `servir()` fija `app.puerto`. `GET/POST /api/reservas-online/web-pruebas` (admin, auditado). Interfaz: `ajReservasOnline` se divide en pestañas (`RO_PESTANAS`) dentro de un único formulario; `pintarPrueba()` pinta el botón, la dirección, el QR y el aviso superior. `scripts/web_pruebas.py` queda como envoltorio de línea de comandos.

**1.17:** `reservas_min_minutos` (0-1440, por defecto 0): `_fechas_reserva` rechaza las reservas de origen `web` más cortas; el personal queda exento. `pub_config` la expone como `min_minutos` y `scripts/integracion_web/reservas.js` la muestra.

**1.18:** tres bloques sobre las reservas online. **(A)** `scripts/servidor_reservas/relay.py` (stdlib) es un servidor intermedio: cola de peticiones públicas (`/api/publico/reservas*`) en memoria, estáticos de la página, límite por IP, CORS por lista, clave `Bearer` comparada con `hmac.compare_digest`; `app/agente_reservas.py` (`AgenteReservas`, `App.agente`) es un hilo que hace long-poll saliente a `/agente/esperar`, ejecuta cada petición por `127.0.0.1:{puerto}` con las cabeceras `X-Allas-Relay` (token aleatorio del proceso) y `X-Allas-IP`, y publica la respuesta en `/agente/responder/{id}`. `_ip_cliente` solo da por buena `X-Allas-IP` si viene de loopback con el token del agente; el agente rechaza cualquier ruta que no empiece por `/api/publico/reservas` y cualquier método que no sea GET/POST. Se arranca en `servir()` y al guardar los ajustes. **(B)** `svc_reservas_pago.py`: `pub_pagar` crea una sesión de Checkout por `senal_cent` (metadatos `reserva`=código; se reutiliza si sigue abierta), `confirmar_senal_stripe` (al volver, en `pub_ver`, en `caducar_reservas_sin_pago` y cada pocos minutos en `sincronizar_senales_stripe`) verifica pago, código e importe y marca `pagada` con `pago_ref`=payment_intent; si no cabe en la reserva, se reembolsa. `cancelar_reserva_online` reembolsa sola (`reembolsar_senal_auto`) y cierra sesiones abiertas. `aplicar_senal_a_ticket` inserta en `pagos` (vía `_insertar_pago`, sin turno) la señal como pago anticipado del ticket una sola vez (`senal_pago_id`), llamada al emitir el ticket y al cobrar la señal con el coche dentro; `_liquidar` añade `a_favor_cent`. **(C)** `svc_reservas_despues.py`: `modificar_reserva_online` (revalida fechas, cupo con `excluir`, solape de matrícula y recalcula importe/señal), `liberar_no_presentadas` (estado `cancelada` + `noshow=1`, la señal pagada se retiene), `enviar_recordatorios_reservas` (QR PNG adjunto con `codigos.qr_png`, una vez por reserva) e `informe_reservas[_csv]`. `tarea_periodica` ejecuta liberación, recordatorios y sincronización de señales.

**1.19:** `vehiculos_dentro` calcula `pago_estimado_cent` con `_liquidar` por ticket (si una tarifa falla devuelve `null` y registra el error) y ordena por `entrada DESC`; la pestaña de Vehículos se llama «Presentes». En Entrada el panel `#e-llegadas` va antes que `#e-ultimo`; el ocultar se guarda en `localStorage` (`allas_ultimo_oculto`).
